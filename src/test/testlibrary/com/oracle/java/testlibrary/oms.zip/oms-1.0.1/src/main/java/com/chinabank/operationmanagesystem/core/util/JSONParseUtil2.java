/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-3-26</li>
 * <li>3、开发时间：下午4:23:09</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.util</li>
 * <li>6、文件名称：JSONParseUtil2.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.chinabank.operationmanagesystem.core.adapter.TypeAdapterManager;
import com.chinabank.operationmanagesystem.core.bean.Element;
import com.chinabank.operationmanagesystem.core.bean.form.Form;
import com.chinabank.operationmanagesystem.core.bean.grid.ColModel;
import com.chinabank.operationmanagesystem.core.bean.grid.Grid;
import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.QueryForm;
import com.chinabank.operationmanagesystem.core.bean.query.SubmitButton;
import com.chinabank.operationmanagesystem.core.bean.view.View;
import com.chinabank.operationmanagesystem.core.bean.view.ViewData;
import com.chinabank.operationmanagesystem.core.enums.ButtonEnum;
import com.chinabank.operationmanagesystem.core.enums.ColumnTypeEnum;
import com.chinabank.operationmanagesystem.core.enums.ViewTypeEnum;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wangyin.operation.utils.GsonUtil;

/**
 * <ul>
 * <li>1、开发日期：2014-3-26</li>
 * <li>2、开发时间：下午4:23:09</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：JSONParseUtil2</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class JSONParseUtil2 {
	private Map<String,Element> eles = new HashMap<String,Element>();
	/**  
	 * Title: JSONParseUtil2.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	

	public View getView(String jsonStr) {
		View view = new View();
		JsonParser jsonparer = new JsonParser();
		JsonElement jsonEle = jsonparer.parse(jsonStr);
		JsonObject jsonObject = jsonEle.getAsJsonObject();
		JsonArray jsonArray = jsonObject.get("elements").getAsJsonArray();
		for (JsonElement jsonElement : jsonArray) {
			Element ele = GsonUtil.getInstance().fromJson(jsonElement, Element.class);
			eles.put(ele.getCode(), ele);
		}
		String title = null;
		String strViewDatas = null;
		if(null != jsonObject.get("title")) {
			title = jsonObject.get("title").getAsString();
		} else {
			throw new RuntimeException("title属性不能缺失");
		}
		if(null != jsonObject.get("viewDatas")) {
			strViewDatas = jsonObject.get("viewDatas").toString();
		} else {
			throw new RuntimeException("viewDatas属性不能缺失");
		}
		List<ViewData> viewDatas = getViewDatas(strViewDatas);
		view.setTitle(title);
		if(null != jsonObject.get("bind")) {
			String bind = jsonObject.get("bind").getAsString();
			view.setBind(bind);
			for (ViewData viewData : viewDatas) {
				if(viewData instanceof QueryForm) {
					((QueryForm) viewData).setNumPerLine(2);
				} else if(viewData instanceof Form) {
					((Form) viewData).setNumPerLine(2);
				}
			}
		}
		view.setViewDatas(viewDatas);
		return view;
	}
	
	private List<ViewData> getViewDatas(String jsonStr) {
		List<ViewData> viewDatas = new ArrayList<ViewData>();
		JsonParser jsonparer = new JsonParser();
		JsonArray jsonArray = jsonparer.parse(jsonStr).getAsJsonArray();
		for (JsonElement jsonElement : jsonArray) {
			JsonObject jsonObject = jsonElement.getAsJsonObject();
			String type = jsonObject.get("type").getAsString();
			String data = jsonObject.get("data").toString();
			ViewData viewData = null;
			if(type.equals(ViewTypeEnum.GRID.getName())) {
				viewData = getGrid(data);
			} else if(type.equals(ViewTypeEnum.QUERYFORM.getName())) {
				viewData = getQueryForm(data);
			} else if(type.equals(ViewTypeEnum.FORM.getName())) {
				viewData = getForm(data);
			} else {
				throw new RuntimeException("类型:"+type+"不存在，目前仅支持grid,queryFrom,from这三种类型");
			}
			viewDatas.add(viewData);
		}
		return viewDatas;
	}
	
	private Grid getGrid(String jsonStr) {
		JsonParser jsonParser = new JsonParser();
		JsonElement jsonEle = jsonParser.parse(jsonStr);
		JsonObject jsonObject = jsonEle.getAsJsonObject();
		String strColModels = jsonObject.get("colModels").toString();
		boolean showIndex = false;
		if(null != jsonObject.get("showIndex")) {
			showIndex = jsonObject.get("showIndex").getAsBoolean();
		}
		boolean singleSelect = false;
		if(null != jsonObject.get("singleSelect")) {
			singleSelect = jsonObject.get("singleSelect").getAsBoolean();
		}
		boolean autoFit = false;
		if(null != jsonObject.get("autoFit")) {
			autoFit = jsonObject.get("autoFit").getAsBoolean();
		}
		boolean query = true;
		if(null != jsonObject.get("query")) {
			query = jsonObject.get("query").getAsBoolean();
		}
		List<ColModel> listColModels = getColModel(strColModels);
		Grid grid = new Grid();
		grid.setAutoFit(autoFit);
		grid.setColModels(listColModels);
		grid.setSingleSelect(singleSelect);
		grid.setQuery(query);
		grid.setShowIndex(showIndex);
		return grid;
	}
	
	private List<ColModel> getColModel(String jsonStr) {
		JsonParser jsonParser = new JsonParser();
		JsonElement jsonEle = jsonParser.parse(jsonStr);
		JsonArray jsonArray = jsonEle.getAsJsonArray();
		List<ColModel> list = new ArrayList<ColModel>();
		for (JsonElement jsonElement : jsonArray) {
			String type = jsonElement.getAsString();
			Element ele = eles.get(type);
			if(null == ele) {
				throw new RuntimeException("grid中colModels引用的元素："+type+"不存在，请检查elements中是否有对应code元素定义！");
			}
			list.add(TypeAdapterManager.gridTypeAdapter(ele));
			buildColModels(list);
		}
		return list;
	}
	
	private void buildColModels(List<ColModel> colModels) {
		Integer id = 0;
		for (ColModel colModel : colModels) {
			if(ColumnTypeEnum.ACTION.equals(colModel.getColumnTypeEnum())) {
				colModel.setId(id.toString());
				id ++;
			}
		}
	}
	
	private QueryForm getQueryForm(String jsonStr) {
		JsonParser jsonParser = new JsonParser();
		JsonElement jsonEle = jsonParser.parse(jsonStr);
		JsonObject jsonObject = jsonEle.getAsJsonObject();
		String url = jsonObject.get("url").getAsString();
		QueryForm queryForm = new QueryForm();
		queryForm.setUrl(url);
		if(null != jsonObject.get("numPerLine")) {
			int numPerLine = jsonObject.get("numPerLine").getAsInt();
			queryForm.setNumPerLine(numPerLine);
		}
		String strQueryDatas = jsonObject.get("queryDatas").toString();
		List<QueryData> listQueryDatas = getQueryData(strQueryDatas);
		queryForm.setQueryDatas(listQueryDatas);
		return queryForm;
	}
	
	private List<QueryData> getQueryData(String jsonStr) {
		List<QueryData> list = new ArrayList<QueryData>();
		JsonParser jsonParser = new JsonParser();
		JsonElement jsonEle = jsonParser.parse(jsonStr);
		JsonArray jsonArray = jsonEle.getAsJsonArray();
		for (JsonElement jsonElement : jsonArray) {
			String type = jsonElement.getAsString();
			Element ele = eles.get(type);
			if(null == ele) {
				throw new RuntimeException("queryForm中queryDatas引用的元素："+type+"不存在，请检查elements中是否有对应code元素定义！");
			}
			list.add(TypeAdapterManager.queryTypeAdapter(ele));
		}
		return list;
	}
	
	private Form getForm(String jsonStr) {
		JsonParser jsonParser = new JsonParser();
		JsonElement jsonEle = jsonParser.parse(jsonStr);
		JsonObject jsonObject = jsonEle.getAsJsonObject();
		String url = jsonObject.get("url").getAsString();
		Form form = new Form();
		form.setUrl(url);
		if(null != jsonObject.get("numPerLine")) {
			int numPerLine = jsonObject.get("numPerLine").getAsInt();
			form.setNumPerLine(numPerLine);
		}
		String strQueryDatas = jsonObject.get("queryDatas").toString();
		List<QueryData> listQueryDatas = getFormData(strQueryDatas);
		buildForm(form,listQueryDatas);
		form.setQueryDatas(listQueryDatas);
		return form;
	}
	
	private void buildForm(Form form,List<QueryData> listQueryDatas) {
		Integer submitButtonId = 0;
		for (QueryData queryData : listQueryDatas) {
			if(queryData instanceof SubmitButton) {
				SubmitButton submitButton = (SubmitButton) queryData;
				if(!ButtonEnum.BIND.getCode().equals(submitButton.getButtonEnum().getCode())) {
					submitButton.setUrl(form.getUrl());
					submitButton.setId(submitButtonId.toString());
					submitButtonId ++;
				}
			}
		}
	}
	
	private List<QueryData> getFormData(String jsonStr) {
		List<QueryData> list = new ArrayList<QueryData>();
		JsonParser jsonParser = new JsonParser();
		JsonElement jsonEle = jsonParser.parse(jsonStr);
		JsonArray jsonArray = jsonEle.getAsJsonArray();
		for (JsonElement jsonElement : jsonArray) {
			String type = jsonElement.getAsString();
			Element ele = eles.get(type);
			if(null == ele) {
				throw new RuntimeException("form中queryDatas引用的元素："+type+"不存在，请检查elements中是否有对应code元素定义！");
			}
			list.add(TypeAdapterManager.formTypeAdapter(ele));
		}
		return list;
	}
	
	public static void main(String[] args) {
		JSONParseUtil2 jsonParseUtil2 = new JSONParseUtil2();
		String jsonStr = "{\"title\":\"审核管理\",\"elements\":[{\"code\":\"A\",\"type\":\"dict\",\"label\":\"业务类型\",\"name\":\"bizType\",\"rule\":\"required\",\"value\":\"biz\"},{\"code\":\"B\",\"type\":\"date\",\"labe\":\"订单提交时间\",\"name\":\"submitDate\",\"rule\":\"required\",\"value\":2},{\"code\":\"C\",\"type\":\"date\",\"labe\":\"订单处理时间\",\"name\":\"dealDate\",\"rule\":\"required\",\"value\":2},{\"code\":\"D\",\"type\":\"text\",\"label\":\"收单银行\",\"name\":\"acceptBank\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"E\",\"type\":\"text\",\"label\":\"订单号\",\"name\":\"orderNum\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"F\",\"type\":\"text\",\"label\":\"银行订单号\",\"name\":\"bankOrder\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"G\",\"type\":\"text\",\"label\":\"支付银行\",\"name\":\"payBank\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"H\",\"type\":\"text\",\"label\":\"金额\",\"name\":\"money\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"I\",\"type\":\"text\",\"label\":\"卡号后4位\",\"name\":\"card\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"J\",\"type\":\"text\",\"label\":\"商户号\",\"name\":\"merchantNo\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"K\",\"type\":\"text\",\"label\":\"卖家名称\",\"name\":\"salerName\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"L\",\"type\":\"text\",\"label\":\"交易类型\",\"name\":\"dict\",\"rule\":\"required\",\"value\":\"tradeType\"},{\"code\":\"M\",\"type\":\"dict\",\"label\":\"交易状态\",\"name\":\"tradeStatus\",\"rule\":\"required\",\"value\":\"tradeStatus\"},{\"code\":\"N\",\"type\":\"dict\",\"label\":\"支付渠道\",\"name\":\"tradeCanal\",\"rule\":\"required\",\"value\":\"tradeCanal\"},{\"code\":\"O\",\"type\":\"text\",\"label\":\"授权号\",\"name\":\"authNum\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"P\",\"type\":\"dict\",\"label\":\"支付状态\",\"name\":\"payStatus\",\"rule\":\"required\",\"value\":\"payStatus\"},{\"code\":\"Q\",\"type\":\"dict\",\"label\":\"退款状态\",\"name\":\"refundStatus\",\"rule\":\"required\",\"value\":\"refundStatus\"},{\"code\":\"R\",\"type\":\"text\",\"label\":\"币种\",\"name\":\"currency\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"S\",\"type\":\"text\",\"label\":\"说明\",\"name\":\"remark\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"T\",\"type\":\"operation\",\"label\":\"操作\",\"name\":\"operation\",\"rule\":\"required\",\"value\":\"{\\\"actions\\\":[{\\\"text\\\":\\\"查补单\\\",\\\"url\\\":\\\"/trade/trade/queryBill.view\\\",\\\"params\\\":[\\\"merchantNo\\\"],\\\"fixedParam\\\":\\\"\\\"}]}\"},{\"code\":\"U\",\"type\":\"text\",\"label\":\"卡号\",\"name\":\"cardNum\",\"rule\":\"required\",\"value\":\"\"}],\"viewDatas\":[{\"type\":\"queryForm\",\"data\":{\"url\":\"/certification/certificate/certificate.biz\",\"queryDatas\":[\"A\",\"B\",\"C\",\"D\",\"E\",\"F\",\"G\",\"H\",\"I\",\"J\",\"K\",\"L\",\"M\",\"N\",\"O\",\"P\",\"Q\"],\"numPerLine\":3}},{\"type\":\"grid\",\"data\":{\"colModels\":[\"B\",\"C\",\"E\",\"F\",\"D\",\"G\",\"H\",\"T\",\"U\",\"O\",\"G\",\"K\",\"A\",\"M\",\"P\",\"S\",\"Q\",\"T\"],\"singleSelect\":\"true\"}}]}";
		View view = jsonParseUtil2.getView(jsonStr);
		System.out.println(view);
	}
}
