/**
 * <p>项目名称：oms-0.0.3<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-6-17</li>
 * <li>3、开发时间：下午2:38:48</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.controller</li>
 * <li>6、文件名称：PluginController.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

import com.chinabank.operationmanagesystem.core.bean.UploadFile;
import com.chinabank.operationmanagesystem.core.util.UnZipUtils;
import com.chinabank.operationmanagesystem.desktop.bean.UploadObject;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.utils.GsonUtil;
import com.wangyin.ssoclient.sso.model.User;
import org.springframework.stereotype.Component;

/**
 * <ul>
 * <li>1、开发日期：2014-6-17</li>
 * <li>2、开发时间：下午2:38:48</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：PluginController</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
@Component("plugin_manager")
public class PluginController {
	private static final Logger logger = LoggerFactory.getLogger(PluginController.class);
	/**
	 * <ul>
	 * <li>1、开发日期：2014年6月17日</li>
	 * <li>2、开发时间：上午10:54:43</li>
	 * <li>3、作          者：wychangxiangwei</li>
	 * <li>4、返回类型：Map<String,Object></li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：进入到上传的主界面</li>
	 * </ul>
	 * @param map
	 * @return
	 */
	public Map<String,Object> toPublishMainView(Map<String,String> map) {
		Map<String,Object> resultMap=new HashMap<String,Object>();
		return resultMap;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014年6月17日</li>
	 * <li>2、开发时间：上午10:55:34</li>
	 * <li>3、作          者：wychangxiangwei</li>
	 * <li>4、返回类型：UploadObject</li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：上传文件，确定文件版本保存到文件名中</li>
	 * </ul>
	 * @param map
	 * @param uploadObject
	 * @return
	 */
	public UploadObject onlineUpload(Map<String,Object> map,UploadObject uploadObject, HttpServletRequest request) {
		uploadObject.setVersion("2.0");
		List<UploadFile> list = uploadObject.getFileList();
		Integer version = 0;

		logger.info("上传插件：", map, GsonUtil.getInstance().toJson(uploadObject));

		//根据前台传入的systemId，确定存放二级目录路径，并根据文件现存版本号生成文件版本号。
		for (UploadFile uploadFile : list) {
			String systemName = uploadObject.getParams().get("systemName")+"";
			String branch = (String) request.getSession().getAttribute("branch");
			if(StringUtils.isNotBlank(branch)) {
				systemName += "_"+branch;
			}
			try {
				version = UnZipUtils.getMaxVersion(systemName);
			} catch (Exception e) {
				e.printStackTrace();
			}
			uploadFile.setPath("plugins/zip/"+systemName);
			uploadFile.setName(systemName+"_"+version);
		}
		return uploadObject;
	}
	
	/**
	 * <ul>
	 * <li>1、开发日期：2014年6月17日</li>
	 * <li>2、开发时间：上午10:55:39</li>
	 * <li>3、作          者：wychangxiangwei</li>
	 * <li>4、返回类型：String</li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：上传成功后的回调函数</li>
	 * </ul>
	 * @param uploadObject
	 * @return
	 */
	public String onlineCallback(UploadObject uploadObject, HttpServletRequest request, User user) {//appCdoe、sign、uploadObject、user

		logger.info("上传插件回调：", GsonUtil.getInstance().toJson(uploadObject));
		boolean isSuccess = true;
		String message = "上传成功";
		if(uploadObject.getFileList().size() <= 0) {
			isSuccess = false;
			message = "请选择待上传的zip包！";
		}else {
			UploadFile uploadFile = uploadObject.getFileList().get(0);
			String systemName = uploadObject.getParams().get("systemName")+"";
			String originalName = uploadFile.getOriginalName();
			if(originalName.equals(systemName + ".zip")) {
				String branch = (String) request.getSession().getAttribute("branch");
				if(StringUtils.isBlank(branch)) {
					branch = "";
				}
				String name = uploadFile.getName();
				String username = "";
				if(null != user) {
					username = user.getUsername();
				}
				logger.info("插件升级："+username+"|"+systemName+"|"+name);
				try {
					UnZipUtils.unZipPlugin(systemName, name , branch);
				} catch (IOException e) {
					logger.error(e.getMessage(),e.fillInStackTrace());
					isSuccess = false;
					message = e.getMessage();
				}
			} else {
				isSuccess = false;
				message = "升级失败，所传zip包与升级系统不符，请检查后再试！";
			}
			
		}
		return "{\"success\":" + isSuccess + ",\"message\":\"" + message + "\"}";
	}
	
	public Map<String,Object> toUpSelfView(Map<String,String> map) {
		Map<String,Object> resultMap=new HashMap<String,Object>();
		return resultMap;
	}
	
	public UploadObject upSelfUpload(Map<String,Object> map,UploadObject uploadObject) {
		uploadObject.setVersion("2.0");
		List<UploadFile> list = uploadObject.getFileList();
		//根据前台传入的systemId，确定存放二级目录路径，并根据文件现存版本号生成文件版本号。
		for (UploadFile uploadFile : list) {
			uploadFile.setPath("plugins/pages/plugin/manager/");
			uploadFile.setName("toPublishMain");
		}
		return uploadObject;
	}
	
	public String upSelfCallback(UploadObject uploadObject) {//appCdoe、sign、uploadObject、user
		boolean isSuccess = true;
		String message = "上传成功";
		if(uploadObject.getFileList().size() <= 0) {
			isSuccess = false;
			message = "请选择上传的文件！";
		}else {
			UploadFile uploadFile = uploadObject.getFileList().get(0);
			if(!uploadFile.isSuccess()) {
				isSuccess = false;
				message = "上传失败！";
			}
		}
		return "{\"success\":" + isSuccess + ",\"message\":\"" + message + "\"}";
	}
}
