/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-5-8</li>
 * <li>3、开发时间：下午12:04:23</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.rules.adapter</li>
 * <li>6、文件名称：RequiredRuleAdapter.java</li>
 * </ul>
 *//*
package com.chinabank.operationmanagesystem.core.rules.adapter;

import com.chinabank.operationmanagesystem.core.rules.Rule;

*//**
 * <ul>
 * <li>1、开发日期：2014-5-8</li>
 * <li>2、开发时间：下午12:04:23</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：RequiredRuleAdapter</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 *//*
public class RequiredRuleAdapter extends BaseRuleAdapter {

	*//**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午12:04:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.rules.adapter.BaseRuleAdapter#getRule(com.chinabank.operationmanagesystem.core.rules.Rule)
	 *//*
	@Override
	public String getRule(BaseRule rule) {
		return null;
	}

	*//**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午12:04:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.rules.adapter.BaseRuleAdapter#getMessage(com.chinabank.operationmanagesystem.core.rules.Rule)
	 *//*
	@Override
	public String getMessage(BaseRule rule) {
		// TODO Auto-generated method stub
		return null;
	}
	*//**  
	 * Title: RequiredRuleAdapter.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 *//*
}
*/