/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：上午9:45:09</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean</li>
 * <li>6、文件名称：Action.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.grid;

import java.io.Serializable;

import com.chinabank.operationmanagesystem.core.enums.ActionTypeEnum;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：上午9:45:09</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Action</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class Action implements Serializable{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：Action.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	private String text = "操作";
	private String url;
	private String[] params;
	private String fixedParam = null;
	private String expression = "";
	private ActionTypeEnum actionTypeEnum = ActionTypeEnum.VIEW;
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：上午9:45:09</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public Action() {
		// TODO Auto-generated constructor stub
	}
	/**  
	 * Title: Action.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String[] getParams() {
		return params;
	}
	public void setParams(String[] params) {
		this.params = params;
	}
	public String getFixedParam() {
		return fixedParam;
	}
	public void setFixedParam(String fixedParam) {
		this.fixedParam = fixedParam;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-6</li>
	 * <li>2、开发时间：上午11:38:02</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“actionTypeEnum”的值
	 */
	public ActionTypeEnum getActionTypeEnum() {
		return actionTypeEnum;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-6</li>
	 * <li>2、开发时间：上午11:38:03</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“actionTypeEnum”的值将赋给字段“actionTypeEnum”
	 */
	public void setActionTypeEnum(ActionTypeEnum actionTypeEnum) {
		this.actionTypeEnum = actionTypeEnum;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-9</li>
	 * <li>2、开发时间：下午2:15:00</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“expression”的值
	 */
	public String getExpression() {
		return expression;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-9</li>
	 * <li>2、开发时间：下午2:15:00</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“expression”的值将赋给字段“expression”
	 */
	public void setExpression(String expression) {
		this.expression = expression;
	}

}
