/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：下午2:33:12</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.enums</li>
 * <li>6、文件名称：TextTypeEnum.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.enums;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：下午2:33:12</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：TextTypeEnum</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public enum TextTypeEnum {
	TEXT(0,"T","text","文本域"),
	HIDDEN(1,"H","hidden","隐藏域"),
	CHECKBOX(2,"C","checkbox","复选框"),
	BIND(3,"B","bind","绑定查询输入框");//绑定查询input，不同的地方是加上readonly和额外的bind属性
	
	private int order;
	private String code;
	private String name;
	private String desc;
	private TextTypeEnum(int order,String code,String name,String desc) {
		this.order = order;
		this.code = code;
		this.name = name;
		this.desc = desc;
	}
	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：上午9:39:30</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：AlignEnum</li>
	 * <li>5、方法含义：根据code找到对应枚举类型</li>
	 * <li>6、方法说明：找不到时返回null</li>
	 * </ul>
	 * @param code
	 * @return
	 */
	public static TextTypeEnum getByCode(String code) {
		TextTypeEnum textTypeEnum = null;
		for(TextTypeEnum ele : TextTypeEnum.values()) {
			if(ele.getCode().equals(code)) {
				textTypeEnum = ele;
				break;
			}
		}
		return textTypeEnum;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public boolean equals(TextTypeEnum textTypeEnum) {
		if(this.getName().equals(textTypeEnum.getName())) {
			return true;
		}
		return false;
	}
}
