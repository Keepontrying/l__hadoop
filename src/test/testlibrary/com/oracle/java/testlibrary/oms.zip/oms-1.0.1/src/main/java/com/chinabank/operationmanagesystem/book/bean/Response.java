/**
 * <p>项目名称：boss-enter-0.0.1<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-9-25</li>
 * <li>3、开发时间：下午4:53:12</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.wangyin.boss.enter.api.beans</li>
 * <li>6、文件名称：Response.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.book.bean;

import java.io.Serializable;

/**
 * <ul>
 * <li>1、开发日期：2014-9-25</li>
 * <li>2、开发时间：下午4:53:12</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Response</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class Response<T> implements Serializable {

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：Response.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1192066909118994610L;
	public static final String SUCCESS = "000000";
	private String responseCode;
	private String message;
	private T data;
	
	public Response() {
		super();
	}

	public Response(String responseCode, String message) {
		super();
		this.responseCode = responseCode;
		this.message = message;
	}

	public boolean isSuccessful() {
		return SUCCESS.equals(responseCode);
	}
	public boolean isSuccess() {
		return SUCCESS.equals(responseCode);
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-9-25</li>
	 * <li>2、开发时间：下午4:56:04</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“responseCode”的值
	 */
	public String getResponseCode() {
		return responseCode;
	}


	/**
	 * <ul>
	 * <li>1、开发日期：2014-9-25</li>
	 * <li>2、开发时间：下午4:56:04</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“responseCode”的值将赋给字段“responseCode”
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}


	/**
	 * <ul>
	 * <li>1、开发日期：2014-9-25</li>
	 * <li>2、开发时间：下午4:53:49</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“message”的值
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-9-25</li>
	 * <li>2、开发时间：下午4:53:49</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“message”的值将赋给字段“message”
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-10-16</li>
	 * <li>2、开发时间：下午5:33:27</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“data”的值
	 */
	public T getData() {
		return data;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-10-16</li>
	 * <li>2、开发时间：下午5:33:27</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“data”的值将赋给字段“data”
	 */
	public void setData(T data) {
		this.data = data;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-10-16</li>
	 * <li>2、开发时间：下午5:33:35</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Response [responseCode=" + responseCode + ", message="
				+ message + ", data=" + data + "]";
	}

	
	/**  
	 * Title: Response.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
}
