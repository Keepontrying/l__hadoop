/**
 * <p>项目名称：boss-enter-0.0.1<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-9-25</li>
 * <li>3、开发时间：下午4:50:49</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.wangyin.boss.enter.api.beans</li>
 * <li>6、文件名称：Request.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.book.bean;

import java.io.Serializable;

/**
 * <ul>
 * <li>1、开发日期：2014-9-25</li>
 * <li>2、开发时间：下午4:50:49</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Request</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class Request implements Serializable {
	
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：Request.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -1445128441831662637L;
	private String appCode;
	private String param;
	private String sign;
	private String version = "1.0";
	/**
	 * <ul>
	 * <li>1、开发日期：2014-9-25</li>
	 * <li>2、开发时间：下午4:52:02</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“appCode”的值
	 */
	public String getAppCode() {
		return appCode;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-9-25</li>
	 * <li>2、开发时间：下午4:52:02</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“appCode”的值将赋给字段“appCode”
	 */
	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-9-25</li>
	 * <li>2、开发时间：下午5:04:12</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“param”的值
	 */
	public String getParam() {
		return param;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-9-25</li>
	 * <li>2、开发时间：下午5:04:12</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“param”的值将赋给字段“param”
	 */
	public void setParam(String param) {
		this.param = param;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-9-25</li>
	 * <li>2、开发时间：下午4:52:02</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“sign”的值
	 */
	public String getSign() {
		return sign;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-9-25</li>
	 * <li>2、开发时间：下午4:52:02</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“sign”的值将赋给字段“sign”
	 */
	public void setSign(String sign) {
		this.sign = sign;
	}
	
	
	/**
	 * <ul>
	 * <li>1、开发日期：2014-10-29</li>
	 * <li>2、开发时间：下午1:54:10</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“version”的值
	 */
	public String getVersion() {
		return version;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-10-29</li>
	 * <li>2、开发时间：下午1:54:10</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“version”的值将赋给字段“version”
	 */
	public void setVersion(String version) {
		this.version = version;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-10-29</li>
	 * <li>2、开发时间：下午1:54:17</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Request [appCode=" + appCode + ", param=" + param + ", sign="
				+ sign + ", version=" + version + "]";
	}
	
	/**  
	 * Title: Request.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
}
