/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-4-29</li>
 * <li>3、开发时间：下午4:26:53</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.form</li>
 * <li>6、文件名称：DatePicker.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.form;

import java.util.Date;

import com.chinabank.operationmanagesystem.core.bean.query.QueryData;

/**
 * <ul>
 * <li>1、开发日期：2014-4-29</li>
 * <li>2、开发时间：下午4:26:53</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：DatePicker</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class DatePicker extends QueryData {
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：DatePicker.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -9160536001283610711L;
	/**  
	 * Title: DatePicker.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private int timeDiff = 0;
	private boolean showTime = false;
	private Date date;
	
	
	public DatePicker() {
		super();
	}
	public DatePicker(String label, String name, String explain) {
		super(label, name, explain);
	}
	public DatePicker(String label, String name) {
		super(label, name);
	}
	
	public DatePicker(String label, String name,boolean showTime,int timeDiff) {
		super(label, name);
		this.showTime = showTime;
		this.timeDiff = timeDiff;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午4:28:21</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“timeDiff”的值
	 */
	public int getTimeDiff() {
		return timeDiff;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午4:28:21</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“timeDiff”的值将赋给字段“timeDiff”
	 */
	public void setTimeDiff(int timeDiff) {
		this.timeDiff = timeDiff;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午4:28:21</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“showTime”的值
	 */
	public boolean isShowTime() {
		return showTime;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午4:28:21</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“showTime”的值将赋给字段“showTime”
	 */
	public void setShowTime(boolean showTime) {
		this.showTime = showTime;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午4:59:49</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“date”的值
	 */
	public Date getDate() {
		return date;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午4:59:49</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“date”的值将赋给字段“date”
	 */
	public void setDate(Date date) {
		this.date = date;
	}
	
}
