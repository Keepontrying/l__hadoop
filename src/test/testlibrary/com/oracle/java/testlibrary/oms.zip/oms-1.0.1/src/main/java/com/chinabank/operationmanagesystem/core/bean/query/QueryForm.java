/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：下午2:25:27</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.query</li>
 * <li>6、文件名称：QueryForm.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.query;

import java.util.List;

import com.chinabank.operationmanagesystem.core.bean.view.ViewData;
import com.chinabank.operationmanagesystem.core.enums.FormTypeEnum;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：下午2:25:27</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：QueryForm</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class QueryForm extends ViewData{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：QueryForm.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 查询url
	 */
	private String url;
	/**
	 * 查询区每行显示的查询条件数量
	 * @Default 3
	 */
	private int numPerLine = 3;
	/**
	 * 查询条件
	 */
	private List<QueryData> queryDatas;
	private FormTypeEnum formTypeEnum = FormTypeEnum.QUERY;
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：下午2:25:27</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public QueryForm() {
		// TODO Auto-generated constructor stub
	}
	
	public QueryForm(String url, int numPerLine, List<QueryData> queryDataList) {
		super();
		this.url = url;
		this.numPerLine = numPerLine;
		this.queryDatas = queryDataList;
	}

	/**  
	 * Title: QueryForm.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public List<QueryData> getQueryDatas() {
		return queryDatas;
	}
	public void setQueryDatas(List<QueryData> queryDatas) {
		this.queryDatas = queryDatas;
	}
	public int getNumPerLine() {
		return numPerLine;
	}
	public void setNumPerLine(int numPerLine) {
		this.numPerLine = numPerLine;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-9</li>
	 * <li>2、开发时间：下午6:29:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“formTypeEnum”的值
	 */
	public FormTypeEnum getFormTypeEnum() {
		return formTypeEnum;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-9</li>
	 * <li>2、开发时间：下午6:29:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“formTypeEnum”的值将赋给字段“formTypeEnum”
	 */
	public void setFormTypeEnum(FormTypeEnum formTypeEnum) {
		this.formTypeEnum = formTypeEnum;
	}
	
}
