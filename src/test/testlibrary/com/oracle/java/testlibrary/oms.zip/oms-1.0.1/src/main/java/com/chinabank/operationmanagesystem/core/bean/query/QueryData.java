/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：下午1:45:50</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.query</li>
 * <li>6、文件名称：QueryForm.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.query;

import java.io.Serializable;

import com.chinabank.operationmanagesystem.core.rules.Rule;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：下午1:45:50</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：QueryForm</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class QueryData implements Serializable{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：QueryForm.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * label，显示在页面上
	 * @Defalut ""
	 */
	private String label="";
	/**
	 * 数据域的name，例如<input name="bankcode" type="text"/>的name
	 * @Default ""
	 */
	private String name="";
	/**
	 * 对数据域的解释文字，显示在数据域右侧，暂时无用
	 * @Default ""
	 */
	private String explain="";
	/**
	 * 数据域的id，选填
	 */
	private String id;
	/**
	 * 表单校验规则
	 */
	private Rule rule;
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：下午1:45:50</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public QueryData() {
		// TODO Auto-generated constructor stub
	}
	
	public QueryData(String label, String name) {
		super();
		this.label = label;
		this.name = name;
	}

	public QueryData(String label, String name, String explain) {
		super();
		this.label = label;
		this.name = name;
		this.explain = explain;
	}

	
	/**  
	 * Title: QueryForm.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getExplain() {
		return explain;
	}
	public void setExplain(String explain) {
		this.explain = explain;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-12</li>
	 * <li>2、开发时间：下午5:23:07</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“rule”的值
	 */
	public Rule getRule() {
		return rule;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-12</li>
	 * <li>2、开发时间：下午5:23:07</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“rule”的值将赋给字段“rule”
	 */
	public void setRule(Rule rule) {
		this.rule = rule;
	}

}
