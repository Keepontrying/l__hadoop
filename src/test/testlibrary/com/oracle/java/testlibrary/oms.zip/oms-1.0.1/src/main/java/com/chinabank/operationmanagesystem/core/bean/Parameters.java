/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-2-8</li>
 * <li>3、开发时间：下午1:39:08</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.util</li>
 * <li>6、文件名称：Parameters.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * <ul>
 * <li>1、开发日期：2014-2-8</li>
 * <li>2、开发时间：下午1:39:08</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Parameters</li>
 * <li>5、类型意图：</li>
 * </ul>
 * @param <K>
 *
 */
public class Parameters<K, V> extends LinkedHashMap<K, V> implements Map<K, V> {

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：Parameters.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	private static final SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
	private static final SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	/**
	 * <ul>
	 * <li>1、开发日期：2014-2-8</li>
	 * <li>2、开发时间：下午1:39:08</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：void</li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * @param args
	 */
	public String getString(String key) {
		return String.valueOf(this.get(key));
	}
	
	public int getInt(String key) {
		return Integer.parseInt(this.getString(key));
	}
	
	public long getLong(String key) {
		return Long.parseLong(this.getString(key));
	}
	
	public short getShort(String key) {
		return Short.parseShort(this.getString(key));
	}
	
	public float getFloat(String key) {
		return Float.parseFloat(this.getString(key));
	}
	
	public double getDouble(String key) {
		return Double.parseDouble(this.getString(key));
	}
	
	public boolean getBoolean(String key) {
		return Boolean.parseBoolean(this.getString(key));
	}
	
	public Date getDate1(String key) throws ParseException {
		return sdf1.parse(this.getString(key));
	}
	
	public Date getDate2(String key) throws ParseException {
		return sdf2.parse(this.getString(key));
	}
	
	/**  
	 * Title: Parameters.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
}
