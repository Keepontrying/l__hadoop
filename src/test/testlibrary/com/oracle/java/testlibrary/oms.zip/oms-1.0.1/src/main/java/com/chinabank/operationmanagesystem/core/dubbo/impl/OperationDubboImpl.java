/**
 * <p>项目名称：oms-0.0.5<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-6-25</li>
 * <li>3、开发时间：下午6:58:26</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.dubbo.impl</li>
 * <li>6、文件名称：OperationDubboImpl.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.dubbo.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.chinabank.operationmanagesystem.core.bean.ModelAndView;
import com.chinabank.operationmanagesystem.core.bean.UploadFile;
import com.chinabank.operationmanagesystem.core.bean.UserModel;
import com.chinabank.operationmanagesystem.core.dubbo.beans.QueryBean;
import com.chinabank.operationmanagesystem.core.dubbo.interfaces.OperationGeneralDubboInterface;
import com.chinabank.operationmanagesystem.desktop.bean.UploadObject;
import com.chinabank.operationmanagesystem.desktop.util.MapUtil;

/**
 * <ul>
 * <li>1、开发日期：2014-6-25</li>
 * <li>2、开发时间：下午6:58:26</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：OperationDubboImpl</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class OperationDubboImpl implements OperationGeneralDubboInterface {

	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-27</li>
	 * <li>2、开发时间：上午9:46:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.dubbo.interfaces.OperationGeneralDubboInterface#view(java.util.Map, com.chinabank.operationmanagesystem.core.bean.UserModel, java.lang.String)
	 */
	@Override
	public ModelAndView view(Map<String, Object> map, UserModel userModel,
			String from) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-27</li>
	 * <li>2、开发时间：上午9:46:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.dubbo.interfaces.OperationGeneralDubboInterface#biz(java.util.Map, com.chinabank.operationmanagesystem.core.bean.UserModel, java.lang.String)
	 */
	@Override
	public String biz(Map<String, Object> map, UserModel userModel, String from) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-27</li>
	 * <li>2、开发时间：上午9:46:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.dubbo.interfaces.OperationGeneralDubboInterface#upload(com.chinabank.operationmanagesystem.desktop.bean.UploadObject, com.chinabank.operationmanagesystem.core.bean.UserModel, java.lang.String)
	 */
	@Override
	public UploadObject upload(UploadObject uploadObject, UserModel userModel,
			String from) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-27</li>
	 * <li>2、开发时间：上午9:46:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.dubbo.interfaces.OperationGeneralDubboInterface#callback(com.chinabank.operationmanagesystem.desktop.bean.UploadObject, com.chinabank.operationmanagesystem.core.bean.UserModel, java.lang.String)
	 */
	@Override
	public String callback(UploadObject uploadObject, UserModel userModel,
			String from) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-27</li>
	 * <li>2、开发时间：上午9:46:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.dubbo.interfaces.OperationGeneralDubboInterface#download(java.util.Map, com.chinabank.operationmanagesystem.core.bean.UserModel, java.lang.String)
	 */
	@Override
	public UploadFile download(Map<String, Object> map, UserModel userModel,
			String from) {
		// TODO Auto-generated method stub
		return null;
	}
}
