/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-2</li>
 * <li>3、开发时间：下午2:14:15</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean</li>
 * <li>6、文件名称：File.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean;

import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <ul>
 * <li>1、开发日期：2014-1-2</li>
 * <li>2、开发时间：下午2:14:15</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：UploadFile</li>
 * <li>5、类型意图：上传或下载时传递文件相关参数</li>
 * </ul>
 *
 */
public class UploadFile implements Serializable{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：File.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 1、上传时保存将要上传的文件位置
	 * 2、上传回调时保存已经上传到文件服务器的相对位置
	 * 3、下载时保存将要下载的文件在服务器中的位置
	 */
	private String path;
	/**
	 * 1、上传时保存将要上传的文件名称（不包括后缀）
	 * 2、上传回调时保存已经上传到文件服务器的名称（包括后缀）
	 * 3、下载时保存将要下载的文件在服务器中的名称（包括后缀）
	 */
	private String name;
	/**
	 * 1、上传时此值为null
	 * 2、上传回调时保存上传文件在客服端时的全名（包括后缀）
	 * 3、下载时保存下载到客户端时显示的名称（包括后缀），不传值则下载时同服务器中文件名
	 */
	private String originalName;
	private String fieldName;
	private long size;
	/**
	 * 文件在文件服务器中的绝对路径
	 */
	private String realPathname;
	/**
	 * 上传或下载是否成功
	 */
	private boolean success = true;
	/**
	 * 调用上传插件时的版本号，推荐2.0
	 */
	private String version = "1.0";
	/**
	 * 上传时设置，是否上传到临时目录（临时目录会定期清理）
	 */
	private boolean temp = false;
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-2</li>
	 * <li>2、开发时间：下午2:14:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public UploadFile() {
		// TODO Auto-generated constructor stub
	}
	
	public UploadFile(String path, String name, String originalName) {
		super();
		this.path = path;
		this.name = name;
		this.originalName = originalName;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public String getOriginalName() {
		return originalName;
	}

	public void setOriginalName(String originalName) {
		this.originalName = originalName;
	}

	public String getRealPathname() {
		return realPathname;
	}

	public void setRealPathname(String realPathname) {
		this.realPathname = realPathname;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2014-1-2</li>
	 * <li>2、开发时间：下午4:24:47</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：void</li>
	 * <li>5、方法含义：通过文件全路径及名称设置path和name</li>
	 * <li>6、方法说明：传入全路径，通过正则匹配分解成path=xxxx/xxxx和name=xxx.xxx。
	 * 				例如：1、上传文件a分解为path=""，name="a"
	 * 					      上传文件a/b/c分解为path="a/b"，name="c"
	 * 					2、下载文件a/b/c.jpg分解为path="a/b"，name="c.jpg"</li>
	 * </ul>
	 * @param pathname 文件全路径及名称，例如：/ftp/img/example.jpg
	 */
	public void setPathname(String pathname) {
		pathname = pathname.replaceAll("[/|\\\\]+", "/");
		pathname = pathname.replaceAll("/*$", "");
		pathname = pathname.replaceAll("^/*", "");
		String temp = pathname;
		Matcher mInput = Pattern.compile("[^/]*$").matcher(temp);
		if(mInput.find()) {
			this.name = mInput.group();
		}
		this.path = pathname.replaceFirst("/?[^/]*$", "");
	}
	
	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2014-1-2</li>
	 * <li>2、开发时间：下午4:28:13</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：String</li>
	 * <li>5、方法含义：得到上传文件的全路径</li>
	 * <li>6、方法说明：返回path/name的组合</li>
	 * </ul>
	 * @return
	 */
	public String getPathname() {
		return path + "/" + name;
	}
	
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-3</li>
	 * <li>2、开发时间：下午3:34:07</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“fieldName”的值
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-3</li>
	 * <li>2、开发时间：下午3:34:07</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“fieldName”的值将赋给字段“fieldName”
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-3</li>
	 * <li>2、开发时间：下午3:35:28</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“size”的值
	 */
	public long getSize() {
		return size;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-3</li>
	 * <li>2、开发时间：下午3:35:28</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“size”的值将赋给字段“size”
	 */
	public void setSize(long size) {
		this.size = size;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-8-26</li>
	 * <li>2、开发时间：下午4:03:10</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“version”的值
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-8-26</li>
	 * <li>2、开发时间：下午4:03:10</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“version”的值将赋给字段“version”
	 */
	public void setVersion(String version) {
		this.version = version;
	}
	
	/**
	 * <ul>
	 * <li>1、开发日期：2014-10-14</li>
	 * <li>2、开发时间：下午2:15:20</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“temp”的值
	 */
	public boolean isTemp() {
		return temp;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-10-14</li>
	 * <li>2、开发时间：下午2:15:20</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“temp”的值将赋给字段“temp”
	 */
	public void setTemp(boolean temp) {
		this.temp = temp;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-10-14</li>
	 * <li>2、开发时间：下午2:15:33</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UploadFile [path=" + path + ", name=" + name
				+ ", originalName=" + originalName + ", fieldName=" + fieldName
				+ ", size=" + size + ", realPathname=" + realPathname
				+ ", success=" + success + ", version=" + version + ", temp="
				+ temp + "]";
	}


}
