/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-2-10</li>
 * <li>3、开发时间：下午6:08:22</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean</li>
 * <li>6、文件名称：ModelAndView.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean;

import java.io.Serializable;
import java.util.Map;

/**
 * <ul>
 * <li>1、开发日期：2014-2-10</li>
 * <li>2、开发时间：下午6:08:22</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：ModelAndView</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class ModelAndView implements Serializable {

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：ModelAndView.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	private Map<?,?> map;
	private String view;
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-2-10</li>
	 * <li>2、开发时间：下午6:08:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public ModelAndView() {
		// TODO Auto-generated constructor stub
	}

	/**  
	 * Title: ModelAndView.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */

	public Map<?, ?> getMap() {
		return map;
	}

	public ModelAndView(String view, Map<?, ?> map) {
		super();
		this.view = view;
		this.map = map;
	}

	public void setMap(Map<?, ?> map) {
		this.map = map;
	}

	public String getView() {
		return view;
	}

	public void setView(String view) {
		this.view = view;
	}
	
}
