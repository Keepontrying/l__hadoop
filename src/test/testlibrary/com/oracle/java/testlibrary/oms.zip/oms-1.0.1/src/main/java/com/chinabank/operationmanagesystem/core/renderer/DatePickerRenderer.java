/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-4-29</li>
 * <li>3、开发时间：下午4:47:44</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.renderer</li>
 * <li>6、文件名称：DatePickerRenderer.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.renderer;

import java.text.SimpleDateFormat;
import java.util.Date;


import com.chinabank.operationmanagesystem.core.bean.form.DatePicker;
import com.chinabank.operationmanagesystem.core.bean.form.renderer.FormRenderer;
import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.ViewObject;
import com.chinabank.operationmanagesystem.core.bean.query.renderer.QueryRenderer;
import com.chinabank.operationmanagesystem.core.util.DateUtil;
import com.chinabank.operationmanagesystem.core.util.FormUtil;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/**
 * <ul>
 * <li>1、开发日期：2014-4-29</li>
 * <li>2、开发时间：下午4:47:44</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：DatePickerRenderer</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class DatePickerRenderer implements FormRenderer, QueryRenderer {

	private static int datePickerId = 0;
	private static final String formDatePickerClass = "iconrept";
	private static final Logger logger = LoggerFactory.getLogger(DatePickerRenderer.class);
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午4:47:44</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.form.renderer.FormRenderer#renderForm(com.chinabank.operationmanagesystem.core.bean.query.QueryData)
	 */
	@Override
	public ViewObject renderForm(QueryData queryData) {
		DatePicker datePicker = (DatePicker) queryData;
		if(datePickerId > 100) {//约定同一页面中，时间对元素不会大于100个
			datePickerId = 0;
		}
		StringBuilder ready = new StringBuilder();
		StringBuilder function = new StringBuilder();
		StringBuilder html = new StringBuilder();
		int width = 180;
		html.append(FormUtil.JS_CR).append(FormUtil.INDENT_FIVE).append("<label>").append(datePicker.getLabel()).append("</label>");
		html.append(FormUtil.JS_CR).append(FormUtil.INDENT_FIVE).append("<input id='datePicker").append(datePickerId).append("' name='").append(datePicker.getName()).append("' type='text' class='").append(formDatePickerClass).append("' style='width:").append(width).append("px'>");
		SimpleDateFormat sdf = DateUtil.getInstance(DateUtil.FORMAT4);
		Date time = datePicker.getDate();
		if(null == time ) {
			function.append(FormUtil.JS_CR).append("getDate").append(datePickerId).append(" = function() {");
			function.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("now = new Date();");
			function.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("now.setDate(now.getDate() + ").append(datePicker.getTimeDiff()).append(");");
			function.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("return now;");
			function.append(FormUtil.JS_CR).append("}");
		}
		ready.append(FormUtil.CR).append(FormUtil.JS_CR).append("$('#datePicker").append(datePickerId).append("').omCalendar({");
		if(null == time ) {
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("date: getDate").append(datePickerId).append("(),");
		} else {
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("date: new Date('").append(sdf.format(time)).append("'),");
		}
		ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("showTime: ").append(datePicker.isShowTime()).append(",");
		ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("readOnly: true");
		ready.append(FormUtil.JS_CR).append("});");
		datePickerId +=1;
		return new ViewObject(html.toString(),function.toString(),ready.toString());
	}
	/**  
	 * Title: DatePickerRenderer.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午5:23:37</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.query.renderer.QueryRenderer#renderQuery(com.chinabank.operationmanagesystem.core.bean.query.QueryData)
	 */
	@Override
	public ViewObject renderQuery(QueryData queryData) {
		return this.renderForm(queryData);
	}
}
