/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-15</li>
 * <li>3、开发时间：下午5:44:37</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.util</li>
 * <li>6、文件名称：DateEditor.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.util;

import java.beans.PropertyEditorSupport;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * <ul>
 * <li>1、开发日期：2014-1-15</li>
 * <li>2、开发时间：下午5:44:37</li>
 * <li>3、作 者：wangjiaqi</li>
 * <li>4、类型名称：DateEditor</li>
 * <li>5、类型意图：</li>
 * </ul>
 * 
 */
public class DateEditor extends PropertyEditorSupport{

	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-15</li>
	 * <li>2、开发时间：下午5:44:37</li>
	 * <li>3、作 者：wangjiaqi</li>
	 * </ul>
	 */
	
	@Override
	public String getAsText() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date value = (Date) getValue();
		return (value != null ? dateFormat.format(value) : "");
	}
	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		Date value = null;
		if (null != text && !text.equals("")) {
			boolean blDate  = text.matches("\\d{4}-\\d{2}-\\d{2}");
			boolean blDateTime = text.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}");
			if(blDate) {
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				try {
					value = df.parse(text);
				} catch (ParseException e) {
					e.printStackTrace();
				}
			} else if(blDateTime) {
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				try {
					value = df.parse(text);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				value = new Date();
			}
		}
		setValue(value);
	}
	/**
	 * Title: DateEditor.java Description: TODO(用一句话描述该文件做什么)
	 * 
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
}
