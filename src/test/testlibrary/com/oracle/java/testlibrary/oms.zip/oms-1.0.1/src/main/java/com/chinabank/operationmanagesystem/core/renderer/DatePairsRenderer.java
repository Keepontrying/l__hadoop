/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-4-8</li>
 * <li>3、开发时间：上午11:07:58</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.renderer</li>
 * <li>6、文件名称：DatePairsRenderer.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.renderer;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.chinabank.operationmanagesystem.core.bean.form.renderer.FormRenderer;
import com.chinabank.operationmanagesystem.core.bean.query.DatePairs;
import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.ViewObject;
import com.chinabank.operationmanagesystem.core.bean.query.renderer.QueryRenderer;
import com.chinabank.operationmanagesystem.core.util.DateUtil;
import com.chinabank.operationmanagesystem.core.util.FormUtil;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/**
 * <ul>
 * <li>1、开发日期：2014-4-8</li>
 * <li>2、开发时间：上午11:07:58</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：DatePairsRenderer</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class DatePairsRenderer implements FormRenderer, QueryRenderer {

	private static int datePairsId = 0;
	private static final String formDatePairsClass = "iconrept";
	private static final Logger logger = LoggerFactory.getLogger(DatePairsRenderer.class);
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午11:07:58</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.form.renderer.FormRenderer#renderForm(com.chinabank.operationmanagesystem.core.bean.query.QueryData)
	 */
	@Override
	public ViewObject renderForm(QueryData queryData) {
		DatePairs datePairs = (DatePairs) queryData;
		if(datePairsId > 100) {//约定同一页面中，时间对元素不会大于100个
			datePairsId = 0;
		}
		StringBuilder ready = new StringBuilder();
		StringBuilder function = new StringBuilder();
		StringBuilder html = new StringBuilder();
		int width = 75;
		if(datePairs.isShowTime()) {
			width = 140;
		}
		html.append(FormUtil.JS_CR).append(FormUtil.INDENT_FIVE).append("<label>").append(datePairs.getLabel()).append("</label>");
		html.append(FormUtil.JS_CR).append(FormUtil.INDENT_FIVE).append("<input id='datePairs").append(datePairsId).append("' name='").append(datePairs.getStartName()).append("' type='text' class='").append(formDatePairsClass).append("' style='width:").append(width).append("px'> — <input id='datePairs").append(datePairsId + 1).append("' name='").append(datePairs.getEndName()).append("' type='text' class='").append(formDatePairsClass).append("' style='width:").append(width).append("px'>");
		SimpleDateFormat sdf = DateUtil.getInstance(DateUtil.FORMAT4);
		Date startTime = datePairs.getStartTime();
		Date endTime = datePairs.getEndTime();
		if(null == startTime && null == endTime ) {
			function.append(FormUtil.JS_CR).append("getDatePairs").append(datePairsId).append(" = function() {");
			function.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("now = new Date();");
			function.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("now.setDate(now.getDate() + ").append(datePairs.getTimeDiff()).append(" - ").append(datePairs.getInterval()).append(");");
			function.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("return now;");
			function.append(FormUtil.JS_CR).append("}");
			function.append(FormUtil.JS_CR);
			function.append(FormUtil.JS_CR).append("getDatePairs").append(datePairsId + 1).append(" = function() {");
			function.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("now = new Date();");
			function.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("now.setDate(now.getDate() + ").append(datePairs.getTimeDiff()).append(");");
			function.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("return now;");
			function.append(FormUtil.JS_CR).append("}");
		} else {
			if( null == startTime ) {
				startTime = new Date();
				if(logger.isDebugEnabled()) {
					logger.debug("开始时间为空，默认返回系统当前时间！");
				}
			}
			if( null == endTime ) {
				endTime = new Date();
				if(logger.isDebugEnabled()) {
					logger.debug("结束时间为空，默认返回系统当前时间！");
				}
			}
		}
		ready.append(FormUtil.CR).append(FormUtil.JS_CR).append("$('#datePairs").append(datePairsId).append("').omCalendar({");
		if(null == startTime && null == endTime ) {
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("date: getDatePairs").append(datePairsId).append("(),");
		} else {
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("date: new Date('").append(sdf.format(startTime)).append("'),");
		}
		ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("showTime: ").append(datePairs.isShowTime()).append(",");
		ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("readOnly: true");
		ready.append(FormUtil.JS_CR).append("});");
		
		ready.append(FormUtil.CR).append(FormUtil.JS_CR).append("$('#datePairs").append(datePairsId + 1).append("').omCalendar({");
		if(null == startTime && null == endTime ) {
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("date: getDatePairs").append(datePairsId + 1).append("(),");
		} else {
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("date: new Date('").append(sdf.format(endTime)).append("'),");
		}
		ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("showTime: ").append(datePairs.isShowTime()).append(",");
		ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("readOnly: true");
		ready.append(FormUtil.JS_CR).append("});");
		datePairsId +=2;
		return new ViewObject(html.toString(), function.toString(), ready.toString());
	}
	/**  
	 * Title: DatePairsRenderer.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午5:22:02</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.query.renderer.QueryRenderer#renderQuery(com.chinabank.operationmanagesystem.core.bean.query.QueryData)
	 */
	@Override
	public ViewObject renderQuery(QueryData queryData) {
		return this.renderForm(queryData);
	}
	
}
