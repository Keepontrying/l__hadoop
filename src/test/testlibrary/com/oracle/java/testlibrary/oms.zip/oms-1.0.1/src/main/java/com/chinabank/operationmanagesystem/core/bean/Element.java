/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-3-26</li>
 * <li>3、开发时间：上午10:44:02</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean</li>
 * <li>6、文件名称：Element.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean;

import java.io.Serializable;

/**
 * <ul>
 * <li>1、开发日期：2014-3-26</li>
 * <li>2、开发时间：上午10:44:02</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Element</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class Element implements Serializable{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：Element.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 9049610467621741896L;
	private String code = "";
	private String type = "";
	private String label = "";
	private String name = "";
	private String rule = "";
	private String value = "";
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午12:06:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“label”的值
	 */
	public String getLabel() {
		return label;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午12:06:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“label”的值将赋给字段“label”
	 */
	public void setLabel(String label) {
		this.label = label;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午12:06:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“name”的值
	 */
	public String getName() {
		return name;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午12:06:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“name”的值将赋给字段“name”
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午12:06:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“rule”的值
	 */
	public String getRule() {
		return rule;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午12:06:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“rule”的值将赋给字段“rule”
	 */
	public void setRule(String rule) {
		this.rule = rule;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午12:06:43</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“value”的值
	 */
	public String getValue() {
		return value;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午12:06:43</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“value”的值将赋给字段“value”
	 */
	public void setValue(String value) {
		this.value = value;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午12:13:21</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“type”的值
	 */
	public String getType() {
		return type;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午12:13:21</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“type”的值将赋给字段“type”
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午4:36:29</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“code”的值
	 */
	public String getCode() {
		return code;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午4:36:29</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“code”的值将赋给字段“code”
	 */
	public void setCode(String code) {
		this.code = code;
	}
	
	/**  
	 * Title: Element.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	
	
}
