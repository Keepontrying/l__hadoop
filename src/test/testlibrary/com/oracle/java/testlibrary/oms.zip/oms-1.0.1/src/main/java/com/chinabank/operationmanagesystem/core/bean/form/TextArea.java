/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-4-23</li>
 * <li>3、开发时间：下午4:25:04</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.form</li>
 * <li>6、文件名称：TextArea.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.form;

import com.chinabank.operationmanagesystem.core.bean.query.QueryData;

/**
 * <ul>
 * <li>1、开发日期：2014-4-23</li>
 * <li>2、开发时间：下午4:25:04</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：TextArea</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class TextArea extends QueryData {
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：TextArea.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -3701726288693273938L;
	/**  
	 * Title: TextArea.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private int rows = 3;
	private int width = 710;
	private String placeholder = "请输入...";
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-23</li>
	 * <li>2、开发时间：下午4:29:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“rows”的值
	 */
	public int getRows() {
		return rows;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-23</li>
	 * <li>2、开发时间：下午4:29:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“rows”的值将赋给字段“rows”
	 */
	public void setRows(int rows) {
		this.rows = rows;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-23</li>
	 * <li>2、开发时间：下午4:29:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“width”的值
	 */
	public int getWidth() {
		return width;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-23</li>
	 * <li>2、开发时间：下午4:29:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“width”的值将赋给字段“width”
	 */
	public void setWidth(int width) {
		this.width = width;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-23</li>
	 * <li>2、开发时间：下午4:29:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“placeholder”的值
	 */
	public String getPlaceholder() {
		return placeholder;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-23</li>
	 * <li>2、开发时间：下午4:29:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“placeholder”的值将赋给字段“placeholder”
	 */
	public void setPlaceholder(String placeholder) {
		this.placeholder = placeholder;
	}
	
}
