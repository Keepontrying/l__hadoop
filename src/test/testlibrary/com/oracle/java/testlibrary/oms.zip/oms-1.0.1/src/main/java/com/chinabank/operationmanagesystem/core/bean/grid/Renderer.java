/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：上午9:41:48</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean</li>
 * <li>6、文件名称：Renderer.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.grid;

import java.io.Serializable;
import java.util.List;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：上午9:41:48</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Renderer</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class Renderer implements Serializable{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：Renderer.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	private List<Action> actions;
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：上午9:41:48</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public Renderer() {
		// TODO Auto-generated constructor stub
	}
	
	public Renderer(List<Action> actions) {
		super();
		this.actions = actions;
	}


	/**  
	 * Title: Renderer.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	public List<Action> getActions() {
		return actions;
	}
	public void setActions(List<Action> actions) {
		this.actions = actions;
	}
	
}
