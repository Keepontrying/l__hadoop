package com.chinabank.statistic.service;

import com.chinabank.statistic.domain.RequestDomain;
import com.chinabank.statistic.mapper.RequestMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 统计服务
 *
 * @author: dongzhihua
 * @time: 2018/5/17 18:31:36
 */
@Service
public class RequestServer {

	private static Logger logger = LoggerFactory.getLogger(RequestServer.class);

	@Autowired
	RequestMapper statisticMapper;

	@Transactional
	public void saveInfo(RequestDomain requestDomain) {
		logger.info("StatisticServer.saveInfo statisticDomain: {}", requestDomain);
		statisticMapper.save(requestDomain);
	}
}
