/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：上午9:25:34</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean</li>
 * <li>6、文件名称：Grid.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.grid;

import java.util.List;

import com.chinabank.operationmanagesystem.core.bean.view.ViewData;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：上午9:25:34</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Grid</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class Grid extends ViewData{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：Grid.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	private int limit = 10;
	private boolean showIndex = false;
	private boolean singleSelect = true;
	private boolean autoFit = false;
	private String title = "";
	private List<ColModel> colModels;
	private String dataSource;
	private String method = "POST";
	private boolean query = true;
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：上午9:25:34</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public Grid() {
		// TODO Auto-generated constructor stub
	}
	
	public Grid(List<ColModel> colModel, String dataSource) {
		super();
		this.colModels = colModel;
		this.dataSource = dataSource;
	}

	public Grid(int limit, boolean showIndex, boolean singleSelect,
			String title, List<ColModel> colModel, String dataSource,
			String method) {
		super();
		this.limit = limit;
		this.showIndex = showIndex;
		this.singleSelect = singleSelect;
		this.title = title;
		this.colModels = colModel;
		this.dataSource = dataSource;
		this.method = method;
	}

	/**  
	 * Title: Grid.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	public int getLimit() {
		return limit;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}
	public boolean isShowIndex() {
		return showIndex;
	}
	public void setShowIndex(boolean showIndex) {
		this.showIndex = showIndex;
	}
	public boolean isSingleSelect() {
		return singleSelect;
	}
	public void setSingleSelect(boolean singleSelect) {
		this.singleSelect = singleSelect;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<ColModel> getColModels() {
		return colModels;
	}
	public void setColModels(List<ColModel> colModels) {
		this.colModels = colModels;
	}
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-6</li>
	 * <li>2、开发时间：下午2:54:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“autoFit”的值
	 */
	public boolean isAutoFit() {
		return autoFit;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-6</li>
	 * <li>2、开发时间：下午2:54:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“autoFit”的值将赋给字段“autoFit”
	 */
	public void setAutoFit(boolean autoFit) {
		this.autoFit = autoFit;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-23</li>
	 * <li>2、开发时间：下午2:09:06</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“query”的值
	 */
	public boolean isQuery() {
		return query;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-23</li>
	 * <li>2、开发时间：下午2:09:06</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“query”的值将赋给字段“query”
	 */
	public void setQuery(boolean query) {
		this.query = query;
	}
	
	
}
