/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-5-8</li>
 * <li>3、开发时间：下午1:21:23</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.rules.factory</li>
 * <li>6、文件名称：RulesFactory.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.rules.factory;

import java.util.HashMap;
import java.util.Map;

import com.chinabank.operationmanagesystem.core.rules.RequiredRule;
import com.chinabank.operationmanagesystem.core.rules.Rule;

/**
 * <ul>
 * <li>1、开发日期：2014-5-8</li>
 * <li>2、开发时间：下午1:21:23</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：RulesFactory</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class RulesFactory {
	/**  
	 * Title: RulesFactory.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private static final Map<String,Class<?>> factory = new HashMap<String,Class<?>>();
	static {
		RulesFactory.register("required", RequiredRule.class);
	}
	
	public static void register(String name,Class<?> clazz) {
		factory.put(name, clazz);
	}
	
	public static Rule getRule(String name) {
		Class<?> clazz = factory.get(name);
		if(null != clazz) {
			try {
				return (Rule) clazz.newInstance();
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		} else {
			//throw new NoSuchRuleException(); 
		}
		return null;
	}
	
	public static void main(String[] args) {
		Rule rule = RulesFactory.getRule("required");
		System.out.println();
	}
}
