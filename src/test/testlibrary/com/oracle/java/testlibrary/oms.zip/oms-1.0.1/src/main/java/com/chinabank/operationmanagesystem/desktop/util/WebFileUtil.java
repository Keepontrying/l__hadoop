/**
 * <p>项目名称：oms_0.1.3<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2015-2-11</li>
 * <li>3、开发时间：下午4:12:44</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.util</li>
 * <li>6、文件名称：WebFileUtil.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.util;

import javax.servlet.http.HttpServletResponse;

import com.chinabank.operationmanagesystem.core.bean.UploadFile;

/**
 * <ul>
 * <li>1、开发日期：2015-2-11</li>
 * <li>2、开发时间：下午4:12:44</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：WebFileUtil</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public interface WebFileUtil extends DownloadUtil {
	
	public boolean downloadByNginx(HttpServletResponse response, UploadFile uploadfile, String uniqueID);

}
