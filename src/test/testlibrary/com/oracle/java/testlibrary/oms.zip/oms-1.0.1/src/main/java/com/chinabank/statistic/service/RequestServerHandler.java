package com.chinabank.statistic.service;

import com.chinabank.statistic.domain.RequestDomain;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

/**
 * handler
 *
 * @author: dongzhihua
 * @time: 2018/5/23 16:53:49
 */
@Component
public class RequestServerHandler {

	private static Logger logger = LoggerFactory.getLogger(RequestServerHandler.class);

	@Autowired
	RequestServer requestServer;

	@Async
	public void saveInfoAsync(RequestDomain requestDomain) {
		try {
			requestServer.saveInfo(requestDomain);
		} catch (Exception e) {
			logger.error("saveInfoAsync exception: {}", e);
		}
	}
}
