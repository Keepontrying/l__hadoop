package com.chinabank.statistic.mapper;

import com.chinabank.statistic.domain.RequestDomain;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * 数据库层
 *
 * @author: dongzhihua
 * @time: 2018/5/18 11:19:15
 */
@Repository
public interface RequestMapper extends JpaRepository<RequestDomain, Long> {

	/**
	 * 新增
	 * @author: dongzhihua
	 * @time: 2018/5/18 13:20:42
	 */
//	int insertSelective(RequestDomain requestDomain);
}
