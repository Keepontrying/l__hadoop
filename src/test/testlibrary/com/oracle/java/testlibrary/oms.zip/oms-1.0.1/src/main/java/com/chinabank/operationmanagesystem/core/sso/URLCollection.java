/**
 * <p>项目名称：oms-0.0.5<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-7-8</li>
 * <li>3、开发时间：下午4:10:20</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean</li>
 * <li>6、文件名称：URLCollection.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.sso;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.ssoclient.regex.URLCollectionObject;

/**
 * <ul>
 * <li>1、开发日期：2014-7-8</li>
 * <li>2、开发时间：下午4:10:20</li>
 * <li>3、作 者：wangjiaqi</li>
 * <li>4、类型名称：URLCollection</li>
 * <li>5、类型意图：</li>
 * </ul>
 * 
 */
public class URLCollection implements Serializable {
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：URLCollection.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -1332325418185791651L;
	/**
	 * Title: URLCollection.java Description: TODO(用一句话描述该文件做什么)
	 * 
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private static final Logger logger = LoggerFactory.getLogger(URLCollectionObject.class);
	public static final boolean DEBUG = false;
	public Map<String, RegexURL> pureURLs;
	public Map<JavaRegexURL, RegexURL> regexURLs;
	public Map<StartsWithURL, RegexURL> startsWithURLs;

	public URLCollection() {
		this.pureURLs = new HashMap<String, RegexURL>();

		this.regexURLs = new HashMap<JavaRegexURL, RegexURL>();

		this.startsWithURLs = new HashMap<StartsWithURL, RegexURL>();
	}

	public void newAction(RegexURL.UrlType urlType, String urlValue) {
		newAction(new RegexURL(urlType, urlValue));
	}

	public void newAction(RegexURL url) {
		switch (url.getUrlType().ordinal()) {
		case 1:
			this.pureURLs.put(url.getUrlValue(), url);
			break;
		case 2:
			this.regexURLs.put(new JavaRegexURL(url.getUrlValue(), true), url);
			break;
		case 3:
			this.startsWithURLs.put(new StartsWithURL(url.getUrlValue()), url);
		}
	}

	public boolean invoke(String url) {
		if (!(url.startsWith("/"))) {
			url = "/" + url;
		}

		RegexURL o = null;

		o = (RegexURL) this.pureURLs.get(url);
		if (null != o) {
			logger.debug("Match:" + url + "\t With:" + o);
			return true;
		}

		StartsWithURL requestStartsWith = new StartsWithURL(url);
		o = (RegexURL) this.startsWithURLs.get(requestStartsWith);
		if (null != o) {
			logger.debug("Match:" + url + "\t With:" + o);
			return true;
		}

		JavaRegexURL requestRegex = new JavaRegexURL(url, false);
		o = (RegexURL) this.regexURLs.get(requestRegex);
		if (null != o) {
			logger.debug("Match:" + url + "\t With:" + o);
			return true;
		}
		logger.info("Audit:" + url + " cannot passed!!!");

		return false;
	}
}
