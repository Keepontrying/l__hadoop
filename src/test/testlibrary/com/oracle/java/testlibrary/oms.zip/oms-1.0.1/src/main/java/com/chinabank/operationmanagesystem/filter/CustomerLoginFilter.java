package com.chinabank.operationmanagesystem.filter;

import com.wangyin.operation.common.beans.Page;
import com.wangyin.ssoclient.sso.model.Configuration;
import com.wangyin.ssoclient.sso.model.User;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 定制登录过滤器，区别view和biz请求
 *
 * @author dongzhihua
 */
//@Component
//@Order(10)
public class CustomerLoginFilter extends com.wangyin.ssoclient.sso.filter.LoginFilter {

	private static ThreadLocal<User> localUser = new ThreadLocal<User>();
	private static ThreadLocal<String> localAddress = new ThreadLocal<String>();

	private static Logger logger = LoggerFactory.getLogger(CustomerLoginFilter.class);

	@Override
	public void doFilter(ServletRequest a1, ServletResponse a2,
						 FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) a1;
		if (UserLoginOnlyFilter.excludeUriRegex != null && request.getRequestURI().matches(UserLoginOnlyFilter.excludeUriRegex)) {
			chain.doFilter(a1, a2);
		} else {
			User user = (User) request.getSession().getAttribute(Configuration.userSession);
			if (request.getParameter("ticket") == null && user == null && UserLoginOnlyFilter.isJson(request)) {
				HttpServletResponse response = (HttpServletResponse) a2;
				Page<Object> page = new Page<Object>();
				page.setCode("SESSION_TIMEOUT");
				page.setMessage("会话超时，请重新登录!(Session timeout!)");
				response.addHeader("content-type", "text/json;charset=utf-8");
				response.getWriter().write(JSONObject.fromObject(page).toString());
				return;
			}
			initUser(user);
			initAddress(request);

			super.doFilter(a1, a2, chain);
		}
	}

	// 初始化登陆人信息
	private void initUser(User user) {
		try {
			if (user != null) {
				localUser.set(user);
			} else {
				localUser.remove();
			}
		} catch (Exception e) {
			logger.warn("CustomerLoginFilter.removeUser exception: {}", e);
		}
	}

	// 初始化客户端地址
	private void initAddress(HttpServletRequest request) {
		try {
			String ip = request.getHeader("X-Real-IP");
			localAddress.set(ip);
		} catch (Exception e) {
			logger.warn("CustomerLoginFilter.initAddress exception: {}", e);
		}
	}

	/**
	 * 获取登录人信息
	 * @return
	 */
	public static User getUser() {
		return localUser.get();
	}

	/**
	 * 获取客户端地址
	 * @return
	 */
	public static String getAddress() {
		return localAddress.get();
	}
}
