/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-24</li>
 * <li>3、开发时间：上午10:34:58</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.util</li>
 * <li>6、文件名称：DateUtil.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.util;

import java.text.SimpleDateFormat;

/**
 * <ul>
 * <li>1、开发日期：2014-1-24</li>
 * <li>2、开发时间：上午10:34:58</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：DateUtil</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class DateUtil {

	/**
	 * yyyy-MM-dd
	 */
	public static String FORMAT1 = "format1";
	/**
	 * yyyy-MM-dd HH:mm:ss
	 */
	public static String FORMAT2 = "format2";
	/**
	 * yyyy/MM/dd
	 */
	public static String FORMAT3 = "format3";
	/**
	 * yyyy/MM/dd HH:mm:ss
	 */
	public static String FORMAT4 = "format4";
	private static SimpleDateFormat format1 = null;
	private static SimpleDateFormat format2 = null;
	private static SimpleDateFormat format3 = null;
	private static SimpleDateFormat format4 = null;
	
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-24</li>
	 * <li>2、开发时间：上午10:34:58</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public DateUtil() {
		// TODO Auto-generated constructor stub
	}
	
	public static SimpleDateFormat getInstance(String format) {
		if(FORMAT1.equals(format)) {
			return getFormat1();
		} else if(FORMAT2.equals(format)) {
			return getFormat2();
		} else if(FORMAT3.equals(format)) {
			return getFormat3();
		} else if(FORMAT4.equals(format)) {
			return getFormat4();
		}
		return null;
	}
	/**  
	 * Title: DateUtil.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	
	private static SimpleDateFormat getFormat1() {
		if (format1 == null) {
			synchronized (DateUtil.class) {
				if (format1 == null) {
					format1 = new SimpleDateFormat("yyyy-MM-dd");
				}
			}
		}
		return format1;
	}
	private static SimpleDateFormat getFormat2() {
		if (format2 == null) {
			synchronized (DateUtil.class) {
				if (format2 == null) {
					format2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				}
			}
		}
		return format2;
	}
	private static SimpleDateFormat getFormat3() {
		if (format3 == null) {
			synchronized (DateUtil.class) {
				if (format3 == null) {
					format3 = new SimpleDateFormat("yyyy/MM/dd");
				}
			}
		}
		return format3;
	}
	private static SimpleDateFormat getFormat4() {
		if (format4 == null) {
			synchronized (DateUtil.class) {
				if (format4 == null) {
					format4 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				}
			}
		}
		return format4;
	}
}
