/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：下午2:28:12</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.util</li>
 * <li>6、文件名称：QueryFormUtil.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.chinabank.operationmanagesystem.core.bean.form.DatePicker;
import com.chinabank.operationmanagesystem.core.bean.query.DatePairs;
import com.chinabank.operationmanagesystem.core.bean.query.Option;
import com.chinabank.operationmanagesystem.core.bean.query.Placeholder;
import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.QueryForm;
import com.chinabank.operationmanagesystem.core.bean.query.Select;
import com.chinabank.operationmanagesystem.core.bean.query.SubmitButton;
import com.chinabank.operationmanagesystem.core.bean.query.TextField;
import com.chinabank.operationmanagesystem.core.bean.query.ViewObject;
import com.chinabank.operationmanagesystem.core.bean.query.renderer.QueryRenderer;
import com.chinabank.operationmanagesystem.core.enums.TextTypeEnum;
import com.chinabank.operationmanagesystem.core.exception.NoSuchRendererException;
import com.chinabank.operationmanagesystem.core.renderer.DatePairsRenderer;
import com.chinabank.operationmanagesystem.core.renderer.DatePickerRenderer;
import com.chinabank.operationmanagesystem.core.renderer.PlaceholderRenderer;
import com.chinabank.operationmanagesystem.core.renderer.SelectRenderer;
import com.chinabank.operationmanagesystem.core.renderer.SubmitButtonRenderer;
import com.chinabank.operationmanagesystem.core.renderer.TextFieldRenderer;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：下午2:28:12</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：QueryFormUtil</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class QueryFormUtil {
	private static Logger logger = LoggerFactory.getLogger(QueryFormUtil.class);
	private static Map<String,QueryRenderer> factory = new HashMap<String,QueryRenderer>();
	private static final String CR = "\n";
	private static final String JS_CR = "\n\t";
	private static final String INDENT_ONE = "\t";
	private static final String INDENT_TWO = "\t\t";
	private static final String INDENT_THREE = "\t\t\t";
	private static final String INDENT_FOUR = "\t\t\t\t";
	private static final String INDENT_FIVE = "\t\t\t\t\t";
	private static final String INDENT_SIX = "\t\t\t\t\t\t";
	private static int datePickerId = 0;
	static {
		QueryFormUtil.register(TextField.class, new TextFieldRenderer());
		QueryFormUtil.register(Placeholder.class, new PlaceholderRenderer());
		QueryFormUtil.register(Select.class, new SelectRenderer());
		QueryFormUtil.register(SubmitButton.class, new SubmitButtonRenderer());
		QueryFormUtil.register(DatePairs.class, new DatePairsRenderer());
		QueryFormUtil.register(DatePicker.class, new DatePickerRenderer());
	}
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：下午2:28:12</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public QueryFormUtil() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午11:42:35</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：void</li>
	 * <li>5、方法含义：注册表单渲染器</li>
	 * <li>6、方法说明：以name作为渲染器名称，注册渲染器。</li>
	 * </ul>
	 * @param name
	 * @param formRenderer
	 */
	public static void register(String name, QueryRenderer QueryRenderer) {
		factory.put(name, QueryRenderer);
	}
	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午11:41:29</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：void</li>
	 * <li>5、方法含义：注册表单渲染器</li>
	 * <li>6、方法说明：以clazz的simpleName作为渲染器名称，注册渲染器。</li>
	 * </ul>
	 * @param clazz
	 * @param formRenderer
	 */
	public static void register(Class<?> clazz, QueryRenderer queryRenderer) {
		factory.put(clazz.getSimpleName(), queryRenderer);
	}
	
	private static QueryRenderer getRenderer(String name) throws NoSuchRendererException {
		QueryRenderer queryRenderer = factory.get(name);
		if(null == queryRenderer) {
			throw new NoSuchRendererException("没有这种渲染器："+name+"，请确保已经在QueryUtil中register。");
		}
		return queryRenderer;
	}
	
	/**  
	 * Title: QueryFormUtil.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	
	public static ViewObject getQueryForm(QueryForm queryForm) {
		List<QueryData> queryDataList = queryForm.getQueryDatas();
		StringBuilder html = new StringBuilder();
		html.append(JS_CR +"<div class='ui-search-form'>");
		html.append(JS_CR + INDENT_ONE +"<form id='selectForm'>");
		html.append(JS_CR + INDENT_TWO +"<table class='ui-search-item'>");
		StringBuilder ready = new StringBuilder();
		StringBuilder function = new StringBuilder();
		int num = queryForm.getNumPerLine();
		int i = 1;
		String td = JS_CR + INDENT_FOUR +"<td>";
		try {
			for (QueryData queryData : queryDataList) {
				if(1 == i) {
					html.append(JS_CR + INDENT_THREE +"<tr>");
				}
				html.append(td);
				boolean isHidden = false;
				if(queryData instanceof TextField) {
					TextField textField = (TextField) queryData;
					if(TextTypeEnum.HIDDEN.equals(textField.getType())) {//如果是hidden隐藏域，去掉<td>标签
						html.delete(html.length() - td.length(), html.length());
						isHidden = true;
						i --;
					}
				}
				QueryRenderer queryRenderer = QueryFormUtil.getRenderer(queryData.getClass().getSimpleName());
				ViewObject viewObject = queryRenderer.renderQuery(queryData);
				html.append(viewObject.getHtml());
				function.append(viewObject.getFunction());
				ready.append(viewObject.getReady());
				if(!isHidden) {
					html.append(JS_CR + INDENT_FOUR +"</td>");
				}
				if(num == i){
					html.append(JS_CR + INDENT_THREE +"</tr>");
					i=0;
				}
				i++;
			}
		} catch (NoSuchRendererException e) {
			e.printStackTrace();
		}
		if(i != num) {
			html.append(JS_CR + INDENT_THREE +"</tr>");
		}
		html.append(JS_CR + INDENT_TWO +"</table>");
		html.append(JS_CR + INDENT_ONE +"</form>");
		html.append(JS_CR +"</div>");
		function.append(JS_CR +"dataSource = function() {");
		function.append(JS_CR + INDENT_ONE +"var jsonuserinfo =$('#selectForm').serialize();");
		function.append(JS_CR + INDENT_ONE +"return '"+ queryForm.getUrl() +"?' +jsonuserinfo;");
		function.append(JS_CR +"};");
		ready.append(CR + JS_CR +"$('#query').click(function() {");
		ready.append(JS_CR + INDENT_ONE +"var jsonuserinfo =$('#selectForm').serialize();");
		ready.append(JS_CR + INDENT_ONE +"$('#grid').omGrid('setData', '"+ queryForm.getUrl() +"?' +jsonuserinfo);");
		ready.append(JS_CR +"});");
		return new ViewObject(html.toString(),function.toString(),ready.toString());
	}
	
	private static ViewObject getDatePicker(DatePairs datePicker) {
		if(datePickerId > 100) {//约定同一页面中，时间对元素不会大于100个
			datePickerId = 0;
		}
		StringBuilder ready = new StringBuilder();
		String function = "";
		StringBuilder html = new StringBuilder();
		int width = 75;
		if(datePicker.isShowTime()) {
			width = 140;
		}
		html.append(JS_CR + INDENT_FIVE +"<label>"+ datePicker.getLabel() +"</label>");
		html.append(JS_CR + INDENT_FIVE +"<input id='datePicker"+ datePickerId +"' name='"+ datePicker.getStartName() +"' type='text' class='iconrept' style='width:"+width+"px'> — <input id='datePicker"+ (datePickerId + 1) +"' name='"+ datePicker.getEndName() +"' type='text' class='iconrept' style='width:"+width+"px'>");
		SimpleDateFormat sdf = DateUtil.getInstance(DateUtil.FORMAT4);
		Date startTime = datePicker.getStartTime();
		Date endTime = datePicker.getEndTime();
		if(null == startTime && null == endTime ) {
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.DATE, datePicker.getTimeDiff());
			endTime = cal.getTime();
			cal.add(Calendar.DATE, -datePicker.getInterval());
			startTime = cal.getTime();
		} else {
			if( null == startTime ) {
				startTime = new Date();
				if(logger.isDebugEnabled()) {
					logger.debug("开始时间为空，默认返回系统当前时间！");
				}
			}
			if( null == endTime ) {
				endTime = new Date();
				if(logger.isDebugEnabled()) {
					logger.debug("结束时间为空，默认返回系统当前时间！");
				}
			}
		}
		ready.append(CR + JS_CR +"$('#datePicker"+ datePickerId +"').omCalendar({");
		ready.append(JS_CR + INDENT_ONE +"date: new Date('"+ sdf.format(startTime) +"'),");
		ready.append(JS_CR + INDENT_ONE +"showTime: "+ datePicker.isShowTime() +",");
		ready.append(JS_CR + INDENT_ONE +"readOnly: true");
		ready.append(JS_CR +"});");
		ready.append(CR + JS_CR +"$('#datePicker"+ (datePickerId + 1) +"').omCalendar({");
		ready.append(JS_CR + INDENT_ONE +"date: new Date('"+ sdf.format(endTime) +"'),");
		ready.append(JS_CR + INDENT_ONE +"showTime: "+ datePicker.isShowTime() +",");
		ready.append(JS_CR + INDENT_ONE +"readOnly: true");
		ready.append(JS_CR +"});");
		datePickerId +=2;
		return new ViewObject(html.toString(), function, ready.toString());
	}
	
	private static String getSubmitButton(SubmitButton submitButton) {
		String buttonHtml = "<span id='query' class='iconrept btn ml20'><span class='icon icon-ss mr5'></span>"+ submitButton.getLabel() +"</span>";
		return buttonHtml;
	}
	
	private static ViewObject getSelect(Select select) {
		String parentId = select.getParentId();
		String selectHtml = JS_CR + INDENT_FIVE +"<label>"+ select.getLabel() +"</label>";
		StringBuilder ready = new StringBuilder();
		String function = "";
		if(null == parentId || parentId.equals("")) {
			if(null != select.getId() && !"".equals(select.getId())) {
				selectHtml += JS_CR + INDENT_FIVE +"<select id='"+ select.getId() +"' class='ui-forms-select' name='"+ select.getName() +"'>";
			} else {
				selectHtml += JS_CR + INDENT_FIVE +"<select class='ui-forms-select' name='"+ select.getName() +"'>";
			}
		} else {
			selectHtml += JS_CR + INDENT_FIVE +"<select id='"+ select.getId() +"' class='ui-forms-select' name='"+ select.getName() +"'>";
			ready.append(CR + JS_CR + "$('#"+ parentId +"').bind('change',function() {");
			ready.append(JS_CR + INDENT_ONE +"var query =$(this).find(':selected').val();");
			ready.append(JS_CR + INDENT_ONE +"$.post('"+ select.getUrl() +"',");
			ready.append(JS_CR + INDENT_ONE +"{");
			String queryParamName = select.getQueryParamName();
			ready.append(JS_CR + INDENT_TWO +queryParamName + " : query");
			ready.append(JS_CR + INDENT_ONE +"},function(data) {");
			/*function += JS_CR + INDENT_TWO +"data = eval('('+data+')');";*/
			ready.append(JS_CR + INDENT_TWO +"var child = $('#"+ select.getId() +"');");
			ready.append(JS_CR + INDENT_TWO +"child.empty();");
			if(select.isShowDefault()) {
				ready.append(JS_CR + INDENT_TWO +"child.append(\"<option value=''>全部</option>\");");
			}
			ready.append(JS_CR + INDENT_TWO +"data.list.forEach(function(item) {");
			ready.append(JS_CR + INDENT_TWO + INDENT_ONE +"child.append(\"<option value='\"+ item."+ select.getJsonValueName() +" +\"'>\"+ item."+ select.getJsonTextName() +" +\"</option>\");");
			ready.append(JS_CR + INDENT_TWO +"});");
			ready.append(JS_CR + INDENT_TWO +"child.change();");
			ready.append(JS_CR + INDENT_ONE +"});");
			ready.append(JS_CR +"});");
		}
		if(select.isShowDefault()) {
			selectHtml += JS_CR + INDENT_SIX +"<option value='"+ select.getDefaultValue() +"' selected='selected'>"+ select.getDefaultText() +"</option>";
		}
		List<Option> optionList = select.getOptionList();
		StringBuilder sbSelectHtml = new StringBuilder();
		if(null != optionList) {
			for (Option option : optionList) {
				sbSelectHtml.append(JS_CR).append(INDENT_SIX).append("<option value='").append(option.getValue()).append("'>").append(option.getText()).append("</option>");
			}
		}
		selectHtml += sbSelectHtml.toString();
		if((null == parentId || parentId.equals("")) && null != select.getUrl() && !"".equals(select.getUrl())) {
			ready.append(CR + JS_CR +"$.post('"+ select.getUrl() +"',");
			if(select.getQueryValue() != null &&!"".equals(select.getQueryValue())) {
				ready.append(JS_CR + INDENT_ONE +"{");
				String queryParamName = select.getQueryParamName();
				String queryValue = select.getQueryValue();
				ready.append(JS_CR + INDENT_TWO +queryParamName + " : '" + queryValue +"'");
				ready.append(JS_CR + INDENT_ONE +"},");
			}
			ready.append(JS_CR + INDENT_ONE +"function(data) {");
			ready.append(JS_CR + INDENT_TWO +"var _self = $('#"+ select.getId() +"');");
			ready.append(JS_CR + INDENT_TWO +"data.list.forEach(function(item) {");
			ready.append(JS_CR + INDENT_TWO +"_self.append(\"<option value='\"+ item."+ select.getJsonValueName() +" +\"'>\"+ item."+ select.getJsonTextName() +" +\"</option>\");");
			ready.append(JS_CR + INDENT_ONE +"});");
			ready.append(JS_CR + INDENT_TWO +"_self.change();");
			ready.append(JS_CR +"});");
		}
		selectHtml += JS_CR + INDENT_FIVE +"</select>";
		return new ViewObject(selectHtml,function,ready.toString());
	}
	
	private static String getTextField(TextField textField) {
		String textFieldHtml = JS_CR + INDENT_FIVE +"<label>"+ textField.getLabel() +"</label>";
		textFieldHtml += JS_CR + INDENT_FIVE +"<input type='"+ textField.getType().getName() +"' name='"+ textField.getName() +"' value='"+  textField.getDefaultValue() +"' class='iconrept'/>";
		return textFieldHtml;
	}
	
}
