/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-3-31</li>
 * <li>3、开发时间：下午4:27:53</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.bean</li>
 * <li>6、文件名称：UploadObject.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.chinabank.operationmanagesystem.core.bean.UploadFile;

/**
 * <ul>
 * <li>1、开发日期：2014-3-31</li>
 * <li>2、开发时间：下午4:27:53</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：UploadObject</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class UploadObject implements Serializable{
	
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：UploadFiles.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 5009090862993009363L;
	private Map<String,String> params = new HashMap<String,String>();
	private Map<String,UploadFile> uploadFiles = new HashMap<String,UploadFile>();
	private boolean success = true;
	/**
	 * 调用上传插件时的版本号，推荐2.0
	 */
	private String version= "1.0";
	/**  
	 * Title: UploadFiles.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-31</li>
	 * <li>2、开发时间：下午4:30:11</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“params”的值
	 */
	public Map<String, String> getParams() {
		return params;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-31</li>
	 * <li>2、开发时间：下午4:30:11</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“params”的值将赋给字段“params”
	 */
	public void setParams(Map<String, String> params) {
		this.params = params;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-31</li>
	 * <li>2、开发时间：下午5:24:21</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“uploadFiles”的值
	 */
	public Map<String, UploadFile> getUploadFiles() {
		return uploadFiles;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-31</li>
	 * <li>2、开发时间：下午5:24:21</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“uploadFiles”的值将赋给字段“uploadFiles”
	 */
	public void setUploadFiles(Map<String, UploadFile> uploadFiles) {
		this.uploadFiles = uploadFiles;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-31</li>
	 * <li>2、开发时间：下午5:32:02</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“success”的值
	 */
	public boolean isSuccess() {
		return success;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-31</li>
	 * <li>2、开发时间：下午5:32:02</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“success”的值将赋给字段“success”
	 */
	public void setSuccess(boolean success) {
		this.success = success;
	}
	
	public List<UploadFile> getFileList() {
		List<UploadFile> list = new ArrayList<UploadFile>();
		Set<Entry<String, UploadFile>> set = uploadFiles.entrySet();
		for (Entry<String, UploadFile> entry : set) {
			list.add(entry.getValue());
		}
		return list;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-8-26</li>
	 * <li>2、开发时间：下午3:58:00</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“version”的值
	 */
	public String getVersion() {
		return version;
	}
	
	/**
	 * <ul>
	 * <li>1、开发日期：2014-8-26</li>
	 * <li>2、开发时间：下午3:58:00</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“version”的值将赋给字段“version”
	 */
	public void setVersion(String version) {
		this.version = version;
	}
	
	
}
