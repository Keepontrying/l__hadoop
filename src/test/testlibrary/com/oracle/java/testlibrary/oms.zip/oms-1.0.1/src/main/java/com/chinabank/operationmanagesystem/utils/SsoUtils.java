package com.chinabank.operationmanagesystem.utils;

import com.wangyin.ssoclient.sso.servlet.LogoutInvokeServlet;
import com.wangyin.ssoclient.sso.servlet.LogoutServlet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 单点工具
 *
 * @author: dongzhihua
 * @time: 2018/6/27 12:40:05
 */
public class SsoUtils {

	static LogoutServlet logoutServlet = new LogoutServlet();
	static LogoutInvokeServlet logoutInvokeServlet = new LogoutInvokeServlet();

	/**
	 * 退出
	 *
	 * @author: dongzhihua
	 * @time: 2018/6/27 12:47:17
	 */
	public static void logout(HttpServletRequest request, HttpServletResponse response) {
		try {
			logoutServlet.doPost(request, response);
		} catch (Exception e) {
			throw new RuntimeException("退出异常", e);
		}
	}

	/**
	 * 执行退出
	 *
	 * @author: dongzhihua
	 * @time: 2018/6/27 12:47:53
	 */
	public static void logoutInvoke(HttpServletRequest request, HttpServletResponse response) {
		try {
			logoutInvokeServlet.doPost(request, response);
		} catch (Exception e) {
			throw new RuntimeException("执行退出异常", e);
		}
	}
}
