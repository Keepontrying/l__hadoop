/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-4-8</li>
 * <li>3、开发时间：上午10:24:43</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.util</li>
 * <li>6、文件名称：FormUtil.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.chinabank.operationmanagesystem.core.bean.form.DatePicker;
import com.chinabank.operationmanagesystem.core.bean.form.Form;
import com.chinabank.operationmanagesystem.core.bean.form.TextArea;
import com.chinabank.operationmanagesystem.core.bean.form.renderer.FormRenderer;
import com.chinabank.operationmanagesystem.core.bean.query.DatePairs;
import com.chinabank.operationmanagesystem.core.bean.query.Option;
import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.Select;
import com.chinabank.operationmanagesystem.core.bean.query.SubmitButton;
import com.chinabank.operationmanagesystem.core.bean.query.TextField;
import com.chinabank.operationmanagesystem.core.bean.query.ViewObject;
import com.chinabank.operationmanagesystem.core.enums.TextTypeEnum;
import com.chinabank.operationmanagesystem.core.exception.NoSuchRendererException;
import com.chinabank.operationmanagesystem.core.renderer.DatePairsRenderer;
import com.chinabank.operationmanagesystem.core.renderer.DatePickerRenderer;
import com.chinabank.operationmanagesystem.core.renderer.SelectRenderer;
import com.chinabank.operationmanagesystem.core.renderer.SubmitButtonRenderer;
import com.chinabank.operationmanagesystem.core.renderer.TextAreaRenderer;
import com.chinabank.operationmanagesystem.core.renderer.TextFieldRenderer;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/**
 * <ul>
 * <li>1、开发日期：2014-4-8</li>
 * <li>2、开发时间：上午10:24:43</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：FormUtil</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class FormUtil {
	private static Logger logger = LoggerFactory.getLogger(FormUtil.class);
	private static Map<String,FormRenderer> factory = new HashMap<String,FormRenderer>();
	public static final String CR = "\n";
	public static final String JS_CR = "\n\t";
	public static final String INDENT_ONE = "\t";
	public static final String INDENT_TWO = "\t\t";
	public static final String INDENT_THREE = "\t\t\t";
	public static final String INDENT_FOUR = "\t\t\t\t";
	public static final String INDENT_FIVE = "\t\t\t\t\t";
	public static final String INDENT_SIX = "\t\t\t\t\t\t";
	static {
		FormUtil.register(TextField.class, new TextFieldRenderer());
		FormUtil.register(Select.class, new SelectRenderer());
		FormUtil.register(SubmitButton.class, new SubmitButtonRenderer());
		FormUtil.register(DatePairs.class, new DatePairsRenderer());
		FormUtil.register(TextArea.class, new TextAreaRenderer());
		FormUtil.register(DatePicker.class, new DatePickerRenderer());
	}
	/**  
	 * Title: FormUtil.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	
	public FormUtil() {}
	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午11:42:35</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：void</li>
	 * <li>5、方法含义：注册表单渲染器</li>
	 * <li>6、方法说明：以name作为渲染器名称，注册渲染器。</li>
	 * </ul>
	 * @param name
	 * @param formRenderer
	 */
	public static void register(String name, FormRenderer formRenderer) {
		factory.put(name, formRenderer);
	}
	
	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午11:41:29</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：void</li>
	 * <li>5、方法含义：注册表单渲染器</li>
	 * <li>6、方法说明：以clazz的simpleName作为渲染器名称，注册渲染器。</li>
	 * </ul>
	 * @param clazz
	 * @param formRenderer
	 */
	public static void register(Class<?> clazz, FormRenderer formRenderer) {
		factory.put(clazz.getSimpleName(), formRenderer);
	}
	
	private static FormRenderer getRenderer(String name) throws NoSuchRendererException {
		FormRenderer formRenderer = factory.get(name);
		if(null == formRenderer) {
			throw new NoSuchRendererException("没有这种渲染器："+name+"，请确保已经在FormUtil中register。");
		}
		return formRenderer;
	}
	
	public static ViewObject getForm(Form form) {
		Integer id = 0;
		StringBuilder html = new StringBuilder();
		StringBuilder ready = new StringBuilder();
		StringBuilder function = new StringBuilder();
		html.append(JS_CR).append(INDENT_ONE).append("<div class='m15'>");
		html.append(JS_CR).append(INDENT_TWO).append("<form id='saveForm'>");
		html.append(JS_CR).append(INDENT_THREE).append("<table class='ui-search-item'>");
		List<QueryData> list = form.getQueryDatas();
		int num = form.getNumPerLine();
		int i = 1;
		String td = JS_CR + INDENT_FOUR +"<td>";
		String tr = JS_CR + INDENT_THREE +"<tr>";
		String backTd = JS_CR + INDENT_FOUR +"</td>";
		String backTr = JS_CR + INDENT_THREE +"</tr>";
		boolean isHidden = false;
		List<SubmitButton> buttons = new ArrayList<SubmitButton>();
		for (QueryData queryData : list) {
			if(queryData instanceof SubmitButton) {
				buttons.add((SubmitButton)queryData);
				continue;
			}
			if(1 == i) {
				html.append(tr);
			}
			if(queryData instanceof TextField) {
				TextField textField = (TextField) queryData;
				if(TextTypeEnum.HIDDEN.equals(textField.getType())) {//如果是hidden隐藏域，不添加<td>标签
					isHidden = true;
					i --;
				} else {
					html.append(td);
				}
			} else {
				html.append(td);
			}
			try {
				FormRenderer formRenderer = FormUtil.getRenderer(queryData.getClass().getSimpleName());
				ViewObject viewObject = formRenderer.renderForm(queryData);
				if(null == viewObject) {
					//处理异常 throw
				}
				html.append(viewObject.getHtml());
				ready.append(viewObject.getReady());
				function.append(viewObject.getFunction());
			} catch (NoSuchRendererException e) {
				logger.error("生成表单页面出错。",e.fillInStackTrace());
			}
			if(!isHidden) {//如果不是隐藏域，添加</td>标签
				html.append(backTd);
			}
			if(num == i){
				html.append(backTr);
				i=0;
			}
			i++;
		}
		if(i != num) {//最后，即时没到限制行数，也加上</tr>
			html.append(backTr);
		}
		html.append(JS_CR).append(INDENT_THREE).append("</table>");
		html.append(JS_CR).append(INDENT_TWO).append("</form>");
		html.append(JS_CR).append(INDENT_ONE).append("</div>");
		html.append(JS_CR).append(INDENT_ONE).append("<div class='alignc mt30'>");
		for(SubmitButton submitButton : buttons) {
			FormRenderer formRenderer = null;
			try {
				submitButton.setUrl(form.getUrl());
				formRenderer = FormUtil.getRenderer(submitButton.getClass().getSimpleName());
			} catch (NoSuchRendererException e) {
				logger.error("生成表单页面出错。",e.fillInStackTrace());
			}
			ViewObject viewObject = formRenderer.renderForm(submitButton);
			String htmlTemp = viewObject.getHtml();
			String htmlButton = htmlTemp.replaceAll("\\$\\{id\\}", id.toString());
			html.append(JS_CR).append(INDENT_TWO).append(htmlButton);
			String readyTemp = viewObject.getReady();
			String readyButton = readyTemp.replaceAll("\\$\\{id\\}", id.toString());
			ready.append(readyButton);
			function.append(viewObject.getFunction().toString());
			id ++;
		}
		html.append(JS_CR).append(INDENT_ONE).append("</div>");
		return new ViewObject(html.toString(),function.toString(),ready.toString());
	}
	
	public static void main(String[] args) {
		List<Option> optionList = new ArrayList<Option>();
		optionList.add(new Option("0001","北京市"));
		optionList.add(new Option("0002","天津市"));
		String url = "/operationmanagesystem/desktop/query.biz";
		Select select = new Select("详细地址","provinceCode","/operationmanagesystem/desktop/province.biz");
		select.setId("province");
		Select child = new Select("","cityCode",url,"province");
		child.setId("city");
		child.setShowDefault(false);
		
		List<QueryData> queryDataList = new ArrayList<QueryData>();
		queryDataList.add(new TextField("商户名","companyName"));
		queryDataList.add(new TextField("商户类型","customerType"));
		queryDataList.add(select);
		queryDataList.add(child);
		queryDataList.add(new DatePairs("签约日期","startTime","endTime",new Date(),new Date()));
		queryDataList.add(new SubmitButton("查询"));
		
		Form form = new Form();
		form.setNumPerLine(3);
		form.setUrl("/dict/dict/queryTest.biz");
		form.setQueryDatas(queryDataList);
		ViewObject viewObject = FormUtil.getForm(form);
		System.out.println();
	}
}
