package com.chinabank.operationmanagesystem.core.util;
import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PluginScriptExecutor extends URLClassLoader {
	private File root;
	private String impClass;
	private Constructor<?> scriptConstructor;
	private Method evalMethod;
	private Method callMethod;
	private Map<String,Object> cachedMap=new ConcurrentHashMap<String,Object>();

	public PluginScriptExecutor(String plugin, String impClass) {
		super(new URL[] {});
		this.root = new File(plugin);
		this.impClass = impClass;
		init();

	}

	private void init() {
		List<File> files = new ArrayList<File>();
		loopFiles(root, files);
		for (File f : files) {
			try {
				this.addURL(f.toURI().toURL());
			} catch (MalformedURLException e) {
				// log.error(e);
			}
		}
	}

	private static final void loopFiles(File file, List<File> files) {
		if (file.isDirectory()) {
			File[] tmps = file.listFiles();
			for (File tmp : tmps) {
				loopFiles(tmp, files);
			}
		} else {
			if (file.getAbsolutePath().endsWith(".jar")
					|| file.getAbsolutePath().endsWith(".zip")) {
				files.add(file);
			}
		}
	}

	public void eval(String name, String filePath) {
		Thread.currentThread().setContextClassLoader(this);
		if (scriptConstructor == null) {
			try {
				Class<?> scriptImp = this.loadClass(impClass);
				scriptConstructor = scriptImp.getConstructor(String.class);
				evalMethod = scriptImp.getMethod("eval", File.class);
				callMethod = scriptImp.getMethod("call", String.class,
						Object[].class);
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				Object script = scriptConstructor.newInstance(name);
				evalMethod.invoke(script, new File(filePath));
				cachedMap.put(name, script);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	public Object call(String name, String function, Object[] parameters) {
		Object script = cachedMap.get(name);
		if (script != null) {
			try {
				return callMethod.invoke(script, function, parameters);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return null;

	}

}
