/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-4-8</li>
 * <li>3、开发时间：上午11:31:27</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.exception</li>
 * <li>6、文件名称：NoSuchRendererException.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.exception;

/**
 * <ul>
 * <li>1、开发日期：2014-4-8</li>
 * <li>2、开发时间：上午11:31:27</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：NoSuchRendererException</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class NoSuchAdapterException extends Exception {

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：NoSuchRendererException.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -8135728519734994433L;
	/**  
	 * Title: NoSuchRendererException.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */

	public NoSuchAdapterException() {
		super();
	}

	public NoSuchAdapterException(String message, Throwable cause) {
		super(message, cause);
	}

	public NoSuchAdapterException(String message) {
		super(message);
	}

	public NoSuchAdapterException(Throwable cause) {
		super(cause);
	}
	
	
}
