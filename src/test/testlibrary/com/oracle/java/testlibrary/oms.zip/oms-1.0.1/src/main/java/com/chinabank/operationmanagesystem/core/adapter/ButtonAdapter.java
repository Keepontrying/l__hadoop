/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-4-29</li>
 * <li>3、开发时间：下午7:25:52</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.adapter</li>
 * <li>6、文件名称：ButtonAdapter.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.adapter;

import com.chinabank.operationmanagesystem.core.bean.Element;
import com.chinabank.operationmanagesystem.core.bean.form.adapter.FormAdapter;
import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.SubmitButton;
import com.chinabank.operationmanagesystem.core.bean.query.adapter.QueryAdapter;
import com.chinabank.operationmanagesystem.core.enums.ButtonEnum;

/**
 * <ul>
 * <li>1、开发日期：2014-4-29</li>
 * <li>2、开发时间：下午7:25:52</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：ButtonAdapter</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class ButtonAdapter implements FormAdapter, QueryAdapter {

	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午7:25:52</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.query.adapter.QueryAdapter#adapter4Query(com.chinabank.operationmanagesystem.core.bean.Element)
	 */
	@Override
	public QueryData adapter4Query(Element element) {
		return this.adapter4Form(element);
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午7:25:52</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.form.adapter.FormAdapter#adapter4Form(com.chinabank.operationmanagesystem.core.bean.Element)
	 */
	@Override
	public QueryData adapter4Form(Element element) {
		SubmitButton submitButton = new SubmitButton();
		submitButton.setLabel(element.getLabel());
		submitButton.setName(element.getName());
		submitButton.setButtonEnum(ButtonEnum.valueOf(element.getValue()));
		return submitButton;
	}
	/**  
	 * Title: ButtonAdapter.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
}
