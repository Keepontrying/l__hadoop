/**
 * <p>项目名称：operation-log<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-3-5</li>
 * <li>3、开发时间：上午11:09:41</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operation.log.util</li>
 * <li>6、文件名称：MD5Util.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.util;

/**
 * <ul>
 * <li>1、开发日期：2014-3-5</li>
 * <li>2、开发时间：上午11:09:41</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：MD5Util</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
import java.security.MessageDigest;

public class MD5Util {
	public final static String MD5(String s) {
		char hexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
				'A', 'B', 'C', 'D', 'E', 'F' };
		try {
			byte[] btInput = s.getBytes();
			// 获得MD5摘要算法的 MessageDigest 对象
			MessageDigest mdInst = MessageDigest.getInstance("MD5");
			// 使用指定的字节更新摘要
			mdInst.update(btInput);
			// 获得密文
			byte[] md = mdInst.digest();
			// 把密文转换成十六进制的字符串形式
			int j = md.length;
			char str[] = new char[j * 2];
			int k = 0;
			for (int i = 0; i < j; i++) {
				byte byte0 = md[i];
				str[k++] = hexDigits[byte0 >>> 4 & 0xf];
				str[k++] = hexDigits[byte0 & 0xf];
			}
			return new String(str);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
