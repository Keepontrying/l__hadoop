package com.chinabank.operationmanagesystem.desktop.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.Map;

import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;


public final class HttpURLUtil {

	private static Logger logger = LoggerFactory.getLogger(HttpURLUtil.class);
	public static String doPost(String reqUrl, Map parameters) {
		return doPost(reqUrl, parameters, "UTF-8");
	}

	/**
	 * 
	 * @param reqUrl
	 * @param parameters
	 * @return
	 */
	public static String doPost(String reqUrl, Map parameters, String charset) {
		if(HttpURLUtil.isURL(reqUrl)) {
			HttpURLConnection urlConn = null;
			try {
				urlConn = sendPost(reqUrl, parameters, charset);
				String responseContent = getContent(urlConn, charset);
				return responseContent.trim();
			} finally {
				if (urlConn != null) {
					urlConn.disconnect();
					urlConn = null;
				}
			}
		} else {
			HttpURLUtil.logger.info("URL地址("+reqUrl+")不合法。请检查！");
			return null;
		}
	}

	/**
	 * 
	 * @param urlConn
	 * @return
	 */
	private static String getContent(HttpURLConnection urlConn, String charset) {
		try {
			String responseContent = null;
			InputStream in = urlConn.getInputStream();
			BufferedReader rd = new BufferedReader(new InputStreamReader(in, charset));
			String tempLine = rd.readLine();
			StringBuffer tempStr = new StringBuffer();
			String crlf = System.getProperty("line.separator");
			while (tempLine != null) {
				tempStr.append(tempLine);
				tempStr.append(crlf);
				tempLine = rd.readLine();
			}
			responseContent = tempStr.toString();
			rd.close();
			in.close();
			return responseContent;
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	/**
	 * qqq
	 * 
	 * @param reqUrl
	 * @param parameters
	 * @return
	 */
	private static HttpURLConnection sendPost(String reqUrl, Map parameters,
			String charset) {
		HttpURLConnection urlConn = null;
		try {
			String params = generatorParamString(parameters, charset);

			URL url = new URL(reqUrl);
			urlConn = (HttpURLConnection) url.openConnection();
			urlConn.setRequestMethod("POST");
			// urlConn.setConnectTimeout(30000);
			// urlConn.setReadTimeout(50000);
			urlConn.setDoOutput(true);

			byte[] b = params.getBytes("UTF-8");
			urlConn.getOutputStream().write(b, 0, b.length);
			urlConn.getOutputStream().flush();
			urlConn.getOutputStream().close();
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		return urlConn;
	}

	public static String generatorParamString(Map parameters, String charset) {
		StringBuffer params = new StringBuffer();
		if (parameters != null) {
			for (Iterator iter = parameters.keySet().iterator(); iter.hasNext();) {
				String name = iter.next().toString();
				String value = parameters.get(name).toString();
				if (value == null) {
					continue;
				}
				params.append(name + "=");
				try {
					params.append(URLEncoder.encode(value,"UTF-8"));
					// params.append(URLEncoder.encode(value));
				} catch (Exception e) {
					throw new RuntimeException("message", e);
				}
				if (iter.hasNext()) {
					params.append("&");
				}
			}
		}
		return params.toString();
	}

	public static String urlEncoding(String url, String enc) {
		try {
			return URLEncoder.encode(url, enc);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static boolean isURL(String reqUrl) {
		if(null != reqUrl) {
			if(reqUrl.matches("^http://.+")) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
}
