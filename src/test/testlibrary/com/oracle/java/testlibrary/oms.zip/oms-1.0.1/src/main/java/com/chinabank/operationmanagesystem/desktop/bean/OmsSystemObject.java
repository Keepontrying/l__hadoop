package com.chinabank.operationmanagesystem.desktop.bean;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartHttpServletRequest;

/**
 * 系统对象
 * @author dongzhihua
 * @time 2017年11月6日 下午9:43:50
 */
public class OmsSystemObject {

	private String project;
	private String module;
	private String action;
	private HttpServletResponse response;
	private MultipartHttpServletRequest request;

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	public MultipartHttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(MultipartHttpServletRequest request) {
		this.request = request;
	}
}
