	//将页面上所有readonly的input，背景置灰
	$(document).ready(function() {
		$("input[readonly='readonly']").css("background","#eee");
	});
	gridHeight = function() {
		var winHeight;
		if(parent != self) {//如果在框架中
			//减30去掉上下边框
			winHeight = parent.document.documentElement.clientHeight - $('header', parent.parent.document).height() - $('nav.iconrept', parent.parent.document).height() - 30;
		} else {
			winHeight = document.documentElement.clientHeight;
		}
		winHeight = winHeight - 40;//减40，去掉上下border
		var actionDiv = $('.actionDiv');
		if(false === actionDiv.is(":hidden")) {
			winHeight = winHeight - actionDiv.outerHeight(true);
		}
		return winHeight;
	}
	
	function getSingleForm(url,rowData) {
		// 创建Form
		var form = $('<form></form>');
		// 设置属性
		form.attr('action', url);
		form.attr('method', 'post');
		// form的target属性决定form在哪个页面提交
		// _self -> 当前页面 _blank -> 新页面
		form.attr('target', '_self');
		$.each(rowData,function(name,value){
			if(null != value) {
				// 创建Input
				var my_input = $('<input type="text" />');
				my_input.attr('name', name);
				my_input.attr('value', value);
				// 附加到Form
				form.append(my_input);
			}
		});
		$(form).hide();
		$(form).appendTo("body");
		return form;
	}
	
	function hiddenSingleSubmit(url,rowData) {
		// 创建Form
		var form = getSingleForm(url,rowData);
		// 提交表单
		form.submit();
	}
	
	function hiddenSingleAjax(url,rowData) {
		var form = getSingleForm(url,rowData);
		var params = form.serialize();
		form.remove();
		var result;
		$.ajax({
			type : "post",
			url : url,
			data : params,
			async : false,
			dataType : "json",
			success : function(data) {
				result = data;
			}
		});
		return result;
	}
	
	function doSingleAjax(_self,url) {
		var diabled = _self.hasClass('disabled');
		if(!diabled) {
			_grid = $('#grid');
			_tip = $('.ui-tiptext-success');
			var selectRows = _grid.omGrid('getSelections',true);
			var result = hiddenSingleAjaxWithRemark(url,selectRows[0]);
			if(undefined == result) {
				alert('网络异常，请稍后重试！');
				return;
			}
			if(false == result.success){
				alert(result.message);
			} else {
				_tip.find('.success').text(result.message);
				_tip.show();
				_tip.fadeOut(3000);
				_grid.omGrid('reload');
			}
		}
	}
	
	function doSingleForm(_self,url) {
		var diabled = _self.hasClass('disabled');
		if(!diabled) {
			var selectRows = $('#grid').omGrid('getSelections',true);
			hiddenSingleSubmit(url,selectRows[0]);
		}
	}
	
	function getMultiForm(url,rowsData) {
		// 创建Form
		var form = $('<form></form>');
		// 设置属性
		form.attr('action', url);
		form.attr('method', 'post');
		// form的target属性决定form在哪个页面提交
		// _self -> 当前页面 _blank -> 新页面
		form.attr('target', '_self');
		$.each(rowsData,function(index,item){
			$.each(item,function(name,value){
				if(null != value) {
					// 创建Input
					var my_input = $('<input type="text" />');
					my_input.attr('name', 'list'+'['+index+'].'+name);
					my_input.attr('value', value);
					// 附加到Form
					form.append(my_input);
				}
			});
		});
		$(form).hide();
		$(form).appendTo("body");
		return form;
	}
	
	function hiddenMultiSubmit(url,rowsData) {
		var form = getMultiForm(url,rowsData);
		// 提交表单
		form.submit();
	}

	function hiddenMultiAjax(url,rowData) {
		var form = getMultiForm(url,rowData);
		var params = form.serialize();
		form.remove();
		var result;
		$.ajax({
			type : "post",
			url : url,
			data : params,
			async : false,
			dataType : "json",
			success : function(data) {
				result = data;
			}
		});
		return result;
	}
	
	function doMultiAjax(_self,url) {
		var diabled = _self.hasClass('disabled');
		if(!diabled) {
			_grid = $('#grid');
			_tip = $('.ui-tiptext-success');
			var selectRows = _grid.omGrid('getSelections',true);
			var result = hiddenMultiAjaxWithRemark(url,selectRows);
			if(undefined == result) {
				alert('网络异常，请稍后重试！');
				return;
			}
			if(false == result.success){
				alert(result.message);
			} else {
				_tip.find('.success').text(result.message);
				_tip.show();
				_tip.fadeOut(3000);
				_grid.omGrid('reload');
			}
		}
	}
	
	function checkSelect() {
		var selectedIndexed = $('#grid').omGrid('getSelections');
		var _multi = $('.multi');
		if(selectedIndexed.length >= 1) {
			_multi.removeClass('disabled');
		} else {
			_multi.addClass('disabled');
		}
		var _single = $('.single');
		if(selectedIndexed.length == 1) {
			_single.removeClass('disabled');
		} else {
			_single.addClass('disabled');
		}
	}
	
	function checkConditionSelect() {
		var rowsData = $('#grid').omGrid('getSelections',true);
		var buttons = $('.ui-action .btn');
		$.each(buttons,function(index,button){
			var rule = $(button).attr('rule');
			if("" != rule) {
				$.each(rowsData,function(index,item){
					var flag = eval(rule);
					if(false == flag) {
						$(button).addClass('disabled');
						return false;
					}
				});
			}
		});
	}
	
	function doAjax4Form2Jump(url,back,_form) {
		if(_form.valid()) {
			var params = _form.serialize();
			$.ajax({
				type : "post",
				url : url,
				data : params,
				dataType : "json",
				success : function(data) {
					if(undefined == data) {
						alert('网络出现问题，请多次尝试，如果无效，请记录当前时间并联系相关人员！')
						return;
					}
					if(false == data.success) {
						alert(data.message);
						return;
					}
					window.location = back;
				}
			});
		}
	}
	
	function getMultiFormWithRemark(url,rowsData,remarkName,remark) {
		// 创建Form
		var form = $('<form></form>');
		// 设置属性
		form.attr('action', url);
		form.attr('method', 'post');
		// form的target属性决定form在哪个页面提交
		// _self -> 当前页面 _blank -> 新页面
		form.attr('target', '_self');
		$.each(rowsData,function(index,item){
			$.each(item,function(name,value){
				if(null != value) {
					// 创建Input
					var my_input = $('<input type="text" />');
					my_input.attr('name', 'list'+'['+index+'].'+name);
					my_input.attr('value', value);
					// 附加到Form
					form.append(my_input);
				}
			});
		});
		if('undefined' != remarkName && null != remarkName) {
			// 创建Input
			var my_input = $('<input type="text" />');
			my_input.attr('name', remarkName);
			my_input.attr('value', remark);
			// 附加到Form
			form.append(my_input);
		}
		$(form).hide();
		$(form).appendTo("body");
		return form;
	}
	
	function hiddenMultiSubmitWithRemark(url,rowsData,remarkName,remark) {
		var form = getMultiFormWithRemark(url,rowsData,remarkName,remark);
		// 提交表单
		form.submit();
	}

	function hiddenMultiAjaxWithRemark(url,rowData,remarkName,remark) {
		var form = getMultiFormWithRemark(url,rowData,remarkName,remark);
		var params = form.serialize();
		form.remove();
		var result;
		$.ajax({
			type : "post",
			url : url,
			data : params,
			async : false,
			dataType : "json",
			success : function(data) {
				result = data;
			}
		});
		return result;
	}
	
	function doMultiAjaxWithRemark(_self,url,remarkName,remark) {
		var diabled = _self.hasClass('disabled');
		if(!diabled) {
			_grid = $('#grid');
			_tip = $('.ui-tiptext-success');
			var selectRows = _grid.omGrid('getSelections',true);
			var result = hiddenMultiAjaxWithRemark(url,selectRows,remarkName,remark);
			if(undefined == result) {
				alert('网络异常，请稍后重试！');
				return;
			}
			if(false == result.success){
				alert(result.message);
			} else {
				_tip.find('.success').text(result.message);
				_tip.show();
				_tip.fadeOut(3000);
				_grid.omGrid('reload');
			}
		}
	}
	
	function getSingleFormWithRemark(url,rowData,remarkName,remark) {
		// 创建Form
		var form = $('<form></form>');
		// 设置属性
		form.attr('action', url);
		form.attr('method', 'post');
		// form的target属性决定form在哪个页面提交
		// _self -> 当前页面 _blank -> 新页面
		form.attr('target', '_self');
		$.each(rowData,function(name,value){
			if(null != value) {
				// 创建Input
				var my_input = $('<input type="text" />');
				my_input.attr('name', name);
				my_input.attr('value', value);
				// 附加到Form
				form.append(my_input);
			}
		});
		if('undefined' != remarkName && null != remarkName) {
			// 创建Input
			var my_input = $('<input type="text" />');
			my_input.attr('name', remarkName);
			my_input.attr('value', remark);
			// 附加到Form
			form.append(my_input);
		}
		$(form).hide();
		$(form).appendTo("body");
		return form;
	}
	
	function hiddenSingleSubmitWithRemark(url,rowData,remarkName,remark) {
		// 创建Form
		var form = getSingleFormWithRemark(url,rowData,remarkName,remark);
		// 提交表单
		form.submit();
	}
	
	function hiddenSingleAjaxWithRemark(url,rowData,remarkName,remark) {
		var form = getSingleFormWithRemark(url,rowData,remarkName,remark);
		var params = form.serialize();
		form.remove();
		var result;
		$.ajax({
			type : "post",
			url : url,
			data : params,
			async : false,
			dataType : "json",
			success : function(data) {
				result = data;
			}
		});
		return result;
	}
	
	function doSingleAjaxWithRemark(_self,url,remarkName,remark) {
		var diabled = _self.hasClass('disabled');
		if(!diabled) {
			_grid = $('#grid');
			_tip = $('.ui-tiptext-success');
			var selectRows = _grid.omGrid('getSelections',true);
			var result = hiddenSingleAjaxWithRemark(url,selectRows[0],remarkName,remark);
			if(undefined == result) {
				alert('网络异常，请稍后重试！');
				return;
			}
			if(false == result.success){
				alert(result.message);
			} else {
				_tip.find('.success').text(result.message);
				_tip.show();
				_tip.fadeOut(3000);
				_grid.omGrid('reload');
			}
		}
	}
	
	function doSingleFormWithRemark(_self,url,remarkName,remark) {
		var diabled = _self.hasClass('disabled');
		if(!diabled) {
			var selectRows = $('#grid').omGrid('getSelections',true);
			hiddenSingleSubmitWithRemark(url,selectRows[0],remarkName,remark);
		}
	}

	function getQueryStringByGrid4Single(grid) {
		var selectRows = grid.omGrid('getSelections',true);
		var queryString = getQueryStringByRowData4Single(selectRows[0]);
		return queryString;
	}
	
	function getQueryStringByRowData4Single(rowData) {
		var queryString = '';
		var count = 0;
		$.each(rowData,function(name,value){
			if(null != value) {
				if(count !== 0) {
					queryString +='&';
				}
				queryString += name + '=' + encodeURIComponent(value);
				count ++;
			}
		});
		return queryString;
	}
	
	function getQueryStringByGrid4Multi(grid) {
		var selectRows = grid.omGrid('getSelections',true);
		var queryString = getQueryStringByRowData4Single(selectRows);
		return queryString;
	}
	
	function getQueryStringByRowData4Multi(rowData) {
		var queryString = '';
		var count = 0;
		$.each(rowsData,function(index,item){
			$.each(item,function(name,value){
				if(null != value) {
					if(count !== 0) {
						queryString +='&';
					}
					queryString += 'list'+'['+index+'].'+name + '=' + encodeURIComponent(value);
					count ++;
				}
			});
		});
		return queryString;
	}
	
	