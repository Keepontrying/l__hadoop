/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-5-8</li>
 * <li>3、开发时间：下午12:12:10</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.rules</li>
 * <li>6、文件名称：RequiredRule.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.rules;

/**
 * <ul>
 * <li>1、开发日期：2014-5-8</li>
 * <li>2、开发时间：下午12:12:10</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：RequiredRule</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class RequiredRule extends BaseRule {

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：RequiredRule.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -7569160119150540100L;
	/**  
	 * Title: RequiredRule.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private Boolean value = true;
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-12</li>
	 * <li>2、开发时间：下午6:19:05</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.rules.BaseRule#getValue()
	 */
	@Override
	public String getValue() {
		return value.toString();
	}
}
