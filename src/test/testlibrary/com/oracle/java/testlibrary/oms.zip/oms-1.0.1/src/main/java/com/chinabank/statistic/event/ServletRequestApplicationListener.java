package com.chinabank.statistic.event;

import com.chinabank.operationmanagesystem.filter.CustomerLoginFilter;
import com.chinabank.statistic.domain.RequestDomain;
import com.chinabank.statistic.service.RequestServerHandler;
import com.wangyin.commons.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import org.springframework.web.context.support.ServletRequestHandledEvent;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Date;

/**
 * 请求事件处理
 * @author: dongzhihua
 * @time: 2018/5/18 15:48:56
 */
@Component
public class ServletRequestApplicationListener implements ApplicationListener<ServletRequestHandledEvent> {

	private static final Logger logger = LoggerFactory.getLogger(ServletRequestApplicationListener.class);

	@Autowired
	RequestServerHandler statisticServer;

	@Override
	public void onApplicationEvent(ServletRequestHandledEvent event) {
		logger.info("ServletRequestApplicationListener.onApplicationEvent event: {}", event);
		RequestDomain requestDomain = new RequestDomain();
		requestDomain.setExceptionMessage(getExceptionMessage(event.getFailureCause()));
		if (CustomerLoginFilter.getUser() != null) {
			requestDomain.setUserName(CustomerLoginFilter.getUser().getUsername());
		}
		requestDomain.setResponseTime(new Date(event.getTimestamp()));
		requestDomain.setUri(event.getRequestUrl());
		requestDomain.setProcessingTimeMillis(event.getProcessingTimeMillis());
		requestDomain.setReqType("OMS");
		requestDomain.setClientAddress(CustomerLoginFilter.getAddress());
        try {
            requestDomain.setServerAddress(InetAddress.getLocalHost().getHostAddress());
        } catch (UnknownHostException e) {
            logger.error("onApplicationEvent 获取本机ip地址异常：", e);
        }
        statisticServer.saveInfoAsync(requestDomain);
	}

	/**
	 * 获取异常信息，保留100个字节
	 * @param throwable
	 * @return
	 */
	public static String getExceptionMessage(Throwable throwable) {
		if (throwable == null) {
			return null;
		}
		try {
			String message = StringUtil.join(throwable.getClass().getSimpleName(), ":", throwable.getMessage());
			byte[] msgBytes = message.getBytes("UTF-8");
			if(msgBytes.length > 100) {
				msgBytes = Arrays.copyOf(msgBytes, 100);
				message = new String(msgBytes, "UTF-8");
			}
			return message;
		} catch (Exception e) {
			logger.warn("ServletRequestApplicationListener.getExceptionMessage exception: {}", e);
			return throwable.getClass().getSimpleName();
		}
	}
}
