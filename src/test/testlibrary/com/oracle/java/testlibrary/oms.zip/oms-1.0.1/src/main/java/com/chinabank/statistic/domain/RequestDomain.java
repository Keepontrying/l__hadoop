package com.chinabank.statistic.domain;
import javax.persistence.*;
import java.util.Date;

/**
 * 统计domain
 *
 * @author: dongzhihua
 * @time: 2018/5/17 18:32:53
 */
//@Document(collection = "oms_request")
@Entity(name = "oms_request")
public class RequestDomain {

	@Id
    @Column(name = "req_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long reqId; // 主键
    @Column
	private String uri; // 请求地址
    @Column
	private String reqType; // 请求类型（区分http client的请求还是浏览器的请求）
    @Column
	private Date responseTime; // 请求时间
    @Column
	private String userName; // 用户名
    @Column
	private long processingTimeMillis; // 响应时长-毫秒
    @Column
	private String exceptionMessage; // 如果有异常，异常message
    @Column
	private String clientAddress;
    @Column
    private String serverAddress;

	public Long getReqId() {
		return reqId;
	}

	public void setReqId(Long reqId) {
		this.reqId = reqId;
	}

	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public Date getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(Date responseTime) {
		this.responseTime = responseTime;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getExceptionMessage() {
		return exceptionMessage;
	}

	public long getProcessingTimeMillis() {
		return processingTimeMillis;
	}

	public void setProcessingTimeMillis(long processingTimeMillis) {
		this.processingTimeMillis = processingTimeMillis;
	}

	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	public String getClientAddress() {
		return clientAddress;
	}

	public void setClientAddress(String clientAddress) {
		this.clientAddress = clientAddress;
	}

    public String getServerAddress() {
        return serverAddress;
    }

    public void setServerAddress(String serverAddress) {
        this.serverAddress = serverAddress;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("{");
        sb.append("\"reqId\":")
                .append(reqId);
        sb.append(",\"uri\":\"")
                .append(uri).append('\"');
        sb.append(",\"reqType\":\"")
                .append(reqType).append('\"');
        sb.append(",\"responseTime\":\"")
                .append(responseTime).append('\"');
        sb.append(",\"userName\":\"")
                .append(userName).append('\"');
        sb.append(",\"processingTimeMillis\":")
                .append(processingTimeMillis);
        sb.append(",\"exceptionMessage\":\"")
                .append(exceptionMessage).append('\"');
        sb.append(",\"clientAddress\":\"")
                .append(clientAddress).append('\"');
        sb.append(",\"serverAddress\":\"")
                .append(serverAddress).append('\"');
        sb.append('}');
        return sb.toString();
    }
}
