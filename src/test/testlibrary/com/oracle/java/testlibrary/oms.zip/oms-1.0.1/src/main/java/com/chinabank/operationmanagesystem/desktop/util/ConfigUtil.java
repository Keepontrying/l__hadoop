/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-2-18</li>
 * <li>3、开发时间：下午4:41:10</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.util</li>
 * <li>6、文件名称：ConfigUtil.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.util;

import java.util.Properties;

import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;


/**
 * <ul>
 * <li>1、开发日期：2014-2-18</li>
 * <li>2、开发时间：下午4:41:10</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：ConfigUtil</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class ConfigUtil {
	private static Logger logger = LoggerFactory.getLogger(ConfigUtil.class);
	private static Properties props;
	
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-2-18</li>
	 * <li>2、开发时间：下午4:41:10</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public ConfigUtil() {
		// TODO Auto-generated constructor stub
	}

	protected static void setProps(Properties props) {
		ConfigUtil.props = props;
	}

	public static String getString(String key) {
		if(null != props) {
			return props.getProperty(key);
		} else {
			logger.error("ConfigUtil为null，请确认是否载入");
			return null;
		}
	}
	
	public static int getInt(String key) {
		return Integer.parseInt(ConfigUtil.getString(key));
	}
	
	public static long getLong(String key) {
		return Long.parseLong(ConfigUtil.getString(key));
	}
	
	public static short getShort(String key) {
		return Short.parseShort(ConfigUtil.getString(key));
	}
	
	public static double getDouble(String key) {
		return Double.parseDouble(ConfigUtil.getString(key));
	}
	
	public static float getFloat(String key) {
		return Float.parseFloat(ConfigUtil.getString(key));
	}
	
	public static boolean getBoolean(String key) {
		return Boolean.parseBoolean(ConfigUtil.getString(key));
	}
	/**  
	 * Title: ConfigUtil.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */

}
