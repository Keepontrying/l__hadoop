package com.chinabank.operationmanagesystem.filter;

import com.wangyin.ssoclient.sso.filter.AuthorityFilter;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.annotation.WebFilter;

/**
 * 自定义权限过滤器
 *
 * @author: dongzhihua
 * @time: 2018/6/28 14:40:28
 */
//@Component
//@Order(30)
public class CustomerAuthorityFilter extends AuthorityFilter {
}
