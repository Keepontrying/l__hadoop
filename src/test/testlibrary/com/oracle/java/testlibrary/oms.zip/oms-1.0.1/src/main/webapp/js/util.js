/*util.js只用于提供工具方法，这次方法里不包含任何业务逻辑*/

/**
 * @version 0.0.1
 * @namespace Namespace
 * @author:sunmm
 * @description 创建䶿¸ª命名空间,命名空间的父子关系使用半角点卿."隔开
 * @param {} namespacePath String 例："a.b.c"
 * @example <br/><br/>
 * 	Namespace.create("a.b.c");
 * 	a.b.c.num = 12;
 * 	a.b.c.str = "12";
 * 	a.b.c.Fun = function(){
 * 					alert("dd");
 * 				}
 * a.b.c.Obj = {a:"",c:""};
 * .....
 * @return {void}
 */
var Namespace = {};
Namespace.create =function(namespacePath){
	//以indow为根
	var rootObject =window;
	//对命名空间路径拆分成数组
	var namespaceParts =namespacePath.split('.');
	for (var i =0;i <namespaceParts.length;i++) {
	   var currentPart =namespaceParts[i];
	   //如果当前命名空间下不存在，则新建䶿¸ªObject对象，等效于䶿¸ª关联数组⾿
	   if (!rootObject[currentPart]){
	      rootObject[currentPart]={};
	   }
	   rootObject =rootObject[currentPart];
	}
}; 

Namespace.create("newTenants.ui");  //以下是实现UI效果的方汿

newTenants.ui = {    

	menuList : function(onedom,onedomli,twodom) {
				$(onedom).find(twodom).addClass("subnav").css("display","none"); 
				$(onedomli).hover(
					function(){
						$(this).addClass("hover");
						$(this).find(twodom).show('50');
					},
					function(){
						$(this).find(twodom).hide('10');
						$(this).removeClass("hover");
				});
	}, //menulist下拉二级菜单实现 如：menuList("ul.navmenu","ul>li","ul")
	
	switchTab : function (dot,block) {
					$(block).css("display","none"); 
					$(dot).first().addClass("on");
					$(block).first().css("display","block").addClass("current-panes");  
					$(dot).click(function() {
						var num = $(this).index();
						$(this).addClass("on");
						$(this).siblings().removeClass("on");
						$(block+':eq('+num+')').css("display","block").addClass("current-panes");
						$(block+':eq('+num+')').siblings(block).css("display","none").removeClass("current-panes");
				});
	}, //tabs切换效果实现 如：switchTab("ul.tabslist li",".tabsdiv")

	showOrHide : function (clickdom,showblock,jiantouUp,jiantouDowm,textb,textp) {
					$(clickdom).click(function(){
						if($(showblock).css("display") != "none"){
							$(showblock).hide();
							if(jiantouDowm){ 
								$(clickdom).find("i").removeClass(jiantouDowm).addClass(jiantouUp);
							}
							if(textb){
								$(clickdom).find("."+textb).show();
								$(clickdom).find("."+textp).hide();
							}
							
						}else{
							$(showblock).show();
							if(jiantouUp){
								$(clickdom).find("i").removeClass(jiantouUp).addClass(jiantouDowm);
							}
							if(textp){
								$(clickdom).find("."+textp).show();
								$(clickdom).find("."+textb).hide();
							}
						}
					});
	},//如：showOrHide(".ui-show-detail",".ui-order-detail-info","icon-ddxqp","icon-ddxqp")//后两个参数可缺省

	switchSelected : function (parentDot, crrentdot) {
					$(parentDot).each(function(){
						$(this).find(crrentdot).first().addClass("on"); 
						$(this).find(crrentdot).click(function() { 
							$(this).addClass("on");
							$(this).siblings().removeClass("on"); 
						}); 
					}); 
	}, //鼠标点击选中效果 switchSelected("ul","li")

	hoverSelected : function (parentDot, crrentdot) {
					$(parentDot).each(function(){
						$(this).find(crrentdot).hover(function() { 
							$(this).addClass("hover"); 
						},function () {
							$(this).removeClass("hover");
						}); 
					}); 
	}, //鼠标经过选中效果 hoverSelected("ul","li") 


	inputBlur : function (inputDom) { 
					$(inputDom).each(function(){
						var passwId; 
						var that = $(this);
						getclear = setInterval(function(){ 
							if(that.val()){
								that.css({"color":"#555","background-position":"-999px 0","z-index":"1"});
								clearInterval(getclear);
							}
						},10);
						
						$(this).focus(function(){   
							clearInterval(getclear);
							if($(this).val()==""){ 
								$(this).css({"color":"#555","background-position":"-999px 0","z-index":"1"});
								if($(this).hasClass("username-input") && $(this).val()==""){  
									var thiser = $(this);
									passwId = setInterval(function(){ 
										if(thiser.siblings("input.password-input").val() &&   thiser.siblings("input.password-input").css("z-index")!="1"){ 
											$(".password-input").css({"color":"#555","background-position":"-999px 0","z-index":"1"});
											clearInterval(passwId);
										}
									},100);
								}
							}   
						});  

						$(this).keyup(function(){ 
							clearInterval(passwId);
							if($(this).hasClass("username-input") && $(this).val()==""){  
									var thiser = $(this);
									passwId = setInterval(function(){ 
										if(thiser.siblings("input.password-input").val() && thiser.siblings("input.password-input").css("z-index")!="1"){ 
											$(".password-input").css({"color":"#555","background-position":"-999px 0","z-index":"1"});
											clearInterval(passwId);
										}
									},100);
								}  
							if($(this).hasClass("username-input") && $(".password-input").val()){
								setTimeout(function(){
									$(".password-input").trigger("blur"); 
								},100)
							}
							
						}); 
						
						$(this).blur(function(){  
							clearInterval(getclear);
							clearInterval(passwId);
							if($(this).val()==""){	 
								if($(this).hasClass("username-input")){
									this.style.backgroundPosition = "0 -68px";
								}
								if($(this).hasClass("password-input")){
									this.style.backgroundPosition = "0 0";
								}
								if($(this).hasClass("usernum-input")){
									this.style.backgroundPosition = "0 -34px";
								}
								if($(this).hasClass("verify-input")){
									this.style.backgroundPosition = "0 -102px";
								}
								
								this.style.zIndex = "0";
							}  
						}); 


					}); 
					
	}, //input输入框点击value清除 

	hoverEvent : function(obj,className,nclassName) {
					$(obj).hover(function() {
						$(this).addClass(nclassName).removeClass(className);
					},
					function() {
						$(this).removeClass(nclassName).addClass(className);
	                });
    },  //鼠标滑入滑出classname变换 如：hoverEvent(".get-btn","get-btn","get-btn-on")

	tableTrBg : function(tabledom,trbgcolor,strlen) {    
					$(tabledom).each(function(){
						$(this).not($(".tstyle")).find("tr:odd").find("td").css("background",trbgcolor); 
						$(this).find("td").each(function(){ 
							if(parseInt($(this).text().length)> strlen){
								$(this).wrapInner("<div style='width:200px; display:inline-block; overflow:hidden; word-wrap:break-word; word-break:break-all;'></div>");
							}
						});  
					});
	}, //tr隔行变换背景色，对长字符串换行夐玿如：tableTrBg("table.recharge-list","#fafbfd",100)

	getSubstr : function(dom, str_len){
			$(dom).each(function(){ 
				var totleStr=$.trim($(this).text());   
				var byteLen = 0, len = totleStr.length;
				if(len > 0){
					for(var i=0; i<len; i++ ){
						if(totleStr.charCodeAt(i) > 255){
							byteLen += 2;
						}else{
							byteLen++;
						}   
						if(byteLen > str_len){ 
							var getString = totleStr.substr(0,i); 
							$(this).attr("title",totleStr); 
							$(this).text(getString + "...");
							return;
						}
					} 
				}
				return;
			});
	}, //td中的文本长度截取，妀getSubstr("td.andson", 14);

	pageWidth : function() {
		var pageWidth = window.innerWidth; 
		var pageHeight = window.innerHeight; 
		if(typeof pageWidth != "number"){
			if(document.compatMode == "CSS1Compat"){
				pageWidth = document.documentElement.clientWidth;  
			}else{
				pageWidth = document.body.clientWidth; 
			}
		} 
		return pageWidth; 
	}, //获取窗口宽度 
	
	pageHeight : function() {
		var pageWidth = window.innerWidth; 
		var pageHeight = window.innerHeight; 
		if(typeof pageWidth != "number"){
			if(document.compatMode == "CSS1Compat"){
				pageHeight = document.documentElement.clientHeight; 
			}else{
				pageHeight = document.body.clientHeight;
			}
		}
		return pageHeight; 
	}, //获取窗口高度
	
	getElementsByClassName : function(className) {
		var all = document.all ? document.all : document.getElementsByTagName('*');
		var elements = new Array();
		for (var e = 0; e < all.length; e++) {
			if (all[e].className == className) {
				elements[elements.length] = all[e]; 
			}
		}
		if(elements.length==0){
			return false;
		}else{
			return elements;
		} 
	},

	tabsScroll : function (tabsNum){
		if($(".div-panes-list li").length > tabsNum){
			$(".div-panes-list li").each(function(){ 
					var sign=0;
					var temp=0;
					$(this).click(function(){   
						if($(this).position().top >= 120 && $(this).next().length != 0 && sign==temp){ 
							sign++;
							$(this).parent().children().first().animate({"margin-top" : '-=31px'}, "normal", function(){ 
								temp++;
							}); 
						}else if($(this).position().top < 5 && $(this).prev().length != 0 && sign==temp){ 
							sign++;
							$(this).parent().children().first().animate({"margin-top" : '+=31px'}, "normal", function(){ 
								temp++;
							}); 
						}
					});
				 
			});
		}
	}//实现tabs的点击滚动效朿如：myMas.ui.tabsScroll(5);
 
};


//自定义jquery的扩展方汿
$.fn.noSelect = function(p) {
    if (p == null){
        prevent = true;
	}else{
        prevent = p;
	}
    if (prevent) {
        return this.each(function() {
            if ($.browser.msie || $.browser.safari) $(this).bind('selectstart', function() { return false; });
            else if ($.browser.mozilla) {
                $(this).css('MozUserSelect', 'none');
                $('body').trigger('focus');
            }
            else if ($.browser.opera) $(this).bind('mousedown', function() { return false; });
            else $(this).attr('unselectable', 'on');
        });
 
    } else {
        return this.each(function() {
            if ($.browser.msie || $.browser.safari) $(this).unbind('selectstart');
            else if ($.browser.mozilla) $(this).css('MozUserSelect', 'inherit');
            else if ($.browser.opera) $(this).unbind('mousedown');
            else $(this).removeAttr('unselectable', 'on');
        });
 
    }
}//实现文字不能被耤¸­效果，如：$(".ui-show-detail").noSelect();



$(function(){   
	//newTenants.ui.switchTab("ul.ui-setting-tabs li",".ui-div-panes");//tabs切换效果
	$("table.ui-record-table").find("tr:even").addClass("split");//td隔行显示不同底色
	newTenants.ui.inputBlur("input.user-input");
	//处理ie6透明
	if($.browser.version == "6.0"){
		DD_belatedPNG.fix(".icon, .on, .txt, background");
	}
	//二级菜单左边距设嬿
	$("ul.tablist").find("li:contains('账户查询')").css("margin-left","130px");
	$("ul.tablist").find("li:contains('修改密码')").css("margin-left","257px");
	$("ul.tablist").find("li:contains('产品商店')").css("margin-left","388px");
	//footer根据页面内容，自动添加高帿
	var footerHeight = $(window).height()-($("header").height()+$("nav.iconrept").height()+$(".main").height()+41);
	if(footerHeight > 120){
		$("footer").css("height",footerHeight);
	}
	$(".btn").noSelect();

	$("select.ui-forms-select[disabled='disabled']").css("background","#f4f4f4");
	$(".ui-fm-item").find("input.inputbg[disabled='disabled']").css("background","#f4f4f4");
	


	
	
});