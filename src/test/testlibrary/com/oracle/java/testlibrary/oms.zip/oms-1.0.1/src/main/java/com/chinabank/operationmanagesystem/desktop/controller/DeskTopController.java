package com.chinabank.operationmanagesystem.desktop.controller;

import com.chinabank.operationmanagesystem.book.bean.BookFileDTO;
import com.chinabank.operationmanagesystem.book.bean.BookResult;
import com.chinabank.operationmanagesystem.book.bean.Request;
import com.chinabank.operationmanagesystem.book.bean.Response;
import com.chinabank.operationmanagesystem.core.bean.Parameters;
import com.chinabank.operationmanagesystem.core.bean.UploadFile;
import com.chinabank.operationmanagesystem.core.bean.view.View;
import com.chinabank.operationmanagesystem.core.util.JSONParseUtil2;
import com.chinabank.operationmanagesystem.core.util.ViewUtil;
import com.chinabank.operationmanagesystem.desktop.bean.Sign;
import com.chinabank.operationmanagesystem.desktop.bean.UploadObject;
import com.chinabank.operationmanagesystem.desktop.util.*;
import com.chinabank.operationmanagesystem.utils.SsoUtils;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.hsp.client.HSPClient;
import com.wangyin.hsp.client.model.result.SaveResult;
import com.wangyin.operation.beans.BookResponse;
import com.wangyin.operation.common.beans.HspFileInfo;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.enums.FileStatusEnum;
import com.wangyin.operation.utils.ExportExcelUtil;
import com.wangyin.operation.utils.GsonUtil;
import com.wangyin.operation.utils.MD5Util;
import com.wangyin.ssoclient.sso.model.Configuration;
import com.wangyin.ssoclient.sso.model.User;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.net.util.Base64;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.RequestContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URLEncoder;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Controller
public class DeskTopController {
	private static final Logger logger = LoggerFactory.getLogger(DeskTopController.class);
	@javax.annotation.Resource(name="localDownload")
	WebFileUtil downloadUtil;

	@Autowired
	private HSPClient hspClient;

	private static String forward_home_view = "forward:operationmanagesystem/desktop/main.view";

	@RequestMapping("/")
	public String index() {
		return forward_home_view;
	}


	@RequestMapping("logout")
	public void logout(HttpServletRequest request, HttpServletResponse response) {
		SsoUtils.logout(request, response);
	}

	@RequestMapping("logoutInvoke")
	public void logoutInvoke(HttpServletRequest request, HttpServletResponse response) {
		SsoUtils.logoutInvoke(request, response);
	}

	@RequestMapping("errorMessage")
	public String errorMessage() {
		return "error";
	}

	@RequestMapping("/http/{project}/{module}/{action}.view")
	public ModelAndView doHttpPost(@PathVariable("project")String project,@PathVariable("module")String module,@PathVariable("action")String action,@RequestParam Map<String,Object> params,HttpServletRequest request) {
		String uniqueID = UniqueID.randomUID();
		User user = (User) request.getSession().getAttribute(Configuration.userSession);
		String ip = getRealIp(request);
		logger.info("ID="+ uniqueID +","+ (user == null?"":user.getUsername()) + "("+ip+")" +"发起View请求：/http/"+project+"/"+module+"/"+action+".view");
		if(null != user) {
			params.put("user", JSONObject.fromObject(user).toString());
		}
		return httpView(project,module,action,params,request,uniqueID);
	}

	/**
	 * 源于view，不同在于轻量化user对象
	 * @param project
	 * @param module
	 * @param action
	 * @param params
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/http/{project}/{module}/{action}.show")
	public ModelAndView doHtml(@PathVariable("project")String project,@PathVariable("module")String module,@PathVariable("action")String action,@RequestParam Map<String,Object> params,HttpServletRequest request,HttpServletResponse response) {
		User user = getSimpleUserInfo(request);
		String ip = getRealIp(request);
		logger.info(String.format("(ip:%s)发起show请求：/http/%s/%s/%s.show", ip, project, module, action));
		logger.info("user: " + JSONObject.fromObject(user));
		if(null != user) {
			params.put("user", JSONObject.fromObject(user).toString());
		}
		return httpView(project,module,action,params,request,Thread.currentThread().getId() + "");
	}

	User getSimpleUserInfo(HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute(Configuration.userSession);
		User simpleUser = new User();
		BeanUtils.copyProperties(user, simpleUser, new String[]{"treeJson"});
		return simpleUser;
	}

	/**
	 * 方法含义：获取真实IP地址
	 * 方法说明：先从nginx中获取X-Real-IP，如果取不到或非nginx反向代理，则直接取RemoteAddr
	 * @param request
	 * @return
	 */
	private String getRealIp(HttpServletRequest request) {
		String ip = request.getHeader("X-Real-IP");
		if(StringUtils.isEmpty(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip;
	}

	@RequestMapping(value="/http/{project}/{module}/{action}.biz")
	public void doHttpAjax(@PathVariable("project")String project,@PathVariable("module")String module,@PathVariable("action")String action,@RequestParam Map<String,Object> params,HttpServletRequest request,HttpServletResponse response) {
		String uniqueID = UniqueID.randomUID();
		User user = (User) request.getSession().getAttribute(Configuration.userSession);
		String ip = getRealIp(request);
		logger.info("ID="+ uniqueID +","+ (user == null?"":user.getUsername()) + "("+ip+")" +"发起Biz请求：/http/"+project+"/"+module+"/"+action+".biz");
		if(null != user) {
			params.put("user", JSONObject.fromObject(user).toString());
		}
		String json = httpBiz(project,module,action,params,uniqueID,request);
		writeJson(json, response);
	}

	/**
	 * 返回数据
	 * @param json
	 * @param response
	 */
	void writeJson(String json, HttpServletResponse response) {
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=UTF-8");
		try {
			response.getWriter().write(json);
		} catch (IOException e) {
			logger.error(e);
		}
	}

	/**
	 * 源于biz，不同在于轻量化user对象
	 * @param project
	 * @param module
	 * @param action
	 * @param params
	 * @param request
	 * @param response
	 */
	@RequestMapping(value="/http/{project}/{module}/{action}.data")
	@ResponseBody
	public Object doData(@PathVariable("project")String project,@PathVariable("module")String module,@PathVariable("action")String action,@RequestParam Map<String,Object> params,HttpServletRequest request,HttpServletResponse response) {
		String ip = getRealIp(request);
		User user = getSimpleUserInfo(request);
		logger.info(String.format("(ip:%s)data：/http/%s/%s/%s.data", ip, project, module, action));
		logger.info("user: " + JSONObject.fromObject(user));
		if(null != user) {
			params.put("user", JSONObject.fromObject(user).toString());
		}
		String json = httpBiz(project,module,action,params, Thread.currentThread().getId() + "",request);
		return GsonUtil.getInstance().fromJson(json, Map.class);
	}

	@RequestMapping("/http/{project}/{module}/{action}.upload")
	@ResponseBody
	public String doHttpUpload(@PathVariable("project")String project,@PathVariable("module")String module,@PathVariable("action")String action,HttpServletResponse response,HttpServletRequest request) {
		String uniqueID = UniqueID.randomUID();
		User user = (User) request.getSession().getAttribute(Configuration.userSession);
		String ip = getRealIp(request);
		logger.info("ID="+ uniqueID +","+ (user == null?"":user.getUsername()) + "("+ip+")" +"发起Upload请求：/http/"+project+"/"+module+"/"+action+".upload");
		Map<String,Object> params = new HashMap<String,Object>();
		MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest)request;
		UploadObject uploadObject = this.getUploadFiles(multiRequest);
		params.put("uploadObject", GsonUtil.getInstance().toJson(uploadObject));
		if(null != user) {
			params.put("user", JSONObject.fromObject(user).toString());
		}
		return httpUpload(project, module, action, multiRequest, params, uniqueID, uploadObject);
	}

	/**
	 *
	 * @param project
	 * @param module
	 * @param action
	 */
	@RequestMapping("/http/{project}/{module}/{action}.up2dir")
	@ResponseBody
	public ResponseData<Object> doHttpUploadToDirectory(@PathVariable("project")String project, @PathVariable("module")String module, @PathVariable("action")String action,
										  @RequestParam(required = false) Map<String, String> params,
										  HttpServletRequest request, UploadFile uploadFile) throws IOException {

		ResponseData<Object> response = new ResponseData<Object>();

		StringBuilder fileDir = new StringBuilder(ConfigUtil.getString("sys.upload20.temp"));
		fileDir.append(project);
		fileDir.append("/").append(module);
		if(StringUtils.isNotEmpty(uploadFile.getPath())) {
			fileDir.append("/").append(uploadFile.getPath()).append("/");
		}
		File dir = new File(fileDir.toString());
		if(!dir.exists()) {
			dir.mkdirs();
		}

		MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest)request;
		//获取multiRequest 中所有的文件名
		Iterator<String> inter=multiRequest.getFileNames();
		List<String> uploadFilePath = new ArrayList<String>();
		while(inter.hasNext()) {
			//一次遍历所有文件
			String nextFileName = inter.next().toString();
			MultipartFile file = multiRequest.getFile(nextFileName);

			if(file != null && StringUtils.isNotEmpty(file.getOriginalFilename())) {
				String fix = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf('.'));
				File localFile = new File(fileDir.toString(), file.getName() + fix);
				if(!localFile.exists()) {
					localFile.createNewFile();
				}

				//上传
				file.transferTo(localFile);
//				uploadFilePath.add(FtpUtil.formatPath(localFile.getCanonicalPath()));
				String pathStr = localFile.getAbsolutePath();
				uploadFilePath.add(pathStr);
			}
		}

		String urlCallback = ReadProperties.read(action+"_url", "/http/"+project+"/"+module+".properties");

		try {
			if(StringUtils.isNotEmpty(urlCallback)) {
                if(uploadFilePath.size() == 1) {
                	params.put("file", uploadFilePath.get(0));
				} else {
                	StringBuilder files = new StringBuilder();
					for (String s : uploadFilePath) {
						files.append(',').append(s);
					}
					params.put("files", files.substring(1).toString());
				}
				logger.info("callbackUrl:", urlCallback);
				logger.info("callbackParam:", params);

				String result = HttpUtils.doPost(urlCallback, params);
				logger.debug(result);
                return GsonUtil.getInstance().fromJson(result, ResponseData.class);
            }
		} catch (Exception e) {
			logger.warn("请求连接出现问题：" + urlCallback, e);
			response.setCodeMessage("9999", "请求连接出现问题：" + urlCallback);
		}
		return response;
	}

	@RequestMapping("/http/{project}/{module}/{action}.hspupload")
	@ResponseBody
	public Object doHspHttpUpload(@PathVariable("project")String project,@PathVariable("module")String module,
			@PathVariable("action")String action, HttpServletRequest request,
			HspFileInfo hspFileInfo) {
		String uniqueID = UniqueID.randomUID();
		User user = (User) request.getSession().getAttribute(Configuration.userSession);
		String ip = getRealIp(request);
		logger.info("ID="+ uniqueID +","+ (user == null?"":user.getUsername()) + "("+ip+")" +"发起Upload请求：/http/"+project+"/"+module+"/"+action+".upload");
		MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest)request;

		// url有效分钟
		int urlValidMinutes = ReadProperties.readIntIfExist(30, "/http/"+project+"/"+module+".properties", action+"_urlValidMinutes", "urlValidMinutes");

		if(hspFileInfo.getUrlValidMinutes() == null) {
			hspFileInfo.setUrlValidMinutes(urlValidMinutes);
		}
		return hspHttpUpload(project, module, action, multiRequest, uniqueID, hspFileInfo);
	}

	/**
	 * hsp下载
	 * @author dongzhihua
	 * @time 2017年11月7日 上午8:54:30
	 * @param project
	 * @param module
	 * @param action
	 * @param hspFileInfo
	 * @param request
	 * @return ResponseData<HspFileInfo>
	 */
	@RequestMapping("/http/{project}/{module}/{action}.hspdownload")
	@ResponseBody
	public ResponseData<HspFileInfo> getUrlByFid(@PathVariable("project")String project,@PathVariable("module")String module,
			@PathVariable("action")String action,
			HspFileInfo hspFileInfo,
			HttpServletRequest request) {
		String ip = getRealIp(request);
		String uniqueID = UniqueID.randomUID();
		User user = (User) request.getSession().getAttribute(Configuration.userSession);
		logger.info("ID="+ uniqueID +","+ (user == null?"":user.getUsername()) + "("+ip+")" +"发起Upload请求：/http/"+project+"/"+module+"/"+action+".upload");

		ResponseData<HspFileInfo> responseData  = new ResponseData<HspFileInfo>();
		if(StringUtils.isEmpty(hspFileInfo.getFid())) {
			return responseData.setCodeMessage(ResponseMessage.PARAM_IS_REQUIRED.name(), "fid不能为空！");
		}
		// url有效分钟
		int urlValidMinutes = ReadProperties.readIntIfExist(30, "/http/"+project+"/"+module+".properties", action+"_urlValidMinutes", "urlValidMinutes");

		if(hspFileInfo.getUrlValidMinutes() == null) {
			hspFileInfo.setUrlValidMinutes(urlValidMinutes);
		}
		if(StringUtils.isEmpty(hspFileInfo.getFileName())) {
			hspFileInfo.setFileName("file");
		}
		String url = hspClient.getUrl(hspFileInfo.getFid(), hspFileInfo.getUrlValidMinutes(), hspFileInfo.getFileName());
		hspFileInfo.setUrl(url);
		responseData.setData(hspFileInfo);
		return responseData;
	}

	@RequestMapping("/http/{project}/{module}/{action}.download")
	public void doHttpDownload(@PathVariable("project")String project,@PathVariable("module")String module,@PathVariable("action")String action,@RequestParam Map<String,Object> params,HttpServletResponse response,HttpServletRequest request) throws UnsupportedEncodingException {
		String uniqueID = UniqueID.randomUID();
		User user = (User) request.getSession().getAttribute(Configuration.userSession);
		String ip = getRealIp(request);
		logger.info("ID="+ uniqueID +","+ (user == null?"":user.getUsername()) + "("+ip+")" +"发起Download请求：/http/"+project+"/"+module+"/"+action+".download");
		if(null != user) {
			params.put("user", JSONObject.fromObject(user).toString());
		}
		UploadFile uploadfile;
		project = getRealProject(project, request);
		String urlDownload = ReadProperties.read(action+"_download", "/http/"+project+"/"+module+".properties");
		logger.info("ID="+ uniqueID +","+"url："+urlDownload);
		Sign sign = new Sign(project,module,action,params);
		params.put("appCode", sign.getAppCode());
		params.put("sign", sign.getSign());
		String jsonUpload = HttpUtils.doPost(urlDownload, params);
		JSONObject jsonObject = JSONObject.fromObject(jsonUpload);
		uploadfile = (UploadFile)JSONObject.toBean(jsonObject, UploadFile.class);
		if(logger.isDebugEnabled()) {
			logger.debug("ID="+ uniqueID +","+"调用上传结束，返回Map内容:"+jsonUpload);
		}
		httpDownload(uploadfile, request, response, uniqueID);
	}

	static TypeToken<Page<Map<String, String>>> pageToken = new TypeToken<Page<Map<String, String>>>(){};
	static TypeToken<String[][]> titleFieldToken = new TypeToken<String[][]>(){};

	/**
	 * 请求[.expxlsx]结尾，配置文件中存在['action'_fieldsTitle_expxlsx]，例如：[['姓名','年龄'],['name','age']]
	 * @author dongzhihua
	 * @time 2017年11月8日 下午4:28:29
	 * @param project
	 * @param module
	 * @param action
	 * @param params
	 * @param response
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 * ResponseData<String>
	 */
	@RequestMapping("/http/{project}/{module}/{action}.expxlsx")
	@ResponseBody
	public com.wangyin.operation.common.beans.Response doHttpExpxlsx(@PathVariable("project") String project,
			@PathVariable("module") String module,
			@PathVariable("action") String action,
			@RequestParam Map<String, Object> params,
			HttpServletResponse response, HttpServletRequest request){
		ResponseData<String> responseData = new ResponseData<String>();
		try {
			String uniqueID = UniqueID.randomUID();
			User user = (User) request.getSession().getAttribute(
					Configuration.userSession);
			String ip = getRealIp(request);
			logger.info("ID=" + uniqueID + ","
					+ (user == null ? "" : user.getUsername()) + "(" + ip + ")"
					+ "发起export请求：/http/" + project + "/" + module + "/"
					+ action + ".expxlsx");
			if (null != user) {
				params.put("user", JSONObject.fromObject(user).toString());
			}
			project = getRealProject(project, request);
			String urlDownload = ReadProperties.read(action + "_expxlsx",
					"/http/" + project + "/" + module + ".properties");
			if (StringUtils.isEmpty(urlDownload)) {
				return new com.wangyin.operation.common.beans.Response("400",
						"http中url未配置");
			}
			logger.info("ID=" + uniqueID + "," + "url：" + urlDownload);
			Sign sign = new Sign(project, module, action, params);
			params.put("appCode", sign.getAppCode());
			params.put("sign", sign.getSign());
			String responseStr = HttpUtils.doPost(urlDownload, params);
			Page<Map<String, String>> pageData = GsonUtil
					.getInstanceWithLongDateFormat().fromJson(responseStr,
							pageToken.getType());
			if (pageData == null) {
				return responseData.setCodeMessage("400", "服务端返回空");
			}
			if (pageData.isNotSuccess()) {
				return responseData.setResponse(pageData);
			}
			if (pageData.getTotal() == 0
					|| CollectionUtils.isEmpty(pageData.getRows())) {
				return responseData.setCodeMessage(
						ResponseMessage.NOT_EXIST.name(), "查询结果为空");
			}
			if (pageData.getRows().size() > 2000) {
				return responseData.setCodeMessage("syslimit", "导出数据不能超过2000");
			}
			// 获取表格title和字段名定义数组
			String fieldsTileProp = ReadProperties.read(action
					+ "_fieldsTitle_expxlsx", "/http/" + project + "/" + module
					+ ".properties");
			String[][] fieldsTile = GsonUtil.getInstance().fromJson(
					fieldsTileProp, titleFieldToken.getType());

			String path = MessageFormat.format("{0}/{1}/{2}{3}.xlsx",
                    project, module, uniqueID, user.getUsername());
			String abstractPathName = ConfigUtil.getString("sys.upload20.temp") + path;
			ExportExcelUtil.exportExcelToXlsx(abstractPathName, pageData.getRows(), fieldsTile);
			UploadFile uploadfile = new UploadFile();
			uploadfile.setPathname(path);
			uploadfile.setTemp(true);
			uploadfile.setVersion("2.0");
			httpDownload(uploadfile, request, response, uniqueID);
		} catch (Exception e) {
			logger.error("导出xlsx异常", e);
			responseData.setCodeMessage("syserror", e.getMessage());
		}
		return responseData;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2015-9-23</li>
	 * <li>2、开发时间：下午3:41:35</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：String</li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * @param project
	 * @param request
	 * @return
	 */
	private String getRealProject(String project, HttpServletRequest request) {
		String branch = (String) request.getSession().getAttribute("branch");
		if(StringUtils.isNotBlank(branch)) {
			project += "_"+branch;
		}
		return project;
	}


	/**
	 * <ul>
	 * <li>1、开发日期：2014-2-20</li>
	 * <li>2、开发时间：上午11:20:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：void</li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * @param response
	 * @param uniqueID
	 * @throws UnsupportedEncodingException
	 */
	public void httpDownload(UploadFile uploadfile, HttpServletRequest request, HttpServletResponse response,
			String uniqueID) throws UnsupportedEncodingException {
		if(null != uploadfile && uploadfile.getName() != null && uploadfile.getPath() != null) {
			String filename = uploadfile.getName();
			String downloadName = uploadfile.getOriginalName();
			if(null == downloadName || downloadName.equals("")) {
				downloadName = filename;
			}
			String filetype = getFileType(filename);
			response.setContentType(filetype);
			response.setHeader("Content-Disposition", "attachment;filename="+ this.getFileHeader(downloadName, request.getHeader("User-Agent")));
			if(logger.isDebugEnabled()) {
				logger.debug("ID="+ uniqueID +","+"调用下载方法结束，返回UploadFile内容:"+uploadfile.toString()+",自动获取文件类型为："+filetype);
			}
			boolean result = false;
			if(!ConfigUtil.getBoolean("sys.environment.local")) {//生产、测试环境
				result = downloadUtil.downloadByNginx(response, uploadfile, uniqueID);
			} else {//本地环境
				try {
					result = downloadUtil.download(response.getOutputStream(), uploadfile, uniqueID);
				} catch (IOException e) {
					logger.error("response输出流出错！",e.fillInStackTrace());
				}
			}
			if(!result) {
				logger.info("ID="+ uniqueID +","+"文件("+uploadfile.getRealPathname()+")下载失败！");
			} else {
				logger.info("ID="+ uniqueID +","+"文件("+uploadfile.getRealPathname()+")下载成功！");
			}
		} else {
			logger.error("ID="+ uniqueID +","+"调用下载方法结束，返回UploadFile为null，参数错误");
		}
	}
	
	
	@RequestMapping(value="/http/{project}/{module}/{action}.book")
	@ResponseBody
	public BookResult doBooking(@PathVariable("project")String project,@PathVariable("module")String module,@PathVariable("action")String action,@RequestParam Map<String,Object> params,HttpServletRequest request,HttpServletResponse response) {
		String uniqueID = UniqueID.randomUID();
		User user = (User) request.getSession().getAttribute(Configuration.userSession);
		String ip = getRealIp(request);
		logger.info("ID="+ uniqueID +","+ (user == null?"":user.getUsername()) + "("+ip+")" +"发起book请求：/http/"+project+"/"+module+"/"+action+".book");
		BookFileDTO queryBean = new BookFileDTO();
		Object objFileDir = params.get("fileDir");
		Object objFileName = params.get("fileName");
		if(null != objFileDir) {
			queryBean.setFileDir(String.valueOf(objFileDir));
		}
		if(null != objFileName) {
			queryBean.setFileName(String.valueOf(objFileName));
		}
		queryBean.setAppCode(project);
		queryBean.setOwner(module);
		BookResult bookResult = new BookResult();
		if(StringUtil.isBlank(queryBean.getFileDir()) || StringUtil.isBlank(queryBean.getFileName())) {
			bookResult.setSuccessful(false);
			bookResult.setMessage("文件目录或文件名不能为空！");
			return bookResult;
		}
		if(null != user) {
			params.put("user", JSONObject.fromObject(user).toString());
		}
		BookFileDTO queryFile;
		try {
			queryFile = this.queryBookFile(queryBean);
		} catch (Exception e) {
			logger.error("查询预约出现问题。",e);
			bookResult.setSuccessful(false);
			bookResult.setMessage("查询预约文件失败！");
			return bookResult;
		}
		if(null == queryFile) {
			//未预约过，进行预约
			buildBookFile(project, module, action, params, queryBean, uniqueID,
					bookResult,request);
		} else {
			boolean rebuild = Boolean.parseBoolean(String.valueOf(params.get("rebuild")));
			if(rebuild) {//如果是重新生成
				//重新生成预约文件
				rebuildBookFile(project, module, action, params, queryBean, uniqueID,
						bookResult,request);
			} else {
				bookResult.setExist(true);
				bookResult.setBookFile(queryFile);
				//把queryFile返回前台处理
			}
		}
		return bookResult;
	}

	/**
	 * 生成预约文件
	 */
	private void buildBookFile(String project, String module, String action,
			Map<String, Object> params, BookFileDTO queryBean, String uniqueID,
			BookResult bookResult,HttpServletRequest request) {
		bookResult.setExist(false);
		BookResponse bookResponse = httpBook(project,module,action,params,uniqueID, request);
		if(bookResponse.isSuccessful()) {
			boolean insert = this.insertBookFile(queryBean);
			if(insert) {
				bookResult.setBookSuccessful(true);
			} else {
				bookResult.setBookSuccessful(false);
				bookResult.setMessage("插入预约文件记录失败！");
			}
		} else {
			bookResult.setBookSuccessful(false);
			bookResult.setMessage(bookResponse.getMessage());
		}
	}
	
	/**
	 * 重新生成预约文件
	 */
	private void rebuildBookFile(String project, String module, String action,
			Map<String, Object> params, BookFileDTO queryBean, String uniqueID,
			BookResult bookResult,HttpServletRequest request) {
		bookResult.setExist(false);
		BookResponse bookResponse = httpBook(project,module,action,params,uniqueID, request);
		if(bookResponse.isSuccessful()) {
			boolean update = this.updateBookFile(queryBean);
			if(update) {
				bookResult.setBookSuccessful(true);
			} else {
				bookResult.setBookSuccessful(false);
				bookResult.setMessage("插入预约文件记录失败！");
			}
		} else {
			bookResult.setBookSuccessful(false);
			bookResult.setMessage(bookResponse.getMessage());
		}
	}
	
	public static BookFileDTO queryBookFile(BookFileDTO bookFileDTO) throws Exception {
		bookFileDTO.setStatus(FileStatusEnum.DONE);
		Gson gson = GsonUtil.getInstanceWithDateFormat();
		String param = gson.toJson(bookFileDTO);
		Request request = new Request();
		request.setAppCode("10000");
		request.setParam(param);
		request.setSign(MD5Util.MD5(request.getAppCode() + request.getParam() + ConfigUtil.getString("sys.book.key")));
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("req", gson.toJson(request));
		String result = HttpUtils.doPost(ConfigUtil.getString("sys.book.query"), params);
		Response<BookFileDTO> response = gson.fromJson(result, new TypeToken<Response<BookFileDTO>>(){}.getType());
		if(response.isSuccessful()) {
			return response.getData();
		} else {
			throw new Exception("查询预约文件出现问题！");
		}
	}
	
	private boolean insertBookFile(BookFileDTO bookFileDTO) {
		logger.info("插入预约文件！");
		Gson gson = GsonUtil.getInstanceWithDateFormat();
		String param = gson.toJson(bookFileDTO);
		Request request = new Request();
		request.setAppCode("10000");
		request.setParam(param);
		request.setSign(MD5Util.MD5(request.getAppCode() + request.getParam() + ConfigUtil.getString("sys.book.key")));
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("req", gson.toJson(request));
		String result = HttpUtils.doPost(ConfigUtil.getString("sys.book.insert"), params);
		Response<BookFileDTO> response = gson.fromJson(result, new TypeToken<Response<BookFileDTO>>(){}.getType());
		if(response.isSuccessful()) {
			return true;
		} else {
			logger.error("插入预约文件失败："+response.getMessage());
		}
		return false;
	}
	
	private boolean updateBookFile(BookFileDTO bookFileDTO) {
		//更新预约文件状态为处理中
		bookFileDTO.setStatus(FileStatusEnum.PROCESSING);
		logger.info("更新预约文件为处理中！");
		Gson gson = GsonUtil.getInstanceWithDateFormat();
		String param = gson.toJson(bookFileDTO);
		Request request = new Request();
		request.setAppCode("10000");
		request.setParam(param);
		request.setSign(MD5Util.MD5(request.getAppCode() + request.getParam() + ConfigUtil.getString("sys.book.key")));
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("req", gson.toJson(request));
		String result = HttpUtils.doPost(ConfigUtil.getString("sys.book.update"), params);
		Response<BookFileDTO> response = gson.fromJson(result, new TypeToken<Response<BookFileDTO>>(){}.getType());
		if(response.isSuccessful()) {
			return true;
		} else {
			logger.error("更新预约文件失败："+response.getMessage());
		}
		return false;
	}
	
	public BookResponse httpBook(String project,String module,String action,Map<String, Object> params,String uniqueID,HttpServletRequest request) {
		project = getRealProject(project, request);
		String url = ReadProperties.read(action+"_book", "/http/"+project+"/"+module+".properties");
		logger.info("ID="+ uniqueID +","+"Http远程请求地址"+url);
		Sign sign = new Sign(project,module,action,params);
		params.put("appCode", sign.getAppCode());
		params.put("sign", sign.getSign());
		params.put("_project", project);
		params.put("_module", module);
		String json = HttpUtils.doPost(url, params);
		BookResponse response = GsonUtil.getInstance().fromJson(json, BookResponse.class);
		logger.info("进行预约！");
		return response;
	}
	
	/**
	 * 页面跳转请求的controller，以.view结尾
	 * @PathVariable project 项目名称
	 * @PathVariable module	模块名称
	 * @PathVariable action	方法名称
	 * @RequestParam params	所接收到的参数
	 * @return ModelAndView 返回的界面由路径安装找取project/module/action
	 * @return model 返回的参数的map集合
	 * @throws Exception 
	 * @throws SecurityException 
	 */
	@RequestMapping("/{project}/{module}/{action}.view")
	public ModelAndView doPost(@PathVariable("project")String project,@PathVariable("module")String module,@PathVariable("action")String action,@RequestParam Map<String,String[]> params,HttpServletRequest request,HttpServletResponse response) {
		Parameters<String,Object> parameters = new Parameters<String,Object>();
		parameters.putAll(params);
		String uniqueID = UniqueID.randomUID();
		/*PropertyValues propertyValues = new ServletRequestParameterPropertyValues(request);*/
		User user = (User) request.getSession().getAttribute(Configuration.userSession);
		String ip = getRealIp(request);
		logger.info("ID="+ uniqueID +","+ (user == null?"":user.getUsername()) + "("+ip+")" +"发起View请求：/"+project+"/"+module+"/"+action+".view");
		Map<String,Object> model = new HashMap<>();
		ApplicationContext ac = RequestContextUtils.findWebApplicationContext(request);
		Class<?> demo = null;
		Object object = null;
		String view = null;
		String beanName=project+"_"+module;
		try {
			if (!ac.containsBean(beanName)){
				throw new NoSuchBeanDefinitionException(beanName,"ID="+ uniqueID +","+"容器中没有"+beanName+"的定义，检查是否注入，或者bean名称是否对应");
				/*createBean(project,module,ac,uniqueID);*/
			}
			Object obj = ac.getBean(beanName);
			if (null==obj){
				removeBean(beanName,ac,uniqueID);
			}else{
				demo = obj.getClass();
				Method[] methods = demo.getMethods();
				for(Method method : methods) {
					if(method.getName().equals(action.trim() + "View")) {
						Class<?>[] parameterTypes = method.getParameterTypes();
						Object[] objs = bindMethodParams(params, request, response, parameterTypes);//绑定数据
						object = method.invoke(obj, objs);
						if(object instanceof Map) {
							model = (Map<String, Object>) object;
						} else if(object instanceof com.chinabank.operationmanagesystem.core.bean.ModelAndView) {
							com.chinabank.operationmanagesystem.core.bean.ModelAndView mav = (com.chinabank.operationmanagesystem.core.bean.ModelAndView) object;
							model = (Map<String, Object>) mav.getMap();
							view = mav.getView();
						}
						logger.info("ID="+ uniqueID +","+"请求结束，返回页面："+"/pages/"+project+"/"+module+"/"+action+".ftl");
						if(null != model) {
							logger.info("ID="+ uniqueID +","+"返回Map大小:"+model.size());
							if(logger.isDebugEnabled()) {
								JSONArray jsonArray = JSONArray.fromObject( model );
								logger.debug("ID="+ uniqueID +","+"返回Map内容:"+jsonArray.toString());
							}
						} else {
							model = new HashMap<>();
							logger.info("ID="+ uniqueID +","+"返回Map为null");
						}
						model.put("basePath", request.getContextPath());
						model.put("jsessionid", request.getSession().getId());
						File file = new File(ConfigUtil.getString("sys.plugins.path")+"/pages/"+project+"/"+module+"/"+action+".ftl");
						if(!file.exists()) {
							logger.info("文件："+file.getPath()+"不存在,生成文件。");
							if(!StringUtils.isBlank(view)) {
								parseView(view,file.getPath());
							} else {
								logger.info("确保方法返回view的json！");
								model.put("project", project);
								model.put("module", module);
								model.put("action", action);
								model.put("message", "没有找到页面配置");
								return new ModelAndView("/operationmanagesystem/desktop/error",model);
							}
						}
						logger.info("ID="+ uniqueID +","+"View请求结束：返回"+"/"+project+"/"+module+"/"+action+"页面。");
						return new ModelAndView("/"+project+"/"+module+"/"+action,model);
					}
				}
				throw new NoSuchMethodException("no method found in this bean");
			}
		} catch (NoSuchBeanDefinitionException e) {
			logger.warn("", e);
			//logger.error(ExceptionUtil.getStackTrace(e));
			model.put("message", e.getMessage());
		} catch (BeanCreationException e) {
			model.put("message", e.getMessage());
			logger.info("ID="+ uniqueID +","+"创建"+beanName+"实例出现错误，可能远程服务器未提供服务或未启动",e.fillInStackTrace());
			removeBean(beanName,ac,uniqueID);
		} catch (BeansException e) {
			model.put("message", e.getMessage());
			logger.info("ID="+ uniqueID +","+"获取不了容器中的"+beanName, e);
		} catch (IllegalAccessException e) {
			model.put("message", e.getMessage());
			logger.info("ID="+ uniqueID +","+"",e);
		} catch (IllegalArgumentException e) {
			model.put("message", e.getMessage());
			logger.info("ID="+ uniqueID +","+"",e);
		} catch (InvocationTargetException e) {
			model.put("message", e.getMessage());
			logger.info("ID="+ uniqueID +","+"",e);
		} catch (NoSuchMethodException e) {
			model.put("message", e.getMessage());
			logger.info("ID="+ uniqueID +","+demo.getName()+"中没有找到对应"+action+"View方法",e);
		} catch (Exception e) {
			model.put("message", e.getMessage());
			logger.error("ID="+ uniqueID +","+"",e);
		}
		return new ModelAndView("operationmanagesystem/desktop/error", model);
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-2-11</li>
	 * <li>2、开发时间：上午11:55:05</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：void</li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * @param view
	 */
	public void parseView(String view,String ftlPath) {
		JSONParseUtil2 jsonParseUtil2 = new JSONParseUtil2();
		View v = jsonParseUtil2.getView(view);
		/*View v = JSONParseUtil.getView(view);*/
		ViewUtil.getView(v,ftlPath);
		/*model.put("ready", vo.getReady());
		model.put("function", vo.getFunction());
		model.put("html", vo.getHtml());*/
	}

	public ModelAndView httpView(String project,String module,String action,Map<String,Object> params,HttpServletRequest request,String uniqueID) {
		project = getRealProject(project, request);
		String url = ReadProperties.read(action+"_url", "/http/"+project+"/"+module+".properties");
		logger.info("ID="+ uniqueID +","+"Http远程请求地址："+url);
		
		Sign sign = new Sign(project,module,action,params);
		params.put("appCode", sign.getAppCode());
		params.put("sign", sign.getSign());
		String json = "{}";
		if(null != url) {
			json = HttpUtils.doPost(url, params);
			if("".equals(json)) {
				json = "{}";
			}
		} else {
			logger.info("/http/"+project+"/"+module+".properties下"+action+"_url不存在。");
		}
		/*JSONObject jsonObject = JSONObject.fromObject(json);
		Map<String,Object> model = (Map<String, Object>) JSONObject.toBean(jsonObject, HashMap.class);*/
		Map<String,Object> model = JsonParser2.toMap(json);
		if(null == model) {
			model = new HashMap<String,Object>();
		}
		model.put("jsessionid", request.getSession().getId());//jsessionid为了应对firefox下使用swf上传时不在同一session下
		File file = new File(ConfigUtil.getString("sys.plugins.path")+"/pages/"+project+"/"+module+"/"+action+".ftl");
		if(!file.exists()) {
			logger.info("文件："+file.getPath()+"不存在,生成文件。");
			String viewJson = ReadProperties.read(action+"_view", "/http/"+project+"/"+module+".properties");
			if(!StringUtils.isBlank(viewJson)) {
				parseView(viewJson,file.getPath());
			} else {
				logger.info(action+"_view不存在,生成文件失败，请确认/http/"+project+"/"+module+".properties下有此配置项！");
				model.put("project", project);
				model.put("module", module);
				model.put("action", action);
				model.put("message", "没有找到页面配置");
				return new ModelAndView("/operationmanagesystem/desktop/error",model);
			}
		}
		logger.info("ID="+ uniqueID +","+"View请求结束：返回"+"/"+project+"/"+module+"/"+action+"页面。");
		return new ModelAndView(project+"/"+module+"/"+action,model);
	}
	
	/**
	 * <ul>
	 * <li>1、开发日期：2014-1-17</li>
	 * <li>2、开发时间：下午4:04:31</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：Object[]</li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * @param params
	 * @param request
	 * @param response
	 * @param parameterTypes
	 * @return
	 * @throws Exception
	 */
	public Object[] bindMethodParams(Map<String, String[]> params,
			HttpServletRequest request, HttpServletResponse response,
			Class<?>[] parameterTypes) throws Exception {
		Object object = null;
		Object[] objs = new Object[parameterTypes.length];
		int i = 0;
		for (Class<?> clazz : parameterTypes) {
			object = newValue(clazz,clazz.getName(),params,request,response,null,null);
			bindObject(object, request);
			objs[i] = object;
			i++;
		}
		return objs;
	}
	
	public void bindMethodParamsByObject(Map<String, Object> params,HttpServletRequest request, HttpServletResponse response,
			Map<String,Object> beansMap) {
		Set<Entry<String,Object>> sets = beansMap.entrySet();
		for (Entry<String, Object> entry : sets) {
			Object obj = entry.getValue();
			bindObject(obj, request);
		}
		beansMap.put("params", params);
	}

	void bindObject(Object object, HttpServletRequest request) {
		if(object == null) {
			return;
		}
		ServletRequestDataBinder dataBinder2 = new ServletRequestDataBinder(object);
		dataBinder2.setIgnoreUnknownFields(true);
		dataBinder2.registerCustomEditor(Date.class, new DateEditor());
		dataBinder2.bind(request);
	}
	
	private Object newValue(Class<?> type, String name,Map<String,String[]> params,HttpServletRequest request,HttpServletResponse response,UploadFile uploadFile,UploadObject uploadObject) throws Exception {
		try {
			if (type.isArray()) {
				return null;
			}
			else if (Collection.class.isAssignableFrom(type)) {
				/*return CollectionFactory.createCollection(type, 16);*/
				return null;
			} else if (Map.class.isAssignableFrom(type)) {
				/*return CollectionFactory.createMap(type, 16);*/
				return params;
			} else if(HttpServletRequest.class.isAssignableFrom(type)) {
				return request;
			} else if(HttpServletResponse.class.isAssignableFrom(type)) {
				return response;
			} else if(User.class.isAssignableFrom(type)) {
				User user = (User) request.getSession().getAttribute(Configuration.userSession);
				return user;
			} else if(UploadFile.class.isAssignableFrom(type)) {
				return uploadFile;
			} else if(UploadObject.class.isAssignableFrom(type)) {
				return uploadObject;
			} else {
				return type.newInstance();
			}
		}
		catch (Exception ex) {
			throw new Exception(ex);
		}
	}
	
	/**
	 * ajax请求的controller 以.biz结尾
	 * @PathVariable project 项目名称
	 * @PathVariable module	模块名称
	 * @PathVariable action	方法名称
	 * @RequestParam params	所接收到的参数
	 * @return model 返回的参数的map集合
	 * @throws Exception 
	 * @throws SecurityException 
	 */
	@RequestMapping("/{project}/{module}/{action}.biz")
	@ResponseBody
	public Map<String,Object> doAjax(@PathVariable("project")String project,@PathVariable("module")String module,@PathVariable("action")String action,@RequestParam Map<String,String[]> params,HttpServletRequest request,HttpServletResponse response) {
		String uniqueID = UniqueID.randomUID();
		/*PropertyValues propertyValues = new ServletRequestParameterPropertyValues(request);*/
		User user = (User) request.getSession().getAttribute(Configuration.userSession);
		String ip = getRealIp(request);
		logger.info("ID="+ uniqueID +","+ (user == null?"":user.getUsername()) + "("+ip+")" +"发起Biz请求：/"+project+"/"+module+"/"+action+".biz");
		Map<String,Object> model = null;
		Object objModel = null;
		ApplicationContext ac = RequestContextUtils.findWebApplicationContext(request);
		Class<?> demo = null;
		String beanName=project+"_"+module;
		try {
			/*if (!ac.containsBean(beanName)){
				createBean(project,module,ac,uniqueID);
			}*/
			if (!ac.containsBean(beanName)){
				throw new NoSuchBeanDefinitionException(beanName,"ID="+ uniqueID +","+"容器中没有"+beanName+"的定义，检查是否注入，或者bean名称是否对应");
			}
			Object obj = ac.getBean(beanName);
			if (null==obj){
				removeBean(beanName,ac,uniqueID);
			}else{
				demo = obj.getClass();
				Method[] methods = demo.getMethods();
				for(Method method : methods) {
					if(method.getName().equals(action.trim() + "Biz")) {
						Class<?>[] parameterTypes = method.getParameterTypes();
						Object[] objs = bindMethodParams(params, request,
								response, parameterTypes);
						objModel = method.invoke(obj, objs);
						if(null != objModel) {
							if(objModel instanceof Map) {
								model = (Map<String, Object>) objModel;
								if(null != model) {
									logger.info("ID="+ uniqueID +","+"请求结束，返回Map大小:"+model.size());
									if(logger.isDebugEnabled()) {
										JSONArray jsonArray = JSONArray.fromObject( model );
										logger.debug("ID="+ uniqueID +","+"返回Map内容:"+jsonArray.toString());
									}
								}
								return model;
							} else if(objModel instanceof String) {
								String json = (String) objModel;
								response.setCharacterEncoding("utf-8");
								response.setContentType("text/html; charset=UTF-8");
								response.getWriter().write(json);
								return null;
							} else {
								logger.warn("ID="+ uniqueID +","+"请求结束，返回类型错误："+objModel.getClass());
							}
						} else {
							logger.info("ID="+ uniqueID +","+"请求结束，Map为null");
							model = new HashMap<String, Object>();
							return model;
						}
					}
				}
				throw new NoSuchMethodException("no method found in this bean");
			}
		} catch (BeanCreationException e) {
			logger.error("ID="+ uniqueID +","+"创建"+beanName+"实例出现错误，可能远程服务器未提供服务或未启动",e);
			removeBean(beanName,ac,uniqueID);
		} catch (NoSuchBeanDefinitionException e) {
			logger.warn("ID="+ uniqueID +","+"容器中没有"+beanName+"的定义，检查是否注入，或者bean名称是否对应",e);
		} catch (BeansException e) {
			logger.error("ID="+ uniqueID +","+"获取不了容器中的"+beanName,e);
		} catch (NoSuchMethodException e) {
			logger.error("ID="+ uniqueID +","+demo.getName()+"中没有找到对应"+action+"Biz方法",e);
		} catch (Exception e) {
			logger.error(e);
			logger.error("ID="+ uniqueID +","+"",e);
		}
		return model;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-2-11</li>
	 * <li>2、开发时间：下午12:55:12</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：Map<String,Object></li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * @param params
	 * @return
	 */
	public String httpBiz(String project,String module,String action,Map<String, Object> params,String uniqueID,HttpServletRequest request) {
		project = getRealProject(project, request);
		String url = ReadProperties.read(action+"_url", "/http/"+project+"/"+module+".properties");
		logger.info("ID="+ uniqueID +","+"Http远程请求地址"+url);
		Sign sign = new Sign(project,module,action,params);
		params.put("appCode", sign.getAppCode());
		params.put("sign", sign.getSign());
		String json = HttpUtils.doPost(url, params);
		return json;
	}

	public UploadObject getUploadFiles(MultipartHttpServletRequest multiRequest) {
		UploadObject uploadObject = new UploadObject();
		Map<String,String> params = uploadObject.getParams();
		Map<String, String[]> map = multiRequest.getParameterMap();
		Set<Entry<String,String[]>> set = map.entrySet();
		for (Entry<String, String[]> entry : set) {
			Object obj = entry.getValue();
			if(null != obj) {
				if(obj.getClass().isArray()) {
					if(Array.getLength(obj) > 0) {
						params.put(entry.getKey(), String.valueOf(Array.get(obj, 0)));
					}
				}
			} else {
				params.put(entry.getKey(),multiRequest.getParameter(entry.getKey()));
			}
		}
		Map<String,UploadFile> uploadFiles = uploadObject.getUploadFiles();
		Iterator<String> it = multiRequest.getFileNames();
		while (it.hasNext()) {
			String string = it.next();
			MultipartFile file = multiRequest.getFile(string);
			if(!file.isEmpty()) {
				UploadFile uploadFile = new UploadFile();
				uploadFile.setFieldName(file.getName());
				uploadFile.setSize(file.getSize());
				uploadFile.setOriginalName(file.getOriginalFilename());
				uploadFiles.put(uploadFile.getFieldName(), uploadFile);
			}
		}
		return uploadObject;
	}
	
	@RequestMapping("/{project}/{module}/{action}.upload")
	/*@ResponseBody*/
	public void upload(@PathVariable("project")String project,@PathVariable("module")String module,@PathVariable("action")String action,HttpServletResponse response,HttpServletRequest request) {
		response.setCharacterEncoding("utf-8");
		String uniqueID = UniqueID.randomUID();
		User user = (User) request.getSession().getAttribute(Configuration.userSession);
		String ip = getRealIp(request);
		logger.info("ID="+ uniqueID +","+ (user == null?"":user.getUsername()) + "("+ip+")" +"发起Upload请求：/"+project+"/"+module+"/"+action+".upload");
		ApplicationContext ac = RequestContextUtils.findWebApplicationContext(request);
		Class<?> demo = null;
		String beanName=project+"_"+module;
		UploadFile uploadfile = null;
		Map<String, String[]> params = null;
		MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest)request;
		UploadObject uploadObject = getUploadFiles(multiRequest);
		//上传文件时附带过来的参数
		params = multiRequest.getParameterMap();
		try {
			if (!ac.containsBean(beanName)){
				throw new NoSuchBeanDefinitionException(beanName,"ID="+ uniqueID +","+"容器中没有"+beanName+"的定义，检查是否注入，或者bean名称是否对应");
			}
			Object obj = ac.getBean(beanName);
			if (null==obj){
				removeBean(beanName,ac,uniqueID);
			}else{
				demo = obj.getClass();
				Method[] methods = demo.getMethods();
				boolean hasMethod = false;
				for(Method method : methods) {
					if(method.getName().equals(action.trim()+"Upload")) {
						hasMethod = true;
						Class<?>[] parameterTypes = method.getParameterTypes();
						Object object = null;
						Object[] objs = new Object[parameterTypes.length];
						int i = 0;
						for (Class<?> clazz : parameterTypes) {
							object = newValue(clazz,clazz.getName(),params,request,response,null,uploadObject);
							objs[i] = object;
							i++;
						}
						Object uploadObj = method.invoke(obj,objs);
						if(null != uploadObj) {
							if(uploadObj instanceof UploadObject) {
								uploadObject = (UploadObject) uploadObj;
							}
						} else {
							throw new Exception(demo.getSimpleName()+"上传方法"+method.getName()+"返回值不能为null");
						}
						if(logger.isDebugEnabled()) {
							logger.debug("ID="+ uniqueID +","+"调用上传结束，返回内容:"+uploadObject.toString());
						}
						uploadObject =  doUpload2(project, module, multiRequest, uploadObject, uniqueID);
						break;
					}
				}
				if(!hasMethod) {
					throw new NoSuchMethodException("no method found in this bean");
				} else {
					if(null == uploadObject) {
						logger.info("ID="+ uniqueID +","+"返回uploadObject为null，将不调用上传回调方法");
					} else {
						boolean hasCallback = false;
						for(Method method : methods) {
							if(method.getName().equals(action.trim()+"Callback")) {
								hasCallback = true;
								Class<?>[] parameterTypes = method.getParameterTypes();
								Object object = null;
								Object[] objs = new Object[parameterTypes.length];
								int i = 0;
								for (Class<?> clazz : parameterTypes) {
									object = newValue(clazz,clazz.getName(),params,request,response,uploadfile,uploadObject);
									objs[i] = object;
									i++;
								}
								//调用上传结束回调方法
								String result = (String) method.invoke(obj,objs);
								if(null != result) {
									if(logger.isDebugEnabled()) {
										logger.debug("ID="+ uniqueID +","+"调用回调方法结束，返回字符串："+result);
									}
									response.getWriter().write(result);
								} else {
									if(logger.isDebugEnabled()) {
										logger.debug("ID="+ uniqueID +","+"调用回调方法结束，返回字符串为null，将自动返回默认值！");
									}
									if(uploadObject.isSuccess()) {
										response.getWriter().write("{'result':'success'}");
									} else {
										response.getWriter().write("{'result':'failed'}");
									}
								}
								break;
							}
						}
						if(!hasCallback) {
							if(uploadObject.isSuccess()) {
								response.getWriter().write("{'result':'success'}");
							} else {
								response.getWriter().write("{'result':'failed'}");
							}
							logger.info("ID="+ uniqueID +","+demo.getName()+"中没有回调方法("+ action.trim()+"Callback" +")将返回默认值！");
						}
					}
				}
			}
		} catch (BeanCreationException e) {
			logger.error("ID="+ uniqueID +","+"创建"+beanName+"实例出现错误，可能远程服务器未提供服务或未启动",e);
			removeBean(beanName,ac,uniqueID);
		} catch (NoSuchBeanDefinitionException e) {
			logger.warn("",e);
		} catch (BeansException e) {
			logger.error("ID="+ uniqueID +","+"获取不了容器中的"+beanName,e);
		} catch (NoSuchMethodException e) {
			logger.error("ID="+ uniqueID +","+"method("+ action.trim()+"Upload" +") not found in bean:"+beanName);
		} catch (Exception e) {
			logger.error("ID="+ uniqueID +","+"",e);
		}
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-2-18</li>
	 * <li>2、开发时间：下午2:06:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：UploadFile</li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * @param project
	 * @param module
	 * @param action
	 * @param request
	 * @param params
	 * @param uniqueID
	 * @return
	 * @throws Exception 
	 */
	public String httpUpload(String project, String module, String action, MultipartHttpServletRequest request,
			Map<String, Object> params, String uniqueID, UploadObject srcUploadObject) {
		UploadObject uploadObject;
		project = getRealProject(project, request);
		String urlUpload = ReadProperties.read(action+"_upload", "/http/"+project+"/"+module+".properties");
		logger.info("ID="+ uniqueID +","+"Http远程请求地址"+urlUpload);
		Sign sign = new Sign(project,module,action,srcUploadObject.getParams());
		params.put("appCode", sign.getAppCode());
		params.put("sign", sign.getSign());
		String jsonUpload = HttpUtils.doPost(urlUpload, params);
		if(logger.isDebugEnabled()) {
			logger.debug("ID="+ uniqueID +","+"调用上传结束，返回Map内容:"+jsonUpload);
		}
		Gson gson = GsonUtil.getInstance();
		uploadObject = gson.fromJson(jsonUpload, UploadObject.class);
		if(null != uploadObject) {
			try {
				if("1.0".equals(uploadObject.getVersion())) {
					uploadObject =  doUpload2(module, action, request, uploadObject, uniqueID);
				} else if("2.0".equals(uploadObject.getVersion())) {
					uploadObject =  doUpload2(project, module, request, uploadObject, uniqueID);
				} else {
					throw new RuntimeException("上传组件版本号错误！");
				}
				String urlCallback=ReadProperties.read(action+"_callback", "/http/"+project+"/"+module+".properties");
				params.put("uploadObject", gson.toJson(uploadObject));
				String jsonCallback = HttpUtils.doPost(urlCallback, params);
				if (null != jsonCallback) {
					logger.debug("ID=" + uniqueID + ","
							+ "调用回调方法结束，返回字符串：" + jsonCallback);
					return jsonCallback;
				} else {
					logger.debug("ID=" + uniqueID + ","
							+ "调用回调方法结束，返回字符串为null，将自动返回默认值！");
					if (uploadObject.isSuccess()) {
						return"{'success':true, 'result':'success'}";
					} else {
						return "{'success':false, 'result':'failed', 'message': '返回参数错误'}";
					}
				}
			} catch (IOException e) {
				logger.error("ID=" + uniqueID,e);
			} catch (Exception e) {
				logger.error("ID=" + uniqueID,e);
			}
		} else {
			logger.error("ID="+ uniqueID +","+"调用上传结束，参数错误，uploadObject为null");
		}
		return "{'success':false, 'result':'failed', 'message': '返回参数为空'}";
	}
	/**
	 * 上传至hsp服务器
	 * @author dongzhihua
	 * @time 2017年11月6日 下午7:06:30
	 * @param project
	 * @param module
	 * @param action
	 * @param request
	 * @param uniqueID
	 * ResponseData
	 */
	public ResponseData<HspFileInfo> hspHttpUpload(String project, String module, String action,
			MultipartHttpServletRequest request, String uniqueID, HspFileInfo hspFileInfo) {
		ResponseData<HspFileInfo> responseData = new ResponseData<HspFileInfo>();
		try {
			InputStream stream = null;
			boolean result = false;
			Iterator<String> it = request.getFileNames();
//			while (it.hasNext()) { 目前不支持多文件上传
				String string = it.next();
				MultipartFile file = request.getFile(string);
				if(!file.isEmpty()) {
					try {
						UploadFile uploadfile = new UploadFile();
						uploadfile.setOriginalName(file.getOriginalFilename());
						uploadfile.setName(uploadfile.getName());

						uploadfile.setVersion("2.0");
						uploadfile.setTemp(true);
						stream = file.getInputStream();
						uploadfile = this.getUploadFile(uploadfile, project);
						result = downloadUtil.upload(stream, uploadfile, uniqueID);
						if(false == result) {
							responseData.setCodeMessage("0001", "上传失败");
							logger.warn("ID="+ uniqueID +","+"文件("+ uploadfile.getPathname() +")上传失败，绝对路径："+uploadfile.getRealPathname());
						} else {
							SaveResult hspResult = hspClient.save(uploadfile.getRealPathname());
							if(StringUtils.isEmpty(hspResult.getFid())) {
								responseData.setCodeMessage(hspResult.getRetcode() + "", "hsp处理失败");
							} else {
								if(StringUtils.isEmpty(hspFileInfo.getFileName())) {
									hspFileInfo.setFileName(uploadfile.getOriginalName());
								}
								hspFileInfo.setFid(hspResult.getFid());
								hspFileInfo.setUrl(hspClient.getUrl(hspResult.getFid(), hspFileInfo.getUrlValidMinutes(), hspFileInfo.getFileName()));
								hspFileInfo.setFileType(StringUtils.substringAfterLast(hspFileInfo.getFileName(), "."));
								responseData.setData(hspFileInfo);
							}
							logger.info("ID="+ uniqueID +","+"文件("+ uploadfile.getPathname() +")上传成功，绝对路径："+uploadfile.getRealPathname());
							File file1 = new File(uploadfile.getRealPathname());
							if(file1.exists()) {
								logger.info("delete:" + file1.delete());
							}
						}
					} catch (IOException e) {
						logger.info("ID="+ uniqueID +","+"上传失败，IO异常。", e);
						responseData.setCodeMessage("IOException", "上传异常");
					}
				} else {
					logger.info("ID="+ uniqueID +","+"上传失败，文件不存在");
					responseData.setCodeMessage("fileNotExist", "文件不存在");
				}
//			}
		} catch (Exception e) {
			responseData.setCodeMessage("9999", "上传异常");
		}
		return responseData;
	}

	public UploadObject doUpload2(String project,String module,
			MultipartHttpServletRequest multiRequest,
			UploadObject uploadObject, String uniqueID) throws Exception {
		Map<String,UploadFile> uploadFiles;
		if(null != uploadObject) {
			uploadFiles = uploadObject.getUploadFiles();
			if(null == uploadFiles) {
				throw new Exception("返回文件列表不能为null");
			}
		} else {
			throw new Exception("返回uploadObject不能为null");
		}
		InputStream stream;
		boolean result;
		Iterator<String> it = multiRequest.getFileNames();
		while (it.hasNext()) {
			String string = it.next();
			MultipartFile file = multiRequest.getFile(string);
			if(!file.isEmpty()) {
				try {
					UploadFile uploadfile;
					if(uploadFiles.containsKey(file.getName())) {
						uploadfile = uploadFiles.get(file.getName());
						if(null == uploadfile) {
							throw new Exception("文件"+file.getOriginalFilename()+"在文件列表中取出为null");
						}
					} else {
						throw new Exception("文件"+file.getOriginalFilename()+"不存在");
					}
					uploadfile.setVersion(uploadObject.getVersion());
					stream = file.getInputStream();
					uploadfile = this.getUploadFile(uploadfile, project);
					result = downloadUtil.upload(stream, uploadfile, uniqueID);
					if(false == result) {
						uploadObject.setSuccess(result);
						uploadfile.setSuccess(result);
						logger.warn("ID="+ uniqueID +","+"文件("+ uploadfile.getPathname() +")上传失败，绝对路径："+uploadfile.getRealPathname());
					} else {
						logger.info("ID="+ uniqueID +","+"文件("+ uploadfile.getPathname() +")上传成功，绝对路径："+uploadfile.getRealPathname());
					}
				} catch (IOException e) {
					logger.info("ID="+ uniqueID +","+"上传失败，IO异常。",e);
				}
			} else {
				logger.info("ID="+ uniqueID +","+"上传失败，文件不存在");
			}
		}
		return uploadObject;
	}

	protected UploadFile getUploadFile(UploadFile file,String project) {
		String filename;
		String pathname;
		
		// 得到文件的扩展名(无扩展名时将得到全名)
		String ext = file.getOriginalName().substring(file.getOriginalName().lastIndexOf(".") + 1);
		//项目名为第一层路径
		pathname = project ;
		//取出路径
		String pathnameTemp = file.getPath();
		//格式化路径为xxxx/xxxx/xxxx的格式
		pathnameTemp = FtpUtil.formatPath(pathnameTemp);
		if(null != pathnameTemp && !pathnameTemp.equals("")) {
			//如果格式化后的pathnameTemp不为空，则在pathname的基础上加上/pathnameTemp
			pathname += "/" + pathnameTemp;
		}
		//得到返回的文件名
		String fileNameTemp = file.getName();
		if(null == fileNameTemp || fileNameTemp.equals("")) {
			//如果为空，默认以年月日时分秒毫秒命名
			filename = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
		} else {
			filename = fileNameTemp;
		}
		filename += "." + ext;//加上文件扩展名
		file.setName(filename);
		file.setPath(pathname);
		return file;
	}

	@RequestMapping("/{project}/{module}/{action}.download")
	public void download(@PathVariable("project")String project,@PathVariable("module")String module,@PathVariable("action")String action,@RequestParam Map<String,String[]> params,HttpServletResponse response,HttpServletRequest request) {
		String uniqueID = UniqueID.randomUID();
		logger.info("ID="+ uniqueID +","+"开始下载文件");
		ApplicationContext ac = RequestContextUtils.findWebApplicationContext(request);
		Class<?> demo = null;
		String beanName=project+"_"+module;
		String filename;
		UploadFile uploadfile;
		try {
			if (!ac.containsBean(beanName)){
				throw new NoSuchBeanDefinitionException(beanName,"ID="+ uniqueID +","+"容器中没有"+beanName+"的定义，检查是否注入，或者bean名称是否对应");
			}
			Object obj = ac.getBean(beanName);
			if (null==obj){
				removeBean(beanName,ac,uniqueID);
			}else{
				demo = obj.getClass();
				Method[] methods = demo.getMethods();
				boolean hasMethod = false;
				for(Method method : methods) {
					if(method.getName().equals(action.trim()+"Download")) {
						hasMethod = true;
						Class<?>[] parameterTypes = method.getParameterTypes();
						Object[] objs = bindMethodParams(params, request,
								response, parameterTypes);
						uploadfile = (UploadFile) method.invoke(obj,objs);
						if(null != uploadfile && uploadfile.getName() != null && uploadfile.getPath() != null) {
							filename = uploadfile.getName();
							String downloadName = uploadfile.getOriginalName();
							if(null == downloadName || downloadName.equals("")) {
								downloadName = filename;
							}
							String filetype = getFileType(filename);
							response.setContentType(filetype);
							response.setHeader("Content-Disposition", "attachment;filename="+ this.getFileHeader(downloadName, request.getHeader("User-Agent")));
							if(logger.isDebugEnabled()) {
								logger.debug("ID="+ uniqueID +","+"调用下载方法结束，返回UploadFile内容:"+uploadfile.toString()+",自动获取文件类型为："+filetype);
							}
							httpDownload(uploadfile, request, response, uniqueID);
							//result =  downloadUtil.download(response.getOutputStream(), uploadfile, uniqueID);
						} else {
							logger.error("ID="+ uniqueID +","+"调用下载方法结束，返回UploadFile为null，参数错误");
						}
						break;
					}
				}
				if(!hasMethod) {
					throw new NoSuchMethodException("no method found in this bean");
				}
			}
		} catch (BeanCreationException e) {
			logger.error("ID="+ uniqueID +","+"创建"+beanName+"实例出现错误，可能远程服务器未提供服务或未启动",e);
			removeBean(beanName,ac,uniqueID);
		} catch (NoSuchBeanDefinitionException e) {
			logger.warn("",e);
		} catch (BeansException e) {
			logger.error("ID="+ uniqueID +","+"获取不了容器中的"+beanName,e);
		} catch(NoSuchMethodException e) {
			logger.error("ID="+ uniqueID +","+demo.getName()+"中没有找到对应"+action.trim()+"Download方法",e);
		} catch (Exception e) {
			logger.error("ID="+ uniqueID +","+"",e);
		}
	}

	private String getFileHeader(String fileName,String head) throws UnsupportedEncodingException {
		String retFileName;
		if (head.indexOf("MSIE") > 0) { // ie
			retFileName = URLEncoder.encode(fileName, "UTF-8");
			// 由于空格问题会被转成 +
			retFileName = retFileName.replace("+", "%20");
			if (retFileName.length() > 150
					&& (head.indexOf("MSIE 6.0") > 0 || head
							.indexOf("MSIE 7.0") > 0)) {// 解决IE 6.0 7.0 bug
				if (fileName.indexOf("Fw:>>") < 0) {// 这种情况ie6下后乱码
					retFileName = new String(fileName.getBytes("GBK"),
							"ISO-8859-1");
				}
			}
		} else if (head.indexOf("Opera") >= 0) {
			retFileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
		} else if (head.indexOf("Safari") >= 0 && head.indexOf("Chrome") < 0) {// 添加Safari浏览器的支持
			retFileName = new String(fileName.getBytes("UTF-8"), "ISO-8859-1");
		} else {// 不是IE浏览器
			retFileName = "=?UTF-8?B?" + new String(Base64.encodeBase64(fileName.getBytes("utf-8"))) + "?=";
		}
		if (retFileName.lastIndexOf("%00") > -1) {
			retFileName = retFileName.substring(0,retFileName.lastIndexOf("%00"));
		}
		return retFileName;
	}
	
	public String getFileType(String filename) {
		String filetype = null;
		if (null != filename) {
			Matcher mInput = Pattern.compile("[^\\.]+$").matcher(filename);
			mInput.find();
			filename = mInput.group();
			filetype = ReadProperties.read(filename, "/filetype.properties");
			if(null == filetype) {
				filetype = "application/octet-stream";
			}
		}
		return filetype;
	}
	
	public void removeBean(String beanName,ApplicationContext applicationContext,String uniqueID){
		ConfigurableApplicationContext ctx = (ConfigurableApplicationContext) applicationContext;
		DefaultListableBeanFactory defaultListableBeanFactory=(DefaultListableBeanFactory)ctx.getBeanFactory();
		try {
			defaultListableBeanFactory.removeBeanDefinition(beanName);
		} catch (Exception e) {
			logger.error("ID="+ uniqueID +","+"",e);
		}
	}

}
