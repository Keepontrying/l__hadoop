/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-5-8</li>
 * <li>3、开发时间：下午7:36:59</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.rules.base</li>
 * <li>6、文件名称：ArrayRule.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.rules.base;

/**
 * <ul>
 * <li>1、开发日期：2014-5-8</li>
 * <li>2、开发时间：下午7:36:59</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：ArrayRule</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class RangeRule extends BaseRule {
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：RangeRule.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -1471733548794493575L;
	/**  
	 * Title: ArrayRule.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private Integer[] value = new Integer[2];

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午7:38:08</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“value”的值
	 */
	public Integer[] getValue() {
		return value;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午7:38:08</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“value”的值将赋给字段“value”
	 */
	public void setValue(Integer[] value) {
		this.value = value;
	}
	
}
