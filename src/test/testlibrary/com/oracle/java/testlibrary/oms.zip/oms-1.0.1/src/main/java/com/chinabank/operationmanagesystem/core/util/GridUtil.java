/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：上午10:13:15</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.util</li>
 * <li>6、文件名称：GridUtil.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.util;

import java.util.ArrayList;
import java.util.List;

import com.chinabank.operationmanagesystem.core.bean.grid.Action;
import com.chinabank.operationmanagesystem.core.bean.grid.ColModel;
import com.chinabank.operationmanagesystem.core.bean.grid.Grid;
import com.chinabank.operationmanagesystem.core.bean.grid.Renderer;
import com.chinabank.operationmanagesystem.core.bean.query.ViewObject;
import com.chinabank.operationmanagesystem.core.enums.ActionTypeEnum;
import com.chinabank.operationmanagesystem.core.enums.ColumnTypeEnum;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：上午10:13:15</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：GridUtil</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class GridUtil {
	public static String CR = "\n";
	public static String JS_CR = "\n\t";
	public static String GRID_CR = JS_CR + "\t";
	public static String COLMODEL_CR = GRID_CR + "\t";
	public static String RENDERER_CR = COLMODEL_CR + "\t\t";
	private static final String JUMP_HTML = "<span id='action${id}' rule='${expression}' class='ml5 iconrept btn'>${label}</span>";
	private static final String VIEW_HTML = "<span id='action${id}' rule='${expression}' class='ml5 iconrept btn disabled single'>${label}</span>";
	private static final String SINGLE_HTML = "<span id='action${id}' rule='${expression}' class='ml5 iconrept btn disabled single'>${label}</span>";
	private static final String MULTI_HTML = "<span id='action${id}' rule='${expression}' class='ml5 iconrept btn disabled multi'>${label}</span>";
	private static final String TIP = "<span class='ui-tiptext-container ui-tiptext-success' style='display:none;vertical-align: middle;'><i class='ui-tiptext-icon' style='vertical-align:middle'></i><span class='success ft-green ft-14' style='vertical-align:middle'>提交成功</span></span>";
	private static final String JUMP_CLICK = GRID_CR +"$('#action${id}').click(function() {" +COLMODEL_CR+
															"window.location = '${url}';"+GRID_CR+
													"});";
	private static final String VIEW_CLICK = GRID_CR +"$('#action${id}').click(function() {" +COLMODEL_CR+
															"doSingleForm($(this),'${url}');"+GRID_CR+
													"});";
	private static final String SINGLE_CLICK = GRID_CR + "$('#action${id}').click(function() {" +COLMODEL_CR+
															"doSingleAjax($(this),'${url}');"+GRID_CR+
														"});";
	private static final String MULTI_CLICK = GRID_CR + "$('#action${id}').click(function() {" +COLMODEL_CR+
															"doMultiAjax($(this),'${url}');"+GRID_CR+
														"});";
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：上午10:13:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public GridUtil() {
		// TODO Auto-generated constructor stub
	}
	/**  
	 * Title: GridUtil.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	
	public static ViewObject getGrid(Grid grid) {
		StringBuilder html = new StringBuilder();
		StringBuilder ready = new StringBuilder();
		StringBuilder function = new StringBuilder();
		ready.append(CR).append(JS_CR).append("$(window).resize(function (){");
		ready.append(GRID_CR).append("$('#grid').omGrid('resize');");
		ready.append(CR).append(JS_CR).append("});");
		ready.append(CR + JS_CR + "$('#grid').omGrid({"+ GRID_CR +"title:'"+ grid.getTitle() +"',");
		if(null != grid.getDataSource()) {
			ready.append(GRID_CR +"dataSource:'" + grid.getDataSource() + "',");
		} else {
			ready.append(GRID_CR +"dataSource:dataSource(),");
		}
		ready.append(GRID_CR +"limit:" + grid.getLimit() + ",");
		ready.append(GRID_CR +"height: gridHeight(),");
		ready.append(GRID_CR +"method:'"+ grid.getMethod() +"',");
		ready.append(GRID_CR +"showIndex:"+ grid.isShowIndex() +",");
		ready.append(GRID_CR +"singleSelect:" + grid.isSingleSelect() +",");
		ready.append(GRID_CR +"autoFit:" + grid.isAutoFit() +",");
		ready.append(GRID_CR +"colModel:"+ GridUtil.getColModel(grid.getColModels())+",");
		ready.append(GRID_CR +"onSuccess:function(data,testStatus,XMLHttpRequest,event){");
		ready.append(COLMODEL_CR +"if(undefined == data || undefined == data.total) {");
		ready.append(RENDERER_CR +"data.total = 0;");
		ready.append(RENDERER_CR +"data.rows = '';");
		ready.append(RENDERER_CR +"alert('读取数据出错，请再次刷新尝试。如多次尝试无效，请联系相关人员！');");
		ready.append(COLMODEL_CR +"}else if(false == data.success) {");
		ready.append(RENDERER_CR +"alert(data.message);");
		ready.append(COLMODEL_CR +"}");
		ready.append(GRID_CR +"}"+",");
		ready.append(GRID_CR +"onRefresh:function() {");
		ready.append(COLMODEL_CR +"checkSelect();");
		ready.append(GRID_CR +"}"+",");
		ready.append(GRID_CR +"onRowSelect:function(rowIndex,rowData,event) {");
		ready.append(COLMODEL_CR +"checkSelect();");
		ready.append(COLMODEL_CR +"checkConditionSelect();");
		ready.append(GRID_CR +"}"+",");
		ready.append(GRID_CR +"onRowDeselect:function(rowIndex,rowData,event) {");
		ready.append(COLMODEL_CR +"checkSelect();");
		ready.append(COLMODEL_CR +"checkConditionSelect();");
		ready.append(GRID_CR +"}");
		ready.append(JS_CR +"});");
		html.append("<div class='ui-box-container'>");
		html.append("<table id='grid'></table>");
		html.append("</div>");
/*		function.append(JS_CR).append("gridHeight = function() {");
		function.append(GRID_CR).append("if(parent != self) {");
		function.append(COLMODEL_CR).append("winHeight = parent.document.documentElement.clientHeight - $('header', parent.parent.document).height() - $('nav.iconrept', parent.parent.document).height() - 30;");
		function.append(GRID_CR).append("} else {");
		function.append(COLMODEL_CR).append("winHeight = document.documentElement.clientHeight;");
		function.append(GRID_CR).append("}");
		function.append(GRID_CR).append("winHeight = winHeight - 20;");
		function.append(GRID_CR).append("return winHeight;");
		function.append(JS_CR).append("}");*/
		ViewObject vo = GridUtil.getActions(grid.getColModels());
		html.append(vo.getHtml());
		ready.append(vo.getReady());
		function.append(vo.getFunction());
		return new ViewObject(html.toString(),function.toString(),ready.toString());
	}
	
	private static String getColModel(List<ColModel> colModels) {
		ViewObject viewObject = new ViewObject();
		StringBuilder colModelJSON = new StringBuilder();
		colModelJSON.append("[");
		for (ColModel colModel : colModels) {
			if(ColumnTypeEnum.ACTION.getCode().equals(colModel.getColumnTypeEnum().getCode())) {
				continue;
			}
			colModelJSON.append(COLMODEL_CR+"{header:'" + colModel.getHeader() +"',name:'" + colModel.getName() +"',width:"+ ((colModel.getWidth() > 0 )?colModel.getWidth():"autoExpand") + ",align:'"+ colModel.getAlign().getName() +"'");
			Renderer renderer = colModel.getRenderer();
			if(null != renderer) {
				colModelJSON.append(",renderer:" + GridUtil.getRenderer(renderer));
			} else if(ColumnTypeEnum.LINK.getCode().equals(colModel.getColumnTypeEnum().getCode())) {
				colModelJSON.append(",renderer:" + GridUtil.getLink(colModel));
			}
			colModelJSON.append("},");
		}
		colModelJSON.delete(colModelJSON.length() - 2, colModelJSON.length());
		colModelJSON.append(COLMODEL_CR + "}");
		colModelJSON.append(GRID_CR + "]");
		return colModelJSON.toString();
	}
	
	private static String getRenderer(Renderer renderer) {
		StringBuilder rendererFunction = new StringBuilder();
		rendererFunction.append("function(colValue, rowData, rowIndex){");
		List<Action> actions = renderer.getActions();
		StringBuilder aLinks = new StringBuilder();
		aLinks.append("'");
		StringBuilder hrefs = new StringBuilder();
		int i = 0;
		for (Action action : actions) {
			hrefs.append(RENDERER_CR).append("var href").append(i).append(" = ").append(GridUtil.getHref(action)).append(";");
			aLinks.append("<a href=\"' + href").append(i).append(" +'\">").append(action.getText()).append("</a>  ");
			i++;
		}
		aLinks.append("'");
		rendererFunction.append(hrefs.toString() + RENDERER_CR + "return " + aLinks.toString() +";"+ COLMODEL_CR +"\t}");
		return rendererFunction.toString();
	}
	
	private static String getLink(ColModel colModel) {
		Action action = colModel.getAction();
		StringBuilder rendererFunction = new StringBuilder();
		rendererFunction.append("function(colValue, rowData, rowIndex){");
		StringBuilder aLinks = new StringBuilder();
		StringBuilder hrefs = new StringBuilder();
		hrefs.append(RENDERER_CR).append("var href").append(" = ").append(GridUtil.getHref(action)).append(";");
		aLinks.append("'<a href=\"' + href").append(" +'\">'+ rowData.").append(colModel.getName()).append(" +'</a>'");
		rendererFunction.append(hrefs.toString() + RENDERER_CR + "return " + aLinks.toString() +";"+ COLMODEL_CR +"\t}");
		return rendererFunction.toString();
	}
	
	private static String getHref(Action action) {
		StringBuilder actionUrl = new StringBuilder();
		actionUrl.append("'" + action.getUrl() + "?'");
		String[] params = action.getParams();
		String andStr = " + '&'";
		for (String param : params) {
			actionUrl.append("+'"+param + "=' + rowData." +param + andStr);
		}
		String fixedParam = action.getFixedParam();
		if(null != fixedParam && !fixedParam.equals("")) {
			actionUrl.append(" + '" + action.getFixedParam() +"'");
		} else {
			actionUrl.delete(actionUrl.length() - andStr.length(), actionUrl.length());//去掉最后一个连接符
		}
		return actionUrl.toString();
	}
	
	private static String[] getParams(List<ColModel> colModels) {
		String[] temp = new String[colModels.size()];
		int i = 0;
		for (ColModel colModel : colModels) {
			if(ColumnTypeEnum.COLUMN.getCode().equals(colModel.getColumnTypeEnum().getCode())) {
				temp[i] = colModel.getName();
				i ++;
			}
		}
		String[] params = new String[i];
		for(int j = 0; j < i; j ++) {
			params[j] = temp[j];
		}
		return params;
	}
	
	private static ViewObject getActions(List<ColModel> colModels) {
		Integer id = 0 ;
		StringBuilder ready = new StringBuilder();
		ready.append(JS_CR).append("insertAction();");
		StringBuilder function = new StringBuilder();
		function.append(JS_CR).append("function insertAction() {");
		function.append(GRID_CR).append("var action = $(\"${html}\");");
		function.append(GRID_CR).append("$('.pDiv').append(action);");
		function.append(GRID_CR).append("buildEvent();");
		function.append(JS_CR).append("}");
		function.append(JS_CR).append("function buildEvent() {");
		function.append("${event}");
		function.append(JS_CR).append("}");
		StringBuilder html = new StringBuilder();
		StringBuilder event = new StringBuilder();
		html.append("<div class='ui-action'>");
		for (ColModel colModel : colModels) {
			if(ColumnTypeEnum.ACTION.getCode().equals(colModel.getColumnTypeEnum().getCode())) {
				ViewObject viewObject = GridUtil.getAction(colModel);
				String htmlTemp = viewObject.getHtml();
				html.append(htmlTemp.replaceAll("\\$\\{id\\}", id.toString()));
				String eventTemp = viewObject.getFunction();
				event.append(eventTemp.replaceAll("\\$\\{id\\}", id.toString()));
				id ++;
			}
		}
		html.append(GridUtil.TIP);
		html.append("</div>");
		String functionTemp = function.toString();
		String eventTemp = GridUtil.filterDollarStr(event.toString());//将所有$替换成\$，因为replaceAll中的替换字符串有$，将进行$1$2分组
		String functionFinal = functionTemp.replaceAll("\\$\\{html\\}", html.toString()).replaceAll("\\$\\{event\\}", eventTemp);
		return new ViewObject("",functionFinal,ready.toString());
	}
	
	private static ViewObject getAction(ColModel colModel) {
		Action action = colModel.getAction();
		String html = null;
		String event = null;
		switch(action.getActionTypeEnum()) {
		case JUMP:
			html = JUMP_HTML.replaceAll("\\$\\{label\\}", colModel.getHeader()).replaceAll("\\$\\{expression\\}", action.getExpression());
			event = JUMP_CLICK.replaceAll("\\$\\{url\\}", action.getUrl());
			break;
		case VIEW:
			html = VIEW_HTML.replaceAll("\\$\\{label\\}", colModel.getHeader()).replaceAll("\\$\\{expression\\}", action.getExpression());
			event = VIEW_CLICK.replaceAll("\\$\\{url\\}", action.getUrl());
			break;
		case SINGLE_AJAX:
			html = SINGLE_HTML.replaceAll("\\$\\{label\\}", colModel.getHeader()).replaceAll("\\$\\{expression\\}", action.getExpression());
			event = SINGLE_CLICK.replaceAll("\\$\\{url\\}", action.getUrl());
			break;
		case MULTI_AJAX:
			html = MULTI_HTML.replaceAll("\\$\\{label\\}", colModel.getHeader()).replaceAll("\\$\\{expression\\}", action.getExpression());
			event = MULTI_CLICK.replaceAll("\\$\\{url\\}", action.getUrl());
			break;
		}
		return new ViewObject(html,event,"");
	}
	
	public static String filterDollarStr(String str) {
		String sReturn = "";
		if (!str.equals("")) {
			if (str.indexOf('$', 0) > -1) {
				while (str.length() > 0) {
					if (str.indexOf('$', 0) > -1) {
						sReturn += str.subSequence(0, str.indexOf('$', 0));
						sReturn += "\\$";
						str = str.substring(str.indexOf('$', 0) + 1,
								str.length());
					} else {
						sReturn += str;
						str = "";
					}
				}
			} else {
				sReturn = str;
			}
		}
		return sReturn;
	}
	
	public static void main(String[] args) {
/*		List<Action> actions = new ArrayList<Action>();
		Action action = new Action();
		action.setUrl("/certification/certificate/verify.biz");
		action.setFixedParam("");
		action.setParams(new String[]{"customer"});
		action.setText("审核");
		actions.add(action);
		Renderer renderer = new Renderer();
		renderer.setActions(actions);
		List<ColModel> colModels = new ArrayList<ColModel>();
		ColModel colModel = new ColModel();
		colModel.setHeader("操作");
		colModel.setRenderer(renderer);
		colModels.add(colModel);
		Grid grid = new Grid();
		grid.setColModels(colModels);
		grid.setDataSource("/certification/certificate/certificate.biz");
		System.out.println(GridUtil.getGrid(grid).getReady());*/
		List<ColModel> colModels = new ArrayList<ColModel>();
/*		ColModel colModel = new ColModel();
		colModel.setHeader("查看");
		Action action = new Action();
		action.setUrl("/certification/certificate/verify.view?type=1");
		action.setActionTypeEnum(ActionTypeEnum.VIEW);
		colModel.setAction(action);
		ColModel colModel1 = new ColModel();
		colModel1.setHeader("添加");
		Action action1 = new Action();
		action1.setActionTypeEnum(ActionTypeEnum.JUMP);
		action1.setUrl("http://www.baidu.com/");
		colModel1.setAction(action1);
		ColModel colModel2 = new ColModel();
		colModel2.setHeader("审核");
		Action action2 = new Action();
		action2.setActionTypeEnum(ActionTypeEnum.SINGLE_AJAX);
		action2.setUrl("/certification/certificate/test.biz");
		colModel2.setAction(action2);
		ColModel colModel3 = new ColModel();
		colModel3.setHeader("审核");
		Action action3 = new Action();
		action3.setActionTypeEnum(ActionTypeEnum.MULTI_AJAX);
		action3.setUrl("/certification/certificate/testMulti.biz");
		colModel3.setAction(action3);
		colModel.setColumnTypeEnum(ColumnTypeEnum.ACTION);
		colModel1.setColumnTypeEnum(ColumnTypeEnum.ACTION);
		colModel2.setColumnTypeEnum(ColumnTypeEnum.ACTION);
		colModel3.setColumnTypeEnum(ColumnTypeEnum.ACTION);
		colModels.add(colModel);
		colModels.add(colModel1);
		colModels.add(colModel2);
		colModels.add(colModel3);*/
		/*ViewObject vo = GridUtil.getActions(colModels);
		System.out.println();*/
		String test1 = "<span id='action${id}' rule='${expression}' class='ml5 iconrept btn disabled single'>${label}</span>";
		String test2 = test1.replaceAll("\\$\\{label\\}", "测试").replaceAll("\\$\\{expression\\}", "abc == \\\\'测试\\\\'");
		System.out.println();
	}
	
}
