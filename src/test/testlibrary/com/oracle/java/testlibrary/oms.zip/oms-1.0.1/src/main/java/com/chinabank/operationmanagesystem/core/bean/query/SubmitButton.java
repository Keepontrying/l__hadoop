/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：下午6:04:37</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.query</li>
 * <li>6、文件名称：SubmitButton.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.query;

import com.chinabank.operationmanagesystem.core.enums.ButtonEnum;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：下午6:04:37</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：SubmitButton</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class SubmitButton extends QueryData {

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：SubmitButton.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	private ButtonEnum buttonEnum = ButtonEnum.QUERY;
	private String url = "";
	private String back = "";
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：下午6:04:37</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public SubmitButton() {
		super("查询","");
		super.setId("query");
	}
	/**  
	 * Title: SubmitButton.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */

	public SubmitButton(String label) {
		super(label, "");
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午4:11:08</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“buttonEnum”的值
	 */
	public ButtonEnum getButtonEnum() {
		return buttonEnum;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-26</li>
	 * <li>2、开发时间：下午4:11:08</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“buttonEnum”的值将赋给字段“buttonEnum”
	 */
	public void setButtonEnum(ButtonEnum buttonEnum) {
		this.buttonEnum = buttonEnum;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-7</li>
	 * <li>2、开发时间：上午10:23:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“url”的值
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-7</li>
	 * <li>2、开发时间：上午10:23:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“url”的值将赋给字段“url”
	 */
	public void setUrl(String url) {
		this.url = url;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-7</li>
	 * <li>2、开发时间：上午11:47:35</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“back”的值
	 */
	public String getBack() {
		return back;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-7</li>
	 * <li>2、开发时间：上午11:47:35</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“back”的值将赋给字段“back”
	 */
	public void setBack(String back) {
		this.back = back;
	}
	
}
