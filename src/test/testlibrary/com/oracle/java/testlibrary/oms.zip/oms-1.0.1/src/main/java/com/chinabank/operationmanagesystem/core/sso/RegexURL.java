/**
 * <p>项目名称：oms-0.0.5<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-7-8</li>
 * <li>3、开发时间：下午4:13:48</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.sso</li>
 * <li>6、文件名称：RegexURL.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.sso;

import java.io.Serializable;

/**
 * <ul>
 * <li>1、开发日期：2014-7-8</li>
 * <li>2、开发时间：下午4:13:48</li>
 * <li>3、作 者：wangjiaqi</li>
 * <li>4、类型名称：RegexURL</li>
 * <li>5、类型意图：</li>
 * </ul>
 * 
 */
public class RegexURL implements Serializable {
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：RegexURL.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -5411301853098468232L;
	/**
	 * Title: RegexURL.java Description: TODO(用一句话描述该文件做什么)
	 * 
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private UrlType urlType;
	private String urlValue;

	public RegexURL(UrlType urlType, String urlValue) {
		this.urlType = urlType;
		this.urlValue = urlValue;
	}

	public UrlType getUrlType() {
		return this.urlType;
	}

	public void setUrlType(UrlType urlType) {
		this.urlType = urlType;
	}

	public String getUrlValue() {
		return this.urlValue;
	}

	public void setUrlValue(String urlValue) {
		this.urlValue = urlValue;
	}

	public String toString() {
		return "RegexURL [urlType=" + this.urlType + ", urlValue="
				+ this.urlValue + "]";
	}

	public static enum UrlType {
		REGEX, URL, StartsWith;
	}
}
