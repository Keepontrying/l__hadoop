package com.chinabank.operationmanagesystem.desktop.controller;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.message.BasicHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.io.IOException;

/**
 * 处理本地static文件，应对没有配置nginx的情况
 *
 * @author: dongzhihua
 * @time: 2018/8/23 17:01:35
 */
@RestController
@RequestMapping("static")
public class StaticController {
    private static Logger logger = LoggerFactory.getLogger(StaticController.class);

    @Value("${sys.plugins.static.path}")
    String staticPath;

    @RequestMapping("{project}/{file}")
    public String originFile(
            HttpResponse httpResponse,
            @PathVariable("project") String project,
            @PathVariable("file") String file) throws IOException {
        String filePath = String.format("%s%s/%s", staticPath, project, file);
        logger.info("index filePath: {}", filePath);
        return FileUtils.readFileToString(new File(filePath), "UTF8");
    }

    @RequestMapping("{project}/{disc}/{file}")
    public String file(@PathVariable("project") String project, @PathVariable("disc") String disc, @PathVariable("file") String file) throws IOException {
        String filePath = String.format("%s%s/%s/%s", staticPath, project, disc, file);
        logger.info("index filePath: {}", filePath);
        return FileUtils.readFileToString(new File(filePath), "UTF8");
    }

    @RequestMapping("{project}/{disc}/{disc1}/{file}")
    public String deepFile(@PathVariable("project") String project,
                           @PathVariable("disc") String disc,
                           @PathVariable("disc1") String disc1,
                           @PathVariable("file") String file) throws IOException {
        String filePath = String.format("%s%s/%s/%s/%s", staticPath, project, disc, disc1, file);
        logger.info("index filePath: {}", filePath);
        return FileUtils.readFileToString(new File(filePath), "UTF8");
    }

    @RequestMapping("{project}/{disc}/{disc1}/{disc2}/{file}")
    public String deepFile1(@PathVariable("project") String project,
                            @PathVariable("disc") String disc,
                            @PathVariable("disc1") String disc1,
                            @PathVariable("disc2") String disc2,
                            @PathVariable("file") String file) throws IOException {
        String filePath = String.format("%s%s/%s/%s/%s/%s", staticPath, project, disc, disc1, disc2, file);
        logger.info("index filePath: {}", filePath);
        return FileUtils.readFileToString(new File(filePath), "UTF8");
    }
}
