/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-5-21</li>
 * <li>3、开发时间：上午10:08:38</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.util</li>
 * <li>6、文件名称：WarUtils.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;

import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.jar.JarArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.io.FileUtils;

import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/**
 * <ul>
 * <li>1、开发日期：2014-5-21</li>
 * <li>2、开发时间：上午10:08:38</li>
 * <li>3、作 者：wangjiaqi</li>
 * <li>4、类型名称：WarUtils</li>
 * <li>5、类型意图：</li>
 * </ul>
 * 
 */
public class WarUtils {
	private static final Logger logger = LoggerFactory.getLogger(WarUtils.class);
	/**
	 * Title: WarUtils.java Description: TODO(用一句话描述该文件做什么)
	 * 
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */

	public static void unzip(String warPath, String unzipPath) {
		String delFiles = "/opt/plugins/files.txt";
		File fileList = new File(delFiles);
		if(!fileList.exists()) {
			try {
				fileList.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		String failDelFiles = "/opt/plugins/failFiles.txt";
		File failDelFileList = new File(failDelFiles);
		if(!failDelFileList.exists()) {
			try {
				failDelFileList.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		File warFile = new File(warPath);
		FileWriter fileWriter = null;
		BufferedWriter fileBufferedWriter = null;
		FileWriter failDelWriter = null;
		BufferedWriter failDelBufferedWriter = null;
		BufferedInputStream bufferedInputStream = null;
		ArchiveInputStream in = null;
		try {
			fileWriter = new FileWriter(fileList);
			fileBufferedWriter = new BufferedWriter(fileWriter);
			failDelWriter = new FileWriter(failDelFileList);
			failDelBufferedWriter = new BufferedWriter(failDelWriter);
			bufferedInputStream = new BufferedInputStream(
					new FileInputStream(warFile));
			in = new ArchiveStreamFactory()
					.createArchiveInputStream(ArchiveStreamFactory.JAR,
							bufferedInputStream);
			JarArchiveEntry entry = null;
			while ((entry = (JarArchiveEntry) in.getNextEntry()) != null) {
				if (entry.isDirectory()) {
					if("WEB-INF/lib/".equals(entry.getName())) {
						new File("/opt/plugins/jars/",warFile.getName()).mkdir();
					} else {
						new File(unzipPath, entry.getName()).mkdir();
					}
				} else {
					if(entry.getName().endsWith("jar")) {
						OutputStream out = FileUtils.openOutputStream(new File(
								"/opt/plugins/jars/"+warFile.getName(), entry.getName()));
						IOUtils.copy(in, out);
						out.close();
					} else {
						File file = new File(unzipPath, entry.getName());
						if(file.exists()) {
							failDelBufferedWriter.write(unzipPath + entry.getName());
							failDelBufferedWriter.newLine();
							logger.warn("文件："+entry.getName()+"已存在，不再解压。");
						} else {
							OutputStream out = FileUtils.openOutputStream(file);
							logger.info("解压文件:"+entry.getName());
							fileBufferedWriter.write(unzipPath + entry.getName());
							fileBufferedWriter.newLine();
							IOUtils.copy(in, out);
							out.close();
						}
					}
				}
			}
			fileBufferedWriter.flush();
		} catch (FileNotFoundException e) {
			System.err.println("未找到war文件");
		} catch (ArchiveException e) {
			System.err.println("不支持的压缩格式");
		} catch (IOException e) {
			System.err.println("文件写入发生错误");
		} finally {
			try {
				if(null != fileBufferedWriter) {
					fileBufferedWriter.close();
				}
				if(null != fileWriter) {
					fileWriter.close();
				}
				if(null != in) {
					in.close();
				}
				if(null != bufferedInputStream) {
					bufferedInputStream.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static void del(String fileList) {
		String jarDir = "/opt/plugins/jars/";
		File jars = new File(jarDir);
		try {
			logger.info("jars文件夹："+jarDir);
			FileUtils.deleteDirectory(jars);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		try {
			fileReader = new FileReader(new File(fileList));
			bufferedReader = new BufferedReader(fileReader);
			String fileName = null;
			while((fileName = bufferedReader.readLine()) != null) {
				File file = new File(fileName);
				logger.info("文件："+fileName+"，删除结果："+file.delete());
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if(null != bufferedReader) {
						bufferedReader.close();
				}
				if(null != fileReader) {
					fileReader.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public static void zip(String destFile, String zipDir) {
		File outFile = new File(destFile);
		try {
			outFile.createNewFile();
			BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(
					new FileOutputStream(outFile));
			ArchiveOutputStream out = new ArchiveStreamFactory()
					.createArchiveOutputStream(ArchiveStreamFactory.JAR,
							bufferedOutputStream);

			if (zipDir.charAt(zipDir.length() - 1) != '/') {
				zipDir += '/';
			}

			Iterator<File> files = FileUtils.iterateFiles(new File(zipDir),
					null, true);
			while (files.hasNext()) {
				File file = files.next();
				ZipArchiveEntry zipArchiveEntry = new ZipArchiveEntry(file,
						file.getPath().replace(zipDir.replace("/", "\\"), ""));
				out.putArchiveEntry(zipArchiveEntry);
				IOUtils.copy(new FileInputStream(file), out);
				out.closeArchiveEntry();
			}
			out.finish();
			out.close();
		} catch (IOException e) {
			System.err.println("创建文件失败");
		} catch (ArchiveException e) {
			System.err.println("不支持的压缩格式");
		}
	}
	
	public static void unzipPlugins(String pluginsPath, String targetPath) {
		String delFiles = "/opt/plugins/files.txt";
		File fileList = new File(delFiles);
		if(!fileList.exists()) {
			try {
				fileList.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		WarUtils.del(delFiles);
		File dir = new File(pluginsPath);
		if(dir.isDirectory()) {
			File[] files = dir.listFiles();
			for (File file : files) {
				if(!file.isDirectory() && file.getName().endsWith("war")) {
					logger.info("文件"+file.getName());
					WarUtils.unzip(file.getAbsolutePath(), targetPath);
				}
			}
		}
	}
	
	public static void main(String[] args) {
		File dir = new File("D:/wartest/plugins/");
		if(dir.isDirectory()) {
			File[] files = dir.listFiles();
			for (File file : files) {
				if(file.getName().endsWith("war")) {
					logger.info("文件"+file.getName());
					WarUtils.unzip(file.getAbsolutePath(), "D:/wartest/target/");
				}
			}
		}
	}
}
