package com.jd.jr.boss.credit.authen.core.beans.entity.mongo;

import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.util.Date;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption :
 * @date ：2018/11/6 11:26
 * @return
 */
@Document(collection="risk_warn_task_product_result")
public class MongoRiskWarnTaskProductResult extends MongoBaseEntity implements Serializable {

    private static final long serialVersionUID = 5401255707141546736L;

    private Integer taskProductId;//
    private String updateInfo;// 更新内容
    private String resultType;// 跑批结果
    private Integer resultListSize;// 本次查询结果大小
    private Date triggerTime;// 跑批时间
    private Integer resultIdContrast;//进行对比的执行结果id
    private String shareholderStr;// 企业股东信息字符串
    private String fringgFlag;//法人从高管中删除  YES-是 NO-否

    public Integer getTaskProductId() {
        return taskProductId;
    }

    public void setTaskProductId(Integer taskProductId) {
        this.taskProductId = taskProductId;
    }

    public String getUpdateInfo() {
        return updateInfo;
    }

    public void setUpdateInfo(String updateInfo) {
        this.updateInfo = updateInfo;
    }

    public String getResultType() {
        return resultType;
    }

    public void setResultType(String resultType) {
        this.resultType = resultType;
    }

    public Integer getResultListSize() {
        return resultListSize;
    }

    public void setResultListSize(Integer resultListSize) {
        this.resultListSize = resultListSize;
    }

    public Date getTriggerTime() {
        return triggerTime;
    }

    public void setTriggerTime(Date triggerTime) {
        this.triggerTime = triggerTime;
    }

    public Integer getResultIdContrast() {
        return resultIdContrast;
    }

    public void setResultIdContrast(Integer resultIdContrast) {
        this.resultIdContrast = resultIdContrast;
    }

    public String getShareholderStr() {
        return shareholderStr;
    }

    public void setShareholderStr(String shareholderStr) {
        this.shareholderStr = shareholderStr;
    }

    public String getFringgFlag() {
        return fringgFlag;
    }

    public void setFringgFlag(String fringgFlag) {
        this.fringgFlag = fringgFlag;
    }
}

