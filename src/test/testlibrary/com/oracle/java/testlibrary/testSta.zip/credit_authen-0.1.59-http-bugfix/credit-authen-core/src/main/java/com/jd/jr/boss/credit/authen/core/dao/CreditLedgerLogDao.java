package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.request.LedgerLogQueryParam;
import com.jd.jr.boss.credit.domain.common.entity.CreditLedgerLog;
import com.jd.jr.boss.credit.domain.common.enums.LedgerRenderStatusEnum;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by anmeng on 2016/12/21.
 */
@Repository
public interface CreditLedgerLogDao  {
    /**
     * 插入台账数据
     * @param ledgerLog
     * @return
     */
    Integer insertLedgerLog(CreditLedgerLog ledgerLog);

    /**
     * 查询台账接口数据
     * @param queryParam
     * @return
     */
    List<CreditLedgerLog> queryLedgerLog(LedgerLogQueryParam queryParam);

    /**
     * 更新台账数据状态
     * @param queryParam
     */
    void updateLedgerLogStatus(@Param("queryParam") LedgerLogQueryParam queryParam, @Param("ledgerStatus") String ledgerStatus);

    /**
     * 清除当天台账数据,防止重复报账
     * @param queryParam
     */
    void removeLedgerLog(LedgerLogQueryParam queryParam);

}
