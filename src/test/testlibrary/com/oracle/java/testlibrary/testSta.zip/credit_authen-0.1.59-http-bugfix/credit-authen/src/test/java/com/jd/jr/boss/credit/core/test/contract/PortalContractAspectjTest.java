package com.jd.jr.boss.credit.core.test.contract;

import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;
import com.jd.jr.boss.credit.domain.common.enums.ProductTableEnum;
import com.jd.jr.boss.credit.facade.authen.api.CreditContractFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditOrderFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditProductAuthenFacade;
import com.jd.jr.boss.credit.facade.authen.beans.entity.CreditProductAuthenEntity;
import com.jd.jr.boss.credit.facade.authen.beans.param.OnlineContactCreateParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.SubOrderQueryParam;
import com.jd.jr.boss.credit.facade.authen.enums.CreditProductAuthenStatusEnum;
import com.wangyin.admin.frame.utils.JSONUtils;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})

public class PortalContractAspectjTest {
    @Resource
    private CreditContractFacade contractFacade;

    @Resource
    private CreditProductAuthenFacade creditProductAuthenFacade;

    @Test
    public void mainTest() {
        OnlineContactCreateParam param =new OnlineContactCreateParam();
        param.setMerchantNo("110014405");
        param.setCreditType("ENTERPRISE");
        param.setOperator("unittest");
        List<Integer> skuList=new ArrayList<Integer>();
        skuList.add(51);
        param.setItemSkuList(skuList);
        ResponseData<CreditContract> responseData = contractFacade.createOnlineContract(param);
        System.out.println(GsonUtil.getInstance().toJson(responseData));
    }

    @Test
    public void authenTest() {
        RequestParam<CreditProductAuthenEntity> param = new RequestParam<CreditProductAuthenEntity>();
        param.setSystemId("1111");
        CreditProductAuthenEntity entity = new CreditProductAuthenEntity();
        entity.setAppId("1111");
        entity.setJdpin(" ");
        entity.setProductCode(ProductTableEnum.IDENTITY_VERIFY);
        entity.setStatus(CreditProductAuthenStatusEnum.AUTHORIZED);
        entity.setTarget("Credit");
        entity.setDataSource("JD");
        param.setParam(entity);

        ResponseData responseData = creditProductAuthenFacade.applyAuthorization(param);
        System.err.println("jsf返回接口："+ JSONUtils.toJSON(responseData));
    }

    @Test
    public void queryTest() {
        RequestParam<CreditProductAuthenEntity> param = new RequestParam<CreditProductAuthenEntity>();
        param.setSystemId("1111");
        CreditProductAuthenEntity entity = new CreditProductAuthenEntity();
        entity.setAppId("1111");
        entity.setJdpin("minqi_pin002");
        entity.setProductCode(ProductTableEnum.IDENTITY_VERIFY);
        entity.setStatus(CreditProductAuthenStatusEnum.AUTHORIZED);
        entity.setTarget("Credit");
        entity.setDataSource("JD");
        param.setParam(entity);

        ResponseData responseData = creditProductAuthenFacade.queryAuthorization(param);
        System.err.println("jsf返回接口："+ JSONUtils.toJSON(responseData));
    }

    @Test
    public void cancelTest() {
        RequestParam<CreditProductAuthenEntity> param = new RequestParam<CreditProductAuthenEntity>();
        param.setSystemId("app_id");
        CreditProductAuthenEntity entity = new CreditProductAuthenEntity();
        entity.setAppId("app_id_one");
        entity.setJdpin("user1");
        entity.setProductCode(ProductTableEnum.BANK_THREE_VERIFY);
        entity.setTarget("user1");
        param.setParam(entity);

        ResponseData responseData = creditProductAuthenFacade.cancelAuthorization(param);
        System.err.println("jsf返回接口："+ JSONUtils.toJSON(responseData));
    }
}
