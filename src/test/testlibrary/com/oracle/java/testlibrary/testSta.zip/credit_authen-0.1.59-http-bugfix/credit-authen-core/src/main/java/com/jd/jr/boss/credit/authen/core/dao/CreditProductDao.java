package com.jd.jr.boss.credit.authen.core.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.jd.jr.boss.credit.authen.core.beans.entity.ProductStrategyEntity;
import com.jd.jr.boss.credit.authen.core.beans.request.AccountPageQueryParam;
import com.jd.jr.boss.credit.authen.core.beans.request.ProductStrategyQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.ProductQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditProduct;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;

/**
 *  合同包含服务产品
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
@Repository
public interface CreditProductDao {
	   /**
     * 合同包含产品详情
     * @param contractDetailsRequest
     * @return
     */
       List<ProductStrategyEntity> queryStrategyList(ProductStrategyQueryParam strategyQueryRequest) throws Exception;
    
	/**
     * 更新产品状态
     * @param productStatusRequest
     * @return
     */
    Integer updateStrategyStatus(CreditProductStrategy productStatusRequest) throws Exception;
    /**
     * 依据策略ID获取策略信息
     * @param strategyQueryRequest
     * @return
     */
    ProductStrategyEntity queryStrategyById(
            ProductStrategyQueryParam strategyQueryRequest)throws Exception;

	/**
	 * 查询指定日期到期的计费策略
	 * @param strategyQueryRequest
	 * @return
	 */
    List<ProductStrategyEntity> quereyExpiredStrategy(ProductStrategyQueryParam strategyQueryRequest);
	/**
     * 依据产品ID和商户号查询包量计费总数
     * @param strategyQueryRequest
     * @return
     */
    Integer queryPackagePageCount(
            AccountPageQueryParam accountPageQueryParam) throws Exception;
	 /**
     * 依据产品ID和商户号查询包量计费列表
     * @author tangmingbo
     * @param contractPageQuery
     * @return
     */
     List<ProductStrategyEntity> queryPackagePage(
             AccountPageQueryParam accountPageQueryParam) throws Exception;
	 /**
     * 依据ID查询产品
     * @param strategyQueryRequest
     * @return
     */
     CreditProduct queryProductById(ProductQueryParam productQueryParam)
			throws Exception;

	/**
	 * 根据计费策略表ID查询计费策略对象
	 * @param strategyQueryRequest
	 * @return
	 * @throws Exception
	 */
    ProductStrategyEntity queryStrategyEntityById(
            ProductStrategyQueryParam strategyQueryRequest)throws Exception;

	/**
	 * 查询计费策略列表
	 * 仅查询计费策略表，不关联其他表
	 * @param queryParam
	 * @return
	 */
    List<ProductStrategyEntity> queryStrategyListOnly(ProductStrategyQueryParam queryParam);

	/**
	 * 根据产品查询参数类查询产品
	 * @param productQueryParam
	 * @return
	 */
    List<CreditProduct> queryProductByParam(ProductQueryParam productQueryParam);

	/**
	 * 根据productCodes查询产品
	 * @param  productCode
	 * @return
	 */
    List<CreditProduct> queryProductByCodes(List<String> productCodes);

	/**
	 * 关联合同表查询商户最新的一笔计费策略
	 * @param strategyQueryParam
	 * @return
	 */
    List<ProductStrategyEntity> queryLastStrategyUnionContract(ProductStrategyQueryParam strategyQueryParam);

	/**
	 * 根据到期日查询有效的计费策略
	 * @param strategyQryPrm
	 * @return
	 */
    List<ProductStrategyEntity> queryDueStrategyByDateUnionContract(ProductStrategyEntity strategyQryPrm);

	/**
	 * 根据商户号、产品id查询大于当前到期日的合同(关联计费策略)
	 * @param strategyContractQryPrm
	 * @return
	 */
    List<ProductStrategyEntity> queryAfterDueStratefyUnionContractByPrm(
            ProductStrategyEntity strategyContractQryPrm);

	/**创建计费策略
	 * @desc 新增
	 * @since Mon Jun 27 17:58:12 CST 2016
	 * @param record 服务产品计费策略实体
	 * @return
	 */
	int insertStrategy(CreditProductStrategy record);

	/**
	 * 根据参数 查询 vip产品
	 */
    List<CreditProduct> queryVipProducts(ProductStrategyQueryParam strategyQueryRequest);

	/**
	 * 查询业务产品List
	 * @param param
	 * @return
	 */
    List<CreditProduct> queryProductListByPrm(ProductQueryParam param);
}
