package com.jd.jr.boss.credit.core.test.order;

import com.jd.jr.boss.credit.authen.core.service.CreditFilterService;
import com.jd.jr.boss.credit.core.test.user.BaseTest;
import com.jd.jr.boss.credit.facade.authen.api.CreditWxOrderFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.WxOrderParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.WxOrderResp;
import com.jd.jr.boss.credit.facade.common.dto.CreditExRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.common.entity.Industry;
import com.jd.jr.boss.credit.facade.external.api.CreditExWxOrderFacade;
import com.jd.jr.boss.credit.facade.external.beans.request.WxOrderReq;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditWxOrderResp;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.List;

/**
 *
 * @author jiangbo
 */
public class CreditWxOrderFacadeTest extends BaseTest {

    @Autowired
    private CreditWxOrderFacade creditWxOrderFacade;

    @Autowired
    private CreditFilterService filterService;

    @Test
    public void testCheckAndCreateWxOrder() {
        CreditRequestParam<WxOrderParam> requestParam = new CreditRequestParam<WxOrderParam>();
        WxOrderParam wxOrderParam = new WxOrderParam();
        wxOrderParam.setMerchantNo("110038233");

        requestParam.setParam(wxOrderParam);

        CreditResponseData<WxOrderResp> resp = creditWxOrderFacade.checkAndCreateWxOrder(requestParam);
        System.out.println("=================");
        System.out.println(GsonUtil.getInstance().toJson(resp));
    }


    @Test
    public void queryIndustry() {
        List<Industry> industryList=  filterService.queryIndustry();
        System.out.println("=================");
        System.out.println(GsonUtil.getInstance().toJson(industryList));
    }
}
