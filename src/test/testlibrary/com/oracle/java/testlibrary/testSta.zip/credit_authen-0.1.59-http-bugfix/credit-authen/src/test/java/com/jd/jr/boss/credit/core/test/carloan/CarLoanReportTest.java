package com.jd.jr.boss.credit.core.test.carloan;

import com.jd.jr.boss.credit.authen.core.utils.FreemarkerUtil;
import com.jd.jr.boss.credit.facade.authen.api.CreditCarLoanReportFacade;
import com.jd.jr.boss.credit.facade.authen.beans.entity.PersonalAssociatedEntity;
import com.jd.jr.boss.credit.facade.authen.beans.param.CarLoanReportBatchQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.CarLoanReportQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.CarLoanReportTaskAddQueryParam;
import com.jd.jr.boss.credit.facade.authen.enums.PersonalTypeEnum;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.BaseFont;
import com.wangyin.boss.credit.admin.entity.CreditReportQueryCarloan;
import com.wangyin.boss.credit.admin.enums.CreditSewageQueryTypeEnum;
import com.wangyin.boss.credit.admin.enums.UploadFileTypeEnum;
import com.wangyin.operation.utils.GsonUtil;
import fr.opensagres.xdocreport.itext.extension.font.IFontProvider;
import freemarker.template.Configuration;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xwpf.converter.pdf.PdfConverter;
import org.apache.poi.xwpf.converter.pdf.PdfOptions;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.ResourceUtils;

import javax.annotation.Resource;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption : 车贷报告测试类
 * @date ：2018年06月14日 下午1:56:59
 * @return
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})
public class CarLoanReportTest {

    @Resource
    private CreditCarLoanReportFacade creditCarLoanReportFacade;


    @Test
    public void addCarLoanReportQueryTaskTest() {
        CreditRequestParam<CarLoanReportTaskAddQueryParam> requestParam = new CreditRequestParam<CarLoanReportTaskAddQueryParam>();
        CarLoanReportTaskAddQueryParam queryParam = new CarLoanReportTaskAddQueryParam();
        queryParam.setQueryString("刘伟的车贷公司");//  小米科技有限责任公司   刘伟的车贷公司  ywx有限责任公司 招商证券股份有限公司
        queryParam.setMerchantId(1076);
        queryParam.setMerchantNo("110040816");
        List<PersonalAssociatedEntity> personalAssociatedList = new ArrayList<PersonalAssociatedEntity>();
        PersonalAssociatedEntity entity1 = new PersonalAssociatedEntity();
        entity1.setPersonalTypeEnum(PersonalTypeEnum.LEGALPERSONNAME);
        entity1.setName("刘伟");
        entity1.setIDcard("150981197202284550");
        entity1.setMobile("18600515344");
        personalAssociatedList.add(entity1);
        PersonalAssociatedEntity entity2 = new PersonalAssociatedEntity();
        entity2.setPersonalTypeEnum(PersonalTypeEnum.EXECUETIVE);
        entity2.setName("李彦宏");
        entity2.setIDcard("150981197202284550");
        entity2.setMobile("18600515344");
        personalAssociatedList.add(entity2);
        PersonalAssociatedEntity entity3 = new PersonalAssociatedEntity();
        entity3.setPersonalTypeEnum(PersonalTypeEnum.EXECUETIVE);
        entity3.setName("许达来");
        entity3.setIDcard("150981197202284550");
        entity3.setMobile("18600515344");
        personalAssociatedList.add(entity3);
        PersonalAssociatedEntity entity4 = new PersonalAssociatedEntity();
        entity4.setPersonalTypeEnum(PersonalTypeEnum.MAJOR_SHAREHOLDER);
        entity4.setName("张三");
        entity4.setIDcard("150981197202284550");
        entity4.setMobile("18600515344");
        personalAssociatedList.add(entity4);
        queryParam.setPersonalAssociatedList(personalAssociatedList);

        queryParam.setQueryType(CreditSewageQueryTypeEnum.PRO.toName());
        requestParam.setParam(queryParam);
        requestParam.setOperator("tests");
        requestParam.setSystemId("a3884c68df2711e7a293ecf4bbcdd49c");
        requestParam.setTradeNo(RandomStringUtils.random(12));
        CreditResponseData responseData = creditCarLoanReportFacade.addCarLoanReportQueryTask(requestParam);
        System.out.println("----- responseData :" + GsonUtil.getInstance().toJson(responseData));

    }

    @Test
    public void queryCarLoanReportPageTest() {
        CreditRequestParam<CarLoanReportQueryParam> requestParam = new CreditRequestParam<CarLoanReportQueryParam>();
        CarLoanReportQueryParam queryParam = new CarLoanReportQueryParam();
        queryParam.setMerchantNo("110040816");
        queryParam.setStart(0);
        queryParam.setLimit(10);
        requestParam.setParam(queryParam);
        requestParam.setOperator("tests");
        CreditPage<CreditReportQueryCarloan> responseData = creditCarLoanReportFacade.queryCarLoanReportPage(requestParam);
        System.out.println("----- responseData :" + GsonUtil.getInstance().toJson(responseData));

    }

    @Test
    public void queryCarLoanPartResultTest() {
        CreditRequestParam<CarLoanReportQueryParam> requestParam = new CreditRequestParam<CarLoanReportQueryParam>();
        CarLoanReportQueryParam queryParam = new CarLoanReportQueryParam();
        queryParam.setId(26);
        queryParam.setResultPartType("baseReport");
        requestParam.setParam(queryParam);
        requestParam.setOperator("test");
        CreditResponseData<String> responseData = creditCarLoanReportFacade.queryCarLoanPartResult(requestParam);
        System.out.println("----- responseData :" + GsonUtil.getInstance().toJson(responseData));

    }

    @Test
    public void carloanReportPdfSupplyHandleTest() {
        try {
            CreditRequestParam<CarLoanReportQueryParam> requestParam = new CreditRequestParam<CarLoanReportQueryParam>();
            CarLoanReportQueryParam param = new CarLoanReportQueryParam();
            param.setId(231);
            requestParam.setParam(param);
            CreditResponseData<String> resp = creditCarLoanReportFacade.carloanReportPdfSupplyHandle(requestParam);
            System.out.println("--- resp : " + GsonUtil.getInstance().toJson(resp));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void toWord() throws Exception {
        Configuration cfg = new Configuration();
        cfg.setDirectoryForTemplateLoading(new File("src/main/resources/template/car_loan"));
        File wordFile = new File("D://export/card/abc.doc");
        FreemarkerUtil.process(cfg.getTemplate("main.ftl"), wordFile, null);
    }

    @Test
    public void wordToPdf() throws Exception {
        String tmp = "D:\\workspace\\credit\\credit_authen\\credit_authen-0.1.14-carload2\\credit-authen\\target\\classes\\carloan.docx";
        String target = "D:\\workspace\\credit\\credit_authen\\credit_authen-0.1.14-carload2\\credit-authen\\target\\classes\\carloan.pdf";
        String fontParam1 = "STSong-Light";
        String fontParam2 = "BaseFont.IDENTITY_H";

        InputStream sourceStream = null;
        OutputStream targetStream = null;
        XWPFDocument doc = null;
        try {
            sourceStream = new FileInputStream(tmp);
            targetStream = new FileOutputStream(target);
            doc = new XWPFDocument(sourceStream);
            PdfOptions options = PdfOptions.create();
            //中文字体处理
            options.fontProvider(new IFontProvider() {

                @Override
                public com.lowagie.text.Font getFont(java.lang.String s, java.lang.String s1, float v, int i, java.awt.Color color) {
                    try {
                        BaseFont bfChinese = BaseFont.createFont(fontParam1, fontParam2, BaseFont.NOT_EMBEDDED);
                        Font fontChinese = new Font(bfChinese);

//                        if (familyName != null)
//                            fontChinese.setFamily(familyName);
                        return fontChinese;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return null;
                    }
                }
            });
            PdfConverter.getInstance().convert(doc, targetStream, options);
            File file = new File(tmp);
            file.delete();  //刪除word文件
        } finally {
            IOUtils.closeQuietly(doc);
            IOUtils.closeQuietly(targetStream);
            IOUtils.closeQuietly(sourceStream);
        }
    }


    static final int wdDoNotSaveChanges = 0;// 不保存待定的更改。
    static final int wdFormatPDF = 17;// word转PDF 格式

    @Test
    public void html() throws FileNotFoundException {
        File ftlFile = ResourceUtils.getFile("D://export/card/html/index.html");
        File pdf = new File("D://export/card/html/index.pdf");
//        BuildHtmlPdfUtil.buildHtml(ftlFile, pdf, null);
    }

    @Test
    public void addCarLoanReportBatchQueryTest() {
        CreditRequestParam<CarLoanReportBatchQueryParam> requestParam = new CreditRequestParam<CarLoanReportBatchQueryParam>();
        requestParam.setSystemId("a3885821df2711e7a293ecf4bbcdd49c");
        requestParam.setOperator("yjl@qq.com");
        requestParam.setTradeNo("YJLTEST201809270001");
        CarLoanReportBatchQueryParam batchParam = new CarLoanReportBatchQueryParam();
        batchParam.setMerchantId(1076);
        batchParam.setFileType(UploadFileTypeEnum.ENT_CAR_LOAN_REPORT.getCode());
        batchParam.setSourceFid("1_1809_37_130");
        batchParam.setFileName("yjlfacade测试");
        batchParam.setTotalNumber(2);
        batchParam.setSuccessNumber(2);
        batchParam.setFailNumber(0);
        batchParam.setRepeatNumber(0);
        batchParam.setMerchantNo("110042475");


        List<PersonalAssociatedEntity> personalAssociatedList = new ArrayList<PersonalAssociatedEntity>();
        PersonalAssociatedEntity entity1 = new PersonalAssociatedEntity();
        entity1.setPersonalTypeEnum(PersonalTypeEnum.LEGALPERSONNAME);
        entity1.setName("刘伟");
        entity1.setIDcard("150981197202284550");
        entity1.setMobile("18600515344");
        personalAssociatedList.add(entity1);
        PersonalAssociatedEntity entity2 = new PersonalAssociatedEntity();
        entity2.setPersonalTypeEnum(PersonalTypeEnum.EXECUETIVE);
        entity2.setName("李彦宏");
        entity2.setIDcard("150981197202284550");
        entity2.setMobile("18600515344");
        personalAssociatedList.add(entity2);
        PersonalAssociatedEntity entity3 = new PersonalAssociatedEntity();
        entity3.setPersonalTypeEnum(PersonalTypeEnum.EXECUETIVE);
        entity3.setName("许达来");
        entity3.setIDcard("150981197202284550");
        entity3.setMobile("18600515344");
        personalAssociatedList.add(entity3);
        PersonalAssociatedEntity entity4 = new PersonalAssociatedEntity();
        entity4.setPersonalTypeEnum(PersonalTypeEnum.MAJOR_SHAREHOLDER);
        entity4.setName("张三");
        entity4.setIDcard("150981197202284550");
        entity4.setMobile("18600515344");
        personalAssociatedList.add(entity4);

        List<CarLoanReportTaskAddQueryParam> carloanList = new ArrayList<>();
        CarLoanReportTaskAddQueryParam addBatchParam2 = new CarLoanReportTaskAddQueryParam();
        addBatchParam2.setPersonalAssociatedList(personalAssociatedList);
        addBatchParam2.setQueryString("刘伟的车贷公司");
        addBatchParam2.setMerchantId(1076);
        addBatchParam2.setMerchantNo("110042475");
        carloanList.add(addBatchParam2);
        CarLoanReportTaskAddQueryParam addBatchParam3 = new CarLoanReportTaskAddQueryParam();
        addBatchParam3.setPersonalAssociatedList(personalAssociatedList);
        addBatchParam3.setQueryString("许达来的股东公司");
        addBatchParam3.setMerchantId(1076);
        addBatchParam3.setMerchantNo("110042475");
        carloanList.add(addBatchParam3);
        batchParam.setCarloanList(carloanList);
        batchParam.setQueryType(CreditSewageQueryTypeEnum.PRO.toName());
        requestParam.setParam(batchParam);

        CreditResponseData responseData = creditCarLoanReportFacade.addCarLoanReportBatchQuery(requestParam);
        System.out.println("-----addCarLoanReportBatchQueryTest responseData :" + GsonUtil.getInstance().toJson(responseData));

    }

}

