package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.entity.CreditBfChangeRecord;
import com.jd.jr.boss.credit.authen.core.beans.entity.CreditBfChangeRecordExample;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CreditBfChangeRecordMapper {
    long countByExample(CreditBfChangeRecordExample example);

    int deleteByExample(CreditBfChangeRecordExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CreditBfChangeRecord record);

    int insertSelective(CreditBfChangeRecord record);

    List<CreditBfChangeRecord> selectByExample(CreditBfChangeRecordExample example);

    CreditBfChangeRecord selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CreditBfChangeRecord record, @Param("example") CreditBfChangeRecordExample example);

    int updateByExample(@Param("record") CreditBfChangeRecord record, @Param("example") CreditBfChangeRecordExample example);

    int updateByPrimaryKeySelective(CreditBfChangeRecord record);

    int updateByPrimaryKey(CreditBfChangeRecord record);
}