package com.jd.jr.boss.credit.core.test;

import com.jd.jr.boss.credit.facade.authen.api.CreditFileFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditTradeInterfaceFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.EntQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import javax.annotation.Resource;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption :
 * @date ：2018/11/7 12:22
 * @return
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})
public class AutoSewageTest {

    @Resource
    private CreditFileFacade creditFileFacade;
    @Resource
    private CreditTradeInterfaceFacade creditTradeInterfaceFacade;

    @Test
    public void queryProTest(){
        String file = "/upload/elimNegReport/user_upload/20190308/110040816_1552015309804_商家排查二期（67个）.xlsx";
//        String file = "/upload/elimNegReport/user_upload/20190307/110040816_1551945630910_aaa.xlsx";
//        String file ="/upload/elimNegReport/user_upload/20181129/110040816_1543460385872_排污报告批量查询模板.xlsx";
//        String file ="/upload/elimNegReport/user_upload/20190124/110040816_1548301771221_排污报告批量查询模板.xlsx";
//        String file ="/upload/elimNegReport/user_upload/20181129/110042475_1543454491167_线上测试_排污_小米.xlsx";
//        String file ="/upload/elimNegReport/user_upload/20181129/101305013_1543497776766_排污_刘伟的车贷公司.xlsx";//ENR201811290922567572
        String startDate ="";
        String endDate ="";
        String batchNo ="ENR201903081121497413";//ENR201903071639490938
        creditFileFacade.testMethod(file,startDate,endDate,batchNo);
        System.out.println("调用完成");
    }
    @Test
    public void queryApiTest(){
        CreditRequestParam<EntQueryParam> requestParam = new CreditRequestParam<>();
        EntQueryParam entQueryParam = new EntQueryParam();
        entQueryParam.setQueryString("小米科技有限责任公司");
        entQueryParam.setMerchantId(1066);
        entQueryParam.setMerchantNo("110040816");
        entQueryParam.setMerchantName("企业商户测试201706131035220");
        requestParam.setParam(entQueryParam);
        requestParam.setTradeNo("aaa");
        requestParam.setSystemId("a3884c68df2711e7a293ecf4bbcdd49c");
        CreditResponseData<String> resp = creditTradeInterfaceFacade.doSewage(requestParam);
        System.out.println(resp);
    }
}
