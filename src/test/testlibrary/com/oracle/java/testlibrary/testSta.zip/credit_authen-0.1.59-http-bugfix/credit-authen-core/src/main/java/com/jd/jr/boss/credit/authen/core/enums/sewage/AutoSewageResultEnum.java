package com.jd.jr.boss.credit.authen.core.enums.sewage;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 排污错误结果
 * @author tangmingbo
 *
 */
public enum AutoSewageResultEnum {
    NULL(-1, null, null),
    ENT_NAME_NODATA(1, "ENT_NAME_NODATA", "企业名称未查询到结果"),
    ENT_BASIC_ERROR(2, "ENT_BASIC_ERROR", "工商信息查询失败")
    ;

    private Integer code;
    private String name;
    private String description;

    /**
     * @param description 中文描述
     */
    AutoSewageResultEnum(String description) {
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param description 中文描述
     */
    AutoSewageResultEnum(Integer code, String description) {
        this.code = code;
        this.description = description;
    }

    /**
     * @param name        英文编码名称
     * @param description 中文描述
     */
    AutoSewageResultEnum(String name, String description) {
        this.name = name;
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param name        英文编码名称
     * @param description 中文描述
     */
    AutoSewageResultEnum(Integer code, String name, String description) {
        this.code = code;
        this.name = name;
        this.description = description;
    }


    /**
     * 获取枚举类型数值编码
     */
    public Integer toCode() {
        return this.code == null ? this.ordinal() : this.code;
    }

    /**
     * 获取枚举类型英文编码名称
     */
    public String toName() {
        return this.name == null ? this.name() : this.name;
    }

    /**
     * 获取枚举类型中文描述
     */
    public String toDescription() {
        return this.description;
    }


    /**
     * 获取枚举类型中文描述
     */
    public String toString() {
        return this.description;
    }



    /**
     * 按数值获取对应的枚举类型
     *
     * @param code 数值
     * @return 枚举类型
     */
    public static AutoSewageResultEnum enumValueOf(Integer code) {
        AutoSewageResultEnum[] values = AutoSewageResultEnum.values();
        AutoSewageResultEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (code != null && code.equals(values[i].toCode())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 按英文编码获取对应的枚举类型
     *
     * @param name 英文编码
     * @return 枚举类型
     */
    public static AutoSewageResultEnum enumValueOf(String name) {
        AutoSewageResultEnum[] values = AutoSewageResultEnum.values();
        AutoSewageResultEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (name != null && name.equalsIgnoreCase(values[i].toName())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 获取枚举类型的所有<数字编码,中文描述>对
     *
     * @return
     */
    public static Map<Integer, String> toCodeDescriptionMap() {
        LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
        for (int i = 0; i < AutoSewageResultEnum.values().length; i++) {
            if (AutoSewageResultEnum.values()[i] != NULL) {
                map.put(AutoSewageResultEnum.values()[i].toCode(), AutoSewageResultEnum.values()[i].toDescription());
            }
        }
        return map;
    }

    /**
     * 获取枚举类型的所有<英文编码名称,中文描述>对
     *
     * @return
     */
    public static Map<String, String> toNameDescriptionMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        for (int i = 0; i < AutoSewageResultEnum.values().length; i++) {
            if (AutoSewageResultEnum.values()[i] != NULL) {
                map.put(AutoSewageResultEnum.values()[i].toName(), AutoSewageResultEnum.values()[i].toDescription());
            }
        }
        return map;
    }
}
