package com.jd.jr.boss.credit.core.test.listener;

import com.alibaba.fastjson.JSONObject;
import com.jd.jmq.common.message.Message;
import com.jd.jr.boss.credit.authen.core.jms.bfMonitor.CreditBfMonitorListener;
import com.jd.jr.boss.credit.authen.core.jms.customs.CreditCustomsListener;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption : 最终受益人
 * @date ：2019/1/23 16:36
 * @return
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/spring-authen.xml" })
public class CreditBfMonitorListenerTest {
    @Resource
    private CreditBfMonitorListener creditBfMonitorListener;

    @Test
    public void testMessage() throws Exception {

        List<Message> messages = new ArrayList<Message>();
        Message message = new Message();
        String text = "[{\"result\":\"{\\\"links\\\":[{\\\"from\\\":\\\"72185093\\\",\\\"id\\\":\\\"58451769\\\",\\\"properties\\\":{\\\"conprop\\\":\\\"0.77802188\\\",\\\"currency\\\":\\\"156\\\",\\\"currencyDesc\\\":\\\"人民币元\\\",\\\"subconam\\\":\\\"143934.0478\\\"},\\\"to\\\":\\\"97313457\\\",\\\"type\\\":\\\"投资\\\"},{\\\"from\\\":\\\"38072901\\\",\\\"id\\\":\\\"137616423\\\",\\\"properties\\\":{\\\"position\\\":\\\"432A\\\",\\\"positionDesc\\\":\\\"董事\\\"},\\\"to\\\":\\\"97313457\\\",\\\"type\\\":\\\"任职\\\"},{\\\"from\\\":\\\"66540188\\\",\\\"id\\\":\\\"137616422\\\",\\\"properties\\\":{\\\"position\\\":\\\"432A\\\",\\\"positionDesc\\\":\\\"董事\\\"},\\\"to\\\":\\\"97313457\\\",\\\"type\\\":\\\"任职\\\"},{\\\"from\\\":\\\"72185093\\\",\\\"id\\\":\\\"137616426\\\",\\\"properties\\\":{\\\"position\\\":\\\"431A\\\",\\\"positionDesc\\\":\\\"董事长\\\"},\\\"to\\\":\\\"97313457\\\",\\\"type\\\":\\\"任职\\\"},{\\\"from\\\":\\\"37538692\\\",\\\"id\\\":\\\"137616425\\\",\\\"properties\\\":{\\\"position\\\":\\\"432A\\\",\\\"positionDesc\\\":\\\"董事\\\"},\\\"to\\\":\\\"97313457\\\",\\\"type\\\":\\\"任职\\\"},{\\\"from\\\":\\\"72185093\\\",\\\"id\\\":\\\"137616424\\\",\\\"properties\\\":{\\\"position\\\":\\\"436A\\\",\\\"positionDesc\\\":\\\"经理\\\"},\\\"to\\\":\\\"97313457\\\",\\\"type\\\":\\\"任职\\\"},{\\\"from\\\":\\\"72185093\\\",\\\"id\\\":\\\"168914223\\\",\\\"properties\\\":{\\\"legal\\\":\\\"true\\\"},\\\"to\\\":\\\"97313457\\\",\\\"type\\\":\\\"任职\\\"}],\\\"nodes\\\":[{\\\"id\\\":\\\"38072901\\\",\\\"innode\\\":\\\"false\\\",\\\"name\\\":\\\"刘芹\\\",\\\"properties\\\":{\\\"cgzb\\\":\\\"\\\",\\\"industryphyDesc\\\":\\\"null\\\",\\\"invtypeDesc\\\":\\\"null\\\",\\\"isSyr\\\":\\\"true\\\",\\\"name\\\":\\\"刘芹\\\",\\\"palgorithmid\\\":\\\"V1!HoA6nKEfLChyro+erD3oNFoawWxZjiAMW0O4q2vVb4N7idyB03jz1qPg95uiK+NAzHetR9u5o9OY<n>bUNgkTV3mw==\\\",\\\"positionDesces\\\":\\\"董事\\\",\\\"syrType\\\":\\\"关键管理人员\\\"},\\\"type\\\":\\\"人员\\\"},{\\\"id\\\":\\\"72185093\\\",\\\"innode\\\":\\\"false\\\",\\\"name\\\":\\\"雷军\\\",\\\"properties\\\":{\\\"cgzb\\\":\\\"77.8022\\\",\\\"industryphyDesc\\\":\\\"null\\\",\\\"invtypeDesc\\\":\\\"null\\\",\\\"isSyr\\\":\\\"true\\\",\\\"name\\\":\\\"雷军\\\",\\\"palgorithmid\\\":\\\"V1!VNaFy4okESJo2mkDLm+kRvU1y8YmewSj32v4r1aOXql+ikhYAUOxFA4UN8HlC1kmA9hRKkmi+lLa<n>/KYfPCPSDw==\\\",\\\"positionDesces\\\":\\\"董事长,经理,法人\\\",\\\"syrType\\\":\\\"直接或间接控股,关键管理人员\\\"},\\\"type\\\":\\\"人员\\\"},{\\\"id\\\":\\\"37538692\\\",\\\"innode\\\":\\\"false\\\",\\\"name\\\":\\\"林斌\\\",\\\"properties\\\":{\\\"cgzb\\\":\\\"\\\",\\\"industryphyDesc\\\":\\\"null\\\",\\\"invtypeDesc\\\":\\\"null\\\",\\\"isSyr\\\":\\\"true\\\",\\\"name\\\":\\\"林斌\\\",\\\"palgorithmid\\\":\\\"V1!fNHSLrlbR33B+889yN5iOgLBCFSaYsPKsoajPqzeH9YPojCEKgvk+2n0mG0g1Ag8gsB2/NNltg4k<n>AWWxwgH9Rw==\\\",\\\"positionDesces\\\":\\\"董事\\\",\\\"syrType\\\":\\\"关键管理人员\\\"},\\\"type\\\":\\\"人员\\\"},{\\\"id\\\":\\\"66540188\\\",\\\"innode\\\":\\\"false\\\",\\\"name\\\":\\\"许达来\\\",\\\"properties\\\":{\\\"cgzb\\\":\\\"\\\",\\\"industryphyDesc\\\":\\\"null\\\",\\\"invtypeDesc\\\":\\\"null\\\",\\\"isSyr\\\":\\\"true\\\",\\\"name\\\":\\\"许达来\\\",\\\"palgorithmid\\\":\\\"V1!GlP+jM9FfMTWl8B5zXJOfw8s/QqUTkX/ZEr5yvIGBB5xOp8drfuZXp3xDLKWYakVms6d40gYmoTn<n>MHEmX0Q4lQ==\\\",\\\"positionDesces\\\":\\\"董事\\\",\\\"syrType\\\":\\\"关键管理人员\\\"},\\\"type\\\":\\\"人员\\\"},{\\\"id\\\":\\\"97313457\\\",\\\"innode\\\":\\\"true\\\",\\\"name\\\":\\\"小米科技有限责任公司\\\",\\\"properties\\\":{\\\"cgzb\\\":\\\"\\\",\\\"creditcode\\\":\\\"91110108551385082Q\\\",\\\"entstatus\\\":\\\"1\\\",\\\"esdate\\\":\\\"2010-03-03\\\",\\\"industryphy\\\":\\\"M\\\",\\\"industryphyDesc\\\":\\\"科学研究和技术服务业\\\",\\\"invtypeDesc\\\":\\\"null\\\",\\\"isSyr\\\":\\\"false\\\",\\\"islist\\\":\\\"0\\\",\\\"name\\\":\\\"小米科技有限责任公司\\\",\\\"positionDesces\\\":\\\"\\\",\\\"regcap\\\":\\\"185000.0000\\\",\\\"regcapcur\\\":\\\"156\\\",\\\"regno\\\":\\\"110108012660422\\\",\\\"syrType\\\":\\\"\\\"},\\\"type\\\":\\\"企业\\\"}]}\",\"userPin\":\"eb38e23da758458c9904c34cc8c495db\",\"entName\":\"小米科技有限责任公司\"}]";
        message.setText(text);
        messages.add(message);
        creditBfMonitorListener.onMessage(messages);

    }
}
