package com.jd.jr.boss.credit.authen.core.facade;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.service.PopRelationQueryService;
import com.jd.jr.boss.credit.facade.authen.api.PopRelationBatchFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.PopRelationParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.creditReport.CreateReportResponse;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.PopRelationFacade;
import com.wangyin.boss.credit.admin.enums.UploadFileTypeEnum;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.Date;

/**
 * created by ChenKaiJu on 2018/12/11  11:39
 */
@Service
public class PopRelationBatchFacadeImpl implements PopRelationBatchFacade {
    private Logger logger = LoggerFactory.getLogger(PopRelationBatchFacadeImpl.class);

    @Resource
    PopRelationQueryService popRelationQueryService;

    @Override
    public CreditResponseData batchQuery(CreditRequestParam<PopRelationParam> requestParam) {
        logger.info("PopRelationBatchFacade batchQuery begin,param:{}", JSONObject.toJSONString(requestParam ));
        CreditResponseData creditResponseData = new CreditResponseData();
        CreateReportResponse result = new CreateReportResponse();
        try {
            if (requestParam == null || requestParam.getParam() == null|| StringUtil.isEmpty(requestParam.getParam().getFileId())) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("PopRelationBatchFacade batchQuery error, requestParam is null");
                return creditResponseData;
            }
            Date now = new Date();
            logger.info("PopRelationBatchFacade batchQuery save to database");
            String batchNo = null;
            try {
                batchNo = popRelationQueryService.saveBatchAndOrder(requestParam.getParam(), UploadFileTypeEnum.POP_RELATION_IMPORT.getCode());
            } catch (Exception e) {
                logger.info(e.getMessage());
            }
            if (StringUtil.isNotEmpty(batchNo)) {
                logger.info("异步调用查询接口");
                popRelationQueryService.batchTrade(requestParam.getParam(), batchNo);
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(result);
            } else {
                creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
                creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
                creditResponseData.setSuccess(false);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            logger.info("batchTrade finished,response:{}", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }
}
