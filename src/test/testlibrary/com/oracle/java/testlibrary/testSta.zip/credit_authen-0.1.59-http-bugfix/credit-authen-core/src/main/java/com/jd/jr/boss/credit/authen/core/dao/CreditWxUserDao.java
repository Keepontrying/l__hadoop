package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.facade.authen.beans.param.WxUserParam;
import com.wangyin.boss.credit.admin.entity.CreditWxUser;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * 用户 微信关联表
 * @author liuwei
 * @since 2017.03.29
 */
@Repository
public interface CreditWxUserDao {
	/**
	 * 获取用户绑定信息
	 * @param creditWxUser
	 * @return
	 */
	List<CreditWxUser> getWxUser(CreditWxUser creditWxUser);
	/**
	 * 插入绑定信息
	 * @param creditWxUser
	 * @return
	 */
	boolean insertWxUser(CreditWxUser creditWxUser);
	/**
	 * 更新绑定信息
	 * @param creditWxUser
	 * @return
	 */
	boolean updateWxUser(CreditWxUser creditWxUser);
	/**
	 * 解绑
	 * @param param
	 * @return
	 */
	boolean unbindingWx(WxUserParam param);
	/**
	 * 查询商户下所有微信用户
	 * @return
	 */
	List<CreditWxUser> getWxUserByParam(WxUserParam param);

	/**
	 * 根据登录账号获取通知的openid
	 * @param creator
	 */
	List<String> getWxUserByLoginName(String creator);
}