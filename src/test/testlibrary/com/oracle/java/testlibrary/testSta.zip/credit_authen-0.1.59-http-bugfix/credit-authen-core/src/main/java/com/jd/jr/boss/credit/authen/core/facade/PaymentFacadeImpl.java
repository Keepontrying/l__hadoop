package com.jd.jr.boss.credit.authen.core.facade;

import com.jd.jr.boss.credit.authen.core.beans.entity.ProductStrategyEntity;
import com.jd.jr.boss.credit.authen.core.beans.request.ProductStrategyQueryParam;
import com.jd.jr.boss.credit.authen.core.service.OrderService;
import com.jd.jr.boss.credit.authen.core.service.PaymentService;
import com.jd.jr.boss.credit.authen.core.service.ProductService;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;
import com.jd.jr.boss.credit.domain.common.entity.CreditPayment;
import com.jd.jr.boss.credit.domain.common.enums.*;
import com.jd.jr.boss.credit.facade.site.api.CreditPaymentFacade;
import com.jd.jr.boss.credit.facade.site.api.dto.request.payment.PaymentReceiptPushRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.payment.PaymentReceiptQueryRequest;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by anmeng on 2017/1/4.
 */
@Service
public class PaymentFacadeImpl implements CreditPaymentFacade {
    private static Logger logger= LoggerFactory.getLogger(PaymentFacadeImpl.class);

    @Autowired
    private OrderService orderService;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private ProductService productService;

    @Override
    public ResponseData pushPaymentReceipt(RequestParam<PaymentReceiptPushRequest> requestParam) {
        logger.info("推送缴费单入参："+ GsonUtil.getInstance().toJson(requestParam));

        ResponseData responseData=new ResponseData();

        PaymentReceiptPushRequest request=requestParam.getParam();
        if (StringUtil.isBlank(request.getMerchantNo())) {
            return this.returnFailResp("参数错误：商户号" + request.getMerchantNo());
        }
        String merchantNo=request.getMerchantNo();
        CreditPaymentChannelEnum paymentChannel=request.getPaymentChannel();

        try {
            Set<String> unpaidSet=this.genUnpaidSet(merchantNo,paymentChannel);

            if(CreditPaymentChannelEnum.PACKAGE_MANUAL.equals(paymentChannel)){
                Integer strategyId=request.getStrategyId();

                if(strategyId==null){
                    return this.returnFailResp("参数错误：计费策略为空！");
                }

                if(unpaidSet.contains(strategyId+"")){
                    return this.returnFailResp("参数错误：当前计费策略存在未缴费的记录！"+strategyId);
                }

                //生成订购记录
                ProductStrategyQueryParam strategyQueryParam = new ProductStrategyQueryParam();
                strategyQueryParam.setStrategyId(strategyId);
                ProductStrategyEntity product=productService.queryStrategyEntityById(strategyQueryParam);
                CreditOrder order=orderService.createOrderByStrategy(product, CreditOrderStatusEnum.UNPAID, CreditOrderSourceEnum.MANUAL);
                //推送缴费单
                CreditPayment payment=new CreditPayment();
                payment.setMerchantNo(merchantNo);
                payment.setPayChannel(paymentChannel);
                payment.setOrderId(order.getOrderId()+"");
                payment.setContractId(product.getContractId()+"");
                payment.setAmount(BigDecimal.valueOf(product.getAmount()));
                payment.setStrategyChargeType(ProductChargeTypeEnum.PACKAGE);

                List<ProductStrategyEntity> strategyEntityList=new ArrayList<ProductStrategyEntity>();
                strategyEntityList.add(product);

                paymentService.pushPayment(payment,strategyEntityList);

            }else if(CreditPaymentChannelEnum.SINGLE_MANUAL.equals(paymentChannel)){
                String contractId=request.getContractId();
                if(StringUtil.isBlank(contractId)){
                    return this.returnFailResp("参数错误：合同号不能为空！");
                }

                if(unpaidSet.contains(contractId)){
                    return this.returnFailResp("参数错误：当前合同存在未缴费的记录！"+contractId);
                }
                //推送缴费单
                CreditPayment payment=new CreditPayment();
                payment.setMerchantNo(merchantNo);
                payment.setPayChannel(paymentChannel);
                payment.setContractId(contractId);
                payment.setAmount(request.getAmount());
                payment.setStrategyChargeType(ProductChargeTypeEnum.SINGLE);
                paymentService.pushPayment(payment,null);
            }else{
                return this.returnFailResp("参数错误:缴费类型"+paymentChannel);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            return this.returnFailResp(e.getMessage());
        }

        return responseData;
    }

    @Override
    public ResponseData<Set<String>> queryPaymentReceiptUnpaid(RequestParam<PaymentReceiptQueryRequest> requestParam) {
        logger.info("查询未缴费记录入参："+ GsonUtil.getInstance().toJson(requestParam));
        ResponseData<Set<String>> responseData=new ResponseData<Set<String>>();

        PaymentReceiptQueryRequest queryRequest=requestParam.getParam();
        String merchantNo=queryRequest.getMerchantNo();
        CreditPaymentChannelEnum paymentChannel=queryRequest.getPaymentChannel();

        if(StringUtil.isBlank(merchantNo)){
            return this.returnFailResp("参数错误:商户号为空！");
        }

        if(paymentChannel==null){
            return this.returnFailResp("参数错误:缴费类型不能为空！");
        }

        Set<String> resultSet=this.genUnpaidSet(merchantNo,paymentChannel);

        responseData.setData(resultSet);
        logger.info("查询未缴费记录出参："+GsonUtil.getInstance().toJson(responseData));
        return responseData;
    }

    private ResponseData returnFailResp(String msg){
        ResponseData responseData=new ResponseData();
        logger.error(msg);
        responseData.setSuccess(false);
        responseData.setMessage(msg);
        responseData.setCode("FAIL");
        return responseData;
    }

    /**
     * 查询未支付的列表
     * @param merchantNo
     * @param channelEnum
     * @return
     */
    private Set<String> genUnpaidSet(String merchantNo,CreditPaymentChannelEnum channelEnum){
        Set<String> resultSet=new HashSet<String>();
        if(CreditPaymentChannelEnum.SINGLE_MANUAL.equals(channelEnum)){
            List<CreditPayment> paymentList=paymentService.queryPaymentUnpaid(merchantNo,ProductChargeTypeEnum.SINGLE);
            for(CreditPayment payment:paymentList){
                resultSet.add(payment.getContractId());
            }
        }else{
            List<CreditOrder> orderList=orderService.queryUnpaidCreditOrder(merchantNo);
            for(CreditOrder order:orderList){
                resultSet.add(order.getStrategyId()+"");
            }
        }
        return resultSet;
    }
}
