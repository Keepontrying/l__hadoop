package com.jd.jr.boss.credit.authen.core.scheduler;


import com.jd.jr.boss.credit.authen.core.service.BillService;
import com.jd.jr.boss.credit.authen.core.service.CreditSummarizeService;
import com.wangyin.boss.credit.admin.entity.CreditSummarize;
import com.wangyin.boss.credit.admin.enums.MerchantClassifyEnum;
import com.wangyin.boss.credit.admin.enums.SummarizeTypeEnum;
import com.wangyin.commons.util.Logger;
import com.wangyin.schedule.client.job.ScheduleContext;
import com.wangyin.schedule.client.job.SchedulerJob;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

/**
 *
 * <ul>
 * <li>1、开发日期：2018年1月12日</li>
 * <li>2、开发时间：下午2:22:17</li>
 * <li>3、作 者：zhanghui12</li>
 * <li>4、类型名称：CallCaseSummarizeJob</li>
 * <li>5、类型意图：产品调用情况汇总 每个月一号凌晨自动执行</li>
 * </ul>
 *
 */
@Service
public class CallCaseSummarizeJob implements SchedulerJob {
	private Logger logger = new Logger(CallCaseSummarizeJob.class);
	@Autowired
	private BillService billService;
	@Autowired
	private CreditSummarizeService creditSummarizeService;
	@Override
	public void doJob(ScheduleContext scheduleContext) throws Exception {
		logger.info("产品调用情况汇总定时任务开始" + System.currentTimeMillis());
		try {
			Map<String, String> userDefineParams = scheduleContext.getParameters();
			// 获取参数
			SummarizeTypeEnum summarizeType = null;
			String monthDate = userDefineParams.get("monthDate");
			String summType = userDefineParams.get("summarizeType");
			if (StringUtils.isBlank(monthDate)) {
				Calendar c=Calendar.getInstance();
				c.setTime(new Date());
				c.set(Calendar.MONTH,c.get(Calendar.MONTH)-1);
				monthDate = DateFormatUtils.format(c.getTime(),"yyyy-MM");
			} else {
				monthDate = DateTime.parse(monthDate).toString("yyyy-MM");
			}
			if (!StringUtils.isBlank(summType)) {
				summarizeType = SummarizeTypeEnum.valueOf(summType);
			}
			logger.info("monthDate=" + monthDate + ",summarizeType=" + summarizeType);
			if (summarizeType != null && summarizeType != SummarizeTypeEnum.ORGANIZATION) {// 指定某些产品
				productHandle(summarizeType, monthDate);
			} else if (summarizeType != null && summarizeType == SummarizeTypeEnum.ORGANIZATION) {// 指定计算新增机构
				organizationHandle(monthDate);
			} else {// summarizeType==null,默认定时任务
				productHandle(SummarizeTypeEnum.ENT_SCORE_QUERY, monthDate);
				productHandle(SummarizeTypeEnum.ENTERPRISE_REPORT_QUERY_BASIC, monthDate);
				productHandle(SummarizeTypeEnum.OTHER_PRO, monthDate);
				organizationHandle(monthDate);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		logger.info("产品调用情况汇总定时任务开始结束" + System.currentTimeMillis());
	}

	/*
	 * 新增机构汇总
	 */
	private void organizationHandle(String monthDate) {
		CreditSummarize creditSummarize = new CreditSummarize();
		creditSummarize.setSummarizeType(SummarizeTypeEnum.ORGANIZATION);
		creditSummarize.setMonthDate(monthDate);
		// 月
		String startDate = getMonthStartDate(monthDate);
		String endDate = getMonthEndDate(monthDate);
		List<String> financeMerchantList = billService.queryAfterMerchant(MerchantClassifyEnum.FINANCE, startDate,endDate);
		queryCount(financeMerchantList, startDate);
		creditSummarize.setFinanceMonthCount(financeMerchantList.size());

		List<String> departMerchantList = billService.queryAfterMerchant(MerchantClassifyEnum.JUSTICE_DEPARTMENT,
				startDate,endDate);
		queryCount(departMerchantList, startDate);
		creditSummarize.setDepartmentMonthCount(departMerchantList.size());

		List<String> nonFinanceMerchantList = billService.queryAfterMerchant(MerchantClassifyEnum.NON_FINANCE,
				startDate,endDate);
		queryCount(nonFinanceMerchantList, startDate);
		creditSummarize.setNonFinanceMonthCount(nonFinanceMerchantList.size());

		List<String> otherMerchantList = billService.queryAfterMerchant(MerchantClassifyEnum.OTHER, startDate,endDate);
		queryCount(otherMerchantList, startDate);
		creditSummarize.setOtherMonthCount(otherMerchantList.size());
		// 年
		String yearStartDate = getYearStartDate(monthDate);
		List<String> yearFinanceMerchantList = billService.queryAfterMerchant(MerchantClassifyEnum.FINANCE,
				yearStartDate,endDate);
		queryCount(yearFinanceMerchantList, yearStartDate);
		creditSummarize.setFinanceYearCount(yearFinanceMerchantList.size());

		List<String> yearDepartMerchantList = billService.queryAfterMerchant(MerchantClassifyEnum.JUSTICE_DEPARTMENT,
				yearStartDate,endDate);
		queryCount(yearDepartMerchantList, yearStartDate);
		creditSummarize.setDepartmentYearCount(yearDepartMerchantList.size());

		List<String> yearNonFinanceMerchantList = billService.queryAfterMerchant(MerchantClassifyEnum.NON_FINANCE,
				yearStartDate,endDate);
		queryCount(yearNonFinanceMerchantList, yearStartDate);
		creditSummarize.setNonFinanceYearCount(yearNonFinanceMerchantList.size());

		List<String> yearOtherMerchantList = billService.queryAfterMerchant(MerchantClassifyEnum.OTHER, yearStartDate,endDate);
		queryCount(yearOtherMerchantList, yearStartDate);
		creditSummarize.setOtherYearCount(yearOtherMerchantList.size());

		// 总的

		List<String> totalFinanceMerchantList = billService.queryAfterMerchant(MerchantClassifyEnum.FINANCE,null,
				endDate);
		creditSummarize.setFinanceTotalCount(totalFinanceMerchantList.size());

		List<String> totalDepartMerchantList = billService.queryAfterMerchant(MerchantClassifyEnum.JUSTICE_DEPARTMENT,null,
				endDate);
		creditSummarize.setDepartmentTotalCount(totalDepartMerchantList.size());

		List<String> totalNonFinanceMerchantList = billService.queryAfterMerchant(MerchantClassifyEnum.NON_FINANCE,null,
				endDate);
		creditSummarize.setNonFinanceTotalCount(totalNonFinanceMerchantList.size());

		List<String> totalOtherMerchantList = billService.queryAfterMerchant(MerchantClassifyEnum.OTHER, null,endDate);
		creditSummarize.setOtherTotalCount(totalOtherMerchantList.size());

		creditSummarize
				.setSumMonthCount(creditSummarize.getFinanceMonthCount() + creditSummarize.getNonFinanceMonthCount()
						+ creditSummarize.getDepartmentMonthCount() + creditSummarize.getOtherMonthCount());
		creditSummarize.setSumYearCount(creditSummarize.getFinanceYearCount() + creditSummarize.getNonFinanceYearCount()
				+ creditSummarize.getDepartmentYearCount() + creditSummarize.getOtherYearCount());
		creditSummarize
				.setSumTotalCount(creditSummarize.getFinanceTotalCount() + creditSummarize.getNonFinanceTotalCount()
						+ creditSummarize.getDepartmentTotalCount() + creditSummarize.getOtherTotalCount());

		CreditSummarize summ = creditSummarizeService.querySummarize(creditSummarize);
		if (summ != null) {
			creditSummarize.setId(summ.getId());
			creditSummarizeService.updateSummarize(creditSummarize);
		} else {
			creditSummarizeService.saveSummarize(creditSummarize);
		}
	}

	private void queryCount(List<String> merchantList, String startDate) {
		Iterator<String> it = merchantList.iterator();
		while (it.hasNext()) {
			Integer count = billService.queryBeforeCount(it.next(), startDate);
			if (count != null && count != 0) {
				it.remove();
			}
		}
	}
	/*
	 * 产品调用情况汇总
	 */
	private void productHandle(SummarizeTypeEnum summarizeType, String monthDate) {
		CreditSummarize creditSummarize = new CreditSummarize();
		creditSummarize.setSummarizeType(summarizeType);
		creditSummarize.setMonthDate(monthDate);
		List<Map<String, Object>> monthSumm = new ArrayList<Map<String, Object>>();
		String startDate = getMonthStartDate(monthDate);
		String endDate = getMonthEndDate(monthDate);
		monthSumm = billService.queryProCallCaseSummarize(startDate, endDate, summarizeType.getCode());
		for (Map map : monthSumm) {
			if (MerchantClassifyEnum.FINANCE.getCode().equalsIgnoreCase((String) map.get("classify"))) {
				creditSummarize.setFinanceMonthCount(((BigDecimal) map.get("count")).intValue());
			}
			if (MerchantClassifyEnum.NON_FINANCE.getCode().equalsIgnoreCase((String) map.get("classify"))) {
				creditSummarize.setNonFinanceMonthCount(((BigDecimal) map.get("count")).intValue());
			}
			if (MerchantClassifyEnum.JUSTICE_DEPARTMENT.getCode().equalsIgnoreCase((String) map.get("classify"))) {
				creditSummarize.setDepartmentMonthCount(((BigDecimal) map.get("count")).intValue());
			}
			if (MerchantClassifyEnum.OTHER.getCode().equalsIgnoreCase((String) map.get("classify"))) {
				creditSummarize.setOtherMonthCount(((BigDecimal) map.get("count")).intValue());
			}
		}

		List<Map<String, Object>> yearSumm = new ArrayList<Map<String, Object>>();
		String yearStart = getYearStartDate(monthDate);
		String yearEnd = getMonthEndDate(monthDate);
		yearSumm = billService.queryProCallCaseSummarize(yearStart, yearEnd, summarizeType.getCode());
		for (Map map : yearSumm) {
			if (MerchantClassifyEnum.FINANCE.getCode().equalsIgnoreCase((String) map.get("classify"))) {
				creditSummarize.setFinanceYearCount(((BigDecimal) map.get("count")).intValue());
			}
			if (MerchantClassifyEnum.NON_FINANCE.getCode().equalsIgnoreCase((String) map.get("classify"))) {
				creditSummarize.setNonFinanceYearCount(((BigDecimal) map.get("count")).intValue());
			}
			if (MerchantClassifyEnum.JUSTICE_DEPARTMENT.getCode().equalsIgnoreCase((String) map.get("classify"))) {
				creditSummarize.setDepartmentYearCount(((BigDecimal) map.get("count")).intValue());
			}
			if (MerchantClassifyEnum.OTHER.getCode().equalsIgnoreCase((String) map.get("classify"))) {
				creditSummarize.setOtherYearCount(((BigDecimal) map.get("count")).intValue());
			}
		}

		List<Map<String, Object>> totalSumm = new ArrayList<Map<String, Object>>();
		yearEnd = getMonthEndDate(monthDate);
		totalSumm = billService.queryProCallCaseSummarize(null, yearEnd, summarizeType.getCode());
		for (Map map : totalSumm) {
			if (MerchantClassifyEnum.FINANCE.getCode().equalsIgnoreCase((String) map.get("classify"))) {
				creditSummarize.setFinanceTotalCount(((BigDecimal) map.get("count")).intValue());
			}
			if (MerchantClassifyEnum.NON_FINANCE.getCode().equalsIgnoreCase((String) map.get("classify"))) {
				creditSummarize.setNonFinanceTotalCount(((BigDecimal) map.get("count")).intValue());
			}
			if (MerchantClassifyEnum.JUSTICE_DEPARTMENT.getCode().equalsIgnoreCase((String) map.get("classify"))) {
				creditSummarize.setDepartmentTotalCount(((BigDecimal) map.get("count")).intValue());
			}
			if (MerchantClassifyEnum.OTHER.getCode().equalsIgnoreCase((String) map.get("classify"))) {
				creditSummarize.setOtherTotalCount(((BigDecimal) map.get("count")).intValue());
			}
		}
		creditSummarize
				.setSumMonthCount(creditSummarize.getFinanceMonthCount() + creditSummarize.getNonFinanceMonthCount()
						+ creditSummarize.getDepartmentMonthCount() + creditSummarize.getOtherMonthCount());
		creditSummarize.setSumYearCount(creditSummarize.getFinanceYearCount() + creditSummarize.getNonFinanceYearCount()
				+ creditSummarize.getDepartmentYearCount() + creditSummarize.getOtherYearCount());
		creditSummarize
				.setSumTotalCount(creditSummarize.getFinanceTotalCount() + creditSummarize.getNonFinanceTotalCount()
						+ creditSummarize.getDepartmentTotalCount() + creditSummarize.getOtherTotalCount());
		CreditSummarize summ = creditSummarizeService.querySummarize(creditSummarize);
		if (summ != null) {
			creditSummarize.setId(summ.getId());
			creditSummarizeService.updateSummarize(creditSummarize);
		} else {
			creditSummarizeService.saveSummarize(creditSummarize);
		}
	}

	private String getYearStartDate(String monthDate) {
		String year = monthDate.substring(0, monthDate.indexOf('-'));
		return year + "-01-01";
	}

	private String getMonthEndDate(String monthDate) {

		return monthDate + "-31";
	}

	private String getMonthStartDate(String monthDate) {
		return monthDate + "-01";
	}
}
