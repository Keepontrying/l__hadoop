package com.jd.jr.boss.credit.core.test.signCode;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.jd.jr.boss.credit.authen.core.utils.ExcelUtil;

/**
 * 企业名称查询证件号码
 */
public class TestEntBasicInfoDemo {
	private static Logger logger = LoggerFactory.getLogger(TestEntBasicInfoDemo.class);
	/**
	 * demo只确保接口api可用，并且处理post请求前参数，json串生成方式和传入参数请自行处理
	 * @param args
	 */
	public static void main(String[] args) {
		logger.info("处理开始");
			String applyUrl="https://icredit.jd.com/search/free/company?queryName=";
			try {
				String srcName = "D:\\京小贷-已贷用户-中征码.xlsx";
				String destName="D:\\中征码参数.xlsx";
				List<CompanyParam> sheetList = new ArrayList<CompanyParam>();
				InputStream inputStream = new FileInputStream(new File(srcName));
			ExcelUtil excelUtil = new ExcelUtil();
			List<List<String>> dataList = excelUtil.read(inputStream, false,1);
			int index=1;
			logger.info("读取excel开始:共"+dataList.size()+"行");
			final long startTime = System.currentTimeMillis();
			logger.info("开始日期"+DateTime.now().toString("yyyy-MM-dd HH:mm:ss"));
			if(dataList!=null&&dataList.size()>0){
				ExecutorService exec = Executors.newCachedThreadPool();//工头
				ArrayList<Future<Map<Integer,List<CompanyParam>>>> results = new ArrayList<Future<Map<Integer,List<CompanyParam>>>>();//
				List<List<List<String>>> subSets = Lists.partition(dataList, 1000);
				logger.info("处理数据开始:共"+subSets.size()+"线程");
				for(List<List<String>> subSet:subSets){
				    results.add(exec.submit(new TaskCallable(subSet,applyUrl,index)));//submit返回一个Future，代表了即将要返回的结果
				    index++;
				}
				//排序
				Collections.sort(results, new Comparator<Future<Map<Integer,List<CompanyParam>>>>() {
					@Override
					public int compare(
							Future<Map<Integer, List<CompanyParam>>> o1,
							Future<Map<Integer, List<CompanyParam>>> o2) {
						// TODO Auto-generated method stub 
						try {
							Integer o1Index = o1.get().keySet().iterator().next();
							Integer o2Index = o2.get().keySet().iterator().next();
							return o1Index.compareTo(o2Index);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (ExecutionException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return 0;
					}
				});
				for(Future<Map<Integer,List<CompanyParam>>> future:results){
					Map<Integer,List<CompanyParam>> map = future.get();
					sheetList.addAll(map.values().iterator().next());
				}
			}
			logger.info("查询数据耗时s："+(System.currentTimeMillis()-startTime)/1000);
			logger.info("写入excel开始");
			createExcel(sheetList,destName);
			logger.info("写入excel处理完成");
			logger.info("结束日期"+DateTime.now().toString("yyyy-MM-dd HH:mm:ss"));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	private static void createExcel(List<CompanyParam> sheetList,String destName){
			String[] titles = {"序号", "企业名称", "工商注册号", "统一社会信用代码", "组织机构代码", "国别", "备注"};
			    String[] properties = {"serialNo", "name", "regNo", "creditCode", "orgNo", "capital", "remark"};
			    String workSheetName = "sheet";
			    OutputStream baos = null;
			    try {
			    SXSSFWorkbook wb = new SXSSFWorkbook(3009);// 创建工作薄
			    if(sheetList!=null&&sheetList.size()>0){
			    	baos = new FileOutputStream(new File(destName));
					ExcelUtil.export(wb, baos, workSheetName, titles, properties, sheetList , "", CompanyParam.class, null, 0);
					wb.write(baos);
			        wb.dispose();
			        //存储文件
			    }
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(baos!=null){
       		 try {
				baos.flush();
				baos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
                
       	}
		}
	}
	
}

