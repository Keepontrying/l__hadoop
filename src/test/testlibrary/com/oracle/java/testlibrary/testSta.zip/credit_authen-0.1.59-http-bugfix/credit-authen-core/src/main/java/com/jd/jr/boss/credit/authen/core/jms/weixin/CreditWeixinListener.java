package com.jd.jr.boss.credit.authen.core.jms.weixin;

import com.alibaba.fastjson.JSON;
import com.google.gson.JsonSyntaxException;
import com.jd.jr.boss.credit.authen.core.service.CreditUserService;
import com.jd.jr.boss.credit.authen.core.service.CreditWxUserService;
import com.jd.jr.boss.credit.authen.core.service.VipAlarmService;
import com.jd.jr.boss.credit.facade.authen.beans.param.VipChangeQueryParam;
import com.jd.jr.boss.credit.gateway.unc.constance.GatewayUncConstance;
import com.jd.jr.boss.credit.gateway.unc.constants.TemplateCodeConstants;
import com.jd.jr.boss.credit.gateway.unc.constants.WxRemindConstants;
import com.jd.jr.boss.credit.gateway.unc.enums.WxEventTypeEnum;
import com.jd.jr.boss.credit.gateway.unc.facade.weixin.GatewayUncWxFacade;
import com.jd.jr.boss.credit.gateway.unc.utils.FlowNoUtils;
import com.jd.jsf.gd.util.StringUtils;
import com.jdjr.fmq.client.consumer.MessageListener;
import com.jdjr.fmq.common.message.Message;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.boss.credit.admin.entity.CreditVipAlarmDetailResult;
import com.wangyin.boss.credit.admin.entity.CreditVipAlarmResult;
import com.wangyin.boss.credit.admin.entity.CreditWxUser;
import com.wangyin.boss.credit.admin.enums.CreditWxUserStatusEnum;
import com.wangyin.boss.credit.admin.enums.VipAlarmEventEnum;
import com.wangyin.boss.credit.admin.enums.VipAlarmLevelEnum;
import com.wangyin.operation.utils.GsonUtil;
import com.wangyin.weixin.api.domain.WeixinMessageInfo;
import com.wangyin.weixin.api.domain.user.UserInfo;
import com.wangyin.weixin.api.facade.UserInfoFacade;
import com.wangyin.weixin.api.result.SingleResult;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 微信结果监听
 *
 * @author jiangbo
 * @since 2017/7/6
 */
@Component("creditWeixinListener")
public class CreditWeixinListener implements MessageListener {

    private static Logger LOGGER = LoggerFactory.getLogger(CreditWeixinListener.class);

    @Resource
    private CreditWxUserService creditWxUserService;

    @Resource
    private CreditUserService creditUserService;

    @Resource
    private GatewayUncWxFacade gatewayUncWxFacade;

    @Resource
    protected VipAlarmService vipAlarmService;
    @Resource
    private UserInfoFacade userInfoFacade;

    @Override
    public void onMessage(List<Message> messages) throws Exception {

        if (messages == null || messages.isEmpty()) {
            LOGGER.warn("CreditWeixinListener message is null");
            return;
        }
        for (Message message : messages) {
            String objectJson = message.getText();
            WeixinMessageInfo messageInfo;
            try {
                messageInfo = JSON.parseObject(objectJson, WeixinMessageInfo.class);
            } catch (JsonSyntaxException e) {
                LOGGER.error("message json format error：" + objectJson);
                continue;
            }

            try {
                if (null == messageInfo) {
                    LOGGER.info("format batchMqVo error,batchMqVo:{}", GsonUtil.getInstance().toJson(messageInfo));
                    continue;
                }

                if (ConfigUtil.getString(TemplateCodeConstants.SYSTEM_ID).equals(messageInfo.getSystemId())) {
                    LOGGER.info("CreditWeixinListener message, body part:{}", objectJson);
                    SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
                    String openId = messageInfo.getFromUserName();
                    String bizNo = FlowNoUtils.createFlowNo("authenWx");
                    String appCode = ConfigUtil.getString(GatewayUncConstance.UNC_CLIENT_APPCODE);
                    CreditWxUser wxUserParam = new CreditWxUser();
                    wxUserParam.setOpenId(openId);
                    wxUserParam.setStatuts(CreditWxUserStatusEnum.BIND.toName());
                    List<CreditWxUser> wxUsers = creditWxUserService.getWxUser(wxUserParam);
                    boolean binding = false;
                    if (CollectionUtils.isNotEmpty(wxUsers)) {//已绑定
                        binding = true;
                    }
                    //eventType 是subscribe 代表关注；click 代表菜单点击  从eventKey可知道具体的菜单
                    String eventType = messageInfo.getEventType();
                    boolean res = false;
                    String wxTemplateUrl = "";
                    boolean insertbing = false;
                    Map<String, Object> templateParams = new HashMap<String, Object>();
                    String eventKey = messageInfo.getEventKey();
                    Integer userId = null;
                    Date triggerTime = null;

                    if (WxEventTypeEnum.SUBSCRIBE.toName().equals(eventType)) {//关注
                        res = gatewayUncWxFacade.sendWxByUnc(openId, wxTemplateUrl, bizNo, templateParams, TemplateCodeConstants.CREDIT_WX_FOCUS, appCode);
                        if (!binding) {//没有绑定并且是通过带参二维码进入的 获取用户信息 进行绑定
                            if (StringUtils.isNotBlank(eventKey)) {//通过带参二维码进入
                                System.out.println("eventKey:" + eventKey);
                                //事件KEY值，qrscene_为前缀，后面为二维码的参数值
                                System.out.println(eventKey.substring(8, eventKey.length()));
                                userId = Integer.valueOf(eventKey.substring(8, eventKey.length()));
                                insertbing = true;
                            } else {//通过正常关注进入 提示绑定
                                res = gatewayUncWxFacade.sendWxByUnc(openId, wxTemplateUrl, bizNo, templateParams, TemplateCodeConstants.CREDIT_WX_PREBINDING, appCode);
                            }
                        }
                        LOGGER.error("发送微信消息结果：", res);
                    } else if (WxEventTypeEnum.CLICK.toName().equals(eventType) && "myWarning".equals(eventKey)) {//点击菜单
                        if (binding) {//发送通知消息
                            //查询商户下变更信息
                            CreditUser user = creditUserService.selectCreditUserByOpenId(openId);

                            //发送变更消息
                            VipChangeQueryParam queryParam = new VipChangeQueryParam();
                            queryParam.setMerchantId(user.getMerchantId());
                            queryParam.setStartModifiedDateStr(sf.format(new Date()));
                            queryParam.setEndModifiedDateStr(sf.format(new Date()));
                            List<CreditVipAlarmResult> results = vipAlarmService.selectVipAlarmResultNew(queryParam);
                            if (CollectionUtils.isNotEmpty(results)) {
                                int entNum = results.size();
                                StringBuffer entChange = new StringBuffer();
                                entChange.append("\n");
                                for (int i = 0; i < results.size(); i++) {
                                    if (i > 1) {
                                        break;
                                    }
                                    CreditVipAlarmResult result = results.get(i);
                                    triggerTime = result.getTriggerTime();
                                    List<CreditVipAlarmDetailResult> list = result.getDetails();
                                    if (CollectionUtils.isNotEmpty(list)) {
                                        Set<String> eventSet = new HashSet<String>();
                                        for (CreditVipAlarmDetailResult detail : list) {
                                            String eventTypeDetail = detail.getTriggerEventType();
                                            if ("basicInfo".equals(eventTypeDetail)) {
                                                eventSet.add(VipAlarmEventEnum.enumValueOfCode(detail.getTriggerEvent()).getName());
                                            } else {
                                                eventSet.add(vipAlarmService.getVipEventTypeName(eventTypeDetail));
                                            }
                                        }
                                        StringBuffer eventStr = new StringBuffer();
                                        for (String str : eventSet) {
                                            eventStr.append(str);
                                            eventStr.append("、");
                                        }
                                        String str = eventStr.toString();
                                        str = str.substring(0, str.length() - 1);
                                        entChange.append(result.getEntName());
                                        entChange.append("：");
                                        entChange.append(str);
                                        entChange.append("\n");
                                    }
                                }
                                entChange.append("......");
                                if (triggerTime == null) {
                                    triggerTime = new Date();
                                }
                                templateParams.put("first", WxRemindConstants.CHANGE_FIRST);
                                templateParams.put("keyword1", "有" + entNum + "家企业发生变更");
                                templateParams.put("keyword2", sf.format(triggerTime));
                                templateParams.put("keyword3", entChange.toString());
                                templateParams.put("remark", WxRemindConstants.CHANGE_REMARK);
                                res = gatewayUncWxFacade.sendWxByUnc(openId, wxTemplateUrl, bizNo, templateParams, ConfigUtil.getString(TemplateCodeConstants.CREDIT_WX_CHANGE), appCode);
                                System.out.println(res);
                            } else {
                                res = gatewayUncWxFacade.sendWxByUnc(openId, wxTemplateUrl, bizNo, templateParams, TemplateCodeConstants.CREDIT_WX_NO_CHANGE, appCode);
                            }
                            //发送预警消息
                            VipChangeQueryParam queryWarnig = new VipChangeQueryParam();
                            queryWarnig.setMerchantId(user.getMerchantId());
                            queryWarnig.setAlarmLevel(VipAlarmLevelEnum.RED.getCode());
                            queryWarnig.setStartModifiedDateStr(sf.format(new Date()));
                            queryWarnig.setEndModifiedDateStr(sf.format(new Date()));
                            List<CreditVipAlarmResult> warningResult = vipAlarmService.selectVipAlarmResultNew(queryWarnig);
                            if (CollectionUtils.isNotEmpty(warningResult)) {
                                int redNum = warningResult.size();
                                StringBuffer warningStr = new StringBuffer();
                                warningStr.append("\n");
                                for (int j = 0; j < warningResult.size(); j++) {
                                    if (j > 1) {
                                        break;
                                    }
                                    CreditVipAlarmResult warn = warningResult.get(j);
                                    triggerTime = warn.getTriggerTime();
                                    warningStr.append(warn.getEntName());
                                    warningStr.append("：红色预警");
                                    warningStr.append("\n");
                                }
                                warningStr.append("......");
                                if (triggerTime == null) {
                                    triggerTime = new Date();
                                }
                                templateParams.put("first", WxRemindConstants.WARNING_FIRST);
                                templateParams.put("keyword1", "有" + redNum + "家企业发生红色预警");
                                templateParams.put("keyword2", sf.format(triggerTime));
                                templateParams.put("keyword3", warningStr.toString());
                                templateParams.put("remark", WxRemindConstants.CHANGE_REMARK);
                                res = gatewayUncWxFacade.sendWxByUnc(openId, wxTemplateUrl, bizNo, templateParams, ConfigUtil.getString(TemplateCodeConstants.CREDIT_WX_WARNING), appCode);
                                System.out.println(res);
                            } else {
                                res = gatewayUncWxFacade.sendWxByUnc(openId, wxTemplateUrl, bizNo, templateParams, TemplateCodeConstants.CREDIT_WX_NO_WARNING, appCode);
                            }
                        } else {//没有绑定
                            res = gatewayUncWxFacade.sendWxByUnc(openId, wxTemplateUrl, bizNo, templateParams, TemplateCodeConstants.CREDIT_WX_PREBINDING, appCode);
                        }
                        LOGGER.error("发送微信消息结果：", res);
                    } else if (WxEventTypeEnum.SCAN.toName().equals(eventType)) {//已经关注用户扫描传参二维码
                        if (!binding) {//没有绑定 进行绑定
                            if (StringUtils.isNotBlank(eventKey)) {
                                userId = Integer.valueOf(eventKey);
                                System.out.println("eventKey:" + eventKey);
                                insertbing = true;
                            }
                        }
                        LOGGER.error("发送微信消息结果：", res);
                    } else {
                        continue;
                    }
                    //需要进行绑定操作
                    if (insertbing) {
                        if (userId == null) {
                            LOGGER.error("userId为空");
                            continue;
                        }
                        CreditWxUser creditWxUser = new CreditWxUser();

                        SingleResult<UserInfo> userInfo = userInfoFacade.getWxUserInfo(ConfigUtil.getString(TemplateCodeConstants.SYSTEM_ID), openId);
                        if (userInfo != null) {
                            creditWxUser.setNickName(userInfo.getData().getNickname());
                        }
                        creditWxUser.setOpenId(openId);
                        creditWxUser.setUserId(userId);
                        creditWxUser.setStatuts(CreditWxUserStatusEnum.BIND.toName());
                        Date now = new Date();
                        creditWxUser.setCreatedDate(now);
                        creditWxUser.setCreator("system");
                        creditWxUser.setModifier("system");
                        creditWxUser.setModifiedDate(now);
                        boolean result = creditWxUserService.insertWxUser(creditWxUser);
                        if (result) {
                            CreditUser user = creditUserService.selectCreditUserById(userId);
                            String loginName = "";
                            if (user != null) {
                                loginName = user.getLoginName();
                            }
                            templateParams.put("first", WxRemindConstants.BIND_FIRST);
                            templateParams.put("keyword1", loginName);
                            templateParams.put("keyword2", sf.format(new Date()));
                            templateParams.put("remark", WxRemindConstants.BIND_REMARK);
                            res = gatewayUncWxFacade.sendWxByUnc(openId, wxTemplateUrl, bizNo, templateParams, ConfigUtil.getString(TemplateCodeConstants.CREDIT_WX_BINDING), appCode);
                            System.out.println(res);
                        } else {//绑定失败 要不要提醒？

                        }
                    }
                }
            } catch (Exception e) {
                LOGGER.error("CreditWeixinListener error", e);
            }
        }
    }

}
