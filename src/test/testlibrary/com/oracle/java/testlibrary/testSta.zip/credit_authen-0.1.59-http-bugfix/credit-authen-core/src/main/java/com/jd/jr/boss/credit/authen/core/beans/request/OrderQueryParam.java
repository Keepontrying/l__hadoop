package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;
import java.util.Date;

import com.jd.jr.boss.credit.domain.common.enums.CreditOrderSourceEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditOrderStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditPurchaseTypeEnum;

/**
 * Created by anmeng on 2017/1/4.
 */
public class OrderQueryParam  implements Serializable {
    private static final long serialVersionUID = 1770014288968816080L;

    private CreditOrderSourceEnum source;//订购来源

    private CreditOrderStatusEnum status;//订购状态

    private Integer strategyId;//计费策略ID

    private String merchantNo;//商户号

    private Integer orderId;//订购ID

    private Integer orderMainId;//主订单ID

    private String chargeType;//订购类型 计费策略PAKCAGE-包量 SINGLE-单笔 

    private Integer productId;//产品ID

    private Date expiredTime;//失效日期

    private Integer start;

    private Integer limit;

    private String creditType;//企业征信订单 ENTERPRISE or 个人征信订单 PERSON
    
    private Integer contractId;//主订单表中的合同id

    private String validMonth;//生效月份，仅用于后付费订单查询
    private CreditPurchaseTypeEnum purchaseType;//付费方式
    
    private String accountNo;//账户号

    public CreditOrderSourceEnum getSource() {
        return source;
    }

    public void setSource(CreditOrderSourceEnum source) {
        this.source = source;
    }

    public CreditOrderStatusEnum getStatus() {
        return status;
    }

    public void setStatus(CreditOrderStatusEnum status) {
        this.status = status;
    }

    public Integer getStrategyId() {
        return strategyId;
    }

    public void setStrategyId(Integer strategyId) {
        this.strategyId = strategyId;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getOrderMainId() {
        return orderMainId;
    }

    public void setOrderMainId(Integer orderMainId) {
        this.orderMainId = orderMainId;
    }

    public String getChargeType() {
        return chargeType;
    }

    public void setChargeType(String chargeType) {
        this.chargeType = chargeType;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public String getCreditType() {
        return creditType;
    }

    public void setCreditType(String creditType) {
        this.creditType = creditType;
    }

	public Integer getContractId() {
		return contractId;
	}

	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}

    public Date getExpiredTime() {
        return expiredTime;
    }

    public void setExpiredTime(Date expiredTime) {
        this.expiredTime = expiredTime;
    }

    public String getValidMonth() {
        return validMonth;
    }

    public void setValidMonth(String validMonth) {
        this.validMonth = validMonth;
    }

    public CreditPurchaseTypeEnum getPurchaseType() {
        return purchaseType;
    }

    public void setPurchaseType(CreditPurchaseTypeEnum purchaseType) {
        this.purchaseType = purchaseType;
    }

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
}
