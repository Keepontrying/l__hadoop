package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;

/**
 * 自动化排污参数
 * @author tangmingbo
 *
 */
public class AutoSewageParam implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 3220752789938570722L;
	/**
     * 文件路径，相对路径
     */
    private String path;
    /**
     * 批次号
     */
    private String batchNo;
    /**
     * 商户号
     */
    private String merchantNo;
	/**
	 * 筛选开始时间,格式yyyy-MM-dd,如2018-01-01
	 */
	private String startFilterDateStr;

	/**
	 * 筛选结束时间,格式yyyy-MM-dd,如2018-01-01
	 */
	private String endFilterDateStr;
	/**
	 *  base 基础版；pro 增值版
	 */
	private String type;
	/**
	 * @return the path
	 */
	public String getPath() {
		return path;
	}
	/**
	 * @param path the path to set
	 */
	public void setPath(String path) {
		this.path = path;
	}
	/**
	 * @return the batchNo
	 */
	public String getBatchNo() {
		return batchNo;
	}
	/**
	 * @param batchNo the batchNo to set
	 */
	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
	/**
	 * @return the merchantNo
	 */
	public String getMerchantNo() {
		return merchantNo;
	}
	/**
	 * @param merchantNo the merchantNo to set
	 */
	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}

	public String getStartFilterDateStr() {
		return startFilterDateStr;
	}

	public void setStartFilterDateStr(String startFilterDateStr) {
		this.startFilterDateStr = startFilterDateStr;
	}

	public String getEndFilterDateStr() {
		return endFilterDateStr;
	}

	public void setEndFilterDateStr(String endFilterDateStr) {
		this.endFilterDateStr = endFilterDateStr;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
