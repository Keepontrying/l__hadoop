package com.jd.jr.boss.credit.authen.core.dao;

import java.util.List;

import com.wangyin.boss.credit.admin.entity.CreditContractDetails;
import org.springframework.stereotype.Repository;

import com.jd.jr.boss.credit.authen.core.beans.entity.ContractDetailsEntity;
import com.jd.jr.boss.credit.authen.core.beans.entity.ContractQueryEntity;
import com.jd.jr.boss.credit.authen.core.beans.request.ContractPageQueryParam;
import com.jd.jr.boss.credit.authen.core.beans.request.ContractQueryParam;
import com.jd.jr.boss.credit.authen.core.beans.request.ContractUpdateParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.OnlineContractQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditContract;

/**
 *  企业站合同管理
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
@Repository
public interface CreditContractDao {
	/**
     * 分页查询合同总数
     * @param contractPageCountRequest
     * @return
     */
    Integer queryContractPageCount(ContractPageQueryParam contractPageCountRequest) throws Exception;
   
	/**
     * 分页查询合同
     * @param contractPageRequest
     * @return
     */
    List<ContractQueryEntity> queryContractPage(ContractPageQueryParam contractPageRequest) throws Exception;
 /**
     * 合同确认结果
     * @param contractUpdateParam
     * @return
     */
 Integer updateContractStatus(ContractUpdateParam contractUpdateParam) throws Exception;
	/**
     * 查询合同详情
     * @param contractQueryParam
     * @return
     * @throws Exception
     */
    List<ContractDetailsEntity> queryContractDetailsByParam(
            ContractQueryParam contractQueryParam) throws Exception;
	 /**
     * 依据参数查询合同列表
     * @param contractQueryParam
     * @return
     * @throws Exception
     */
     List<CreditContract> queryContractByParam(
             ContractQueryParam contractQueryParam) throws Exception;

	/**
	 * 创建合同
	 * @param contract
	 */
    void insert(CreditContract contract);

	/**
	 * 查询企业门户征信合同信息分页List
	 * @param queryPageParam
	 * @return
	 */
    List<CreditContract> query(OnlineContractQueryParam queryPageParam);

	/**
	 * 查询企业门户征信合同分页总记录数
	 * @param queryPageParam
	 * @return
	 */
    Integer queryCount(OnlineContractQueryParam queryPageParam);

	/**
	 * 根据合同id查询合同详情
	 * @return
	 */
    CreditContract queryContractDetailById(Integer contractId);

	/**
	 * 新增合同操作日志表
	 * @param details
	 */
    void insertDetails(CreditContractDetails details);

    /**
     * 查询某商户下是否有购买某产品的合同
     * @param contractQueryParam
     * @return
     */
    List<CreditContract> queryContractProductOrder(ContractQueryParam contractQueryParam);
}
