package com.jd.jr.boss.credit.authen.core.constants;

/**
 * Created by zhanghui12 on 2018/7/18.
 * 格兰德报告中各模块字段常量
 */
public class GladReportConstants {
    public static final String[] financialBasicSort = {"typeOfAnnualReport", "reportDate", "doesItShow", "sourceChannel", "reportType", "auditStatus", "auditUnit"};
    public static final String[] financialAssetSort = {"monetaryFunds", "shortTermInvestment", "settlementPayment", "lendingsToBanksAndOtherFinancialInstitutions", "transactionalFinancialAssets", "billReceivable", "accountsReceivable", "prepaidAccount", "interestReceivable", "dividendsPayable", "otherReceivables", "receivablePremium", "accountsReceivableReinsurance", "reinsuranceContractReserve", "buyingBackTheSaleOfFinancialAssets", "stock", "expendableBiologicalAssets", "nonCurrentAssetsDueInOneYear", "entrustingLoansDueInOneYear", "apportionedCost", "subsidiesReceivable", "longTermBondsDueInOneYear", "otherMobileAssets", "otherSubjectsAffectingTheCurrentAssets", "totalCurrentAssets", "loansAndAdvances", "financialAssetsForSale", "entrustmentLoanAndEntrustmentInvestment", "holdToMaturityInvestment", "investmentRealEstate", "longTermInvestment", "longTermEquityInvestment", "longTermReceivables", "longTermDebtInvestments", "longTermInvestmentsDepreciationReserves", "otherLongTermInvestments", "costBookValueDifferentials", "totalFixedAssets", "theOriginalValueOfFixedAssets", "accumulatedDepreciation", "netValueOfFixedAssets", "fixedAssetsDepreciationReserves", "fixedAssets", "constructionProject", "engineeringMaterials", "fixedAssetsCleaning", "productiveBiologicalAssets", "oilAndGasAssets", "incorporealAssetsAndDeferredAssetsCombined", "intangibleAssets", "developmentExpenditure", "goodwill", "equipmentRentalDeposit", "longTermApportionedCost", "deferredTaxAssets", "otherNonMobileAssets", "otherSubjectsAffectingNonCurrentAssets", "deferredTaxesDebit", "deferredTax", "totalNonCurrentAssets", "totalAssets"};
    public static final String[] financialBalanceSort = {"shortTermBorrowing", "borrowingFromTheCentralBank", "depositAndPeerStorage", "loansFromOtherBanks", "transactionalFinancialLiabilities", "notesPayable", "accountsPayable", "ticketSettlement", "accountsReceivable", "financialAssetsSoldForRepurchase", "handlingFeeAndCommission", "salaryPayableForStaffAndWorkers", "welfarePayable", "taxesAndFeesShouldBePaid", "interestPayable", "dividendsPayable", "otherPayables", "otherPayment", "advanceCost", "expectedLiabilities", "shortTermBondsPayable", "accountsPayableReinsurance", "insuranceContractReserve", "brokerBuyingAndSellingSecurities", "actingUnderwritingSecurities", "payableToTheHoldingCompany", "nonCurrentLiabilitiesDueInOneYear", "longTermHoldingCompanyPaymentsDueInOneYear", "internalPayment", "otherCurrentLiabilities", "otherSubjectsAffectingCurrentLiabilities", "totalCurrentLiabilities", "longTermBorrowing", "bondsPayable", "longTermPayable", "specialPayment", "financialLeasePayable", "longTermPayableToTheHoldingCompany", "largeRepairPreparation", "payMoreThanOneYearForEmployeesSalary", "deferredTaxLiability", "deferredTax", "deferredIncome", "otherNonCurrentLiabilities", "otherSubjectsAffectingNonCurrentLiabilities", "totalNonCurrentLiabilities", "balanceOfLiabilities", "capitalStock", "capitalReserve", "stockStock", "surplusSurplus", "generalRiskPreparation", "specialStorage", "undistributedProfit", "balanceOfForeignCurrencyStatement", "unidentifiedInvestmentLosses", "otherSubjectsAffectingTheOwnerRights", "belongingToTheShareholdersEquityOfTheParentCompany", "retainedEarnings", "otherOwnersRightsAndInterests", "minorityShareholdersRightsAndInterests", "shareholderEquity", "debtAndShareholdersEquity"};
    public static final String[] financialProfitSort = {"grossRevenue", "amongThemBusinessIncome", "interestIncome", "earnedPremium", "commissionAndCommissionIncome", "totalCostOfBusiness", "amongThemOperatingCosts", "businessTaxAndAdditional", "businessMaori", "otherBusinessProfits", "reductionOperatingExpenses", "managementCost", "financialCost", "interestExpenditure", "feeAndCommissionExpenditure", "assetsImpairmentLoss", "refund", "netReimbursement", "extractionOfTheNetAmountOfTheInsuranceContractReserve", "expendituresDividendPolicy", "reinsuranceCost", "explorationCost", "otherSubjectsAffectingBusinessCosts", "netIncomeChangeOfFairValue", "addInvestmentReturns", "investmentReturnsToJointVenturesAndJointVentures", "remittanceIncome", "operatingProfit", "addSubsidizedIncome", "investmentReturns", "outsideIncome", "outOfBusinessExpenditure", "netLossOfDisposingOfNonCurrentAssets", "totalProfit", "reductionIncomeTax", "unidentifiedInvestmentLosses", "otherSubjectsAffectingNetProfit", "profitAndLossOfMinorityShareholdersInThisPeriod", "netProfit", "minorityInterest", "netProfitAttributableToTheOwnerOfAParentCompany"};
    public static final String[] financialChangesSort = {"businessIncome", "totalAssets", "operatingFunds", "totalProfit", "netProfit", "balanceOfLiabilities", "totalEquity", "totalCurrentAssets", "totalCurrentLiabilities", "fixedAssets"};
    public static final String[] registrationSort = {"registrationNumber", "dateOfRegistration", "registrationNumberOfTheMortgaged", "nameOfTheMortgaged", "theTypeOfMortgage", "typeOfMortgaged", "mortgagorInformation", "nameOfTheMortgagor", "mortgagorIdNumber", "mortgageType", "mortgages", "quantityQualityConditionLocationEtc", "categoryOfPrincipalCreditorRights", "scopeOfSecurity", "amountOfPrincipalClaim", "startDateOfCreditorRight", "deadlineForCreditorRights", "registrationOffice", "changeType", "otherInformation"};
    /**
     * 股权冻结
     */
    public static final String[] freezeKeys={"freezeNumber", "freezingOrgan", "freezingStartDate", "freezeUpDate", "freezingAmount", "defrostingOrgan", "thawingNumber", "thawingDate", "explanationOfThawing"};
    /**
     * 股权质押
     */
    public static final String[] pledgeKeys={"registrationNumber", "theNameOfThePledgee", "theTypeOfThePledgor", "amountOfQuality", "dateOfFiling", "qualityAndApprovalDepartment", "dateOfApproval", "expirationDate", "pledgor", "aWitnessAccordingToIdNumber", "state"};
    /**
     * 融资记录
     */
    public static final String[] financingsKeys={"productAbbreviations", "time", "investor", "amountOfMoney", "round"};
    /**
     * 行政许可
     */
    public static final String[] adminLicensingsKeys={"licenseNumber", "licenseFileName", "validPeriodFrom", "periodOfValidityTo", "licensingAuthority","licenseContent","permissiveState","details"};
    /**
     * 行政处罚
     */
    public static final String[] adminPunishsKeys={"isbnNumber", "content", "agency", "date", "remarks","illegalActivities"};
    /**
     * 行政奖励
     */
    public static final String[] adminRewardsKeys={"dataSources", "isbnNumber", "content", "agency", "date","remarks"};
    /**
     * 严重违法信息
     */
    public static final String[] violationsKeys={"theReasonsForListing", "date", "theReasonsForRemoving", "moveOutDate", "makeADecision"};
    /**
     * 经营异常
     */
    public static final String[] abnormitysKeys={"theReasonsForListing", "date", "theReasonsForRemoving", "moveOutDate", "makeADecision"};
    /**
     * 对外提供担保
     */
    public static final String[] guaranteesKeys={"creditor", "obligor", "categoryOfPrincipalCreditorRights", "amountOfPrincipalClaim", "theTimeLimitForThePerformanceOfTheDebt","periodOfGuarantee","theWayOfAssurance","updateDate","noteInformation","getDate","guaranteeTheScopeOfTheGuarantee"};

    /**
     * 企业欠贷信息
     */
    public static final String[] loansKeys={"lessLoanTime", "loanAmount", "underLoanState", "sourcePlatform", "queryTime","overduePrincipal","detailedRemarks"};

    /**
     * 上市公司/发债信息
     */
    public static final String[] listedBondsKeys={"listingIssuingPlace", "stockRightCode", "status","stockAbbreviation", "timeToMarket", "theLatestImportantAnnouncement","remarks"};
    /**
     * 债券信息
     */
    public static final String[] bondsKeys={"fullNameOfTheProduct", "productAbbreviations", "productCode", "publisherName", "totalDistribution","issuePrice","faceValue","releaseDate","dateOfRegistration","circulationDay","endOfCirculation","term","maturity","interestRate","annualRateOfPar","frequency","dayOfInterest"};
    /**
     * 竞争者信息
     */
    public static final String[] competitorsKeys={"chineseName", "englishName", "countryArea", "financialStrength", "publicRecords","creditRisks","theNatureOfTheEnterprise","registrationNumber","unifiedSocialCreditCode","registeredCapital","registeredCapitalCurrency","timeOfEstablishment","legalRepresentative","registeredAddress","operatingAddress","postalCode","countryCode","areaCode","telephone1","telephone2","telephone3","mobilePhone","fax1","fax2","financialYear","website","mainBusiness","businessIncome","financialHighlights","otherInformation"};

}
