package com.jd.jr.boss.credit.authen.core.beans.entity.carLoan;

import java.io.Serializable;

/**
 * 统计维度
 * @author tangmingbo
 *
 */
public class StatisticCount implements Serializable{
	private static final long serialVersionUID = 2936531965994611042L;
	/**
	 * 变更条数
	 */
	private int alterNum;
	/**
	 * 法定代表人发生变更 企业数
	 */
	private int frAlterEntNum;
	/**
	 * 注册资本发生减资 企业数
	 */
	private int regAlterEntNum;
	/**
	 * 股权/股东发生变更 企业数
	 */
	private int shareAlterEntNum;
	/**
	 * 经营地址发生变更 企业数
	 */
	private int domAlterEntNum;
	/**
	 * 经营范围发生变更 企业数
	 */
	private int scopeAlterEntNum;
	/**
	 * 行政处罚 企业数
	 */
	private int punishmentAlterEntNum;
	/**
	 * 列入经营异常名单 企业数
	 */
	private int abnormalAlterEntNum;

	private int illegalAlterEntNum;
	private int checkAlterEntNum;
	private int equityAlterEntNum;
	private int mortgageAlterEntNum;
}
