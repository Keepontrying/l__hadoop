package com.jd.jr.boss.credit.authen.core.beans.entity.microSmallBusinesses;

import java.io.Serializable;
import java.util.Date;

/**
 * 小微企业政策扶持信息
 *
 * @author huangzhiqiang
 * @data 2018/3/26
 */
public class PolicySupportInfo implements Serializable {
    private static final long serialVersionUID = -890882443094624292L;

    private Long id;
    /**
     * 实施扶持政策的部门
     */
    private String supportDepartment;
    /**
     * 实施扶持政策日期
     */
    private String supportDate;
    /**
     * 享受扶持政策依据
     */
    private String supportBasis;
    /**
     * 享受扶持政策内容
     */
    private String supportContent;
    /**
     * 享受扶持政策的数额
     */
    private String supportMoney;
    /**
     * 小微企业信息主键
     */
    private Long fatherId;
    /**
     * 企业名称
     */
    private String companyName;
    /**
     * 统一社会信用代码/注册号
     */
    private String creditCode;

    private Date createdDate;

    private Date modifiedDate;


    public Long getId() {
        return id;
    }

    public String getSupportDepartment() {
        return supportDepartment;
    }

    public void setSupportDepartment(String supportDepartment) {
        this.supportDepartment = supportDepartment;
    }

    public String getSupportDate() {
        return supportDate;
    }

    public void setSupportDate(String supportDate) {
        this.supportDate = supportDate;
    }

    public String getSupportBasis() {
        return supportBasis;
    }

    public void setSupportBasis(String supportBasis) {
        this.supportBasis = supportBasis;
    }

    public String getSupportContent() {
        return supportContent;
    }

    public void setSupportContent(String supportContent) {
        this.supportContent = supportContent;
    }

    public String getSupportMoney() {
        return supportMoney;
    }

    public void setSupportMoney(String supportMoney) {
        this.supportMoney = supportMoney;
    }

    public Long getFatherId() {
        return fatherId;
    }

    public void setFatherId(Long fatherId) {
        this.fatherId = fatherId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
}
