package com.jd.jr.boss.credit.authen.core.facade;

import com.jd.jr.boss.credit.authen.core.service.CreditVipGroupService;
import com.jd.jr.boss.credit.authen.core.service.CreditVipGroupUserService;
import com.jd.jr.boss.credit.authen.core.service.VipService;
import com.jd.jr.boss.credit.facade.authen.api.CreditGroupUserFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.VipGroupQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.VipTaskDtoQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.entity.CreditVipGroup;
import com.wangyin.boss.credit.admin.entity.CreditVipGroupUser;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption :
 * @date ：2019/3/8 15:08
 * @return
 */
@Service("groupUserFacade")
public class CreditGroupUserFacadeImpl implements CreditGroupUserFacade {

    private static Logger logger = LoggerFactory.getLogger(CreditGroupUserFacadeImpl.class);

    @Autowired
    CreditVipGroupUserService creditVipGroupUserService;
    @Autowired
    CreditVipGroupService creditVipGroupService;
    @Autowired
    private VipService vipService;

    @Override
    public Integer selectOpenGroupIdByUserPin(CreditRequestParam<VipTaskDtoQueryParam> queryParam) {
        Integer groupId = null;
        try {
            logger.info("selectOpenGroupIdByUserPin reqeustParam:{}", GsonUtil.getInstance().toJson(queryParam));
            if(null != queryParam && null != queryParam.getParam() && StringUtils.isNotBlank(queryParam.getParam().getUserPin())){
                groupId = creditVipGroupUserService.selectOpenGroupIdByUserPin(queryParam.getParam().getUserPin());
            }else{
                return groupId;
            }
        } catch (Exception e) {
            logger.error("selectOpenGroupIdByUserPin error, {}", e);
        }
        return groupId;
    }

    @Override
    public CreditPage<CreditVipGroup> selectVipGroupPageByParam(CreditRequestParam<VipGroupQueryParam> requestParam) {
        CreditPage<CreditVipGroup> groupPage = new CreditPage<CreditVipGroup>();
        try {
            if (requestParam.getParam() == null ) {
                groupPage.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                groupPage.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                groupPage.setSuccess(false);
                return groupPage;
            }
            VipGroupQueryParam vipGroupPrm = new VipGroupQueryParam();
            List<CreditVipGroup> groupList = creditVipGroupService.selectVipGroupPageByParam(requestParam.getParam());
            groupPage.setRows(groupList);
            if(null != requestParam.getParam().getStart() && null != requestParam.getParam().getLimit()){
                //查询总数量
                Integer total = creditVipGroupService.selectVipGroupPageByParamCount(requestParam.getParam());
                groupPage.setTotal(total);
            }
        } catch (Exception e) {
            logger.error("selectVipGroupPageByParam error, {}", e);
        }
        return groupPage;
    }

    @Override
    public Integer insertBatchGroupUsers(CreditRequestParam<List<CreditVipGroupUser>> creditRequestParam) {
        Integer result = null;
        try {
            if(CollectionUtils.isEmpty(creditRequestParam.getParam())){
                return null;
            }
            int barchtResult = creditVipGroupUserService.insertBatchGroupUsers(creditRequestParam.getParam());
            result = 1;
        } catch (Exception e) {
            logger.error("insertBatchGroupUsers error, {}", e);
        }
        return result;
    }

    @Override
    public Integer insertCreditGroup(CreditRequestParam<CreditVipGroup> creditRequestParam) {
        return creditVipGroupService.insert(creditRequestParam.getParam());
    }

    @Override
    public CreditPage<CreditVipGroupUser> selectGroupUserList(CreditRequestParam<VipGroupQueryParam> requestParam) {
        CreditPage<CreditVipGroupUser> resultPage = null;
        try {
            if (requestParam.getParam() == null ) {
                resultPage.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                resultPage.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                resultPage.setSuccess(false);
                return resultPage;
            }
            VipGroupQueryParam vipGroupQueryParam = requestParam.getParam();
            if(null == vipGroupQueryParam.getGroupId() && StringUtils.isNotBlank(vipGroupQueryParam.getUserPin())){
                Integer groupId = creditVipGroupUserService.selectOpenGroupIdByUserPin(vipGroupQueryParam.getUserPin());
                vipGroupQueryParam.setGroupId(groupId);
                vipGroupQueryParam.setUserPin(null);
            }
            resultPage = creditVipGroupUserService.selectVipGroupUserList(vipGroupQueryParam);
        } catch (Exception e) {
            logger.error("selectGroupUserList error, {}", e);
        }
        return resultPage;
    }

    @Override
    public CreditResponseData cleanDataVipGroup(CreditRequestParam<String> queryParam) {
        return vipService.cleanDataVipGroup(queryParam);
    }

    @Override
    public CreditPage<String> selectUserInGroupEmailList(CreditRequestParam<VipGroupQueryParam> requestParam) {
        CreditPage<String> resultPage = null;
        try {
            if (requestParam.getParam() == null ) {
                resultPage.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                resultPage.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                resultPage.setSuccess(false);
                return resultPage;
            }
            VipGroupQueryParam vipGroupQueryParam = requestParam.getParam();
            if(null == vipGroupQueryParam.getGroupId() && StringUtils.isNotBlank(vipGroupQueryParam.getUserPin())){
                Integer groupId = creditVipGroupUserService.selectOpenGroupIdByUserPin(vipGroupQueryParam.getUserPin());
                vipGroupQueryParam.setGroupId(groupId);
                vipGroupQueryParam.setUserPin(null);
            }
            resultPage = creditVipGroupUserService.selectUserInGroupEmailList(vipGroupQueryParam);
        } catch (Exception e) {
            logger.error("selectUserInGroupEmailList error, {}", e);
        }
        return resultPage;
    }
}
