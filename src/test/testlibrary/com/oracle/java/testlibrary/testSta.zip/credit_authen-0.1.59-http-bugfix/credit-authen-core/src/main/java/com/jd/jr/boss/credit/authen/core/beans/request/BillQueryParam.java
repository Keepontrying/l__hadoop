package com.jd.jr.boss.credit.authen.core.beans.request;

import com.jd.jr.boss.credit.domain.common.enums.CreditPurchaseTypeEnum;

import java.io.Serializable;

public class BillQueryParam implements Serializable{
	/**
	 *
	 */
	private static final long serialVersionUID = -4243247173933131900L;
	/**
	 * 账单时间
	 */
	private String startDate;
	/**
	 * 商户号
	 */
	private String merchantNo;
	/**
	 * 产品ID
	 */
	private Integer productId;
	/**
	 * 调用模式
	 */
	private String callMode;
	/**
	 * 平台类型PORSON,ENTERPRISE
	 */
	private String creditType;

	private String monthDate;//账单月份
	/**
	 * vip监控标识：YES-vip监控；NO-普通使用
	 */
	private String vipMonitorFlag;
	private String purchaseType;//支付类型
	private String userPin;

	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getMerchantNo() {
		return merchantNo;
	}
	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getCallMode() {
		return callMode;
	}
	public void setCallMode(String callMode) {
		this.callMode = callMode;
	}
	public String getCreditType() {
		return creditType;
	}
	public void setCreditType(String creditType) {
		this.creditType = creditType;
	}

	public String getMonthDate() {
		return monthDate;
	}

	public void setMonthDate(String monthDate) {
		this.monthDate = monthDate;
	}

	public String getPurchaseType() {
		return purchaseType;
	}

	public void setPurchaseType(String purchaseType) {
		this.purchaseType = purchaseType;
	}

	/**
	 * @return the vipMonitorFlag
	 */
	public String getVipMonitorFlag() {
		return vipMonitorFlag;
	}
	/**
	 * @param vipMonitorFlag the vipMonitorFlag to set
	 */
	public void setVipMonitorFlag(String vipMonitorFlag) {
		this.vipMonitorFlag = vipMonitorFlag;
	}

	public String getUserPin() {
		return userPin;
	}

	public void setUserPin(String userPin) {
		this.userPin = userPin;
	}
}
