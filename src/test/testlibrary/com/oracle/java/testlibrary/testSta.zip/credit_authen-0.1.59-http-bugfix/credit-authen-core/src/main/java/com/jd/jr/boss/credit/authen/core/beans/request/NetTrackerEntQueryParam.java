package com.jd.jr.boss.credit.authen.core.beans.request;

import com.jd.jr.boss.credit.domain.common.enums.OpenOrCloseStatusEnum;

import java.io.Serializable;
import java.util.List;

/**
 * Created by anmeng on 2017/10/26.
 */
public class NetTrackerEntQueryParam implements Serializable {


    private static final long serialVersionUID = 227565540542157811L;

    private String enterpriseName;
    private Integer groupId;
    private Integer merchantId;
    private List<String> enterpriseNameList;//企业名称列表，批量查询
    private List<String> enterpriseIdList;
    private String enterpriseId;
    private Integer trackerId;//
    private OpenOrCloseStatusEnum focusStatus;

    private Integer limit;
    private Integer start;

    public String getEnterpriseName() {
        return enterpriseName;
    }

    public void setEnterpriseName(String enterpriseName) {
        this.enterpriseName = enterpriseName;
    }

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public Integer getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Integer merchantId) {
        this.merchantId = merchantId;
    }

    public List<String> getEnterpriseNameList() {
        return enterpriseNameList;
    }

    public void setEnterpriseNameList(List<String> enterpriseNameList) {
        this.enterpriseNameList = enterpriseNameList;
    }

    public String getEnterpriseId() {
        return enterpriseId;
    }

    public void setEnterpriseId(String enterpriseId) {
        this.enterpriseId = enterpriseId;
    }

    public Integer getTrackerId() {
        return trackerId;
    }

    public void setTrackerId(Integer trackerId) {
        this.trackerId = trackerId;
    }

    public OpenOrCloseStatusEnum getFocusStatus() {
        return focusStatus;
    }

    public void setFocusStatus(OpenOrCloseStatusEnum focusStatus) {
        this.focusStatus = focusStatus;
    }

    public List<String> getEnterpriseIdList() {
        return enterpriseIdList;
    }

    public void setEnterpriseIdList(List<String> enterpriseIdList) {
        this.enterpriseIdList = enterpriseIdList;
    }
}
