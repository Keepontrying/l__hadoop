package com.jd.jr.boss.credit.authen.core.beans.entity.carLoan;

import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.BasicInfoQueryData;

import java.io.Serializable;
import java.util.List;

/**
 * 企业信息
 * @author tangmingbo
 *
 */
public class EntInfo implements Serializable{
	private static final long serialVersionUID = 2936531965994611042L;
	/**
     * 企业名
	 */
	private String entName;
	/**
	 * 占股
	 */
	private String shareHolderRatio;
	/**
	 * 疑是实际控制人
	 */
	private String isActControl;
	/**
	 * 企业是否命中黑名单
	 */
	private String entBlackList;
	/**
	 * 工商信息
	 */
	private BasicInfoQueryData basicInfoQueryData;

	public String getEntName() {
		return entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	public String getShareHolderRatio() {
		return shareHolderRatio;
	}

	public void setShareHolderRatio(String shareHolderRatio) {
		this.shareHolderRatio = shareHolderRatio;
	}

	public String getIsActControl() {
		return isActControl;
	}

	public void setIsActControl(String isActControl) {
		this.isActControl = isActControl;
	}

	public String getEntBlackList() {
		return entBlackList;
	}

	public void setEntBlackList(String entBlackList) {
		this.entBlackList = entBlackList;
	}

	public BasicInfoQueryData getBasicInfoQueryData() {
		return basicInfoQueryData;
	}

	public void setBasicInfoQueryData(BasicInfoQueryData basicInfoQueryData) {
		this.basicInfoQueryData = basicInfoQueryData;
	}
}
