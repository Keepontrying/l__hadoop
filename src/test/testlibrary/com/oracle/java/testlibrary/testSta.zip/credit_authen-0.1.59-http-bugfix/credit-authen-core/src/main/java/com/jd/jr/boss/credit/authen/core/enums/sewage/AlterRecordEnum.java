package com.jd.jr.boss.credit.authen.core.enums.sewage;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 变更记录
 * @author tangmingbo
 *
 */
public enum AlterRecordEnum {
	//注册资本相关
	ITEM_CAPITAL_ONE(1, "ITEM_CAPITAL_ONE", "注册资本(金)变更"),
	ITEM_CAPITAL_TWO(2, "ITEM_CAPITAL_TWO", "注册资本"),
	ITEM_CAPITAL_THREE(3, "ITEM_CAPITAL_THREE", "注册资本变更(注册资金、资金数额等变更)变更"),
	ITEM_CAPITAL_THIRD(4, "ITEM_CAPITAL_THIRD", "注册资本变更(注册资金、资金数额等变更)"),
	ITEM_CAPITAL_FIVE(5, "ITEM_CAPITAL_FIVE", "资金数额变更"),
	ITEM_CAPITAL_SIXE(6, "ITEM_CAPITAL_SIXE", "注册资本变更"),
	//负责人变更相关
	ITEM_LEGAL_ONE(7, "ITEM_LEGAL_ONE", "法定代表人变更"),
	ITEM_LEGAL_TWO(8, "ITEM_LEGAL_TWO", "法定代表人(负责人、董事长、首席代表)变更"),
	ITEM_LEGAL_THREE(9, "ITEM_LEGAL_THREE", "负责人变更(法定代表人、负责人、首席代表、合伙事务执行人等变更)变更"),
	ITEM_LEGAL_THIED(10, "ITEM_LEGAL_THIED", "负责人变更(法定代表人、负责人、首席代表、合伙事务执行人等变更)"),
	ITEM_LEGAL_FIVE(11, "ITEM_LEGAL_FIVE", "法定代表人"),
	ITEM_LEGAL_SIXE(12, "ITEM_LEGAL_SIXE", "财务负责人"),
	ITEM_LEGAL_SEVEN(13, "ITEM_LEGAL_SEVEN", "董事(理事)、经理、监事"),
	ITEM_LEGAL_EITHGE(14, "ITEM_LEGAL_EITHGE", "负责人变更"),
	ITEM_LEGAL_NINE(15, "ITEM_LEGAL_NINE", "董事成员"),
	ITEM_LEGAL_TEN(16, "ITEM_LEGAL_TEN", "法定代表人(负责人)"),
	ITEM_LEGAL_ELEVEN(17, "ITEM_LEGAL_ELEVEN", "法定代表人(负责人)变更"),
	ITEM_LEGAL_TWETH(18, "ITEM_LEGAL_TWETH", "负责人变更(法定代表人、负责人、首席代表、个体户经营者、投资人、合伙事务执行人等变更)"),
	//抽查检查
	ITEM_CHECK_ONE(19, "ITEM_CHECK_ONE", "正常"),
	ITEM_CHECK_TWO(20, "ITEM_CHECK_TWO", "未发现"),
	ITEM_CHECK_THREE(21, "ITEM_CHECK_THREE", "符合"),
	ITEM_CHECK_THIRD(22, "ITEM_CHECK_THIRD", "合格"),

	ITEM_CHECK_FIVE(23, "ITEM_CHECK_FIVE", "不正常"),
	ITEM_CHECK_SIX(24, "ITEM_CHECK_SIX", "不符合"),
	ITEM_CHECK_SEVEN(25, "ITEM_CHECK_SEVEN", "不合格"),;
	 private Integer code;
	    private String name;
	    private String description;

	    /**
	     * @param description 中文描述
	     */
        AlterRecordEnum(String description) {
	        this.description = description;
	    }

	    /**
	     * @param code        数字编码
	     * @param description 中文描述
	     */
        AlterRecordEnum(Integer code, String description) {
	        this.code = code;
	        this.description = description;
	    }

	    /**
	     * @param name        英文编码名称
	     * @param description 中文描述
	     */
        AlterRecordEnum(String name, String description) {
	        this.name = name;
	        this.description = description;
	    }

	    /**
	     * @param code        数字编码
	     * @param name        英文编码名称
	     * @param description 中文描述
	     */
        AlterRecordEnum(Integer code, String name, String description) {
	        this.code = code;
	        this.name = name;
	        this.description = description;
	    }


	    /**
	     * 获取枚举类型数值编码
	     */
	    public Integer toCode() {
	        return this.code == null ? this.ordinal() : this.code;
	    }

	    /**
	     * 获取枚举类型英文编码名称
	     */
	    public String toName() {
	        return this.name == null ? this.name() : this.name;
	    }

	    /**
	     * 获取枚举类型中文描述
	     */
	    public String toDescription() {
	        return this.description;
	    }


	    /**
	     * 获取枚举类型中文描述
	     */
	    public String toString() {
	        return this.description;
	    }



	    /**
	     * 按数值获取对应的枚举类型
	     *
	     * @param code 数值
	     * @return 枚举类型
	     */
	    public static AlterRecordEnum enumValueOf(Integer code) {
	        AlterRecordEnum[] values = AlterRecordEnum.values();
	        AlterRecordEnum v = null;
	        for (int i = 0; i < values.length; i++) {
	            if (code != null && code.equals(values[i].toCode())) {
	                v = values[i];
	                break;
	            }
	        }
	        return v;
	    }

	    /**
	 * 按英文编码获取对应的枚举类型
	 *
	 * @param name 英文编码
	 * @return 枚举类型
	 */
	public static AlterRecordEnum enumValueOf(String name) {
		AlterRecordEnum[] values = AlterRecordEnum.values();
		AlterRecordEnum v = null;
		for (int i = 0; i < values.length; i++) {
			if (name != null && name.equalsIgnoreCase(values[i].toName())) {
				v = values[i];
				break;
			}
		}
		return v;
	}
	/**
	 * 按description编码获取对应的枚举类型
	 * @param description 英文编码
	 * @return 枚举类型
	 */
	public static AlterRecordEnum getByDescription(String description) {
		AlterRecordEnum[] values = AlterRecordEnum.values();
		AlterRecordEnum v = null;
		for (int i = 0; i < values.length; i++) {
			if (description != null && description.equalsIgnoreCase(values[i].toDescription())) {
				v = values[i];
				break;
			}
		}
		return v;
	}

	    /**
	     * 获取枚举类型的所有<数字编码,中文描述>对
	     *
	     * @return
	     */
	    public static Map<Integer, String> toCodeDescriptionMap() {
	        LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
	        for (int i = 0; i < AlterRecordEnum.values().length; i++) {
	            if (AlterRecordEnum.values()[i] != null) {
	                map.put(AlterRecordEnum.values()[i].toCode(), AlterRecordEnum.values()[i].toDescription());
	            }
	        }
	        return map;
	    }

	    /**
	     * 获取枚举类型的所有<英文编码名称,中文描述>对
	     *
	     * @return
	     */
	    public static Map<String, String> toNameDescriptionMap() {
	        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
	        for (int i = 0; i < AlterRecordEnum.values().length; i++) {
	            if (AlterRecordEnum.values()[i] != null) {
	                map.put(AlterRecordEnum.values()[i].toName(), AlterRecordEnum.values()[i].toDescription());
	            }
	        }
	        return map;
	    }
}
