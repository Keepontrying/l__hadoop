package com.jd.jr.boss.credit.core.test.payment;

import com.jd.jr.boss.credit.domain.common.enums.CreditPaymentChannelEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditPaymentTypeEnum;
import com.jd.jr.boss.credit.facade.site.api.CreditPaymentFacade;
import com.jd.jr.boss.credit.facade.site.api.CreditPaymentUpdateFacade;
import com.jd.jr.boss.credit.facade.site.api.dto.entity.PaymentPackageEntity;
import com.jd.jr.boss.credit.facade.site.api.dto.request.payment.PaymentReceiptPushRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.payment.PaymentReceiptQueryRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.paymentupdate.PaymentUpdateRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.paymentupdate.PaymentUpdateResponse;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/spring-dubbo-consumer.xml"})

public class PaymentUpdateAspectjTest {
    @Resource
    private CreditPaymentFacade paymentFacade;

    @Test
    public void testPushPaymentReceipt() {
        RequestParam<PaymentReceiptPushRequest> requestParam = new RequestParam<PaymentReceiptPushRequest>();

        PaymentReceiptPushRequest request = new PaymentReceiptPushRequest();
        request.setMerchantNo("110029819");
        request.setPaymentChannel(CreditPaymentChannelEnum.SINGLE_MANUAL);
        request.setContractId("357");
        request.setAmount(BigDecimal.valueOf(10000));
        requestParam.setParam(request);
        ResponseData responseData = paymentFacade.pushPaymentReceipt(requestParam);
        System.out.println(GsonUtil.getInstance().toJson(responseData));
    }

    @Test
    public void testPushPaymentReceiptPackage() {
        RequestParam<PaymentReceiptPushRequest> requestParam = new RequestParam<PaymentReceiptPushRequest>();

        PaymentReceiptPushRequest request = new PaymentReceiptPushRequest();
        request.setMerchantNo("110029819");
        request.setPaymentChannel(CreditPaymentChannelEnum.PACKAGE_MANUAL);
        request.setStrategyId(893);
        request.setAmount(BigDecimal.valueOf(10000));
        requestParam.setParam(request);
        ResponseData responseData = paymentFacade.pushPaymentReceipt(requestParam);
        System.out.println(GsonUtil.getInstance().toJson(responseData));
    }

    @Test
    public void testQueryPaymentReceiptUnpaid() {
        RequestParam<PaymentReceiptQueryRequest> requestParam = new RequestParam<PaymentReceiptQueryRequest>();
        PaymentReceiptQueryRequest request = new PaymentReceiptQueryRequest();
        request.setMerchantNo("110034638");
        request.setPaymentChannel(CreditPaymentChannelEnum.SINGLE_MANUAL);
        requestParam.setParam(request);
        ResponseData<Set<String>> responseData = paymentFacade.queryPaymentReceiptUnpaid(requestParam);
        System.out.println(GsonUtil.getInstance().toJson(responseData));
    }

}
