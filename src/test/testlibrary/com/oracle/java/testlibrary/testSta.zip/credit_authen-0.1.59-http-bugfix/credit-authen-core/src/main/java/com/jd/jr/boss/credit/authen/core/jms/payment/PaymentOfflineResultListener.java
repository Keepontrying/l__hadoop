package com.jd.jr.boss.credit.authen.core.jms.payment;

import com.jd.jmq.client.consumer.MessageListener;
import com.jd.jmq.common.message.Message;
import com.jd.jmq.fastjson.JSON;
import com.jd.jr.boss.credit.authen.core.service.PaymentOfflineService;
import com.jd.jr.boss.credit.domain.common.entity.CreditPaymentOffline;
import com.jd.jr.payplatform.jsf.po.PaymentMQMessageVo;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by anmeng on 2017/3/31.
 */
@Service("paymentOfflineResultListener")
public class PaymentOfflineResultListener implements MessageListener {

    private Logger logger= LoggerFactory.getLogger(PaymentOfflineResultListener.class);

    private Integer REF_SYS= ConfigUtil.getInt("gateway.finance.platform.refSys");

    @Resource
    private PaymentOfflineService paymentOfflineService;

    @Override
    public void onMessage(List<Message> messages) throws Exception {
        if (messages == null || messages.isEmpty()) {
            return;
        }

        for (Message message : messages) {
            String dataJSONStr=message.getText();
            try {
                PaymentMQMessageVo messageVo=JSON.parseObject(dataJSONStr,PaymentMQMessageVo.class);
                Integer warrantStatus=messageVo.getWarrantStatus();
                Integer payStatus=messageVo.getPayStatus();
                Integer refSys=messageVo.getRefSys();

                if(REF_SYS.equals(refSys)){
                    logger.info("收到线下收付款平台消息:"+dataJSONStr);
                    Integer paymentId=Integer.parseInt(messageVo.getRefId());
                    String remark=messageVo.getRemark();
                    CreditPaymentOffline paymentOffline=new CreditPaymentOffline();
                    paymentOffline.setId(paymentId);
                    paymentOffline.setRemark(remark);
                    if(warrantStatus==1){//成功
                        if(payStatus==12){//已收款
                            paymentOfflineService.confirmReceivePayment(paymentOffline);
                        }else{
                            logger.warn("unknown payStatus:"+payStatus);
                        }
                    }else if(warrantStatus==3){//失败
                        paymentOfflineService.rejectReceivePayment(paymentOffline);
                    }
                }
            } catch (Exception e) {
                logger.error("消息处理失败:"+ e.getMessage());
            }

        }
    }
}
