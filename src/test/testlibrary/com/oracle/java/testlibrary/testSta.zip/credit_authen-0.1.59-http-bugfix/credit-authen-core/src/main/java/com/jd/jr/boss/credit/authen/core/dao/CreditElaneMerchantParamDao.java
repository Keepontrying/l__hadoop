package com.jd.jr.boss.credit.authen.core.dao;

import com.wangyin.boss.credit.admin.entity.CreditElaneMerchant;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * 船舶商户数据表
 * @author : liuwei@jd.com
 * @version 1.0
 * @desciption :
 * @date ：2017年1月22日 下午4:47:35
 * @return
 */
@Repository
public interface CreditElaneMerchantParamDao {

    /**
     * 查询 船舶商户
     *
     * @param merchantQryParam
     * @return
     */
    List<CreditElaneMerchant> queryElaneByParam(CreditElaneMerchant merchantQryParam);

    /**
     * 修改船舶商户
     *
     * @param creditMerchant
     * @return
     */
    int updateByParam(CreditElaneMerchant creditMerchant);

    /**
     * 添加船舶商户
     *
     * @param creditMerchant
     * @return
     */
    int insertSelective(CreditElaneMerchant creditMerchant);

}
