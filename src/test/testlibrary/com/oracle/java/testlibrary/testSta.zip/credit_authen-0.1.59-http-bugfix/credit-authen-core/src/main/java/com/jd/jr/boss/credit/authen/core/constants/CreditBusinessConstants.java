package com.jd.jr.boss.credit.authen.core.constants;

import com.wangyin.boss.credit.admin.enums.VipResultSubProductCodeEnum;

import java.math.BigDecimal;

/**
 * @author tyangjinlin@jd.com
 * @since 2018/08/13
 */
public class CreditBusinessConstants {

    /** -----------   风控自动排污   start  ------------- **/
	public static final String DEST_PATH = "upload/elimNegReport/dest/";//用户下載文件存放路径
    public static final Integer SEWAGE_MAX_RESULT_SIZE = 50;// 排污报告增值版最多返回50条结果
    public static final String SEWAGE_MAX_BASIC_SHAREHODLER_RATIO = "25";// 持股比例超25%才算大股东
    public static final String BASIC_BASE = "BASIC_BASE";// 工商基本信息-照面信息
	public static final String BASIC_ALTERRECORDS = "BASIC_ALTERRECORDS";// 工商基本信息-历史沿革
	public static final String BASIC_SHAREHOLDERS = "BASIC_SHAREHOLDERS";// 工商基本信息-股东及出资信息
	public static final String BASIC_BRANCHRECORDS = "BASIC_BRANCHRECORDS";// 工商基本信息-分支机构
	public static final String BASIC_MAINSTAFFS = "BASIC_MAINSTAFFS";// 工商基本信息-主要人员
	public static final String SEWAGE_TOTAL = "SEWAGE_TOTAL";// 总表
    /** -----------   风控自动排污   end  ------------- **/

    /** -----------   风控自动排污   start  ------------- **/
    public static final String CARLOAN_REG_STATUS_CANCELLED = "已注销"; //企业经营状态为 已注销
    /** -----------   风控自动排污   end  ------------- **/

    public static void main(String[] args) {
        System.out.println(new BigDecimal(CreditBusinessConstants.SEWAGE_MAX_BASIC_SHAREHODLER_RATIO).compareTo(new BigDecimal(("24%").replace("%",""))) <= 0);
    }

}
