package com.jd.jr.boss.credit.authen.core.jms.crawler;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jd.jmq.client.consumer.MessageListener;
import com.jd.jmq.common.message.Message;
import com.jd.jr.boss.credit.authen.core.service.EntOutDataService;
import com.jd.jr.boss.credit.domain.common.entity.CreditEntOutDataStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

/**
 * @Auther: anmeng
 * @Date: 2018/12/13 14:18
 * @Description:
 */
@Component
public class CrawlerEntDataResultListener implements MessageListener {

    private Logger logger= LoggerFactory.getLogger(CrawlerEntDataResultListener.class);

    @Resource
    private EntOutDataService outDataService;

    @Override
    public void onMessage(List<Message> messages) throws Exception {
        long startTime = System.currentTimeMillis();
        if (messages == null || messages.isEmpty()) {
            logger.warn("crawler message is null");
            return;
        }
        for(Message message : messages) {
            String msgText=message.getText();
            logger.info("receive message:{} ",msgText);

            List<Map> resultList=null;
            ObjectMapper objectMapper=new ObjectMapper();
            try {
                resultList=objectMapper.readValue(msgText, new TypeReference<List<Map>>(){});
            } catch (IOException e) {
                logger.error("数据格式异常");
                return;
            }
            if(resultList!=null){
                DateFormat dateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                resultList.forEach(result->{
                    try {
                        String keyword=(String)result.get("enterpriseName");
                        String batchId=(String)result.get("batchId");
                        String crawlerTime=(String)result.get("crawlerTime");
                        Integer tryTimes=(Integer)result.get("count");
                        String flag=(String)result.get("flag");
                        CreditEntOutDataStatus outDataStatus=new CreditEntOutDataStatus();
                        outDataStatus.setBatchId(batchId);
                        outDataStatus.setFinishTime(dateFormat.parse(crawlerTime));
                        outDataStatus.setQueryParam(keyword);
                        outDataStatus.setTryTimes(tryTimes);
                        if("noCrawled".equals(flag)){
                            outDataStatus.setStatus("NO_CRAWLED");
                        }else if("success".equals(flag)){
                            outDataStatus.setStatus("SUCCESS");
                        }else{
                            outDataStatus.setStatus("FAIL");
                        }
                        outDataService.updateSingleDataStatus(outDataStatus);
                    } catch (ParseException e) {
                        logger.error("更新数据状态失败",e);
                    }
                });
            }
        }
    }
}
