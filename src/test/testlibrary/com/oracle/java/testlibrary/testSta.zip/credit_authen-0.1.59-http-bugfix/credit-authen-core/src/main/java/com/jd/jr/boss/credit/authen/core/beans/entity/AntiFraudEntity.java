package com.jd.jr.boss.credit.authen.core.beans.entity;


import java.io.Serializable;

/**
 *
 * @author: liuwei55
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
public class AntiFraudEntity implements Serializable{

	private static final long serialVersionUID = -465455366312903938L;
	/**
	 * 商户号
	 */
	private String merchantNum;
	/**
	 * 商户名称
	 */
	private String merchantName;
	/**
	 * 是否命中  0：命中 1：未命中
	 */
	private String isHit;
	/**
	 *  网址
	 */
	private String webSiteUrl;
	/**
	 *  命中词 黄、赌、毒
	 */
	private String keyWord;

	public String getMerchantNum() {
		return merchantNum;
	}

	public void setMerchantNum(String merchantNum) {
		this.merchantNum = merchantNum;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getIsHit() {
		return isHit;
	}

	public void setIsHit(String isHit) {
		this.isHit = isHit;
	}

	public String getWebSiteUrl() {
		return webSiteUrl;
	}

	public void setWebSiteUrl(String webSiteUrl) {
		this.webSiteUrl = webSiteUrl;
	}

	public String getKeyWord() {
		return keyWord;
	}

	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}
}
