package com.jd.jr.boss.credit.core.test;

import com.jd.fastjson.JSON;
import com.jd.jr.boss.credit.domain.common.enums.CreditYesOrNoEnum;
import com.jd.jr.boss.credit.facade.authen.api.CreditGroupUserFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditVipStatisticFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.*;
import com.jd.jr.boss.credit.facade.authen.beans.response.CreditModifyDetail;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.entity.*;
import com.wangyin.boss.credit.admin.enums.CreditOpenStatusEnum;
import com.wangyin.boss.credit.admin.enums.EnterpriseProductEnum4Common;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.lang3.ArrayUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption :
 * @date ：2018/11/7 12:22
 * @return
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})
public class VipStatisticFacadeTest {

    @Resource
    private CreditVipStatisticFacade creditVipStatisticFacade;
    @Resource
    private CreditGroupUserFacade groupUserFacade;

    @Test
    public void addVipCompanyListTest(){
        CreditRequestParam<List<CreditVipTask>> queryParam=new CreditRequestParam<>();
        queryParam.setSystemId("a3885821df2711e7a293ecf4bbcdd49c");
        queryParam.setTradeNo("ssss");
        List<CreditVipTask> addListPrm = new ArrayList<>();
        CreditVipTask task=new CreditVipTask();
        task.setAlarmRuleId(117);
        task.setCreatedDate(new Date());
        task.setModifiedDate(new Date());
        task.setMonitorStart(new Date());
        task.setTaskEnd(new Date());
        task.setCertificateNumber("914403001922038216");
        task.setCreator("yjl@qq.com");
        task.setEntName("华为技术有限公司"); // 华为技术有限公司   914403001922038216
        task.setUserPin("a3885821df2711e7a293ecf4bbcdd49c");
        task.setTaskProductList(new ArrayList<>());
        task.setQueryType("pro");
        task.setPerName("刘伟");
        task.setPerCode("150981197202284550");
        addListPrm.add(task);
        queryParam.setParam(addListPrm);
        queryParam.setOperator("yjl@qq.com");
        CreditResponseData<List<String>> resp= creditVipStatisticFacade.addVipCompanyList(queryParam);
        System.out.println("resp : " + GsonUtil.getInstance().toJson(resp));
    }

    @Test
    public void selectGroupIdByUserPinTest(){
        CreditRequestParam<VipTaskDtoQueryParam> queryParam = new CreditRequestParam<VipTaskDtoQueryParam>();
        VipTaskDtoQueryParam dtoQueryParam = new VipTaskDtoQueryParam();
        dtoQueryParam.setUserPin("a3885821df2711e7a293ecf4bbcdd49c");
        queryParam.setParam(dtoQueryParam);
        Integer groupId =  groupUserFacade.selectOpenGroupIdByUserPin(queryParam);
        System.out.println("groupId : " + groupId);
    }

    @Test
    public void queryMerchantVipTaskListTest(){
        CreditRequestParam<VipTaskDtoQueryParam> prm = new CreditRequestParam<VipTaskDtoQueryParam>();
        VipTaskDtoQueryParam queryPrm = new VipTaskDtoQueryParam();
//        List<String> taskIds = new ArrayList<>();
//        taskIds.add("8475");
//        queryPrm.setTaskIds(taskIds);
//        queryPrm.setMerchantNo("110040816");
        queryPrm.setUserPin("a3888199df2711e7a293ecf4bbcdd49c");
        queryPrm.setEntName("小米科技有限责任公司");
        queryPrm.setTaskStatus(CreditOpenStatusEnum.OPEN.toName());
        prm.setParam(queryPrm);
        CreditResponseData<List<CreditVipTask>> resp =  creditVipStatisticFacade.queryMerchantVipTaskList(prm);
        System.out.println("resp : " + GsonUtil.getInstance().toJson(resp));
    }

    @Test
    public void updateAlarmRuleAndDetail4ApiTest(){
        CreditRequestParam<CreditVipAlarmRule> prm = new CreditRequestParam<CreditVipAlarmRule>();
        CreditVipAlarmRule queryPrm = new CreditVipAlarmRule();
        queryPrm.setId(117);
        queryPrm.setRuleName("霖爷把许爷的方案变更了");
        queryPrm.setModifier("yjl");
        queryPrm.setModifiedDate(new Date());
        List<CreditVipAlarmRuleDetail> detailList = new ArrayList<>();
        CreditVipAlarmRuleDetail detail1 = new CreditVipAlarmRuleDetail();
        detail1.setTriggerEvent("entCheckUpdate");
        detail1.setAlarmLevel("RED");
        detailList.add(detail1);
        CreditVipAlarmRuleDetail detail2 = new CreditVipAlarmRuleDetail();
        detail2.setTriggerEvent("illegalUpdate1");
        detail2.setAlarmLevel("RED");
        detailList.add(detail2);
        queryPrm.setDetailList(detailList);
        prm.setParam(queryPrm);
        CreditResponseData<String> resp =  creditVipStatisticFacade.updateAlarmRuleAndDetail4Api(prm);
        System.out.println("resp : " + GsonUtil.getInstance().toJson(resp));
    }

    @Test
    public void queryAlarmRuleDetailTest(){
        VipAlarmRuleQueryParam ruleDetailPrm = new VipAlarmRuleQueryParam();
        ruleDetailPrm.setRuleId(117);
        CreditVipAlarmRule resp =  creditVipStatisticFacade.queryAlarmRuleDetail(ruleDetailPrm);
        System.out.println("resp : " + GsonUtil.getInstance().toJson(resp));
    }

    @Test
    public void insertBatchVipAlarmRuleDetailsTest(){
        List<CreditVipAlarmRuleDetail> ruleDetailList = new ArrayList();
        CreditVipAlarmRuleDetail detail = new CreditVipAlarmRuleDetail();
        detail.setRelRuleId(112);
        ruleDetailList.add(detail);
        CreditVipAlarmRuleDetail detail2 = new CreditVipAlarmRuleDetail();
        detail2.setTriggerEvent("legalPersonNameUpdate");
        detail2.setTriggerEventType("basicInfo");
        detail2.setAlarmLevel("RED");
        ruleDetailList.add(detail2);
        int resp =  creditVipStatisticFacade.insertBatchVipAlarmRuleDetails(ruleDetailList);
        System.out.println("resp : " + GsonUtil.getInstance().toJson(resp));
    }


    //增值版接口从这里开始测试
    @Test
    public void queryMonitorEnt(){
        CreditRequestParam<VipQueryParam> reqParam=new CreditRequestParam<VipQueryParam>();
        reqParam.setSystemId("a3884c68df2711e7a293ecf4bbcdd49c");
        reqParam.setTradeNo("ssss");
        VipQueryParam vipQueryParam=new VipQueryParam();
        vipQueryParam.setMerchantId(1066);
        vipQueryParam.setMerchantNo("110040816");
        vipQueryParam.setUserPin("a3884c68df2711e7a293ecf4bbcdd49c");
        reqParam.setParam(vipQueryParam);
        CreditResponseData data=creditVipStatisticFacade.queryMonitorEnt(reqParam);
        System.out.println(JSON.toJSONString(data));
    }

    @Test
    public void queryVipTaskList(){
        VipTaskDtoQueryParam vipTaskDtoQueryParam=new VipTaskDtoQueryParam();
        vipTaskDtoQueryParam.setUserPin("4069ea44257a436dbaef9289705ee586");
        System.out.println(JSON.toJSONString(creditVipStatisticFacade.queryVipTaskList(vipTaskDtoQueryParam)));

    }

    @Test
    public void queryVipChangeInfo(){
        VipChangeQueryParam vipTaskDtoQueryParam=new VipChangeQueryParam();
        vipTaskDtoQueryParam.setUserPin("a3885821df2711e7a293ecf4bbcdd49c");
        vipTaskDtoQueryParam.setMerchantId(1076);

        CreditPage<CreditVipAlarmResult> response = creditVipStatisticFacade.queryVipChangeInfo(vipTaskDtoQueryParam);
        System.out.println("response : "+ GsonUtil.getInstance().toJson(response));
    }

    @Test
    public void queryVipProducts(){
        System.out.println(JSON.toJSONString(creditVipStatisticFacade.queryVipProducts(1179)));
    }

    @Test
    public void updateMonitorStatus(){
        VipTaskDtoQueryParam vipTaskDtoQueryParam=new VipTaskDtoQueryParam();
        vipTaskDtoQueryParam.setUserPin("4069ea44257a436dbaef9289705ee586");
        vipTaskDtoQueryParam.setModifier("ckj");
        List<String> taskIds=new ArrayList<>();
        taskIds.add("8514");
        vipTaskDtoQueryParam.setTaskIds(taskIds);
        vipTaskDtoQueryParam.setTaskStatus("OPEN");
        System.out.println(JSON.toJSONString(creditVipStatisticFacade.updateMonitorStatus(vipTaskDtoQueryParam)));
    }


    @Test
    public void queryVipTaskProducts(){
        VipTaskProductsQueryParam param=new VipTaskProductsQueryParam();
        param.setEntName("保定力敏商贸有限公司");
        param.setMerchantId(1066);
        System.out.println(JSON.toJSONString(creditVipStatisticFacade.queryVipTaskProducts(param)));
    }

    @Test
    public void queryModifyDetail(){
        VipTaskProductsResultQueryParam param=new VipTaskProductsResultQueryParam();
        param.setTaskId(8713);
        param.setHistory(CreditYesOrNoEnum.YES.toName());
        param.setRelationType(CreditYesOrNoEnum.NO.toName()); // YES-关联企业；NO-目标企业
        param.setProductCode(EnterpriseProductEnum4Common.ENTERPRISE_EQUITYINFO_QUERY.toName());
        CreditModifyDetail  response = creditVipStatisticFacade.queryModifyDetail(param);
        System.out.println("response : "+GsonUtil.getInstance().toJson(response));
    }


    @Test
    public void addVipCompany(){
        CreditRequestParam<CreditVipTask> queryParam=new CreditRequestParam<>();
        queryParam.setSystemId("a3885821df2711e7a293ecf4bbcdd49c");
        queryParam.setTradeNo("ssss");
        CreditVipTask task=new CreditVipTask();
        task.setAlarmRuleId(1);
        task.setCreatedDate(new Date());
        task.setModifiedDate(new Date());
        task.setMonitorStart(new Date());
        task.setTaskEnd(new Date());
        task.setCertificateNumber("914115005672601531");
        task.setCreator("liuwei55@jd.com");
        task.setEntName("华为技术有限公司124");
        task.setUserPin("4069ea44257a436dbaef9289705ee586");
        task.setTaskProductList(new ArrayList<>());
        queryParam.setParam(task);
        queryParam.setOperator("liuwei55@jd.com");
        CreditResponseData<List<String>> resp= creditVipStatisticFacade.addVipCompany(queryParam);
        System.out.println("resp : " + GsonUtil.getInstance().toJson(resp));
    }

    @Test
    public void modifyBlackLists(){
        CreditRequestParam<String> queryParam=new CreditRequestParam<>();
        queryParam.setSystemId("a3884c68df2711e7a293ecf4bbcdd49c");
        queryParam.setParam("北京京东世纪贸易有限公司");
        queryParam.setTradeNo("ssss");
    }

    @Test
    public void selectVipTaskPageByParam(){
        VipTaskDtoQueryParam param=new VipTaskDtoQueryParam();
        param.setUserPin("a3884c68df2711e7a293ecf4bbcdd49c");
        System.out.println(JSON.toJSONString(creditVipStatisticFacade.selectVipTaskPageByParam(param)));
    }

    @Test
    public void batchModifyVipMerchantMonitorStatus () throws Exception {
        CreditRequestParam<CreditVip> param=new CreditRequestParam();
        param.setOperator("a3884c68df2711e7a293ecf4bbcdd49c");
        param.setSystemId("a3884c68df2711e7a293ecf4bbcdd49c");
        param.setOperator("liuwei55@jd.com");
        param.setTradeNo("sdfas");
        CreditVip vip=new CreditVip();
        vip.setVipId(58);
        param.setParam(vip);
        System.out.println(JSON.toJSONString(creditVipStatisticFacade.batchModifyVipMerchantMonitorStatus(param)));
    }

    @Test
    public void selectByMerchantId(){
        CreditRequestParam<String> queryParam=new CreditRequestParam<>();
        queryParam.setSystemId("a3884c68df2711e7a293ecf4bbcdd49c");
        queryParam.setParam("北京京东世纪贸易有限公司");
        queryParam.setTradeNo("ssss");
    }

    @Test
    public void insertVipMerchant(){
        CreditRequestParam<String> queryParam=new CreditRequestParam<>();
        queryParam.setSystemId("a3884c68df2711e7a293ecf4bbcdd49c");
        queryParam.setParam("北京京东世纪贸易有限公司");
        queryParam.setTradeNo("ssss");
    }


    @Test
    public void insertBatchVipTime(){
        CreditRequestParam<String> queryParam=new CreditRequestParam<>();
        queryParam.setSystemId("a3884c68df2711e7a293ecf4bbcdd49c");
        queryParam.setParam("北京京东世纪贸易有限公司");
        queryParam.setTradeNo("ssss");
    }

    @Test
    public void queryAlarmRule(){
        VipAlarmRuleQueryParam queryParam=new VipAlarmRuleQueryParam();
        queryParam.setUserPin("a3884c68df2711e7a293ecf4bbcdd49c");
        System.out.println(JSON.toJSONString(creditVipStatisticFacade.queryAlarmRule(queryParam)));
    }

    //ok
    @Test
    public void queryAlarmRuleDetail(){
        VipAlarmRuleQueryParam queryParam=new VipAlarmRuleQueryParam();
        queryParam.setUserPin("930637397e514ff6ba2463b7f40aac46");
        queryParam.setRuleId(164);
        System.out.println(JSON.toJSONString(creditVipStatisticFacade.queryAlarmRuleDetail(queryParam)));
    }

    //OK
    @Test
    public void insertAlarmRule(){
        CreditVipAlarmRule queryParam=new CreditVipAlarmRule();
        queryParam.setUserPin("a3884c68df2711e7a293ecf4bbcdd49c");
        queryParam.setModifier("ckj");
        queryParam.setCreatedDate(new Date());
        queryParam.setModifiedDate(new Date());
        queryParam.setDetailList(new ArrayList<>());
        queryParam.setRelVipId(2);
        queryParam.setRuleStatus("OPEN");
        System.out.println(JSON.toJSONString(creditVipStatisticFacade.insertAlarmRule(queryParam)));
    }

    //OK
    @Test
    public void updateAlarmRule(){
        CreditVipAlarmRule queryParam=new CreditVipAlarmRule();
        queryParam.setModifier("ckj");
        queryParam.setId(1);
        System.out.println(JSON.toJSONString(creditVipStatisticFacade.updateAlarmRule(queryParam)));
    }



    @Test
    public void testQueryEntRelation(){
        CreditRequestParam<String> queryParam=new CreditRequestParam<>();
        queryParam.setSystemId("a3885821df2711e7a293ecf4bbcdd49c");
        queryParam.setParam("华为技术有限公司"); // 小米科技有限责任公司 关联企业200多家; 华为技术有限公司 5 家
        queryParam.setTradeNo("ssss");
        CreditResponseData<List<String>> resp= creditVipStatisticFacade.queryRelationEnt(queryParam);
        System.out.println("resp : " + GsonUtil.getInstance().toJson(resp));
    }
    @Test
    public void cleanRelation(){
        CreditRequestParam<String> queryParam=new CreditRequestParam<>();
        queryParam.setSystemId("a3885821df2711e7a293ecf4bbcdd49c");
        queryParam.setParam("华为技术有限公司"); // 小米科技有限责任公司 关联企业200多家; 华为技术有限公司 5 家
        queryParam.setTradeNo("ssss");
        CreditResponseData resp= groupUserFacade.cleanDataVipGroup(queryParam);
        System.out.println("resp : " + GsonUtil.getInstance().toJson(resp));
    }

    @Test
    public void selectGroupUserList(){
        CreditRequestParam<VipGroupQueryParam> queryParam = new CreditRequestParam<VipGroupQueryParam>();
        VipGroupQueryParam vipGroupQueryParam = new VipGroupQueryParam();
        vipGroupQueryParam.setStart(null);
        vipGroupQueryParam.setLimit(null);
        vipGroupQueryParam.setMerchantId(1152);
//        vipGroupQueryParam.setUserPin("e5604bb5963146b28f8c1d3be3d0b086");
        queryParam.setParam(vipGroupQueryParam);
        CreditPage<CreditVipGroupUser> resp= groupUserFacade.selectGroupUserList(queryParam);
        System.out.println("resp : " + GsonUtil.getInstance().toJson(resp));
    }

    @Test
    public void selectUserInGroupEmailList(){
        CreditRequestParam<VipGroupQueryParam> queryParam = new CreditRequestParam<VipGroupQueryParam>();
        VipGroupQueryParam vipGroupQueryParam = new VipGroupQueryParam();
        vipGroupQueryParam.setStart(null);
        vipGroupQueryParam.setLimit(null);
        vipGroupQueryParam.setUserPin("a388965fdf2711e7a293ecf4bbcdd49c");
        queryParam.setParam(vipGroupQueryParam);
        CreditPage<String> resp= groupUserFacade.selectUserInGroupEmailList(queryParam);
        System.out.println("resp : " + GsonUtil.getInstance().toJson(resp));
        resp.getRows().removeAll(Collections.singletonList(null));
        String eamilStr = ArrayUtils.toString(resp.getRows());
        System.out.println("eamilStr : " + eamilStr);
    }

}
