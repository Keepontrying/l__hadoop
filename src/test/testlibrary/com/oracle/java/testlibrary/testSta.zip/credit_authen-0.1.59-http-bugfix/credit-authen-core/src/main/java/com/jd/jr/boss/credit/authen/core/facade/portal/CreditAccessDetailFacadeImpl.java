package com.jd.jr.boss.credit.authen.core.facade.portal;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.authen.core.service.AccessDetailsService;
import com.jd.jr.boss.credit.facade.authen.api.CreditAccessDetailFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.AccessDetailQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.wangyin.boss.credit.admin.entity.CreditAccessDetails;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption : 门户业务详单
 * @date ：2017年3月30日 下午10:21:21
 * @return
 */
@Service("creditAccessDetailFacade")
public class CreditAccessDetailFacadeImpl implements CreditAccessDetailFacade {

    private Logger logger = LoggerFactory.getLogger(CreditProductFacadeImpl.class);

    @Resource
    private AccessDetailsService accessDetailsService;

    @Override
    public CreditPage<CreditAccessDetails> queryAccessDetailsList(AccessDetailQueryParam queryPageParam) {
        CreditPage<CreditAccessDetails> result = accessDetailsService.queryAccessDetailsList(queryPageParam);
        return result;
    }

}
