package com.jd.jr.boss.credit.core.test.listener;

import com.jd.jr.boss.credit.authen.core.jms.autoSewage.AutoSewageListener;
import com.jdjr.fmq.common.message.Message;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @desciption : 排污处理
 * @author : liuwei@jd.com
 * @date ：2017年7月20日 下午5:56:59
 * @version 1.0
 * @return  */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring/spring-authen.xml"})

public class AutoSewageListenerTest {

	@Resource
	private AutoSewageListener autoSewageListener;

	@Test
	public void testMessage() throws Exception {
		String topic ="autosewage_url";
		String businessId = "aaabb";
		String content = "{\"systemId\":\"a3884c68df2711e7a293ecf4bbcdd49c\",\"fileUrl\":\"/upload/elimNegReport/user_upload/20190118/110040816_1547784106756_aaa.xlsx\",\"batchNo\":\"ENR201901181201467070\",\"merchantNo\":\"110040816\"}";
		List<Message> messages = new ArrayList<>();
		Message message = new Message();
		message.setText(content);
		messages.add(message);
		autoSewageListener.onMessage(messages);

	}


}
