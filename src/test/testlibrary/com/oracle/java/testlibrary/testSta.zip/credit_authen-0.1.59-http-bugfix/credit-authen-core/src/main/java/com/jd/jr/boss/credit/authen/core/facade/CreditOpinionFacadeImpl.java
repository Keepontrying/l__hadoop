package com.jd.jr.boss.credit.authen.core.facade;

import com.jd.jr.boss.credit.authen.core.beans.request.NetTrackerEntQueryParam;
import com.jd.jr.boss.credit.authen.core.service.NetTrackerService;
import com.jd.jr.boss.credit.domain.common.entity.CreditNetTrackerEnterprise;
import com.jd.jr.boss.credit.domain.common.entity.CreditNetTrackerGroup;
import com.jd.jr.boss.credit.facade.authen.api.CreditOpinionFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.FocusEnterpriseQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.exception.CreditBusinessException;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.utils.GsonUtil;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by anmeng on 2017/11/9.
 */
@Component("creditOpinionFacade")
public class CreditOpinionFacadeImpl implements CreditOpinionFacade {

    private Logger logger= LoggerFactory.getLogger(CreditOpinionFacadeImpl.class);

    @Resource
    private NetTrackerService netTrackerService;

    /**
     * 查询关注企业
     *
     * @param queryParam
     * @return
     */
    @Override
    public CreditPage<CreditNetTrackerEnterprise> queryFocusEnterprise(FocusEnterpriseQueryParam queryParam) {
        if(queryParam==null){
            throw new CreditBusinessException("参数错误：入参不能为空！");
        }

        CreditPage<CreditNetTrackerEnterprise> result= null;
        try {
            logger.info("queryFocusEnterprise 查询入参："+GsonUtil.getInstance().toJson(queryParam));
            NetTrackerEntQueryParam param=new NetTrackerEntQueryParam();
            param.setEnterpriseName(queryParam.getEnterpriseName());
            param.setGroupId(queryParam.getGroupId());
            param.setMerchantId(queryParam.getMerchantId());
            param.setLimit(queryParam.getLimit());
            param.setStart(queryParam.getStart());
            result = netTrackerService.queryEnterprise(param);
            logger.info("queryFocusEnterprise 返回结果："+GsonUtil.getInstance().toJson(result));
        } catch (Exception e) {
            e.printStackTrace();
            throw new CreditBusinessException("authen查询失败！");
        }
        return result;
    }

    /**
     * 查询企业分组
     *
     * @param merchantId
     * @return
     */
    @Override
    public List<CreditNetTrackerGroup> queryTrackerGroup(Integer merchantId) {
        if(merchantId==null){
            throw new CreditBusinessException("参数错误：入参不能为空！");
        }
        List<CreditNetTrackerGroup> groupList= null;
        try {
            logger.info("queryTrackerGroup入参："+merchantId);
            groupList = netTrackerService.queryEntGroup(merchantId);
            logger.info("queryTrackerGroup返回结果："+GsonUtil.getInstance().toJson(groupList));
        } catch (Exception e) {
            e.printStackTrace();
            throw new CreditBusinessException("authen查询失败！");
        }
        return groupList;
    }

    /**
     * 查询分组统计信息
     *
     * @param merchantId
     * @return
     */
    @Override
    public List<CreditNetTrackerGroup> queryGroupStatistics(Integer merchantId) {
        if(merchantId==null){
            throw new CreditBusinessException("参数错误：入参不能为空！");
        }
        List<CreditNetTrackerGroup> statisticsList=null;
        try {
            logger.info("queryGroupStatistics入参："+merchantId);
            statisticsList=netTrackerService.queryEntGroupStatistics(merchantId);
            logger.info("queryGroupStatistics返回结果:"+GsonUtil.getInstance().toJson(statisticsList));
        } catch (Exception e) {
            e.printStackTrace();
            throw new CreditBusinessException("authen查询失败！");
        }
        return statisticsList;
    }

    /**
     * 关注企业
     *
     * @param enterprise
     */
    @Override
    public Integer focusEnterprise(CreditNetTrackerEnterprise enterprise,String userPin) {
        if(enterprise==null){
            throw new CreditBusinessException("参数错误：入参不能为空！");
        }
        try {
            logger.info("focusEnterprise入参："+GsonUtil.getInstance().toJson(enterprise));
            Integer focusId=netTrackerService.addFocusEnt(enterprise,userPin);
            return focusId;
        } catch(CreditBusinessException e){
            throw e;
        }catch (Exception e) {
            e.printStackTrace();
            throw new CreditBusinessException("添加关注失败！");
        }
    }

    /**
     * 取消关注企业
     *
     * @param enterprise
     */
    @Override
    public void cancelFocusEnterprise(CreditNetTrackerEnterprise enterprise) {
        if(enterprise==null){
            throw new CreditBusinessException("参数错误：入参不能为空！");
        }

        if(enterprise.getMerchantId()==null||StringUtil.isBlank(enterprise.getOutEnterpriseId())){
            throw new CreditBusinessException("参数错误：未找到关注的企业！");
        }
        try {
            logger.info("cancelFocusEnterprise入参："+GsonUtil.getInstance().toJson(enterprise));
            netTrackerService.removeFocusEnt(enterprise);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CreditBusinessException("取消关注失败！");
        }

    }

    /**
     * 修改企业归属分组
     *
     * @param enterprise
     */
    @Override
    public void changeEnterpriseGroup(CreditNetTrackerEnterprise enterprise) {
        if(enterprise==null||StringUtil.isBlank(enterprise.getOutEnterpriseId())||enterprise.getBelongGroup()==null){
            throw new CreditBusinessException("参数错误：参数不合法！");
        }
        try {
            logger.info("changeEnterpriseGroup入参："+GsonUtil.getInstance().toJson(enterprise));
            netTrackerService.addEnterpriseToGroup(enterprise);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CreditBusinessException("修改企业归属分组失败！");
        }
    }

    /**
     * 修改分组信息
     *
     * @param group
     */
    @Override
    public void modifyTrackerGroup(CreditNetTrackerGroup group) {
        if(group==null||StringUtil.isBlank(group.getGroupName())){
            throw new CreditBusinessException("参数错误：参数不合法！");
        }
        try {
            logger.info("modifyTrackerGroup入参："+GsonUtil.getInstance().toJson(group));
            netTrackerService.updateEntGroup(group);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CreditBusinessException("修改分组信息失败！");
        }
    }

    /**
     * 添加分组
     *
     * @param group
     */
    @Override
    public Integer addTrackerGroup(CreditNetTrackerGroup group) {
        if(group==null||StringUtil.isBlank(group.getGroupName())){
            throw new CreditBusinessException("参数错误：参数不合法！");
        }
        try {
            logger.info("addTrackerGroup入参："+GsonUtil.getInstance().toJson(group));
            return netTrackerService.createEntGroup(group);
        } catch (Exception e) {
            e.printStackTrace();
            throw new CreditBusinessException("添加分组失败！");
        }
    }

    /**
     * 判断企业是否已关注，如果关注，返回关注信息,支持按照企业名称或企业id批量查询
     * 入参：
     * 1、merchantId+enterpriseNameList
     * 2、merchantId+enterpriseIdList
     * @param queryParam
     * @return
     */
    @Override
    public List<CreditNetTrackerEnterprise> judgeAndQueryFocusEnterprise(FocusEnterpriseQueryParam queryParam) {
        if(queryParam==null){
            throw new CreditBusinessException("参数错误：入参不能为空！");
        }
        if(queryParam.getMerchantId()==null||queryParam.getEnterpriseNameList()==null){
            throw new CreditBusinessException("参数错误：参数非法！");
        }
        List<CreditNetTrackerEnterprise> enterpriseList= null;
        try {
            logger.info("judgeAndQueryFocusEnterprise入参："+GsonUtil.getInstance().toJson(queryParam));
            NetTrackerEntQueryParam param=new NetTrackerEntQueryParam();
            param.setMerchantId(queryParam.getMerchantId());
            param.setEnterpriseNameList(queryParam.getEnterpriseNameList());
            param.setEnterpriseIdList(queryParam.getEnterpriseIdList());
            enterpriseList = netTrackerService.judgeAndQueryFocusEnterprise(param);
            logger.info("judgeAndQueryFocusEnterprise返回结果:"+GsonUtil.getInstance().toJson(enterpriseList));
        } catch (Exception e) {
            e.printStackTrace();
            throw new CreditBusinessException("authen查询失败！");
        }
        return enterpriseList;
    }

    /**
     * 查询单个关注企业，入参有两种组合：
     * 1、merchantId+enterpriseId
     * 2、trackerId
     *
     * @param queryParam
     * @return
     */
    @Override
    public CreditNetTrackerEnterprise queryFocusEnterpriseSingle(FocusEnterpriseQueryParam queryParam) {
        if(queryParam==null){
            throw new CreditBusinessException("参数错误：入参不能为空！");
        }
        NetTrackerEntQueryParam param=new NetTrackerEntQueryParam();
        if(queryParam.getTrackerId()!=null){
            param.setTrackerId(queryParam.getTrackerId());
        }else if(StringUtil.isNotBlank(queryParam.getEnterpriseId())&&queryParam.getMerchantId()!=null){
            param.setMerchantId(queryParam.getMerchantId());
            param.setEnterpriseId(queryParam.getEnterpriseId());
        }else{
            throw new CreditBusinessException("参数错误：非法入参！");
        }


        CreditNetTrackerEnterprise enterprise=netTrackerService.queryEnterpriseSingle(param);
        return enterprise;
    }
}
