package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.request.WarningRuleQueryParam;
import com.jd.jr.boss.credit.domain.common.entity.CreditWarningRule;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by anmeng on 2017/1/18.
 */
@Repository
public interface CreditWarningRuleDao {

    /**
     * 查询预警规则
     * @param queryParam
     * @return
     */
    List<CreditWarningRule> queryWaringRule(WarningRuleQueryParam queryParam);
}
