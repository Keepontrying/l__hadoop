package com.jd.jr.boss.credit.authen.core.exception;

/**
 *vip 存库 异常
 */
public class CreditVipDbException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1066922463769034687L;

	public CreditVipDbException(String message){
		super(message);
	}

	public CreditVipDbException(){
		super("存库异常");
	}
}
