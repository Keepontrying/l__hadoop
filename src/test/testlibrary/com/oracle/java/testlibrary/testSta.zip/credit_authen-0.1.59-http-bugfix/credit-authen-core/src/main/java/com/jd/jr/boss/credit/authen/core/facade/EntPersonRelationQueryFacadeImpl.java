package com.jd.jr.boss.credit.authen.core.facade;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.service.EntPersonRelationQueryService;
import com.jd.jr.boss.credit.facade.authen.api.EntPersonRelationQueryFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.EntPersonRelationQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.creditReport.CreateReportResponse;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.enums.UploadFileTypeEnum;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * Created by zhanghui12 on 2018/8/8.
 * 疑似关联企业批量查询
 */
@Service("entPersonRelationQueryFacade")
public class EntPersonRelationQueryFacadeImpl implements EntPersonRelationQueryFacade {
    private Logger logger = LoggerFactory.getLogger(EntPersonRelationQueryFacadeImpl.class);
    @Autowired
    private EntPersonRelationQueryService entPersonRelationQueryService;
    @Override
    public CreditResponseData batchQuery(CreditRequestParam<EntPersonRelationQueryParam> requestParam) {
        logger.info("EntPersonRelationQuery batchQuery begin,param:{}", JSONObject.toJSONString(requestParam ));
        CreditResponseData creditResponseData = new CreditResponseData();
        CreateReportResponse result = new CreateReportResponse();
        try {
            if (requestParam == null || requestParam.getParam() == null|| StringUtil.isEmpty(requestParam.getParam().getFileId())) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("EntPersonRelationQuery batchQuery error, requestParam is null");
                return creditResponseData;
            }
            Date now = new Date();
            logger.info("EntPersonRelationQuery batchQuery save to database");
            String batchNo = null;
            try {
                batchNo = entPersonRelationQueryService.saveBatchAndOrder(requestParam.getParam(), UploadFileTypeEnum.ENT_RELATION_BATCH_QUERY.getCode());
            } catch (Exception e) {
                logger.info(e.getMessage());
            }
            if (StringUtil.isNotEmpty(batchNo)) {
                logger.info("异步调用查询接口");
                entPersonRelationQueryService.batchTrade(requestParam.getParam(), batchNo);
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(result);
            } else {
                creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
                creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
                creditResponseData.setSuccess(false);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            logger.info("batchTrade finished,response:{}", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }

    @Override
    public CreditResponseData batchQueryInner(CreditRequestParam<EntPersonRelationQueryParam> requestParam) {
        logger.info("EntPersonRelationQuery batchQueryInner begin,param:{}", JSONObject.toJSONString(requestParam ));
        CreditResponseData creditResponseData = new CreditResponseData();
        CreateReportResponse result = new CreateReportResponse();
        try {
            if (requestParam == null || requestParam.getParam() == null|| StringUtil.isEmpty(requestParam.getParam().getFileId())) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.info("EntPersonRelationQuery batchQueryInner error, requestParam is null");
                return creditResponseData;
            }
            Date now = new Date();
            logger.info("EntPersonRelationQuery batchQueryInner save to database");
            String batchNo = null;
            try {
                batchNo = entPersonRelationQueryService.saveBatchAndOrder(requestParam.getParam(), UploadFileTypeEnum.ENT_RELATION_BATCH_QUERY_INNER.getCode());
            } catch (Exception e) {
                logger.error("EntPersonRelationQuery batchQueryInner error, {}", e);
            }
            if (StringUtil.isNotEmpty(batchNo)) {
                logger.info("EntPersonRelationQuery batchQueryInner 异步调用查询接口 start");
                entPersonRelationQueryService.batchTradeInner(requestParam.getParam(), batchNo);
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(result);
            } else {
                creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
                creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
                creditResponseData.setSuccess(false);
            }
        } catch (Exception e) {
            logger.error("EntPersonRelationQuery batchQueryInner error,{}", e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            logger.info("EntPersonRelationQuery batchQueryInner finished,response:{}", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }
}
