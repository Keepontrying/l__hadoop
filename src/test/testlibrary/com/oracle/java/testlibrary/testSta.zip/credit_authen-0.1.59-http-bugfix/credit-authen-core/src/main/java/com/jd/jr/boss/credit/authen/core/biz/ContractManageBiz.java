package com.jd.jr.boss.credit.authen.core.biz;

import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractDetailsRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractQueryRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractVerifyRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.contract.ContractContentResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.contract.ContractDetailsResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.contract.ContractQueryResponse;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.Response;
import com.wangyin.operation.common.beans.ResponseData;

/**
 *  企业站合同查询
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
public interface ContractManageBiz {
	
    /**
     * 分页查询合同
     * @author tangmingbo
     * @param contractPageQueryRequest
     * @return
     */
    void queryContractPage(ContractQueryRequest contractQueryRequest, Page<ContractQueryResponse> page) throws Exception;
    /**
     * 合同包含产品详情
     * @param contractDetailsRequest
     * @return
     */
    void queryContractDetails(ContractDetailsRequest contractDetailsRequest, ResponseData<ContractDetailsResponse> responseData) throws Exception;
    /**
     * 合同内容
     * @param contractDetailsRequest
     * @return
     */
    void queryContractContent(ContractDetailsRequest contractContentRequest, ResponseData<ContractContentResponse> responseData) throws Exception;
    /**
     * 合同确认结果
     * @param contractVerifyRequest
     * @return
     */
    void updateContractVerify(ContractVerifyRequest contractVerifyRequest, Response response) throws Exception;
    
}
