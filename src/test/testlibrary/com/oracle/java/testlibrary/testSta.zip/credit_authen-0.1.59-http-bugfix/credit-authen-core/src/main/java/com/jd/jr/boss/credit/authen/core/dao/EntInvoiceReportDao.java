package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.entity.CreditBaiwangAuthOrderEntity;
import org.springframework.data.mongodb.core.aggregation.ArrayOperators;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author ：zhanghui12
 * @date ：Created in 2019/3/20 11:25
 * @description：
 */
@Repository
public interface EntInvoiceReportDao {
    Integer insertAuthOrder(List<CreditBaiwangAuthOrderEntity> authList);

    List<CreditBaiwangAuthOrderEntity> getWaitNoticeOrder();

    List<CreditBaiwangAuthOrderEntity> getWaitingOrder();

    Integer updateAuthOrder(CreditBaiwangAuthOrderEntity authOrder);
}
