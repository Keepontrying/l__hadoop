package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CreditBfMonitorEntpriseExample implements Serializable {
    private static final long serialVersionUID = -8576606774866708771L;
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CreditBfMonitorEntpriseExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andEntNameIsNull() {
            addCriterion("ent_name is null");
            return (Criteria) this;
        }

        public Criteria andEntNameIsNotNull() {
            addCriterion("ent_name is not null");
            return (Criteria) this;
        }

        public Criteria andEntNameEqualTo(String value) {
            addCriterion("ent_name =", value, "entName");
            return (Criteria) this;
        }

        public Criteria andEntNameNotEqualTo(String value) {
            addCriterion("ent_name <>", value, "entName");
            return (Criteria) this;
        }

        public Criteria andEntNameGreaterThan(String value) {
            addCriterion("ent_name >", value, "entName");
            return (Criteria) this;
        }

        public Criteria andEntNameGreaterThanOrEqualTo(String value) {
            addCriterion("ent_name >=", value, "entName");
            return (Criteria) this;
        }

        public Criteria andEntNameLessThan(String value) {
            addCriterion("ent_name <", value, "entName");
            return (Criteria) this;
        }

        public Criteria andEntNameLessThanOrEqualTo(String value) {
            addCriterion("ent_name <=", value, "entName");
            return (Criteria) this;
        }

        public Criteria andEntNameLike(String value) {
            addCriterion("ent_name like", value, "entName");
            return (Criteria) this;
        }

        public Criteria andEntNameNotLike(String value) {
            addCriterion("ent_name not like", value, "entName");
            return (Criteria) this;
        }

        public Criteria andEntNameIn(List<String> values) {
            addCriterion("ent_name in", values, "entName");
            return (Criteria) this;
        }

        public Criteria andEntNameNotIn(List<String> values) {
            addCriterion("ent_name not in", values, "entName");
            return (Criteria) this;
        }

        public Criteria andEntNameBetween(String value1, String value2) {
            addCriterion("ent_name between", value1, value2, "entName");
            return (Criteria) this;
        }

        public Criteria andEntNameNotBetween(String value1, String value2) {
            addCriterion("ent_name not between", value1, value2, "entName");
            return (Criteria) this;
        }

        public Criteria andCreditCodeIsNull() {
            addCriterion("credit_code is null");
            return (Criteria) this;
        }

        public Criteria andCreditCodeIsNotNull() {
            addCriterion("credit_code is not null");
            return (Criteria) this;
        }

        public Criteria andCreditCodeEqualTo(String value) {
            addCriterion("credit_code =", value, "creditCode");
            return (Criteria) this;
        }

        public Criteria andCreditCodeNotEqualTo(String value) {
            addCriterion("credit_code <>", value, "creditCode");
            return (Criteria) this;
        }

        public Criteria andCreditCodeGreaterThan(String value) {
            addCriterion("credit_code >", value, "creditCode");
            return (Criteria) this;
        }

        public Criteria andCreditCodeGreaterThanOrEqualTo(String value) {
            addCriterion("credit_code >=", value, "creditCode");
            return (Criteria) this;
        }

        public Criteria andCreditCodeLessThan(String value) {
            addCriterion("credit_code <", value, "creditCode");
            return (Criteria) this;
        }

        public Criteria andCreditCodeLessThanOrEqualTo(String value) {
            addCriterion("credit_code <=", value, "creditCode");
            return (Criteria) this;
        }

        public Criteria andCreditCodeLike(String value) {
            addCriterion("credit_code like", value, "creditCode");
            return (Criteria) this;
        }

        public Criteria andCreditCodeNotLike(String value) {
            addCriterion("credit_code not like", value, "creditCode");
            return (Criteria) this;
        }

        public Criteria andCreditCodeIn(List<String> values) {
            addCriterion("credit_code in", values, "creditCode");
            return (Criteria) this;
        }

        public Criteria andCreditCodeNotIn(List<String> values) {
            addCriterion("credit_code not in", values, "creditCode");
            return (Criteria) this;
        }

        public Criteria andCreditCodeBetween(String value1, String value2) {
            addCriterion("credit_code between", value1, value2, "creditCode");
            return (Criteria) this;
        }

        public Criteria andCreditCodeNotBetween(String value1, String value2) {
            addCriterion("credit_code not between", value1, value2, "creditCode");
            return (Criteria) this;
        }

        public Criteria andRegNoIsNull() {
            addCriterion("reg_no is null");
            return (Criteria) this;
        }

        public Criteria andRegNoIsNotNull() {
            addCriterion("reg_no is not null");
            return (Criteria) this;
        }

        public Criteria andRegNoEqualTo(String value) {
            addCriterion("reg_no =", value, "regNo");
            return (Criteria) this;
        }

        public Criteria andRegNoNotEqualTo(String value) {
            addCriterion("reg_no <>", value, "regNo");
            return (Criteria) this;
        }

        public Criteria andRegNoGreaterThan(String value) {
            addCriterion("reg_no >", value, "regNo");
            return (Criteria) this;
        }

        public Criteria andRegNoGreaterThanOrEqualTo(String value) {
            addCriterion("reg_no >=", value, "regNo");
            return (Criteria) this;
        }

        public Criteria andRegNoLessThan(String value) {
            addCriterion("reg_no <", value, "regNo");
            return (Criteria) this;
        }

        public Criteria andRegNoLessThanOrEqualTo(String value) {
            addCriterion("reg_no <=", value, "regNo");
            return (Criteria) this;
        }

        public Criteria andRegNoLike(String value) {
            addCriterion("reg_no like", value, "regNo");
            return (Criteria) this;
        }

        public Criteria andRegNoNotLike(String value) {
            addCriterion("reg_no not like", value, "regNo");
            return (Criteria) this;
        }

        public Criteria andRegNoIn(List<String> values) {
            addCriterion("reg_no in", values, "regNo");
            return (Criteria) this;
        }

        public Criteria andRegNoNotIn(List<String> values) {
            addCriterion("reg_no not in", values, "regNo");
            return (Criteria) this;
        }

        public Criteria andRegNoBetween(String value1, String value2) {
            addCriterion("reg_no between", value1, value2, "regNo");
            return (Criteria) this;
        }

        public Criteria andRegNoNotBetween(String value1, String value2) {
            addCriterion("reg_no not between", value1, value2, "regNo");
            return (Criteria) this;
        }

        public Criteria andCreatedDateIsNull() {
            addCriterion("created_date is null");
            return (Criteria) this;
        }

        public Criteria andCreatedDateIsNotNull() {
            addCriterion("created_date is not null");
            return (Criteria) this;
        }

        public Criteria andCreatedDateEqualTo(Date value) {
            addCriterion("created_date =", value, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateNotEqualTo(Date value) {
            addCriterion("created_date <>", value, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateGreaterThan(Date value) {
            addCriterion("created_date >", value, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateGreaterThanOrEqualTo(Date value) {
            addCriterion("created_date >=", value, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateLessThan(Date value) {
            addCriterion("created_date <", value, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateLessThanOrEqualTo(Date value) {
            addCriterion("created_date <=", value, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateIn(List<Date> values) {
            addCriterion("created_date in", values, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateNotIn(List<Date> values) {
            addCriterion("created_date not in", values, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateBetween(Date value1, Date value2) {
            addCriterion("created_date between", value1, value2, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateNotBetween(Date value1, Date value2) {
            addCriterion("created_date not between", value1, value2, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdIsNull() {
            addCriterion("create_system_id is null");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdIsNotNull() {
            addCriterion("create_system_id is not null");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdEqualTo(String value) {
            addCriterion("create_system_id =", value, "createSystemId");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdNotEqualTo(String value) {
            addCriterion("create_system_id <>", value, "createSystemId");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdGreaterThan(String value) {
            addCriterion("create_system_id >", value, "createSystemId");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdGreaterThanOrEqualTo(String value) {
            addCriterion("create_system_id >=", value, "createSystemId");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdLessThan(String value) {
            addCriterion("create_system_id <", value, "createSystemId");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdLessThanOrEqualTo(String value) {
            addCriterion("create_system_id <=", value, "createSystemId");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdLike(String value) {
            addCriterion("create_system_id like", value, "createSystemId");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdNotLike(String value) {
            addCriterion("create_system_id not like", value, "createSystemId");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdIn(List<String> values) {
            addCriterion("create_system_id in", values, "createSystemId");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdNotIn(List<String> values) {
            addCriterion("create_system_id not in", values, "createSystemId");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdBetween(String value1, String value2) {
            addCriterion("create_system_id between", value1, value2, "createSystemId");
            return (Criteria) this;
        }

        public Criteria andCreateSystemIdNotBetween(String value1, String value2) {
            addCriterion("create_system_id not between", value1, value2, "createSystemId");
            return (Criteria) this;
        }

        public Criteria andModifiedDateIsNull() {
            addCriterion("modified_date is null");
            return (Criteria) this;
        }

        public Criteria andModifiedDateIsNotNull() {
            addCriterion("modified_date is not null");
            return (Criteria) this;
        }

        public Criteria andModifiedDateEqualTo(Date value) {
            addCriterion("modified_date =", value, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateNotEqualTo(Date value) {
            addCriterion("modified_date <>", value, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateGreaterThan(Date value) {
            addCriterion("modified_date >", value, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateGreaterThanOrEqualTo(Date value) {
            addCriterion("modified_date >=", value, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateLessThan(Date value) {
            addCriterion("modified_date <", value, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateLessThanOrEqualTo(Date value) {
            addCriterion("modified_date <=", value, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateIn(List<Date> values) {
            addCriterion("modified_date in", values, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateNotIn(List<Date> values) {
            addCriterion("modified_date not in", values, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateBetween(Date value1, Date value2) {
            addCriterion("modified_date between", value1, value2, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateNotBetween(Date value1, Date value2) {
            addCriterion("modified_date not between", value1, value2, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifierIsNull() {
            addCriterion("modifier is null");
            return (Criteria) this;
        }

        public Criteria andModifierIsNotNull() {
            addCriterion("modifier is not null");
            return (Criteria) this;
        }

        public Criteria andModifierEqualTo(String value) {
            addCriterion("modifier =", value, "modifier");
            return (Criteria) this;
        }

        public Criteria andModifierNotEqualTo(String value) {
            addCriterion("modifier <>", value, "modifier");
            return (Criteria) this;
        }

        public Criteria andModifierGreaterThan(String value) {
            addCriterion("modifier >", value, "modifier");
            return (Criteria) this;
        }

        public Criteria andModifierGreaterThanOrEqualTo(String value) {
            addCriterion("modifier >=", value, "modifier");
            return (Criteria) this;
        }

        public Criteria andModifierLessThan(String value) {
            addCriterion("modifier <", value, "modifier");
            return (Criteria) this;
        }

        public Criteria andModifierLessThanOrEqualTo(String value) {
            addCriterion("modifier <=", value, "modifier");
            return (Criteria) this;
        }

        public Criteria andModifierLike(String value) {
            addCriterion("modifier like", value, "modifier");
            return (Criteria) this;
        }

        public Criteria andModifierNotLike(String value) {
            addCriterion("modifier not like", value, "modifier");
            return (Criteria) this;
        }

        public Criteria andModifierIn(List<String> values) {
            addCriterion("modifier in", values, "modifier");
            return (Criteria) this;
        }

        public Criteria andModifierNotIn(List<String> values) {
            addCriterion("modifier not in", values, "modifier");
            return (Criteria) this;
        }

        public Criteria andModifierBetween(String value1, String value2) {
            addCriterion("modifier between", value1, value2, "modifier");
            return (Criteria) this;
        }

        public Criteria andModifierNotBetween(String value1, String value2) {
            addCriterion("modifier not between", value1, value2, "modifier");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredIsNull() {
            addCriterion("ent_monitored is null");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredIsNotNull() {
            addCriterion("ent_monitored is not null");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredEqualTo(String value) {
            addCriterion("ent_monitored =", value, "entMonitored");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredNotEqualTo(String value) {
            addCriterion("ent_monitored <>", value, "entMonitored");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredGreaterThan(String value) {
            addCriterion("ent_monitored >", value, "entMonitored");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredGreaterThanOrEqualTo(String value) {
            addCriterion("ent_monitored >=", value, "entMonitored");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredLessThan(String value) {
            addCriterion("ent_monitored <", value, "entMonitored");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredLessThanOrEqualTo(String value) {
            addCriterion("ent_monitored <=", value, "entMonitored");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredLike(String value) {
            addCriterion("ent_monitored like", value, "entMonitored");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredNotLike(String value) {
            addCriterion("ent_monitored not like", value, "entMonitored");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredIn(List<String> values) {
            addCriterion("ent_monitored in", values, "entMonitored");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredNotIn(List<String> values) {
            addCriterion("ent_monitored not in", values, "entMonitored");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredBetween(String value1, String value2) {
            addCriterion("ent_monitored between", value1, value2, "entMonitored");
            return (Criteria) this;
        }

        public Criteria andEntMonitoredNotBetween(String value1, String value2) {
            addCriterion("ent_monitored not between", value1, value2, "entMonitored");
            return (Criteria) this;
        }

        public Criteria andEntBeginDateIsNull() {
            addCriterion("ent_begin_date is null");
            return (Criteria) this;
        }

        public Criteria andEntBeginDateIsNotNull() {
            addCriterion("ent_begin_date is not null");
            return (Criteria) this;
        }

        public Criteria andEntBeginDateEqualTo(Date value) {
            addCriterion("ent_begin_date =", value, "entBeginDate");
            return (Criteria) this;
        }

        public Criteria andEntBeginDateNotEqualTo(Date value) {
            addCriterion("ent_begin_date <>", value, "entBeginDate");
            return (Criteria) this;
        }

        public Criteria andEntBeginDateGreaterThan(Date value) {
            addCriterion("ent_begin_date >", value, "entBeginDate");
            return (Criteria) this;
        }

        public Criteria andEntBeginDateGreaterThanOrEqualTo(Date value) {
            addCriterion("ent_begin_date >=", value, "entBeginDate");
            return (Criteria) this;
        }

        public Criteria andEntBeginDateLessThan(Date value) {
            addCriterion("ent_begin_date <", value, "entBeginDate");
            return (Criteria) this;
        }

        public Criteria andEntBeginDateLessThanOrEqualTo(Date value) {
            addCriterion("ent_begin_date <=", value, "entBeginDate");
            return (Criteria) this;
        }

        public Criteria andEntBeginDateIn(List<Date> values) {
            addCriterion("ent_begin_date in", values, "entBeginDate");
            return (Criteria) this;
        }

        public Criteria andEntBeginDateNotIn(List<Date> values) {
            addCriterion("ent_begin_date not in", values, "entBeginDate");
            return (Criteria) this;
        }

        public Criteria andEntBeginDateBetween(Date value1, Date value2) {
            addCriterion("ent_begin_date between", value1, value2, "entBeginDate");
            return (Criteria) this;
        }

        public Criteria andEntBeginDateNotBetween(Date value1, Date value2) {
            addCriterion("ent_begin_date not between", value1, value2, "entBeginDate");
            return (Criteria) this;
        }

        public Criteria andEntEndDateIsNull() {
            addCriterion("ent_end_date is null");
            return (Criteria) this;
        }

        public Criteria andEntEndDateIsNotNull() {
            addCriterion("ent_end_date is not null");
            return (Criteria) this;
        }

        public Criteria andEntEndDateEqualTo(Date value) {
            addCriterion("ent_end_date =", value, "entEndDate");
            return (Criteria) this;
        }

        public Criteria andEntEndDateNotEqualTo(Date value) {
            addCriterion("ent_end_date <>", value, "entEndDate");
            return (Criteria) this;
        }

        public Criteria andEntEndDateGreaterThan(Date value) {
            addCriterion("ent_end_date >", value, "entEndDate");
            return (Criteria) this;
        }

        public Criteria andEntEndDateGreaterThanOrEqualTo(Date value) {
            addCriterion("ent_end_date >=", value, "entEndDate");
            return (Criteria) this;
        }

        public Criteria andEntEndDateLessThan(Date value) {
            addCriterion("ent_end_date <", value, "entEndDate");
            return (Criteria) this;
        }

        public Criteria andEntEndDateLessThanOrEqualTo(Date value) {
            addCriterion("ent_end_date <=", value, "entEndDate");
            return (Criteria) this;
        }

        public Criteria andEntEndDateIn(List<Date> values) {
            addCriterion("ent_end_date in", values, "entEndDate");
            return (Criteria) this;
        }

        public Criteria andEntEndDateNotIn(List<Date> values) {
            addCriterion("ent_end_date not in", values, "entEndDate");
            return (Criteria) this;
        }

        public Criteria andEntEndDateBetween(Date value1, Date value2) {
            addCriterion("ent_end_date between", value1, value2, "entEndDate");
            return (Criteria) this;
        }

        public Criteria andEntEndDateNotBetween(Date value1, Date value2) {
            addCriterion("ent_end_date not between", value1, value2, "entEndDate");
            return (Criteria) this;
        }

        public Criteria andExtraMsgIsNull() {
            addCriterion("extra_msg is null");
            return (Criteria) this;
        }

        public Criteria andExtraMsgIsNotNull() {
            addCriterion("extra_msg is not null");
            return (Criteria) this;
        }

        public Criteria andExtraMsgEqualTo(String value) {
            addCriterion("extra_msg =", value, "extraMsg");
            return (Criteria) this;
        }

        public Criteria andExtraMsgNotEqualTo(String value) {
            addCriterion("extra_msg <>", value, "extraMsg");
            return (Criteria) this;
        }

        public Criteria andExtraMsgGreaterThan(String value) {
            addCriterion("extra_msg >", value, "extraMsg");
            return (Criteria) this;
        }

        public Criteria andExtraMsgGreaterThanOrEqualTo(String value) {
            addCriterion("extra_msg >=", value, "extraMsg");
            return (Criteria) this;
        }

        public Criteria andExtraMsgLessThan(String value) {
            addCriterion("extra_msg <", value, "extraMsg");
            return (Criteria) this;
        }

        public Criteria andExtraMsgLessThanOrEqualTo(String value) {
            addCriterion("extra_msg <=", value, "extraMsg");
            return (Criteria) this;
        }

        public Criteria andExtraMsgLike(String value) {
            addCriterion("extra_msg like", value, "extraMsg");
            return (Criteria) this;
        }

        public Criteria andExtraMsgNotLike(String value) {
            addCriterion("extra_msg not like", value, "extraMsg");
            return (Criteria) this;
        }

        public Criteria andExtraMsgIn(List<String> values) {
            addCriterion("extra_msg in", values, "extraMsg");
            return (Criteria) this;
        }

        public Criteria andExtraMsgNotIn(List<String> values) {
            addCriterion("extra_msg not in", values, "extraMsg");
            return (Criteria) this;
        }

        public Criteria andExtraMsgBetween(String value1, String value2) {
            addCriterion("extra_msg between", value1, value2, "extraMsg");
            return (Criteria) this;
        }

        public Criteria andExtraMsgNotBetween(String value1, String value2) {
            addCriterion("extra_msg not between", value1, value2, "extraMsg");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}