package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.domain.common.entity.CreditMerchantChannelGather;
import com.jd.jr.boss.credit.facade.authen.beans.param.MerchantChannelQueryParam;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Description: 商户渠道数据持久层
 * User: yangjinlin@jd.com
 * Date: 2018/5/10 11:58
 * Version: 1.0
 */
@Repository
public interface CreditMerchantChannelGatherDao {

    /**
     * 多条件查询商户渠道信息List
     * @param merchChanlQryPrm
     * @return
     */
    List<CreditMerchantChannelGather> queryMerchantChannelInfoList(MerchantChannelQueryParam merchChanlQryPrm);

    /**
     * 更新商户渠道信息
     * @param merchChanlGather
     */
    Integer updateMerchantChannelGatherById(CreditMerchantChannelGather merchChanlGather);

    /**
     * 新增商户渠道信息
     * @param merchChanlGather
     * @return
     */
    Integer insertMerchantChannelGather(CreditMerchantChannelGather merchChanlGather);

    /**
     * 查询商户渠道信息 总个数
     * @param queryParam
     * @return
     */
    int queryMerchantChannelInfoListCount(MerchantChannelQueryParam queryParam);

    /**
     * 查询商户渠道成功是失败统计
     * @param queryParam
     * @return
     */
    int selectCountMerchantChannelGatherByParam(MerchantChannelQueryParam queryParam);
}
