package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;
import java.util.List;

import com.wangyin.operation.common.beans.PageQuery;

public class AccountPageQueryParam extends PageQuery implements Serializable{


	private static final long serialVersionUID = -6199773330355702393L;
	/**
     * 商户号
     */
    private String marchantNo;

    /**
     * 产品ID
     */
    private Integer productId;
    /**
     * 计费类型
     * @return
     */
    private String chargeType;
    /**
     * 合同ID列表
     */
    private List<Integer> contractIdList;
    public String getMarchantNo() {
		return marchantNo;
	}

	public void setMarchantNo(String marchantNo) {
		this.marchantNo = marchantNo;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public List<Integer> getContractIdList() {
		return contractIdList;
	}

	public void setContractIdList(List<Integer> contractIdList) {
		this.contractIdList = contractIdList;
	}

}
