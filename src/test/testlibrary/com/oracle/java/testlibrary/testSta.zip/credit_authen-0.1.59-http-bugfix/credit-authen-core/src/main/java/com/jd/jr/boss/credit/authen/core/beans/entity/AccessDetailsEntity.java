package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;

import com.wangyin.boss.credit.admin.entity.CreditAccessDetails;

/**
 *  合同包含产品实体类
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
public class AccessDetailsEntity  extends CreditAccessDetails  implements Serializable{

	private static final long serialVersionUID = -3877643019864397890L;
	/**
	 * 总额和总条数
	 */
	private Long amount;
	/**
	 * 商户ID
	 */
    private Integer merchantId;
    private Integer count;

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public Integer getMerchantId() {
		return merchantId;
	}
	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}
}
