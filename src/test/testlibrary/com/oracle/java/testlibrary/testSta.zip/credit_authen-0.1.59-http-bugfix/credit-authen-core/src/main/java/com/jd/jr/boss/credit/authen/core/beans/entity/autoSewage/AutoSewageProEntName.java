package com.jd.jr.boss.credit.authen.core.beans.entity.autoSewage;

import java.io.Serializable;

/**
 * Created by liuwei55@jd.com
 *
 * @version 1.0
 * @date : 2018/11/20.
 * @return
 */
public class AutoSewageProEntName  implements Serializable {

    private static final long serialVersionUID = 8383990358224087150L;
    /**
     * 企业名称
     */
    private String entName;
    /**
     * 是否内部用户
     */
    private String entType;
    /**
     * 小分组
     */
    private String relationGroup;
    /**
     * 大分组
     */
    private String group;

    public String getEntName() {
        return entName;
    }

    public void setEntName(String entName) {
        this.entName = entName;
    }

    public String getEntType() {
        return entType;
    }

    public void setEntType(String entType) {
        this.entType = entType;
    }

    public String getRelationGroup() {
        return relationGroup;
    }

    public void setRelationGroup(String relationGroup) {
        this.relationGroup = relationGroup;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }
}
