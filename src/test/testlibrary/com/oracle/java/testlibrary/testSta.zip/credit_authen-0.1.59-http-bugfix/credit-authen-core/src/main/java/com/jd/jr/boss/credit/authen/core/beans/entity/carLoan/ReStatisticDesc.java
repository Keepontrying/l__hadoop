package com.jd.jr.boss.credit.authen.core.beans.entity.carLoan;

import java.io.Serializable;

/**
 * 关联企业工商信息
 * @author tangmingbo
 */
public class ReStatisticDesc implements Serializable{
	private static final long serialVersionUID = 2936531965994611042L;
	//变更登记共
	private int alterNum;
	//法人变更企业数
	private int frEntNum;
	//注册资本变更企业数
	private int regEntNum;
	//企业名称变更企业数
	private int entNameEntNum;
	//股东变更企业数
	private int shareEntNum;
	//经营地址变更企业数
	private int domEntNum;
	//经营范围变更企业数
	private int opScopeEntNum;
	//行政处罚 企业数
	private int punishmentEntNum;
	//列入经营异常 企业数
	private int abnormalEntNum;
	//股权质押 企业数
	private int equityInfoEntNum;
	/**
	 * 有效出质股权数额
	 */
	private String equityInfoAmount;
	/**
	 * 动产抵押 企业数
	 */
	private int mortgageInfoEntNum;
	/**
	 * 被担保人债券数额
	 */
	private String mortgageInfoAmount;
	/**
	 * 严重违法 企业数
	 */
	private int illegalEntNum;
	/**
	 * 抽查检查 企业数
	 */
	private int checkInfoEntNum;
	/**
	 * 企业失信企业数
	 */
	private int punishBreakEntNum;
	/**
	 * 企业失信条数
	 */
	private int punishBreakNum;
	/**
	 * 企业失信未履行条数
	 */
	private int unPunishBreakNum;
	/**
	 * 被强制执行的金额
	 */
	private String punishedAmount;
	/**
	 * 被强制执行企业数
	 */
	private int punishedEntNum;
	/**
	 * 被强制执行条数
	 */
	private int punishedNum;
	/**
	 * 涉诉案件 条数
	 */
	private int lawsuitNum;
	/**
	 * 涉诉案件 企业数
	 */
	private int lawsuitEntNum;
	/**
	 * 重大税收违法 条数
	 */
	private int majorTaxNum;
	/**
	 * 重大税收违法企业条数
	 */
	private int majorTaxEntNum;

    public int getAlterNum() {
        return alterNum;
    }

    public void setAlterNum(int alterNum) {
        this.alterNum = alterNum;
    }

    public int getFrEntNum() {
		return frEntNum;
	}

	public void setFrEntNum(int frEntNum) {
		this.frEntNum = frEntNum;
	}

	public int getRegEntNum() {
		return regEntNum;
	}

	public void setRegEntNum(int regEntNum) {
		this.regEntNum = regEntNum;
	}

	public int getEntNameEntNum() {
		return entNameEntNum;
	}

	public void setEntNameEntNum(int entNameEntNum) {
		this.entNameEntNum = entNameEntNum;
	}

	public int getShareEntNum() {
		return shareEntNum;
	}

	public void setShareEntNum(int shareEntNum) {
		this.shareEntNum = shareEntNum;
	}

	public int getDomEntNum() {
		return domEntNum;
	}

	public void setDomEntNum(int domEntNum) {
		this.domEntNum = domEntNum;
	}

	public int getOpScopeEntNum() {
		return opScopeEntNum;
	}

	public void setOpScopeEntNum(int opScopeEntNum) {
		this.opScopeEntNum = opScopeEntNum;
	}

	public int getPunishmentEntNum() {
		return punishmentEntNum;
	}

	public void setPunishmentEntNum(int punishmentEntNum) {
		this.punishmentEntNum = punishmentEntNum;
	}

	public int getAbnormalEntNum() {
		return abnormalEntNum;
	}

	public void setAbnormalEntNum(int abnormalEntNum) {
		this.abnormalEntNum = abnormalEntNum;
	}

	public int getEquityInfoEntNum() {
		return equityInfoEntNum;
	}

	public void setEquityInfoEntNum(int equityInfoEntNum) {
		this.equityInfoEntNum = equityInfoEntNum;
	}

	public String getEquityInfoAmount() {
		return equityInfoAmount;
	}

	public void setEquityInfoAmount(String equityInfoAmount) {
		this.equityInfoAmount = equityInfoAmount;
	}

	public int getMortgageInfoEntNum() {
		return mortgageInfoEntNum;
	}

	public void setMortgageInfoEntNum(int mortgageInfoEntNum) {
		this.mortgageInfoEntNum = mortgageInfoEntNum;
	}

	public String getMortgageInfoAmount() {
		return mortgageInfoAmount;
	}

	public void setMortgageInfoAmount(String mortgageInfoAmount) {
		this.mortgageInfoAmount = mortgageInfoAmount;
	}

	public int getIllegalEntNum() {
		return illegalEntNum;
	}

	public void setIllegalEntNum(int illegalEntNum) {
		this.illegalEntNum = illegalEntNum;
	}

	public int getCheckInfoEntNum() {
		return checkInfoEntNum;
	}

	public void setCheckInfoEntNum(int checkInfoEntNum) {
		this.checkInfoEntNum = checkInfoEntNum;
	}

	public int getPunishBreakEntNum() {
		return punishBreakEntNum;
	}

	public void setPunishBreakEntNum(int punishBreakEntNum) {
		this.punishBreakEntNum = punishBreakEntNum;
	}

	public int getPunishBreakNum() {
		return punishBreakNum;
	}

	public void setPunishBreakNum(int punishBreakNum) {
		this.punishBreakNum = punishBreakNum;
	}

	public int getUnPunishBreakNum() {
		return unPunishBreakNum;
	}

	public void setUnPunishBreakNum(int unPunishBreakNum) {
		this.unPunishBreakNum = unPunishBreakNum;
	}

	public String getPunishedAmount() {
		return punishedAmount;
	}

	public void setPunishedAmount(String punishedAmount) {
		this.punishedAmount = punishedAmount;
	}

	public int getPunishedEntNum() {
		return punishedEntNum;
	}

	public void setPunishedEntNum(int punishedEntNum) {
		this.punishedEntNum = punishedEntNum;
	}

	public int getPunishedNum() {
		return punishedNum;
	}

	public void setPunishedNum(int punishedNum) {
		this.punishedNum = punishedNum;
	}

	public int getLawsuitNum() {
		return lawsuitNum;
	}

	public void setLawsuitNum(int lawsuitNum) {
		this.lawsuitNum = lawsuitNum;
	}

	public int getLawsuitEntNum() {
		return lawsuitEntNum;
	}

	public void setLawsuitEntNum(int lawsuitEntNum) {
		this.lawsuitEntNum = lawsuitEntNum;
	}

	public int getMajorTaxNum() {
		return majorTaxNum;
	}

	public void setMajorTaxNum(int majorTaxNum) {
		this.majorTaxNum = majorTaxNum;
	}

	public int getMajorTaxEntNum() {
		return majorTaxEntNum;
	}

	public void setMajorTaxEntNum(int majorTaxEntNum) {
		this.majorTaxEntNum = majorTaxEntNum;
	}
}
