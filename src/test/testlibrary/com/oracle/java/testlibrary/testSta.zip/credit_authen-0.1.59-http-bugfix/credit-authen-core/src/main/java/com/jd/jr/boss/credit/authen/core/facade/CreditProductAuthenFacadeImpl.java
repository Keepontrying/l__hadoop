package com.jd.jr.boss.credit.authen.core.facade;

import com.jd.jr.boss.credit.authen.core.exception.CreditAuthenException;
import com.jd.jr.boss.credit.authen.core.service.CreditProductAuthenService;
import com.jd.jr.boss.credit.facade.authen.api.CreditProductAuthenFacade;
import com.jd.jr.boss.credit.facade.authen.beans.entity.CreditProductAuthenEntity;
import com.jd.jr.boss.credit.facade.authen.beans.param.CreditAuthenQueryParam;
import com.jd.jr.boss.credit.facade.authen.enums.CreditErrCodeEnum;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.Response;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * 类描述：
 *
 * @author liangyuwu
 * @Time 2018/6/5 17:26
 */
@Service("creditProductAuthenFacade")
public class CreditProductAuthenFacadeImpl implements CreditProductAuthenFacade {

    private static Logger logger = LoggerFactory.getLogger(CreditProductAuthenFacadeImpl.class);

    @Autowired
    private CreditProductAuthenService creditProductAuthenService;

    @Override
    public ResponseData applyAuthorization(RequestParam<CreditProductAuthenEntity> param) {
        ResponseData responseData = new ResponseData();
        Response response = validDTOCommonParam(param);
        if (!response.isSuccess()) {
            logger.error("applyAuthorization param is null");
            responseData.setResponse(response);
            return responseData;
        }

        logger.info("applyAuthorization申请授权参数："+GsonUtil.getInstance().toJson(param));
        CreditProductAuthenEntity entity = param.getParam();
        if (!StringUtils.hasText(entity.getJdpin()) || !StringUtils.hasText(entity.getAppId())
                || entity.getProductCode() == null || !StringUtils.hasText(entity.getDataSource())) {
            logger.error("applyAuthorization" + ResponseMessage.PARAM_IS_REQUIRED.getDesc());
            responseData.setSuccess(false);
            responseData.setCode(CreditErrCodeEnum.请求参数不能为空.getCode());
            responseData.setMessage(CreditErrCodeEnum.请求参数不能为空.name());
            responseData.setData(param);
            return responseData;
        }

        try {
            int data = creditProductAuthenService.insertSelective(entity);
            if (data == 1) {
                responseData.setSuccess(true);
                responseData.setCode(CreditErrCodeEnum.请求成功.getCode());
                responseData.setMessage(CreditErrCodeEnum.请求成功.name());
                responseData.setData(data);
            } else if (data == 2) {
                responseData.setSuccess(true);
                responseData.setCode(CreditErrCodeEnum.重复申请权限.getCode());
                responseData.setMessage(CreditErrCodeEnum.重复申请权限.name());
                responseData.setData(data);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());

            responseData.setSuccess(false);
            responseData.setMessage(CreditErrCodeEnum.系统异常.name());
            responseData.setCode(CreditErrCodeEnum.系统异常.getCode());
        }

        logger.info("applyAuthorization返回结果信息："+GsonUtil.getInstance().toJson(responseData));
        return responseData;
    }

    @Override
    public ResponseData cancelAuthorization(RequestParam<CreditProductAuthenEntity> param) {
        ResponseData responseData = new ResponseData();
        Response response = validDTOCommonParam(param);
        if (!response.isSuccess()) {
            logger.error("cancelAuthorization param is null");
            responseData.setResponse(response);
            return responseData;
        }

        logger.info("cancelAuthorization取消授权参数："+ GsonUtil.getInstance().toJson(param));
        CreditProductAuthenEntity entity = param.getParam();
        if (!StringUtils.hasText(entity.getJdpin())) {
            responseData.setSuccess(false);
            responseData.setMessage(CreditErrCodeEnum.用户id为空.name());
            responseData.setCode(CreditErrCodeEnum.用户id为空.getCode());
            return responseData;
        }

        if (!StringUtils.hasText(entity.getAppId())) {
            responseData.setSuccess(false);
            responseData.setMessage(CreditErrCodeEnum.appId为空.name());
            responseData.setCode(CreditErrCodeEnum.appId为空.getCode());
            return responseData;
        }

        try {
            int data = creditProductAuthenService.update(entity);
            if (data > 0) {
                responseData.setSuccess(true);
                responseData.setCode(CreditErrCodeEnum.请求成功.getCode());
                responseData.setMessage(CreditErrCodeEnum.请求成功.name());
            }else{
                responseData.setSuccess(false);
                responseData.setCode(CreditErrCodeEnum.未授权.getCode());
                responseData.setMessage(CreditErrCodeEnum.未授权.name());
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            responseData.setSuccess(false);
            responseData.setMessage(CreditErrCodeEnum.数据库异常.name());
            responseData.setCode(CreditErrCodeEnum.系统异常.getCode());
        }

        logger.info("cancelAuthorization返回结果信息："+GsonUtil.getInstance().toJson(responseData));
        return responseData;
    }

    @Override
    public ResponseData queryAuthorization(RequestParam<CreditProductAuthenEntity> param) {
        logger.info("queryAuthorization查询授权参数："+ GsonUtil.getInstance().toJson(param));
        ResponseData responseData = new ResponseData();
        Response response = validDTOCommonParam(param);
        if (!response.isSuccess()) {
            logger.error("queryAuthorization param is null");
            responseData.setResponse(response);
            return responseData;
        }
        logger.info("queryAuthorization查询授权参数：", GsonUtil.getInstance().toJson(param));
        CreditProductAuthenEntity entity = param.getParam();
        if (!StringUtils.hasText(entity.getJdpin()) || !StringUtils.hasText(entity.getAppId())) {
            logger.error("queryAuthorization param is null");
            responseData.setSuccess(true);
            responseData.setCode(CreditErrCodeEnum.请求参数不能为空.getCode());
            responseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
            return responseData;
        }

        try {
            responseData = creditProductAuthenService.selectSelective(entity);
        } catch (Exception e) {
            logger.error(e.getMessage());

            responseData.setSuccess(false);
            responseData.setMessage(CreditErrCodeEnum.系统异常.name());
            responseData.setCode(CreditErrCodeEnum.系统异常.getCode());
        }

        logger.info("queryAuthorization返回结果信息："+GsonUtil.getInstance().toJson(responseData));
        return responseData;
    }

    @Override
    public Page<CreditProductAuthenEntity> pageList(CreditAuthenQueryParam param) {
        Page<CreditProductAuthenEntity> page = new Page<CreditProductAuthenEntity>();
        Response response = new Response(true,ResponseMessage.SUCCESS.getDesc());
        logger.info("pageList 查询权限列表"+GsonUtil.getInstance().toJson(param));
        if (param == null || !StringUtils.hasText(param.getJdpin())) {
            response.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
            response.setCode(CreditErrCodeEnum.请求参数不能为空.getCode());
            response.setSuccess(true);
            page.setResponse(response);
            return page;
        }

        try {
            page = creditProductAuthenService.pageList(param);
        } catch (Exception e) {
            logger.error(e.getMessage());
            response.setSuccess(false);
            response.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            page.setResponse(response);
        }

        logger.info("pageList列表查询返回结果："+GsonUtil.getInstance().toJson(page));
        return page;
    }


    public <T> ResponseData<T> validDTOCommonParam(
            RequestParam<?> requestParam) {
        ResponseData<T> responseData = new ResponseData<T>();
        if (requestParam == null || requestParam.getParam() == null) {
            responseData.setSuccess(false);
            responseData.setCode(CreditErrCodeEnum.请求参数不能为空.getCode());
            responseData.setMessage(CreditErrCodeEnum.请求参数不能为空.name());
            return responseData;
        }
        // 参数非空校验
        if (!StringUtils.hasText(requestParam.getSystemId())) {
            responseData.setSuccess(false);
            responseData.setCode(CreditErrCodeEnum.systemId为空.getCode());
            responseData.setMessage(CreditErrCodeEnum.systemId为空.name());
            return responseData;
        }
        //校验是否存在
        int exist = creditProductAuthenService.hasSystemId(requestParam.getSystemId());
        if (exist < 0) {
            responseData.setSuccess(false);
            responseData.setCode(CreditErrCodeEnum.systemId不存在.getCode());
            responseData.setMessage(CreditErrCodeEnum.systemId不存在.name());
        }
        return responseData;
    }

}
