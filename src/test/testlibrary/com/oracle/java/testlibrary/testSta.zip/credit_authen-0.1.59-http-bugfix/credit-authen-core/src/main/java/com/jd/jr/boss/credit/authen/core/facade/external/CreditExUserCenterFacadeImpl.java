package com.jd.jr.boss.credit.authen.core.facade.external;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.beans.entity.ProductToBuyShow;
import com.jd.jr.boss.credit.facade.authen.api.CreditAccessDetailFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditBillFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditMerchantAccountFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditOrderFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.OrderRemainQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.CreditBillMerchantSum;
import com.jd.jr.boss.credit.facade.authen.beans.response.CreditOrderRemain;
import com.jd.jr.boss.credit.facade.authen.beans.response.FacadeMerchantAccountBalance;
import com.jd.jr.boss.credit.facade.common.dto.CreditExRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.elasticsearch.api.CreditLogSearchFacade;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.param.CreditLogQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.CreditTradeLogInfo;
import com.jd.jr.boss.credit.facade.external.api.CreditExUserCenterFacade;
import com.jd.jr.boss.credit.facade.external.beans.request.CreditAccessDetailQueryReq;
import com.jd.jr.boss.credit.facade.external.beans.request.CreditBillQueryReq;
import com.jd.jr.boss.credit.facade.external.beans.request.MerchantReq;
import com.jd.jr.boss.credit.facade.external.beans.request.OrderRemainingQueryReq;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditAccessDetailResp;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditBillChartResp;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditOrderRemainingResp;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditUserOverviewResp;
import com.jd.jr.boss.credit.facade.external.enums.CreditDateRangeEnum;
import com.wangyin.boss.credit.admin.entity.CreditBill;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Created by anmeng on 2018/5/29.
 */
@Service("creditExUserCenterFacade")
public class CreditExUserCenterFacadeImpl implements CreditExUserCenterFacade {

    private Logger logger= LoggerFactory.getLogger(CreditExUserCenterFacadeImpl.class);

    @Autowired
    private CreditOrderFacade creditOrderFacade;

    @Autowired
    private CreditLogSearchFacade creditLogSearchFacade;

    @Autowired
    private CreditBillFacade creditBillFacade;

    @Autowired
    private CreditMerchantAccountFacade merchantAccountFacade;

    /**
     * 查询商户用户中心首页概览
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<CreditUserOverviewResp> queryOverview(CreditExRequestParam<MerchantReq> requestParam) {

        CreditResponseData<CreditUserOverviewResp> exResponseData=new CreditResponseData<>();
        CreditUserOverviewResp overviewResp=new CreditUserOverviewResp();

        try {
            MerchantReq req=requestParam.getParam();
            CreditRequestParam<String> queryParam=new CreditRequestParam<>();
            queryParam.setParam(req.getMerchantNo());
            CreditResponseData<FacadeMerchantAccountBalance> responseData = merchantAccountFacade.queryMerchantBalance(queryParam);
            if(responseData.isSuccess()) {
                FacadeMerchantAccountBalance accountBalance = responseData.getData();
                Long balance=  accountBalance.getSumAmount();
                overviewResp.setBalance(balance);
            }
            CreditRequestParam<CreditBill> billQueryParam=new CreditRequestParam<CreditBill>();
            CreditBill billParam=new CreditBill();
            billParam.setMerchantNo(req.getMerchantNo());
            billParam.setStartDateStr(LocalDate.now().plusDays(-1).atStartOfDay().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            billParam.setEndDateStr(LocalDate.now().atStartOfDay().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            billQueryParam.setParam(billParam);
            CreditResponseData<CreditBillMerchantSum> responseData1=creditBillFacade.queryMerchantBillSum(billQueryParam);
            if(responseData1.isSuccess()){
                CreditBillMerchantSum sum=responseData1.getData();
                if(sum!=null) {
                    overviewResp.setYesterdayCallTimes(sum.getYesterdayCallTimes());
                    overviewResp.setYesterdayConsumeSum(sum.getYesterdayConsumeSum());
                }else{
                    overviewResp.setYesterdayCallTimes(0L);
                    overviewResp.setYesterdayConsumeSum(0L);
                }
                exResponseData.setData(overviewResp);
            }else{
                logger.error("查询商户统计信息失败！");
                exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            }
        } catch (Exception e) {
            logger.error("查询商户统计信息",e);
            exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        logger.info("response data:"+ JSONObject.toJSONString(exResponseData));
        return exResponseData;
    }

    /**
     * 查询商户最近一段时间调用量趋势
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<List<CreditBillChartResp>> queryBillCount(CreditExRequestParam<CreditBillQueryReq> requestParam) {

        CreditResponseData<List<CreditBillChartResp>> exResponseData=new CreditResponseData<>();
        CreditBillQueryReq req=requestParam.getParam();
        CreditRequestParam<CreditBill> queryParam = new CreditRequestParam<>();
        CreditBill creditBill=new CreditBill();
        LocalDateTime now=LocalDateTime.now();
        DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String startTime="";
        String endTime=now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        Integer recordCount=0;
        if(CreditDateRangeEnum.PERIOD_MONTH.equals(req.getDateRange())){
            startTime=now.minusDays(30).format(dtf)+" 00:00:00";
            recordCount=30;
        }else if(CreditDateRangeEnum.PERIOD_WEEK.equals(req.getDateRange())){
            startTime=now.minusDays(7).format(dtf)+" 00:00:00";
            recordCount=7;
        }else {
            startTime=now.minusDays(1).format(dtf)+" 00:00:00";
            recordCount=1;
        }
        creditBill.setStartDateStr(startTime);
        creditBill.setEndDateStr(endTime);
        creditBill.setMerchantNo(req.getMerchantNo());
        queryParam.setParam(creditBill);
        try {
            CreditResponseData<List<CreditBill>> responseData=creditBillFacade.queryBillList4Chart(queryParam);
            if(responseData.isSuccess()&&responseData.getData()!=null){
                Map<String,CreditBillChartResp> respMap=new HashMap<>();
                List<CreditBillChartResp> respList=new ArrayList<>();
                for(int i=recordCount;i>=1;i--){
                    CreditBillChartResp resp=new CreditBillChartResp();
                    resp.setDateStr(now.minusDays(i).format(dtf));
                    resp.setCount("0");
                    respMap.put(resp.getDateStr(),resp);
                    respList.add(resp);
                }
                ZoneId zoneId = ZoneId.systemDefault();
                responseData.getData().forEach(bill->{
                    String dateStr=bill.getStartDate().toInstant().atZone(zoneId).toLocalDateTime().format(dtf);
                    CreditBillChartResp resp=respMap.get(dateStr);
                    if(resp!=null) {
                        resp.setCount(bill.getPacketCount() + "");
                    }
                });
                exResponseData.setData(respList);
            }else{
                logger.error("查询用量趋势失败",responseData.getMessage());
                exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            }
        } catch (Exception e) {
            logger.error("查询用量趋势失败",e);
            exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        logger.info("response data:"+ JSONObject.toJSONString(exResponseData));
        return exResponseData;
    }

    /**
     * 查询商户访问详情
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<List<CreditAccessDetailResp>> queryAccessDetail(CreditExRequestParam<CreditAccessDetailQueryReq> requestParam) {

        CreditResponseData<List<CreditAccessDetailResp>> exResponseData=new CreditResponseData<>();

        CreditAccessDetailQueryReq queryReq=requestParam.getParam();
        LocalDateTime now=LocalDateTime.now();
        DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String startTime="";
        String endTime=now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        if(CreditDateRangeEnum.PERIOD_MONTH.equals(queryReq.getDateRange())){
            startTime=now.minusDays(29).format(dtf)+" 00:00:00";
        }else if(CreditDateRangeEnum.PERIOD_WEEK.equals(queryReq.getDateRange())){
            startTime=now.minusDays(6).format(dtf)+" 00:00:00";
        }else if(CreditDateRangeEnum.PERIOD_DAY.equals(queryReq.getDateRange())){
            startTime=now.format(dtf)+" 00:00:00";
        }

        CreditLogQueryParam queryParam = new CreditLogQueryParam();
        queryParam.setMerchantNo(queryReq.getMerchantNo());
        if(queryReq.getDateRange()!=null){
            queryParam.setStartOccursDateStr(startTime);
            queryParam.setEndOccursDateStr(endTime);
        }

        if(queryReq.getPageIndex()!=null&&queryReq.getPageSize()!=null){
            queryParam.setLimit(queryReq.getPageSize());
            queryParam.setStart((queryReq.getPageIndex()-1)*queryReq.getPageSize());
        }
        queryParam.setProductCode(queryReq.getProductCode());
        CreditPage<CreditTradeLogInfo> page=creditLogSearchFacade.queryTradeLogList(queryParam);
        if(page.isSuccess() && page.getRows()!=null){
            List<CreditAccessDetailResp> respList=new ArrayList<>();
            List<CreditTradeLogInfo> logInfoList=page.getRows();
            logInfoList.forEach(logInfo->{
                CreditAccessDetailResp resp=new CreditAccessDetailResp();
                resp.setAccessStatus(logInfo.getAccessStatus());
                resp.setCreatedDate(logInfo.getOccursDate());
                resp.setProductName(logInfo.getProductName());
                respList.add(resp);
            });
            exResponseData.setData(respList);
        }else if("NODATA".equals(page.getCode())){
            exResponseData.setData(new ArrayList<>());
        }else{
            logger.error("查询访问明细",page.getMessage());
            exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        logger.info("response data:"+ JSONObject.toJSONString(exResponseData));
        return exResponseData;
    }

    /**
     * 查询订单剩余量
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<List<CreditOrderRemainingResp>> queryOrderRemaining(CreditExRequestParam<OrderRemainingQueryReq> requestParam) {
        CreditResponseData<List<CreditOrderRemainingResp>> exResponseData=new CreditResponseData<>();
        OrderRemainingQueryReq req=requestParam.getParam();
        OrderRemainQueryParam queryParam = new OrderRemainQueryParam();
        queryParam.setMerchantNo(req.getMerchantNo());
        queryParam.setOrderStatus(req.getOrderStatus().getCode());
        queryParam.setStart((req.getPageIndex()-1)*req.getPageSize());
        queryParam.setLimit(req.getPageSize());
        try {
            CreditPage<CreditOrderRemain> remainPage = creditOrderFacade.queryOrderRemained(queryParam);
            if(remainPage.isSuccess()){
                List<CreditOrderRemain> remainList=remainPage.getRows();
                if(remainList!=null){
                    List<CreditOrderRemainingResp> respList=new ArrayList<>();
                    ProductToBuyShow toBuyShow=new ProductToBuyShow();
                    remainList.forEach(remain->{
                        CreditOrderRemainingResp resp=new CreditOrderRemainingResp();
                        BeanUtils.copyProperties(remain,resp);
                        if(toBuyShow.getItemMap().get(remain.getProductCode())!=null){
                            resp.setIconCode(toBuyShow.getItemMap().get(remain.getProductCode()).getIconClass());
                        }else{
                            resp.setIconCode(toBuyShow.getDefaultIcon());
                        }
                        respList.add(resp);
                    });
                    exResponseData.setData(respList);
                }
            }else{
                logger.error("查询用户订单使用量失败",remainPage.getMessage());
                exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            }
        } catch (Exception e) {
            logger.error("查询用户订单使用量失败",e);
            exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        logger.info("response data:"+ JSONObject.toJSONString(exResponseData));
        return exResponseData;
    }
}
