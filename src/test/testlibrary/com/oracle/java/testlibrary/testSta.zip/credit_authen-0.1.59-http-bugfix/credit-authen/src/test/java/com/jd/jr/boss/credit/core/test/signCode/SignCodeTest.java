package com.jd.jr.boss.credit.core.test.signCode;

import com.jd.jr.boss.credit.domain.common.entity.signcode.CreditSignCode;
import com.jd.jr.boss.credit.facade.authen.api.CreditSignCodeFacade;
import com.jd.jr.boss.credit.facade.elasticsearch.api.CreditCompanySearchFacade;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.math.BigDecimal;

/**
 * @author huangzhiqiang
 * @data 2017/8/25
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})

public class SignCodeTest {

    @Resource
    private CreditSignCodeFacade signCodeFacade;

    @Resource
    private CreditCompanySearchFacade searchFacade;


    @Test
    public void insert(){
        CreditSignCode signCodeParam = new CreditSignCode();
        signCodeParam.setSerialNo("123123123");
        signCodeParam.setRemark("remark");
        signCodeParam.setStatus("FINISH");
        signCodeParam.setFileName("110040816_20170824095150_企业中证码查询.csv");
        signCodeParam.setMerchantNo("110040816");
        signCodeParam.setDate("2017-08-30 18:00:00");
        signCodeParam.setVersion("1.0");
        signCodeFacade.insert(signCodeParam);
    }

    @Test
    public void query(){
        BigDecimal ESCount = new BigDecimal(searchFacade.countESDocs());
        System.out.println(ESCount );
    }


}
