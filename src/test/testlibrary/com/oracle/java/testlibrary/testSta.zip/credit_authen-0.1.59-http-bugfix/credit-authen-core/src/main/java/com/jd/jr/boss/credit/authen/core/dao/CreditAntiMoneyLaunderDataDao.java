package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.entity.AntiMoneyLaunderEntity;
import com.jd.jr.boss.credit.authen.core.beans.request.AntiMoneyLQueryParam;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * created by ChenKaiJu on 2018/7/17  14:34
 */
@Repository
public interface CreditAntiMoneyLaunderDataDao {
    /**
     * 根据时间查询企业信息
     * @return
     */
    List<AntiMoneyLaunderEntity> findEntByTime(AntiMoneyLQueryParam param);


    /**
     * 更新表信息
     * @return
     */
    void updateAntiMoneyLaunderData(AntiMoneyLaunderEntity entity);


    List<AntiMoneyLaunderEntity> queryForBfmtEntByTime(AntiMoneyLQueryParam param);

    void updateAntiMoneyDataForBfmt(AntiMoneyLaunderEntity entity);

    AntiMoneyLaunderEntity selectByEntName(String value);

    void insertForBfmt(AntiMoneyLaunderEntity entity);

}
