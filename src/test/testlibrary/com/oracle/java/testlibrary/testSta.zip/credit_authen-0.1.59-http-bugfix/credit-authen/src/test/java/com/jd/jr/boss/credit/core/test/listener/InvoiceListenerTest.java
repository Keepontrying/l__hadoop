package com.jd.jr.boss.credit.core.test.listener;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import com.jd.jr.boss.credit.authen.core.service.CreditChargeService;
import com.wangyin.boss.credit.admin.enums.EnterpriseProductEnum4Common;
import com.wangyin.rediscluster.client.CacheClusterClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.alibaba.fastjson.JSONObject;
import com.jd.jmq.common.message.Message;
import com.jd.jr.boss.credit.authen.core.jms.invoiceVerify.CreditInvoiceVerifyResultListener;

/** 
* @desciption : 海关mq测试类
* @author : yangjinlin@jd.com
* @date ：2017年7月20日 下午5:56:59 
* @version 1.0 
* @return  */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/spring-authen.xml" })

public class InvoiceListenerTest {
	
	@Resource
	private CreditInvoiceVerifyResultListener invoiceListener;


	@Test
	public void testMessage() throws Exception {

		List<Message> messages = new ArrayList<Message>();
		Message message = new Message();
		JSONObject json = new JSONObject();
		json.put("crawlerTime", "2018-07-25 17:15:47");
		json.put("invoiceData", "{'status': '030','errorMsg': '打码失败','fpdm_zp': '4400164130'}'");
		json.put("fphm", "10859762");
		json.put("batchToken", "807544ea499949c2a750468031d5549c");
		json.put("result", "1");
		json.put("fpdm", "4400164130");
		json.put("systemId", "a3885821df2711e7a293ecf4bbcdd49c");
		message.setText(json.toJSONString());
		messages.add(message);
		invoiceListener.onMessage(messages);
		
	}
	

}
