package com.jd.jr.boss.credit.core.test.external;

import com.jd.jr.boss.credit.authen.core.service.CreditFilterService;
import com.jd.jr.boss.credit.core.test.user.BaseTest;
import com.jd.jr.boss.credit.facade.common.dto.CreditExRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.common.entity.Industry;
import com.jd.jr.boss.credit.facade.external.api.CreditExFilterFacade;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditFilterResp;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2017/9/21
 */
public class CreditExFilterFacadeTest extends BaseTest {

    @Autowired
    private CreditExFilterFacade creditExFilterFacade;

    @Autowired
    private CreditFilterService filterService;

    @Test
    public void testQueryFilter() {
        CreditExRequestParam queryParam = new CreditExRequestParam();
        queryParam.setBussId("credit");
        queryParam.setSystemId("credit_test");
        queryParam.setToken("712b6819471b4fe7a37f2d8b2b3a421e");
        CreditResponseData<CreditFilterResp> responseData = creditExFilterFacade.getFilter(queryParam);
        CreditFilterResp filterResp = responseData.getData();
        System.out.println("=================");
        System.out.println(GsonUtil.getInstance().toJson(filterResp));
    }


    @Test
    public void queryIndustry() {
        List<Industry> industryList=  filterService.queryIndustry();
        System.out.println("=================");
        System.out.println(GsonUtil.getInstance().toJson(industryList));
    }
}
