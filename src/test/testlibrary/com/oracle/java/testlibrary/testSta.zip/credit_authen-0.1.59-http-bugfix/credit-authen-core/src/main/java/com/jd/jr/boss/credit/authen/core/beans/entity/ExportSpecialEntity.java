package com.jd.jr.boss.credit.authen.core.beans.entity;

import org.apache.poi.ss.usermodel.Sheet;

import java.io.Serializable;

/**
 *  合同包含产品实体类
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
public class ExportSpecialEntity implements Serializable{
	private static final long serialVersionUID = -5976372532098995081L;
	private int rowNum;
	private Sheet sheet;

	public int getRowNum() {
		return rowNum;
	}

	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}

	public Sheet getSheet() {
		return sheet;
	}

	public void setSheet(Sheet sheet) {
		this.sheet = sheet;
	}
}
