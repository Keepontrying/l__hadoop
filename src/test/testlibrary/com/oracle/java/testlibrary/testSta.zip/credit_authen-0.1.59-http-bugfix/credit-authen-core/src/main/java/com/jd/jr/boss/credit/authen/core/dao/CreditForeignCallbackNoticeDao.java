package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.domain.common.entity.CreditCallbackUrl;
import com.jd.jr.boss.credit.domain.common.entity.CreditQuerySyncNotice;
import com.jd.jr.boss.credit.facade.authen.beans.param.CallbackUrlQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.SyncNoticeQueryParam;
import org.springframework.stereotype.Repository;

import java.util.List;

/** 
* @desciption :  征信外部回调dao
* @author : yangjinlin@jd.com
* @date ：2018年3月1日 下午4:34:37 
* @version 1.0 
* @return  */
@Repository
public interface CreditForeignCallbackNoticeDao {

	/**
	 * 多条件查询回调信息List
	 * @param callbackUrlQueryParam
	 * @return
	 */
    List<CreditCallbackUrl> queryCallbackUrlListByPrm(CallbackUrlQueryParam callbackUrlQueryParam);

	/**
	 * 多条件查询异步通知信息List
	 * @param syncNoticeQueryParam
	 * @return
	 */
    List<CreditQuerySyncNotice> querySyncNoticeListByPrm(SyncNoticeQueryParam syncNoticeQueryParam);

	/**
	 * 新增异步结果通知任务
	 * @param querySyncNotice
	 * @return
	 */
    Integer addSyncNotice(CreditQuerySyncNotice querySyncNotice);

	/**
	 * 根据主键更新任务表信息
	 * @param querySyncNotice4Upd
	 * @return
	 */
    int updateByPrimaryKeySelective(CreditQuerySyncNotice querySyncNotice4Upd);

}
