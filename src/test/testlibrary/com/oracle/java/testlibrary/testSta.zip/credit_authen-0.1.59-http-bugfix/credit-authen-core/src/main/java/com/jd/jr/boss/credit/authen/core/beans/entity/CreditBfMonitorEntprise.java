package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.Date;

public class CreditBfMonitorEntprise implements Serializable {
    private static final long serialVersionUID = 4995712702855662463L;
    private Integer id;

    private String entName;

    private String creditCode;

    private String regNo;

    private Date createdDate;

    private String createSystemId;

    private Date modifiedDate;

    private String modifier;

    private String entMonitored;

    private Date entBeginDate;

    private Date entEndDate;

    private String extraMsg;

    private String systemId;
    /**
     * 标识 目前有null和vip
     */
    private String flagMark;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEntName() {
        return entName;
    }

    public void setEntName(String entName) {
        this.entName = entName == null ? null : entName.trim();
    }

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode == null ? null : creditCode.trim();
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo == null ? null : regNo.trim();
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreateSystemId() {
        return createSystemId;
    }

    public void setCreateSystemId(String createSystemId) {
        this.createSystemId = createSystemId == null ? null : createSystemId.trim();
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier == null ? null : modifier.trim();
    }

    public String getEntMonitored() {
        return entMonitored;
    }

    public void setEntMonitored(String entMonitored) {
        this.entMonitored = entMonitored == null ? null : entMonitored.trim();
    }

    public Date getEntBeginDate() {
        return entBeginDate;
    }

    public void setEntBeginDate(Date entBeginDate) {
        this.entBeginDate = entBeginDate;
    }

    public Date getEntEndDate() {
        return entEndDate;
    }

    public void setEntEndDate(Date entEndDate) {
        this.entEndDate = entEndDate;
    }

    public String getExtraMsg() {
        return extraMsg;
    }

    public void setExtraMsg(String extraMsg) {
        this.extraMsg = extraMsg == null ? null : extraMsg.trim();
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public String getFlagMark() {
        return flagMark;
    }

    public void setFlagMark(String flagMark) {
        this.flagMark = flagMark;
    }
}