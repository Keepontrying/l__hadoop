package com.jd.jr.boss.credit.authen.core.biz;

import java.util.Date;
import java.util.List;

import com.jd.jr.boss.credit.facade.site.api.dto.entity.PaymentPackageEntity;
import com.jd.jr.boss.credit.facade.site.api.dto.request.account.AccountChargeRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.account.AccountPackageRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.account.AccountQueryRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.account.AccountDetailsResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.account.AccountQueryResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.paymentupdate.PaymentUpdateResponse;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.Response;
import com.wangyin.operation.common.beans.ResponseData;

/**
 * 企业站充值反馈和余额查询接口
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
public interface AccountManageBiz {

    /**
     * 充值反馈
     *
     * @param accountChargeRequest
     * @return
     */
    @Deprecated
    void updateAccountBalance(AccountChargeRequest accountChargeRequest, Response response) throws Exception;

    /**
     * 余额/余量查询
     *
     * @param accountChargeRequest
     * @return
     */
    ResponseData<AccountQueryResponse> queryBalance(AccountQueryRequest accountQueryRequest, ResponseData<AccountQueryResponse> responseData) throws Exception;

    /**
     * 分页查询包量列表
     *
     * @param contractQueryRequest
     * @return
     */
    void queryPackagePage(AccountPackageRequest accountPackageRequest, Page<AccountDetailsResponse> page) throws Exception;

    /**
     * 单笔缴费
     */
    void updateSingleCharge(String merchantNo, Long chargeAmt) throws Exception;

    /**
     * 包量缴费
     *
     * @param contractId
     * @param finishTime
     * @throws Exception
     */
    void updatePackageCharge(Integer contractId, Date finishTime) throws Exception;

    /**
     * 单包量订购缴费
     * @param orderId
     * @param finishTime
     */
    void updateOnePackageCharge(Integer orderId, Date finishTime);

    /**
     * 重置单笔账户余额
     */
    void resetSingleBalance(String merchantNo, Long chargeAmt, ResponseData<PaymentUpdateResponse> responseData) throws Exception;

    /**
     * 充值包量余额
     *
     * @param contractId
     * @param finishTime
     * @param strategyRemainMap
     */
    void resetPackageBalance(List<PaymentPackageEntity> paymentSreategyList, ResponseData<PaymentUpdateResponse> responseData) throws Exception;


}
