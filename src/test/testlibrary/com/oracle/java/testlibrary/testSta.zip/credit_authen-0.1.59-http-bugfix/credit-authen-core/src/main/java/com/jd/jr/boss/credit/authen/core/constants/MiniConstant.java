package com.jd.jr.boss.credit.authen.core.constants;
/** 
* @desciption : Mini尽调常量类
* @author : yangjinlin@jd.com
* @date ：2017年10月16日 下午3:34:18 
* @version 1.0 
* @return  */
public class MiniConstant {
	
	/*---------------------  Mini尽调     start    -------------------*/
	/**
	 * 文件系统的连接串
	 */
	public static final String SAMPLE_DETAIL_TAPE_FILENAME = "全程录音";
	/**
	 * Mini尽调项目样本总量在缓存中的前缀
	 */
	public static final String MINI_PROJECT_SAMPLE_COUNT_ = "MINI_PROJECT_SAMPLE_COUNT_";
	/**
	 * 项目审核不通过时的邮件模板编码templatecode
	 */
	public static final String UNC_CLIENT_MINI_PROJECT_TEMPLATECODE = "unc.client.mini.project.templatecode";
	/**
	 * 项目审核不通过时的邮件模板主题
	 */
	public static final String UNC_CLIENT_MINI_PROJECT_SUNJECT = "京东金融企业信用Mini尽调样本项目审核拒绝通知";
	/**
	 * 项目审核不通过时的邮件收件人
	 */
	public static final String UNC_CLIENT_MINI_RECEIVER = "unc.client.mini.receiver";
	
	public static final String PRODUCT_NAME_MINI = "mini尽调";
	/**
	 * 批量导出多样本附件
	 */
	public static final String MINI_DETAILS_ZIP_EXPORT = "京东金融企业信用Mini尽调多样本附件导出";
	/**
	 * 批量导出多样本附件的模板编码templatecode
	 */
	public static final String MINI_DETAILS_ZIP_EXPORT_TEMPLATECODE = "mini.details.zip.export.templatecode";

	/**
	 * 支付拓客 商户去重url
	 */
	public static final String DUE_PAY_URL_CHECKDUPLICATE = "due.pay.url.checkDuplicate";
	/**
	 * 支付拓客 拓客新增url
	 */
	public static final String DUE_PAY_URL_EXPAND = "due.pay.url.expand";
	/**
	 *  支付拓客 图片上传url
	 */
	public static final String DUE_PAY_URL_UPLOAD = "due.pay.url.upload";
    /**
     * 支付拓客 模糊查询
     */
    public static final String DUE_PAY_URL_CHECKNAMES = "due.pay.url.checkNames";
	/**
	 *  支付拓客 服务商编码
	 */
	public static final String DUE_PAY_DEALER_NO= "due.pay.dealer.no";

	/**
	 *  支付拓客 计费用到的systemId
	 */
	public static final String DUE_PAY_CHARGE_SYSTEMID= "due.pay.charge.systemid";
	/**
	 *  支付拓客 计费用到的systemId
	 */
	public static final String DUE_PAY_CHARGE_MERCHANTNO= "due.pay.charge.merchantno";
	
	/*---------------------  Mini尽调     end    -------------------*/
	
}
