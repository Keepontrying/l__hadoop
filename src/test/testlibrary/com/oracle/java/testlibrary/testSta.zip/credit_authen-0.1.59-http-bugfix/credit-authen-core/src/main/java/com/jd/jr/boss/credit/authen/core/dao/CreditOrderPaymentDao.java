package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.domain.common.entity.CreditOrderPayment;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by anmeng on 2017/5/24.
 */
@Repository
public interface CreditOrderPaymentDao {

    /**
     * 插入支付单
     * @param creditOrderPayment
     * @return
     */
    void insert(CreditOrderPayment creditOrderPayment);

    /**
     * 修改支付单号
     * @param creditOrderPayment
     */
    void update(CreditOrderPayment creditOrderPayment);

    /**
     * 查询支付单
     * @param creditOrderPayment
     * @return
     */
    List<CreditOrderPayment> query(CreditOrderPayment creditOrderPayment);

}
