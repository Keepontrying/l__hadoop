package com.jd.jr.boss.credit.core.test.paymentupdate;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.jd.jr.boss.credit.facade.site.api.CreditPaymentUpdateFacade;
import com.jd.jr.boss.credit.facade.site.api.dto.entity.PaymentPackageEntity;
import com.jd.jr.boss.credit.facade.site.api.dto.request.paymentupdate.PaymentUpdateRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.paymentupdate.PaymentUpdateResponse;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:springtest/spring-dubbo-consumer.xml" })

public class PaymentUpdateAspectjTest {
	@Resource
	private CreditPaymentUpdateFacade paymentUpdateFacade;
	
	@Test
	public void testUpdatePaymentStatus() { 
		RequestParam<PaymentUpdateRequest> requestParam=new RequestParam<PaymentUpdateRequest>();
		PaymentUpdateRequest paymentUpdateRequest=new PaymentUpdateRequest();
		paymentUpdateRequest.setMerchantNo("110029819");
		paymentUpdateRequest.setMoney(100000L);
		
		List<PaymentPackageEntity> paymentPackageList = new ArrayList<PaymentPackageEntity>();
		
		PaymentPackageEntity paymentPackage1 = new PaymentPackageEntity();
		paymentPackage1.setContractId(360);
		paymentPackage1.setStrategyId(901);
		paymentPackage1.setRemainCount(5);
		paymentPackageList.add(paymentPackage1);
		
//		PaymentPackageEntity paymentPackage2 = new PaymentPackageEntity();
//		paymentPackage2.setContractId(123);
//		paymentPackage2.setStrategyId(740);
//		paymentPackage2.setRemainCount(10);
//		paymentPackageList.add(paymentPackage2);

		paymentUpdateRequest.setPaymentPackageList(paymentPackageList );
		requestParam.setParam(paymentUpdateRequest);
		ResponseData<PaymentUpdateResponse> result=paymentUpdateFacade.updatePaymentStatus(requestParam);
		System.out.println(GsonUtil.getInstance().toJson(result));
	}
   
}
