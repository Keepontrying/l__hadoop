package com.jd.jr.boss.credit.core.test.account;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.jd.jr.boss.credit.facade.site.api.CreditAccountFacade;
import com.jd.jr.boss.credit.facade.site.api.dto.request.account.AccountChargeRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.account.AccountPackageRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.account.AccountQueryRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.account.AccountDetailsResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.account.AccountQueryResponse;
import com.jd.jr.boss.credit.gateway.account.utils.SerialNoUtils;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.Response;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:springtest/spring-dubbo-consumer.xml" })

public class AccountAspectjTest  {
	@Resource
	private CreditAccountFacade accountFacade;
	
	@Test
	public void testMain() {
		try {
			String merchantNo="110042475";
			String merchantCode="";
			Integer strategyId = 3026;
//			charge(merchantNo,merchantCode);
			balance(merchantNo,merchantCode,strategyId);
//			Integer productId = 3;
//			details(merchantNo,merchantCode,productId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	 /**
     * 充值结果反馈
     * @param accountChargeRequest
     * @return
     */
    public void charge(String merchantNo,String merchantCode){
    	RequestParam<AccountChargeRequest> requestParam = new RequestParam<AccountChargeRequest>();
    	AccountChargeRequest accountChargeRequest = new AccountChargeRequest();
    	accountChargeRequest.setMerchantNo(merchantNo);
    	accountChargeRequest.setMerchantCode(merchantCode);
    	accountChargeRequest.setMoney(20000L);
    	accountChargeRequest.setTradeNo(SerialNoUtils.createOrderNo());
    	requestParam.setParam(accountChargeRequest);
    	Response resutlt = accountFacade.charge(requestParam);
    	System.out.println(GsonUtil.getInstance().toJson(resutlt));
    }
    /**
     * 余额/余量查询
     * @param accountQueryRequest
     * @return
     */
    public void balance(String merchantNo,String merchantCode,Integer strategyId){
    	RequestParam<AccountQueryRequest> requestParam = new RequestParam<AccountQueryRequest>();
    	AccountQueryRequest accountQueryRequest = new AccountQueryRequest();
    	accountQueryRequest.setMerchantNo(merchantNo);
//    	accountQueryRequest.setMerchantCode(merchantCode);
    	accountQueryRequest.setStrategyId(strategyId);
    	requestParam.setParam(accountQueryRequest);
    	ResponseData<AccountQueryResponse> resutlt = accountFacade.balance(requestParam);
    	System.out.println(GsonUtil.getInstance().toJson(resutlt));
    }
    /**
     * 包量详情查询
     * @param contractQueryRequest
     * @return
     */
    public void details(String merchantNo,String merchantCode,Integer productId){ 
    	RequestParam<AccountPackageRequest> requestParam = new RequestParam<AccountPackageRequest>();
    	AccountPackageRequest contractQueryRequest = new AccountPackageRequest();
    	contractQueryRequest.setMerchantNo(merchantNo);
    	contractQueryRequest.setMerchantCode(merchantCode);
    	contractQueryRequest.setProductId(productId);
    	contractQueryRequest.setPageNo(1); 
    	contractQueryRequest.setPageSize(40);
    	requestParam.setParam(contractQueryRequest);
    	Page<AccountDetailsResponse> page = accountFacade.details(requestParam);
    	System.out.println(GsonUtil.getInstance().toJson(page));
    }
}
