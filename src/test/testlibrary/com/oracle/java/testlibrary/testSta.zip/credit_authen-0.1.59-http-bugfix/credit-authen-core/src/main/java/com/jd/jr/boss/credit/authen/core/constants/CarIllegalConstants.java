package com.jd.jr.boss.credit.authen.core.constants;

/**
 * @author tangmingbo
 * @since 2017/11/13
 */
public class CarIllegalConstants {
	public static final String SRC_PATH = "upload/carillegal/src/";//用户上传文件存放路径
	public static final String DEST_PATH = "upload/carillegal/dest/";//用户下載文件存放路径
	public static final String COPY_PATH = "upload/signcode/temp/";//用户上传文件存放路径
}
