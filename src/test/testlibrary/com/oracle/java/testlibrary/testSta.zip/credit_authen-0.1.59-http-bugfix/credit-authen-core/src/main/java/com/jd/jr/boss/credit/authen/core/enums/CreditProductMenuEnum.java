package com.jd.jr.boss.credit.authen.core.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author jiangbo
 * @since 20170906
 */
public enum CreditProductMenuEnum {
    NULL(-1, null, null),
    ENT_BUSINESS_RISK(0, "ENT_BUSINESS_RISK", "经营风险"),
    ENT_OPERATION_STATUS(1, "ENT_OPERATION_STATUS", "经营状况"),
    ENT_JUDICIAL_LITIGATION(2, "ENT_JUDICIAL_LITIGATION", "司法风险"),
    ENT_INTELLECTUAL_PROPERTY(3, "ENT_INTELLECTUAL_PROPERTY", "知识产权"),
    ENT_ENTERPRISE_PROFILE(4, "ENT_ENTERPRISE_PROFILE", "企业概况"),
    ;

    private Integer code;
    private String name;
    private String description;

    /**
     * @param description 中文描述
     */
    CreditProductMenuEnum(String description) {
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param description 中文描述
     */
    CreditProductMenuEnum(Integer code, String description) {
        this.code = code;
        this.description = description;
    }

    /**
     * @param name        英文编码名称
     * @param description 中文描述
     */
    CreditProductMenuEnum(String name, String description) {
        this.name = name;
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param name        英文编码名称
     * @param description 中文描述
     */
    CreditProductMenuEnum(Integer code, String name, String description) {
        this.code = code;
        this.name = name;
        this.description = description;
    }


    /**
     * 获取枚举类型数值编码
     */
    public Integer toCode() {
        return this.code == null ? this.ordinal() : this.code;
    }

    /**
     * 获取枚举类型英文编码名称
     */
    public String toName() {
        return this.name == null ? this.name() : this.name;
    }

    /**
     * 获取枚举类型中文描述
     */
    public String toDescription() {
        return this.description;
    }


    /**
     * 获取枚举类型中文描述
     */
    public String toString() {
        return this.description;
    }



    /**
     * 按数值获取对应的枚举类型
     *
     * @param code 数值
     * @return 枚举类型
     */
    public static CreditProductMenuEnum enumValueOf(Integer code) {
        CreditProductMenuEnum[] values = CreditProductMenuEnum.values();
        CreditProductMenuEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (code != null && code.equals(values[i].toCode())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 按英文编码获取对应的枚举类型
     *
     * @param name 英文编码
     * @return 枚举类型
     */
    public static CreditProductMenuEnum enumValueOf(String name) {
        CreditProductMenuEnum[] values = CreditProductMenuEnum.values();
        CreditProductMenuEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (name != null && name.equalsIgnoreCase(values[i].toName())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 获取枚举类型的所有<数字编码,中文描述>对
     *
     * @return
     */
    public static Map<Integer, String> toCodeDescriptionMap() {
        LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
        for (int i = 0; i < CreditProductMenuEnum.values().length; i++) {
            if (CreditProductMenuEnum.values()[i] != NULL) {
                map.put(CreditProductMenuEnum.values()[i].toCode(), CreditProductMenuEnum.values()[i].toDescription());
            }
        }
        return map;
    }

    /**
     * 获取枚举类型的所有<英文编码名称,中文描述>对
     *
     * @return
     */
    public static Map<String, String> toNameDescriptionMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        for (int i = 0; i < CreditProductMenuEnum.values().length; i++) {
            if (CreditProductMenuEnum.values()[i] != NULL) {
                map.put(CreditProductMenuEnum.values()[i].toName(), CreditProductMenuEnum.values()[i].toDescription());
            }
        }
        return map;
    }
}
