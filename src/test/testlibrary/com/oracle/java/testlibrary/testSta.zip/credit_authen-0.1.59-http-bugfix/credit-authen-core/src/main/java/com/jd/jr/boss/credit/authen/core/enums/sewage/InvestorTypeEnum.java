package com.jd.jr.boss.credit.authen.core.enums.sewage;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 股东类型
 * @author tangmingbo
 *
 */
public enum InvestorTypeEnum {
	NULL(-1, null, null),

	REPRESENTATIVE(1, "REPRESENTATIVE", "个人股东"),

	REPRESENT_COMPANY(2, "REPRESENT_COMPANY", "企业股东");
	 private Integer code;
	    private String name;
	    private String description;

	    /**
	     * @param description 中文描述
	     */
        InvestorTypeEnum(String description) {
	        this.description = description;
	    }

	    /**
	     * @param code        数字编码
	     * @param description 中文描述
	     */
        InvestorTypeEnum(Integer code, String description) {
	        this.code = code;
	        this.description = description;
	    }

	    /**
	     * @param name        英文编码名称
	     * @param description 中文描述
	     */
        InvestorTypeEnum(String name, String description) {
	        this.name = name;
	        this.description = description;
	    }

	    /**
	     * @param code        数字编码
	     * @param name        英文编码名称
	     * @param description 中文描述
	     */
        InvestorTypeEnum(Integer code, String name, String description) {
	        this.code = code;
	        this.name = name;
	        this.description = description;
	    }


	    /**
	     * 获取枚举类型数值编码
	     */
	    public Integer toCode() {
	        return this.code == null ? this.ordinal() : this.code;
	    }

	    /**
	     * 获取枚举类型英文编码名称
	     */
	    public String toName() {
	        return this.name == null ? this.name() : this.name;
	    }

	    /**
	     * 获取枚举类型中文描述
	     */
	    public String toDescription() {
	        return this.description;
	    }


	    /**
	     * 获取枚举类型中文描述
	     */
	    public String toString() {
	        return this.description;
	    }



	    /**
	     * 按数值获取对应的枚举类型
	     *
	     * @param code 数值
	     * @return 枚举类型
	     */
	    public static InvestorTypeEnum enumValueOf(Integer code) {
	        InvestorTypeEnum[] values = InvestorTypeEnum.values();
	        InvestorTypeEnum v = NULL;
	        for (int i = 0; i < values.length; i++) {
	            if (code != null && code.equals(values[i].toCode())) {
	                v = values[i];
	                break;
	            }
	        }
	        return v;
	    }

	    /**
	     * 按英文编码获取对应的枚举类型
	     *
	     * @param name 英文编码
	     * @return 枚举类型
	     */
	    public static InvestorTypeEnum enumValueOf(String name) {
	        InvestorTypeEnum[] values = InvestorTypeEnum.values();
	        InvestorTypeEnum v = NULL;
	        for (int i = 0; i < values.length; i++) {
	            if (name != null && name.equalsIgnoreCase(values[i].toName())) {
	                v = values[i];
	                break;
	            }
	        }
	        return v;
	    }

	    /**
	     * 获取枚举类型的所有<数字编码,中文描述>对
	     *
	     * @return
	     */
	    public static Map<Integer, String> toCodeDescriptionMap() {
	        LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
	        for (int i = 0; i < InvestorTypeEnum.values().length; i++) {
	            if (InvestorTypeEnum.values()[i] != NULL) {
	                map.put(InvestorTypeEnum.values()[i].toCode(), InvestorTypeEnum.values()[i].toDescription());
	            }
	        }
	        return map;
	    }

	    /**
	     * 获取枚举类型的所有<英文编码名称,中文描述>对
	     *
	     * @return
	     */
	    public static Map<String, String> toNameDescriptionMap() {
	        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
	        for (int i = 0; i < InvestorTypeEnum.values().length; i++) {
	            if (InvestorTypeEnum.values()[i] != NULL) {
	                map.put(InvestorTypeEnum.values()[i].toName(), InvestorTypeEnum.values()[i].toDescription());
	            }
	        }
	        return map;
	    }
}
