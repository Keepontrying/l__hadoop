package com.jd.jr.boss.credit.authen.core.facade;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.beans.entity.JsfConfig;
import com.jd.jr.boss.credit.authen.core.service.CreditBatchDataService;
import com.jd.jr.boss.credit.authen.core.utils.ExcelUtil;
import com.jd.jr.boss.credit.authen.core.utils.HspUtil;
import com.jd.jr.boss.credit.authen.core.utils.JSFUtils;
import com.jd.jr.boss.credit.facade.authen.api.CreditBatchDataFacade;
import com.jd.jr.boss.credit.facade.authen.beans.entity.JsfConfigBean;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchDataQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.BatchDataEntity;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.admin.frame.utils.JSONUtils;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service("creditBatchDataFacadeImpl")
public class CreditBatchDataFacadeImpl implements CreditBatchDataFacade {

    private static Logger logger = LoggerFactory.getLogger(CreditBatchDataFacadeImpl.class);

    @Autowired
    CreditBatchDataService creditBatchDataService;

    @Override
    public CreditResponseData jsfResult(CreditRequestParam<Map<String, Object>> jsfParams) {
        logger.info("jsf接口入参：" + JSONUtils.toJSON(jsfParams));
        CreditResponseData creditResponseData = new CreditResponseData();
        Map<String, Object> map = jsfParams.getParam();
        if (CollectionUtils.isEmpty(map)) {
            creditResponseData.setSuccess(false);
            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
            return creditResponseData;
        }
        Object p = map.get("id");
        if (p == null) {
            creditResponseData.setSuccess(false);
            creditResponseData.setMessage("接口ID不为空");
            return creditResponseData;
        }
        String _id = String.valueOf(p);
        //根据产品ID查询对应的jsf接口
        JsfConfig jsfConfig = creditBatchDataService.queryJsfConfigBy(Long.parseLong(_id));
        if (jsfConfig == null) {
            creditResponseData.setSuccess(false);
            creditResponseData.setMessage("无效的接口配置ID");
            return creditResponseData;
        }

        Object result = JSFUtils.jsfResult(jsfConfig, map);
        creditResponseData.setSuccess(true);
        creditResponseData.setData(result);
        creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
        return creditResponseData;
    }

    @Override
    public CreditResponseData uploadJsfConfig(CreditRequestParam<JsfConfigBean> jsfConfigBean) {
        logger.info("更新jsf配置文件参数：" + JSONUtils.toJSON(jsfConfigBean));
        CreditResponseData creditResponseData = new CreditResponseData();
        JsfConfigBean config = jsfConfigBean.getParam();
        if (StringUtils.isEmpty(config)) {
            creditResponseData.setSuccess(false);
            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
            return creditResponseData;
        }
        try {
            int ok = creditBatchDataService.updateJsfConfig(config);
            if (ok > 0) {
                creditResponseData.setSuccess(true);
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
            } else {
                creditResponseData.setSuccess(false);
                creditResponseData.setMessage(ResponseMessage.DATABASE_ERROR.getDesc());
            }
        } catch (DuplicateKeyException e) {
            e.printStackTrace();
            creditResponseData.setSuccess(false);
            creditResponseData.setMessage(config.getMethodName() + "方法重复");
        } catch (JSONException e) {
            e.printStackTrace();
            creditResponseData.setSuccess(false);
            creditResponseData.setMessage("参数模板不满足json格式");
        } catch (Exception e) {
            e.printStackTrace();
            creditResponseData.setSuccess(false);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
        }

        return creditResponseData;
    }

    @Override
    public CreditPage<JsfConfigBean> queryJsfConfig(CreditRequestParam<JsfConfigBean> jsfConfigBean) {
        logger.info("jsf接口配置查询参数："+JSONUtils.toJSON(jsfConfigBean));
        JsfConfigBean configBean = jsfConfigBean.getParam();
        return creditBatchDataService.pageList(configBean);
    }

    @Override
    public CreditResponseData uploadBatchDataParam(CreditRequestParam<List<Map<String, Object>>> jsfParams) {
        logger.info("上传导出数据参数：" + JSONUtils.toJSON(jsfParams));
        CreditResponseData creditResponseData = new CreditResponseData();
        try{
            Map<String, Object> args = (Map<String, Object>) jsfParams.getArg();
            List<Map<String, Object>> jsfInterfaceParams = jsfParams.getParam();
            // 调用service生成csv文件，异步
            creditBatchDataService.exportCsv(args, jsfInterfaceParams);
            creditResponseData.setSuccess(true);
            creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
        }catch (Exception e){
            logger.error(e.getMessage());
            creditResponseData.setSuccess(false);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
        }

        return creditResponseData;
    }

    @Override
    public CreditPage<BatchDataEntity> queryBatchExportData(CreditRequestParam<BatchDataQueryParam> param) {
        logger.info("下载文件列表参数：" + JSONUtils.toJSON(param));
        return creditBatchDataService.exportDataList(param.getParam());
    }

    @Override
    public CreditResponseData exportOutsideData(CreditRequestParam<Map<String, Object>> param) {
        logger.info("外部数据导出：" + JSONUtils.toJSON(param));
        CreditResponseData responseData = new CreditResponseData();
        try {
            //参数校验
            Map<String, Object> paramMap = param.getParam();
            Object json = paramMap.get("json");
            Object url = paramMap.get("url");
            if (json == null || url == null || CollectionUtils.isEmpty(paramMap)) {
                responseData.setSuccess(false);
                responseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
                return responseData;
            }
            creditBatchDataService.exportOutsideData(paramMap);
            responseData.setSuccess(true);
            responseData.setMessage(ResponseMessage.SUCCESS.getDesc());
        } catch (Exception e) {
            logger.error(e.getMessage());
            responseData.setSuccess(false);
            responseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
        }
        return responseData;
    }

    @Override
    public CreditResponseData<List<String>> getJsfConfigInterfaceId(CreditRequestParam<JsfConfigBean> param) {
        logger.info("查询已配置jsf接口：" + JSONUtils.toJSON(param));
        CreditResponseData<List<String>> creditResponseData = new CreditResponseData<>();
        try {
            List<String> rows = creditBatchDataService.getJsfConfigInterfaceId(param.getParam());
            creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
            creditResponseData.setSuccess(true);
            creditResponseData.setData(rows);
        } catch (Exception e) {
            logger.error(e.getMessage());
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setSuccess(false);
        }
        return creditResponseData;
    }

    @Override
    public CreditResponseData<List<JsfConfigBean>> getMethodList(CreditRequestParam<JsfConfigBean> param) {
        logger.info("根据interfaceId查询已配置方法列表：" + JSONUtils.toJSON(param));
        CreditResponseData<List<JsfConfigBean>> creditResponseData = new CreditResponseData<>();
        try {
            List<JsfConfigBean> rows = creditBatchDataService.getMethodList(param.getParam());
            creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
            creditResponseData.setSuccess(true);
            creditResponseData.setData(rows);
        } catch (Exception e) {
            logger.error(e.getMessage());
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setSuccess(false);
        }
        return creditResponseData;
    }

}
