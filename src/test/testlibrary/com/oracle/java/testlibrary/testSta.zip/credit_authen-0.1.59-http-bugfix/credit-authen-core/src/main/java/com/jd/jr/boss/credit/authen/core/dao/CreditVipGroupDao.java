package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.facade.authen.beans.param.VipGroupQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.VipMerchantQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditVipGroup;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CreditVipGroupDao {

    /**
     * 插入
     * @param record
     * @return
     */
    int insert(CreditVipGroup record);
    /**
     * 插入
     * @param vipGroup
     * @return
     */
    int updateByPrimaryKeySelective(CreditVipGroup vipGroup);

    /**
     * 多条件查询vip商户  分页
     * @param queryParam
     * @return
     */
	List<CreditVipGroup> selectVipGroupPageByParam(VipGroupQueryParam queryParam);

	/**
	 * 多条件查询vip商户总记录数  分页
	 * @param queryParam
	 * @return
	 */
	Integer selectVipGroupPageCountByParam(VipGroupQueryParam queryParam);

}