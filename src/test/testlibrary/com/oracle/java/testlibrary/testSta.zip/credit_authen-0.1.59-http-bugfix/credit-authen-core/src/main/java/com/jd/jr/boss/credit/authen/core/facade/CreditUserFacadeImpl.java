package com.jd.jr.boss.credit.authen.core.facade;

import com.jd.jr.boss.credit.authen.core.service.CreditUserService;
import com.jd.jr.boss.credit.authen.core.service.CreditWxUserService;
import com.jd.jr.boss.credit.authen.core.service.impl.CreditUserServiceImpl;
import com.jd.jr.boss.credit.facade.authen.api.CreditUserFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.UserQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.WxUserParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.boss.credit.admin.entity.CreditWxUser;
import com.wangyin.boss.credit.admin.enums.CreditUserCheckEnum;
import com.wangyin.boss.credit.admin.enums.CreditUserSuperCheckEnum;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * @author jiangbo
 * @since 2017/3/29
 */
@Service("creditUserFacade")
public class CreditUserFacadeImpl implements CreditUserFacade {
    private static Logger logger = LoggerFactory.getLogger(CreditUserServiceImpl.class);

    @Autowired
    CreditUserService creditUserService;

    @Autowired
    CreditWxUserService creditWxUserService;

//    @Override
//    @Deprecated
//    public CreditResponseData<CreditUser> selectSingleCreditUserByParam(CreditRequestParam<UserQueryParam> requestParam) {
//        CreditResponseData<CreditUser> creditResponseData = new CreditResponseData<CreditUser>();
//        logger.error("CreditUserFacadeImpl selectSingleCreditUserByParam error, requestParam:{}", requestParam);
//        creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
//        creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
//        creditResponseData.setSuccess(false);
//        creditResponseData.setData(null);
//        return creditResponseData;
//
////        CreditUser creditUser = new CreditUser();
////        UserQueryParam userQueryParam = requestParam.getParam();
////        creditUser.setUserStatus(userQueryParam.getUserStatus());
//////        creditUser.setEmail(userQueryParam.getLoginName());
////        creditUser.setLoginName(userQueryParam.getLoginName());
////        creditUser.setEmailReal(userQueryParam.getEmailReal());
////        creditUser.setLimit("1");
////        creditUser.setStart("0");
////        CreditResponseData<CreditUser> creditResponseData = new CreditResponseData<CreditUser>();
////        if (StringUtils.isBlank(creditUser.getLoginName())){
////            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
////            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
////            creditResponseData.setSuccess(false);
////            return creditResponseData;
////        }
////
////
////        List<CreditUser> creditUserList = null;
////
////        try {
////            creditUserList = creditUserService.selectCreditUserByParam(creditUser);
////        } catch (Exception e) {
////            logger.error("CreditUserFacade selectCreditUserByParam error, creditUser:{}", creditUser, e);
////            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
////            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
////            creditResponseData.setSuccess(false);
////            creditResponseData.setData(null);
////            return creditResponseData;
////        }
////        if (creditUserList != null && creditUserList.size() > 0){
////
////            creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
////            creditResponseData.setCode(ResponseMessage.SUCCESS.name());
////            creditResponseData.setSuccess(true);
////            creditResponseData.setData(creditUserList.get(0));
////            return creditResponseData;
////        }else {
////            creditResponseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
////            creditResponseData.setCode(ResponseMessage.NOT_EXIST.name());
////            creditResponseData.setSuccess(false);
////            return creditResponseData;
////        }
//
//    }

    @Override
    public CreditResponseData<CreditUser> selectSingleCreditSuperUserByParam(CreditRequestParam<UserQueryParam> requestParam) {
        CreditUser creditUser = new CreditUser();
        UserQueryParam userQueryParam = requestParam.getParam();
        creditUser.setUserStatus(userQueryParam.getUserStatus());
//        creditUser.setEmail(userQueryParam.getLoginName());
//        creditUser.setLoginName(userQueryParam.getLoginName());
//        creditUser.setEmailReal(userQueryParam.getEmailReal());
        creditUser.setOperatorId(userQueryParam.getOperatorId());
        creditUser.setCompanyUserId(userQueryParam.getCompanyUserId());
        creditUser.setLoginInfoId(userQueryParam.getLoginInfoId());
        creditUser.setLimit("1");
        creditUser.setStart("0");
        CreditResponseData<CreditUser> creditResponseData = new CreditResponseData<CreditUser>();

        //不使用loginName,因为loginName可以被注销释放掉
//        if (StringUtils.isBlank(creditUser.getLoginName())){
//            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
//            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
//            creditResponseData.setSuccess(false);
//            return creditResponseData;
//        }

        //三个id都不能为空
        if (StringUtils.isBlank(creditUser.getOperatorId()) || StringUtils.isBlank(creditUser.getCompanyUserId()) || StringUtils.isBlank(creditUser.getLoginInfoId())) {
            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
            creditResponseData.setSuccess(false);
            return creditResponseData;
        }

        List<CreditUser> creditUserList = null;

        try {
            creditUserList = creditUserService.selectCreditSuperUserByParam(creditUser);
        } catch (Exception e) {
            logger.error("CreditUserFacade selectCreditUserByParam error, creditUser:{}", GsonUtil.getInstance().toJson(creditUser), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(null);
            return creditResponseData;
        }
        if (creditUserList != null && creditUserList.size() > 0){

            if (creditUserList.size() > 1){
                logger.error("selectSingleCreditUserByParam return more than one user!!,requestParam:{}", GsonUtil.getInstance().toJson(requestParam));
            }

            creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
            creditResponseData.setCode(ResponseMessage.SUCCESS.name());
            creditResponseData.setSuccess(true);
            creditResponseData.setData(creditUserList.get(0));
            return creditResponseData;
        }else {
            creditResponseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
            creditResponseData.setCode(ResponseMessage.NOT_EXIST.name());
            creditResponseData.setSuccess(false);
            return creditResponseData;
        }
    }

    @Override
    public CreditResponseData<Integer> insert(CreditRequestParam<UserQueryParam> requestParam) {
        CreditUser creditUser = new CreditUser();
        UserQueryParam userQueryParam = requestParam.getParam();
        CreditResponseData<Integer> creditResponseData = new CreditResponseData<Integer>();

        if (requestParam == null || requestParam.getParam() == null){

            creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
            creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(null);
            logger.error("insert error, requestParam is null");
            return creditResponseData;
        }

        try {

            creditUser.setUserStatus(userQueryParam.getUserStatus());
//            creditUser.setEmail(userQueryParam.getEmail());
            creditUser.setLoginName(userQueryParam.getLoginName());
            creditUser.setMerchantId(userQueryParam.getMerchantId());
            creditUser.setPhone(userQueryParam.getPhone());
            creditUser.setJrId(userQueryParam.getJrId());
            creditUser.setLoginInfoId(userQueryParam.getLoginInfoId());
            creditUser.setCompanyUserId(userQueryParam.getCompanyUserId());
            creditUser.setOperatorId(userQueryParam.getOperatorId());
            creditUser.setCreatedDate(new Date());
            creditUser.setModifiedDate(new Date());
            creditUser.setUserPin(UUID.randomUUID().toString().replace("-",""));
            creditUser.setCheckStatus(CreditUserCheckEnum.NEW.getCode());
            creditUser.setSuperCheckStatus(CreditUserSuperCheckEnum.SUPER_NEW.getCode());

            int result = creditUserService.insertSelective(creditUser);
            if (result > 0){
                logger.info("CreditUserFacade insertSelective success, creditUser:{}",creditUser);
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(creditUser.getUserId());
                return creditResponseData;
            }else {
                logger.info("CreditUserFacade insertSelective error, creditUser:{}",creditUser);
                creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
                creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
                creditResponseData.setSuccess(false);
                creditResponseData.setData(null);
                return creditResponseData;
            }

        } catch (Exception e) {
            logger.error("CreditUserFacade insert error, creditUser:{}", creditUser, e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(null);
            return creditResponseData;
        }
    }

    public List<CreditWxUser> getWxUser(CreditWxUser param){
        try {
            List<CreditWxUser> list = creditWxUserService.getWxUser(param);
            return list;
        }catch (Exception e){
            logger.error("queryWxUser error",e);
        }
        return null;
    }

    @Override
    public boolean unbindingWx(WxUserParam param) {
        try {
            return creditWxUserService.unbindingWx(param);
        }catch (Exception e){
            logger.error("queryWxUser error",e);
        }
        return false;
    }

    @Override
    public List<CreditUser> selectCreditUserByParam4Common(CreditRequestParam<UserQueryParam> creditRequestParam) {
        List<CreditUser> userList = new ArrayList<>();
        try {
            UserQueryParam userQueryParam =creditRequestParam.getParam();
            if(null == userQueryParam){
               return userList;
            }
            CreditUser creditUser = new CreditUser();
            creditUser.setMerchantId(userQueryParam.getMerchantId());
            userList = creditUserService.selectCreditUserByPrm4Common(creditUser);
        } catch (Exception e) {
            logger.error("selectCreditUserByParam error",e);
        }
        return userList;
    }

    @Override
    public CreditUser selectCreditUserByOpenId(String openId){
        try {
            CreditUser user = creditUserService.selectCreditUserByOpenId(openId);
            return user;
        }catch (Exception e){
            logger.error("queryUserByOpenId error",e);
        }
        return null;
    }

    public static void main(String[] args) {
        String uuid = UUID.randomUUID().toString(); //获取UUID并转化为String对象
        uuid = uuid.replace("-", "");               //因为UUID本身为32位只是生成时多了“-”，所以将它们去点就可
        System.out.println(uuid);
    }
}
