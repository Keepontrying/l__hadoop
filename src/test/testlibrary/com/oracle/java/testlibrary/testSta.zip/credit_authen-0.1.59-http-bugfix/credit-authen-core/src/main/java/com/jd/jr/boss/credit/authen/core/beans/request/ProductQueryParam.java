package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;

public class ProductQueryParam implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2894124185609740621L;
	/**
     * 产品ID
     */
    private Integer productId;
    /**
     * 产品状态
     */
    private String productStatus;

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductStatus() {
		return productStatus;
	}

	public void setProductStatus(String productStatus) {
		this.productStatus = productStatus;
	}
	
	
}
