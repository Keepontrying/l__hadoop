package com.jd.jr.boss.credit.authen.core.dao;

import org.springframework.stereotype.Repository;

import com.jd.jr.boss.credit.authen.core.beans.request.AccountQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditMerchantAccount;

/**
 *  账户管理
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
@Repository
public interface CreditAccountDao {
	 /**
     *  查询清结算账户号
     * @param accountChargeRequest
     * @return
     */
     CreditMerchantAccount queryAccountNo(AccountQueryParam accountQueryParam) throws Exception;
    /**
     *  查询用户信息
     * @param mapRequest
     * @return
     */
    CreditMerchant queryMerchantInfo(AccountQueryParam accountQueryParam) throws Exception;
    /**
     *  新增用户和账务关系
     * @param merchantAccoutRequest
     * @return
     */
    Integer saveMerchantAccount(CreditMerchantAccount merchantAccoutRequest) throws Exception;

}
