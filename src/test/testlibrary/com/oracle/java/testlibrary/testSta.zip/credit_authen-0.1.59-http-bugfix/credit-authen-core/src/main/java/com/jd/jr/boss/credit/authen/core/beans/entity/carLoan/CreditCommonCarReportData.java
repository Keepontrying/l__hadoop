package com.jd.jr.boss.credit.authen.core.beans.entity.carLoan;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 通用版排污报告返回结果
 * @author tangmingbo
 *
 */
public class CreditCommonCarReportData implements Serializable{

	private static final long serialVersionUID = 2936531965994611042L;
	/**
	 * 主题企业
	 */
	private EntInfo mainEntInfo;
	/**
	 * 关联企业信息
	 */
	private RelationEntInfoData relationInfos;
	/**
	 * 企业信息 key= entName+productCode 企业维度
	 */
	Map<String,List> entInfoMap;
	/**
	 * 企业信息 key= productCode 产品维度
	 */
	Map<String,List> productInfoMap;
	/**
	 * 关联公司 股权质押和动产抵押 key= entName+productCode value：股权质押和动产抵押的钱
	 */
	Map<String,String> amountMap;



	/**
	 * 工商信息描述
	 */
	private StatisticDesc statisticDesc;

	// 扩展信息
	private Map extendInfo = new HashMap();

	public EntInfo getMainEntInfo() {
		return mainEntInfo;
	}

	public void setMainEntInfo(EntInfo mainEntInfo) {
		this.mainEntInfo = mainEntInfo;
	}

	public RelationEntInfoData getRelationInfos() {
		return relationInfos;
	}

	public void setRelationInfos(RelationEntInfoData relationInfos) {
		this.relationInfos = relationInfos;
	}

	public Map<String, List> getEntInfoMap() {
		return entInfoMap;
	}

	public void setEntInfoMap(Map<String, List> entInfoMap) {
		this.entInfoMap = entInfoMap;
	}

	public StatisticDesc getStatisticDesc() {
		return statisticDesc;
	}

	public void setStatisticDesc(StatisticDesc statisticDesc) {
		this.statisticDesc = statisticDesc;
	}

	public Map<String, List> getProductInfoMap() {
		return productInfoMap;
	}

	public void setProductInfoMap(Map<String, List> productInfoMap) {
		this.productInfoMap = productInfoMap;
	}

    public Map<String, String> getAmountMap() {
        return amountMap;
    }

    public void setAmountMap(Map<String, String> amountMap) {
        this.amountMap = amountMap;
    }

    public Map getExtendInfo() {
        return extendInfo;
    }

    public void setExtendInfo(Map extendInfo) {
        this.extendInfo = extendInfo;
    }
}
