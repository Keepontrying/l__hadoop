package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;

/** 
* @desciption : 海关消息队列 批量单号状态
* @author : yangjinlin@jd.com
* @date ：2017年7月20日 下午6:32:11 
* @version 1.0 
* @return  */
public class CustomsMqBatchVo implements Serializable{

	private static final long serialVersionUID = -4412151228480906292L;
	
	/**
	 * 单号报关状态
	 */
	private String result;
	/**
	 * 爬取时间
	 */
	private String crawlerDate;
	/**
	 * 错误码
	 */
	private String code;
	/**
	 * 批次号
	 */
	private String batchtoken;
	/**
	 * 报关单号
	 */
	private String txtCode;
	/**
	 * 错误信息
	 */
	private String message;
	/**
	 * 历史轨迹
	 */
	private String history;

	private String systemId;//用户Id

	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getCrawlerDate() {
		return crawlerDate;
	}
	public void setCrawlerDate(String crawlerDate) {
		this.crawlerDate = crawlerDate;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getBatchtoken() {
		return batchtoken;
	}
	public void setBatchtoken(String batchtoken) {
		this.batchtoken = batchtoken;
	}
	public String getTxtCode() {
		return txtCode;
	}
	public void setTxtCode(String txtCode) {
		this.txtCode = txtCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getHistory() {
		return history;
	}
	public void setHistory(String history) {
		this.history = history;
	}

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }
}
