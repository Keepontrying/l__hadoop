package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.Date;

public class CreditBfMonitorList implements Serializable {
    private static final long serialVersionUID = -7857043635979186567L;
    private Integer id;

    private String systemId;

    private Integer entpriseId;

    private Date createdDate;

    private String listMonitored;

    private Date listBeginDate;

    private Date listEndDate;

    private Date modifiedDate;

    private String isPushed;

    private Date pushDate;
    /**
     * 标识 目前有null和vip
     */
    private String flagMark;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId == null ? null : systemId.trim();
    }

    public Integer getEntpriseId() {
        return entpriseId;
    }

    public void setEntpriseId(Integer entpriseId) {
        this.entpriseId = entpriseId;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getListMonitored() {
        return listMonitored;
    }

    public void setListMonitored(String listMonitored) {
        this.listMonitored = listMonitored == null ? null : listMonitored.trim();
    }

    public Date getListBeginDate() {
        return listBeginDate;
    }

    public void setListBeginDate(Date listBeginDate) {
        this.listBeginDate = listBeginDate;
    }

    public Date getListEndDate() {
        return listEndDate;
    }

    public void setListEndDate(Date listEndDate) {
        this.listEndDate = listEndDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getIsPushed() {
        return isPushed;
    }

    public void setIsPushed(String isPushed) {
        this.isPushed = isPushed == null ? null : isPushed.trim();
    }

    public Date getPushDate() {
        return pushDate;
    }

    public void setPushDate(Date pushDate) {
        this.pushDate = pushDate;
    }

    public String getFlagMark() {
        return flagMark;
    }

    public void setFlagMark(String flagMark) {
        this.flagMark = flagMark;
    }
}