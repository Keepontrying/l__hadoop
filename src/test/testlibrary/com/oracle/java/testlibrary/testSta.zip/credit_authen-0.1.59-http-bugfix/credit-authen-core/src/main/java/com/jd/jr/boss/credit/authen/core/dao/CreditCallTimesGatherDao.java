package com.jd.jr.boss.credit.authen.core.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.jd.jr.boss.credit.domain.common.entity.CreditCallTimesGather;
import com.jd.jr.boss.credit.facade.authen.beans.param.CallTimesGatherQueryParam;

/** 
* @desciption : 调用量汇总数据层
* @author : yangjinlin@jd.com
* @date ：2018年4月16日 下午2:59:57 
* @version 1.0 
* @return  */
@Repository
public interface CreditCallTimesGatherDao {

	/**
	 * 查询调用量汇总信息List
	 * @param callTimesGatherPrm
	 * @return
	 */
	List<CreditCallTimesGather> queryCallTimesGatherTradeLogList(CallTimesGatherQueryParam callTimesGatherPrm);
	
	/**
	 * 查询调用量汇总信息List 总数
	 * @param queryParam
	 * @return
	 */
	int queryCallTimesGatherTradeLogListCount(CallTimesGatherQueryParam queryParam);

	/**
	 * 根据主键id更新调用量汇总信息
	 * @param callTimesGather
	 * @return
	 */
	Integer updateCallTimesGatherById(CreditCallTimesGather callTimesGather);

	/**
	 * 新增调用量汇总
	 * @param callTimesGather
	 * @return
	 */
	Integer insertCallTimesGather(CreditCallTimesGather callTimesGather);

	/**
	 * 查询商户维度调用量汇总信息List 总数
	 * @param queryParam
	 * @return
	 */
	int queryMerchTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam);

	/**
	 * 查询商户维度调用量汇总信息List
	 * @param queryParam
	 * @return
	 */
	List<CreditCallTimesGather> queryMerchTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam);

	/**
	 * 
	 * @param queryParam
	 * @return
	 */
	int queryMerchProdTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam);

	/**
	 * 
	 * @param queryParam
	 * @return
	 */
	List<CreditCallTimesGather> queryMerchProdTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam);

	/**
	 * 
	 * @param queryParam
	 * @return
	 */
	int queryMerchProdStepTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam);

	/**
	 * 
	 * @param queryParam
	 * @return
	 */
	List<CreditCallTimesGather> queryMerchProdStepTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam);

	/**
	 * 
	 * @param queryParam
	 * @return
	 */
	int queryMerchProdResoTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam);

	/**
	 * 
	 * @param queryParam
	 * @return
	 */
	List<CreditCallTimesGather> queryMerchProdResoTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam);

	/**
	 *
	 * @param queryParam
	 * @return
	 */
	List<CreditCallTimesGather> queryResoTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam);

    /**
     * 查询业务流水调用量汇总  产品维度  总数
     * @param queryParam
     * @return
     */
    int queryProdTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam);

    /**
     * 查询业务流水调用量汇总  产品维度 list
     * @param queryParam
     * @return
     */
    List<CreditCallTimesGather> queryProdTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam);
}
