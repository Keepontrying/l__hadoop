package com.jd.jr.boss.credit.authen.core.jms.order;


import com.jd.jr.boss.credit.authen.core.service.OrderService;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;
import com.jd.jr.boss.credit.domain.common.enums.CreditOrderStatusEnum;
import com.jdjr.fmq.client.consumer.MessageListener;
import com.jdjr.fmq.common.message.Message;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by anmeng on 2017/1/23.
 */

@Service("orderBalanceUsedListener")
public class OrderBalanceUsedListener implements MessageListener {

    private static final Logger logger = LoggerFactory.getLogger(OrderBalanceUsedListener.class);

    @Autowired
    private OrderService orderService;

    @Override
    public void onMessage(List<Message> messages) throws Exception {
        if (messages == null || messages.isEmpty()) {
            return;
        }

        for (Message message : messages) {
            logger.info(String.format("收到一条订单余量用完消息,消息主题（队列名）：%s,内容是：%s,业务ID为:%s", message.getTopic(), message.getText(), message.getBusinessId()));
            String objectJson = message.getText();

            JSONObject triggerEntity = null;
            try {
                triggerEntity = JSONObject.fromObject(objectJson);
            } catch (Exception e) {
                logger.error("json消息格式错误：" + objectJson);
                return;
            }

            Integer orderId = triggerEntity.getInt("orderId");

            CreditOrder creditOrder = new CreditOrder();
            creditOrder.setStatus(CreditOrderStatusEnum.USED);
            creditOrder.setOrderId(orderId);
            orderService.updateCreditOrderValidity(creditOrder);
            logger.info("订单余量用完消息处理完成:" + message.getText());
        }
    }
}
