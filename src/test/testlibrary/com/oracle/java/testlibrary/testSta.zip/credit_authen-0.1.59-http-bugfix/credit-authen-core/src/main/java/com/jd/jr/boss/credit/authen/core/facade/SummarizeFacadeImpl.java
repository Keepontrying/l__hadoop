package com.jd.jr.boss.credit.authen.core.facade;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.service.CreditSummarizeService;
import com.jd.jr.boss.credit.facade.authen.api.SummarizeFacade;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.entity.CreditSummarize;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.commons.util.StringUtil;

/**
 * 
 * <ul>
 * <li>1、开发日期：2018年1月15日</li>
 * <li>2、开发时间：下午4:45:37</li>
 * <li>3、作 者：zhanghui12</li>
 * <li>4、类型名称：SummarizeFacadeImpl</li>
 * <li>5、类型意图：统计查询</li>
 * </ul>
 *
 */
@Service("summarizeFacade")
public class SummarizeFacadeImpl implements SummarizeFacade {
	private static final Logger logger = LoggerFactory.getLogger(SummarizeFacadeImpl.class);
	@Autowired
	private CreditSummarizeService creditSummarizeService;
	@Override
	public CreditResponseData<List<CreditSummarize>> querySummarize(CreditRequestParam<String> reqParam) {
		logger.info("查询统计结果"+reqParam.getParam());
		CreditResponseData<List<CreditSummarize>> response=new CreditResponseData<List<CreditSummarize>>();
		try {
			if(StringUtil.isEmpty(reqParam.getParam())){
				response.setCode("FAIL");
				response.setMessage("查询月份不能为空");
			}
			List<CreditSummarize> list = creditSummarizeService.querySummarizeList(reqParam.getParam());
			response.setCode("SUCCESS");
			response.setMessage("成功");
			response.setData(list);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			response.setCode("FAIL");
			response.setMessage("未知异常");
		}
		logger.info("查询统计结果:" + JSONObject.toJSONString(response));
		return response;
	}

}
