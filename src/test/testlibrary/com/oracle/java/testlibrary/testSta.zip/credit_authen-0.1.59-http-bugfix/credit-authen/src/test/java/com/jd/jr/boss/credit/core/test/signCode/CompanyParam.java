package com.jd.jr.boss.credit.core.test.signCode;

public class CompanyParam {
		private String serialNo;
		private String name;
		private String creditCode;
		private String regNo;
		private String orgNo;
		private String capital;
		private String remark;
		/**
		 * @return the serialNo
		 */
		public String getSerialNo() {
			return serialNo;
		}
		/**
		 * @param serialNo the serialNo to set
		 */
		public void setSerialNo(String serialNo) {
			this.serialNo = serialNo;
		}
		/**
		 * @return the name
		 */
		public String getName() {
			return name;
		}
		/**
		 * @param name the name to set
		 */
		public void setName(String name) {
			this.name = name;
		}
		/**
		 * @return the creditCode
		 */
		public String getCreditCode() {
			return creditCode;
		}
		/**
		 * @param creditCode the creditCode to set
		 */
		public void setCreditCode(String creditCode) {
			this.creditCode = creditCode;
		}
		/**
		 * @return the regNo
		 */
		public String getRegNo() {
			return regNo;
		}
		/**
		 * @param regNo the regNo to set
		 */
		public void setRegNo(String regNo) {
			this.regNo = regNo;
		}
		/**
		 * @return the orgNo
		 */
		public String getOrgNo() {
			return orgNo;
		}
		/**
		 * @param orgNo the orgNo to set
		 */
		public void setOrgNo(String orgNo) {
			this.orgNo = orgNo;
		}
		/**
		 * @return the capital
		 */
		public String getCapital() {
			return capital;
		}
		/**
		 * @param capital the capital to set
		 */
		public void setCapital(String capital) {
			this.capital = capital;
		}
		/**
		 * @return the remark
		 */
		public String getRemark() {
			return remark;
		}
		/**
		 * @param remark the remark to set
		 */
		public void setRemark(String remark) {
			this.remark = remark;
		}
}
