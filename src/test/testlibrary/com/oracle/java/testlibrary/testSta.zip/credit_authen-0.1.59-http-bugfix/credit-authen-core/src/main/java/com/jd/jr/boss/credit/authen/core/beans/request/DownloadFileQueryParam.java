package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;

/**
 * Created by anmeng on 2016/12/14.
 */
public class DownloadFileQueryParam implements Serializable {
    private static final long serialVersionUID = 3595607506263729022L;
    /**
     * 商户号
     */
    private String merchantNo;
    /**
     * 文件生成状态
     */
    private String status;
    /**
     * 文件类型
     */
    private String fileType;
    /**
     * 分页参数
     */
    private Integer start;
    private Integer limit;

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }
}
