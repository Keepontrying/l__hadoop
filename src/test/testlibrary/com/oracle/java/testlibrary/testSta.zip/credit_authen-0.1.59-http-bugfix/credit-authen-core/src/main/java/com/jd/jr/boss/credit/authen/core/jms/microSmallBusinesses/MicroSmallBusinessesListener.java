package com.jd.jr.boss.credit.authen.core.jms.microSmallBusinesses;

import com.google.gson.JsonSyntaxException;
import com.jd.jmq.client.consumer.MessageListener;
import com.jd.jmq.fastjson.JSON;
import com.jd.jr.boss.credit.authen.core.beans.entity.microSmallBusinesses.Basic4Huaitao;
import com.jd.jr.boss.credit.authen.core.service.CreditMicroSmallBusinessesService;
import com.wangyin.commons.util.Logger;
import com.wangyin.operation.utils.GsonUtil;
import com.jd.jmq.common.message.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2018/3/28
 */
@Component("microSmallBusinessesListener")
public class MicroSmallBusinessesListener implements MessageListener {
    private Logger logger = new Logger(MicroSmallBusinessesListener.class);

    @Autowired
    private CreditMicroSmallBusinessesService creditMicroSmallBusinessesService;

    @Override
    public void onMessage(List<Message> list) throws Exception {
        if (list == null || list.isEmpty()) {
            logger.warn("microSmallBusinessesListener message is null");
            return;
        }

        for (Message message : list) {
            String objectJson = message.getText();
            logger.info("microSmallBusinessesListener message, body part:{}", objectJson);
            Basic4Huaitao basic;
            try {
                basic = JSON.parseObject(objectJson, Basic4Huaitao.class);
                logger.info("microSmallBusinessesListener parse object paymentNotice:{}", GsonUtil.getInstance().toJson(basic));
                if("100".equals(basic.getCode())){
                    creditMicroSmallBusinessesService.insertBasic4Huaitao(basic);
                }
            } catch (JsonSyntaxException e) {
                logger.error("message json format error：" + objectJson);
                continue;
            }
        }
    }

}
