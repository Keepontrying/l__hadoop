package com.jd.jr.boss.credit.authen.core.jms.entbfmt;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.beans.entity.CreditBfMonitorEntprise;
import com.jd.jr.boss.credit.authen.core.service.impl.DBBfmtRecordServiceImpl;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.EntBfMonitorListFacade;
import com.jdjr.fmq.client.consumer.MessageListener;
import com.jdjr.fmq.common.message.Message;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.commons.util.Logger;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * created by ChenKaiJu on 2018/9/18  19:40
 */
@Component("entBfMonitorChangeListener")
public class EntBfMonitorChangeListener implements MessageListener {

    private Logger logger = new Logger(EntBfMonitorChangeListener.class);

    @Resource
    DBBfmtRecordServiceImpl bfmtRecordService;

    @Override
    public void onMessage(List<Message> list) throws Exception {
        logger.info("收到企业反洗钱受益人变更信息，添加到变更记录开始执行。。。");
        if (list != null) {
            for (Message message : list) {
                String msgtext = message.getText();
                JSONObject msgobj = JSON.parseObject(msgtext);
                String entName = msgobj.getString("entName");
                CreditBfMonitorEntprise entprise= bfmtRecordService.supdateToRecord(entName,getOurSystemId());
                bfmtRecordService.updateToRecord(entprise);
            }
        }
        logger.info("添加到变更记录任务执行结束。。。");
    }

    public String getOurSystemId(){
        String ourSystemId="";
        String systemIds=ConfigUtil.getString("our.merchant.private.systemId");
        if(systemIds!=null){
            String[] ids=systemIds.split(";");
            ourSystemId=ids[0];
        }
        return ourSystemId;
    }
}
