package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;

public class BillDetailsQueryParam implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 245681702025152560L;
	/**
     * 账单时间
     */
    private String startDate;
    /**
     * 商户号
     */
    private String merchantNo;
    /**
     * 产品ID
     */
    private Integer productId;
    /**
     * 计费ID
     */
    private Integer strategyId;
    /**
     * 计费类型
     */
    private String chargeType;
    /**
     * 调用模式
     */
    private String callMode;
    /**
     * 开始时间
     */
    private String startTime;
    /**
     * 结束时间
     */
    private String finishTime;
    /**
     * 平台类型PORSON,ENTERPRISE
     */
    private String creditType;
    /**
	 * vip监控标识：YES-vip监控；NO-普通使用
	 */
	private String vipMonitorFlag;

	/**
	 * 付费模式，预付或后付
	 */
	private String purchaseType;
	/**
	 * 用户唯一标识
	 */
	private String userPin;
    
    
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getMerchantNo() {
		return merchantNo;
	}
	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public Integer getStrategyId() {
		return strategyId;
	}
	public void setStrategyId(Integer strategyId) {
		this.strategyId = strategyId;
	}
	public String getChargeType() {
		return chargeType;
	}
	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}
	public String getCallMode() {
		return callMode;
	}
	public void setCallMode(String callMode) {
		this.callMode = callMode;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getFinishTime() {
		return finishTime;
	}
	public void setFinishTime(String finishTime) {
		this.finishTime = finishTime;
	}
	public String getCreditType() {
		return creditType;
	}
	public void setCreditType(String creditType) {
		this.creditType = creditType;
	}
	/**
	 * @return the vipMonitorFlag
	 */
	public String getVipMonitorFlag() {
		return vipMonitorFlag;
	}
	/**
	 * @param vipMonitorFlag the vipMonitorFlag to set
	 */
	public void setVipMonitorFlag(String vipMonitorFlag) {
		this.vipMonitorFlag = vipMonitorFlag;
	}
	/**
	 * @return the purchaseType
	 */
	public String getPurchaseType() {
		return purchaseType;
	}
	/**
	 * @param purchaseType the purchaseType to set
	 */
	public void setPurchaseType(String purchaseType) {
		this.purchaseType = purchaseType;
	}

	public String getUserPin() {
		return userPin;
	}

	public void setUserPin(String userPin) {
		this.userPin = userPin;
	}
}
