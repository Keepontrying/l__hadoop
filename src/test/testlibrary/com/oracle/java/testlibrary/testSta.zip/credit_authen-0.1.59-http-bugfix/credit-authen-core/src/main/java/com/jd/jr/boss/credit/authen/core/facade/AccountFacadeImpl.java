package com.jd.jr.boss.credit.authen.core.facade;

import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.jd.jr.boss.credit.authen.core.biz.AccountManageBiz;
import com.jd.jr.boss.credit.facade.site.api.CreditAccountFacade;
import com.jd.jr.boss.credit.facade.site.api.dto.request.account.AccountChargeRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.account.AccountPackageRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.account.AccountQueryRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.account.AccountDetailsResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.account.AccountQueryResponse;
import com.jd.jr.boss.credit.facade.site.api.enums.response.AccountManageResponseEnum;
import com.jd.jr.boss.credit.facade.site.api.enums.response.ContractManageResponseEnum;
import com.wangyin.commons.util.Logger;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.Response;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;

/**
 *  企业站充值反馈和余额查询接口
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
@Service
public class AccountFacadeImpl implements CreditAccountFacade{
	 private Logger logger = new Logger(AccountFacadeImpl.class);
	 @Autowired
	 private AccountManageBiz accountManageBiz;
	@Override
	public Response charge(
			RequestParam<AccountChargeRequest> accountChargeRequest) {
		logger.info("charge 充值信息参数：", GsonUtil.getInstance().toJson(accountChargeRequest.getParam()));
		long startTime = System.currentTimeMillis();
		Response response = new Response();
		//验证参数
		try {	
			if (accountChargeRequest == null || accountChargeRequest.getParam() == null) {
				logger.error(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
				response.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				return response;
			}
			if (!StringUtils.hasText(accountChargeRequest.getParam().getMerchantNo())) {
				//判定商户号
				logger.error(ContractManageResponseEnum.PARAM_MERCHANTNO_REQUIRED.toDescription());
				response.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				response.setCode(ContractManageResponseEnum.PARAM_MERCHANTNO_REQUIRED.toName());
				response.setMessage(ContractManageResponseEnum.PARAM_MERCHANTNO_REQUIRED.toDescription());
				return response;
			}
			/*if (!StringUtils.hasText(accountChargeRequest.getParam().getMerchantCode())) {
				//判定账户代码
				logger.error(ContractManageResponseEnum.PARAM_MERCHANTCODE_REQUIRED.toDescription());
				response.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				response.setCode(ContractManageResponseEnum.PARAM_MERCHANTCODE_REQUIRED.toName());
				response.setMessage(ContractManageResponseEnum.PARAM_MERCHANTCODE_REQUIRED.toDescription());
				return response;
			}*/
			if (!StringUtils.hasText(accountChargeRequest.getParam().getTradeNo())) {
				//判定流水号
				logger.error(AccountManageResponseEnum.PARAM_TRADENO_REQUIRED.toDescription());
				response.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				response.setCode(AccountManageResponseEnum.PARAM_TRADENO_REQUIRED.toName());
				response.setMessage(AccountManageResponseEnum.PARAM_TRADENO_REQUIRED.toDescription());
				return response;
			}
			if (!NumberUtils.isNumber(String.valueOf(accountChargeRequest.getParam().getMoney()))) {
				//判定充值金额
				logger.error(AccountManageResponseEnum.PARAM_MONEY_ISNUMBER.toDescription());
				response.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				response.setCode(AccountManageResponseEnum.PARAM_MONEY_ISNUMBER.toName());
				response.setMessage(AccountManageResponseEnum.PARAM_MONEY_ISNUMBER.toDescription());
				return response;
			}
			//同步充值金额到清结算
			accountManageBiz.updateAccountBalance(accountChargeRequest.getParam(),response);
//			if (!response.isSuccess()) {
//				response.setMessage(ResponseMessage.NOT_EXIST.getDesc());
//			}
		} catch (Exception e) {
			logger.error(e);
			response.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
		}
		logger.info("charge 充值信息结果：",(System.currentTimeMillis()-startTime)+" ms;"+GsonUtil.getInstance().toJson(response));
		return response;
	}

	@Override
	public ResponseData<AccountQueryResponse> balance(
			RequestParam<AccountQueryRequest> accountQueryRequest) {
		logger.info("balance 余额/余量查询参数：", GsonUtil.getInstance().toJson(accountQueryRequest.getParam()));
		long startTime = System.currentTimeMillis();
		ResponseData<AccountQueryResponse> responseData = new ResponseData<AccountQueryResponse>();
		//验证参数
		try {	
			if (accountQueryRequest == null || accountQueryRequest.getParam() == null) {
				logger.error(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
				responseData.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				return responseData;
			}
			if (!StringUtils.hasText(accountQueryRequest.getParam().getMerchantNo())) {
				//判定商户号
				logger.error(ContractManageResponseEnum.PARAM_MERCHANTNO_REQUIRED.toDescription());
				responseData.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				responseData.setCode(ContractManageResponseEnum.PARAM_MERCHANTNO_REQUIRED.toName());
				responseData.setMessage(ContractManageResponseEnum.PARAM_MERCHANTNO_REQUIRED.toDescription());
				return responseData;
			}
			/*if (!StringUtils.hasText(accountQueryRequest.getParam().getMerchantCode())) {
				//判定账户代码
				logger.error(ContractManageResponseEnum.PARAM_MERCHANTCODE_REQUIRED.toDescription());
				responseData.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				responseData.setCode(ContractManageResponseEnum.PARAM_MERCHANTCODE_REQUIRED.toName());
				responseData.setMessage(ContractManageResponseEnum.PARAM_MERCHANTCODE_REQUIRED.toDescription());
				return responseData;
			}*/
			//查询账户余额
			accountManageBiz.queryBalance(accountQueryRequest.getParam(),responseData);
//			if (!responseData.isSuccess()) {
//				responseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
//			}
		} catch (Exception e) {
			logger.error(e);
			responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
		}
		logger.info("balance 余额/余量查询结果：",(System.currentTimeMillis()-startTime)+" ms;"+GsonUtil.getInstance().toJson(responseData));
		return responseData;
	}

	@Override
	public Page<AccountDetailsResponse> details(
			RequestParam<AccountPackageRequest> requestParam) {
		logger.info("details 查询包量余额详情参数：", GsonUtil.getInstance().toJson(requestParam.getParam()));
		long startTime = System.currentTimeMillis();
		//验证参数
		Page<AccountDetailsResponse> page=new Page<AccountDetailsResponse>();
		try {	
			if (requestParam == null || requestParam.getParam() == null) {
				logger.error(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
				page.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				return page;
			}
			if (!StringUtils.hasText(requestParam.getParam().getMerchantNo())) {
				//判定商户号
				logger.error(ContractManageResponseEnum.PARAM_MERCHANTNO_REQUIRED.toDescription());
				page.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				page.setCode(ContractManageResponseEnum.PARAM_MERCHANTNO_REQUIRED.toName());
				page.setMessage(ContractManageResponseEnum.PARAM_MERCHANTNO_REQUIRED.toDescription());
				return page;
			}
			if (!NumberUtils.isNumber(String.valueOf(requestParam.getParam().getProductId()))) { 
				//判定产品ID 
				logger.error(ContractManageResponseEnum.PARAM_MERCHANTCODE_REQUIRED.toDescription());
				page.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				page.setCode(AccountManageResponseEnum.PARAM_PRODUCT_REQUIRED.toName());
				page.setMessage(AccountManageResponseEnum.PARAM_PRODUCT_REQUIRED.toDescription());
				return page;
			}
			//查询合同列表
			accountManageBiz.queryPackagePage(requestParam.getParam(),page);
//			if (!page.isSuccess()) {
//				page.setMessage(ResponseMessage.NOT_EXIST.getDesc());
//			}
		} catch (Exception e) {
			logger.error(e);
			page.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
		}
		logger.info("details 查询包量余额详情：",(System.currentTimeMillis()-startTime)+" ms;"+GsonUtil.getInstance().toJson(page));
		return page;
	}
}
