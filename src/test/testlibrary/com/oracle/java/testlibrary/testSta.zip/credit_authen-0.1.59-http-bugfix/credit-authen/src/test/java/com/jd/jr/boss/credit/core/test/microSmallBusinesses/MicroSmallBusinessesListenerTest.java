package com.jd.jr.boss.credit.core.test.microSmallBusinesses;

import com.jd.jmq.common.message.Message;
import com.jd.jr.boss.credit.authen.core.jms.microSmallBusinesses.MicroSmallBusinessesListener;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2018/3/28
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath*:spring/spring-authen.xml"})
public class MicroSmallBusinessesListenerTest extends AbstractJUnit4SpringContextTests {

    @Resource
    private MicroSmallBusinessesListener listener;

    @Test
    public void testMessage() throws Exception {
        String jsonStr = "{\"code\":\"\",\"result\":\"\",\"data\":{\"industry\":\"配电开关控制设备制造\",\"tag\":\"01\",\"category\":\"制造业\",\"createDate\":\"1998年01月08日\",\"registerOffice\":\"阳泉市工商行政管理局城区分局\",\"companyName\":\"阳泉市恒源电力电子有限公司\",\"supportInfo\":[{\"supportMoney\":\"2258.16元\",\"supportDate\":\"2025年08月25日\",\"supportContent\":\"减免企业所得税\",\"supportBasis\":\"财政部国家税务总局关于小型微利企业所得税优惠政策的通知\",\"supportDepartment\":\"阳泉市地方税务局直属五分局\"},{\"supportMoney\":\"551.15元\",\"supportDate\":\"2016年05月10日\",\"supportContent\":\"减免企业所得税\",\"supportBasis\":\"财政部国家税务总局关于小型微利企业所得税优惠政策的通知\",\"supportDepartment\":\"阳泉市地方税务局直属五分局\"},{\"supportMoney\":\"1179.33元\",\"supportDate\":\"2018年01月10日\",\"supportContent\":\"减免企业所得税\",\"supportBasis\":\"财政部国家税务总局关于小型微利企业所得税优惠政策的通知\",\"supportDepartment\":\"阳泉市地方税务局直属五分局\"}],\"companyType\":\"有限责任公司(国有独资)\",\"creditCode\":\"91140302701070167L\",\"registerCapital\":\"61.4万元\"},\"mag\":\"\"}";

        List<Message> messages = new ArrayList<Message>();
        Message message = new Message();
        message.setText(jsonStr);
        messages.add(message);
//        listener.onMessage(messages);

    }

}
