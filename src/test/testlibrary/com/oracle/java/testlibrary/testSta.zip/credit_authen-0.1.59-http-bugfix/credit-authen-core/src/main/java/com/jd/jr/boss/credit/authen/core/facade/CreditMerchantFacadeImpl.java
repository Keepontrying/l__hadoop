package com.jd.jr.boss.credit.authen.core.facade;

import com.jd.jr.boss.credit.authen.core.service.MerchantService;
import com.jd.jr.boss.credit.authen.core.service.impl.CreditUserServiceImpl;
import com.jd.jr.boss.credit.facade.authen.api.CreditMerchantFacade;
import com.jd.jr.boss.credit.facade.authen.beans.response.CreditMerchantEntity;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditVip;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.rediscluster.client.CacheClusterClient;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


/**
 * @author jiangbo
 * @since 2017/3/29
 */
@Service("creditMerchantFacade")
public class CreditMerchantFacadeImpl implements CreditMerchantFacade {

    private static Logger logger = LoggerFactory.getLogger(CreditUserServiceImpl.class);

    private static final String CACHE_KEY_PREFIX = "AUTHEN_";

    @Autowired
    private MerchantService merchantService;

    @Resource
    private CacheClusterClient cacheClusterClient;

    @Override
    public CreditResponseData<Integer> insert(CreditRequestParam<CreditMerchant> requestParam) {
        CreditMerchant creditMerchant = requestParam.getParam();
        CreditResponseData<Integer> creditResponseData = new CreditResponseData<Integer>();

        if (requestParam == null || requestParam.getParam() == null) {
            creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
            creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(0);
            logger.error("insert error, requestParam is null");
            return creditResponseData;
        }

        try {

            int result = merchantService.insertSelective(creditMerchant);
            if (result > 0) {
                logger.info("CreditMerchantFacade insertSelective success, creditMerchant:{}", ReflectionToStringBuilder.toString(creditMerchant));
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(result);
                return creditResponseData;
            } else {
                logger.info("CreditMerchantFacade creditUserService insertSelective error, ReflectionToStringBuilder.toString(creditMerchant):{}", ReflectionToStringBuilder.toString(creditMerchant));
                creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
                creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
                creditResponseData.setSuccess(false);
                creditResponseData.setData(0);
                return creditResponseData;
            }

        } catch (Exception e) {
            logger.error("CreditMerchantFacade insert error, creditMerchant:{}", ReflectionToStringBuilder.toString(creditMerchant), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(0);
            return creditResponseData;
        }
    }

    /**
     * 根据商户ID查询商户vip信息
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<CreditVip> queryMerchantVip(CreditRequestParam<Integer> requestParam) {
        Integer merchantId = requestParam.getParam();
        CreditResponseData<CreditVip> creditResponseData = new CreditResponseData<CreditVip>();
        if (requestParam == null || requestParam.getParam() == null) {
            creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
            creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
            creditResponseData.setSuccess(false);
            logger.error("query error, requestParam is null");
            return creditResponseData;
        }
        try {
            CreditVip vipDO = merchantService.queryMerchantVipInfo(merchantId);
            creditResponseData.setData(vipDO);
            creditResponseData.setResponseMessage(ResponseMessage.SUCCESS);
            return creditResponseData;
        } catch (Exception e) {
            logger.error("CreditMerchantFacade query vip error, merchant id:{}", merchantId, e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
            return creditResponseData;
        }

    }

    @Override
    public CreditResponseData<String> queryMerchantInfoByUserPin(CreditRequestParam<String> requestParam) {
        String userPin = requestParam.getSystemId();
        CreditResponseData<String> creditResponseData = new CreditResponseData<String>();
        if (requestParam == null || StringUtils.isBlank(userPin)) {
            creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
            creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
            creditResponseData.setSuccess(false);
            return creditResponseData;
        }
        try {
            CreditMerchantEntity merchantEntity = merchantService.queryMerchantInfoByUserPin(userPin);

            if(merchantEntity ==  null){
                creditResponseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
                creditResponseData.setCode(ResponseMessage.NOT_EXIST.name());
                creditResponseData.setSuccess(false);
                return creditResponseData;
            }

            String R2M_KEY = StringUtils.isBlank(merchantEntity.getUserPin()) ? "" : merchantEntity.getUserPin();

            String GLOBAL_KEY = cacheClusterClient.get(CACHE_KEY_PREFIX);

            if (StringUtils.isBlank(GLOBAL_KEY)) {
                cacheClusterClient.set("GLOBAL_ES_KEY", CACHE_KEY_PREFIX);
                cacheClusterClient.expire(CACHE_KEY_PREFIX, ConfigUtil.getInt("ent.data.global.expired"));
            }

            cacheClusterClient.set(CACHE_KEY_PREFIX + R2M_KEY, R2M_KEY);
            cacheClusterClient.expire(CACHE_KEY_PREFIX, ConfigUtil.getInt("ent.data.expired"));

            creditResponseData.setData(merchantEntity.getUserPin());
            creditResponseData.setResponseMessage(ResponseMessage.SUCCESS);
            return creditResponseData;
        } catch (Exception e) {
            logger.error("CreditMerchantFacade query userPin error,  userPin:{}", userPin, e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
            return creditResponseData;
        }
    }

}
