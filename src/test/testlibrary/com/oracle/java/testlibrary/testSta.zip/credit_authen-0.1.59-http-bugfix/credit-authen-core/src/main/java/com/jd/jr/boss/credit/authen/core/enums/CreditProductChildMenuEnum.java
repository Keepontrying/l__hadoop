package com.jd.jr.boss.credit.authen.core.enums;

import java.util.LinkedHashMap;
import java.util.Map;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.EnterpriseProductEnum;

/**
 * @author jiangbo
 * @since 20170906
 */
public enum CreditProductChildMenuEnum {
    NULL(-1, null, null, null),
    ENT_ALTER_RECORD(0, "ENT_ALTER_RECORD", "历史沿革", EnterpriseProductEnum.ENTERPRISE_BASIC_QUERY.toName()),
    ENT_SHARE_HOLDER(1, "ENT_SHARE_HOLDER", "股东信息", EnterpriseProductEnum.ENTERPRISE_BASIC_QUERY.toName()),
    ENT_MAIN_STAFF(2, "ENT_MAIN_STAFF", "主要人员", EnterpriseProductEnum.ENTERPRISE_BASIC_QUERY.toName()),
    ENT_BRANCH_RECORD(3, "ENT_BRANCH_RECORD", "分支机构", EnterpriseProductEnum.ENTERPRISE_BASIC_QUERY.toName()),
    ENT_PUNISHMENT(4, "ENT_PUNISHMENT", "行政处罚", EnterpriseProductEnum.ENTERPRISE_PUNISHMENT_QUERY.toName()),
    ENT_ABNORMAL(5, "ENT_ABNORMAL", "经营异常名录", EnterpriseProductEnum.ENTERPRISE_ABNORMAL_QUERY.toName()),
    ENT_PATENT(6, "ENT_PATENT", "专利信息", EnterpriseProductEnum.ENTERPRISE_PATENT_QUERY.toName()),
    ENT_TMINFO(7, "ENT_TMINFO", "商标信息", EnterpriseProductEnum.ENTERPRISE_TMINFO_QUERY.toName()),
    ;

    private Integer code;
    private String name;
    private String description;
    private String parentCode;

    /**
     * @param description 中文描述
     */
    CreditProductChildMenuEnum(String description) {
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param description 中文描述
     */
    CreditProductChildMenuEnum(Integer code, String description) {
        this.code = code;
        this.description = description;
    }

    /**
     * @param name        英文编码名称
     * @param description 中文描述
     */
    CreditProductChildMenuEnum(String name, String description) {
        this.name = name;
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param name        英文编码名称
     * @param description 中文描述
     */
    CreditProductChildMenuEnum(Integer code, String name, String description, String parentCode) {
        this.code = code;
        this.name = name;
        this.description = description;
        this.parentCode = parentCode;
    }


    /**
     * 获取枚举类型数值编码
     */
    public Integer toCode() {
        return this.code == null ? this.ordinal() : this.code;
    }

    /**
     * 获取枚举类型英文编码名称
     */
    public String toName() {
        return this.name == null ? this.name() : this.name;
    }

    /**
     * 获取枚举类型中文描述
     */
    public String toDescription() {
        return this.description;
    }

     /**
      *  获取枚举类型父code,即真实的产品code
     */
    public String toParentCode() {
        return this.parentCode;
    }
    /**
     * 获取枚举类型中文描述
     */
    public String toString() {
        return this.description;
    }



    /**
     * 按数值获取对应的枚举类型
     *
     * @param code 数值
     * @return 枚举类型
     */
    public static CreditProductChildMenuEnum enumValueOf(Integer code) {
        CreditProductChildMenuEnum[] values = CreditProductChildMenuEnum.values();
        CreditProductChildMenuEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (code != null && code.equals(values[i].toCode())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 按英文编码获取对应的枚举类型
     *
     * @param name 英文编码
     * @return 枚举类型
     */
    public static CreditProductChildMenuEnum enumValueOf(String name) {
        CreditProductChildMenuEnum[] values = CreditProductChildMenuEnum.values();
        CreditProductChildMenuEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (name != null && name.equalsIgnoreCase(values[i].toName())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 获取枚举类型的所有<数字编码,中文描述>对
     *
     * @return
     */
    public static Map<Integer, String> toCodeDescriptionMap() {
        LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
        for (int i = 0; i < CreditProductChildMenuEnum.values().length; i++) {
            if (CreditProductChildMenuEnum.values()[i] != NULL) {
                map.put(CreditProductChildMenuEnum.values()[i].toCode(), CreditProductChildMenuEnum.values()[i].toDescription());
            }
        }
        return map;
    }

    /**
     * 获取枚举类型的所有<英文编码名称,中文描述>对
     *
     * @return
     */
    public static Map<String, String> toNameDescriptionMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        for (int i = 0; i < CreditProductChildMenuEnum.values().length; i++) {
            if (CreditProductChildMenuEnum.values()[i] != NULL) {
                map.put(CreditProductChildMenuEnum.values()[i].toName(), CreditProductChildMenuEnum.values()[i].toDescription());
            }
        }
        return map;
    }
}
