package com.jd.jr.boss.credit.authen.core.facade.trade;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jd.jr.boss.credit.facade.authen.beans.param.mini.*;
import com.wangyin.commons.util.StringUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.authen.core.constants.MiniConstant;
import com.jd.jr.boss.credit.authen.core.constants.SystemConstants;
import com.jd.jr.boss.credit.authen.core.dao.CreditMiniSampleBaseDao;
import com.jd.jr.boss.credit.authen.core.service.CreditDiligenceService;
import com.jd.jr.boss.credit.authen.core.service.CreditMiniService;
import com.jd.jr.boss.credit.authen.core.task.CreditAsyncExcuteCommonService;
import com.jd.jr.boss.credit.domain.common.enums.CreditMiniSampleProgressEnum;
import com.jd.jr.boss.credit.facade.authen.api.CreditDiligenceFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.MiniProjectQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.MiniSampleQueryParam;
import com.jd.jr.boss.credit.facade.channel.enterprise.api.DueInfoManageFacade;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.response.ResultDataEnum;
import com.jd.jr.boss.credit.gateway.unc.constance.GatewayUncConstance;
import com.jd.jr.boss.credit.gateway.unc.facade.email.GatewayUncEmailFacade;
import com.jd.jr.boss.credit.gateway.unc.utils.FlowNoUtils;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniProject;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniSampleBase;
import com.wangyin.boss.credit.admin.enums.CreditProjectProgressEnum;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;

/**
 * @author mini带回调
 * @since 2017/3/29
 */
@Service("creditDiligenceFacade")
public class CreditDiligenceFacadeImpl implements CreditDiligenceFacade {
    private static Logger logger = LoggerFactory.getLogger(CreditDiligenceFacadeImpl.class);

    @Autowired
    CreditDiligenceService creditDiligenceService;
    @Autowired
    DueInfoManageFacade dueInfoManageFacade;
    @Autowired
	private CreditMiniService miniService;
    @Autowired
    private CreditMiniSampleBaseDao miniSampleBaseDao;
    @Autowired
    private GatewayUncEmailFacade gatewayUncEmailFacade;
    @Autowired
    private CreditAsyncExcuteCommonService asyncExcuteCommonService;


    @Override
    public CreditResponseData<String> doSimple(CreditRequestParam<List<DueStatusParam>> requestParam) {
        logger.info("回调simple接口入参"+ GsonUtil.getInstance().toJson(requestParam));
        CreditResponseData<String> responseData =new CreditResponseData<String>();
        List<DueStatusParam> params=requestParam.getParam();
        for(DueStatusParam dueStatusParam:params){
            CreditMiniSampleBase sampleBase=new CreditMiniSampleBase();
            sampleBase.setSampleNo(dueStatusParam.getSampleId());
            //通过sampleNo 获取项目
            CreditMiniProject project = miniService.queryMiniProjectBySampleNo(dueStatusParam.getSampleId());
            if(project==null){
                logger.error("样本查询不到对应的项目");
                responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
                return responseData;
            }
            project.setModifiedDate(new Date());
            List<CreditMiniSampleBase> miniSampleBaseList =new ArrayList<CreditMiniSampleBase>();
            String projectNo ="";
            try {
            	if(StringUtils.isBlank(dueStatusParam.getSampleId())){
                    logger.error("saveSampleDetailsFromShuzhe:sampleid is null",dueStatusParam.getSampleId());
                    responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
                    return responseData;
                }
                MiniSampleQueryParam queryParam4QrySample = new MiniSampleQueryParam();
                queryParam4QrySample.setSampleNo(dueStatusParam.getSampleId());
                miniSampleBaseList = miniSampleBaseDao.queryMiniSampleByPrm(queryParam4QrySample);
                if(CollectionUtils.isEmpty(miniSampleBaseList)){
                    logger.info("[saveSampleDetailsFromShuzhe-miniSampleBaseDao.queryMiniSampleByPrm] responseData is null, query result:" + GsonUtil.getInstance().toJson(miniSampleBaseList));
                    responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
                    return responseData;
                }
                projectNo = miniSampleBaseList.get(0).getProjectNo();
                if(StringUtils.isBlank(projectNo)){
                    logger.error("saveSampleDetailsFromShuzhe:projectNo is null",projectNo);
                    responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
                    return responseData;
                }
			} catch (Exception e) {
				logger.error("[saveSampleDetailsFromShuzhe-miniSampleBaseDao.queryMiniSampleByPrm] failed, ", e);
			}
            
            if("START".equals(dueStatusParam.getStatus())){
                sampleBase.setSampleProgress(CreditMiniSampleProgressEnum.VISITING.toCode()+"");
                sampleBase.setDistributeDate(new Date());
                if(!miniSampleBaseList.get(0).getSampleProgress().equals(CreditMiniSampleProgressEnum.VISITING.toCode()+"")){//多次回调时避免重复计算
                	project.setSampleOngoingCount(project.getSampleOngoingCount()==null?1:project.getSampleOngoingCount()+1);
                    if(miniSampleBaseList.get(0).getSampleProgress().equals(CreditMiniSampleProgressEnum.SAMPLE_FINISH.toCode()+"")){//多次回调时避免重复计算
                        int sampleFinish = project.getSampleFinishCount()==null?0:project.getSampleFinishCount();
                        project.setSampleFinishCount(sampleFinish>=1?sampleFinish-1:0);
                    }
                    miniService.updateProject(project);
                }

            }else if("FINISH".equals(dueStatusParam.getStatus())){
                sampleBase.setSampleProgress(CreditMiniSampleProgressEnum.SAMPLE_FINISH.toCode()+"");
                sampleBase.setModifier(StringUtils.isBlank(dueStatusParam.getOperator()) ? SystemConstants.PARAM_INPUT_OPERATOR : dueStatusParam.getOperator());
                try {
                	if(!miniSampleBaseList.get(0).getSampleProgress().equals(CreditMiniSampleProgressEnum.SAMPLE_FINISH.toCode()+"")){//多次回调时避免重复计算
                		project.setSampleFinishCount(project.getSampleFinishCount()==null?1:project.getSampleFinishCount()+1);
                        project.setSampleOngoingCount(project.getSampleOngoingCount()==null?0:((project.getSampleOngoingCount()-1)<0?0:(project.getSampleOngoingCount()-1)));
                        miniService.updateProject(project);
                    }
//                	this.saveSampleDetailsFromShuzhe(dueStatusParam.getSampleId(), projectNo, miniSampleBaseList, project);
                	asyncExcuteCommonService.saveSampleDetailsFromShuzheExcute(dueStatusParam.getSampleId(), projectNo, miniSampleBaseList, project);
                }catch (Exception e){
                    logger.error("样本详情异常",e);
                }
            }else if("CANCEL".equals(dueStatusParam.getStatus())){
                sampleBase.setSampleProgress(CreditMiniSampleProgressEnum.SAMPLE_POUSE.toCode()+"");
                if(miniSampleBaseList.get(0).getSampleProgress().equals(CreditMiniSampleProgressEnum.SAMPLE_FINISH.toCode()+"")){//多次回调时避免重复计算
                    int sampleFinish = project.getSampleFinishCount()==null?0:project.getSampleFinishCount();
                    project.setSampleFinishCount(sampleFinish>=1?sampleFinish-1:0);
                    miniService.updateProject(project);
                }
            }
            try{
                Integer res = creditDiligenceService.doSimple(sampleBase);
            }catch (Exception e){
                logger.error("CreditDiligenceFacade doSimple error, ", e);
                responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            }
        }
        return responseData;
    }

    @Override
    public CreditResponseData<String> doProject(CreditRequestParam<DueStatusParam> requestParam) {
        CreditResponseData<String> responseData = new CreditResponseData<String>();
        try{
        	logger.info("CreditDiligenceFacade doSimple request, " + GsonUtil.getInstance().toJson(requestParam));
            DueStatusParam param=requestParam.getParam();
            CreditMiniProject project = new CreditMiniProject();
            project.setProjectNo(param.getProjectId());
            project.setRemark(param.getRemark());
            if("1".equals(param.getCheckState())){
                project.setProjectProgress(CreditProjectProgressEnum.CHECK_SUCESS.toName());
            }else if("2".equals(param.getCheckState())){
                project.setProjectProgress(CreditProjectProgressEnum.CHECK_FAIL.toName());
                MiniProjectQueryParam projectQueryParam = new MiniProjectQueryParam();
                projectQueryParam.setProjectNo(project.getProjectNo());
                CreditPage<CreditMiniProject> projectPage = miniService.queryMiniProject(projectQueryParam);
                if(null != projectPage && null != projectPage.getRows() 
                		&& projectPage.getRows().size() >0 && null != projectPage.getRows().get(0) ){
                	this.sendWarningEmail4ProjectNopass(projectPage);
                }else{
                	responseData.setSuccess(false);
                	responseData.setCode(ResultDataEnum.RESULT_SYSTEM_EXCEPTION.toName());
                	responseData.setMessage("未查得项目信息");
                	return responseData;
                }
            }
            Integer res = creditDiligenceService.doProject(project);
        }catch (Exception e){
        	logger.error("CreditDiligenceFacade doSimple error, ", e);
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        return responseData;
    }
    /**
     * Mini尽调的项目审核不通过时给石明杰发送通知邮件
     * @param projectPage
     * @throws Exception
     */
	private void sendWarningEmail4ProjectNopass(CreditPage<CreditMiniProject> projectPage) {
		try {
			Map<String, Object> uncParamsMap = new HashMap<String, Object>();
			String receiver = ConfigUtil.getString(MiniConstant.UNC_CLIENT_MINI_RECEIVER);
			String emailObject = MiniConstant.UNC_CLIENT_MINI_PROJECT_SUNJECT;
			String bizNo = FlowNoUtils.createFlowNo("MINI");
			String templateCode = ConfigUtil.getString(MiniConstant.UNC_CLIENT_MINI_PROJECT_TEMPLATECODE);
			String appCode = ConfigUtil.getString(GatewayUncConstance.UNC_CLIENT_APPCODE);
			uncParamsMap.put("merchantNo", projectPage.getRows().get(0).getMerchantNo());
			uncParamsMap.put("projectName", projectPage.getRows().get(0).getProjectName());
			uncParamsMap.put("remark", projectPage.getRows().get(0).getRemark());
			boolean sendMailResult = gatewayUncEmailFacade.sendMailByUnc(receiver, emailObject, bizNo, uncParamsMap, templateCode, appCode);
			if(!sendMailResult){
				logger.info("[doProject-gatewayUncEmailFacade.sendMailByUnc]：send email failed, projectName:"+ projectPage.getRows().get(0).getProjectName());
			}
		} catch (Exception e) {
			logger.error("[doProject-gatewayUncEmailFacade.sendMailByUnc]：send email error, projectName:"+ projectPage.getRows().get(0).getProjectName());
		}
	}

	@Override
	public CreditResponseData<String> doAreaSync(CreditRequestParam<List<DueAreaSyncEntity>> requestParam) {
		logger.info("due doAreaSync requestPrm:", GsonUtil.getInstance().toJson(requestParam));
        CreditResponseData<String> responseData = new CreditResponseData<String>();
            try{
            	Integer resultId = miniService.addOrUpdateSyncArea(requestParam.getParam());
            }catch (Exception e){
                logger.error("CreditDiligenceFacade doAreaSync failed, ", e);
                e.printStackTrace();
                responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            }
        return responseData;
	}
	
    /**
     * 异步查询样本明细并落库
     * @throws Exception
     */
//	@Deprecated
//    private void saveSampleDetailsFromShuzhe(final String sampleId, final String projectNo,
//    		final List<CreditMiniSampleBase> miniSampleBaseList, final CreditMiniProject project) throws Exception{
//        new Thread() {
//            @Override
//            public void run() {
//            	try {
//            		CreditRequestParam<EntDueSimpleExamineReq> requestParam = new CreditRequestParam<EntDueSimpleExamineReq>();
//                    requestParam.setOperator("SYSTEM");
//                    requestParam.setSystemId("ENTCAE");
//                    requestParam.setTradeNo(SerialNoUtil.createSerialNo("SAMEXA"));
//            		EntDueSimpleExamineReq examineReq = new EntDueSimpleExamineReq();
//            		List<EntDueSimpleExamineBean> simples = new ArrayList<EntDueSimpleExamineBean>();
//
//                    EntDueSimpleExamineBean examineBean = new EntDueSimpleExamineBean();
//                    examineBean.setSampleId(sampleId.trim());
//                    examineBean.setCheckState(DueExamineEnum.PASS);
//                    simples.add(examineBean);
//            		examineReq.setSimples(simples);
//                    examineReq.setProjectId(projectNo);
//            		requestParam.setParam(examineReq);
//            		CreditResponseData<EntDueSimpleExamineResp> examineResponseData = dueInfoManageFacade.examine(requestParam);
//            		logger.info("[saveSampleDetailsFromShuzhe-dueInfoManageFacade.examine] responseData, " + GsonUtil.getInstance().toJson(examineResponseData));
//				} catch (Exception e) {
//					logger.error("[saveSampleDetailsFromShuzhe dueInfoManageFacade.examine] failed, ", e);
//					e.printStackTrace();
//				}
//                List<String> simpleIds =new ArrayList<String>();
//            	simpleIds.add(sampleId);
//                try {
//                	CreditRequestParam<EntDueSimpleDetailsReq> detailsQryParam = new CreditRequestParam<EntDueSimpleDetailsReq>();
//                	detailsQryParam.setOperator("SYSTEM");
//                	detailsQryParam.setSystemId("ENTCAE");
//                	detailsQryParam.setTradeNo(SerialNoUtil.createSerialNo("SAMUP"));
//                	EntDueSimpleDetailsReq detailsReq = new EntDueSimpleDetailsReq();
//                	detailsReq.setSimpleIds(simpleIds);
//                    detailsReq.setProjectId(projectNo);
//                	detailsQryParam.setParam(detailsReq);
//                	CreditResponseData<EntDueSimpleDetailsResp> simpleDetailsResp = dueInfoManageFacade.details(detailsQryParam);
//                	logger.info("[saveSampleDetailsFromShuzhe-dueInfoManageFacade.details] responseData, " + GsonUtil.getInstance().toJson(simpleDetailsResp));
//                	if(simpleDetailsResp == null||!simpleDetailsResp.isSuccess() || simpleDetailsResp.getData() == null ){
//            			logger.info("[doSimple-saveSampleDetailsFromShuzhe-dueInfoManageFacade.details] is failed： "+GsonUtil.getInstance().toJson(simpleDetailsResp));
//            			return;
//            		}
//                        if(simpleDetailsResp.getData().getSamples() == null ){
//            			logger.info("[doSimple-saveSampleDetailsFromShuzhe-dueInfoManageFacade.details] is failed： "+GsonUtil.getInstance().toJson(simpleDetailsResp));
//            			return;
//            		}
//                	boolean resultFlag = true;
//                	for(EntDueSimpleDetailsBean simpleDetailsBean: simpleDetailsResp.getData().getSamples()){
//                		resultFlag = miniService.saveSampleDetailsFromShuzhe(simpleDetailsBean,miniSampleBaseList, project);
//                	}
//                	if(resultFlag == false){
//                		logger.info("[doSimple-saveSampleDetailsFromShuzhe-miniService.saveSampleDetailsFromShuzhe] partial failure ： "+GsonUtil.getInstance().toJson(simpleDetailsResp));
//                	}
//                } catch (Exception e) {
//                	logger.error("CreditDiligenceFacade saveSampleDetailsFromShuzhe failed, ", e);
//                }
//            }
//        }.start();
//    }

    @Override
    public CreditResponseData<String> doSimpleFinish(CreditRequestParam<SampleFinishEntity> requestParam) {
        logger.info("doSimpleFinish requestPrm:", GsonUtil.getInstance().toJson(requestParam));
        CreditResponseData<String> responseData = new CreditResponseData<String>();
        try{
            CreditMiniSampleBase base = new CreditMiniSampleBase();
            base.setSyncType("YES");
            base.setSyncDir(requestParam.getParam().getSftpDir());
            base.setSampleNo(requestParam.getParam().getSampleId());
            Integer res = miniSampleBaseDao.updateBySampleNo(base);
            
//            CreditRequestParam<List<DueStatusParam>> requestParam4Sync = new CreditRequestParam<List<DueStatusParam>>();
//        	List<DueStatusParam> dueStatusParamList4Sync = new ArrayList<DueStatusParam>();
//        	DueStatusParam DueStatus = new DueStatusParam();
//        	DueStatus.setSampleId(requestParam.getParam().getSampleId());
//        	DueStatus.setStatus("FINISH");
//        	dueStatusParamList4Sync.add(DueStatus);
//        	requestParam4Sync.setParam(dueStatusParamList4Sync);
//        	CreditResponseData<String> result = this.doSimple(requestParam4Sync);
//			logger.info("doSimpleFinish handle result , "+ GsonUtil.getInstance().toJson(result));
            
            asyncExcuteCommonService.saveSampleDetailsFromShuzheExcute4Sftp(requestParam.getParam().getSampleId(), requestParam.getParam().getSftpDir());
        }catch (Exception e){
            logger.error("\\ doSimpleFinish failed, ", e);
            e.printStackTrace();
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        return responseData;
    }

    @Override
    public CreditResponseData<PayMerchantCheckResponse> doPayMerchantCheck(CreditRequestParam<PayMerchantCheckDuplicateParam> requestParam) {
        logger.info("支付拓客商户去重接口入参 doPayMerchantCheck requestParam: " + GsonUtil.getInstance().toJson(requestParam));
        CreditResponseData<PayMerchantCheckResponse> responseData = new CreditResponseData<PayMerchantCheckResponse>();
        if(StringUtil.isBlank(requestParam.getParam().getStoreName()) || StringUtil.isBlank(requestParam.getParam().getStoreAddress())){
            responseData.setCode(ResultDataEnum.REQUEST_PARAM_REQUIRED.toName());
            responseData.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
            return responseData;
        }
        responseData = miniService.payMerchantCheck(requestParam.getParam());
        return responseData;
    }

    @Override
    public CreditResponseData<String> doPaySampleStatus(CreditRequestParam<DueStatusParam> requestParam) {
        logger.info("回调simple接口入参"+ GsonUtil.getInstance().toJson(requestParam));
        CreditResponseData<String> responseData =new CreditResponseData<String>();
        if(null != requestParam && null != requestParam.getParam() && "FINISH".equalsIgnoreCase(requestParam.getParam().getStatus())){
            // 异步调用详情接口，立即转换数据给支付返回结果后落库相关数据，异步上送图片给支付，异步处理图片至hsp并更新库
            responseData.setCode(ResultDataEnum.SUCCESS.toName());
            responseData.setResponseMessage(ResponseMessage.SUCCESS);
            miniService.details4PayMerchantExpand(requestParam.getParam());
        }else{
            responseData.setSuccess(false);
            responseData.setCode(ResultDataEnum.REQUEST_PARAM_REQUIRED.toName());
            responseData.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
        }
        return responseData;
    }

    @Override
    public CreditResponseData<PayMerchantCheckResponse> doPayMerchantFuzzySearch(CreditRequestParam<PayMerchantCheckDuplicateParam> requestParam) {
        logger.info("回调simple接口入参doPayMerchantFuzzySearch:"+ GsonUtil.getInstance().toJson(requestParam));
        CreditResponseData<PayMerchantCheckResponse> responseData = new CreditResponseData<PayMerchantCheckResponse>();
        if(null != requestParam && null != requestParam.getParam() && StringUtils.isNotBlank(requestParam.getParam().getStoreName())
                && StringUtils.isNotBlank(requestParam.getParam().getCountyCode())){
            responseData = miniService.doPayMerchantFuzzySearch(requestParam.getParam());
        }else{
            responseData.setSuccess(false);
            responseData.setCode(ResultDataEnum.REQUEST_PARAM_REQUIRED.toName());
            responseData.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
        }
        return responseData;
    }
}
