package com.jd.jr.boss.credit.authen.core.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 产品对应数据库中ID
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */

public enum EnterpriseProductEnum {

    NULL(-1, null, null),
    ENTERPRISE_BANK_VERIFY(1, "ENT_BANK_VERIFY", "银行卡四要素认证"),
    ENTERPRISE_IDENTITY_VERIFY(2, "ENT_IDENTITY_VERIFY", "身份证认证"),
    ENTERPRISE_DEGREE_QUERY(3, "ENT_DEGREE_QUERY", "学历认证"),
    ENTERPRISE_COLLEGE_VERIFY(4, "ENT_COLLEGE_VERIFY", "学籍认证"),
    ENTERPRISE_THREEBANK_VERIFY(5, "ENT_THREEBANK_VERIFY", "银行卡三要素认证"),
    ENTERPRISE_IDENTITYNOPIC_VERIFY(6, "ENT_IDENTITYNOPIC_VERIFY", "身份证无图认证"),
    ENTERPRISE_BASIC_QUERY(7, "ENT_BASIC_QUERY", "企业基本信息"),
    ENTERPRISE_ENTINV_QUERY(8, "ENT_ENTINV_QUERY", "企业对外投资信息"),
    ENTERPRISE_NEGATIVE_QUERY(9, "ENT_NEGATIVE_QUERY", "企业负面信息"),
    ENTERPRISE_PUNISHBREAK_QUERY(10, "ENT_PUNISHBREAK_QUERY", "企业失信被执行信息"),
    ENTERPRISE_PUNISHED_QUERY(11, "ENT_PUNISHED_QUERY", "被执行人信息"),
    ENTERPRISE_REPORT_QUERY_BASIC(12, "ENTERPRISE_REPORT_QUERY_BASIC", "企业信用报告信息"),
    ENTERPRISE_VERIFY(13, "ENT_VERIFY", "工商三要素验证"),
    ENTERPRISE_LAWSUITINFO_QUERY(14, "ENT_LAWSUITINFO_QUERY", "法院裁判信息"),
    ENTERPRISE_TMPATENTINFO_QUERY(15, "ENT_TMPATENTINFO_QUERY", "企业知识产权"),
    ENTERPRISE_BLACKLIST_QUERY(16, "ENT_BLACKLIST_QUERY", "企业黑名单"),
    ENTERPRISE_QUALIFY_VERIFY(17, "ENT_QUALIFYCHECK_QUERY", "企业资质认证"),
    ENTERPRISE_REGLICENSE_QUERY(18, "ENT_OCR_REG_BUSSLICENSE", "营业执照识别"),
    ENTERPRISE_REGIDCARD_QUERY(19, "ENT_OCR_REG_IDCARD", "身份证OCR识别"),
    ENTERPRISE_LOANINFO_QUERY(20, "ENT_LOANINFO_QUERY", "多头负债信息"),
    ENTERPRISE_PERSONNALBLACK_QUERY(21, "ENT_PERSONAL_BLACK", "个人黑名单"),
    ENTERPRISE_REGIDCARDVERIFY_QUERY(22, "ENT_OCR_REG_IDCARD_VERIFY", "身份证OCR认证")
    ;

    private Integer code;
    private String name;
    private String description;

    /**
     * @param description 中文描述
     */
    EnterpriseProductEnum(String description) {
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param description 中文描述
     */
    EnterpriseProductEnum(Integer code, String description) {
        this.code = code;
        this.description = description;
    }

    /**
     * @param name        英文编码名称
     * @param description 中文描述
     */
    EnterpriseProductEnum(String name, String description) {
        this.name = name;
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param name        英文编码名称
     * @param description 中文描述
     */
    EnterpriseProductEnum(Integer code, String name, String description) {
        this.code = code;
        this.name = name;
        this.description = description;
    }


    /**
     * 获取枚举类型数值编码
     */
    public Integer toCode() {
        return this.code == null ? this.ordinal() : this.code;
    }

    /**
     * 获取枚举类型英文编码名称
     */
    public String toName() {
        return this.name == null ? this.name() : this.name;
    }

    /**
     * 获取枚举类型中文描述
     */
    public String toDescription() {
        return this.description;
    }

    /**
     * 获取枚举类型中文描述
     */
    public String toString() {
        return this.description;
    }

    /**
     * 按数值获取对应的枚举类型
     *
     * @param code 数值
     * @return 枚举类型
     */
    public static EnterpriseProductEnum enumValueOf(Integer code) {
        EnterpriseProductEnum[] values = EnterpriseProductEnum.values();
        EnterpriseProductEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (code != null && code.equals(values[i].toCode())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 按英文编码获取对应的枚举类型
     *
     * @param name 英文编码
     * @return 枚举类型
     */
    public static EnterpriseProductEnum enumValueOf(String name) {
        EnterpriseProductEnum[] values = EnterpriseProductEnum.values();
        EnterpriseProductEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (name != null && name.equalsIgnoreCase(values[i].toName())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 获取枚举类型的所有<数字编码,中文描述>对
     *
     * @return
     */
    public static Map<Integer, String> toCodeDescriptionMap() {
        LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
        for (int i = 0; i < EnterpriseProductEnum.values().length; i++) {
            if (EnterpriseProductEnum.values()[i] != NULL) {
                map.put(EnterpriseProductEnum.values()[i].toCode(), EnterpriseProductEnum.values()[i].toDescription());
            }
        }
        return map;
    }

    /**
     * 获取枚举类型的所有<英文编码名称,中文描述>对
     *
     * @return
     */
    public static Map<String, String> toNameDescriptionMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        for (int i = 0; i < EnterpriseProductEnum.values().length; i++) {
            if (EnterpriseProductEnum.values()[i] != NULL) {
                map.put(EnterpriseProductEnum.values()[i].toName(), EnterpriseProductEnum.values()[i].toDescription());
            }
        }
        return map;
    }

}
