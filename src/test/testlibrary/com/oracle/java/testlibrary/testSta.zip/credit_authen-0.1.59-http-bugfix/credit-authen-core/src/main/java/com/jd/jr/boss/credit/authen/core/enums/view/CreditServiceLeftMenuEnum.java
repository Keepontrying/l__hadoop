package com.jd.jr.boss.credit.authen.core.enums.view;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by anmeng on 2017/6/3.
 */
public enum CreditServiceLeftMenuEnum {
    NULL(-1, null, null),
    ENT_NEGATIVE_QUERY(0, "ENT_NEGATIVE_QUERY", "企业经营风险"),
    ENT_ANNUAL_REPORT(1, "ENT_ANNUAL_REPORT", "企业经营状况"),
    ENT_JUDICIAL_LITIGATION(2, "ENT_JUDICIAL_LITIGATION", "企业司法风险"),
    ENT_INTELLECTUAL_PROPERTY(3, "ENT_INTELLECTUAL_PROPERTY", "企业知识产权"),
    ENT_BUSINESS_DATA(4, "ENT_BUSINESS_DATA", "经营数据查询"),
    ENT_IDENTIFICATION_VERIFICATION(5, "ENT_IDENTIFICATION_VERIFICATION", "识别认证核验"),
    ENT_COMPANY_BASEINFO(6, "ENT_COMPANY_BASEINFO", "企业基本概况"),
    ENT_BLACK(7,"ENT_BLACK","黑名单");

    private Integer code;
    private String name;
    private String description;

    /**
     * @param description 中文描述
     */
    private CreditServiceLeftMenuEnum(String description) {
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param description 中文描述
     */
    private CreditServiceLeftMenuEnum(Integer code, String description) {
        this.code = code;
        this.description = description;
    }

    /**
     * @param name        英文编码名称
     * @param description 中文描述
     */
    private CreditServiceLeftMenuEnum(String name, String description) {
        this.name = name;
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param name        英文编码名称
     * @param description 中文描述
     * @param parentMenu 是否是父菜单
     */
    private CreditServiceLeftMenuEnum(Integer code, String name, String description) {
        this.code = code;
        this.name = name;
        this.description = description;
    }


    /**
     * 获取枚举类型数值编码
     */
    public Integer toCode() {
        return this.code == null ? this.ordinal() : this.code;
    }

    /**
     * 获取枚举类型英文编码名称
     */
    public String toName() {
        return this.name == null ? this.name() : this.name;
    }

    /**
     * 获取枚举类型中文描述
     */
    public String toDescription() {
        return this.description;
    }


    /**
     * 获取枚举类型中文描述
     */
    @Override
    public String toString() {
        return this.description;
    }



    /**
     * 按数值获取对应的枚举类型
     *
     * @param code 数值
     * @return 枚举类型
     */
    public static CreditServiceLeftMenuEnum enumValueOf(Integer code) {
        CreditServiceLeftMenuEnum[] values = CreditServiceLeftMenuEnum.values();
        CreditServiceLeftMenuEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (code != null && code.equals(values[i].toCode())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 按英文编码获取对应的枚举类型
     *
     * @param name 英文编码
     * @return 枚举类型
     */
    public static CreditServiceLeftMenuEnum enumValueOf(String name) {
        CreditServiceLeftMenuEnum[] values = CreditServiceLeftMenuEnum.values();
        CreditServiceLeftMenuEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (name != null && name.equalsIgnoreCase(values[i].toName())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 获取枚举类型的所有<数字编码,中文描述>对
     *
     * @return
     */
    public static Map<Integer, String> toCodeDescriptionMap() {
        LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
        for (int i = 0; i < CreditServiceLeftMenuEnum.values().length; i++) {
            if (CreditServiceLeftMenuEnum.values()[i] != NULL) {
                map.put(CreditServiceLeftMenuEnum.values()[i].toCode(), CreditServiceLeftMenuEnum.values()[i].toDescription());
            }
        }
        return map;
    }

    /**
     * 获取枚举类型的所有<英文编码名称,中文描述>对
     *
     * @return
     */
    public static Map<String, String> toNameDescriptionMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        for (int i = 0; i < CreditServiceLeftMenuEnum.values().length; i++) {
            if (CreditServiceLeftMenuEnum.values()[i] != NULL) {
                map.put(CreditServiceLeftMenuEnum.values()[i].toName(), CreditServiceLeftMenuEnum.values()[i].toDescription());
            }
        }
        return map;
    }
}
