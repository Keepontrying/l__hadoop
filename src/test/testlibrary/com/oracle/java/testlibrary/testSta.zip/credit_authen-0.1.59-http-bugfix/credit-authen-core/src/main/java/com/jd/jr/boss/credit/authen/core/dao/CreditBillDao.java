package com.jd.jr.boss.credit.authen.core.dao;

import java.util.List;
import java.util.Map;

import com.jd.jr.boss.credit.facade.authen.beans.response.CreditBillMerchantSum;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.jd.jr.boss.credit.authen.core.beans.request.BillQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.VipStatisticQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditBill;
import com.wangyin.boss.credit.admin.enums.MerchantClassifyEnum;

/**
 *  业务详情管理
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
@Repository
public interface CreditBillDao {
    /**
     * 汇总交易详情数据
     * @param bill
     * @return
     * @throws Exception
     */
	Integer saveBill(CreditBill bill) throws Exception;
    /**
     * 修改账单详单
     * @param billQueryParam
     * @return
     * @throws Exception
     */
    Integer updateBill(CreditBill bill) throws Exception;
    /**
     * 查询账单详单
     * @param billQueryParam
     * @return
     * @throws Exception
     */
    List<CreditBill> queryBill(BillQueryParam billQueryParam) throws Exception;
    /**
     * 查询账单list生成图表
     * @param bill
     * @return
     */
	List<CreditBill> queryBillList4Chart(CreditBill bill) throws Exception;
    /**
     * 查询vip接口统计报表
     * @return
     */
    List<CreditBill> queryStatisticCount(VipStatisticQueryParam param) throws Exception;

	/**
	 * 查询产品调用统计
	 * 
	 * @return
	 */
	List<Map<String, Object>> queryProCallCaseSummarize(@Param("startDate") String startDate,
			@Param("endDate") String endDate, @Param("proCode") String proCode);

	/*
	 * 查询商户在指定时间之前的调用次数
	 */
	Integer queryBeforeCount(@Param("merchant") String merchant, @Param("startDate") String startDate);

	/*
	 * 查询在指定时间之后产品使用商户列表
	 */
	List<String> queryAfterMerchant(@Param("merchantClassify") MerchantClassifyEnum merchantClassify,
			@Param("startDate") String startDate,@Param("endDate") String endDate);

	CreditBillMerchantSum queryBillMerchantSum(CreditBill bill);

}
