package com.jd.jr.boss.credit.authen.core.facade;

import com.jd.jr.boss.credit.authen.core.beans.request.AccessDetailsQueryParamExtend;
import com.jd.jr.boss.credit.authen.core.beans.request.DownloadFileQueryParam;
import com.jd.jr.boss.credit.authen.core.service.AccessDetailsService;
import com.jd.jr.boss.credit.domain.common.entity.CreditDownloadFile;
import com.jd.jr.boss.credit.domain.common.enums.*;
import com.jd.jr.boss.credit.facade.site.api.CreditAccessFacade;
import com.jd.jr.boss.credit.facade.site.api.dto.PageWithParam;
import com.jd.jr.boss.credit.facade.site.api.dto.entity.AccessSummaryEntity;
import com.jd.jr.boss.credit.facade.site.api.dto.request.access.AccessMakeRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.access.AccessQueryFileRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.access.AccessQueryRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.access.AccessQueryFileResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.access.AccessQueryResponse;
import com.wangyin.boss.credit.admin.entity.CreditAccessDetails;
import com.wangyin.boss.credit.admin.enums.AccessStepStatusEnum;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.Response;
import com.wangyin.operation.utils.GsonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by anmeng on 2016/12/12.
 */
@Service("accessFacade")
public class AccessFacadeImpl implements CreditAccessFacade {

    private Logger logger = LoggerFactory.getLogger(AccessFacadeImpl.class);

    @Autowired
    private AccessDetailsService accessDetailsService;

    @Override
    public PageWithParam<AccessQueryResponse> queryAccessList(RequestParam<AccessQueryRequest> requestParam) {
        logger.info("查询详单参数：", GsonUtil.getInstance().toJson(requestParam));
        String msg = "";
        String code="SUCCESS";
        Boolean success=true;
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        PageWithParam<AccessQueryResponse> page=new PageWithParam<AccessQueryResponse>();
        page.setParam(requestParam);

        List<AccessQueryResponse> resultList = new ArrayList<AccessQueryResponse>();

        if (requestParam != null && requestParam.getParam() != null) {
            try {
                AccessQueryRequest accessQueryRequest = requestParam.getParam();

                //处理参数
                String merchantNo = accessQueryRequest.getMerchantNo();
                Integer pageNo = accessQueryRequest.getPageNo();
                Integer pageSize = accessQueryRequest.getPageSize();
                ProductTableEnum product = accessQueryRequest.getProductName();
                SuccessOrFailStatusEnum status = accessQueryRequest.getStatus();
                Date startTime = accessQueryRequest.getStartTime();
                Date finishTime = accessQueryRequest.getFinishTime();
                if(startTime==null||finishTime==null){
                    throw new RuntimeException("参数错误：请输入起止时间！");
                }

                String orderNo = accessQueryRequest.getOrderNo();

                //查询详单
                AccessDetailsQueryParamExtend accessDetailsQueryParam = new AccessDetailsQueryParamExtend();
                accessDetailsQueryParam.setMerchantNo(merchantNo);
                accessDetailsQueryParam.setMerchantCode(accessQueryRequest.getMerchantCode());
                if (status!=null && status != SuccessOrFailStatusEnum.NULL) {
                    accessDetailsQueryParam.setAccessStatus(status.toName());
                }
                if (product!=null && product != ProductTableEnum.NULL) {
                    accessDetailsQueryParam.setProductId(product.toCode());
                }
                accessDetailsQueryParam.setStartTime(df.format(startTime));
                accessDetailsQueryParam.setFinishTime(df.format(finishTime));
                Integer start=0;
                Integer limit = 10;
                if(pageNo!=null&&pageSize!=null) {
                    if(pageNo<0||pageSize<0){
                        throw new RuntimeException("参数错误：页码不能为负数！");
                    }
                    start = (pageNo - 1) * pageSize;
                    limit = pageSize;
                }
                accessDetailsQueryParam.setStart(start);
                accessDetailsQueryParam.setLimit(limit);

                List<CreditAccessDetails> accessDetails = accessDetailsService.queryAccessDetails(accessDetailsQueryParam);
                if (accessDetails != null) {
                    for (CreditAccessDetails detail : accessDetails) {
                        AccessQueryResponse detailRes=convertAccessEntity(detail);
                        resultList.add(detailRes);
                    }
                }
                page.setRows(resultList);

                //查询记录数量
                Map<String,Integer> resultCount=accessDetailsService.queryAccessDetailsCount(accessDetailsQueryParam);
                AccessSummaryEntity summaryEntity=new AccessSummaryEntity();
                summaryEntity.setSumCount(resultCount.get("totalCount"));
                summaryEntity.setSuccessCount(resultCount.get("succCount"));
                summaryEntity.setFailCount(resultCount.get("failCount"));

                page.setExtend(summaryEntity);
                page.setTotal(resultCount.get("totalCount"));
            } catch (RuntimeException e) {
                success=false;
                code="fail";
                msg = e.getMessage();
                logger.error(e);
            }
        } else {
            success=false;
            code="fail";
            msg = "参数错误！";
        }

        page.setSuccess(success);
        page.setCode(code);
        page.setMessage(msg);
        logger.info("查询访问详单返回：", GsonUtil.getInstance().toJson(page));
        return page;
    }

    @Override
    public Response makeFile(RequestParam<AccessMakeRequest> requestParam) {
        logger.info("预约文件生成参数：", GsonUtil.getInstance().toJson(requestParam));
        String msg = "";
        String code="SUCCESS";
        Boolean success=true;
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (requestParam != null && requestParam.getParam() != null) {
            AccessMakeRequest accessMakeRequest = requestParam.getParam();

            //处理参数
            String merchantNo = accessMakeRequest.getMerchantNo();

            ProductTableEnum product = accessMakeRequest.getProductName();
            SuccessOrFailStatusEnum status = accessMakeRequest.getStatus();
            Date startTime = accessMakeRequest.getStartTime();
            Date finishTime = accessMakeRequest.getFinishTime();
            String orderNo = accessMakeRequest.getOrderNo();
            //查询详单
            AccessDetailsQueryParamExtend accessDetailsQueryParam = new AccessDetailsQueryParamExtend();
            accessDetailsQueryParam.setMerchantNo(merchantNo);
            accessDetailsQueryParam.setMerchantCode(accessMakeRequest.getMerchantCode());
            if (status!=null && status != SuccessOrFailStatusEnum.NULL) {
                accessDetailsQueryParam.setAccessStatus(status.toName());
            }
            if (product!=null && product != ProductTableEnum.NULL) {
                accessDetailsQueryParam.setProductId(product.toCode());
            }
            accessDetailsQueryParam.setStartTime(df.format(startTime));
            accessDetailsQueryParam.setFinishTime(df.format(finishTime));
            accessDetailsService.applyAccessDetailDownload(accessDetailsQueryParam);
        }else {
            success=false;
            code="fail";
            msg = "参数错误！";
        }

        Response response=new Response();
        response.setSuccess(success);
        response.setCode(code);
        response.setMessage(msg);
        logger.info("预约生成文件返回：", GsonUtil.getInstance().toJson(response));
        return response;
    }

    @Override
    public PageWithParam<AccessQueryFileResponse> queryFileList(RequestParam<AccessQueryFileRequest> requestParam) {
        logger.info("查询预约文件参数：", GsonUtil.getInstance().toJson(requestParam));
        String msg = "";
        String code="SUCCESS";
        Boolean success=true;
        PageWithParam<AccessQueryFileResponse> page=new PageWithParam<AccessQueryFileResponse>();
        page.setParam(requestParam);

        List<AccessQueryFileResponse> resultList=new ArrayList<AccessQueryFileResponse>();

        if (requestParam != null && requestParam.getParam() != null) {
            AccessQueryFileRequest queryFileRequest=requestParam.getParam();
            String merchantNo=queryFileRequest.getMerchantNo();
            String fileType=DownloadFileTypeEnum.ACCESS_DETAIL.getCode();
            Integer pageNo = queryFileRequest.getPageNo();
            Integer pageSize = queryFileRequest.getPageSize();

            //构造查询参数对象
            DownloadFileQueryParam queryParam = new DownloadFileQueryParam();
            queryParam.setMerchantNo(merchantNo);
            queryParam.setFileType(fileType);

            Integer start=0;
            Integer limit = 10;
            if(pageNo!=null&&pageSize!=null) {
                if(pageNo<0||pageSize<0){
                    throw new RuntimeException("参数错误：页码不能为负数！");
                }
                start = (pageNo - 1) * pageSize;
                limit = pageSize;
            }
            queryParam.setStart(start);
            queryParam.setLimit(limit);

            List<CreditDownloadFile> creditDownloadFiles=accessDetailsService.queryAccessDetailDownloadFile(queryParam);
            if(creditDownloadFiles!=null){
                for(CreditDownloadFile downloadFile:creditDownloadFiles){
                    AccessQueryFileResponse fileResponse=new AccessQueryFileResponse();
                    fileResponse.setFileName(downloadFile.getFileName());
                    fileResponse.setFileType(DownloadFileTypeEnum.ACCESS_DETAIL);
                    fileResponse.setMakeStatus(downloadFile.getStatus());
                    fileResponse.setCreateTime(downloadFile.getCreatedDate());
                    fileResponse.setStartTime(downloadFile.getStartTime());
                    fileResponse.setFinishTime(downloadFile.getFinishTime());
                    resultList.add(fileResponse);
                }
            }
            page.setRows(resultList);
            //查询总条数
            Integer totalCount=accessDetailsService.queryAccessDetailDownloadFileCount(queryParam);
            page.setTotal(totalCount);
        }else {
            success=false;
            code="fail";
            msg = "参数错误！";
        }

        page.setSuccess(success);
        page.setCode(code);
        page.setMessage(msg);
        logger.info("查询预约文件返回：", GsonUtil.getInstance().toJson(page));
        return page;
    }

    /**
     * 详单接口格式转换
     * @param detail
     * @return
     */
    private AccessQueryResponse convertAccessEntity(CreditAccessDetails detail) {
        AccessQueryResponse response=new AccessQueryResponse();
        response.setTradeNo(detail.getTradeNo());
        response.setAccessStatus(SuccessOrFailStatusEnum.enumValueOf(detail.getAccessStatus()));
        response.setProductName(ProductTableEnum.enumValueOf(detail.getProductId()));
        response.setRequestParam(detail.getRequestParam());
        response.setResponseParam(detail.getResponseParam());
        response.setStartTime(detail.getCreatedDate());
        response.setFinishTime(detail.getResponseTime());
        response.setChargeType(ProductChargeTypeEnum.enumValueOf(detail.getChargeType()));
        response.setPrice(detail.getPrice());
        response.setOrderNo(detail.getOrderNo());
        response.setRemark(AccessStepStatusEnum.enumValueOf(detail.getStepStatus()).toDescription());
        return response;
    }
}
