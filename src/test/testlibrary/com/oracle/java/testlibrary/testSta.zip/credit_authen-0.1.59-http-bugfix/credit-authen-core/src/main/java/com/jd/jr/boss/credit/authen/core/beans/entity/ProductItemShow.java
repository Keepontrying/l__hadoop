package com.jd.jr.boss.credit.authen.core.beans.entity;

import com.jd.jr.boss.credit.facade.enterprise.trade.enums.EnterpriseProductEnum;
import com.wangyin.boss.credit.admin.entity.CreditItem;

import java.io.Serializable;

/**
 * Created by anmeng on 2018/1/15.
 */
public class ProductItemShow extends CreditItem implements Serializable {
    private static final long serialVersionUID = 8648616345987951065L;

    private String showName;//展示名
    private boolean isShow = false;//是否展示
    private String iconClass;//展示图标

    public ProductItemShow(){

    }

    public ProductItemShow(EnterpriseProductEnum productEnum, String iconClass){
        this.setProductName(productEnum.toDescription());
        this.setProductCode(productEnum.toName());
        this.showName=productEnum.toDescription();
        this.iconClass=iconClass;
    }

    public String getShowName() {
        return showName;
    }

    public void setShowName(String showName) {
        this.showName = showName;
    }

    public String getIconClass() {
        return iconClass;
    }

    public void setIconClass(String iconClass) {
        this.iconClass = iconClass;
    }

    public boolean isShow() {
        return isShow;
    }

    public void setShow(boolean show) {
        isShow = show;
    }
}
