package com.jd.jr.boss.credit.authen.core.beans.entity;

import com.jd.jr.boss.credit.authen.core.enums.AuthStatus;

import java.io.Serializable;
import java.util.Date;

/**
 * @author ：zhanghui12
 * @date ：Created in 2019/3/20 10:34
 * @description：百望授权订单对象
 */
public class CreditBaiwangAuthOrderEntity implements Serializable {
    private static final long serialVersionUID = 7956950589353456238L;
    private Integer id;
    /**
     * 企业唯一标志
     */
    private String unionId;
    /**
     * 企业税号
     */
    private String taxNo;
    /**
     * 统一信用代码
     */
    private String creditCode;
    /**
     * 商户号
     */
    private String merchantNo;
    /**
     * 授权类型
     */
    private String authType;
    /**
     * 授权状态
     */
    private AuthStatus authStatus;
    /**
     * 上次查询百望授权接口时间
     */
    private Date lastQueryTime;
    /**
     * 通知状态
     */
    private String noticeStatus;
    /**
     * 通知次数
     */
    private Integer noticeCount;
    /**
     * 上一次通知时间
     */
    private Date lastNoticeTime;
    /**
     * 通知地址
     */
    private String noticeUrl;
    /**
     * 授权有效期
     */
    private String authLimitTime;
    /**
     * 创建时间
     */
    private Date createdDate;
    /**
     * 修改时间
     */
    private Date modifiedDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUnionId() {
        return unionId;
    }

    public void setUnionId(String unionId) {
        this.unionId = unionId;
    }

    public String getTaxNo() {
        return taxNo;
    }

    public void setTaxNo(String taxNo) {
        this.taxNo = taxNo;
    }

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public String getAuthType() {
        return authType;
    }

    public void setAuthType(String authType) {
        this.authType = authType;
    }

    public AuthStatus getAuthStatus() {
        return authStatus;
    }

    public void setAuthStatus(AuthStatus authStatus) {
        this.authStatus = authStatus;
    }



    public String getNoticeStatus() {
        return noticeStatus;
    }

    public void setNoticeStatus(String noticeStatus) {
        this.noticeStatus = noticeStatus;
    }

    public Integer getNoticeCount() {
        return noticeCount;
    }

    public void setNoticeCount(Integer noticeCount) {
        this.noticeCount = noticeCount;
    }

    public Date getLastQueryTime() {
        return lastQueryTime;
    }

    public void setLastQueryTime(Date lastQueryTime) {
        this.lastQueryTime = lastQueryTime;
    }

    public Date getLastNoticeTime() {
        return lastNoticeTime;
    }

    public void setLastNoticeTime(Date lastNoticeTime) {
        this.lastNoticeTime = lastNoticeTime;
    }

    public String getNoticeUrl() {
        return noticeUrl;
    }

    public void setNoticeUrl(String noticeUrl) {
        this.noticeUrl = noticeUrl;
    }

    public String getAuthLimitTime() {
        return authLimitTime;
    }

    public void setAuthLimitTime(String authLimitTime) {
        this.authLimitTime = authLimitTime;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
}
