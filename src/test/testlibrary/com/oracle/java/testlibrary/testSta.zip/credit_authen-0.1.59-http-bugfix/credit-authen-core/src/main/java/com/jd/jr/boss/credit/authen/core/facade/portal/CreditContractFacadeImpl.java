package com.jd.jr.boss.credit.authen.core.facade.portal;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.authen.core.service.ContractService;
import com.jd.jr.boss.credit.facade.authen.api.CreditContractFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.OnlineContactCreateParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.OnlineContractQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.common.enums.ResponseMessage;

/**
 * Created by anmeng on 2017/3/29.
 */
@Service("creditContractFacade")
public class CreditContractFacadeImpl implements CreditContractFacade {

    private Logger logger= LoggerFactory.getLogger(CreditContractFacadeImpl.class);

    @Resource
    private ContractService contractService;

    /**
     * 创建线上合同
     *
     * @param param
     * @return
     */
    @Override
    public ResponseData<CreditContract> createOnlineContract(OnlineContactCreateParam param) {
        ResponseData<CreditContract> responseData=null;
        try {
            responseData=contractService.createOnlineContract(param);
            return responseData;
        } catch (Exception e) {
            logger.error(e);
            responseData=new ResponseData<>();
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        return responseData;
    }

	@Override
	public CreditPage<CreditContract> queryCreditContractList(OnlineContractQueryParam queryPageParam) {
		
        return contractService.queryCreditContractList(queryPageParam);
	}

	@Override
	public CreditResponseData<CreditContract> queryCreditContractDetail(CreditRequestParam<CreditContract> queryParam) {
		CreditResponseData<CreditContract> responseData=new CreditResponseData<CreditContract>();
		CreditContract cc = queryParam.getParam();
        cc = contractService.queryContractDetailById(cc.getContractId());
        responseData.setData(cc);
        return responseData;
	}
}
