package com.jd.jr.boss.credit.authen.core.constants;

import com.jd.jr.boss.credit.facade.common.dto.SystemInfo;
import org.apache.commons.lang3.StringUtils;

import java.util.concurrent.ConcurrentHashMap;

/**
 * 系统信息
 */
public class SystemInfoConstants {
    private ConcurrentHashMap<String, SystemInfo> systemInfoHashMap = new ConcurrentHashMap();
    public SystemInfoConstants(){
        String token = "2686f89bcc4246538834045d3b3e61a7";
        SystemInfo systemInfo = new SystemInfo(token, null, "credit_mobile", "credit");
        systemInfoHashMap.put(token, systemInfo);
    }

    public SystemInfo get(String token){
        return systemInfoHashMap.get(token);
    }

    public boolean check(SystemInfo systemInfoReq){
        boolean result = false;
        if (StringUtils.isNotBlank(systemInfoReq.getToken())){
            SystemInfo systemInfo =this.get(systemInfoReq.getToken());
            if (systemInfo != null && systemInfo.getSystemId().equals(systemInfoReq.getSystemId())
                    && systemInfo.getBussId().equals(systemInfoReq.getBussId())){
                result = true;
            }
        }

        return result;
    }


}
