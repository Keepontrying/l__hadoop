package com.jd.jr.boss.credit.authen.core.jms.invoiceVerify;

import com.google.gson.Gson;
import com.jd.fastjson.JSONObject;
import com.jd.jmq.client.consumer.MessageListener;
import com.jd.jmq.common.message.Message;
import com.jd.jr.boss.credit.authen.core.constants.AsyncChargeConstants;
import com.jd.jr.boss.credit.authen.core.constants.SystemConstants;
import com.jd.jr.boss.credit.authen.core.enums.CrawlerInvoiceVerifyStatusEnum;
import com.jd.jr.boss.credit.authen.core.service.*;
import com.jd.jr.boss.credit.domain.common.entity.CreditCallbackUrl;
import com.jd.jr.boss.credit.domain.common.entity.CreditQueryBatch;
import com.jd.jr.boss.credit.domain.common.entity.CreditQuerySyncNotice;
import com.jd.jr.boss.credit.domain.common.entity.invoiceVerify.CreditInvoiceVerify;
import com.jd.jr.boss.credit.domain.common.entity.invoiceVerify.CreditInvoiceVerifyApi;
import com.jd.jr.boss.credit.domain.common.entity.invoiceVerify.CreditInvoiceVerifyApiReponse;
import com.jd.jr.boss.credit.domain.common.entity.invoiceVerify.CreditInvoiceVerifyGoods;
import com.jd.jr.boss.credit.domain.common.enums.*;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.CallbackUrlQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.InvoiceQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.common.utils.SerialNoUtil;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.DoChargeFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.ForeignFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.ResultData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.ForeignParam;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.invoice.InvoiceVerifyChargeParam;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.EnterpriseProductEnum;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.response.ResultDataEnum;
import com.wangyin.boss.credit.admin.entity.InterfaceFlow;
import com.wangyin.boss.credit.admin.enums.EnterpriseProductEnum4Common;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.utils.GsonUtil;
import com.wangyin.rediscluster.client.CacheClusterClient;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 *
 * 发票查验结果监听
 * @author for jinlin
 * @since 2017/7/6
 */
@Component("creditInvoiceVerifyResultListener")
public class CreditInvoiceVerifyResultListener implements MessageListener {
	
    private static Logger LOGGER = LoggerFactory.getLogger(CreditInvoiceVerifyResultListener.class);

    @Resource
    private CreditInvoiceVerifyService invoiceVerifyService;

    @Resource
    private CreditQueryBatchService queryBatchService;

    @Resource
    protected CacheClusterClient cacheClusterClient;
    
    @Resource
    private ForeignFacade foreignFacade;
    
    @Resource
    private ForeignCallbackNoticeService foreignCallbackNoticeService;

    @Autowired
    private DoChargeFacade doChargeFacade;

    @Resource
    private CreditChargeService creditChargeService;

    @Resource
    private MsgProducerService msgProducerService;

    private final String PROCESS_COUNT_KEY_PREFIX="BATCH_QUERY_PROCESS_COUNT_";
    private final String SUCCESS_COUNT_KEY_PREFIX="BATCH_QUERY_SUCCESS_COUNT_";
    private final String INVOICE_API_SYNC_NOTICE_FLAG="API";
    private final Integer INVOICE_API_SYNC_NOTICE_PARAM_LENGTH_MAX = 2800;

    @Override
    public void onMessage(List<Message> messages) throws Exception {
    	
    	LOGGER.info("======CreditInvoiceVerifyResultListener handler start======");
        if (messages == null || messages.isEmpty()) {
        	LOGGER.info("CreditInvoiceVerifyResultListener message is null");
            return;
        }
        for (Message message : messages) {
            String objectJson = message.getText();
            LOGGER.info("CreditInvoiceVerifyResultListener message, body part:{}",objectJson);
            CreditQueryBatch queryBatch= null;
            CreditInvoiceVerify invoiceVerify= null;
            boolean refundRedisResult = false;
            String balanceKey = null;
            long amount = 1;//批次回量均为1---即次数
            try {
            JSONObject returnData=JSONObject.parseObject(objectJson);

            String batchToken=returnData.getString("batchToken");
            if(StringUtils.isBlank(batchToken)){
                    LOGGER.info("CreditInvoiceVerifyResultListener bad request , batchToken is null!");
                return;
            }

            String crawlerTime=returnData.getString("crawlerTime");
            String result=returnData.getString("result");
            String invoiceCode=returnData.getString("fpdm");
            String invoiceNo=returnData.getString("fphm");
                String systemId=returnData.getString("systemId");
                if(StringUtil.isBlank(invoiceCode)||StringUtil.isBlank(invoiceNo)){
                    LOGGER.info("bad request , invoiceCode or invoiceNo is null!");
                return;
            }

            BatchQueryParam queryParam=new BatchQueryParam();
            queryParam.setBatchNoToken(batchToken);
                queryBatch = queryBatchService.queryBatchNoPage(queryParam);
            if(queryBatch==null){
                    LOGGER.info("CreditInvoiceVerifyResultListener can not find batch info!");
                return ;
            }
                invoiceVerify = new CreditInvoiceVerify();
            invoiceVerify.setBatchId(queryBatch.getId());
            invoiceVerify.setCode(invoiceCode);
            invoiceVerify.setNumber(invoiceNo);
                CreditRequestParam<InvoiceVerifyChargeParam> requestParam4Charge = null;
                InvoiceVerifyChargeParam invoiceVerifyParam = null;
                String tradeNo = SerialNoUtil.createSerialNo("CAEFP");

                //无论查询结果是否为终态，均把缓存中的预扣量返还
                balanceKey = "balance_"+ queryBatch.getMerchantNo()+ "_"+EnterpriseProductEnum4Common.ENTERPRISE_INVOICE_VERIFY.toName();
                refundRedisResult = creditChargeService.refundRedisBanlance(balanceKey, amount);
                LOGGER.info("CreditInvoiceVerifyResultListener refundRedisBanlance refundRedisResult,{}", refundRedisResult);
                InvoiceQueryParam queryParam4Qry = new InvoiceQueryParam();
                queryParam4Qry.setBatchId(invoiceVerify.getBatchId());
                queryParam4Qry.setCode(invoiceVerify.getCode());
                queryParam4Qry.setNumber(invoiceVerify.getNumber());
                CreditPage<CreditInvoiceVerify> queryInvoiceDetailData = invoiceVerifyService.queryInvoiceDetailData(queryParam4Qry);
                if(null == queryInvoiceDetailData){
                    LOGGER.info("CreditInvoiceVerifyResultListener can not find invoice info!");
                    continue;
                }
                if(null!=queryInvoiceDetailData && !queryInvoiceDetailData.isSuccess()){
                    LOGGER.info("CreditInvoiceVerifyResultListener queryInvoiceDetailData failed!");
                    continue;
                }
                if(null!=queryInvoiceDetailData && queryInvoiceDetailData.isSuccess() && CollectionUtils.isEmpty(queryInvoiceDetailData.getRows())){
                    LOGGER.info("CreditInvoiceVerifyResultListener queryInvoiceDetailData success, list is null !");
                    continue;
                }
                requestParam4Charge = new CreditRequestParam<InvoiceVerifyChargeParam>();
                invoiceVerifyParam = new InvoiceVerifyChargeParam();
                invoiceVerifyParam.setInvoiceCode(invoiceCode);
                invoiceVerifyParam.setInvoiceNo(invoiceNo);
                invoiceVerifyParam.setCreateDate(queryInvoiceDetailData.getRows().get(0).getCreateDate());
                invoiceVerifyParam.setAmount(queryInvoiceDetailData.getRows().get(0).getTotalAmount());
                invoiceVerifyParam.setCheckCode(queryInvoiceDetailData.getRows().get(0).getCheckCode());

            if("0".equals(result)){
                //正常获取到国税发票平台结果
                Map invoiceMap=returnData.getJSONObject("invoiceData");
                String status=(String)invoiceMap.get("status");
                CrawlerInvoiceVerifyStatusEnum verifyStatusEnum= CrawlerInvoiceVerifyStatusEnum.enumValueOf(status);
                if(CrawlerInvoiceVerifyStatusEnum.SUCCESS.equals(verifyStatusEnum)){
                    this.convertToInvoice(invoiceMap,invoiceVerify);
                    invoiceVerify.setVerifyStatus(verifyStatusEnum.getDescription());
                }else{
                    invoiceVerify.setVerifyStatus(verifyStatusEnum.getDescription());
                }
                if(CrawlerInvoiceVerifyStatusEnum.SUCCESS.equals(verifyStatusEnum)||CrawlerInvoiceVerifyStatusEnum.INCONFORMITY.equals(verifyStatusEnum)
                        ||CrawlerInvoiceVerifyStatusEnum.NO_INVOICE.equals(verifyStatusEnum)
                        ||CrawlerInvoiceVerifyStatusEnum.TODAY_INVOICE.equals(verifyStatusEnum)){
                    //更新批次成功个数
                    Long successCount=cacheClusterClient.incr(SUCCESS_COUNT_KEY_PREFIX+queryBatch.getId());
                    if(successCount.equals(1L)){
                        cacheClusterClient.expire(SUCCESS_COUNT_KEY_PREFIX+queryBatch.getId(),24*3600);
                    }
                    BigDecimal successRate = BigDecimal.valueOf(successCount).divide(new BigDecimal(queryBatch.getBatchCount()),2,BigDecimal.ROUND_HALF_EVEN);
                    queryBatch.setSuccessRate(successRate.multiply(new BigDecimal(100)));
                }
                    invoiceVerifyParam.setDoCharge(true);
                    invoiceVerifyParam.setCode(result);
                    requestParam4Charge.setParam(invoiceVerifyParam);
                    requestParam4Charge.setSystemId(systemId);//systemId  待数据部发出的海关mq改造完毕后给出
                    requestParam4Charge.setTradeNo(tradeNo);
                    LOGGER.info("creditInvoiceVerifyResultListener-doChargeFacade.payInvoice requestParam: {}", GsonUtil.getInstance().toJson(requestParam4Charge));
                    CreditResponseData<ResultData<InvoiceVerifyChargeParam, String>> chargeResp = doChargeFacade.payInvoice(requestParam4Charge);
                    if(null != chargeResp){
                        tradeNo = chargeResp.getTradeNo();
                    }
                    LOGGER.info("creditInvoiceVerifyResultListener-doChargeFacade.payInvoice requestParam responseData: {}", GsonUtil.getInstance().toJson(chargeResp));
                    if(null != chargeResp && chargeResp.isSuccess()){
                    }else{//扣费失败则变更发票查询状态
                        LOGGER.info("creditInvoiceVerifyResultListenerr-doChargeFacade.payInvoice failed, cant update status to success end.");
                        invoiceVerify.setVerifyStatus(chargeResp.getMessage());
                        LOGGER.info("creditCustomsListener-doChargeFacade.payCustom failed, cant update status to success end.");
                        if(ResultDataEnum.RESULT_BALANCE_LACK.toName().equals(chargeResp.getCode())||ResultDataEnum.RESULT_SERVICE_NOSTRATEGY.toName().equals(chargeResp.getCode())){
                            invoiceVerify.setVerifyStatus(AsyncChargeConstants.ASYNC_CHARGE_RESPONSE_MESSAGE_NO_FUNDS);
            }else{
                            invoiceVerify.setVerifyStatus(AsyncChargeConstants.ASYNC_CHARGE_RESPONSE_MESSAGE_FAIL_FUNDS);
                        }
                    }
                }else{
                //爬虫组报错
                invoiceVerify.setVerifyStatus("查询失败");
                    invoiceVerifyParam.setDoCharge(false);
                    invoiceVerifyParam.setCode(result);
                    requestParam4Charge.setParam(invoiceVerifyParam);
                    requestParam4Charge.setSystemId(systemId);//systemId  待数据部发出的海关mq改造完毕后给出
                    requestParam4Charge.setTradeNo(tradeNo);
                    LOGGER.info("creditInvoiceVerifyResultListener-doChargeFacade.payInvoice requestParam: {}", GsonUtil.getInstance().toJson(requestParam4Charge));
                    CreditResponseData<ResultData<InvoiceVerifyChargeParam, String>> chargeResp = doChargeFacade.payInvoice(requestParam4Charge);
                    if(null != chargeResp){
                        tradeNo = chargeResp.getTradeNo();
            }
                    LOGGER.info("creditInvoiceVerifyResultListener-doChargeFacade.payInvoice requestParam responseData: {}", GsonUtil.getInstance().toJson(chargeResp));
                }

                try {
                    InterfaceFlow interfaceFlow = new InterfaceFlow();
                    interfaceFlow.setInsCode(CreditChannelInterfaceCodeInsCodeEnum.invoiceVerify.getInsCode());//
                    interfaceFlow.setInterfaceCode(CreditChannelInterfaceCodeInsCodeEnum.invoiceVerify.getInterfaceCode());//
                    interfaceFlow.setTradeNo(tradeNo);
                    Date date = new Date();
                    interfaceFlow.setRequestTime(date);
                    interfaceFlow.setResponseTime(date);
                    interfaceFlow.setReturnCode(result);
                    interfaceFlow.setReturnStatus(StringUtils.isNotBlank(result)&&("0".equals(result)) ? "true" : "false");
                    String requestParamStr = GsonUtil.getInstance().toJson(invoiceVerifyParam);
                    interfaceFlow.setRequestParam(requestParamStr);
                    interfaceFlow.setReturnMsg(null);
                    interfaceFlow.setResponseParam(objectJson);
                    interfaceFlow.setChannel(CreditChannelTypeEnum.DATA_DEPARTMENT + "");
                    interfaceFlow.setFromCache(false);
                    msgProducerService.sendChannelLogFmqMsg(interfaceFlow);
                    LOGGER.info("creditInvoiceVerifyResultListener sendChannelLogFmqMsg success, mq: {}", GsonUtil.getInstance().toJson(interfaceFlow));
                } catch (Exception e) {
                    LOGGER.error("creditInvoiceVerifyResultListener sendChannelLogFmqMsg error, {}", e);
                }

            invoiceVerifyService.updateInvoice(invoiceVerify);
            //更新批次完成个数
            Long processCount=cacheClusterClient.incr(PROCESS_COUNT_KEY_PREFIX+queryBatch.getId());
            if(processCount.equals(1L)){
                cacheClusterClient.expire(PROCESS_COUNT_KEY_PREFIX+queryBatch.getId(),24*3600);
            }
            BigDecimal processRate = BigDecimal.valueOf(processCount).divide(new BigDecimal(queryBatch.getBatchCount()),2,BigDecimal.ROUND_HALF_EVEN);
            queryBatch.setProgress(processRate.multiply(new BigDecimal(100)));
            queryBatchService.updateQueryBatch(queryBatch);
            } catch (Exception e) {
                LOGGER.error("creditInvoiceVerifyResultListener handle mq error, {}", e);
            }finally {
                if(!refundRedisResult){//上方退还预扣失败，则再次尝试回量预扣款
                    refundRedisResult = creditChargeService.refundRedisBanlance(balanceKey, amount);
                }
            }

            try {
    			if(null != queryBatch && StringUtils.isNotBlank(queryBatch.getFileName()) && queryBatch.getFileName().equalsIgnoreCase(INVOICE_API_SYNC_NOTICE_FLAG)){
    				CallbackUrlQueryParam callbackUrlQueryParam = new CallbackUrlQueryParam();
    				callbackUrlQueryParam.setMerchantNo(queryBatch.getMerchantNo());
    				callbackUrlQueryParam.setProductCode(EnterpriseProductEnum.ENTERPRISE_INVOICE_VERIFY.toName());
    				callbackUrlQueryParam.setBusinessType(CreditCallbackBusinessTypeEnum.RESULT.toName());
    				callbackUrlQueryParam.setUrlStatus(OpenOrCloseStatusEnum.OPEN.toName());
    				List<CreditCallbackUrl> callbackUrlList = foreignCallbackNoticeService.queryCallbackUrlListByPrm(callbackUrlQueryParam);
    				if(CollectionUtils.isEmpty(callbackUrlList)){
    					LOGGER.info("======CreditInvoiceVerifyResultListener handler end======");
    					return;
    				}
    				if(StringUtils.isBlank(callbackUrlList.get(0).getCallbackUrl())){
    					LOGGER.info("======CreditInvoiceVerifyResultListener handler end======");
    					return;
    				}
    				CreditInvoiceVerifyApiReponse creditInvoiceVerifyApiReponse = new CreditInvoiceVerifyApiReponse();
    				this.convertToInvoiceApi(invoiceVerify, queryBatch, creditInvoiceVerifyApiReponse);
    				Gson gson = new Gson();
    				String resultStr = gson.toJson(creditInvoiceVerifyApiReponse);
    				CreditRequestParam<ForeignParam> requestParam = new CreditRequestParam<ForeignParam>();
    				ForeignParam foreignParam = new ForeignParam();
    				foreignParam.setUrl(callbackUrlList.get(0).getCallbackUrl());
    				foreignParam.setData(resultStr);
    				requestParam.setParam(foreignParam);
    				LOGGER.info("CreditInvoiceVerifyResultListener callback success, requestPrm:{}",GsonUtil.getInstance().toJson(requestParam) );
    				CreditResponseData<String> responseData = foreignFacade.notice(requestParam);
    				if(null != responseData && responseData.isSuccess() && StringUtils.isNotBlank(responseData.getData()) 
    						&& responseData.getData().equalsIgnoreCase(CrawlerInvoiceVerifyStatusEnum.SUCCESS.getName())){
    					LOGGER.info("CreditInvoiceVerifyResultListener callback success, responseData:{}",GsonUtil.getInstance().toJson(responseData) );
    				}else{//将回调失败信息放到回调失败任务轮训表中
    					LOGGER.info("CreditInvoiceVerifyResultListener callback failed, responseData:{}",GsonUtil.getInstance().toJson(responseData) );
    					int addId = this.addQuerySyncNotice(callbackUrlList, resultStr, invoiceVerify);
    					if(0!= addId){
    						LOGGER.info("CreditInvoiceVerifyResultListener-addQuerySyncNotice success, invoice number :{}",invoiceVerify.getNumber() );
    					}else{
    						LOGGER.info("CreditInvoiceVerifyResultListener-addQuerySyncNotice failed, invoice number :{}",invoiceVerify.getNumber() );
    					}
    				}
    			}
    		} catch (Exception e) {
    			LOGGER.error("CreditInvoiceVerifyResultListener callback failed, {}", e);
    			e.printStackTrace();
    		}
        }
        LOGGER.info("======CreditInvoiceVerifyResultListener handler end======");
    }

    /**
     * 构造发票实体类信息
     * @param returnData
     * @param invoiceEntity
     */
    private void convertToInvoice(Map<String,Object> returnData,CreditInvoiceVerify invoiceEntity){
        invoiceEntity.setCode((String)returnData.get("fpdm_zp"));
        invoiceEntity.setNumber((String)returnData.get("fphm_zp"));
        invoiceEntity.setCreateDate((String)returnData.get("kprq_zp"));
        invoiceEntity.setCheckCode((String)returnData.get("jym_zp"));
        invoiceEntity.setMachineNo((String)returnData.get("jqbh_zp"));
        invoiceEntity.setVerifyNum((String)returnData.get("cycs_zp"));
        invoiceEntity.setVerifyDate((String)returnData.get("cysj_zp"));
        invoiceEntity.setSource((String)returnData.get("fpcc_zp"));
        invoiceEntity.setBuyerDom((String)returnData.get("gfdzdh_zp"));
        invoiceEntity.setBuyerName((String)returnData.get("gfmc_zp"));
        invoiceEntity.setBuyerAccount((String)returnData.get("gfyhzh_zp"));
        invoiceEntity.setBuyerTaxNo((String)returnData.get("gfsbh_zp"));
        invoiceEntity.setSellerDom((String)returnData.get("xfdzdh_zp"));
        invoiceEntity.setSellerName((String)returnData.get("xfmc_zp"));
        invoiceEntity.setSellerTaxNo((String)returnData.get("xfsbh_zp"));
        invoiceEntity.setSellerAccount((String)returnData.get("xfyhzh_zp"));
        invoiceEntity.setRemark((String)returnData.get("bz_zp"));
        invoiceEntity.setTotalAmount((String)returnData.get("hjje_zp"));
        invoiceEntity.setTotalTax((String)returnData.get("hjse_zp"));
        invoiceEntity.setAmountOrdinary((String)returnData.get("jshjxx_zp"));
        invoiceEntity.setAmountCapital((String)returnData.get("jshjdx_zp"));
        invoiceEntity.setIsCanceled((String)returnData.get("sfzf_zp"));
        invoiceEntity.setType((String)returnData.get("fplx_zp"));
        List<Map<String,String>> goodsMapList=(List)returnData.get("hwxxs");
        if(goodsMapList!=null){
            List<CreditInvoiceVerifyGoods> goodsEntityList=new ArrayList<CreditInvoiceVerifyGoods>();
            for(Map<String,String> goodsMap:goodsMapList){
                CreditInvoiceVerifyGoods goods=new CreditInvoiceVerifyGoods();
                goods.setName(goodsMap.get("mc"));
                goods.setModel(goodsMap.get("ggxh"));
                goods.setUnit(goodsMap.get("dw"));
                goods.setNumber(goodsMap.get("sl"));
                goods.setPrice(goodsMap.get("dj"));
                goods.setAmount(goodsMap.get("je"));
                goods.setTaxRatio(goodsMap.get("shl"));
                goods.setTax(goodsMap.get("she"));
                goodsEntityList.add(goods);
            }
            invoiceEntity.setGoodsList(goodsEntityList);
        }
    }
    /**
     * 构造API发票实体类信息
     * @param invoiceVerify
     * @param queryBatch
     * @param creditInvoiceVerifyApiReponse
     */
    private void convertToInvoiceApi(CreditInvoiceVerify invoiceVerify, CreditQueryBatch queryBatch, CreditInvoiceVerifyApiReponse creditInvoiceVerifyApiReponse){
    	creditInvoiceVerifyApiReponse.setCode(CrawlerInvoiceVerifyStatusEnum.enumValueOfByDesc(invoiceVerify.getVerifyStatus()).getName());
    	creditInvoiceVerifyApiReponse.setMsg(invoiceVerify.getVerifyStatus());
    	creditInvoiceVerifyApiReponse.setBatchNo(queryBatch.getBatchNo());
    	if(StringUtils.isNotBlank(invoiceVerify.getVerifyStatus()) && 
    			(CrawlerInvoiceVerifyStatusEnum.INVALID_VERIFY_CODE.getDescription().equalsIgnoreCase(CrawlerInvoiceVerifyStatusEnum.enumValueOfByDesc(invoiceVerify.getVerifyStatus()).getDescription()) || 
    					CrawlerInvoiceVerifyStatusEnum.WRONG_VERIFY_CODE.getDescription().equalsIgnoreCase(CrawlerInvoiceVerifyStatusEnum.enumValueOfByDesc(invoiceVerify.getVerifyStatus()).getDescription()) )  ){
    		creditInvoiceVerifyApiReponse.setCode(CrawlerInvoiceVerifyStatusEnum.SYSTEM_ERROR.name());
    		creditInvoiceVerifyApiReponse.setMsg(CrawlerInvoiceVerifyStatusEnum.SYSTEM_ERROR.getDescription());
    	}
    	List<CreditInvoiceVerifyApi> invoiceDataList = new ArrayList<CreditInvoiceVerifyApi>();
    	CreditInvoiceVerifyApi invoiceVerify4Api = new CreditInvoiceVerifyApi();
		BeanUtils.copyProperties(invoiceVerify, invoiceVerify4Api, new String[]{"goodsList"});
		invoiceVerify4Api.setInvoiceCode(invoiceVerify.getCode());
		invoiceVerify4Api.setInvoiceNo(invoiceVerify.getNumber());
		invoiceVerify4Api.setGoodsList(invoiceVerify.getGoodsList());
		invoiceDataList.add(invoiceVerify4Api);
		creditInvoiceVerifyApiReponse.setData(invoiceDataList);
    }
    /**
     * 将回调失败的任务落地
     * @param callbackUrlList
     * @param resultStr
     * @param invoiceVerify
     * @return
     */
    private int addQuerySyncNotice(List<CreditCallbackUrl> callbackUrlList, String resultStr, CreditInvoiceVerify invoiceVerify){
    	int addId = 0;
    	CreditQuerySyncNotice querySyncNotice = new CreditQuerySyncNotice();
    	querySyncNotice.setCallbackId(callbackUrlList.get(0).getId());
    	if(StringUtils.isBlank(resultStr)){
    		InvoiceQueryParam queryParam = new InvoiceQueryParam();
    		queryParam.setBatchId(invoiceVerify.getBatchId());
    		queryParam.setCode(invoiceVerify.getCode());
    		queryParam.setNumber(invoiceVerify.getNumber());
    		CreditPage<CreditInvoiceVerify> queryInvoiceDetailData = invoiceVerifyService.queryInvoiceDetailData(queryParam);
    		if(null != queryInvoiceDetailData && queryInvoiceDetailData.isSuccess() && !CollectionUtils.isEmpty(queryInvoiceDetailData.getRows())){
    			querySyncNotice.setResultId(queryInvoiceDetailData.getRows().get(0).getId());
    		}
    		querySyncNotice.setParamComplFlag(CreditYesOrNoEnum.NO.toName());
			querySyncNotice.setResultParam(resultStr);
    	}else if(StringUtils.isNotBlank(resultStr) && resultStr.length()>=INVOICE_API_SYNC_NOTICE_PARAM_LENGTH_MAX){
    		InvoiceQueryParam queryParam = new InvoiceQueryParam();
    		queryParam.setBatchId(invoiceVerify.getBatchId());
    		queryParam.setCode(invoiceVerify.getCode());
    		queryParam.setNumber(invoiceVerify.getNumber());
    		CreditPage<CreditInvoiceVerify> queryInvoiceDetailData = invoiceVerifyService.queryInvoiceDetailData(queryParam);
    		if(null != queryInvoiceDetailData && queryInvoiceDetailData.isSuccess() && !CollectionUtils.isEmpty(queryInvoiceDetailData.getRows())){
    			querySyncNotice.setResultId(queryInvoiceDetailData.getRows().get(0).getId());
    		}
    		querySyncNotice.setParamComplFlag(CreditYesOrNoEnum.NO.toName());
			querySyncNotice.setResultParam(resultStr.substring(0, INVOICE_API_SYNC_NOTICE_PARAM_LENGTH_MAX.intValue()) );
    	}else{
    		querySyncNotice.setParamComplFlag(CreditYesOrNoEnum.YES.toName());
			querySyncNotice.setResultParam(resultStr );
    	}
    	querySyncNotice.setNoticeType(CreditQueryBatchTypeEnum.INVOICE.toName());
    	querySyncNotice.setNoticeStatus(CreditCallbackNoticeStatusEnum.UNDO.toName());
    	querySyncNotice.setNoticeTimes(0);
    	querySyncNotice.setMerchantNo(callbackUrlList.get(0).getMerchantNo());
    	querySyncNotice.setMerchantName(callbackUrlList.get(0).getMerchantName());
    	querySyncNotice.setCreator(SystemConstants.PARAM_INPUT_OPERATOR);
    	querySyncNotice.setCreatedDate(new Date());
    	querySyncNotice.setModifier(SystemConstants.PARAM_INPUT_OPERATOR);
    	querySyncNotice.setModifiedDate(new Date());
    	addId = foreignCallbackNoticeService.addSyncNotice(querySyncNotice);
    	return addId;
    }
    
}
