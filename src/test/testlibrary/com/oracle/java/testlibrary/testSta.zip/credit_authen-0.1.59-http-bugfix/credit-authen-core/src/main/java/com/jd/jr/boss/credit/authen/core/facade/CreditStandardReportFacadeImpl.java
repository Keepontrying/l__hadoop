package com.jd.jr.boss.credit.authen.core.facade;

import com.alibaba.fastjson.JSONObject;
import com.jd.finance.common.utils.GsonUtils;
import com.jd.jr.boss.credit.authen.core.dao.CreditStandardReportDao;
import com.jd.jr.boss.credit.authen.core.service.CreditMerchantLogoService;
import com.jd.jr.boss.credit.authen.core.service.MerchantService;
import com.jd.jr.boss.credit.domain.common.entity.StandardReportBatch;
import com.jd.jr.boss.credit.facade.authen.api.CreditStandardReportFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchCreateReportParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchReportQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.SingleCreateReportParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.creditReport.*;
import com.jd.jr.boss.credit.facade.channel.enterprise.beans.response.creditReport.OrderInfo;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.common.utils.SerialNoUtil;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.RequestReferEnum;
import com.jdjr.fmq.client.producer.MessageProducer;
import com.jdjr.fmq.common.exception.JMQException;
import com.jdjr.fmq.common.message.Message;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.entity.CreditMerchantLogo;
import com.wangyin.boss.credit.admin.entity.CreditStandardReport;
import com.wangyin.boss.credit.admin.entity.TradeAccessFlow;
import com.wangyin.boss.credit.admin.enums.*;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.fundpayment.operation.facade.FundPaymentCutDayFacade;
import com.wangyin.fundpayment.operation.facade.common.Response;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.apache.commons.lang.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * Created by zhanghui12 on 2018/5/15.
 * 商户logo 管理
 */
@Service("creditStandardReportFacade")
public class CreditStandardReportFacadeImpl implements CreditStandardReportFacade {
    private Logger logger = LoggerFactory.getLogger(CreditStandardReportFacadeImpl.class);

    @Autowired
    private CreditMerchantLogoService creditMerchantLogoService;
    @Autowired
    private CreditStandardReportDao creditStandardReportDao;
    @Resource
    private FundPaymentCutDayFacade fundPaymentCutDayFacade;

    @Override
    public CreditResponseData<Integer> addLogo(CreditRequestParam<CreditMerchantLogo> requestParam) {
        logger.info("merchant logo manage :add logo", JSONObject.toJSONString(requestParam));
        CreditResponseData<Integer> creditResponseData = new CreditResponseData<Integer>();
        try {
            if (requestParam == null || requestParam.getParam() == null || StringUtil.isEmpty(requestParam.getParam().getMerchantNo())) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                creditResponseData.setData(0);
                logger.error("add Logo error, requestParam is null");
                return creditResponseData;
            }
            CreditMerchantLogo merchantLogo = requestParam.getParam();
            Integer addResult = creditMerchantLogoService.addLogo(merchantLogo);
            creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
            creditResponseData.setCode(ResponseMessage.SUCCESS.name());
            creditResponseData.setSuccess(true);
            creditResponseData.setData(addResult);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(0);
        } finally {
            logger.info("add merchant logo finished,response:{} ", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }

    @Override
    public CreditResponseData<Integer> updateLogo(CreditRequestParam<CreditMerchantLogo> requestParam) {
        logger.info("merchant logo manage :update logo", JSONObject.toJSONString(requestParam));
        CreditResponseData<Integer> creditResponseData = new CreditResponseData<Integer>();
        try {
            if (requestParam == null || requestParam.getParam() == null || StringUtil.isEmpty(requestParam.getParam().getMerchantNo())) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                creditResponseData.setData(0);
                logger.error("update Logo error, requestParam is null");
                return creditResponseData;
            }
            CreditMerchantLogo merchantLogo = requestParam.getParam();
            Integer updateResult = creditMerchantLogoService.updateLogo(merchantLogo);
            creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
            creditResponseData.setCode(ResponseMessage.SUCCESS.name());
            creditResponseData.setSuccess(true);
            creditResponseData.setData(updateResult);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(0);
        } finally {
            logger.info("update merchant logo finished,response:{} ", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }

    @Override
    public CreditResponseData<CreditMerchantLogo> queryLogo(CreditRequestParam<CreditMerchantLogo> requestParam) {
        logger.info("merchant logo manage :query logo", JSONObject.toJSONString(requestParam));
        CreditResponseData<CreditMerchantLogo> creditResponseData = new CreditResponseData<CreditMerchantLogo>();
        try {
            if (requestParam == null || requestParam.getParam() == null || StringUtil.isEmpty(requestParam.getParam().getMerchantNo())) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("query Logo error, requestParam is null");
                return creditResponseData;
            }
            CreditMerchantLogo merchantLogo = requestParam.getParam();
            CreditMerchantLogo queryResult = creditMerchantLogoService.queryLogo(merchantLogo);
            creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
            creditResponseData.setCode(ResponseMessage.SUCCESS.name());
            creditResponseData.setSuccess(true);
            creditResponseData.setData(queryResult);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            logger.info("query merchant logo finished,response:{} ", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }
    @Autowired
    private MerchantService merchantService;
    @Override
    public CreditResponseData<EntInfo> queryEntInfo(CreditRequestParam<String> requestParam) {
        logger.info("queryEntInfo begin", JSONObject.toJSONString(requestParam));
        CreditResponseData<EntInfo> creditResponseData = new CreditResponseData<EntInfo>();
        try {
            if (requestParam == null || StringUtil.isEmpty(requestParam.getParam())) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("queryEntInfo error, requestParam is null");
                return creditResponseData;
            }
            String entName = requestParam.getParam();
            EntInfo queryResult = creditMerchantLogoService.queryEntInfo(entName.trim(), requestParam);
            if (queryResult != null && StringUtil.isNotEmpty(queryResult.getOrgId())) {
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(queryResult);
            } else {
                creditResponseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
                creditResponseData.setCode(ResponseMessage.NOT_EXIST.name());
                creditResponseData.setSuccess(false);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            logger.info("queryEntInfo finished,response:{} ", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }


    @Override
    public CreditResponseData<CreateReportResponse> singleTrade(CreditRequestParam<SingleCreateReportParam> requestParam) {

        logger.info("singleTrade begin,param:{}", JSONObject.toJSONString(requestParam));
        CreditResponseData creditResponseData = new CreditResponseData();
        CreateReportResponse result = new CreateReportResponse();

        try {
            if (requestParam == null || requestParam.getParam() == null || StringUtil.isEmpty(requestParam.getParam().getReportSpeed()) || StringUtil.isEmpty(requestParam.getParam().getOrgId())) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("singleTrade error, requestParam is null");
                return creditResponseData;
            }
            Date expectedPackageTime = null;
            // 调接口下单
            Date now = new Date();
            result.setCreateOrderTime(now);
            OrderInfo order = creditMerchantLogoService.gladTrade(requestParam.getParam().getOrgId(), requestParam.getParam().getReportSpeed(), requestParam);
            // 入库
            if (order != null) {
                logger.info("singleTrade create order success,save to database");
                try {
                    Date beginTime = getBeginTime(now);
                    result.setActualcreateOrderTime(beginTime);
                    expectedPackageTime = creditMerchantLogoService.saveSingleBatchAndOrder(order, requestParam.getParam(), beginTime, now);
                } catch (Exception e) {
                    logger.info(e.getMessage());
                }
                if (expectedPackageTime == null) {
                    //TODO 退单
                }
                result.setExpectedPackageTime(expectedPackageTime);
            } else {
                logger.info("singleTrade create order-[creditMerchantLogoService.gladTrade()] failed");
            }
            if (expectedPackageTime != null) {
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(result);
            } else {
                creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
                creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
                creditResponseData.setSuccess(false);
            }
        } catch (Exception e) {
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
            logger.error(e.getMessage(), e);
        } finally {
            logger.info("singleTrade finished,response:{}", JSONObject.toJSONString(creditResponseData));
        }

        return creditResponseData;
    }

    private Date getBeginTime(Date reqTime) {
        Calendar c = Calendar.getInstance();
        c.setTime(reqTime);
        if (c.get(Calendar.HOUR_OF_DAY) >= 11) {
            c.set(Calendar.DAY_OF_MONTH, c.get(Calendar.DAY_OF_MONTH) + 1);
        }
        try {
            String today = DateFormatUtils.format(c.getTime(), "yyyyMMdd");
            Response<String> response = null;
            try {
                response = fundPaymentCutDayFacade.queryWorkDay(today);
            } catch (Exception e) {
                logger.error("查询日切异常" + e.getMessage(), e);
            }
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            if (response != null) {
                return sdf.parse(response.getData());
            }
        } catch (ParseException e) {
            logger.error(e.getMessage(), e);
        }
        return c.getTime();
    }

    @Override
    public CreditResponseData<BatchEntVerifyResonse> batchEntVerify(CreditRequestParam<List<String>> requestParam) {
        logger.info("batchEntVerify begin,param:{}", JSONObject.toJSONString(requestParam));
        CreditResponseData<BatchEntVerifyResonse> creditResponseData = new CreditResponseData<BatchEntVerifyResonse>();
        BatchEntVerifyResonse reponse = new BatchEntVerifyResonse();
        try {
            if (requestParam == null || CollectionUtils.isEmpty(requestParam.getParam())) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("batchEntVerify error, requestParam is null");
                return creditResponseData;
            }
            List<String> entNames = requestParam.getParam();
            List<EntInfo> succEntList = new ArrayList<EntInfo>();
            List<EntInfo> failEntList = new ArrayList<EntInfo>();
            for (String entName : entNames) {
                EntInfo queryResult = creditMerchantLogoService.queryEntInfo(entName, requestParam);
                if (queryResult != null && StringUtil.isNotEmpty(queryResult.getOrgId())) {
                    succEntList.add(queryResult);
                } else {
                    failEntList.add(queryResult);
                }
            }
            repeatVerify(succEntList, failEntList);
            reponse.setFailEntList(failEntList);
            reponse.setSuccEntList(succEntList);

            creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
            creditResponseData.setCode(ResponseMessage.SUCCESS.name());
            creditResponseData.setSuccess(true);
            creditResponseData.setData(reponse);

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            logger.info("batchEntVerify finished,response:{} ", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }

    /**
     * 重复校验
     */
    private void repeatVerify(List<EntInfo> succEntList, List<EntInfo> failEntList) {
        Set<String> entNameSet = new HashSet<String>();
        Iterator<EntInfo> it = succEntList.iterator();
        while (it.hasNext()) {
            EntInfo entInfo = it.next();
            if (entNameSet.contains(entInfo.getOrgName())) {
                entInfo.setFailReason("重复");
                failEntList.add(entInfo);
                it.remove();
            } else {
                entNameSet.add(entInfo.getOrgName());
            }
        }
    }

    @Override
    public CreditResponseData<CreateReportResponse> batchTrade(CreditRequestParam<BatchCreateReportParam> requestParam) {
        logger.info("batchTrade begin,param:{}", JSONObject.toJSONString(requestParam));
        CreditResponseData creditResponseData = new CreditResponseData();
        CreateReportResponse result = new CreateReportResponse();
        try {
            if (requestParam == null || requestParam.getParam() == null || StringUtil.isEmpty(requestParam.getParam().getReportSpeed()) || CollectionUtils.isEmpty(requestParam.getParam().getEntInfos())) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("batchTrade error, requestParam is null");
                return creditResponseData;
            }
            Date expectedPackageTime = null;
            Date now = new Date();
            result.setCreateOrderTime(now);
            logger.info("batchTrade save to database");
            Map<String, Object> map = null;
            try {
                Date beginTime = getBeginTime(now);
                result.setActualcreateOrderTime(beginTime);
                map = creditMerchantLogoService.saveBatchAndOrder(requestParam.getParam(), beginTime, now);
            } catch (Exception e) {
                logger.info(e.getMessage());
            }
            result.setExpectedPackageTime((Date) map.get("expectedPackageTime"));
            logger.info("异步调用格兰德下单接口");
            creditMerchantLogoService.batchGladTrade(requestParam.getParam(), requestParam.getParam().getReportSpeed(), (String) map.get("batchNo"), requestParam);

            if (map.get("expectedPackageTime") != null) {
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(result);
            } else {
                creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
                creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
                creditResponseData.setSuccess(false);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            logger.info("batchTrade finished,response:{}", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }

    @Override
    public CreditResponseData<StandardReportBatchResponse> batchQuery(CreditRequestParam<BatchQueryParam> requestParam) {
        logger.info("batchQuery begin,param:{}", JSONObject.toJSONString(requestParam));
        CreditResponseData<StandardReportBatchResponse> creditResponseData = new CreditResponseData<StandardReportBatchResponse>();
        StandardReportBatchResponse response = new StandardReportBatchResponse();
        try {
            if (requestParam == null || requestParam.getParam() == null) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("batchQuery error, requestParam is null");
                return creditResponseData;
            }
            List<StandardReportBatch> queryResult = creditMerchantLogoService.batchQuery(requestParam.getParam());
            Integer totalCount = creditMerchantLogoService.batchCountQuery(requestParam.getParam());
            response.setList(queryResult);
            response.setTotalCount(totalCount);
            if (null != queryResult) {
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(response);
            } else {
                creditResponseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
                creditResponseData.setCode(ResponseMessage.NOT_EXIST.name());
                creditResponseData.setSuccess(false);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            logger.info("batchQuery finished,response:{} ", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }

    @Override
    public CreditResponseData createReport(CreditRequestParam<String> requestParam) {
        logger.info("createReport begin", JSONObject.toJSONString(requestParam));
        CreditResponseData creditResponseData = new CreditResponseData();
        try {
            if (requestParam == null || StringUtil.isEmpty(requestParam.getParam())) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("createReport error, requestParam is null");
                return creditResponseData;
            }
            CreditStandardReport standardReport = creditStandardReportDao.queryMerchantByOrder(requestParam.getParam());
            if (standardReport != null && standardReport.getLimitResTime() != null) {
                Date limitResTime = standardReport.getLimitResTime();
                if (limitResTime.before(new Date())) {
                    creditResponseData.setMessage("已超过最后截止时间");
                    creditResponseData.setCode("OVER_TIME");
                    creditResponseData.setSuccess(false);
                    logger.error("已超过最后截止时间:", limitResTime);
                    return creditResponseData;
                }

                logger.info("query status begin");
                OrderInfo orderInfo = creditMerchantLogoService.queryStatus(requestParam.getParam(), standardReport.getMerchantNo(),standardReport.getMerchantName(),requestParam);
                if (orderInfo != null) {
                    //如果被退回修改状态、remark等
                    CreditStandardReport report = new CreditStandardReport();
                    GladReportStatusEnum.getByCode(orderInfo.getStatus());
                    report.setRemark(orderInfo.getRemark());
                    report.setResTime(new Date());
                    report.setOrderId(orderInfo.getOrderId());

                    Integer result = creditStandardReportDao.updateReportByOrderId(report);
                    logger.debug(result + "");
                    //异步生成报告
                    //if (GladReportStatusEnum.FINISHED == report.getStatus()) {
                    logger.info("订单：{} 已完成，异步生成报告", report.getOrderId());
                    creditMerchantLogoService.createReport(requestParam.getParam(), standardReport.getMerchantNo(),standardReport.getMerchantName(),requestParam);
                    //}
                    //订单被退回修改批次进度
                    if (GladReportStatusEnum.RETURNED_BACK == report.getStatus()) {
                        logger.info("订单：{} 被退回，修改批次进度", report.getOrderId());
                        creditMerchantLogoService.updateBatchStatus(standardReport.getBatchNo(), null);
                    }
                    creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                    creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                    creditResponseData.setSuccess(true);
                } else {
                    creditResponseData.setMessage("订单状态错误");
                    creditResponseData.setCode("STATUS_ERROR");
                    creditResponseData.setSuccess(false);
                }
            } else {
                logger.error("订单不存在");
                creditResponseData.setMessage("订单不存在");
                creditResponseData.setCode("ORDER_NOT_EXIST");
                creditResponseData.setSuccess(false);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            logger.info("createReport finished,response:{} ", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }

    @Override
    public CreditResponseData updateAuthFile(CreditRequestParam<BatchCreateReportParam> requestParam) {
        logger.info("updateAuthFile begin,param:{}", JSONObject.toJSONString(requestParam));
        CreditResponseData<StandardReportBatchResponse> creditResponseData = new CreditResponseData<StandardReportBatchResponse>();
        try {
            if (requestParam == null || requestParam.getParam() == null) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("updateAuthFile error, requestParam is null");
                return creditResponseData;
            }
            int result = creditMerchantLogoService.updateAuthFile(requestParam.getParam());

            if (result == 1) {
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
            } else {
                creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
                creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
                creditResponseData.setSuccess(false);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            logger.info("updateAuthFile finished,response:{} ", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }

    @Override
    public CreditResponseData reCreateOrder(CreditRequestParam<String> requestParam) {
        logger.info("reCreateOrder begin,param:{}", JSONObject.toJSONString(requestParam));
        CreditResponseData creditResponseData = new CreditResponseData();
        CreateReportResponse result = new CreateReportResponse();
        try {
            if (requestParam == null || StringUtil.isEmpty(requestParam.getParam())) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("reCreateOrder error, requestParam is null");
                return creditResponseData;
            }
            // 调接口下单
            Date now = new Date();
            result.setCreateOrderTime(now);
            boolean flag = creditMerchantLogoService.reCreateOrder(requestParam.getParam(), requestParam);
            if (flag) {
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(result);
            } else {
                creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
                creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
                creditResponseData.setSuccess(false);
            }
        } catch (Exception e) {
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
            logger.error(e.getMessage(), e);
        } finally {
            logger.info("reCreateOrder finished,response:{}", JSONObject.toJSONString(creditResponseData));
        }

        return creditResponseData;
    }


    @Override
    public CreditResponseData<StandardReportResponse> reportQuery(CreditRequestParam<BatchReportQueryParam> requestParam) {
        logger.info("根据订单号查询订单信息,请求参数：{}", JSONObject.toJSONString(requestParam));
        CreditResponseData<StandardReportResponse> response = new CreditResponseData<StandardReportResponse>();
        try {
            if (requestParam != null) {
                StandardReportResponse page = new StandardReportResponse();
                List<CreditStandardReport> report = creditStandardReportDao.queryReportPage(requestParam.getParam());
                page.setList(report);
                int totalCount = creditStandardReportDao.queryReportTotalCount(requestParam.getParam());
                page.setTotalCount(totalCount);
                response.setData(page);
            } else {
                logger.error("请求参数为空");
                response.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
                response.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            response.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            response.setCode(ResponseMessage.SYSTEM_ERROR.name());
            response.setSuccess(false);
        }
        logger.info("返回结果：{}", JSONObject.toJSONString(response));
        return response;
    }


}
