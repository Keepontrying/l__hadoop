package com.jd.jr.boss.credit.authen.core.enums;

import java.util.LinkedHashMap;
import java.util.Map;


/** 
* @desciption : 车贷对应key
* @author : yangjinlin@jd.com
* @date ：2018年3月7日 下午6:09:25 
* @version 1.0 
* @return  */
public enum CarlonProductCommonEnum {
    ENTERPRISE_PUNISHBREAK_QUERY(1, "ENT_PUNISHBREAK_QUERY", "失信被执行人"),//企业失信被执行信息
    ENTERPRISE_PUNISHED_QUERY(2, "ENT_PUNISHED_QUERY", "被执行人信息"),
    ENTERPRISE_LAWSUITINFO_QUERY(3, "ENT_LAWSUITINFO_QUERY", "法院裁判文书"),//法院裁判信息
    ENTERPRISE_PERSONNALBLACK_QUERY(4, "ENT_PERSONAL_BLACK", "小白信用黑名单"),
    ENTERPRISE_CHECKINFO_QUERY(5, "ENT_CHECK_INFO", "抽查检查"),
    ENTERPRISE_EQUITYINFO_QUERY(6, "ENT_EQUITY_INFO", "股权质押"),//股权质押信息
    ENTERPRISE_ILLEGALINFO_QUERY(7, "ENT_ILLEGAL_INFO", "企业严重违法"),//企业严重违法信息
    ENTERPRISE_MORTGAGEINFO_QUERY(8, "ENT_MORTGAGE_INFO", "动产抵押"),//动产抵押信息
    ENTERPRISE_MAJOR_TAX_VIOLATION(9,"ENT_MAJOR_TAX_VIOLATION","重大税收违法查询"),//重大税收违法信息
    ENTERPRISE_ABNORMAL_QUERY(12,"ENT_ABNORMAL_QUERY","列入经营异常名单查询"),
    ENTERPRISE_PUNISHMENT_QUERY(13,"ENT_PUNISHMENT_QUERY","行政处罚查询"),
    ENTERPRISE_PUNISHED_PERSON_QUERY(14, "ENT_PUNISHED_PERSON_QUERY", "个人被执行人信息"),
    ENTERPRISE_PUNISHBREAK_PERSON_QUERY(15, "ENT_PUNISHBREAK_PERSON_QUERY", "个人失信被执行人"),
    ENTERPRISE_PER_LAWSUITINFO_QUERY(16, "ENT_PER_LAWSUITINFO_QUERY", "个人法院裁判文书"),//个人法院裁判信息
    ;
    private Integer code;
    private String name;
    private String description;

    /**
     * @param description 中文描述
     */
    private CarlonProductCommonEnum(String description) {
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param description 中文描述
     */
    private CarlonProductCommonEnum(Integer code, String description) {
        this.code = code;
        this.description = description;
    }

    /**
     * @param name        英文编码名称
     * @param description 中文描述
     */
    private CarlonProductCommonEnum(String name, String description) {
        this.name = name;
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param name        英文编码名称
     * @param description 中文描述
     */
    private CarlonProductCommonEnum(Integer code, String name, String description) {
        this.code = code;
        this.name = name;
        this.description = description;
    }


    /**
     * 获取枚举类型数值编码
     */
    public Integer toCode() {
        return this.code == null ? this.ordinal() : this.code;
    }

    /**
     * 获取枚举类型英文编码名称
     */
    public String toName() {
        return this.name == null ? this.name() : this.name;
    }

    /**
     * 获取枚举类型中文描述
     */
    public String toDescription() {
        return this.description;
    }

    /**
     * 获取枚举类型中文描述
     */
    public String toString() {
        return this.description;
    }

    /**
     * 按数值获取对应的枚举类型
     * @param code 数值
     * @return 枚举类型
     */
    public static CarlonProductCommonEnum enumValueOf(Integer code) {
        CarlonProductCommonEnum[] values = CarlonProductCommonEnum.values();
        CarlonProductCommonEnum v = null;
        for (int i = 0; i < values.length; i++) {
            if (code != null && code.equals(values[i].toCode())) {
                v = values[i];
                break;
            }
        }
        return v;
    }
    /**
     * 按英文编码获取对应的枚举类型
     *
     * @param name 英文编码
     * @return 枚举类型
     */
    public static CarlonProductCommonEnum enumValueOf(String name) {
        CarlonProductCommonEnum[] values = CarlonProductCommonEnum.values();
        CarlonProductCommonEnum v = null;
        for (int i = 0; i < values.length; i++) {
            if (name != null && name.equalsIgnoreCase(values[i].toName())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 获取枚举类型的所有<数字编码,中文描述>对
     *
     * @return
     */
    public static Map<Integer, String> toCodeDescriptionMap() {
        LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
        for (int i = 0; i < CarlonProductCommonEnum.values().length; i++) {
            if (CarlonProductCommonEnum.values()[i] != null) {
                map.put(CarlonProductCommonEnum.values()[i].toCode(), CarlonProductCommonEnum.values()[i].toDescription());
            }
        }
        return map;
    }

    /**
     * 获取枚举类型的所有<英文编码名称,中文描述>对
     *
     * @return
     */
    public static Map<String, String> toNameDescriptionMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        for (int i = 0; i < CarlonProductCommonEnum.values().length; i++) {
            if (CarlonProductCommonEnum.values()[i] != null) {
                map.put(CarlonProductCommonEnum.values()[i].toName(), CarlonProductCommonEnum.values()[i].toDescription());
            }
        }
        return map;
    }
    
}
