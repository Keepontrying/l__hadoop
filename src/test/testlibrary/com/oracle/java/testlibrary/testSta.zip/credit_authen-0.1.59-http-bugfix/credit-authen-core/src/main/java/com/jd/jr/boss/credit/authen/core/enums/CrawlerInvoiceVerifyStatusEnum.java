package com.jd.jr.boss.credit.authen.core.enums;

import com.jd.jr.boss.credit.domain.common.enums.CreditMiniStatusEnum;

/**
 * Created by anmeng on 2017/8/25.
 */
public enum CrawlerInvoiceVerifyStatusEnum {
    
	SUCCESS("001","SUCCESS","成功"),
    VERIFY_EXCEED("002","VERIFY_EXCEED","超过该张发票当日查验次数"),
    //    VERIFY_FREQUENTLY("003","VERIFY_FREQUENTLY","发票查验请求太频繁"),
//    REQUEST_EXCEED("004","REQUEST_EXCEED","超过服务器最大请求数"),
//    BAD_REQUEST("005","BAD_REQUEST","请求不合法"),
    INCONFORMITY("006","INCONFORMITY","不一致"),
    INVALID_VERIFY_CODE("007","INVALID_VERIFY_CODE","验证码失效"),
    WRONG_VERIFY_CODE("008","WRONG_VERIFY_CODE","验证码错误"),
    NO_INVOICE("009","NO_INVOICE","查无此票"),
    //    NET_TIME_OUT("010","NET_TIME_OUT","网络超时"),
//    UNUSUAL_VERIFY("020","UNUSUAL_VERIFY","查验行为异常"),
    TODAY_INVOICE("rqerr","TODAY_INVOICE","当日开具发票"),
    SYSTEM_ERROR("","SYSTEM_ERROR","查询失败");

    private String code;
    private String name;
    private String description;

    CrawlerInvoiceVerifyStatusEnum(){
    }

    CrawlerInvoiceVerifyStatusEnum(String code,String name,String description){
        this.code=code;
        this.name=name;
        this.description=description;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public static CrawlerInvoiceVerifyStatusEnum enumValueOf(String code) {
        CrawlerInvoiceVerifyStatusEnum[] values = CrawlerInvoiceVerifyStatusEnum.values();
        CrawlerInvoiceVerifyStatusEnum v = SYSTEM_ERROR;
        for (int i = 0; i < values.length; i++) {
            if (code != null && code.equals(values[i].getCode())) {
                v = values[i];
                break;
            }
        }
        return v;
    }
    
    /**
     * 按英文编码获取对应的枚举类型
     *
     * @param name 英文编码
     * @return 枚举类型
     */
    public static CrawlerInvoiceVerifyStatusEnum enumValueOfByDesc(String description) {
    	CrawlerInvoiceVerifyStatusEnum[] values = CrawlerInvoiceVerifyStatusEnum.values();
    	CrawlerInvoiceVerifyStatusEnum v = SYSTEM_ERROR;
        for (int i = 0; i < values.length; i++) {
            if (description != null && description.equalsIgnoreCase(values[i].getDescription())) {
                v = values[i];
                break;
            }
        }
        return v;
    }
    
}
