package com.jd.jr.boss.credit.authen.core.beans.request;

import com.jd.jr.boss.credit.facade.authen.beans.param.MainOrderQueryParam;
import com.wangyin.operation.common.beans.PageQuery;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by anmeng on 2017/3/22.
 */
public class OrderMainQueryParam extends PageQuery implements Serializable {
    private static final long serialVersionUID = -8477666994209588307L;

    private Integer orderMainId;//主订单ID

    private String orderStatus;//订单状态

    private String merchantNo;//商户号
    private String merchantName;//商户名称

    private Date beginTime;//开始时间
    private Date endTime;//结束时间

    private String orderMainNo;//订单号

    private String orderSource;//订单来源

    private String contractNo;//合同编号

    private String paymentStartTime;//缴费时间
    private String paymentEndTime;//缴费时间

    private List<String> payTypeList;//缴费方式
    private List<String> merchantClassifyList;// 商户分类
    private String signStatus;// 签约状态  yes-已签约；no-未签约
    private String merchantClassify;// 商户分类
    public OrderMainQueryParam(){

    }

    public OrderMainQueryParam(MainOrderQueryParam queryParam){
        this.beginTime=queryParam.getBeginTime();
        this.contractNo=queryParam.getContractNo();
        this.endTime=queryParam.getEndTime();
        this.merchantName=queryParam.getMerchantName();
        this.merchantNo=queryParam.getMerchantNo();
        this.orderMainId=queryParam.getOrderMainId();
        this.orderMainNo=queryParam.getOrderMainNo();
        this.orderSource=queryParam.getOrderSource();
        this.orderStatus=queryParam.getOrderStatus();
        this.merchantClassifyList=queryParam.getMerchantClassifyList();
        this.merchantClassify=queryParam.getMerchantClassify();
        this.setStart(queryParam.getStart());
        this.setLimit(queryParam.getLimit());
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public Date getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(Date beginTime) {
        this.beginTime = beginTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getOrderMainNo() {
        return orderMainNo;
    }

    public void setOrderMainNo(String orderMainNo) {
        this.orderMainNo = orderMainNo;
    }

    public String getOrderSource() {
        return orderSource;
    }

    public void setOrderSource(String orderSource) {
        this.orderSource = orderSource;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public Integer getOrderMainId() {
        return orderMainId;
    }

    public void setOrderMainId(Integer orderMainId) {
        this.orderMainId = orderMainId;
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public String getPaymentStartTime() {
        return paymentStartTime;
    }

    public void setPaymentStartTime(String paymentStartTime) {
        this.paymentStartTime = paymentStartTime;
    }

    public String getPaymentEndTime() {
        return paymentEndTime;
    }

    public void setPaymentEndTime(String paymentEndTime) {
        this.paymentEndTime = paymentEndTime;
    }

    public List<String> getPayTypeList() {
        return payTypeList;
    }

    public void setPayTypeList(List<String> payTypeList) {
        this.payTypeList = payTypeList;
    }

    public List<String> getMerchantClassifyList() {
        return merchantClassifyList;
    }

    public void setMerchantClassifyList(List<String> merchantClassifyList) {
        this.merchantClassifyList = merchantClassifyList;
    }

    public String getSignStatus() {
        return signStatus;
    }

    public void setSignStatus(String signStatus) {
        this.signStatus = signStatus;
    }

    public String getMerchantClassify() {
        return merchantClassify;
    }

    public void setMerchantClassify(String merchantClassify) {
        this.merchantClassify = merchantClassify;
    }
}
