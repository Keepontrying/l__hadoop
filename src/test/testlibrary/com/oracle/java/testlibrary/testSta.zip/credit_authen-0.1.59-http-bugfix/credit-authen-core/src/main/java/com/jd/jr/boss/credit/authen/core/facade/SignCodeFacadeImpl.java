package com.jd.jr.boss.credit.authen.core.facade;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.jd.jr.boss.credit.authen.core.constants.HspConstant;
import com.jd.jr.boss.credit.authen.core.exception.CreditSignCodeException;
import com.jd.jr.boss.credit.authen.core.service.SignCodeInfoService;
import com.jd.jr.boss.credit.authen.core.service.SignCodeService;
import com.jd.jr.boss.credit.authen.core.utils.CsvUtil;
import com.jd.jr.boss.credit.authen.core.utils.SFTPClient;
import com.jd.jr.boss.credit.domain.common.entity.signcode.CreditSignCode;
import com.jd.jr.boss.credit.domain.common.entity.signcode.CreditSignCodeInfo;
import com.jd.jr.boss.credit.facade.authen.api.CreditSignCodeFacade;
import com.jd.jr.boss.credit.facade.authen.beans.signCode.SignCodeUploadFileParam;
import com.jd.jr.boss.credit.facade.common.constants.SFTPConstants;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.common.utils.FileProgressMonitor;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.BatchChargeFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.ResultData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.BatchChargeParam;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.BatchChargeData;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.EnterpriseProductEnum;
import com.jd.jr.boss.credit.gateway.hsp.facade.GatewayHspUploadFileFacade;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.admin.frame.utils.SFTPUtil;
import com.wangyin.boss.credit.admin.entity.CreditUploadFile;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.hsp.client.HSPClient;
import com.wangyin.hsp.client.HSPConfig;
import com.wangyin.hsp.client.NetFile;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author huangzhiqiang
 * @data 2017/8/25
 */
@Service("signCodeFacade")
public class SignCodeFacadeImpl implements CreditSignCodeFacade {

    private static final Logger LOGGER = LoggerFactory.getLogger(SignCodeFacadeImpl.class);

    @Autowired
    private SignCodeService signCodeService;
    @Autowired
    private SignCodeInfoService signCodeInfoService;
    @Autowired
    private BatchChargeFacade batchChargeFacade;
    @Autowired
    private GatewayHspUploadFileFacade uploadFileFacade;

    /**
     * 中证码 - 用户上传文件存放路径
     */
    private static final String SIGN_CODE_PATH = "upload/signcode/user_upload/";

    @Override
    public void insert(CreditSignCode signCode) {
        if ("START".equals(signCode.getStatus())) {
            LOGGER.info(" 【中证码解析入库请求开始】");

            if (signCode.getDate().contains("年")) {
                SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd");
                Date date = null;
                try {
                    date = format.parse(signCode.getDate());
                } catch (ParseException e) {
                    LOGGER.info(" 【日期格式错误！】");
                    e.printStackTrace();
                }
                SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd");
                String newDate = format2.format(date);
                signCode.setDate(newDate);
            }
            signCodeService.insert(signCode);
            LOGGER.info("【中证码解析入库请求结束 】 " + GsonUtil.getInstance().toJson(signCode));
        }

        if ("FINISH".equals(signCode.getStatus())) {
            try {
                LOGGER.info("【中证码解析入库等待.... 】 ");
                TimeUnit.SECONDS.sleep(5);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            LOGGER.info("【中证码解析入库开始】 " + GsonUtil.getInstance().toJson(signCode));
            Long CsvStart = System.currentTimeMillis();
            //HSP
            String connectString = ConfigUtil.getString(HspConstant.HSP_CONNECT_STRING);
            Integer appId = Integer.valueOf(ConfigUtil.getString(HspConstant.HSP_PORTAL_APPID));
            String appPwd = ConfigUtil.getString(HspConstant.HSP_PORTAL_APPPWD);
            String httpServerUrl = ConfigUtil.getString(HspConstant.HSP_HTTPSERVER_URL);
            HSPConfig hspConfig = new HSPConfig(connectString, appId, appPwd);
            hspConfig.setHttpServerUrl(httpServerUrl);
            HSPClient hspClient = new HSPClient(hspConfig);
            NetFile netFile = new NetFile(hspClient);

            String filePath = ConfigUtil.getString(SFTPConstants.SFTP_PATH) + signCode.getDate().substring(0, 10).replace("-", "");
            String fileName = signCode.getFileName();
            String fileName2FTP = filePath + "/" + signCode.getFileName();
            LOGGER.info("fileName2FTP:{ " + fileName2FTP + " }, fileName:{" + fileName + " }");
            ChannelSftp chSftp = null;
            try {
                chSftp = SFTPClient.getSftp();
                //SFTP 获取文件
                SftpATTRS sftpATTRS = chSftp.lstat(fileName2FTP);
                long fileSize = sftpATTRS.getSize();
                long fileSize2 = 0L;
                while (fileSize2 != fileSize) {
                    sftpATTRS = chSftp.lstat(fileName2FTP);
                    fileSize2 = sftpATTRS.getSize();
                }

                InputStream is = chSftp.get(fileName2FTP, new FileProgressMonitor(sftpATTRS.getSize()));
                InputStream is2 = chSftp.get(fileName2FTP, new FileProgressMonitor(sftpATTRS.getSize()));

                //解析文件
                CsvUtil csvUtil = new CsvUtil();
                Integer skipRow = 1;//表头行数
                List<String[]> dataList = csvUtil.readCsv(is);
                int batchSize = dataList.size() - skipRow; //查询企业数
                List<String> codes = new ArrayList<String>();
                for (int i = skipRow; i < dataList.size(); i++) {
                    String[] strings = dataList.get(i);
                    if (StringUtils.isNotBlank(strings[1])) {
                        codes.add(strings[1]);
                    } else if (StringUtils.isNotBlank(strings[2])) {
                        codes.add(strings[2]);
                    } else if (StringUtils.isNotBlank(strings[3])) {
                        codes.add(strings[3]);
                    } else if (StringUtils.isNotBlank(strings[4])) {
                        codes.add(strings[4]);
                    } else if (StringUtils.isNotBlank(strings[6])) {
                        codes.add(strings[6]);
                    } else if (StringUtils.isNotBlank(strings[7])) {
                        codes.add(strings[7]);
                    } else if (StringUtils.isNotBlank(strings[8])) {
                        codes.add(strings[8]);
                    } else {
                        codes.add("data exception!");
                    }
                }
                LOGGER.info("【调用计费接口开始】");
                Long batchChargeStart = System.currentTimeMillis();

                CreditRequestParam<BatchChargeParam> requestParam = new CreditRequestParam<BatchChargeParam>();
                BatchChargeParam batchChargeParam = new BatchChargeParam();
                batchChargeParam.setBatchNo(signCode.getSerialNo());
                batchChargeParam.setMerchantNo(signCode.getMerchantNo());
                batchChargeParam.setBatchSize(batchSize);
                batchChargeParam.setCodes(codes);
                batchChargeParam.setProductEnum(EnterpriseProductEnum.ENTERPRISE_SIGNCODE_QUERY);
                requestParam.setParam(batchChargeParam);
                requestParam.setTradeNo(signCode.getSerialNo());
                requestParam.setSystemId(signCode.getMerchantNo());

                CreditResponseData<ResultData<BatchChargeParam, BatchChargeData>> responseData = batchChargeFacade.batchCharging(requestParam);
                if (!responseData.isSuccess()) {
                    if (!"RESULT_SERVICE_NOSTRATEGY".equals(responseData.getCode())) {
                        LOGGER.error("【调用计费接口异常】" + responseData.getCode() + "{}" + responseData.getMessage());
                        throw new CreditSignCodeException(responseData.getMessage());
                    }
                    responseData.getData().getResult().setSuccesNum(0);
                }

                BatchChargeData batchChargeData = responseData.getData().getResult();
                int succesNum = batchChargeData.getSuccesNum(); //成功扣减数量
                LOGGER.info("【成功扣减数量】" + succesNum);
                Long batchChargeEnd = System.currentTimeMillis();
                LOGGER.info("【调用计费接口结束,花费时间】" + (batchChargeEnd - batchChargeStart));

                LOGGER.info("【上传HSP开始】" + filePath);
                Long hspStart = System.currentTimeMillis();
                String resultFid = uploadFile2HSP(hspClient, netFile, fileName, filePath, succesNum, is2);
                Long hspEnd = System.currentTimeMillis();
                LOGGER.info("【上传HSP结束，花费时间】" + (hspEnd - hspStart));

                CreditUploadFile uploadFile = new CreditUploadFile();
                uploadFile.setFileName(fileName);
                uploadFile.setResultFid(resultFid);
                uploadFile.setFileType("SIGN_CODE");
                String merchantNo = signCode.getMerchantNo();
                uploadFile.setCreator(merchantNo);
                uploadFile.setModifier(merchantNo);

                int fileId = signCodeService.uploadFileInsert(uploadFile);

                signCode.setFileId(String.valueOf(fileId));
                signCode.setCount(batchSize);
                signCode.setFileName(signCode.getFileName());
                int batchId = signCodeService.insert(signCode);

                CreditSignCodeInfo signCodeInfo;
                for (int i = skipRow; i <= batchSize; i++) {
                    signCodeInfo = new CreditSignCodeInfo();
                    signCodeInfo.setBatchId(batchId);
                    String[] data = dataList.get(i);
                    if (data.length == 0 || StringUtil.isBlank(data[0].trim())) {
                        continue;
                    }

                    if (data.length < 9) {
                        LOGGER.error("【数据质量问题】" + GsonUtil.getInstance().toJson(signCode) + "【行号】" + data[0]);
                        continue;
                    }

                    // 企业名称
                    if ("--/--".equals(data[1].trim()) || "".equals(data[1].trim())) {
                        signCodeInfo.setEntNameCN("");
                        signCodeInfo.setEntNameEN("");
                    } else {
                        String[] entName = data[1].trim().split("/");
                        if ("--".equals(entName[0].trim()) || "".equals(entName[0].trim())) {
                            signCodeInfo.setEntNameCN("");
                        } else {
                            signCodeInfo.setEntNameCN(entName[0].trim());
                        }
                        signCodeInfo.setEntNameEN("");
                    }

                    // 机构信用代码
                    if ("--".equals(data[2].trim())) {
                        signCodeInfo.setCreditCode("");
                    } else {
                        signCodeInfo.setCreditCode(data[2].trim());
                    }

                    // 组织机构代码
                    if ("--".equals(data[3].trim())) {
                        signCodeInfo.setOrgNo("");
                    } else {
                        signCodeInfo.setOrgNo(data[3].trim());
                    }

                    //中证码
                    if ("--".equals(data[4].trim())) {
                        signCodeInfo.setSignCode("");
                        signCodeInfo.setStatus(0);//查询失败
                        signCodeInfo.setIsExist(-1);
                    } else if ("".equals(data[4].trim())) {
                        signCodeInfo.setStatus(0);//查询失败
                        signCodeInfo.setIsExist(-1);
                    } else {
                        signCodeInfo.setSignCode(data[4].trim());
                        if (i > succesNum) {
                            signCodeInfo.setStatus(2);//余额不足
                        } else {
                            signCodeInfo.setStatus(1);
                        }
                        signCodeInfo.setIsExist(0);
                    }

                    //登记注册号类型
                    if ("--".equals(data[5].trim())) {
                        signCodeInfo.setRegType("");
                    } else {
                        signCodeInfo.setRegType(data[5].trim());
                    }

                    //登记注册号
                    if ("--".equals(data[6].trim())) {
                        signCodeInfo.setRegNo("");
                    } else {
                        signCodeInfo.setRegNo(data[6].trim());
                    }

                    //纳税人识别号（国税）
                    if ("--".equals(data[7].trim())) {
                        signCodeInfo.setTaxNoNational("");
                    } else {
                        signCodeInfo.setTaxNoNational(data[7].trim());
                    }

                    //纳税人识别号（地税）
                    if ("--".equals(data[8].trim())) {
                        signCodeInfo.setTaxNoLand("");
                    } else {
                        signCodeInfo.setTaxNoLand(data[8].trim());
                    }

                    signCodeInfo.setCreator(merchantNo);
                    DateTimeFormatter format = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:SS");
                    DateTime date = DateTime.parse(signCode.getDate(), format);
                    signCodeInfo.setCreatedDate(date.toDate());
                    signCodeInfoService.insert(signCodeInfo);
                }
                Long CsvEnd = System.currentTimeMillis();
                LOGGER.info("【中证码解析入库结束，花费时间】" + (CsvEnd - CsvStart));
            } catch (JSchException e) {
                LOGGER.error("【连接服务器失败】" + e.getMessage());
                e.printStackTrace();
            } catch (SftpException e) {
                LOGGER.error("【传输文件失败】" + e.getMessage());
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                SFTPUtil.close(chSftp);
            }

        }

    }

    @Override
    public boolean uploadFile2FTP(CreditRequestParam<SignCodeUploadFileParam> requestParam) {
        boolean flag = false;
        SignCodeUploadFileParam uploadFile = requestParam.getParam();

        String fileName = uploadFile.getMerchantNo() + "_" + System.currentTimeMillis() + "_" + uploadFile.getFileName();
        String startFileName = "start_" + fileName;
        ChannelSftp sftp = null;
        try {
            sftp = SFTPClient.getSftp();
            LOGGER.info("【sftp 成功,上传SFTP开始】");
            String finalPath = SIGN_CODE_PATH + DateTime.now().toString("yyyyMMdd");
            Long sftpStart = System.currentTimeMillis();
            ByteArrayInputStream is = new ByteArrayInputStream(uploadFile.getByteArry());
            flag = SFTPUtil.upload(sftp, finalPath, fileName, is);
            Long sftpEnd = System.currentTimeMillis();
            LOGGER.info("【上传SFTP结束，花费时间】" + (sftpEnd - sftpStart));
            if (flag) {
                ChannelSftp sftp1 = SFTPClient.getSftp();
                sftp1.rename(finalPath + "/" + fileName, finalPath + "/" + startFileName);
                SFTPUtil.close(sftp1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            SFTPUtil.close(sftp);
            LOGGER.info("【上传SFTP成功】" + fileName);
        }
        return flag;
    }

    /**
     * 上传文件到HSP
     *
     * @param inStream
     * @return
     * @throws IOException
     */
    private String uploadFile2HSP(HSPClient hspClient, NetFile netFile, String fileName, String filePath, int succesNum, InputStream inStream)
            throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(inStream, "GBK"));
        StringBuffer sb = new StringBuffer();
        String line;
        int count = 0;
        while ((line = reader.readLine()) != null) {
            if (count > succesNum) {
                String[] linearry = line.split(",");
                for (int i = 4; i < linearry.length; i++) {
                    linearry[i] = "--";
                }
                line = StringUtils.join(linearry, ",");
            }
            sb.append(line);
            sb.append("\n");
            count++;
        }
        reader.close();
        inStream.close();
        return uploadFileFacade.uploadFileHsp(hspClient, netFile, fileName, filePath, sb.toString().getBytes("GBK"));
    }

}
