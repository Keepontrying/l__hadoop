package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.request.DownloadFileQueryParam;
import com.jd.jr.boss.credit.domain.common.entity.CreditDownloadFile;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by anmeng on 2016/12/14.
 */
@Repository
public interface CreditDownloadFileDao {
    /**
     *新增预约下载文件
     * @param creditDownloadFile
     * @return
     */
    Integer createDownloadFile(CreditDownloadFile creditDownloadFile);

    /**
     *查询预约下载文件
     * @param downloadFileQueryParam
     * @return
     */
    List<CreditDownloadFile> queryDownloadFile(DownloadFileQueryParam downloadFileQueryParam);

    /**
     * 查询预约下载文件记录数
     * @param downloadFileQueryParam
     * @return
     */
    Integer queryDownloadFileCount(DownloadFileQueryParam downloadFileQueryParam);

    /**
     * 更新预约文件处理状态
     * @param creditDownloadFile
     * @return
     */
    Integer updateDownloadFileStatus(CreditDownloadFile creditDownloadFile);
}
