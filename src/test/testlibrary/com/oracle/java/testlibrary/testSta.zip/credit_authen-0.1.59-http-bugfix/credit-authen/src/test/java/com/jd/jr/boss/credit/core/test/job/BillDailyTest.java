package com.jd.jr.boss.credit.core.test.job;

import com.alibaba.fastjson.JSON;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.AntiMoneyLaunderFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.ResultData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.CdAntiMoneyLaunderParam;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.antiMoneyLaunder.chinaData.ChinaDataAntiMoneyLaunderResp;
import com.jd.jr.boss.credit.gateway.account.utils.SerialNoUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.jd.jr.boss.credit.authen.core.scheduler.DailyBillJop;

import javax.annotation.Resource;

/**
 * 
 * <ul>
 * <li>1、开发日期：2017年12月22日</li>
 * <li>2、开发时间：下午4:25:17</li>
 * <li>3、作 者：zhanghui12</li>
 * <li>4、类型名称：BillDailyTest</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/spring-authen.xml" })

public class BillDailyTest {

	@Autowired
	private DailyBillJop dailyBillJob;

	@Test
	public void testJob() throws Exception {
		dailyBillJob.doJob(null);
	}

}
