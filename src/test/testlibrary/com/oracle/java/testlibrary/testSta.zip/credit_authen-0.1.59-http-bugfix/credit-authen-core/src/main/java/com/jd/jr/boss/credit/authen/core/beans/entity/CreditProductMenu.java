package com.jd.jr.boss.credit.authen.core.beans.entity;

import com.jd.jr.boss.credit.authen.core.enums.CreditProductChildMenuEnum;
import com.jd.jr.boss.credit.authen.core.enums.CreditProductMenuEnum;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.EnterpriseProductEnum;
import com.jd.jr.boss.credit.facade.external.beans.entity.CreditProductMenuEntity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/**
 *
 * 信用服务菜单
 * @author jiangbo
 * @since 2017/8/23
 */
public class CreditProductMenu implements Serializable {
    private static final long serialVersionUID = -989482322235122611L;
    public LinkedHashMap<String, CreditProductMenuEntity> menu = new LinkedHashMap<String, CreditProductMenuEntity>();

    public CreditProductMenu(){
        this.identificationMenuEntity();
        this.negativeMenuEntity();
        this.judicialMenuEntity();
//        this.annualMenuEntity();
        this.intellectualMenuEntity();

    }

    /**
     * 企业概况
     */
    private void identificationMenuEntity(){
        //企业概况
        CreditProductMenuEntity identificationMenuEntity = new CreditProductMenuEntity();
        identificationMenuEntity.setDisplayName(CreditProductMenuEnum.ENT_ENTERPRISE_PROFILE.toDescription());
        identificationMenuEntity.setCode(CreditProductMenuEnum.ENT_ENTERPRISE_PROFILE.toName());
        identificationMenuEntity.setMenuLevel(1);  //一级
        identificationMenuEntity.setIconCode(CreditProductMenuEnum.ENT_ENTERPRISE_PROFILE.toName());
        menu.put(CreditProductMenuEnum.ENT_ENTERPRISE_PROFILE.toName(),identificationMenuEntity);

        ArrayList<CreditProductMenuEntity> identificationSubMenu = new ArrayList<CreditProductMenuEntity>();
        identificationMenuEntity.setSubMenu(identificationSubMenu); //set企业概况的子菜单

        //工商基本信息
        CreditProductMenuEntity basicMenuEntity = new CreditProductMenuEntity();
        basicMenuEntity.setDisplayName("工商信息");
        basicMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_BASIC_QUERY.toName());
        basicMenuEntity.setMenuLevel(2);
        basicMenuEntity.setParentCode(CreditProductMenuEnum.ENT_ENTERPRISE_PROFILE.toName());
        basicMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t13606/236/167424191/6972/5f8fc4af/5a051210Nc303809f.png");
        identificationSubMenu.add(basicMenuEntity);
//        menu.add(basicMenuEntity);
        menu.put(EnterpriseProductEnum.ENTERPRISE_BASIC_QUERY.toName(),basicMenuEntity);

        //历史沿革
        CreditProductMenuEntity alterMenuEntity = new CreditProductMenuEntity();
        alterMenuEntity.setDisplayName(CreditProductChildMenuEnum.ENT_ALTER_RECORD.toDescription());
        alterMenuEntity.setCode(CreditProductChildMenuEnum.ENT_ALTER_RECORD.toName());
        alterMenuEntity.setMenuLevel(2);
        alterMenuEntity.setParentCode(CreditProductMenuEnum.ENT_ENTERPRISE_PROFILE.toName());
        alterMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t12151/64/164299218/7218/b00bf6a9/5a05120dN91ad0619.png");
        identificationSubMenu.add(alterMenuEntity);
//        menu.add(basicMenuEntity);
        menu.put(CreditProductChildMenuEnum.ENT_ALTER_RECORD.toName(),alterMenuEntity);

        //股东信息
        CreditProductMenuEntity shareMenuEntity = new CreditProductMenuEntity();
        shareMenuEntity.setDisplayName(CreditProductChildMenuEnum.ENT_SHARE_HOLDER.toDescription());
        shareMenuEntity.setCode(CreditProductChildMenuEnum.ENT_SHARE_HOLDER.toName());
        shareMenuEntity.setMenuLevel(2);
        shareMenuEntity.setParentCode(CreditProductMenuEnum.ENT_ENTERPRISE_PROFILE.toName());
        shareMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t11416/96/1483351349/8667/73d6b28f/5a051210N7f6cf03e.png");
        identificationSubMenu.add(shareMenuEntity);
//        menu.add(basicMenuEntity);
        menu.put(CreditProductChildMenuEnum.ENT_SHARE_HOLDER.toName(),shareMenuEntity);

        //主要人员
        CreditProductMenuEntity mainMenuEntity = new CreditProductMenuEntity();
        mainMenuEntity.setDisplayName(CreditProductChildMenuEnum.ENT_MAIN_STAFF.toDescription());
        mainMenuEntity.setCode(CreditProductChildMenuEnum.ENT_MAIN_STAFF.toName());
        mainMenuEntity.setMenuLevel(2);
        mainMenuEntity.setParentCode(CreditProductMenuEnum.ENT_ENTERPRISE_PROFILE.toName());
        mainMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t13930/149/174279339/7969/b74c13d0/5a05120eN8a231bae.png");
        identificationSubMenu.add(mainMenuEntity);
//        menu.add(basicMenuEntity);
        menu.put(CreditProductChildMenuEnum.ENT_MAIN_STAFF.toName(),mainMenuEntity);


        //分支机构
        CreditProductMenuEntity branchMenuEntity = new CreditProductMenuEntity();
        branchMenuEntity.setDisplayName(CreditProductChildMenuEnum.ENT_BRANCH_RECORD.toDescription());
        branchMenuEntity.setCode(CreditProductChildMenuEnum.ENT_BRANCH_RECORD.toName());
        branchMenuEntity.setMenuLevel(2);
        branchMenuEntity.setParentCode(CreditProductMenuEnum.ENT_ENTERPRISE_PROFILE.toName());
        branchMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t13981/145/160799125/3426/4a7e0507/5a051210N74032f9a.png");
        identificationSubMenu.add(branchMenuEntity);
//        menu.add(basicMenuEntity);
        menu.put(CreditProductChildMenuEnum.ENT_BRANCH_RECORD.toName(),branchMenuEntity);


        //企业对外投资
        CreditProductMenuEntity entinvMenuEntity = new CreditProductMenuEntity();
        entinvMenuEntity.setDisplayName("对外投资");
        entinvMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_ENTINV_QUERY.toName());
        entinvMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t12088/218/178043298/8202/851656eb/5a051210N8f91fdcb.png");
        entinvMenuEntity.setMenuLevel(2);
        entinvMenuEntity.setParentCode(CreditProductMenuEnum.ENT_ENTERPRISE_PROFILE.toName());
        identificationSubMenu.add(entinvMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(EnterpriseProductEnum.ENTERPRISE_ENTINV_QUERY.toName(), entinvMenuEntity);
    }

    /**
     *  经营风险
     */
    private void negativeMenuEntity(){
        //经营风险
        CreditProductMenuEntity negativeMenuEntity = new CreditProductMenuEntity();
        negativeMenuEntity.setDisplayName(CreditProductMenuEnum.ENT_BUSINESS_RISK.toDescription());
        negativeMenuEntity.setCode(CreditProductMenuEnum.ENT_BUSINESS_RISK.toName());
        negativeMenuEntity.setIconCode(CreditProductMenuEnum.ENT_BUSINESS_RISK.toName());
        negativeMenuEntity.setMenuLevel(1);  //一级
//        menu.add(negativeMenuEntity);
        menu.put(CreditProductMenuEnum.ENT_BUSINESS_RISK.toName(), negativeMenuEntity);

        ArrayList<CreditProductMenuEntity> negativeSubMenu = new ArrayList<CreditProductMenuEntity>();
        negativeMenuEntity.setSubMenu(negativeSubMenu); //set经营风险的子菜单

        //行政处罚
        CreditProductMenuEntity punishmentMenuEntity = new CreditProductMenuEntity();
        punishmentMenuEntity.setDisplayName(CreditProductChildMenuEnum.ENT_PUNISHMENT.toDescription());
        punishmentMenuEntity.setCode(CreditProductChildMenuEnum.ENT_PUNISHMENT.toName());
        punishmentMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t7768/63/4273677564/7123/8c18f5ee/5a051210N93ecbd71.png");
        punishmentMenuEntity.setMenuLevel(2);
        punishmentMenuEntity.setParentCode(CreditProductMenuEnum.ENT_BUSINESS_RISK.toName());
        negativeSubMenu.add(punishmentMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(CreditProductChildMenuEnum.ENT_PUNISHMENT.toName(), punishmentMenuEntity);

        //经营异常名录
        CreditProductMenuEntity abnormalMenuEntity = new CreditProductMenuEntity();
        abnormalMenuEntity.setDisplayName(CreditProductChildMenuEnum.ENT_ABNORMAL.toDescription());
        abnormalMenuEntity.setCode(CreditProductChildMenuEnum.ENT_ABNORMAL.toName());
        abnormalMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t11548/267/1621522664/7441/40079af1/5a05120cNeec7e5fc.png");
        abnormalMenuEntity.setMenuLevel(2);
        abnormalMenuEntity.setParentCode(CreditProductMenuEnum.ENT_BUSINESS_RISK.toName());
        negativeSubMenu.add(abnormalMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(CreditProductChildMenuEnum.ENT_ABNORMAL.toName(), abnormalMenuEntity);


//        //严重违法
        CreditProductMenuEntity illegalinfoMenuEntity = new CreditProductMenuEntity();
        illegalinfoMenuEntity.setDisplayName("严重违法");
        illegalinfoMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_ILLEGALINFO_QUERY.toName());
        illegalinfoMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t19678/303/577942715/12832/de455d61/5a97ec4eN6e094636.png");
        illegalinfoMenuEntity.setMenuLevel(2);
        illegalinfoMenuEntity.setParentCode(CreditProductMenuEnum.ENT_BUSINESS_RISK.toName());
        negativeSubMenu.add(illegalinfoMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(EnterpriseProductEnum.ENTERPRISE_ILLEGALINFO_QUERY.toName(), illegalinfoMenuEntity);

                //抽查检查
        CreditProductMenuEntity checkinfoMenuEntity = new CreditProductMenuEntity();
        checkinfoMenuEntity.setDisplayName("抽查检查");
        checkinfoMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_CHECKINFO_QUERY.toName());
        checkinfoMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t19492/35/569935405/10881/823413bc/5a97ec4eNdf28bbe4.png");
        checkinfoMenuEntity.setMenuLevel(2);
        checkinfoMenuEntity.setParentCode(CreditProductMenuEnum.ENT_BUSINESS_RISK.toName());
        negativeSubMenu.add(checkinfoMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(EnterpriseProductEnum.ENTERPRISE_CHECKINFO_QUERY.toName(), checkinfoMenuEntity);

//        //动产抵押
        CreditProductMenuEntity mortgageinfoMenuEntity = new CreditProductMenuEntity();
        mortgageinfoMenuEntity.setDisplayName("动产抵押");
        mortgageinfoMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_MORTGAGEINFO_QUERY.toName());
        mortgageinfoMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t19579/234/585917386/11178/7d727b5a/5a97ec4eNd74a4302.png");
        mortgageinfoMenuEntity.setMenuLevel(2);
        mortgageinfoMenuEntity.setParentCode(CreditProductMenuEnum.ENT_BUSINESS_RISK.toName());
        negativeSubMenu.add(mortgageinfoMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(EnterpriseProductEnum.ENTERPRISE_MORTGAGEINFO_QUERY.toName(), mortgageinfoMenuEntity);
//
        //股权质押
        CreditProductMenuEntity equityinfoMenuEntity = new CreditProductMenuEntity();
        equityinfoMenuEntity.setDisplayName("股权质押");
        equityinfoMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_EQUITYINFO_QUERY.toName());
        equityinfoMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t18463/165/592868213/10139/e4f57c84/5a97ec4eN12441572.png");
        equityinfoMenuEntity.setMenuLevel(2);
        equityinfoMenuEntity.setParentCode(CreditProductMenuEnum.ENT_BUSINESS_RISK.toName());
        negativeSubMenu.add(equityinfoMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(EnterpriseProductEnum.ENTERPRISE_EQUITYINFO_QUERY.toName(), equityinfoMenuEntity);
//
//        //企业黑名单
//        CreditProductMenuEntity blacklistMenuEntity = new CreditProductMenuEntity();
//        blacklistMenuEntity.setDisplayName(EnterpriseProductEnum.ENTERPRISE_BLACKLIST_QUERY.toDescription());
//        blacklistMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_BLACKLIST_QUERY.toName());
//        blacklistMenuEntity.setIconCode(EnterpriseProductEnum.ENTERPRISE_BLACKLIST_QUERY.toName());
//        blacklistMenuEntity.setMenuLevel(2);
//        blacklistMenuEntity.setParentCode(CreditProductMenuEnum.ENT_BUSINESS_RISK.toName());
//        negativeSubMenu.add(blacklistMenuEntity);
////        menu.add(entinvMenuEntity);
//        menu.put(EnterpriseProductEnum.ENTERPRISE_BLACKLIST_QUERY.toName(), blacklistMenuEntity);

    }

    /**
     * 司法信息
     */
    private void judicialMenuEntity(){
        //司法信息
        CreditProductMenuEntity judicialMenuEntity = new CreditProductMenuEntity();
        judicialMenuEntity.setDisplayName(CreditProductMenuEnum.ENT_JUDICIAL_LITIGATION.toDescription());
        judicialMenuEntity.setCode(CreditProductMenuEnum.ENT_JUDICIAL_LITIGATION.toName());
        judicialMenuEntity.setIconCode(CreditProductMenuEnum.ENT_JUDICIAL_LITIGATION.toName());
        judicialMenuEntity.setMenuLevel(1);  //一级
//        menu.add(negativeMenuEntity);
        menu.put(CreditProductMenuEnum.ENT_JUDICIAL_LITIGATION.toName(), judicialMenuEntity);

        ArrayList<CreditProductMenuEntity> judicialSubMenu = new ArrayList<CreditProductMenuEntity>();
        judicialMenuEntity.setSubMenu(judicialSubMenu); //set经营风险的子菜单

        //法院裁判
        CreditProductMenuEntity lawsuitinfoMenuEntity = new CreditProductMenuEntity();
        lawsuitinfoMenuEntity.setDisplayName("裁判文书");
        lawsuitinfoMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_LAWSUITINFO_QUERY.toName());
        lawsuitinfoMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t7774/241/4306154703/5911/e1a258c4/5a051210N139906f7.png");
        lawsuitinfoMenuEntity.setMenuLevel(2);
        lawsuitinfoMenuEntity.setParentCode(CreditProductMenuEnum.ENT_JUDICIAL_LITIGATION.toName());
        judicialSubMenu.add(lawsuitinfoMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(EnterpriseProductEnum.ENTERPRISE_LAWSUITINFO_QUERY.toName(), lawsuitinfoMenuEntity);

        //被执行人
        CreditProductMenuEntity punishedMenuEntity = new CreditProductMenuEntity();
        punishedMenuEntity.setDisplayName("被执行人");
        punishedMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_PUNISHED_QUERY.toName());
        punishedMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t18340/302/561529133/12809/9f0b4d7f/5a97ec4eN11e9434e.png");
        punishedMenuEntity.setMenuLevel(2);
        punishedMenuEntity.setParentCode(CreditProductMenuEnum.ENT_JUDICIAL_LITIGATION.toName());
        judicialSubMenu.add(punishedMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(EnterpriseProductEnum.ENTERPRISE_PUNISHED_QUERY.toName(), punishedMenuEntity);


        //失信被执行人
        CreditProductMenuEntity punishbreakMenuEntity = new CreditProductMenuEntity();
        punishbreakMenuEntity.setDisplayName("失信被执行人");
        punishbreakMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_PUNISHBREAK_QUERY.toName());
        punishbreakMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t13939/146/176691499/9037/cfa52286/5a05120dN6cc30192.png");
        punishbreakMenuEntity.setMenuLevel(2);
        punishbreakMenuEntity.setParentCode(CreditProductMenuEnum.ENT_JUDICIAL_LITIGATION.toName());
        judicialSubMenu.add(punishbreakMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(EnterpriseProductEnum.ENTERPRISE_PUNISHBREAK_QUERY.toName(), punishbreakMenuEntity);

        //开庭公告
        CreditProductMenuEntity openCourtMenuEntity = new CreditProductMenuEntity();
        openCourtMenuEntity.setDisplayName("开庭公告");
        openCourtMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_OPEN_COURT.toName());
        openCourtMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t15133/339/2336175187/9800/d4af3c28/5a97ec4eN8e4e9933.png");
        openCourtMenuEntity.setMenuLevel(2);
        openCourtMenuEntity.setParentCode(CreditProductMenuEnum.ENT_JUDICIAL_LITIGATION.toName());
        judicialSubMenu.add(openCourtMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(EnterpriseProductEnum.ENTERPRISE_OPEN_COURT.toName(), openCourtMenuEntity);

        //法院公告
        CreditProductMenuEntity courtNoticeMenuEntity = new CreditProductMenuEntity();
        courtNoticeMenuEntity.setDisplayName("法院公告");
        courtNoticeMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_COURT_NOTICE.toName());
        courtNoticeMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t18622/314/570208328/13004/8d307981/5a97ec4eN7c0e83e2.png");
        courtNoticeMenuEntity.setMenuLevel(2);
        courtNoticeMenuEntity.setParentCode(CreditProductMenuEnum.ENT_JUDICIAL_LITIGATION.toName());
        judicialSubMenu.add(courtNoticeMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(EnterpriseProductEnum.ENTERPRISE_COURT_NOTICE.toName(), courtNoticeMenuEntity);

    }

//    /**
//     * 经营状况
//     */
//    private void annualMenuEntity(){
//        //经营状况
//        CreditProductMenuEntity annualMenuEntity = new CreditProductMenuEntity();
//        annualMenuEntity.setDisplayName(CreditProductMenuEnum.ENT_OPERATION_STATUS.toDescription());
//        annualMenuEntity.setCode(CreditProductMenuEnum.ENT_OPERATION_STATUS.toName());
//        annualMenuEntity.setIconCode(CreditProductMenuEnum.ENT_OPERATION_STATUS.toName());
//        annualMenuEntity.setMenuLevel(1);  //一级
//        menu.put(CreditProductMenuEnum.ENT_OPERATION_STATUS.toName(), annualMenuEntity);
//
//        ArrayList<CreditProductMenuEntity> annualSubMenu = new ArrayList<CreditProductMenuEntity>();
//        annualMenuEntity.setSubMenu(annualSubMenu); //set经营风险的子菜单
//
//        //企业年报
//        CreditProductMenuEntity punishedMenuEntity = new CreditProductMenuEntity();
//        punishedMenuEntity.setDisplayName("企业年报");
//        punishedMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_ANNUALREPORT_QUERY.toName());
//        punishedMenuEntity.setIconCode(EnterpriseProductEnum.ENTERPRISE_ANNUALREPORT_QUERY.toName());
//        punishedMenuEntity.setMenuLevel(2);
//        punishedMenuEntity.setParentCode(CreditProductMenuEnum.ENT_OPERATION_STATUS.toName());
//        annualSubMenu.add(punishedMenuEntity);
////        menu.add(entinvMenuEntity);
//        menu.put(EnterpriseProductEnum.ENTERPRISE_ANNUALREPORT_QUERY.toName(), punishedMenuEntity);
//
//
//        //抽查检查
//        CreditProductMenuEntity checkinfoMenuEntity = new CreditProductMenuEntity();
//        checkinfoMenuEntity.setDisplayName("抽查检查");
//        checkinfoMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_CHECKINFO_QUERY.toName());
//        checkinfoMenuEntity.setIconCode(EnterpriseProductEnum.ENTERPRISE_CHECKINFO_QUERY.toName());
//        checkinfoMenuEntity.setMenuLevel(2);
//        checkinfoMenuEntity.setParentCode(CreditProductMenuEnum.ENT_OPERATION_STATUS.toName());
//        annualSubMenu.add(checkinfoMenuEntity);
////        menu.add(entinvMenuEntity);
//        menu.put(EnterpriseProductEnum.ENTERPRISE_CHECKINFO_QUERY.toName(), checkinfoMenuEntity);
//    }

    /**
     * 知识产权
     */
    private void intellectualMenuEntity(){
        //知识产权
        CreditProductMenuEntity intellectualMenuEntity = new CreditProductMenuEntity();
        intellectualMenuEntity.setDisplayName(CreditProductMenuEnum.ENT_INTELLECTUAL_PROPERTY.toDescription());
        intellectualMenuEntity.setCode(CreditProductMenuEnum.ENT_INTELLECTUAL_PROPERTY.toName());
        intellectualMenuEntity.setIconCode(CreditProductMenuEnum.ENT_INTELLECTUAL_PROPERTY.toName());
        intellectualMenuEntity.setMenuLevel(1);  //一级
        menu.put(CreditProductMenuEnum.ENT_INTELLECTUAL_PROPERTY.toName(), intellectualMenuEntity);

        ArrayList<CreditProductMenuEntity> intellectualSubMenu = new ArrayList<CreditProductMenuEntity>();
        intellectualMenuEntity.setSubMenu(intellectualSubMenu); //set知识产权的子菜单

        //专利信息
        CreditProductMenuEntity patentMenuEntity = new CreditProductMenuEntity();
        patentMenuEntity.setDisplayName(CreditProductChildMenuEnum.ENT_PATENT.toDescription());
        patentMenuEntity.setCode(CreditProductChildMenuEnum.ENT_PATENT.toName());
        patentMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t18046/296/574382892/12355/41b2bad0/5a97ec4eNa12d6854.png");
        patentMenuEntity.setMenuLevel(2);
        patentMenuEntity.setParentCode(CreditProductMenuEnum.ENT_INTELLECTUAL_PROPERTY.toName());
        intellectualSubMenu.add(patentMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(CreditProductChildMenuEnum.ENT_PATENT.toName(), patentMenuEntity);

        //商标信息
        CreditProductMenuEntity tminfoMenuEntity = new CreditProductMenuEntity();
        tminfoMenuEntity.setDisplayName(CreditProductChildMenuEnum.ENT_TMINFO.toDescription());
        tminfoMenuEntity.setCode(CreditProductChildMenuEnum.ENT_TMINFO.toName());
        tminfoMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t15352/142/2256876307/10900/a511249/5a97ec4eN77ab40d0.png");
        tminfoMenuEntity.setMenuLevel(2);
        tminfoMenuEntity.setParentCode(CreditProductMenuEnum.ENT_INTELLECTUAL_PROPERTY.toName());
        intellectualSubMenu.add(tminfoMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(CreditProductChildMenuEnum.ENT_TMINFO.toName(), tminfoMenuEntity);

        //ICP网站备案
        CreditProductMenuEntity icpInfoMenuEntity = new CreditProductMenuEntity();
        icpInfoMenuEntity.setDisplayName("ICP网站备案");
        icpInfoMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_ICP_INFO.toName());
        icpInfoMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t7624/333/3184692508/12827/f0133414/5a97ec4eN62787265.png");
        icpInfoMenuEntity.setMenuLevel(2);
        icpInfoMenuEntity.setParentCode(CreditProductMenuEnum.ENT_INTELLECTUAL_PROPERTY.toName());
        intellectualSubMenu.add(icpInfoMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(EnterpriseProductEnum.ENTERPRISE_ICP_INFO.toName(), icpInfoMenuEntity);

        //软件著作权
        CreditProductMenuEntity softwareMenuEntity = new CreditProductMenuEntity();
        softwareMenuEntity.setDisplayName("软件著作权");
        softwareMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_SOFT_WARE_QUERY.toName());
        softwareMenuEntity.setIconCode("http://img30.360buyimg.com/jr_image/jfs/t17359/288/567408297/9900/e4529f4d/5a97ec4eNbcaa950f.png");
        softwareMenuEntity.setMenuLevel(2);
        softwareMenuEntity.setParentCode(CreditProductMenuEnum.ENT_INTELLECTUAL_PROPERTY.toName());
        intellectualSubMenu.add(softwareMenuEntity);
//        menu.add(entinvMenuEntity);
        menu.put(EnterpriseProductEnum.ENTERPRISE_SOFT_WARE_QUERY.toName(), softwareMenuEntity);


//        //企业资质
//        CreditProductMenuEntity qualifyMenuEntity = new CreditProductMenuEntity();
//        qualifyMenuEntity.setDisplayName("企业资质");
//        qualifyMenuEntity.setCode(EnterpriseProductEnum.ENTERPRISE_QUALIFY_VERIFY.toName());
//        qualifyMenuEntity.setIconCode(EnterpriseProductEnum.ENTERPRISE_QUALIFY_VERIFY.toName());
//        qualifyMenuEntity.setMenuLevel(2);
//        qualifyMenuEntity.setParentCode(CreditProductMenuEnum.ENT_INTELLECTUAL_PROPERTY.toName());
//        intellectualSubMenu.add(qualifyMenuEntity);
////        menu.add(entinvMenuEntity);
//        menu.put(EnterpriseProductEnum.ENTERPRISE_QUALIFY_VERIFY.toName(), qualifyMenuEntity);
    }

    public LinkedHashMap getMenu() {
        return menu;
    }

}
