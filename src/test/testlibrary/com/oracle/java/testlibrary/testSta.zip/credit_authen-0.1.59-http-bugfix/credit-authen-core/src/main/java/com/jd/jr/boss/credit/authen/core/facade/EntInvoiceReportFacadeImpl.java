package com.jd.jr.boss.credit.authen.core.facade;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.beans.entity.CreditBaiwangAuthOrderEntity;
import com.jd.jr.boss.credit.authen.core.scheduler.EntInvoiceReportStatusQueryJob;
import com.jd.jr.boss.credit.authen.core.service.EntInvoiceReportService;
import com.jd.jr.boss.credit.facade.authen.api.EntInvoiceReportFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.EntInvoiceReportAuthParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author ：zhanghui12
 * @date ：Created in 2019/3/20 10:40
 * @description：百望授权服务
 */
@Service("entInvoiceReportFacadeImpl")
public class EntInvoiceReportFacadeImpl implements EntInvoiceReportFacade {
    private static Logger logger = LoggerFactory.getLogger(EntInvoiceReportFacadeImpl.class);
    @Autowired
    EntInvoiceReportService entInvoiceReportService;
    @Autowired
    EntInvoiceReportStatusQueryJob entInvoiceReportStatusQueryJob;
    @Override
    public CreditResponseData saveAuthOrder(CreditRequestParam<EntInvoiceReportAuthParam> requestParam) {
        logger.info("百望授权入库，request:{}", JSONObject.toJSONString(requestParam));
        CreditResponseData response = new CreditResponseData();
        List<CreditBaiwangAuthOrderEntity> orderList = null;
        Integer saveCount = 0;
        try {
            orderList = getOrderList(requestParam.getParam());
            if (CollectionUtils.isNotEmpty(orderList)) {
                saveCount = entInvoiceReportService.saveAuthOrder(orderList);
            }
            //发起查询
            entInvoiceReportStatusQueryJob.doTask(null);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
        if (saveCount==0||saveCount != orderList.size()) {
            response.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            response.setCode(ResponseMessage.SYSTEM_ERROR.name());
            response.setSuccess(false);
        }
        logger.info("百望授权入库结束，response:{}", JSONObject.toJSONString(response));
        return response;
    }

    private List<CreditBaiwangAuthOrderEntity> getOrderList(EntInvoiceReportAuthParam param) {
        List<CreditBaiwangAuthOrderEntity> orderList = new ArrayList<>();
        if (param != null && CollectionUtils.isNotEmpty(param.getAuthType())) {
            for (String[] authTyp : param.getAuthType()) {
                if(authTyp.length>1){
                    CreditBaiwangAuthOrderEntity authOrder=new CreditBaiwangAuthOrderEntity();
                    authOrder.setAuthLimitTime(authTyp.length==3?authTyp[2]:null);
                    authOrder.setAuthType(authTyp[0]);
                    authOrder.setMerchantNo(param.getMerchantNo());
                    authOrder.setNoticeUrl(param.getNoticeUrl());
                    authOrder.setTaxNo(param.getTaxNo());
                    authOrder.setUnionId(param.getUnionId());
                    authOrder.setCreditCode(param.getCreditCode());
                    orderList.add(authOrder);
                }else{
                    logger.info("授权类型为空");
                }
            }
        }
        return orderList;
    }
}
