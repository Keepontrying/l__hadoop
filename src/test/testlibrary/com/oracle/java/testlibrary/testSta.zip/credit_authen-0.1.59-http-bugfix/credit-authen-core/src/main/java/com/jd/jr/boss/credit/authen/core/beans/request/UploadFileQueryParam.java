package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by anmeng on 2017/7/27.
 */
public class UploadFileQueryParam implements Serializable {
    private static final long serialVersionUID = 7220774815857018304L;

    private Integer merchantId;//商户号
    private Date beginDate;//开始时间
    private Date endDate;//结束时间
    private String fileType;//文件类型
    private Integer id;//主键id

    public Integer getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Integer merchantId) {
        this.merchantId = merchantId;
    }

    public Date getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(Date beginDate) {
        this.beginDate = beginDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
    
}
