package com.jd.jr.boss.credit.core.test.listener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.alibaba.fastjson.JSONObject;
import com.jd.jmq.common.message.Message;
import com.jd.jr.boss.credit.authen.core.jms.customs.CreditCustomsListener;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : 海关mq测试类
* @author : yangjinlin@jd.com
* @date ：2017年7月20日 下午5:56:59 
* @version 1.0 
* @return  */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/spring-authen.xml" })

public class CustomsListenerTest {
	
	@Resource
	private CreditCustomsListener creditCustomsListener;
	
	@Test
	public void testMessage() throws Exception {

		List<Message> messages = new ArrayList<Message>();
		Message message = new Message();
		JSONObject json = new JSONObject();
		json.put("result", "结关环节：已结关");
		json.put("crawlerDate", "2017-08-07 10:58:42");
		json.put("code", "0");
		json.put("batchtoken", "857f99ea56154b07bcb609b3d85c4f6a");
		json.put("txtCode", "220120090519145275");
		json.put("history", "{\"电子申报\": \"2009-01-16\",\"单证放行\": \"2009-01-16\",\"现场接单\": \"2009-01-16\",\"电脑审单\": \"2009-01-16\",\"人工审单\": \"2009-02-05\",\"货物放行\": \"2009-02-06\"}");
		json.put("message", "");
		message.setText(json.toJSONString());
		messages.add(message);
		creditCustomsListener.onMessage(messages);
		
	}
	

}
