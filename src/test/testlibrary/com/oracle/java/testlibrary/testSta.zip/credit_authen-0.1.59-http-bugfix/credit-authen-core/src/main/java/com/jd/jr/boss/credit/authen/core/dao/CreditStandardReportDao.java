package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.facade.authen.beans.param.BatchReportQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditStandardReport;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

/**
 * Created by zhanghui12 on 2018/5/17.
 */
@Repository
public interface CreditStandardReportDao {
    Integer saveStandardReport(CreditStandardReport standardReport);

    Integer saveBatchReport(@Param("batchReports") List<CreditStandardReport> batchReports);

    Integer updateReport(CreditStandardReport report);

    CreditStandardReport queryMerchantByOrder(String orderId);

    Integer updateReportByOrderId(CreditStandardReport report);

    /**
     * 查询一个批次的所有订单
     * @param batchNo
     * @return
     */
    List<CreditStandardReport> queryBatchOrder(String batchNo);

    /**
     * 查询请求时间
     * @param orderId
     * @return
     */
    Date queryReportDate(String orderId);

    /**
     * 分页查询
     * @param param
     * @return
     */
    List<CreditStandardReport> queryReportPage(BatchReportQueryParam param);
    /**
     * 查询总条数
     * @param param
     * @return
     */
    int queryReportTotalCount(BatchReportQueryParam param);

    /**
     * 根据id查询
     * @param id
     * @return
     */
    CreditStandardReport queryById(String id);
}
