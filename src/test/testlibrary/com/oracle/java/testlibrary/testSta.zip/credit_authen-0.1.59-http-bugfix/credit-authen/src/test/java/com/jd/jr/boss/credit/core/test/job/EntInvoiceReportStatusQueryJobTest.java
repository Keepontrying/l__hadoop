package com.jd.jr.boss.credit.core.test.job;

import com.jd.jr.boss.credit.authen.core.scheduler.AntiMoneyUpdateJob;
import com.jd.jr.boss.credit.authen.core.scheduler.EntInvoiceReportStatusQueryJob;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author ：zhanghui12
 * @date ：Created in 2019/3/20 16:35
 * @description：
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/spring-authen.xml" })
public class EntInvoiceReportStatusQueryJobTest {
    @Autowired
    EntInvoiceReportStatusQueryJob entInvoiceReportStatusQueryJob;

    @Test
    public void testJob() throws Exception {
        entInvoiceReportStatusQueryJob.doTask(null);
    }
}
