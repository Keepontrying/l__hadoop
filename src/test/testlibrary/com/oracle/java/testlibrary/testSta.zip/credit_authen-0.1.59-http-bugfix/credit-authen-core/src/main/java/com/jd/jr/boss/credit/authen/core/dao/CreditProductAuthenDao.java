package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.facade.authen.beans.entity.CreditProductAuthenEntity;
import com.jd.jr.boss.credit.facade.authen.beans.param.CreditAuthenQueryParam;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 类描述：
 *
 * @author liangyuwu
 * @Time 2018/6/6 10:56
 */
@Repository
public interface CreditProductAuthenDao {
    int insert(CreditProductAuthenEntity entity);

    List<CreditProductAuthenEntity> select(CreditProductAuthenEntity entity);

    int update(CreditProductAuthenEntity entity);

    int countList(CreditAuthenQueryParam param);

    List<CreditProductAuthenEntity> pageList(CreditAuthenQueryParam param);
}
