package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.domain.common.entity.signcode.CreditSignCode;
import com.jd.jr.boss.credit.domain.common.entity.signcode.CreditSignCodeInfo;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchQueryParam;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 中证码
 * @author huangzhiqiang
 * @data 2017/8/24
 */
@Repository
public interface CreditSignCodeDao {

    /**
     * 插入中证码调度信息
     * @param signCode
     * @return
     */
    Integer insert(CreditSignCode signCode);
    /**
     * 查询中证码批次信息  分页
     * @param queryParam
     * @return
     */
    List<CreditSignCode> querySigncodeBatchHistory(BatchQueryParam queryParam);
	/**
	 * 查询中证码批次信息总记录数  分页
	 * @param queryParam
	 * @return
	 */
    Integer querySigncodeBatchHistoryCount(BatchQueryParam queryParam);

}
