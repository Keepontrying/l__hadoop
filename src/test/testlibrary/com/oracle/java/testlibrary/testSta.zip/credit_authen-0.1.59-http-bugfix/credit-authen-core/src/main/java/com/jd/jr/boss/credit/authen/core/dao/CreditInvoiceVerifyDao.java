package com.jd.jr.boss.credit.authen.core.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.jd.jr.boss.credit.domain.common.entity.invoiceVerify.CreditInvoiceVerify;
import com.jd.jr.boss.credit.domain.common.entity.invoiceVerify.CreditInvoiceVerifyGoods;
import com.jd.jr.boss.credit.facade.authen.beans.param.InvoiceQueryParam;

/** 
* @desciption : 国税发票验真
* @author : yangjinlin@jd.com
* @date ：2017年8月23日 下午4:31:18 
* @version 1.0 
* @return  */
@Repository
public interface CreditInvoiceVerifyDao {

	/**
	 * 新增国税发票信息
	 * @param invoiceVerify
	 * @return
	 */
    Integer insertInvoice(CreditInvoiceVerify invoiceVerify);

	/**
	 * 批量新增发票详情对应的货物信息
	 * @param goodsList
	 */
    void insertBatchGoods(List<CreditInvoiceVerifyGoods> goodsList);
	/**
	 * 查询发票票面信息   分页
	 * @param queryParam
	 * @return
	 */
    List<CreditInvoiceVerify> queryInvoiceByPrm(InvoiceQueryParam queryParam);
	/**
	 * 查询发票票面信息总记录数   分页
	 * @param queryParam
	 * @return
	 */
    Integer queryInvoiceByPrmCount(InvoiceQueryParam queryParam);

	/**
	 * 根据主键更新发票信息
	 * @param invoiceVerify
	 * @return
	 */
    int updateInvoice(CreditInvoiceVerify invoiceVerify);

	/**
	 *
	 * @param batchId
	 * @param code
	 * @param number
	 * @return
	 */
    CreditInvoiceVerify queryInvoiceByBatch(@Param("batchId") Integer batchId, @Param("code") String code, @Param("number") String number);

	/**
	 * 查询发票下的货品信息  分页 
	 * @param queryParam
	 * @return
	 */
    List<CreditInvoiceVerifyGoods> queryInvoiceGoodsData(InvoiceQueryParam queryParam);

	/**
	 * 查询发票下的货品信息总记录数  分页 
	 * @param queryParam
	 * @return
	 */
    Integer queryInvoiceGoodsDataCount(InvoiceQueryParam queryParam);

}
