package com.jd.jr.boss.credit.authen.core.beans.entity;


import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.PunishedQueryData;

import java.io.Serializable;

/**
 *
 * @author: liuwei55
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
public class PunishedQueryEntity extends PunishedQueryData implements Serializable{
	private static final long serialVersionUID = -5976372532098995081L;
	/**
	 * 被执行人
	 */
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
