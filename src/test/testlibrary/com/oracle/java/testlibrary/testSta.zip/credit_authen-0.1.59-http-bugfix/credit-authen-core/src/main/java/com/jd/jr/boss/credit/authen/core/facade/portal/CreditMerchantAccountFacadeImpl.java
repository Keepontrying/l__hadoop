package com.jd.jr.boss.credit.authen.core.facade.portal;

import com.jd.jr.boss.credit.authen.core.service.MerchantAccountService;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrderMain;
import com.jd.jr.boss.credit.facade.authen.api.CreditMerchantAccountFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.FacadeGenBizPayUrlRequest;
import com.jd.jr.boss.credit.facade.authen.beans.response.FacadeMerchantAccountBalance;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


/**
 * Created by anmeng on 2017/5/19.
 */
@Service("creditMerchantAccountFacade")
public class CreditMerchantAccountFacadeImpl implements CreditMerchantAccountFacade {

    private static final Logger logger= LoggerFactory.getLogger(CreditMerchantAccountFacadeImpl.class);

    @Resource
    private MerchantAccountService merchantAccountService;

    /**
     * 查询商户企业站总余额
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<FacadeMerchantAccountBalance> queryMerchantBalance(CreditRequestParam<String> requestParam) {
        CreditResponseData<FacadeMerchantAccountBalance> responseData=new CreditResponseData<FacadeMerchantAccountBalance>();
        String merchantNo=requestParam.getParam();
        try {
            FacadeMerchantAccountBalance balance=merchantAccountService.queryMerchantBalance(merchantNo);
            responseData.setData(balance);
        } catch (Exception e) {
            logger.error(e);
            responseData.setResponseMessage(ResponseMessage.BUSINESS_EXCEPTION);
            responseData.setMessage(e.getMessage());
        }
        return responseData;
    }

    /**
     * 查询企业站支付页面URL
     *
     * @param requestParam
     * @return
     */
    @Override
    @Deprecated
    public CreditResponseData<String> queryPayUrl(CreditRequestParam<FacadeGenBizPayUrlRequest> requestParam) {

        CreditResponseData<String> responseData=new CreditResponseData<String>();
        FacadeGenBizPayUrlRequest bizPayUrlRequest=requestParam.getParam();
        String url=merchantAccountService.genBizPayUrl(bizPayUrlRequest);
        responseData.setData(url);
        return responseData;
    }
}
