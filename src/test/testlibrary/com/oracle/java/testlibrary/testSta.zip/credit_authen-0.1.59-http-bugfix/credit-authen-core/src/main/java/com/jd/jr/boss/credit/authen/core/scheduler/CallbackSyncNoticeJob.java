package com.jd.jr.boss.credit.authen.core.scheduler;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.jd.jr.boss.credit.authen.core.constants.SystemConstants;
import com.jd.jr.boss.credit.authen.core.enums.CrawlerInvoiceVerifyStatusEnum;
import com.jd.jr.boss.credit.authen.core.service.CreditInvoiceVerifyService;
import com.jd.jr.boss.credit.authen.core.service.ForeignCallbackNoticeService;
import com.jd.jr.boss.credit.domain.common.entity.CreditCallbackUrl;
import com.jd.jr.boss.credit.domain.common.entity.CreditQuerySyncNotice;
import com.jd.jr.boss.credit.domain.common.entity.invoiceVerify.CreditInvoiceVerify;
import com.jd.jr.boss.credit.domain.common.entity.invoiceVerify.CreditInvoiceVerifyGoods;
import com.jd.jr.boss.credit.domain.common.enums.CreditCallbackNoticeStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditQueryBatchTypeEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditYesOrNoEnum;
import com.jd.jr.boss.credit.facade.authen.beans.param.CallbackUrlQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.InvoiceQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.SyncNoticeQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.ForeignFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.ForeignParam;
import com.jd.jsf.gd.util.StringUtils;
import com.wangyin.operation.utils.GsonUtil;
import com.wangyin.schedule.client.job.ScheduleContext;
import com.wangyin.schedule.client.job.SchedulerJob;

/** 
* @desciption : 异步通知任务轮询
* @author : yangjinlin@jd.com
* @date ：2018年3月1日 下午5:42:12 
* @version 1.0 
* @return  */
@Service
public class CallbackSyncNoticeJob implements SchedulerJob {

	private static final Logger LOGGER = LoggerFactory.getLogger(CallbackSyncNoticeJob.class);
	private final Integer INVOICE_API_SYNC_NOTICE_TIME_MAX = 3;
	
	@Resource
    private ForeignCallbackNoticeService foreignCallbackNoticeService;
	
	@Resource
    private ForeignFacade foreignFacade;
	
	@Resource
    private CreditInvoiceVerifyService invoiceVerifyService;
	
	@Override
	public void doJob(ScheduleContext scheduleContext) throws Exception {
		Long startTime = System.currentTimeMillis();
		LOGGER.info("==========CallbackSyncNoticeJob start=========", this.getClass());
		SyncNoticeQueryParam syncNoticeQueryParam = new SyncNoticeQueryParam();
		syncNoticeQueryParam.setNoticeStatus(CreditCallbackNoticeStatusEnum.UNDO.toName());
		List<CreditQuerySyncNotice> syncNoticeList = foreignCallbackNoticeService.querySyncNoticeListByPrm(syncNoticeQueryParam);
		if(CollectionUtils.isEmpty(syncNoticeList)){
			Long endTime = System.currentTimeMillis();
			LOGGER.info("=============CallbackSyncNoticeJob end，total time: "+((startTime - endTime) / 1000)+" s ==============");
			return;
		}
		for(CreditQuerySyncNotice querySyncNotice : syncNoticeList){
			if(querySyncNotice.getNoticeTimes() >= INVOICE_API_SYNC_NOTICE_TIME_MAX){//超过指定次数不再通知
				continue;
			}
			CallbackUrlQueryParam callbackUrlQueryParam = new CallbackUrlQueryParam();
			callbackUrlQueryParam.setCallbackId(querySyncNotice.getCallbackId());
			List<CreditCallbackUrl> callbackUrlList = foreignCallbackNoticeService.queryCallbackUrlListByPrm(callbackUrlQueryParam);
			if(CollectionUtils.isNotEmpty(callbackUrlList) && null != callbackUrlList.get(0) && StringUtils.isNotBlank(callbackUrlList.get(0).getCallbackUrl())){
				ForeignParam foreignParam = new ForeignParam();
				foreignParam.setUrl(callbackUrlList.get(0).getCallbackUrl());
				if(querySyncNotice.getParamComplFlag().equalsIgnoreCase(CreditYesOrNoEnum.YES.toName())){
					foreignParam.setData(querySyncNotice.getResultParam());
				}else if(querySyncNotice.getParamComplFlag().equalsIgnoreCase(CreditYesOrNoEnum.NO.toName()) 
						&& querySyncNotice.getNoticeType().equalsIgnoreCase(CreditQueryBatchTypeEnum.INVOICE.toName())){
					InvoiceQueryParam queryParam = new InvoiceQueryParam();
		    		queryParam.setInvoiceId(querySyncNotice.getResultId());
		    		CreditPage<CreditInvoiceVerify> queryInvoiceDetailData = invoiceVerifyService.queryInvoiceDetailData(queryParam);
		    		if(null == queryInvoiceDetailData){
		    			LOGGER.info("[CallbackSyncNoticeJob-queryCallbackUrlListByPrm] queryInvoiceDetailData failed, responseData:",GsonUtil.getInstance().toJson(queryInvoiceDetailData));
		    			continue;
		    		}
		    		if(!queryInvoiceDetailData.isSuccess()){
		    			LOGGER.info("[CallbackSyncNoticeJob-queryCallbackUrlListByPrm] queryInvoiceDetailData failed, responseData:",GsonUtil.getInstance().toJson(queryInvoiceDetailData));
		    			continue;
		    		}
		    		if(queryInvoiceDetailData.isSuccess() && CollectionUtils.isNotEmpty(queryInvoiceDetailData.getRows())){//查询发票信息并组装成参数调用 CreditResponseData<String> responseData = foreignFacade.notice(requestParam);
		    			 //调用成功，则更新notice状态为DONE；调用不成功，则增加noticeTimes
		    			CreditInvoiceVerify invoiceVerify = this.convertInvoiceInfo4Api(queryInvoiceDetailData.getRows());
		    			if(null == invoiceVerify){
		    				LOGGER.info("[CallbackSyncNoticeJob-queryCallbackUrlListByPrm] queryInvoiceDetailData has no incoiceInfo, responseData:",GsonUtil.getInstance().toJson(queryInvoiceDetailData.getRows()));
		    				continue;
		    			}
		    			Gson gson = new Gson();
	    				String resultStr = gson.toJson(invoiceVerify);
	    				foreignParam.setData(resultStr);
		    		}
				}
				CreditRequestParam<ForeignParam> requestParam = new CreditRequestParam<ForeignParam>();
				requestParam.setParam(foreignParam);
				CreditResponseData<String> responseData = foreignFacade.notice(requestParam);
				//TODO test
//				CreditResponseData<String> responseData = new CreditResponseData<String>();
//				responseData.setSuccess(true);
//				responseData.setData("FAIL");
				CreditQuerySyncNotice querySyncNotice4Upd = new CreditQuerySyncNotice();
				querySyncNotice4Upd.setId(querySyncNotice.getId());
				querySyncNotice4Upd.setNoticeStatus(CreditCallbackNoticeStatusEnum.DONE.toName());
				if(null != responseData && responseData.isSuccess() && StringUtils.isNotBlank(responseData.getData()) 
						&& responseData.getData().equalsIgnoreCase(CrawlerInvoiceVerifyStatusEnum.SUCCESS.getName())){
					LOGGER.info("CallbackSyncNoticeJob invoice callback success, responseData:",GsonUtil.getInstance().toJson(responseData) );
					querySyncNotice4Upd.setNoticeStatus(CreditCallbackNoticeStatusEnum.DONE.toName());
				}else{
					LOGGER.info("CallbackSyncNoticeJob invoice callback failed, responseData:",GsonUtil.getInstance().toJson(responseData) );
					int noticeTimesNow = querySyncNotice.getNoticeTimes() + 1;
					querySyncNotice4Upd.setNoticeTimes(noticeTimesNow);
					querySyncNotice4Upd.setNoticeStatus(CreditCallbackNoticeStatusEnum.UNDO.toName());
				}
				querySyncNotice4Upd.setModifier(SystemConstants.PARAM_INPUT_OPERATOR);
				querySyncNotice4Upd.setModifiedDate(new Date());
				int updateId = foreignCallbackNoticeService.updateByPrimaryKeySelective(querySyncNotice4Upd);
			}else{
				LOGGER.info("[CallbackSyncNoticeJob-queryCallbackUrlListByPrm] this notice has no available callback url, queryResult:",GsonUtil.getInstance().toJson(callbackUrlList));
			}
		}
		Long endTime = System.currentTimeMillis();
		LOGGER.info("=============CallbackSyncNoticeJob end，total time: "+((startTime - endTime) / 1000)+" s ==============");
		
	}
	
	/**
	 * 构造发票API回调的入参信息
	 * @param invoiceVerifyList
	 * @return
	 */
	private CreditInvoiceVerify convertInvoiceInfo4Api(List<CreditInvoiceVerify> invoiceVerifyList){
		CreditInvoiceVerify invoiceEntity = new CreditInvoiceVerify();
		CreditInvoiceVerify invoiceVerifyResponse = new CreditInvoiceVerify();
		invoiceEntity.setCode(invoiceVerifyResponse.getCode());
        invoiceEntity.setNumber(invoiceVerifyResponse.getNumber());
        invoiceEntity.setCreateDate(invoiceVerifyResponse.getCreateDate());
        invoiceEntity.setCheckCode(invoiceVerifyResponse.getCheckCode());
        invoiceEntity.setMachineNo(invoiceVerifyResponse.getMachineNo());
        invoiceEntity.setVerifyNum(invoiceVerifyResponse.getVerifyNum());
        invoiceEntity.setVerifyDate(invoiceVerifyResponse.getVerifyDate());
        invoiceEntity.setSource(invoiceVerifyResponse.getSource());
        invoiceEntity.setBuyerDom(invoiceVerifyResponse.getBuyerDom());
        invoiceEntity.setBuyerName(invoiceVerifyResponse.getBuyerName());
        invoiceEntity.setBuyerAccount(invoiceVerifyResponse.getBuyerAccount());
        invoiceEntity.setBuyerTaxNo(invoiceVerifyResponse.getBuyerTaxNo());
        invoiceEntity.setSellerDom(invoiceVerifyResponse.getSellerDom());
        invoiceEntity.setSellerName(invoiceVerifyResponse.getSellerName());
        invoiceEntity.setSellerTaxNo(invoiceVerifyResponse.getSellerTaxNo());
        invoiceEntity.setSellerAccount(invoiceVerifyResponse.getSellerAccount());
        invoiceEntity.setRemark(invoiceVerifyResponse.getRemark());
        invoiceEntity.setTotalAmount(invoiceVerifyResponse.getTotalAmount());
        invoiceEntity.setTotalTax(invoiceVerifyResponse.getTotalTax());
        invoiceEntity.setAmountOrdinary(invoiceVerifyResponse.getAmountOrdinary());
        invoiceEntity.setAmountCapital(invoiceVerifyResponse.getAmountCapital());
        invoiceEntity.setIsCanceled(invoiceVerifyResponse.getIsCanceled());
        invoiceEntity.setType(invoiceVerifyResponse.getType());
        List<CreditInvoiceVerifyGoods> goodsResponseList = invoiceVerifyResponse.getGoodsList();
        if(CollectionUtils.isNotEmpty(goodsResponseList)){
            List<CreditInvoiceVerifyGoods> goodsEntityList=new ArrayList<CreditInvoiceVerifyGoods>();
            for(CreditInvoiceVerifyGoods goodsResponse : goodsResponseList){
                CreditInvoiceVerifyGoods goods=new CreditInvoiceVerifyGoods();
                goods.setName(goodsResponse.getName());
                goods.setModel(goodsResponse.getModel());
                goods.setUnit(goodsResponse.getUnit());
                goods.setNumber(goodsResponse.getNumber());
                goods.setPrice(goodsResponse.getPrice());
                goods.setAmount(goodsResponse.getAmount());
                goods.setTaxRatio(goodsResponse.getTaxRatio());
                goods.setTax(goodsResponse.getTax());
                goodsEntityList.add(goods);
            }
            invoiceEntity.setGoodsList(goodsEntityList);
        }
		return invoiceEntity;
	}

}
