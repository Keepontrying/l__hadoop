package com.jd.jr.boss.credit.authen.core.beans.entity;

import com.jd.jr.boss.credit.authen.core.enums.view.CreditServiceLeftMenuEnum;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.EnterpriseProductEnum;

import java.io.Serializable;
import java.util.*;

/**
 * Created by anmeng on 2018/1/15.
 */
public class ProductToBuyShow implements Serializable {
    private static final long serialVersionUID = 8212112049331718482L;
    private HashMap<String,ProductItemShow> itemMap=new HashMap<String, ProductItemShow>();
    private LinkedHashMap<String,List<ProductItemShow>> menuMap=new LinkedHashMap<String, List<ProductItemShow>>();
    private String defaultIcon="http://img30.360buyimg.com/jr_image/jfs/t13930/149/174279339/7969/b74c13d0/5a05120eN8a231bae.png";

    public ProductToBuyShow(){
        List<ProductItemShow> productList=null;
        ProductItemShow itemShow=null;

        //企业基本概况
        productList=new LinkedList<ProductItemShow>();
        menuMap.put(CreditServiceLeftMenuEnum.ENT_COMPANY_BASEINFO.toDescription(),productList);
        //1.工商基本信息
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_BASIC_QUERY,"http://img30.360buyimg.com/jr_image/jfs/t13606/236/167424191/6972/5f8fc4af/5a051210Nc303809f.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_BASIC_QUERY.toName(),itemShow);
        //2.企业对外投资
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_ENTINV_QUERY,"http://img30.360buyimg.com/jr_image/jfs/t12088/218/178043298/8202/851656eb/5a051210N8f91fdcb.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_ENTINV_QUERY.toName(),itemShow);
//        //3.企业年报
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_ANNUALREPORT_QUERY,"ent_annual_report");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_ANNUALREPORT_QUERY.toName(),itemShow);

        //企业经营风险
        productList=new LinkedList<ProductItemShow>();
        menuMap.put(CreditServiceLeftMenuEnum.ENT_NEGATIVE_QUERY.toDescription(),productList);
        //1.行政处罚
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_PUNISHMENT_QUERY,"http://img30.360buyimg.com/jr_image/jfs/t7768/63/4273677564/7123/8c18f5ee/5a051210N93ecbd71.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_PUNISHMENT_QUERY.toName(),itemShow);
        //2.经营异常名单
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_ABNORMAL_QUERY,"http://img30.360buyimg.com/jr_image/jfs/t11548/267/1621522664/7441/40079af1/5a05120cNeec7e5fc.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_ABNORMAL_QUERY.toName(),itemShow);
//        //3.企业负面信息
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_NEGATIVE_QUERY,"ent_negative_query");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_NEGATIVE_QUERY.toName(),itemShow);
        //4.动产抵押
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_MORTGAGEINFO_QUERY,"http://img30.360buyimg.com/jr_image/jfs/t19579/234/585917386/11178/7d727b5a/5a97ec4eNd74a4302.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_MORTGAGEINFO_QUERY.toName(),itemShow);
        //5.股权质押
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_EQUITYINFO_QUERY,"http://img30.360buyimg.com/jr_image/jfs/t18463/165/592868213/10139/e4f57c84/5a97ec4eN12441572.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_EQUITYINFO_QUERY.toName(),itemShow);
        //6.抽查检查
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_CHECKINFO_QUERY,"http://img30.360buyimg.com/jr_image/jfs/t19492/35/569935405/10881/823413bc/5a97ec4eNdf28bbe4.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_CHECKINFO_QUERY.toName(),itemShow);

        //企业司法风险
        productList=new LinkedList<ProductItemShow>();
        menuMap.put(CreditServiceLeftMenuEnum.ENT_JUDICIAL_LITIGATION.toDescription(),productList);
        //1.法院裁判信息
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_LAWSUITINFO_QUERY,"http://img30.360buyimg.com/jr_image/jfs/t7774/241/4306154703/5911/e1a258c4/5a051210N139906f7.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_LAWSUITINFO_QUERY.toName(),itemShow);
        //2.失信被执行人
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_PUNISHBREAK_QUERY,"http://img30.360buyimg.com/jr_image/jfs/t13939/146/176691499/9037/cfa52286/5a05120dN6cc30192.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_PUNISHBREAK_QUERY.toName(),itemShow);
        //3.被执行人信息
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_PUNISHED_QUERY,"http://img30.360buyimg.com/jr_image/jfs/t18340/302/561529133/12809/9f0b4d7f/5a97ec4eN11e9434e.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_PUNISHED_QUERY.toName(),itemShow);
        //4.法院公告
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_COURT_NOTICE,"http://img30.360buyimg.com/jr_image/jfs/t18622/314/570208328/13004/8d307981/5a97ec4eN7c0e83e2.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_COURT_NOTICE.toName(),itemShow);
        //5.开庭公告
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_OPEN_COURT,"http://img30.360buyimg.com/jr_image/jfs/t15133/339/2336175187/9800/d4af3c28/5a97ec4eN8e4e9933.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_OPEN_COURT.toName(),itemShow);

        //企业知识产权
        productList=new LinkedList<ProductItemShow>();
        menuMap.put(CreditServiceLeftMenuEnum.ENT_INTELLECTUAL_PROPERTY.toDescription(),productList);
        //1.专利信息
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_PATENT_QUERY,"http://img30.360buyimg.com/jr_image/jfs/t18046/296/574382892/12355/41b2bad0/5a97ec4eNa12d6854.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_PATENT_QUERY.toName(),itemShow);
        //2.商标信息
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_TMINFO_QUERY,"http://img30.360buyimg.com/jr_image/jfs/t15352/142/2256876307/10900/a511249/5a97ec4eN77ab40d0.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_TMINFO_QUERY.toName(),itemShow);
//        //3.企业资质认证
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_QUALIFY_VERIFY,"ent_qualifycheck_query");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_QUALIFY_VERIFY.toName(),itemShow);
        //4.ICP网站备案
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_ICP_INFO,"http://img30.360buyimg.com/jr_image/jfs/t7624/333/3184692508/12827/f0133414/5a97ec4eN62787265.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_ICP_INFO.toName(),itemShow);
        //5.软件著作权
        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_SOFT_WARE_QUERY,"http://img30.360buyimg.com/jr_image/jfs/t17359/288/567408297/9900/e4529f4d/5a97ec4eNbcaa950f.png");
        productList.add(itemShow);
        itemMap.put(EnterpriseProductEnum.ENTERPRISE_SOFT_WARE_QUERY.toName(),itemShow);
        //6.作品著作权 todo 

//        //经营数据查询
//        productList=new LinkedList<ProductItemShow>();
//        menuMap.put(CreditServiceLeftMenuEnum.ENT_BUSINESS_DATA.toDescription(),productList);
//        //1.海关信息查询
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_CUSTOMS_QUERY,"ent_customs_query");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_CUSTOMS_QUERY.toName(),itemShow);
//        //2.A级纳税人查询
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_LEVELATAXPAYER_QUERY,"ent_levelataxpayer_query");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_LEVELATAXPAYER_QUERY.toName(),itemShow);
//        //3.一般纳税人查询
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_TAX_PAY_QUERY,"tax_pay_query");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_TAX_PAY_QUERY.toName(),itemShow);
//        //4.中证码查询
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_SIGNCODE_QUERY,"ent_signcode_query");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_SIGNCODE_QUERY.toName(),itemShow);
//        //5.风控排污报告
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_ELIMINATE_NEGATIVE_REPORT,"ent_eliminate_negative_report");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_ELIMINATE_NEGATIVE_REPORT.toName(),itemShow);
//        //6.重大税收违法查询
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_MAJOR_TAX_VIOLATION,"ent_major_tax_violation");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_MAJOR_TAX_VIOLATION.toName(),itemShow);

//        //识别认证核验
//        productList=new LinkedList<ProductItemShow>();
//        menuMap.put(CreditServiceLeftMenuEnum.ENT_IDENTIFICATION_VERIFICATION.toDescription(),productList);
//        //1.工商三要素验证
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_VERIFY,"ent_verify");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_VERIFY.toName(),itemShow);
//        //2.工商四要素验证
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_ENT_4ELEMENTS_AUTH,"ent_4elements_auth");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_ENT_4ELEMENTS_AUTH.toName(),itemShow);
//        //3.国税发票验真
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_INVOICE_VERIFY,"ent_invoice_verify");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_INVOICE_VERIFY.toName(),itemShow);
//        //4.营业执照OCR识别
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_REGLICENSE_QUERY,"ent_ocr_reg_busslicense");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_REGLICENSE_QUERY.toName(),itemShow);
//
//        //黑名单
//        productList=new LinkedList<ProductItemShow>();
//        menuMap.put(CreditServiceLeftMenuEnum.ENT_BLACK.toDescription(),productList);
//        //1.企业黑名单
//        itemShow=new ProductItemShow(EnterpriseProductEnum.ENTERPRISE_BLACKLIST_QUERY,"ent_blacklist_query");
//        productList.add(itemShow);
//        itemMap.put(EnterpriseProductEnum.ENTERPRISE_BLACKLIST_QUERY.toName(),itemShow);
    }

    public HashMap<String, ProductItemShow> getItemMap() {
        return itemMap;
    }

    public void setItemMap(HashMap<String, ProductItemShow> itemMap) {
        this.itemMap = itemMap;
    }

    public LinkedHashMap<String, List<ProductItemShow>> getMenuMap() {
        for(String key:menuMap.keySet()){
            List<ProductItemShow> itemList=menuMap.get(key);
            Iterator<ProductItemShow> iter=itemList.iterator();
            while(iter.hasNext()){
                ProductItemShow show=iter.next();
                if(!show.isShow()){
                    iter.remove();
                }
            }
            if(itemList.isEmpty()){
                menuMap.remove(key);
            }
        }
        return menuMap;
    }

    public void setMenuMap(LinkedHashMap<String, List<ProductItemShow>> menuMap) {
        this.menuMap = menuMap;
    }

    public String getDefaultIcon() {
        return defaultIcon;
    }

    public void setDefaultIcon(String defaultIcon) {
        this.defaultIcon = defaultIcon;
    }
}
