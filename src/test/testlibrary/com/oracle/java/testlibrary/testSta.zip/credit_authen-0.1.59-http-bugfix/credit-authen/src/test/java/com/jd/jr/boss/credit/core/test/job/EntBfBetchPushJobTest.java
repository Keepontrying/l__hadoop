package com.jd.jr.boss.credit.core.test.job;

import com.jd.jr.boss.credit.authen.core.scheduler.EntBfBetchPushJob;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * created by ChenKaiJu on 2018/9/21  17:02
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/spring-authen.xml" })
public class EntBfBetchPushJobTest {

    @Resource
    EntBfBetchPushJob entBfBetchPushJob;

    @Test
    public void testJob() throws Exception {
        entBfBetchPushJob.doJob(null);
    }
}
