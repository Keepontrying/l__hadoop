package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.domain.common.entity.CreditNetTrackerGroup;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by anmeng on 2017/10/26.
 */
@Repository
public interface CreditNetTrackerGroupDao {

    int insert(CreditNetTrackerGroup group);

    int update(CreditNetTrackerGroup group);

    List<CreditNetTrackerGroup> findGroupByMerchantId(Integer merchantId);

    /**
     * 查询商户默认分组
     * @param merchantId
     * @return
     */
    CreditNetTrackerGroup queryDefaultGroupByMerchantId(Integer merchantId);

}
