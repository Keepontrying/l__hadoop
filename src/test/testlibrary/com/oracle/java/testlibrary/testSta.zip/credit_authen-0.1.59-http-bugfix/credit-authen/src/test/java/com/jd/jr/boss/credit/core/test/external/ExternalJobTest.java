package com.jd.jr.boss.credit.core.test.external;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.facade.common.dto.CreditExRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.external.api.CreditExProductFacade;
import com.jd.jr.boss.credit.facade.external.api.CreditExUserFacade;
import com.jd.jr.boss.credit.facade.external.beans.request.*;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditProductMenuResp;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import javax.annotation.Resource;

/**
 * @author jiangbo
 * @since 2017/6/23
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:springtest/jsf-consumer.xml" })

public class ExternalJobTest {
    @Resource
    public CreditExUserFacade creditExUserFacade;
    @Resource
    private CreditExProductFacade creditExProductFacade;

    @Test
    public void testJob() throws Exception {
        CreditExRequestParam<UserQueryReq> requestParam = new CreditExRequestParam<UserQueryReq>();
        UserQueryReq userQueryReq = new UserQueryReq();
        userQueryReq.setEmail("credittest010@jd.com");
//        requestParam.setOperator("hehe");
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_test");
        requestParam.setToken("712b6819471b4fe7a37f2d8b2b3a421e");
        requestParam.setParam(userQueryReq);
        requestParam.setOperator("110048553");

        System.out.println(JSONObject.toJSONString(creditExUserFacade.queryCreditUserByParam(requestParam)));
    }

    @Test
    public void testQueryRegisterUser() throws Exception {
        CreditExRequestParam<RegisterReq> requestParam = new CreditExRequestParam<RegisterReq>();
        RegisterReq registerReq = new RegisterReq();
        registerReq.setPhone("123456");
        registerReq.setUserName("credittest010@jd.com");
        registerReq.setMerchantNo("110048553");
//        requestParam.setOperator("hehe");
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_test");
        requestParam.setToken("712b6819471b4fe7a37f2d8b2b3a421e");
        requestParam.setParam(registerReq);

        System.out.println(JSONObject.toJSONString(creditExUserFacade.registerUser(requestParam)));
    }

    @Test
    public void testProduct() throws Exception {
        CreditExRequestParam<ProductItemQueryReq> requestParam = new CreditExRequestParam<ProductItemQueryReq>();
        ProductItemQueryReq registerReq = new ProductItemQueryReq();
        registerReq.setMerchantNo("110043895");
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        requestParam.setParam(registerReq);

        System.out.println(JSONObject.toJSONString(creditExProductFacade.queryProductItem(requestParam)));
    }


    @Test
    public void testProduct1() throws Exception {
        CreditExRequestParam<ProductItemCustomQueryReq> requestParam = new CreditExRequestParam<ProductItemCustomQueryReq>();
        ProductItemCustomQueryReq registerReq = new ProductItemCustomQueryReq();
        registerReq.setMerchantNo("110043895");
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        requestParam.setParam(registerReq);

        ResponseData<CreditProductMenuResp> responseData=creditExProductFacade.queryProductItemCustom(requestParam);
        System.out.println(JSONObject.toJSONString(responseData));
    }

    @Test
    public void testQueryAvailableItem() throws Exception {
        CreditExRequestParam<MerchantReq> requestParam = new CreditExRequestParam<>();
        MerchantReq req = new MerchantReq();
        req.setMerchantNo("110043895");
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        requestParam.setParam(req);
        CreditResponseData<CreditProductMenuResp> responseData= creditExProductFacade.queryAvailableItem(requestParam);

        System.out.println(GsonUtil.getInstance().toJson(responseData));
    }

    @Test
    public void testQueryShelvedProductItem() throws Exception {
        CreditExRequestParam<MerchantReq> requestParam = new CreditExRequestParam<>();
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");
        CreditResponseData<CreditProductMenuResp> responseData= creditExProductFacade.queryShelvedProductItem(requestParam);

        System.out.println(GsonUtil.getInstance().toJson(responseData));
    }

}
