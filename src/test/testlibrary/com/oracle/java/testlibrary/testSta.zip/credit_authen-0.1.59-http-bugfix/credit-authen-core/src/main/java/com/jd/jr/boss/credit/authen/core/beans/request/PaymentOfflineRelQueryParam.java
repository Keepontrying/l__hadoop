package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;

/**
 * Created by anmeng on 2017/9/19.
 */
public class PaymentOfflineRelQueryParam implements Serializable {
    private static final long serialVersionUID = 8412820007817550644L;

    private Integer paymentId;
    private Integer billId;

    public Integer getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Integer paymentId) {
        this.paymentId = paymentId;
    }

    public Integer getBillId() {
        return billId;
    }

    public void setBillId(Integer billId) {
        this.billId = billId;
    }
}
