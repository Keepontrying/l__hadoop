package com.jd.jr.boss.credit.authen.core.beans.entity.mongo;

import org.springframework.data.annotation.Id;

import java.io.Serializable;
import java.util.Date;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption : mongo baseEntity
 * @date ：2018/11/6 11:34
 * @return
 */
public abstract class MongoBaseEntity  implements Serializable {

    private static final long serialVersionUID = 8120898326490514988L;
    @Id
    private String id;
    private String creator;
    private Date createdDate;
    private String modifier;
    private Date modifiedDate;
    //数据有效性
    private Boolean effect = true;

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public Boolean getEffect() {
        return effect;
    }

    public void setEffect(Boolean effect) {
        this.effect = effect;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
