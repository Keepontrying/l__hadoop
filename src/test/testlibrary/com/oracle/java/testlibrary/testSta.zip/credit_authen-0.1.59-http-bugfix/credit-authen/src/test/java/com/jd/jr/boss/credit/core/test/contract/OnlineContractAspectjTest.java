package com.jd.jr.boss.credit.core.test.contract;

import java.util.Arrays;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.jd.jr.boss.credit.facade.authen.api.CreditContractFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.OnlineContractQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.enums.CreditTypeEnum;
import com.wangyin.operation.utils.GsonUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})

public class OnlineContractAspectjTest  {
	
	@Resource
	private CreditContractFacade creditContractFacade;
	
	@Test
	public void testMain() {
		try {
			String merchantNo="110014405";
			String merchantCode="110029819001";
			Integer contractId = 360;
			String contrtactNo = "TEST201703250002";
			query(merchantNo, contrtactNo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	 /**
     * 合同查询
     * @param contractQueryRequest
     * @return
     */
    public void query(String merchantNo, String contrtactNo){
    	try {
    		OnlineContractQueryParam qryParam  = new OnlineContractQueryParam();
        	qryParam.setMerchantNo(merchantNo);
        	qryParam.setCreditType(CreditTypeEnum.ENTERPRISE.toName());
        	String contractStatusesStr = "NOPAY,VALID,TERMINATE";
        	String[] contractStatuses = null;
        	if(StringUtils.isNotBlank(contractStatusesStr)){
    			contractStatuses = contractStatusesStr.substring(0).split(",");
    		}
        	qryParam.setContractStatusList(Arrays.asList(contractStatuses));
        	qryParam.setStart(0);
        	qryParam.setLimit(100);
        	CreditPage<CreditContract> result = creditContractFacade.queryCreditContractList(qryParam);
        	if(result.isSuccess()){
        		System.out.println("线上合同查询结果："+GsonUtil.getInstance().toJson(result));
        	}
		} catch (Exception e) {
			System.out.println("线上合同查询异常："+e);
		}
    	
    }
    /**
     * 合同包含产品详情
     * @param contractDetailsRequest
     * @return
     */
    public void details(Integer contractId,String merchantNo,String merchantCode){
    }
    
   
}
