package com.jd.jr.boss.credit.core.test.product;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.jd.jr.boss.credit.facade.authen.api.CreditProductFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.ProductItemQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.entity.CreditItem;
import com.wangyin.operation.utils.GsonUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})

public class ProductAspectjTest {
    @Resource
    private CreditProductFacade productFacade;

//    @Test
    public void mainTest() {
        CreditRequestParam<ProductItemQueryParam> requestParam=new CreditRequestParam<ProductItemQueryParam>();
        ProductItemQueryParam queryParam=new ProductItemQueryParam();
//        queryParam.setItemStatus("SHELVE");
        requestParam.setParam(queryParam);
        CreditResponseData<List<CreditItem>> pageData = productFacade.queryProductItem(requestParam);
        System.out.println("-----------"+GsonUtil.getInstance().toJson(pageData));
    }
    
    @Test
    public void queryProductShowItemTest() {
        CreditRequestParam<ProductItemQueryParam> requestParam=new CreditRequestParam<ProductItemQueryParam>();
        ProductItemQueryParam queryParam=new ProductItemQueryParam();
        queryParam.setMerchantNo("110014405");
        queryParam.setProductSort("CREDIT_SERVICE");
        requestParam.setParam(queryParam);
        CreditResponseData<List<CreditItem>> pageData = productFacade.queryProductShowItem(requestParam);
        System.out.println("-----------"+GsonUtil.getInstance().toJson(pageData));
    }


}
