package com.jd.jr.boss.credit.authen.core.beans.entity.microSmallBusinesses;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 企业信息
 *
 * @author huangzhiqiang
 * @data 2018/3/26
 */
public class Company implements Serializable {
    private static final long serialVersionUID = -1433370888105492645L;

    private Long id;
    /**
     * 企业名称
     */
    private String companyName;
    /**
     * 统一社会信用代码/注册号
     */
    private String creditCode;
    /**
     * 企业类型
     */
    private String companyType;
    /**
     * 成立日期
     */
    private String createDate;
    /**
     * 注册资本
     */
    private String registerCapital;
    /**
     * 登记机关
     */
    private String registerOffice;
    /**
     * 所属门类
     */
    private String category;
    /**
     * 行业
     */
    private String industry;
    /**
     * 企业标签
     */
    private String tag;

    /**
     * 状态
     * 0 - 正常
     * 1- 已移除
     */
    private Integer status;

    private Date createdDate;

    private Date modifiedDate;

    private List<PolicySupportInfo> supportInfo;

    public Long getId() {
        return id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode;
    }

    public String getCompanyType() {
        return companyType;
    }

    public void setCompanyType(String companyType) {
        this.companyType = companyType;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getRegisterCapital() {
        return registerCapital;
    }

    public void setRegisterCapital(String registerCapital) {
        this.registerCapital = registerCapital;
    }

    public String getRegisterOffice() {
        return registerOffice;
    }

    public void setRegisterOffice(String registerOffice) {
        this.registerOffice = registerOffice;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public List<PolicySupportInfo> getSupportInfo() {
        return supportInfo;
    }

    public void setSupportInfo(List<PolicySupportInfo> supportInfo) {
        this.supportInfo = supportInfo;
    }
}
