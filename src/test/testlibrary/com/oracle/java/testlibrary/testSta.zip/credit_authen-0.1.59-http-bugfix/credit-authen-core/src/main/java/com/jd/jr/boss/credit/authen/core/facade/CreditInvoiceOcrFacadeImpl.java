package com.jd.jr.boss.credit.authen.core.facade;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.service.CreditInvoiceOcrService;
import com.jd.jr.boss.credit.authen.core.service.CreditQueryBatchService;
import com.jd.jr.boss.credit.domain.common.entity.CreditQueryBatch;
import com.jd.jr.boss.credit.facade.authen.api.CreditInvoiceOcrFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchInvoiceOcrParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by zhanghui12 on 2018/9/27.
 */
@Service("creditInvoiceOcrFacade")
public class CreditInvoiceOcrFacadeImpl implements CreditInvoiceOcrFacade {
    private Logger logger = LoggerFactory.getLogger(CreditInvoiceOcrFacadeImpl.class);
    @Autowired
    private CreditInvoiceOcrService creditInvoiceOcrService;

    @Autowired
    private CreditQueryBatchService creditQueryBatchService;

    /**
     * 批量提交发票识别
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData batchTrade(CreditRequestParam<BatchInvoiceOcrParam> requestParam) {
        logger.info("Invoice ocr batchTrade begin,param:{}", JSONObject.toJSONString(requestParam));
        CreditResponseData creditResponseData = new CreditResponseData();
        try {
            if (requestParam == null || requestParam.getParam() == null) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("Invoice ocr batchTrade error, requestParam is null");
                return creditResponseData;
            }
            logger.info("Invoice ocr batchTrade save to database");
            String batchNo = null;
            try {
                batchNo = creditInvoiceOcrService.saveBatchAndOrder(requestParam.getParam());
            } catch (Exception e) {
                logger.info(e.getMessage());
            }

            logger.info("异步调用trade发票OCR识别接口");
            creditInvoiceOcrService.batchTrade(requestParam.getParam(), batchNo);

            if (StringUtils.isNotEmpty(batchNo)) {
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
            } else {
                creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
                creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
                creditResponseData.setSuccess(false);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            logger.info("Invoice ocr batchTrade finished,response:{}", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }

    @Override
    public CreditPage<CreditQueryBatch> batchQuery(CreditRequestParam<BatchQueryParam> requestParam) {
        logger.info("batchQuery begin,param:{}", JSONObject.toJSONString(requestParam));
        CreditPage<CreditQueryBatch> creditResponseData = new CreditPage<CreditQueryBatch>();
        try {
            if (requestParam == null || requestParam.getParam() == null) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("batchQuery error, requestParam is null");
                return creditResponseData;
            }
            creditResponseData = creditQueryBatchService.queryBatchHistory(requestParam.getParam());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            logger.info("batchQuery finished,response:{} ", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }

}
