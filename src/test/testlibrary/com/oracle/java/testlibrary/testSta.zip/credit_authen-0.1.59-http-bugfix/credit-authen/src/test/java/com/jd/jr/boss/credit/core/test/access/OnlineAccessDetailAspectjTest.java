package com.jd.jr.boss.credit.core.test.access;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.jd.jr.boss.credit.facade.authen.api.CreditAccessDetailFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditContractFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.AccessDetailQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.OnlineContractQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.wangyin.boss.credit.admin.entity.CreditAccessDetails;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.operation.utils.GsonUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})

public class OnlineAccessDetailAspectjTest  {
	
	@Resource
	private CreditAccessDetailFacade creditAccessDetailFacade;
	
	@Test
	public void testMain() {
		try {
			query();//测试分页查询
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	 /**
     * 合同查询
     * @param contractQueryRequest
     * @return
     */
    public void query(){
    	
    	AccessDetailQueryParam qryParam = new AccessDetailQueryParam();
    	qryParam.setMerchantNo("110014405");
    	qryParam.setCreditType("ENTERPRISE");
//    	qryParam.setStartCreateDateStr("2017-01-01 12:02:23");
//    	qryParam.setEndCreateDateStr("2017-04-01 12:02:23");
    	qryParam.setStart(0);
    	qryParam.setLimit(100);
    	CreditPage<CreditAccessDetails> result = creditAccessDetailFacade.queryAccessDetailsList(qryParam);
    	if(result.isSuccess()){
    		System.out.println("线上明细查询结果："+GsonUtil.getInstance().toJson(result));
    	}
    }
    
   
}
