package com.jd.jr.boss.credit.core.test.listener;

import com.jd.jmq.common.message.Message;
import com.jd.jr.boss.credit.authen.core.jms.CreditMerchant.CreditMerchantAuditListener;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import javax.annotation.Resource;
import java.util.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/spring-authen.xml" })

public class ListenerAspectjTest {
	@Resource
	private CreditMerchantAuditListener creditMerchantAuditListener;
	
	@Test
	public void testMessage() throws Exception {

		List<Message> messages = new ArrayList<Message>();
		Message message = new Message();

		HashMap test = new HashMap();
		test.put("merchantNo", "110040816");

		message.setText(GsonUtil.getInstance().toJson(test));
		messages.add(message);

		creditMerchantAuditListener.onMessage(messages);
	}

	@Test
	public void testPackageMessage() {

//		PaymentNotice paymentNotice = new PaymentNotice();
//		paymentNotice.setSystemId("CAE");
//		paymentNotice.setRequestCode("1_358_20160010");
//		paymentNotice.setPaymentType(CreditPaymentTypeEnum.CREDIT_PACKAGE.toName());
//		paymentNotice.setAmount(BigDecimal.valueOf(1000));
//		paymentNotice.setFinishTime(new Date());
//		paymentNotice.setMerchantNo("110029819");
//		paymentNotice.setPaymentId("payid0106022");
//		paymentNotice.setPaymentResult(PaymentResultEnum.SUCCESS.name());
//		consumerListener.onMessage(paymentNotice);
	}
   
}
