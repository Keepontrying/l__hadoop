package com.jd.jr.boss.credit.core.test.job;

import com.jd.jr.boss.credit.authen.core.beans.entity.mongo.MongoRiskWarnTaskProductResult;
import com.jd.jr.boss.credit.authen.core.beans.request.VipTaskQueryParam;
import com.jd.jr.boss.credit.authen.core.scheduler.VipJop;
import com.jd.jr.boss.credit.authen.core.service.MongoService;
import com.jd.jr.boss.credit.authen.core.service.VipService;
import com.wangyin.boss.credit.admin.entity.CreditVipTask;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Date;
import java.util.List;

/**
 * @author jiangbo
 * @since 2017/6/23
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/spring-authen.xml" })

public class VipJobTest {
    @Autowired
    private VipJop vipJop;

    @Autowired
    private VipService vipService;

    @Autowired
    private MongoService mongoService;

    @Test
    public void testJob() throws Exception {
        vipJop.doJob(null);

    }

    @Test
    public void queryVipTaskTest() throws Exception {
        VipTaskQueryParam vipTaskQueryParam = new VipTaskQueryParam();
        List<CreditVipTask> vipTaskList = vipService.queryVipTask(vipTaskQueryParam);
        System.out.println("queryVipTaskTest responseData: {}"+ GsonUtil.getInstance().toJson(vipTaskList));
    }

    @Test
    public void addRiskWarnUpdateInfoTest() throws Exception {
        try {
            MongoRiskWarnTaskProductResult vipTskResult = new MongoRiskWarnTaskProductResult();
            vipTskResult.setTaskProductId(8);
            vipTskResult.setUpdateInfo("[{\"putReason\":\"未按规定期限公示年度报告\",\"putDate\":\"2016-07-06 00:00:00\",\"putDepartment\":\"北京市工商行政管理局海淀分局\",\"removeReason\":\"— —\",\"removeDate\":\"\",\"removeDepartment\":\"— —\"}]");
            vipTskResult.setResultType("SUCCESS");
            vipTskResult.setResultListSize(1);
            vipTskResult.setTriggerTime(new Date());
            vipTskResult.setResultIdContrast(25);
            vipTskResult.setShareholderStr("");
            vipTskResult.setFringgFlag("");
            vipTskResult.setCreator("jl");
            vipTskResult.setCreatedDate(new Date());
            vipTskResult.setModifier("jl");
            vipTskResult.setModifiedDate(new Date());
            MongoRiskWarnTaskProductResult addResult = mongoService.addRiskWarnUpdateInfo(vipTskResult);
            System.out.println("addRiskWarnUpdateInfo responseData: {}"+ GsonUtil.getInstance().toJson(addResult.getId()));
            System.out.println("id :"+ addResult.getId());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void queryRiskWarnUpdateInfoByIdTest() throws Exception {
        try {
            MongoRiskWarnTaskProductResult vipTskResult = new MongoRiskWarnTaskProductResult();
//            vipTskResult.setId("5be11b27cd9f392eace5157c");
            vipTskResult.setId("5be");
//            vipTskResult.setResultId(1);
            MongoRiskWarnTaskProductResult addResult = mongoService.queryRiskWarnUpdateInfoById(vipTskResult);
            System.out.println("queryRiskWarnUpdateInfoById responseData: {}"+ GsonUtil.getInstance().toJson(addResult.getId()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
