package com.jd.jr.boss.credit.authen.core.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.jd.jr.boss.credit.authen.core.beans.entity.BillDetailsEntity;
import com.jd.jr.boss.credit.authen.core.beans.request.BillDetailsQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditBillDetails;

/**
 *  业务详情管理
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
@Repository
public interface CreditBillDetailsDao {
    /**
     * 汇总交易详情数据
     * @param accessDetailsQueryParam
     * @return
     * @throws Exception
     */
	Integer saveBillDetails(CreditBillDetails billDetails) throws Exception;
    /**
     * 修改账单详单
     * @param accessDetailsQueryParam
     * @return
     * @throws Exception
     */
    Integer updateBillDetails(CreditBillDetails billDetails) throws Exception;
    /**
     * 查询账单详单
     * @param accessDetailsQueryParam
     * @return
     * @throws Exception
     */
    List<CreditBillDetails> queryBillDetails(BillDetailsQueryParam billDetailsQueryParam) throws Exception;

    /**
     * 与上个方法的区别：上个方法不能查询所有purchaseType的情况
     * @param billDetailsQueryParam
     * @return
     * @throws Exception
     */
    List<CreditBillDetails> queryBillDetailsByCondition(BillDetailsQueryParam billDetailsQueryParam) throws Exception;
    /**
     * 查询账单汇总
     * @param accessDetailsQueryParam
     * @return
     * @throws Exception
     */
     List<BillDetailsEntity> querySumBillDetails(BillDetailsQueryParam billDetailsQueryParam) throws Exception ;
     
     /**
      * 修改账单详单中billId
      * @param accessDetailsQueryParam
      * @return
      * @throws Exception
      */
     Integer updateBillDetailsByParam(CreditBillDetails billDetails) throws Exception;

	/*
	 * 修改总笔数
	 */
	Integer updateTotalCount(CreditBillDetails billDetails);
}
