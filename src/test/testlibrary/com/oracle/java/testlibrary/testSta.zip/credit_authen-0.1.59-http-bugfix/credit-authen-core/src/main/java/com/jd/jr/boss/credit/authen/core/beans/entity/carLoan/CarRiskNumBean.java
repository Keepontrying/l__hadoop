package com.jd.jr.boss.credit.authen.core.beans.entity.carLoan;

import java.io.Serializable;

/**
 * Created by liuwei55@jd.com
 * 车贷风险
 * @version 1.0
 * @date : 2018/6/15.
 * @return
 */
public class CarRiskNumBean  implements Serializable {
    private static final long serialVersionUID = -6167783359833103895L;
    /**
     * 拒绝数
     */
    int refuseNum = 0;
    /**
     * 关注数
     */
    int focusNum = 0;
    /**
     * 线程数
     */
    int taskCount = 0;
    /**
     * 筛选开始时间,格式yyyy-MM-dd,如2018-01-01
     */
    private String startFilterDateStr;

    /**
     * 筛选结束时间,格式yyyy-MM-dd,如2018-01-01
     */
    private String endFilterDateStr;

    public int getRefuseNum() {
        return refuseNum;
    }

    public void setRefuseNum(int refuseNum) {
        this.refuseNum = refuseNum;
    }

    public int getFocusNum() {
        return focusNum;
    }

    public void setFocusNum(int focusNum) {
        this.focusNum = focusNum;
    }

    public int getTaskCount() {
        return taskCount;
    }

    public void setTaskCount(int taskCount) {
        this.taskCount = taskCount;
    }

    public String getStartFilterDateStr() {
        return startFilterDateStr;
    }

    public void setStartFilterDateStr(String startFilterDateStr) {
        this.startFilterDateStr = startFilterDateStr;
    }

    public String getEndFilterDateStr() {
        return endFilterDateStr;
    }

    public void setEndFilterDateStr(String endFilterDateStr) {
        this.endFilterDateStr = endFilterDateStr;
    }
}
