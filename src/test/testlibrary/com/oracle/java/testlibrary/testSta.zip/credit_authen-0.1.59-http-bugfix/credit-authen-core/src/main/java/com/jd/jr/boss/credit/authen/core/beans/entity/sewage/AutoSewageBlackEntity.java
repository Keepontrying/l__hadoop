package com.jd.jr.boss.credit.authen.core.beans.entity.sewage;

import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.BlackListData;

import java.io.Serializable;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption : 排污报告 黑名单
 * @date ：2018/11/22 20:40
 * @return
 */
public class AutoSewageBlackEntity extends BlackListData  implements Serializable {
    private static final long serialVersionUID = 1133947589408926739L;
    /**
     * 公司全称
     */
    private String enterpriseName;
    /**
     * 内外部标识
     */
    private String entInnerFlag;
    /**
     * 风险等级
     */
    private String riskLevel;

    public String getEnterpriseName() {
        return enterpriseName;
    }

    public void setEnterpriseName(String enterpriseName) {
        this.enterpriseName = enterpriseName;
    }

    public String getEntInnerFlag() {
        return entInnerFlag;
    }

    public void setEntInnerFlag(String entInnerFlag) {
        this.entInnerFlag = entInnerFlag;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }
}
