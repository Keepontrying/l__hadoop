package com.jd.jr.boss.credit.authen.core.beans.request;

import com.jd.jr.boss.credit.domain.common.enums.WarningRuleTypeEnum;

import java.io.Serializable;

/**
 * Created by anmeng on 2017/1/18.
 */
public class WarningRuleQueryParam implements Serializable {

    private static final long serialVersionUID = 162963153052489766L;
    /**
     * 预警类型
     */
    private WarningRuleTypeEnum ruleType;

    public WarningRuleTypeEnum getRuleType() {
        return ruleType;
    }

    public void setRuleType(WarningRuleTypeEnum ruleType) {
        this.ruleType = ruleType;
    }
}
