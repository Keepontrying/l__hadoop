package com.jd.jr.boss.credit.core.test.job;

import com.jd.jr.boss.credit.authen.core.scheduler.EntBfBetchMonitorJob;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * created by ChenKaiJu on 2018/9/18  20:22
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/spring-authen.xml" })
public class EntBfBetchMonitorJobTest {

    @Autowired
    EntBfBetchMonitorJob entBfBetchMonitorJob;

    @Test
    public void testJob() throws Exception {
        entBfBetchMonitorJob.doJob(null);
    }
}
