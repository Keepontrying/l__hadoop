package com.jd.jr.boss.credit.authen.core.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.jd.jr.boss.credit.authen.core.biz.ContractManageBiz;
import com.jd.jr.boss.credit.facade.site.api.CreditContractFacade;
import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractDetailsRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractQueryRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractVerifyRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.contract.ContractContentResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.contract.ContractDetailsResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.contract.ContractQueryResponse;
import com.jd.jr.boss.credit.facade.site.api.enums.request.ContractVerifyRequestEnum;
import com.jd.jr.boss.credit.facade.site.api.enums.response.ContractManageResponseEnum;
import com.wangyin.commons.util.Logger;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.Response;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;

/**
 *  企业站合同查询接口
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
@Service
public class ContractFacadeImpl implements CreditContractFacade{
	 private Logger logger = new Logger(ContractFacadeImpl.class);
	 @Autowired
	 private ContractManageBiz contractQueryBiz;
	 /**
	     * 合同查询
	     * @param contractQueryRequest
	     * @return
	     */
	@Override
	public Page<ContractQueryResponse> query(
			RequestParam<ContractQueryRequest> contractQueryRequest) {
		logger.info("query 查询合同信息参数：", GsonUtil.getInstance().toJson(contractQueryRequest.getParam()));
		long startTime = System.currentTimeMillis();
		//验证参数
		Page<ContractQueryResponse> page=new Page<ContractQueryResponse>();
		try {
			if (contractQueryRequest == null || contractQueryRequest.getParam() == null) {
				logger.error(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
				page.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				return page;
			}
			if (!StringUtils.hasText(contractQueryRequest.getParam().getMerchantNo())) {
				//判定商户号
				logger.error(ContractManageResponseEnum.PARAM_MERCHANTNO_REQUIRED.toDescription());
				page.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				page.setCode(ContractManageResponseEnum.PARAM_MERCHANTNO_REQUIRED.toName());
				page.setMessage(ContractManageResponseEnum.PARAM_MERCHANTNO_REQUIRED.toDescription());
				return page;
			}
			/*if (!StringUtils.hasText(contractQueryRequest.getParam().getMerchantCode())) {
				//判定账户代码
				logger.error(ContractManageResponseEnum.PARAM_MERCHANTCODE_REQUIRED.toDescription());
				page.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				page.setCode(ContractManageResponseEnum.PARAM_MERCHANTCODE_REQUIRED.toName());
				page.setMessage(ContractManageResponseEnum.PARAM_MERCHANTCODE_REQUIRED.toDescription());
				return page;
			}*/

			//查询合同列表
			 contractQueryBiz.queryContractPage(contractQueryRequest.getParam(),page);
//			if (!page.isSuccess()) {
//				page.setMessage(ResponseMessage.NOT_EXIST.getDesc());
//			}
		} catch (Exception e) {
			logger.error(e);
			page.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
		}
		logger.info("查询合同信息结果：",(System.currentTimeMillis()-startTime)+" ms;"+GsonUtil.getInstance().toJson(page));
		return page;
	}
	/**
     * 合同包含产品详情
     * @param contractDetailsRequest
     * @return
     */
	@Override
	public ResponseData<ContractDetailsResponse> details(
			RequestParam<ContractDetailsRequest> contractDetailsRequest) {
		logger.info("details 查询包含产品详情参数：", GsonUtil.getInstance().toJson(contractDetailsRequest.getParam()));
		long startTime = System.currentTimeMillis();
		ResponseData<ContractDetailsResponse> responseData = new ResponseData<ContractDetailsResponse>();
		//验证参数
		try {
			if (contractDetailsRequest == null || contractDetailsRequest.getParam() == null) {
				logger.error(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
				responseData.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				return responseData;
			}
		/*	if (!StringUtils.hasText(contractDetailsRequest.getParam().getMerchantNo())) {
				//判定商户号
				logger.error(ContractQueryResponseEnum.PARAM_MERCHANTNO_REQUIRED.toDescription());
				responseData.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				responseData.setCode(ContractQueryResponseEnum.PARAM_MERCHANTNO_REQUIRED.toName());
				responseData.setMessage(ContractQueryResponseEnum.PARAM_MERCHANTNO_REQUIRED.toDescription());
				return responseData;
			}
			if (!StringUtils.hasText(contractDetailsRequest.getParam().getMerchantCode())) {
				//判定账户代码
				logger.error(ContractQueryResponseEnum.PARAM_MERCHANTCODE_REQUIRED.toDescription());
				responseData.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				responseData.setCode(ContractQueryResponseEnum.PARAM_MERCHANTCODE_REQUIRED.toName());
				responseData.setMessage(ContractQueryResponseEnum.PARAM_MERCHANTCODE_REQUIRED.toDescription());
				return responseData;
			}*/
			if (!StringUtils.hasText(String.valueOf(contractDetailsRequest.getParam().getContractId()))) {
				//判定合同ID
				logger.error(ContractManageResponseEnum.PARAM_CONTRACTID_REQUIRED.toDescription());
				responseData.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				responseData.setCode(ContractManageResponseEnum.PARAM_CONTRACTID_REQUIRED.toName());
				responseData.setMessage(ContractManageResponseEnum.PARAM_CONTRACTID_REQUIRED.toDescription());
				return responseData;
			}
			//查询合同列表
			 contractQueryBiz.queryContractDetails(contractDetailsRequest.getParam(),responseData);
		} catch (Exception e) {
			logger.error(e);
			responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
		}
		logger.info("查询包含产品详情结果：",(System.currentTimeMillis()-startTime)+" ms;"+GsonUtil.getInstance().toJson(responseData));
		return responseData;
	}
	  /**
     * 合同协议内容
     * @param contractContentRequest
     * @return
     */
	@Override
	public ResponseData<ContractContentResponse> content(
			RequestParam<ContractDetailsRequest> contractContentRequest) {
		logger.info("content 查询合同协议内容参数：", GsonUtil.getInstance().toJson(contractContentRequest.getParam()));
		long startTime = System.currentTimeMillis();
		ResponseData<ContractContentResponse> responseData = new ResponseData<ContractContentResponse>();
		//验证参数
		try {
			if (contractContentRequest == null || contractContentRequest.getParam() == null) {
				logger.error(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
				responseData.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				return responseData;
			}
			if (!StringUtils.hasText(String.valueOf(contractContentRequest.getParam().getContractId()))) {
				//判定合同ID
				logger.error(ContractManageResponseEnum.PARAM_CONTRACTID_REQUIRED.toDescription());
				responseData.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				responseData.setCode(ContractManageResponseEnum.PARAM_CONTRACTID_REQUIRED.toName());
				responseData.setMessage(ContractManageResponseEnum.PARAM_CONTRACTID_REQUIRED.toDescription());
				return responseData;
			}
			//查询合同内容
			contractQueryBiz.queryContractContent(contractContentRequest.getParam(),responseData);
		} catch (Exception e) {
			logger.error(e);
			responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
		}
		logger.info("查询合同内容结果：",(System.currentTimeMillis()-startTime)+" ms;"+GsonUtil.getInstance().toJson(responseData));
		return responseData;
	}
	/**
     * 合同确认结果
     * @param contractVerifyRequest
     * @return
     */
	@Override
	public Response verify(RequestParam<ContractVerifyRequest> contractVerifyRequest) {
		logger.info("verify 合同确认参数：", GsonUtil.getInstance().toJson(contractVerifyRequest.getParam()));
		long startTime = System.currentTimeMillis();
		Response response = new Response();
		//验证参数
		try {
			if (contractVerifyRequest == null || contractVerifyRequest.getParam() == null) {
				logger.error(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
				response.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				return response;
			}
			if (!StringUtils.hasText(String.valueOf(contractVerifyRequest.getParam().getContractId()))) {
				//判定合同ID
				logger.error(ContractManageResponseEnum.PARAM_CONTRACTID_REQUIRED.toDescription());
				response.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				response.setCode(ContractManageResponseEnum.PARAM_CONTRACTID_REQUIRED.toName());
				response.setMessage(ContractManageResponseEnum.PARAM_CONTRACTID_REQUIRED.toDescription());
				return response;
			}if (!StringUtils.hasText(contractVerifyRequest.getParam().getVerifyStatus().toName())) {
				//判定合同确认状态
				logger.error(ContractManageResponseEnum.PARAM_CONTRACTSTATUS_REQUIRED.toDescription());
				response.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				response.setCode(ContractManageResponseEnum.PARAM_CONTRACTSTATUS_REQUIRED.toName());
				response.setMessage(ContractManageResponseEnum.PARAM_CONTRACTSTATUS_REQUIRED.toDescription());
				return response;
			}if (!ContractVerifyRequestEnum.PASS.toName().equals(contractVerifyRequest.getParam().getVerifyStatus().toName())) {
				//判定合同确认状态为确认状态
				logger.error(ContractManageResponseEnum.PARAM_CONTRACTSTATUS_REQUIRED.toDescription());
				response.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
				response.setCode(ContractManageResponseEnum.PARAM_CONTRACTSTATUS_REQUIRED.toName());
				response.setMessage(ContractManageResponseEnum.PARAM_CONTRACTSTATUS_REQUIRED.toDescription());
				return response;
			}
			//确认合同
			contractQueryBiz.updateContractVerify(contractVerifyRequest.getParam(),response);
		} catch (Exception e) {
			logger.error(e);
			response.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
		}
		logger.info("合同确认结果：",(System.currentTimeMillis()-startTime)+" ms;"+GsonUtil.getInstance().toJson(response));
		return response;
	}
}
