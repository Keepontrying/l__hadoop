package com.jd.jr.boss.credit.authen.core.exception;

/**
 *authen 存库 异常
 */
public class CreditAuthenException extends RuntimeException {

	/**
	 *
	 */
	private static final long serialVersionUID = -1066922463769034687L;

	public CreditAuthenException(String message){
		super(message);
	}

	public CreditAuthenException(){
		super("存库异常");
	}
}
