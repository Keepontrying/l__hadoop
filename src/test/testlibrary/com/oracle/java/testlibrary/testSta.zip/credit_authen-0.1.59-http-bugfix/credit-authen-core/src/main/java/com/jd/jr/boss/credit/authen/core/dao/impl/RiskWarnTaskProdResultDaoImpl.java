package com.jd.jr.boss.credit.authen.core.dao.impl;

import com.jd.jr.boss.credit.authen.core.beans.entity.mongo.MongoRiskWarnTaskProductResult;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption :
 * @date ：2018/11/6 18:48
 * @return
 */
@Component("riskWarnTaskProdResultDao")
public class RiskWarnTaskProdResultDaoImpl extends BaseMongoDaoImpl<MongoRiskWarnTaskProductResult>{
    @Override
    protected Class<MongoRiskWarnTaskProductResult> getEntityClass() {
        return MongoRiskWarnTaskProductResult.class;
    }
}
