package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;

import com.wangyin.boss.credit.admin.entity.CreditBillDetails;

/**
 *  账单详情实体类
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
public class BillDetailsEntity  extends CreditBillDetails  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7879975684733813526L;
	/**
	 * 商户名称
	 */
	private String merchantName;
	/**
	 * 产品名称
	 */
    private String productName;
    /**
	 * 包量次数
	 */
    private Integer packageCount;
    /**
	 * 包量总金额
	 */
	private Long packageAmount;
	/**
	 * 单笔总金额
	 */
	private Long singleAmount;


	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Integer getPackageCount() {
		return packageCount;
	}
	public void setPackageCount(Integer packageCount) {
		this.packageCount = packageCount;
	}

	public Long getPackageAmount() {
		return packageAmount;
	}

	public void setPackageAmount(Long packageAmount) {
		this.packageAmount = packageAmount;
	}


	public Long getSingleAmount() {
		return singleAmount;
	}

	public void setSingleAmount(Long singleAmount) {
		this.singleAmount = singleAmount;
	}

}
