package com.jd.jr.boss.credit.core.test.external;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.facade.common.dto.CreditExRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.external.api.CreditExOrderFacade;
import com.jd.jr.boss.credit.facade.external.api.CreditExUserCenterFacade;
import com.jd.jr.boss.credit.facade.external.beans.request.*;
import com.jd.jr.boss.credit.facade.external.beans.response.*;
import com.jd.jr.boss.credit.facade.external.enums.CreditDateRangeEnum;
import com.jd.jr.boss.credit.facade.external.enums.CreditOrderStatusEnum;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/**
 * Created by anmeng on 2018/5/29.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:springtest/jsf-consumer.xml" })
public class CreditUserCenterFacadeTest {

    @Autowired
    private CreditExUserCenterFacade userCenterFacade;

    @Test
    public void testQueryOverview(){
        CreditExRequestParam<MerchantReq> requestParam=new CreditExRequestParam<MerchantReq>();
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        MerchantReq req=new MerchantReq();
        req.setMerchantNo("110038298");
        requestParam.setParam(req);

        CreditResponseData<CreditUserOverviewResp> responseData= userCenterFacade.queryOverview(requestParam);
        System.out.println(JSONObject.toJSONString(responseData));
    }

    @Test
    public void testQueryBillCount(){
        CreditExRequestParam<CreditBillQueryReq> requestParam=new CreditExRequestParam<>();
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        CreditBillQueryReq req=new CreditBillQueryReq();
        req.setMerchantNo("110038298");
        req.setDateRange(CreditDateRangeEnum.PERIOD_WEEK);
        requestParam.setParam(req);

        CreditResponseData<List<CreditBillChartResp>> responseData= userCenterFacade.queryBillCount(requestParam);
        System.out.println(JSONObject.toJSONString(responseData));
    }

    @Test
    public void testQueryAccessDetail(){
        CreditExRequestParam<CreditAccessDetailQueryReq> requestParam=new CreditExRequestParam<>();
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        CreditAccessDetailQueryReq req=new CreditAccessDetailQueryReq();
        req.setMerchantNo("110043898");
        req.setProductCode("ENT_BASIC_QUERY");
//        req.setDateRange(CreditDateRangeEnum.PERIOD_DAY);
        req.setPageSize(100);
        req.setPageIndex(1);
        requestParam.setParam(req);

        CreditResponseData<List<CreditAccessDetailResp>> responseData= userCenterFacade.queryAccessDetail(requestParam);
        System.out.println(JSONObject.toJSONString(responseData));
    }

    @Test
    public void testQueryOrderRemaining(){
        CreditExRequestParam<OrderRemainingQueryReq> requestParam=new CreditExRequestParam<>();
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        OrderRemainingQueryReq req=new OrderRemainingQueryReq();
        req.setMerchantNo("110038298");
        req.setOrderStatus(CreditOrderStatusEnum.VALID);
        req.setPageIndex(1);
        req.setPageSize(10);
        requestParam.setParam(req);

        CreditResponseData<List<CreditOrderRemainingResp>> responseData= userCenterFacade.queryOrderRemaining(requestParam);
        System.out.println(JSONObject.toJSONString(responseData));
    }


}
