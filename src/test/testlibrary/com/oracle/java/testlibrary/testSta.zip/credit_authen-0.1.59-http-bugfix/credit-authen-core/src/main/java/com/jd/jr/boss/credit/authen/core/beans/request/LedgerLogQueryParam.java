package com.jd.jr.boss.credit.authen.core.beans.request;

import com.jd.jr.boss.credit.domain.common.enums.LedgerTypeEnum;

import java.io.Serializable;
import java.util.List;

/**
 * Created by anmeng on 2016/12/27.
 */
public class LedgerLogQueryParam implements Serializable {
    private static final long serialVersionUID = -6500052370775879090L;

    private String ledgerDate;//报账日期

    private String ledgerType;//报账类型

    private String merchantNo;//商户号

    private List<String> statusList;//状态

    public String getLedgerDate() {
        return ledgerDate;
    }

    public void setLedgerDate(String ledgerDate) {
        this.ledgerDate = ledgerDate;
    }

    public String getLedgerType() {
        return ledgerType;
    }

    public void setLedgerType(String ledgerType) {
        this.ledgerType = ledgerType;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public List<String> getStatusList() {
        return statusList;
    }

    public void setStatusList(List<String> statusList) {
        this.statusList = statusList;
    }
}
