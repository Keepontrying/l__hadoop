package com.jd.jr.boss.credit.authen.core.jms.AntiFraud;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonSyntaxException;
import com.jd.jmq.client.consumer.MessageListener;
import com.jd.jmq.client.producer.MessageProducer;
import com.jd.jmq.common.message.Message;
import com.jd.jr.boss.credit.authen.core.beans.entity.AntiFraudEntity;
import com.jd.jr.boss.credit.authen.core.constants.SystemConstants;
import com.jd.jr.boss.credit.authen.core.service.CreditChargeService;
import com.jd.jr.boss.credit.authen.core.service.CreditUserService;
import com.jd.jr.boss.credit.authen.core.service.MsgProducerService;
import com.jd.jr.boss.credit.domain.common.enums.CreditChannelInterfaceCodeInsCodeEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditChannelTypeEnum;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.AntiFraudFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.ResultData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.external.ExternalArgs;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.antiFraud.AntiFraudAndChargeParam;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.RequestReferEnum;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.response.ResultDataEnum;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.entity.InterfaceFlow;
import com.wangyin.boss.credit.admin.enums.EnterpriseProductEnum4Common;
import com.wangyin.operation.utils.GsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * 反欺诈--- 黄赌毒
 * @author liuwei55
 * @since 2017/7/6
 */
@Component("creditAntiFraudListener")
public class CreditAntiFraudListener implements MessageListener {
    private static Logger logger = LoggerFactory.getLogger(CreditAntiFraudListener.class);
    @Resource
    private CreditUserService creditUserService;
    @Resource
    private AntiFraudFacade antiFraudFacade;
    @Resource
    private MessageProducer producer;
    @Resource
    private CreditChargeService creditChargeService;
    @Resource
    private MsgProducerService msgProducerService;

    @Override
    public void onMessage(List<Message> messages) throws Exception {
        if (messages == null || messages.isEmpty()) {
            logger.warn("creditAntiFraudListener message is null");
            return;
        }
        for (Message message : messages) {
            String objectJson = message.getText();
            JSONObject messageInfo = null;
            boolean refundRedisResult = false;
            String balanceKey = null;
            long amount = 1;//批次回量均为1---即次数
            try {
                messageInfo = JSON.parseObject(objectJson);
            } catch (JsonSyntaxException e) {
                logger.error("message json format error："+objectJson);
                continue;
            }

            try {
                if(null == messageInfo){
                    logger.info("format batchMqVo error,batchMqVo:{}", GsonUtil.getInstance().toJson(messageInfo));
                    continue;
                }
                logger.info("antifaud request"+objectJson);
                CreditResponseData<AntiFraudEntity> response =new CreditResponseData<AntiFraudEntity>();
                String code = (String)messageInfo.get("code");
                JSONArray resultArray = (JSONArray)messageInfo.get("result");
                JSONObject resultJson = resultArray.getJSONObject(0);
                AntiFraudEntity antiFraudEntity = new AntiFraudEntity();
                antiFraudEntity.setMerchantName(resultJson.get("merchantName")+"");
                antiFraudEntity.setMerchantNum(resultJson.get("merchantNum")+"");
                antiFraudEntity.setWebSiteUrl(resultJson.get("webSiteUrl")+"");
                String businessId = getBusinessId();

                //无论查询结果是否为终态，均把缓存中的预扣量返还
                balanceKey = "balance_"+ antiFraudEntity.getMerchantNum()+ "_"+EnterpriseProductEnum4Common.ENTERPRISE_ENT_ANTIFRUD_QUERY.toName();//商户号+产品code
                refundRedisResult = creditChargeService.refundRedisBanlance(balanceKey, amount);
                logger.info("antifaud refundRedisBanlance refundRedisResult,{}", refundRedisResult);
                //调用计费接口
                String isHit = resultJson.get("isHit")+"";
                CreditRequestParam<AntiFraudAndChargeParam> requestParam4Cahrge=new CreditRequestParam<AntiFraudAndChargeParam>();
                requestParam4Cahrge.setSystemId(resultJson.get("systemId")+"");
                requestParam4Cahrge.setTradeNo(businessId);
                ExternalArgs arg = new ExternalArgs();
                arg.setReferEnum(RequestReferEnum.API);
                requestParam4Cahrge.setArg(arg);
                AntiFraudAndChargeParam antiFraudReqParam= new AntiFraudAndChargeParam();
                antiFraudReqParam.setMerchantName(antiFraudEntity.getMerchantName());
                antiFraudReqParam.setMerchantNum(antiFraudEntity.getMerchantNum());
                antiFraudReqParam.setWebSiteUrl(antiFraudEntity.getWebSiteUrl());
                antiFraudReqParam.setIsHit("0".equals(isHit)?"HIT":"NOTHIT");
                antiFraudReqParam.setKeyWord(resultJson.get("keyWords")+"");
                String tradeNo = businessId;

                if("0".equals(code)){  //成功
                    antiFraudReqParam.setDoCharge(true);
                    antiFraudReqParam.setCode(code);
                    requestParam4Cahrge.setParam(antiFraudReqParam);
                    CreditResponseData<ResultData<AntiFraudAndChargeParam,String>> chargeRes = antiFraudFacade.charge(requestParam4Cahrge);
                    if(null != chargeRes){
                        tradeNo = chargeRes.getTradeNo();
                    }
                    if(chargeRes.isSuccess()){
                        antiFraudEntity.setIsHit("0".equals(isHit)?"HIT":"NOTHIT");
                        antiFraudEntity.setKeyWord(resultJson.get("keyWords")+"");
                    }else {
                        if(ResultDataEnum.RESULT_BALANCE_LACK.toName().equals(chargeRes.getCode())||ResultDataEnum.RESULT_SERVICE_NOSTRATEGY.toName().equals(chargeRes.getCode())){
                            response.setCode(chargeRes.getCode());
                            response.setMessage("计费不足");
                        }else {
                            response.setCode("CHARGE_FAIL");
                            response.setMessage("计费失败");
                        }
                        response.setSuccess(false);
                    }
                }else{
                    response.setSuccess(false);
                    response.setCode("FAIL");
                    response.setMessage("爬取失败");
                    antiFraudReqParam.setDoCharge(false);
                    antiFraudReqParam.setCode(code);
                    requestParam4Cahrge.setParam(antiFraudReqParam);
                    CreditResponseData<ResultData<AntiFraudAndChargeParam,String>> chargeRes = antiFraudFacade.charge(requestParam4Cahrge);
                    if(null != chargeRes){
                        tradeNo = chargeRes.getTradeNo();
                    }
                }
                try {
                    InterfaceFlow interfaceFlow = new InterfaceFlow();
                    interfaceFlow.setInsCode(CreditChannelInterfaceCodeInsCodeEnum.customsQuerySingle.getInsCode());//
                    interfaceFlow.setInterfaceCode(CreditChannelInterfaceCodeInsCodeEnum.customsQuerySingle.getInterfaceCode());//
                    interfaceFlow.setTradeNo(tradeNo);
                    Date date = new Date();
                    interfaceFlow.setRequestTime(date);
                    interfaceFlow.setResponseTime(date);
                    interfaceFlow.setReturnCode(code);
                    interfaceFlow.setReturnStatus(org.apache.commons.lang3.StringUtils.isNotBlank(code)&&("0".equals(code)) ? "true" : "false");
                    String requestParamStr = GsonUtil.getInstance().toJson(antiFraudReqParam);
                    interfaceFlow.setRequestParam(requestParamStr);
                    interfaceFlow.setReturnMsg(null);
                    interfaceFlow.setResponseParam(objectJson);
                    interfaceFlow.setChannel(CreditChannelTypeEnum.DATA_DEPARTMENT + "");
                    interfaceFlow.setFromCache(false);
                    msgProducerService.sendChannelLogFmqMsg(interfaceFlow);
                    logger.info("creditAntiFraudListener sendChannelLogFmqMsg success, mq: {}", GsonUtil.getInstance().toJson(interfaceFlow));
                } catch (Exception e) {
                    logger.error("creditAntiFraudListener sendChannelLogFmqMsg error, {}", e);
                }

                response.setData(antiFraudEntity);
                String content= JSONObject.toJSONString(response);
                String topic = ConfigUtil.getString(SystemConstants.ANTIFRAUD_PROVIDER_JMQ);

                logger.info("creditAntiFraudListener sendMessge:"+content+","+topic+","+businessId);
                //发送消息
                Message sendMessage = new Message(topic, content, businessId);
                producer.send(sendMessage);
            } catch (Exception e) {
                logger.error("creditAntiFraudListener error,{} ", e);
            }finally {
                if(!refundRedisResult){//上方退还预扣失败，则再次尝试回量预扣款
                    refundRedisResult = creditChargeService.refundRedisBanlance(balanceKey, amount);
                }
            }
        }
    }
    private String getBusinessId(){
        DateFormat df=new SimpleDateFormat("yyyyMMddHHmmssSSS");
        String timeStr=df.format(new Date());
        return timeStr;
    }

    public static void main(String[] args) {
      String objectJson = "{\"result\": \"1\", \"code\": \"\", \"msg\": \"\",\"data\": { \"result\": {\"merchantNum \": \"xxxxxx\",\"merchantName \": \"xxxxxx\",\"isHit\": \"\",\"webSiteUrl \": \"www.hei114.com\",\"keyWords\": \"黄，赌，毒\"},\"code\": \"0\", \"message\": \"\",\"crawl_time\": \"2017-11-24\"}}\n";
      JSONObject messageInfo = JSON.parseObject(objectJson);
        String result = (String)messageInfo.get("result");
      JSONObject data = (JSONObject)messageInfo.get("data");
//        JSONObject data = JSON.parseObject(dataStr);
        System.out.println(data.get("code"));
        System.out.println(data.get("result"));
    }

}
