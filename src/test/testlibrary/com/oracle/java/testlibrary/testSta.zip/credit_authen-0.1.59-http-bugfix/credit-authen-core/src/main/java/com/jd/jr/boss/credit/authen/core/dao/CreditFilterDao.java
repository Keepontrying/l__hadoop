package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.facade.common.entity.Industry;
import com.jd.jr.boss.credit.facade.common.entity.Province;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2017/9/11
 */
@Repository
public interface CreditFilterDao {

    /**
     * 查询行业信息
     *
     * @return
     */
    List<Industry> queryIndustry();

    /**
     * 查询省份
     *
     * @return
     */
    List<Province> queryProvince();

}
