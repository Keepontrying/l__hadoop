package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;
import java.util.Date;

/**
 * @author jiangbo
 * @since 2017/6/15
 */
public class VipTriggerQueryParam implements Serializable {
    private static final long serialVersionUID = -7088219332061733556L;
    /**
     * 触发时间
     */
    private Integer triggerTime;

    /**
     * vip状态
     */
    private String vipStatus;

    /**
     * 监控状态
     */
    private String monitorStatus;

    public Integer getTriggerTime() {
        return triggerTime;
    }

    public void setTriggerTime(Integer triggerTime) {
        this.triggerTime = triggerTime;
    }

    public String getVipStatus() {
        return vipStatus;
    }

    public void setVipStatus(String vipStatus) {
        this.vipStatus = vipStatus;
    }

    public String getMonitorStatus() {
        return monitorStatus;
    }

    public void setMonitorStatus(String monitorStatus) {
        this.monitorStatus = monitorStatus;
    }
}
