package com.jd.jr.boss.credit.authen.core.facade.portal;

import java.io.ByteArrayInputStream;
import java.util.List;

import javax.annotation.Resource;

import com.jd.jr.boss.credit.authen.core.task.AutoSewageParentService;
import com.jd.jr.boss.credit.facade.authen.beans.param.ContractProductParam;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.ChannelSftp;
import com.jd.jr.boss.credit.authen.core.beans.request.AutoSewageParam;
import com.jd.jr.boss.credit.authen.core.service.AutoSewageService;
import com.jd.jr.boss.credit.authen.core.service.FileService;
import com.jd.jr.boss.credit.authen.core.utils.SFTPClient;
import com.jd.jr.boss.credit.facade.authen.api.CreditFileFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.FileQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.UploadFile2SftpParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.admin.frame.utils.SFTPUtil;
import com.wangyin.boss.credit.admin.entity.CreditUploadFile;
import com.wangyin.operation.utils.GsonUtil;

/**
 * Created by anmeng on 2017/7/28.
 */
@Service("creditFileFacade")
public class CreditFileFacadeImpl implements CreditFileFacade{

    private static final Logger LOGGER = LoggerFactory.getLogger(CreditFileFacadeImpl.class);

    @Resource
    private FileService fileService;

    @Resource
    private AutoSewageService autoSewageService;
    @Resource
    private AutoSewageParentService autoSewageParentService;

    /**
     * 查询上传文件列表
     *
     * @param requestParam
     * @return
     */
    @Override
    public List<CreditUploadFile> queryUploadFile(CreditRequestParam<FileQueryParam> requestParam) {
        return fileService.queryUploadFileList(requestParam);
    }

    /**
     * 创建文件
     *
     * @param requestParam
     * @return
     */
    @Override
    public int insertFile(CreditRequestParam<CreditUploadFile> requestParam) {
        return fileService.createUploadFile(requestParam);
    }

    @Override
    public int updateFileById(CreditRequestParam<CreditUploadFile> requestParam) {
        return fileService.updateFileById(requestParam);
    }

    @Override
    public boolean uploadEliminateNegativeReportFile2SFTP(CreditRequestParam<UploadFile2SftpParam> requestParam) {
        boolean flag = false;
        UploadFile2SftpParam uploadFile = requestParam.getParam();
        String fileName = uploadFile.getFileName();
        ChannelSftp sftp = null;
        try {
            sftp = SFTPClient.getSftp();
            LOGGER.info("【sftp 成功,上传SFTP开始】");
//            String finalPath = SIGN_CODE_PATH + DateTime.now().toString("yyyyMMdd");
            String finalPath = uploadFile.getFilepath();
            if(StringUtils.isBlank(finalPath) || StringUtils.isBlank(fileName)){
                return false;
            }
            SFTPUtil.createDir(sftp, uploadFile.getFilepath());
            Long sftpStart = System.currentTimeMillis();
            ByteArrayInputStream is = new ByteArrayInputStream(uploadFile.getByteArry());
            flag = SFTPUtil.upload(sftp, finalPath, fileName, is);
            LOGGER.info("SFTPUtil.upload falg:" + flag );
            Long sftpEnd = System.currentTimeMillis();
            LOGGER.info("【上传SFTP结束，花费时间】" + (sftpEnd - sftpStart));
            if (flag) {
                flag = true;
            }
            CreditRequestParam<AutoSewageParam> autoSewageReqParam = new CreditRequestParam<AutoSewageParam>();
            autoSewageReqParam.setOperator(requestParam.getOperator());
            autoSewageReqParam.setSystemId(requestParam.getSystemId());
            autoSewageReqParam.setTradeNo(requestParam.getTradeNo());
            AutoSewageParam autoSewage = new AutoSewageParam();
            autoSewage.setBatchNo(requestParam.getParam().getBatchNo());
            autoSewage.setMerchantNo(requestParam.getParam().getMerchantNo());
            autoSewage.setPath(requestParam.getParam().getFilepath() + "/" +requestParam.getParam().getFileName());
            autoSewage.setType(requestParam.getParam().getType());
            autoSewage.setStartFilterDateStr(requestParam.getParam().getStartFilterDateStr());
            autoSewage.setEndFilterDateStr(requestParam.getParam().getEndFilterDateStr());
            autoSewageReqParam.setParam(autoSewage);
            LOGGER.info("autoSewageService.query requestParam:" + GsonUtil.getInstance().toJson(autoSewageReqParam));
            CreditResponseData<String> autoSewageResponse = autoSewageService.query(autoSewageReqParam);
            LOGGER.info("autoSewageService.query responseData:" + GsonUtil.getInstance().toJson(autoSewageResponse));
            flag = autoSewageResponse.isSuccess();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            SFTPUtil.close(sftp);
            LOGGER.info("【上传SFTP成功】" + fileName);
        }
        return flag;
    }
    public void testMethod(String file,String startDate,String endDate,String batchNo){
        CreditRequestParam<AutoSewageParam> param=new CreditRequestParam<>();
        param.setTradeNo("aa");
        AutoSewageParam autoSewageParam = new AutoSewageParam();
        autoSewageParam.setMerchantNo("110040816");
        autoSewageParam.setPath(file);
        autoSewageParam.setBatchNo(batchNo);
        autoSewageParam.setEndFilterDateStr(endDate);
        autoSewageParam.setStartFilterDateStr(startDate);
        param.setParam(autoSewageParam);
        param.setSystemId("a3884c68df2711e7a293ecf4bbcdd49c");
        autoSewageParentService.doProExecute(param);
    }

    @Override
    public void testMethod2(ContractProductParam param) {

    }
}
