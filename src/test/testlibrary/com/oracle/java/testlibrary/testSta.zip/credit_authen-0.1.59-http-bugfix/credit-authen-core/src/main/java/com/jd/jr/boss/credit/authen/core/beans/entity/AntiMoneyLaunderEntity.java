package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * created by ChenKaiJu on 2018/7/17  15:46
 */
public class AntiMoneyLaunderEntity implements Serializable {

    private static final long serialVersionUID = -2813574409378941365L;
    int applyId;
    int id;
    String eBlicCName;
    Date createdDate;
    String modifiedTime;
    String resultStatus;
    String result;
    String regNo;
    String creditCode;

    //拓展字段，字段表示监控企业的id
    int entpriseId;
    //标识 vip代表vip渠道
    String flagMark;

    public int getApplyId() {
        return applyId;
    }

    public void setApplyId(int applyId) {
        this.applyId = applyId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String geteBlicCName() {
        return eBlicCName;
    }

    public void seteBlicCName(String eBlicCName) {
        this.eBlicCName = eBlicCName;
    }


    public String getModifiedTime() {
        return modifiedTime;
    }

    public void setModifiedTime(String modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public String getResultStatus() {
        return resultStatus;
    }

    public void setResultStatus(String resultStatus) {
        this.resultStatus = resultStatus;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode;
    }

    public int getEntpriseId() {
        return entpriseId;
    }

    public void setEntpriseId(int entpriseId) {
        this.entpriseId = entpriseId;
    }

    public String getFlagMark() {
        return flagMark;
    }

    public void setFlagMark(String flagMark) {
        this.flagMark = flagMark;
    }
}
