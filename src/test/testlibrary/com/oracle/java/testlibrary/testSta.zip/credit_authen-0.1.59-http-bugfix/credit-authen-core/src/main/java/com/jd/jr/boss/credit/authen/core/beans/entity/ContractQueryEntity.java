package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.Date;

import com.jd.jr.boss.credit.domain.common.enums.CreditPurchaseTypeEnum;
import com.jd.jr.boss.credit.facade.site.api.dto.BaseDto;

/**
 *  企业站合同查询结果
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
public class ContractQueryEntity extends BaseDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3055091390902449136L;
	/**
     * 合同ID
     */
    private Integer contractId;
    /**
     * 合同编号
     */
    private String contractNo;
    /**
     * 开始时间
     */
    private Date startTime;
    /**
     * 结束时间
     */
    private Date finishTime;
    /**
     * 合同状态
     */
    private String contractStatus;
    /**
     * 产品名称
     */
    private String productNames;
    /**
     * 商户名称
     */
    private String merchantName;

	private CreditPurchaseTypeEnum purchaseType;//付费方式
	private String creator;//创建人
	private Integer merchantId;//商户ID

	public Integer getContractId() {
		return contractId;
	}
	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}
	public String getContractNo() {
		return contractNo;
	}
	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getFinishTime() {
		return finishTime;
	}
	public void setFinishTime(Date finishTime) {
		this.finishTime = finishTime;
	}
	public String getContractStatus() {
		return contractStatus;
	}
	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}
	public String getProductNames() {
		return productNames;
	}
	public void setProductNames(String productNames) {
		this.productNames = productNames;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public CreditPurchaseTypeEnum getPurchaseType() {
		return purchaseType;
	}

	public void setPurchaseType(CreditPurchaseTypeEnum purchaseType) {
		this.purchaseType = purchaseType;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}
}
