package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.request.PaymentOfflineRelQueryParam;
import com.jd.jr.boss.credit.domain.common.entity.CreditPaymentOffline;
import com.jd.jr.boss.credit.domain.common.entity.CreditPaymentOfflineRel;
import com.jd.jr.boss.credit.facade.authen.beans.param.PaymentOfflineQueryParam;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by anmeng on 2017/9/13.
 */
@Repository
public interface CreditPaymentOfflineDao {
    /**
     * 创建线下收款单
     * @param payment
     * @return
     */
    int insert(CreditPaymentOffline payment);

    /**
     * 查询线下收款单列表
     * @param queryParam
     * @return
     */
    List<CreditPaymentOffline> query(PaymentOfflineQueryParam queryParam);

    /**
     * 查询线下收款单列表总条数
     * @param queryParam
     * @return
     */
    Long queryCount(PaymentOfflineQueryParam queryParam);

    /**
     * 插入收款单关联明细表
     * @param relList
     * @return
     */
    int insertRelList(List<CreditPaymentOfflineRel> relList);

    /**
     * 更新收款单状态和剩余金额
     * @param payment
     * @return
     */
    int update(CreditPaymentOffline payment);

    /**
     * 查询账单与付款单关联表
     * @param queryParam
     * @return
     */
    List<CreditPaymentOfflineRel> queryPaymentRel(PaymentOfflineRelQueryParam queryParam);
}
