package com.jd.jr.boss.credit.authen.core.scheduler;

import com.jd.fastjson.JSON;
import com.jd.jr.boss.credit.authen.core.beans.entity.AntiMoneyLaunderEntity;
import com.jd.jr.boss.credit.authen.core.beans.request.AntiMoneyLQueryParam;
import com.jd.jr.boss.credit.authen.core.dao.CreditAntiMoneyLaunderDataDao;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.common.enums.ResponseCodeEnum;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.AntiMoneyLaunderFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.ResultData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.CdAntiMoneyLaunderParam;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.antiMoneyLaunder.chinaData.ChinaDataAntiMoneyLaunderResp;
import com.jd.jr.boss.credit.gateway.account.utils.SerialNoUtils;
import com.wangyin.commons.util.Logger;
import com.wangyin.schedule.client.job.ScheduleContext;
import com.wangyin.schedule.client.job.SchedulerJob;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * 反洗钱增量数据表定时更新任务
 * created by ChenKaiJu on 2018/7/16  10:05
 */
@Service
public class AntiMoneyUpdateJob implements SchedulerJob {

    private Logger logger = new Logger(AntiMoneyUpdateJob.class);

    @Resource
    AntiMoneyLaunderFacade antiMoneyLaunderFacade;

    @Resource
    CreditAntiMoneyLaunderDataDao creditAntiMoneyLaunderDataDao;


    @Override
    public void doJob(ScheduleContext scheduleContext) throws Exception {
        SimpleDateFormat changeformat=new SimpleDateFormat("YYYY-MM-dd HH:mm:ss");
        logger.info("进入企业反洗钱增量信息更新任务。。。");
        Map<String,String> parameters= scheduleContext.getParameters();
        String SystemId=parameters.get("SystemId");
        if(StringUtils.isBlank(SystemId)){
            throw new Exception("SystemId用户名不能为空");
        }
        AntiMoneyLQueryParam antiparam=formParam(parameters);
        logger.info("查询sql入参："+JSON.toJSONString(antiparam));
        List<AntiMoneyLaunderEntity> cdAntiMoneyList= creditAntiMoneyLaunderDataDao.findEntByTime(antiparam);
        logger.info("根据创建日期查询数据库返回结果："+JSON.toJSONString(cdAntiMoneyList));
        CreditRequestParam<CdAntiMoneyLaunderParam> requestParam=new CreditRequestParam<>();
        requestParam.setTradeNo(SerialNoUtils.createSerialNo("TRADE"));
        requestParam.setSystemId(SystemId);
        CdAntiMoneyLaunderParam param=new CdAntiMoneyLaunderParam();
        for(AntiMoneyLaunderEntity entity:cdAntiMoneyList){
            try{
                param.setEntName(entity.geteBlicCName());
                requestParam.setParam(param);
                logger.info("反洗钱接口调用参数："+JSON.toJSONString(requestParam));
                CreditResponseData<ResultData<CdAntiMoneyLaunderParam, ChinaDataAntiMoneyLaunderResp>> responseData=antiMoneyLaunderFacade.cdDetailQuery(requestParam);
                entity.setModifiedTime(changeformat.format(new Date()));
                logger.info("反洗钱接口返回："+JSON.toJSONString(responseData));
                ResultData resultData=responseData.getData();
                if(resultData!=null){
                    ChinaDataAntiMoneyLaunderResp resp= (ChinaDataAntiMoneyLaunderResp) resultData.getResult();
                    String resultStr=JSON.toJSONString(resp);
                    if(resultStr.length()>=20000){
                        resp.setLinks(null);
                    }
                    resultStr=JSON.toJSONString(resp);
                    if(resultStr.length()>=20000){
                        resultStr=resultStr.substring(0,20000);
                    }
                    entity.setResult(resultStr);
                    if(ResponseCodeEnum.SUCCESS.toName().equals(responseData.getCode()))
                        entity.setResultStatus("success");
                    else{
                        entity.setResultStatus("fail");
                    }
                }else {
                    entity.setResultStatus("fail");
                }
                creditAntiMoneyLaunderDataDao.updateAntiMoneyLaunderData(entity);
            }catch (Exception e){
                logger.info("企业反洗钱增量信息更新任务执行异常，更新的企业："+entity.geteBlicCName()+"，原因："+e.getMessage());
            }
        }
        logger.info("企业反洗钱增量信息更新任务执行完毕。。。");
    }


    public AntiMoneyLQueryParam formParam(Map<String,String> parameters) throws Exception{
        SimpleDateFormat format=new SimpleDateFormat("YYYY-MM-dd");
        AntiMoneyLQueryParam param=new AntiMoneyLQueryParam();
        String startTime=parameters.get("startTime");
        String endTime=parameters.get("endTime");
        if(!StringUtils.isBlank(startTime)&&StringUtils.isBlank(endTime)){
            startTime=startTime.trim();
            if((!isDateTime(startTime))&&(!isDate(startTime)))
                throw new Exception("开始时间格式不正确");
            param.setStartTime(startTime);
            if(startTime.indexOf(" ")<=0){
                param.setEndTime(startTime+" 24:00:00");
            }else {
                param.setEndTime(startTime.substring(0,startTime.indexOf(" "))+" 24:00:00");
            }
        }else if(!StringUtils.isBlank(startTime)&&!StringUtils.isBlank(endTime)){
            startTime=startTime.trim();
            endTime=endTime.trim();
            if(!isDate(startTime)&&!isDateTime(startTime)){
                throw new Exception("开始时间格式不正确");
            }
            if(!isDate(endTime)&&!isDateTime(endTime)){
                throw new Exception("截止时间格式不正确");
            }
            param.setStartTime(startTime);
            if(endTime.indexOf(" ")<=0){
                param.setEndTime(endTime+" 24:00:00");
            }else{
                param.setEndTime(endTime);
            }
        }else if(StringUtils.isBlank(startTime)&&StringUtils.isBlank(endTime)){
            Date date=new Date();
            date.setDate(date.getDate()-1);
            startTime=format.format(date);
            endTime=startTime+" 24:00:00";
            param.setStartTime(startTime);
            param.setEndTime(endTime);
        }else{
            Date date=new Date();
            date.setDate(date.getDate()-1);
            startTime=format.format(date);
            endTime=endTime.trim();
            if(!isDate(endTime)&&!isDateTime(endTime)){
                throw new Exception("截止时间格式不正确");
            }
            if(endTime.indexOf(" ")<=0){
                endTime=endTime+" 24:00:00";
            }
            param.setEndTime(endTime);
            param.setStartTime(startTime);
        }
        return param;
    }


    public boolean isDateTime(String str) {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try{
            Date date =formatter.parse(str);
            formatter.format(date);
            return str.equals(formatter.format(date));
        }catch(Exception e){
            return false;
        }
    }

    public boolean isDate(String str) {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        try{
            Date date =formatter.parse(str);
            formatter.format(date);
            return str.equals(formatter.format(date));
        }catch(Exception e){
            return false;
        }
    }
}
