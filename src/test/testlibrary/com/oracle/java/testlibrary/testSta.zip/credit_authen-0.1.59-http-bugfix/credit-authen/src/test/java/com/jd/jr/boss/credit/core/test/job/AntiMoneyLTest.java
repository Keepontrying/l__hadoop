package com.jd.jr.boss.credit.core.test.job;

import com.jd.jr.boss.credit.authen.core.scheduler.AntiMoneyUpdateJob;
import com.jd.jr.boss.credit.authen.core.scheduler.DailyBillJop;
import com.wangyin.schedule.client.ScheduleClient;
import com.wangyin.schedule.client.job.ScheduleContext;
import com.wangyin.schedule.httpclient.response.SimpleHttpResponse;
import com.wangyin.schedule.sdk.response.TaskGetResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.HashMap;
import java.util.Map;

/**
 * created by ChenKaiJu on 2018/7/30  9:51
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/spring-authen.xml" })
public class AntiMoneyLTest {

    @Autowired
    AntiMoneyUpdateJob antiMoneyUpdateJob;

    @Test
    public void testJob() throws Exception {
        antiMoneyUpdateJob.doJob(null);
    }



}
