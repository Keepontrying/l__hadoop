package com.jd.jr.boss.credit.authen.core.facade.wx;

import com.google.common.base.Preconditions;
import com.jd.jr.boss.credit.authen.core.service.WxOrderService;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.entity.merchant.MerchantUsers;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.request.merchant.GatewayPortalUserRequest;
import com.jd.jr.boss.credit.credit.gateway.merchantca.facade.merchant.GatewayMerchantFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditWxOrderFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.WxOrderParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.WxOrderResp;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.external.beans.request.WxOrderReq;
import com.wangyin.boss.credit.admin.entity.CreditWanxiangOrder;
import com.wangyin.boss.credit.admin.enums.CreditWxOrderStatusEnum;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 万象
 */
@Service("creditWxOrderFacade")
public class CreditWxOrderFacadeImpl implements CreditWxOrderFacade {

    private Logger logger= LoggerFactory.getLogger(CreditWxOrderFacadeImpl.class);

    @Autowired
    private WxOrderService wxOrderService;

    @Autowired
    private GatewayMerchantFacade gatewayMerchantFacade;

    @Override
    public CreditResponseData<WxOrderResp> checkAndCreateWxOrder(CreditRequestParam<WxOrderParam> requestParam) {

        CreditResponseData<WxOrderResp> creditResponseData = new CreditResponseData<WxOrderResp>();
        creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
        creditResponseData.setCode(ResponseMessage.SUCCESS.name());
        creditResponseData.setSuccess(true);
        WxOrderResp wxOrderResp = new WxOrderResp();
        wxOrderResp.setSuccess(true);
        wxOrderResp.setMsg("订单处理完成");
        creditResponseData.setData(wxOrderResp);


        Preconditions.checkNotNull(requestParam,"requestParam is null");
        WxOrderParam wxOrderParam = requestParam.getParam();
        Preconditions.checkNotNull(wxOrderParam, "wxOrderParam is null");
        Preconditions.checkNotNull(wxOrderParam.getMerchantNo(), "merchantNo is null");
        Preconditions.checkArgument(StringUtils.isNotBlank(wxOrderParam.getMerchantNo()), "merchantNo is blank");

        RequestParam<GatewayPortalUserRequest> gatewayPortalUserRequest = new RequestParam<GatewayPortalUserRequest>();
        GatewayPortalUserRequest userRequest = new GatewayPortalUserRequest();
        userRequest.setMerchantNo(wxOrderParam.getMerchantNo());
        gatewayPortalUserRequest.setParam(userRequest);
        Page<MerchantUsers> merchantUsers = null;
        String operator = "wxAdmin";

        try {
            logger.info("gatewayMerchantFacade.queryUsersInfoByPrm, gatewayPortalUserRequest:{}", GsonUtil.getInstance().toJson(gatewayPortalUserRequest));
            merchantUsers = gatewayMerchantFacade.queryUsersInfoByPrm(gatewayPortalUserRequest);
            logger.info("gatewayMerchantFacade.queryUsersInfoByPrm, merchantUsers:{}", GsonUtil.getInstance().toJson(merchantUsers));
            if (merchantUsers.isSuccess()){

                if (merchantUsers.getRows() != null && merchantUsers.getRows().size() > 0){
                    for (MerchantUsers merchantUser : merchantUsers.getRows()){
                        if (StringUtils.isNotBlank(merchantUser.getJdpin())){
                            String jdpin = merchantUser.getJdpin();
                            CreditWanxiangOrder record = new CreditWanxiangOrder();
                            record.setJdpin(jdpin);
                            record.setStatus(CreditWxOrderStatusEnum.NON_RECHARGE.getCode());
                            logger.info("wxOrderService.selectCreditWanxiangOrderByParam, query:{}", GsonUtil.getInstance().toJson(record));
                            List<CreditWanxiangOrder> creditWanxiangOrderList = wxOrderService.selectCreditWanxiangOrderByParam(record);
                            logger.info("wxOrderService.selectCreditWanxiangOrderByParam, creditWanxiangOrder:{}", GsonUtil.getInstance().toJson(creditWanxiangOrderList));
                            if (creditWanxiangOrderList == null || creditWanxiangOrderList.size() == 0){
                                logger.info("checkAndCreateWxOrder no NON_RECHARGE wx order");
                                wxOrderResp.setMsg("无万象订单");
                                continue;

                            }else {

                                for (CreditWanxiangOrder creditWanxiangOrder : creditWanxiangOrderList){

                                    if (StringUtils.isBlank(jdpin) || !creditWanxiangOrder.getJdpin().equals(jdpin)){
                                        logger.error("jdpin may not match creditWanxiangOrder,jdpin:{},creditWanxiangOrder:{}",jdpin,GsonUtil.getInstance().toJson(creditWanxiangOrder));
                                        continue;
                                    }
                                    wxOrderResp.setMsg("订单处理完成");
                                    WxOrderReq wxOrderReq = new WxOrderReq();
                                    BeanUtils.copyProperties(creditWanxiangOrder, wxOrderReq);

                                    //创建万象订单
                                    try {
                                        wxOrderService.createWxOrder(wxOrderParam.getMerchantNo(),operator ,wxOrderReq, creditWanxiangOrder.getId());
                                    } catch (Exception e) {
                                        logger.error("wxOrderService.createWxOrder, error", e);

                                        if (creditWanxiangOrder.getId() > 0){
                                            wxOrderService.updateErrorMsg(creditWanxiangOrder.getId(), e.getMessage(), operator);
                                        }
                                        creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
                                        creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
                                        creditResponseData.setSuccess(false);
                                        wxOrderResp.setSuccess(false);
                                        wxOrderResp.setMsg("创建万象订单有异常");
                                        return creditResponseData;
                                    }

                                }
                            }
                        }
                    }
                }
            }
        }  catch (Exception e) {
            logger.error("creditWxOrderFacade.checkAndCreateWxOrder, error", e);

            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
            wxOrderResp.setSuccess(false);
            wxOrderResp.setMsg("check万象订单有异常");
            return creditResponseData;
        }
        return creditResponseData;
    }
}
