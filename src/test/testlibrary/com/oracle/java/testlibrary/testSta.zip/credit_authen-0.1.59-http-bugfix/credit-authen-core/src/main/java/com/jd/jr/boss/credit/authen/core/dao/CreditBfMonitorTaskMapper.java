package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.entity.CreditBfMonitorTask;
import com.jd.jr.boss.credit.authen.core.beans.entity.CreditBfMonitorTaskExample;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CreditBfMonitorTaskMapper {
    long countByExample(CreditBfMonitorTaskExample example);

    int deleteByExample(CreditBfMonitorTaskExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CreditBfMonitorTask record);

    int insertSelective(CreditBfMonitorTask record);

    List<CreditBfMonitorTask> selectByExample(CreditBfMonitorTaskExample example);

    CreditBfMonitorTask selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CreditBfMonitorTask record, @Param("example") CreditBfMonitorTaskExample example);

    int updateByExample(@Param("record") CreditBfMonitorTask record, @Param("example") CreditBfMonitorTaskExample example);

    int updateByPrimaryKeySelective(CreditBfMonitorTask record);

    int updateByPrimaryKey(CreditBfMonitorTask record);
}