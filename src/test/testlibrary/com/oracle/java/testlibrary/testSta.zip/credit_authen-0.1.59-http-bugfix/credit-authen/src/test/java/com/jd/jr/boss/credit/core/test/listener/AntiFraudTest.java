package com.jd.jr.boss.credit.core.test.listener;

import com.jd.jmq.common.message.Message;
import com.jd.jr.boss.credit.authen.core.jms.AntiFraud.CreditAntiFraudListener;
import com.jd.jr.boss.credit.authen.core.jms.weixin.CreditWeixinListener;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @desciption : 黄赌毒测试类
 * @author : liuwei@jd.com
 * @date ：2017年7月20日 下午5:56:59
 * @version 1.0
 * @return  */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/spring-authen.xml" })

public class AntiFraudTest {

	@Resource
	private CreditAntiFraudListener creditAntiFraudListener;

	@Test
	public void testMessage() throws Exception {

		List<Message> messages = new ArrayList<Message>();
		Message message = new Message();
		message.setText("{\"result\":{\"systemId\":\"a3884c68df2711e7a293ecf4bbcdd49c\",\"keyWords\":\"真人娱乐\",\"isHit \":\"0\",\"merchantNum\":\"aaaa\",\"webSiteUrl \":\"www.5500aaa.com\",\"merchantName\":\"aaaa\"},\"code\":\"0\",\"message\":\"\"}");
		messages.add(message);
		creditAntiFraudListener.onMessage(messages);

	}


}
