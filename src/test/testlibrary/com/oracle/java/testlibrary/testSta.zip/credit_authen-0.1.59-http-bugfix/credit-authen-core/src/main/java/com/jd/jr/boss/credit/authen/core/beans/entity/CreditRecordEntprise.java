package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * created by ChenKaiJu on 2018/9/20  9:43
 */
public class CreditRecordEntprise implements Serializable {

    private static final long serialVersionUID = -42354596524329708L;
    private Integer entpriseId;

    private Date modifiedDate;

    private String synched;

    private Date syncDate;

    private Date createdDate;

    private String entName;

    private String creditCode;

    private String regNo;

    private String createSystemId;

    private String modifier;

    private String entMonitored;

    private Date entBeginDate;

    private Date entEndDate;

    private String extraMsg;

    public Integer getEntpriseId() {
        return entpriseId;
    }

    public void setEntpriseId(Integer entpriseId) {
        this.entpriseId = entpriseId;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getSynched() {
        return synched;
    }

    public void setSynched(String synched) {
        this.synched = synched;
    }

    public Date getSyncDate() {
        return syncDate;
    }

    public void setSyncDate(Date syncDate) {
        this.syncDate = syncDate;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getEntName() {
        return entName;
    }

    public void setEntName(String entName) {
        this.entName = entName;
    }

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getCreateSystemId() {
        return createSystemId;
    }

    public void setCreateSystemId(String createSystemId) {
        this.createSystemId = createSystemId;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getEntMonitored() {
        return entMonitored;
    }

    public void setEntMonitored(String entMonitored) {
        this.entMonitored = entMonitored;
    }

    public Date getEntBeginDate() {
        return entBeginDate;
    }

    public void setEntBeginDate(Date entBeginDate) {
        this.entBeginDate = entBeginDate;
    }

    public Date getEntEndDate() {
        return entEndDate;
    }

    public void setEntEndDate(Date entEndDate) {
        this.entEndDate = entEndDate;
    }

    public String getExtraMsg() {
        return extraMsg;
    }

    public void setExtraMsg(String extraMsg) {
        this.extraMsg = extraMsg;
    }
}
