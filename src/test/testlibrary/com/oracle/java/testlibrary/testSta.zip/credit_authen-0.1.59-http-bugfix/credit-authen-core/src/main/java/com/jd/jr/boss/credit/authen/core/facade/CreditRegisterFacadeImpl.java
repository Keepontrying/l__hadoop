package com.jd.jr.boss.credit.authen.core.facade;

import com.google.common.base.Stopwatch;
import com.google.gson.reflect.TypeToken;
import com.jd.jdjr.commons.api.domain.SystemInfo;
import com.jd.jr.boss.credit.authen.core.beans.request.MerchantQueryParam;
import com.jd.jr.boss.credit.authen.core.service.MerchantService;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.request.merchant.GatewayPortalUserRequest;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.response.merchant.GatewayMerchantQueryResponse;
import com.jd.jr.boss.credit.credit.gateway.merchantca.enums.MercCaRasAuditEnum;
import com.jd.jr.boss.credit.credit.gateway.merchantca.facade.GatewayPortalFacade;
import com.jd.jr.boss.credit.domain.common.enums.OpenOrCloseStatusEnum;
import com.jd.jr.boss.credit.facade.authen.api.CreditRegisterFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditUserFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.*;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.gateway.unc.constance.GatewayUncConstance;
import com.jd.jr.boss.credit.gateway.unc.facade.email.GatewayUncEmailFacade;
import com.jd.jr.boss.credit.gateway.unc.utils.FlowNoUtils;
import com.jd.jr.esu.cuservice.api.domain.common.CompanyUserRequest;
import com.jd.jr.esu.cuservice.api.domain.common.CompanyUserResult;
import com.jd.jr.esu.cuservice.api.domain.vo.CompanyUserQueryVo;
import com.jd.jr.esu.cuservice.api.domain.vo.CompanyUserVo;
import com.jd.jr.esu.cuservice.api.service.companyinfo.CompanyUserInfoQueryService;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.boss.credit.admin.enums.*;
import com.wangyin.boss.merchantoperation.label.api.dto.LabelAllocateDTO;
import com.wangyin.boss.merchantoperation.label.api.facade.LabelAllocateFacade;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.Response;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @author jiangbo
 * @since 2017/3/30
 */
@Service("creditRegisterFacade")
public class CreditRegisterFacadeImpl implements CreditRegisterFacade {

    private static Logger logger = LoggerFactory.getLogger(CreditRegisterFacadeImpl.class);

    @Autowired
    GatewayPortalFacade gatewayPortalFacade;

    @Autowired
    CreditUserFacade creditUserFacade;

    @Autowired
    MerchantService merchantService;

    @Autowired
    GatewayUncEmailFacade uncEmailFacade;

    @Autowired
    protected LabelAllocateFacade labelAllocateFacade;

    @Autowired
    CompanyUserInfoQueryService companyUserInfoQueryService;

    public String sysIdCompanyUser = ConfigUtil.getString("cuservice.companyUserInfoQueryService.querySingleCompanyUser.sysId");
    public String  tokenCompanyUser = ConfigUtil.getString("cuservice.companyUserInfoQueryService.querySingleCompanyUser.token");

    public String labelallocate = ConfigUtil.getString("labelallocate.mark.systemid");
    public String  labelOptionCode = ConfigUtil.getString("labelallocate.mark.labelOptionCode");

    @Override
    public CreditResponseData<Boolean> registerSuperUser(CreditRequestParam<FacadePortalSuperUserRequest> creditRequestParam) throws Exception {
        long time = System.currentTimeMillis();
        CreditResponseData<Boolean> creditResponseData = new CreditResponseData<Boolean>();
        FacadePortalSuperUserRequest paramFacadePortalSuperUserRequest = creditRequestParam.getParam();

        GatewayPortalUserRequest param = new GatewayPortalUserRequest();
        BeanUtils.copyProperties(paramFacadePortalSuperUserRequest, param);

        if (StringUtils.isBlank(paramFacadePortalSuperUserRequest.getOperatorId()) || StringUtils.isBlank(paramFacadePortalSuperUserRequest.getCompanyUserId()) || StringUtils.isBlank(paramFacadePortalSuperUserRequest.getLoginInfoId())){
            logger.error("registerSuperUser, userName is null");
            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(null);
        }

        CreditRequestParam<UserQueryParam> requestUserQueryParam = new CreditRequestParam<UserQueryParam>();
        UserQueryParam userQueryParam = new UserQueryParam();
//        userQueryParam.setEmail(param.getUserName());
//        userQueryParam.setLoginName(param.getUserName());

        userQueryParam.setCompanyUserId(paramFacadePortalSuperUserRequest.getCompanyUserId());
        userQueryParam.setLoginInfoId(paramFacadePortalSuperUserRequest.getLoginInfoId());
        userQueryParam.setOperatorId(paramFacadePortalSuperUserRequest.getOperatorId());


        requestUserQueryParam.setParam(userQueryParam);

        CreditResponseData<CreditUser>  creditResponseUserData = creditUserFacade.selectSingleCreditSuperUserByParam(requestUserQueryParam);
        if (creditResponseUserData.isSuccess() && creditResponseUserData.getData() != null) {
            //如果数据库里已经存在


            logger.info("loginName:{}, existed", param.getUserName());
            creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
            creditResponseData.setCode(ResponseMessage.SUCCESS.name());
            creditResponseData.setSuccess(true);
            creditResponseData.setData(true);

            return creditResponseData;
        }else if (!creditResponseUserData.getCode().equals(ResponseMessage.NOT_EXIST.name())){
            logger.error("registerSuperUser creditUserFacade.selectSingleCreditSuperUserByParam error,creditResponseUserData:{}", GsonUtil.getInstance().toJson(creditResponseUserData));
            creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
            creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(null);
            return creditResponseData;
        }

//        if (StringUtils.isBlank(param.getPassWord())){
//            logger.error("registerUser, passWord is null");
//            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
//            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
//            creditResponseData.setSuccess(false);
//            creditResponseData.setData(null);
//        }

//        if (StringUtils.isBlank(param.getPassWordType())){
//            logger.error("registerUser, passWordType is null");
//            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
//            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
//            creditResponseData.setSuccess(false);
//            creditResponseData.setData(null);
//        }

        //手机号不是必须得

//        if (StringUtils.isBlank(param.getPhone())){
//            logger.error("registerUser, phone is null");
//            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
//            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
//            creditResponseData.setSuccess(false);
//            creditResponseData.setData(null);
//        }

        RequestParam<GatewayPortalUserRequest> registerRequestParam  = new RequestParam<GatewayPortalUserRequest>();
        registerRequestParam.setParam(param);

//        registerRequestParam.setSystemId();

        //获取商户号
        CompanyUserRequest companyUserRequest = new CompanyUserRequest();
        String merchantNo = null;
        CompanyUserVo companyUserVo = null;
        try {
            SystemInfo systemInfo = new SystemInfo();
            systemInfo.setSysId(sysIdCompanyUser);
            systemInfo.setToken(tokenCompanyUser);
            companyUserRequest.setSystemInfo(systemInfo);

            CompanyUserQueryVo companyUserQueryVo = new CompanyUserQueryVo();
            companyUserQueryVo.setOnlyType("companyUserId");
            companyUserQueryVo.setOnlyValue(paramFacadePortalSuperUserRequest.getCompanyUserId());
            companyUserRequest.setParam(companyUserQueryVo);

            CompanyUserResult<CompanyUserVo> result = companyUserInfoQueryService.querySingleCompanyUser(companyUserRequest);

            if (result != null && result.getCode() != null && result.getCode().equals("00000") && result.getData() != null && StringUtils.isNotBlank(result.getData().getOwner())) {
                companyUserVo = result.getData();
                merchantNo = companyUserVo.getOwner();
            } else {
                //获取失败
                logger.error("registerSuperUser companyUserInfoQueryService querySingleCompanyUser error,companyUserRequest:{}", GsonUtil.getInstance().toJson(companyUserRequest));
                creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
                creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
                creditResponseData.setSuccess(false);
                creditResponseData.setData(null);
                return creditResponseData;
            }
        } catch (Exception e) {
            logger.error("registerSuperUser companyUserInfoQueryService querySingleCompanyUser error Exception,companyUserRequest:{}", GsonUtil.getInstance().toJson(companyUserRequest), e);
            creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
            creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(null);
            return creditResponseData;
        }

        //先打标，后注册入库
        RequestParam<LabelAllocateDTO> markRequest = null;
        try {
            markRequest = new RequestParam<LabelAllocateDTO>();
            markRequest.setSystemId(labelallocate);

            LabelAllocateDTO labelAllocateDTO = new LabelAllocateDTO();
            labelAllocateDTO.setMerchantNo(merchantNo);

            Set<String> labelOptionCodes = new HashSet<String>();
            labelOptionCodes.add(labelOptionCode);

            labelAllocateDTO.setLabelOptionCodes(labelOptionCodes);
            labelAllocateDTO.setMerchantLevel("1");

            markRequest.setParam(labelAllocateDTO);

            Response respLabelAllocate = labelAllocateFacade.mark(markRequest);
            if (!(respLabelAllocate != null && respLabelAllocate.isSuccess())) {
                logger.error("labelAllocateFacade mark error,markRequest:{}", GsonUtil.getInstance().toJson(markRequest));
                creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
                creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
                creditResponseData.setSuccess(false);
                creditResponseData.setData(null);
                return creditResponseData;
            }
        } catch (Exception e) {
            logger.error("labelAllocateFacade error Exception,markRequest:{}", GsonUtil.getInstance().toJson(markRequest), e);
            creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
            creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(null);
            return creditResponseData;
        }


        try {
            if (this.initSuperUserAndMerchant(paramFacadePortalSuperUserRequest.getLoginInfoId(), paramFacadePortalSuperUserRequest.getUserName(),
                    paramFacadePortalSuperUserRequest.getCompanyUserId(), paramFacadePortalSuperUserRequest.getOperatorId(),creditRequestParam.getOperator(),merchantNo,paramFacadePortalSuperUserRequest.getJrid())) {
                logger.info("initSuperUserAndMerchant success");
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(true);

                return creditResponseData;
            }
        } catch (Exception e) {
            logger.error("registerSuperUser error,param:{}", GsonUtil.getInstance().toJson(param), e);
        }

        creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
        creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
        creditResponseData.setSuccess(false);
        creditResponseData.setData(null);

        return creditResponseData;
    }

    @Override
    @Deprecated
    public CreditResponseData<Boolean> registerUser(CreditRequestParam<FacadePortalUserRequest> creditRequestParam) throws Exception {
        long time = System.currentTimeMillis();
        CreditResponseData<Boolean> creditResponseData = new CreditResponseData<Boolean>();
//        FacadePortalUserRequest paramFacadePortalUserRequest = creditRequestParam.getParam();
//
//        GatewayPortalUserRequest param = new GatewayPortalUserRequest();
//        BeanUtils.copyProperties(paramFacadePortalUserRequest, param);

//        if (StringUtils.isBlank(param.getUserName())){
//            logger.error("registerUser, userName is null");
            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(null);
            return creditResponseData;
//        }

//        CreditRequestParam<UserQueryParam> requestUserQueryParam = new CreditRequestParam<UserQueryParam>();
//        UserQueryParam userQueryParam = new UserQueryParam();
////        userQueryParam.setEmail(param.getUserName());
//        userQueryParam.setLoginName(param.getUserName());
//        requestUserQueryParam.setParam(userQueryParam);
//
//        CreditResponseData<CreditUser>  creditResponseUserData = creditUserFacade.selectSingleCreditUserByParam(requestUserQueryParam);
//        if (creditResponseUserData.isSuccess() && creditResponseUserData.getData() != null) {
//            //如果数据库里已经存在
//
//
//            logger.info("loginName:{}, existed", param.getUserName());
//            creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
//            creditResponseData.setCode(ResponseMessage.SUCCESS.name());
//            creditResponseData.setSuccess(true);
//            creditResponseData.setData(true);
//
//            return creditResponseData;
//        }
//
////        if (StringUtils.isBlank(param.getPassWord())){
////            logger.error("registerUser, passWord is null");
////            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
////            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
////            creditResponseData.setSuccess(false);
////            creditResponseData.setData(null);
////        }
//
////        if (StringUtils.isBlank(param.getPassWordType())){
////            logger.error("registerUser, passWordType is null");
////            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
////            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
////            creditResponseData.setSuccess(false);
////            creditResponseData.setData(null);
////        }
//
//        //手机号不是必须得
//
////        if (StringUtils.isBlank(param.getPhone())){
////            logger.error("registerUser, phone is null");
////            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
////            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
////            creditResponseData.setSuccess(false);
////            creditResponseData.setData(null);
////        }
//
//        RequestParam<GatewayPortalUserRequest> registerRequestParam  = new RequestParam<GatewayPortalUserRequest>();
//        registerRequestParam.setParam(param);
//
////        registerRequestParam.setSystemId();
//
//        try {
//            if (this.initUserAndMerchant(param.getMerchantNo(), creditRequestParam.getOperator(), param.getUserName(), param.getPhone())) {
//                logger.info("initUserAndMerchant success");
//                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
//                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
//                creditResponseData.setSuccess(true);
//                creditResponseData.setData(true);
//
//                return creditResponseData;
//            }
//        } catch (Exception e) {
//            logger.error("registerUser error,param:{}", ReflectionToStringBuilder.toString(param), e);
//        }
//
//        creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
//        creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
//        creditResponseData.setSuccess(false);
//        creditResponseData.setData(null);
//
//        return creditResponseData;
    }

    @Override
    public CreditResponseData<Boolean> checkEmailExsit(CreditRequestParam<FacadePortalUserRequest> creditRequestParam) throws Exception {
        RequestParam<GatewayPortalUserRequest> checkEmailExsitRequestParam = new RequestParam<GatewayPortalUserRequest>();
        CreditResponseData<Boolean> creditResponseData = new CreditResponseData<Boolean>();
        FacadePortalUserRequest paramFacadePortalUserRequest = creditRequestParam.getParam();

        GatewayPortalUserRequest param = new GatewayPortalUserRequest();
        BeanUtils.copyProperties(paramFacadePortalUserRequest, param);

        if (StringUtils.isBlank(param.getUserName())){
            logger.error("checkEmailExsit, userName is null");
            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(null);
            return creditResponseData;
        }


        checkEmailExsitRequestParam.setParam(param);
//        registerRequestParam.setSystemId();

        try {
            ResponseData<String> responseData = gatewayPortalFacade.checkEmailExsit(checkEmailExsitRequestParam);
            logger.info("checkEmailExsit response, responseData：{}", ReflectionToStringBuilder.toString(responseData));
            if (responseData.isSuccess()){
                HashMap<String,Object> resData = GsonUtil.getInstance().fromJson(responseData.getData(), new TypeToken<HashMap<String,Object>>() {}.getType());
                Boolean isExistUser = (Boolean)resData.get("isExistUser");
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(isExistUser);
                return creditResponseData;
            }

        }catch (Exception e){
            logger.error("checkEmailExsit error, creditRequestParam", ReflectionToStringBuilder.toString(creditRequestParam), e);
        }


        creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
        creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
        creditResponseData.setSuccess(false);
        creditResponseData.setData(null);
        return creditResponseData;
    }

//    @Override
//    public CreditResponseData<CreditUser> login(CreditRequestParam<FacadePortalUserRequest> creditRequestParam) throws Exception {
//        RequestParam<GatewayPortalUserRequest> loginRequestParam = new RequestParam<GatewayPortalUserRequest>();
//        FacadePortalUserRequest paramFacadePortalUserRequest = creditRequestParam.getParam();
//
//        GatewayPortalUserRequest param = new GatewayPortalUserRequest();
//        BeanUtils.copyProperties(paramFacadePortalUserRequest, param);
//        CreditResponseData<CreditUser> creditResponseData = new CreditResponseData<CreditUser>();
//        if (StringUtils.isBlank(param.getUserName()) || StringUtils.isBlank(param.getPassWord())){
//            logger.error("login, userName is null or password is null");
//            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
//            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
//            creditResponseData.setSuccess(false);
//            creditResponseData.setData(null);
//            return creditResponseData;
//        }
//
//        loginRequestParam.setParam(param);
////        registerRequestParam.setSystemId();
//        CreditUser creditUser = new CreditUser();
//        try{
//            ResponseData<String> responseData = gatewayPortalFacade.login(loginRequestParam);
//            logger.info("login response, responseData：{}", ReflectionToStringBuilder.toString(responseData));
//            if (responseData.isSuccess()){
//                HashMap<String,HashMap> resData = GsonUtil.getInstance().fromJson(responseData.getData(), new TypeToken<HashMap<String,HashMap>>() {}.getType());
//                HashMap result = (HashMap)resData.get("result");
//                if ((Boolean) result.get("result")==true){          //登录成功
//                    HashMap user = (HashMap)resData.get("user");
//
//                    CreditRequestParam<UserQueryParam> requestUserQueryParam = new CreditRequestParam<UserQueryParam>();
//                    UserQueryParam userQueryParam = new UserQueryParam();
//                    userQueryParam.setEmail(param.getUserName());
//                    requestUserQueryParam.setParam(userQueryParam);
//
//                    CreditResponseData<CreditUser>  creditResponseUserData = creditUserFacade.selectSingleCreditUserByParam(requestUserQueryParam);
//                    if (creditResponseUserData.isSuccess() && creditResponseUserData.getData() != null){
//                        //如果数据库里已经存在
//                        creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
//                        creditResponseData.setCode(ResponseMessage.SUCCESS.name());
//                        creditResponseData.setSuccess(true);
//                        creditResponseData.setData(creditResponseUserData.getData());
//                    }else {
//                        //如果数据库里不存在，则初始化数据库
//                        if(this.initUserAndMerchant((String) user.get("owner"), creditRequestParam.getOperator(), param.getUserName(),(String) user.get("phone")) ){
//                            logger.info("initUserAndMerchant success");
//                            CreditRequestParam<UserQueryParam> requestUserQueryParamNew = new CreditRequestParam<UserQueryParam>();
//                            UserQueryParam userQueryParamNew = new UserQueryParam();
//                            userQueryParamNew.setEmail(param.getUserName());
//                            requestUserQueryParamNew.setParam(userQueryParamNew);
//
//                            CreditResponseData<CreditUser>  creditResponseUserDataNew = creditUserFacade.selectSingleCreditUserByParam(requestUserQueryParamNew);
//                            creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
//                            creditResponseData.setCode(ResponseMessage.SUCCESS.name());
//                            creditResponseData.setSuccess(true);
//                            creditResponseData.setData(creditResponseUserDataNew.getData());
//
//                        }else {
//                            throw new SQLException("initUserAndMerchant error");
//                        }
//
//                    }
//                    return creditResponseData;
//                } else {
//                    //登录失败
//                    logger.info("login failed,creditRequestParam:{}", ReflectionToStringBuilder.toString(creditRequestParam));
//                    creditResponseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
//                    creditResponseData.setCode(ResponseMessage.NOT_EXIST.name());
//                    creditResponseData.setSuccess(false);
//                    creditResponseData.setData(null);
//                    return creditResponseData;
//                }
//
//            } else {
//                //登录失败
//                logger.info("login failed,creditRequestParam:{}", ReflectionToStringBuilder.toString(creditRequestParam));
//                creditResponseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
//                creditResponseData.setCode(ResponseMessage.NOT_EXIST.name());
//                creditResponseData.setSuccess(false);
//                creditResponseData.setData(null);
//                return creditResponseData;
//            }
//        }catch (Exception e){
//            logger.error("login error, creditRequestParam", ReflectionToStringBuilder.toString(creditRequestParam), e);
//            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
//            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
//            creditResponseData.setSuccess(false);
//            creditResponseData.setData(null);
//            return creditResponseData;
//        }

//    }

    @Override
    public CreditResponseData<Boolean> resetPwdByEmail(CreditRequestParam<FacadePortalUserRequest> creditRequestParam) throws Exception {
//        RequestParam<GatewayPortalUserRequest> requestParam = new RequestParam<GatewayPortalUserRequest>();
//        FacadePortalUserRequest paramFacadePortalUserRequest = creditRequestParam.getParam();
//
//        GatewayPortalUserRequest param = new GatewayPortalUserRequest();
//        BeanUtils.copyProperties(paramFacadePortalUserRequest, param);
//        requestParam.setParam(param);
//
//        CreditResponseData<Boolean> creditResponseData = new CreditResponseData<Boolean>();
//
//        try{
//            //查询商户号
//            MerchantQueryParam merchantQryParam = new MerchantQueryParam();
//            if (StringUtils.isBlank(param.getUserName())){
//                logger.error("resetPwdByEmail, UserName is null");
//                creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
//                creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
//                creditResponseData.setSuccess(false);
//                creditResponseData.setData(null);
//                return creditResponseData;
//            }
//
//            if (StringUtils.isBlank(param.getRedirectUrl())){
//                logger.error("resetPwdByEmail, RedirectUrl is null");
//                creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
//                creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
//                creditResponseData.setSuccess(false);
//                creditResponseData.setData(null);
//                return creditResponseData;
//            }
//
//            CreditRequestParam<UserQueryParam> userQueryParamRequestParam = new CreditRequestParam<UserQueryParam>();
//            UserQueryParam userQueryParam = new UserQueryParam();
////            userQueryParam.setEmail();
//            userQueryParam.setLoginName(param.getUserName());
//            userQueryParamRequestParam.setParam(userQueryParam);
//
//            CreditResponseData<CreditUser> creditUser = creditUserFacade.selectSingleCreditUserByParam(userQueryParamRequestParam);
//
//            if (creditUser == null || !creditUser.isSuccess() || creditUser.getData() == null){
//                logger.error("resetPwdByEmail, username:{} is not exited", param.getUserName());
//                creditResponseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
//                creditResponseData.setCode(ResponseMessage.NOT_EXIST.name());
//                creditResponseData.setSuccess(false);
//                creditResponseData.setData(null);
//                return creditResponseData;
//            }
//
//            merchantQryParam.setMerchantId(creditUser.getData().getMerchantId());
//
//            List<CreditMerchant> creditMerchantList = merchantService.queryMerchantByParam(merchantQryParam);
//            if (creditMerchantList != null && creditMerchantList.size() == 1){
//                param.setMerchantNo(creditMerchantList.get(0).getMerchantNo());
//            }else {
//                logger.error("resetPwdByEmail, UserName is not credit userName");
//                creditResponseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
//                creditResponseData.setCode(ResponseMessage.NOT_EXIST.name());
//                creditResponseData.setSuccess(false);
//                creditResponseData.setData(null);
//                return creditResponseData;
//            }
//
//            ResponseData<String> responseData = gatewayPortalFacade.resetPwdByEmail(requestParam);
//            if (responseData.isSuccess()){
//                logger.info("resetPwdByEmail success, responseData:{}", ReflectionToStringBuilder.toString(responseData));
//                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
//                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
//                creditResponseData.setSuccess(true);
//                creditResponseData.setData(true);
//                return creditResponseData;
//            }else {
//                logger.error("resetPwdByEmail error, responseData:{}", ReflectionToStringBuilder.toString(responseData));
//                creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
//                creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
//                creditResponseData.setSuccess(false);
//                creditResponseData.setData(null);
//                return creditResponseData;
//            }
//
//
//        } catch (Exception e){
//            logger.error("resetPwdByEmail error, creditRequestParam", ReflectionToStringBuilder.toString(creditRequestParam), e);
//            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
//            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
//            creditResponseData.setSuccess(false);
//            creditResponseData.setData(null);
//            return creditResponseData;
//        }
        CreditResponseData<Boolean> creditResponseData = new CreditResponseData<Boolean>();
        logger.error("resetPwdByEmail error, creditRequestParam", ReflectionToStringBuilder.toString(creditRequestParam));
        creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
        creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
        creditResponseData.setSuccess(false);
        creditResponseData.setData(null);
        return creditResponseData;
    }

    @Override
    public CreditResponseData<Boolean> resetPwdOperate(CreditRequestParam<FacadePortalUserRequest> creditRequestParam) throws Exception {

//        FacadePortalUserRequest paramFacadePortalUserRequest = creditRequestParam.getParam();
//        GatewayPortalUserRequest param = new GatewayPortalUserRequest();
//        BeanUtils.copyProperties(paramFacadePortalUserRequest, param);
//        CreditResponseData<Boolean> creditResponseData = new CreditResponseData<Boolean>();
//
//        RequestParam<GatewayPortalUserRequest> requestParam = new RequestParam<GatewayPortalUserRequest>();
//        requestParam.setParam(param);
//
//        try{
//
//            //查询商户号
//            MerchantQueryParam merchantQryParam = new MerchantQueryParam();
//            if (StringUtils.isBlank(param.getUserName())){
//                logger.error("resetPwdByEmail, UserName is null");
//                creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
//                creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
//                creditResponseData.setSuccess(false);
//                creditResponseData.setData(null);
//                return creditResponseData;
//            }
//
//            CreditRequestParam<UserQueryParam> userQueryParamRequestParam = new CreditRequestParam<UserQueryParam>();
//            UserQueryParam userQueryParam = new UserQueryParam();
//            userQueryParam.setLoginName(param.getUserName());
////            userQueryParam.setEmail();
//            userQueryParamRequestParam.setParam(userQueryParam);
//
//            CreditResponseData<CreditUser> creditUser = creditUserFacade.selectSingleCreditUserByParam(userQueryParamRequestParam);
//
//            if (creditUser == null || !creditUser.isSuccess() || creditUser.getData() == null){
//                logger.error("resetPwdByEmail, username:{} is not exited", param.getUserName());
//                creditResponseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
//                creditResponseData.setCode(ResponseMessage.NOT_EXIST.name());
//                creditResponseData.setSuccess(false);
//                creditResponseData.setData(null);
//                return creditResponseData;
//            }
//
//            merchantQryParam.setMerchantId(creditUser.getData().getMerchantId());
//
//            List<CreditMerchant> creditMerchantList = merchantService.queryMerchantByParam(merchantQryParam);
//            if (creditMerchantList != null && creditMerchantList.size() == 1){
//                param.setMerchantNo(creditMerchantList.get(0).getMerchantNo());
//            }else {
//                logger.error("resetPwdByEmail, UserName is not credit userName");
//                creditResponseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
//                creditResponseData.setCode(ResponseMessage.NOT_EXIST.name());
//                creditResponseData.setSuccess(false);
//                creditResponseData.setData(null);
//                return creditResponseData;
//            }
//
//            ResponseData<String> responseData = gatewayPortalFacade.resetPwdOperate(requestParam);
//            if (responseData.isSuccess() && responseData.getCode().equals("0000")){
//                HashMap resultData = GsonUtil.getInstance().fromJson(responseData.getData(), new TypeToken<HashMap>() {}.getType());
//                if (resultData.get("code") == null || !resultData.get("code").equals("0000")){
//                    logger.error("resetPwdOperate error, responseData:{}", ReflectionToStringBuilder.toString(responseData));
//                    creditResponseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
//                    creditResponseData.setCode(ResponseMessage.NOT_EXIST.name());
//                    creditResponseData.setSuccess(false);
//                    creditResponseData.setData(null);
//                    return creditResponseData;
//                }
//
//                logger.info("resetPwdOperate success, responseData:{}", ReflectionToStringBuilder.toString(responseData));
//                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
//                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
//                creditResponseData.setSuccess(true);
//                creditResponseData.setData(true);
//                return creditResponseData;
//            }else {
//                logger.error("resetPwdOperate error, responseData:{}", ReflectionToStringBuilder.toString(responseData));
//                creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
//                creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
//                creditResponseData.setSuccess(false);
//                creditResponseData.setData(null);
//                return creditResponseData;
//            }
//
//
//        } catch (Exception e){
//            logger.error("resetPwdOperate error, creditRequestParam", ReflectionToStringBuilder.toString(creditRequestParam), e);
//            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
//            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
//            creditResponseData.setSuccess(false);
//            creditResponseData.setData(null);
//            return creditResponseData;
//        }

        CreditResponseData<Boolean> creditResponseData = new CreditResponseData<Boolean>();
        logger.error("resetPwdOperate error, creditRequestParam", ReflectionToStringBuilder.toString(creditRequestParam));
        creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
        creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
        creditResponseData.setSuccess(false);
        creditResponseData.setData(null);
        return creditResponseData;
    }

    @Override
    public CreditResponseData<Integer> sendRegisterEmail(CreditRequestParam<FacadePortalUncRequest> creditRequestParam) throws Exception {

        CreditResponseData<Integer> creditResponseData = new CreditResponseData<Integer>();


        if (creditRequestParam == null || creditRequestParam.getParam() == null || StringUtils.isBlank(creditRequestParam.getParam().getUserName()) || StringUtils.isBlank(creditRequestParam.getParam().getUncType())){
            logger.error("param is null！");
            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(null);
            return creditResponseData;
        }

        FacadePortalUncRequest FacadePortalUncRequest = creditRequestParam.getParam();

        UncTypeEnum uncType = UncTypeEnum.enumValueOf(FacadePortalUncRequest.getUncType());

        if (uncType == null){
            logger.error("uncType is not exist！");
            creditResponseData.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
            creditResponseData.setCode(ResponseMessage.PARAM_IS_REQUIRED.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(null);
            return creditResponseData;
        }

        DateFormat df = new SimpleDateFormat("yyyy年MM月dd日HH时mm分");
        try {

            int ranNum = (int) (Math.random() * 1000000);
            if (ranNum > 100000) {
//                System.out.println(ranNum);
            }else {
                ranNum = ranNum+100000;
            }

            HashMap paramMap = new HashMap();
            String nowTimeStr = df.format(new Date());
            paramMap.put("verifyCode", ranNum);
            String templateCode = uncType.getTemplateCode();
            String subject = uncType.getSubject();
            String appCode = ConfigUtil.getString(GatewayUncConstance.UNC_CLIENT_APPCODE);
            String bizNo = FlowNoUtils.createFlowNo("authen");
            Stopwatch watch = Stopwatch.createStarted();
            Boolean result = false;
            try {
                 result = uncEmailFacade.sendMailByUnc(creditRequestParam.getParam().getUserName(), subject, bizNo, paramMap, templateCode, appCode);
            }finally {
                watch.stop();
                logger.info("sendMailByUnc time,elapsed:{}", watch.elapsed(TimeUnit.MILLISECONDS));
            }


            if (!result) {
                logger.error("sendRegisterEmail error, receiver:{}" , creditRequestParam.getParam().getUserName());
                creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
                creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
                creditResponseData.setSuccess(false);
                creditResponseData.setData(null);
                return creditResponseData;
            }else{
                logger.info("sendRegisterEmail success, receiver:{}, ranNum:{}" , creditRequestParam.getParam().getUserName(), ranNum);
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(ranNum);
                return creditResponseData;
            }
        } catch (Exception e) {
            logger.error("sendRegisterEmail error, creditRequestParam:{}", ReflectionToStringBuilder.toString(creditRequestParam));
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
            creditResponseData.setData(null);
            return creditResponseData;
        }
    }
    /**
     * 初始化用户和商户 超级账户
     * @throws Exception
     */
    private boolean initSuperUserAndMerchant(String loginInfoId,String loginName, String companyUserId, String operatorId, String operator, String merchantNo, String jrId) throws Exception{
        if (StringUtils.isBlank(companyUserId)){
            logger.error("companyUserId is null");
            throw new IllegalArgumentException("companyUserId is null");
        }
        MerchantQueryParam merchantQryParam = new MerchantQueryParam();
        merchantQryParam.setMerchantNo(merchantNo);

        List<CreditMerchant> creditMerchantList = merchantService.queryMerchantByParam(merchantQryParam);

        Integer merchantId;
        //如果已经存在商户，则按情况更新MerchantType
        if (creditMerchantList != null && creditMerchantList.size() == 1 && creditMerchantList.get(0).getMerchantNo().equals(merchantNo)){
            logger.info("CreditMerchant exists,will change merchantType");
            CreditMerchant creditMerchant = new CreditMerchant();
            creditMerchant.setMerchantId(creditMerchantList.get(0).getMerchantId());
            if (creditMerchantList.get(0).getMerchantType().equals(CreditMerchantTypeEnum.PERSON.toName())){
                creditMerchant.setMerchantType(CreditMerchantTypeEnum.ALL.toName());
            }else {
                creditMerchant.setMerchantType(CreditMerchantTypeEnum.ENTERPRISE.toName());
            }

            CreditMerchant cm = new CreditMerchant();
            cm.setMerchantNo(merchantNo);
            GatewayMerchantQueryResponse gmqResp = merchantService.queryMerchantInfoByHttp(cm);
            //判断审核状态
//            if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_SUCCESS.getDescription())){
//                creditMerchant.setAuditStatus(MerchantAuditEnum.WAIT_BUSINESS.getCode());
//            }else if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_REJECTED.getDescription())){
//                creditMerchant.setAuditStatus(MerchantAuditEnum.FAIL_RISK.getCode());
//            }else if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_ING.getDescription())){
//                creditMerchant.setAuditStatus(MerchantAuditEnum.WAIT_RISK.getCode());
//            }else{
//                creditMerchant.setAuditStatus(MerchantAuditEnum.NOT_CERTIFIED.getCode());
//            }

            if (MercCaRasAuditEnum.enumValueOfDes(gmqResp.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_ING){
                creditMerchant.setAuditStatus(MerchantAuditEnum.WAIT_RISK.getCode());
                creditMerchant.setMerchantName(gmqResp.getCompanyName());
            }else if (MercCaRasAuditEnum.enumValueOfDes(gmqResp.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_SUCCESS){
                CreditMerchant creditMerchantDB = creditMerchantList.get(0);

//                    creditMerchant.setAuditStatus(MerchantAuditEnum.WAIT_BUSINESS.getCode());
                creditMerchant.setAuditStatus(MerchantAuditEnum.PASS_BUSINESS.getCode());
                creditMerchant.setMerchantName(gmqResp.getCompanyName());

            }else if (MercCaRasAuditEnum.enumValueOfDes(gmqResp.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_EXPIRE){
                creditMerchant.setAuditStatus(MerchantAuditEnum.CER_EXPIRE.getCode());
                creditMerchant.setMerchantName(gmqResp.getCompanyName());
            }else {
                creditMerchant.setAuditStatus(MerchantAuditEnum.NOT_CERTIFIED.getCode());
                creditMerchant.setMerchantName(gmqResp.getCompanyName());
            }

            creditMerchant.setModifiedDate(new Date());
            creditMerchant.setModifier(operator);  //一般为系统用户
            //这里没有判断更新审核状态
            int resultUpdate = merchantService.updateByPrimaryKeySelective(creditMerchant);
            if (resultUpdate > 0){
                logger.info("update merchantType success, creditMerchant:{}",ReflectionToStringBuilder.toString(creditMerchant));
            }else {
                logger.error("update merchantType error, creditMerchant:{}", ReflectionToStringBuilder.toString(creditMerchant));
                throw new IllegalArgumentException("update merchantType error");
            }
            merchantId = creditMerchant.getMerchantId();

        }else {
            //如果不存在，则需要插入新的商户信息
            CreditMerchant cm = new CreditMerchant();
            cm.setMerchantNo(merchantNo);
            GatewayMerchantQueryResponse gmqResp = merchantService.queryMerchantInfoByHttp(cm);

            if (gmqResp == null || gmqResp.getMerchant() == null){
                logger.error("merchantNo is not exist");
                throw new IllegalArgumentException("merchantNo is not exist");
            }

            CreditMerchant insertCm = new  CreditMerchant();

            insertCm.setMerchantNo(merchantNo);
            insertCm.setMerchantName(gmqResp.getCompanyName());
            insertCm.setCreator(operator);  //一般为系统用户
            insertCm.setModifier(operator);  //一般为系统用户
            insertCm.setMerchantStatus(OpenOrCloseStatusEnum.OPEN.toName());//创建商户时默认为开通open
            insertCm.setCallModel(AccessCallModeEnum.DEBUG.toName());//创建商户时默认为联调模式
            insertCm.setMerchantResource(CreditMerchantResourceEnum.NEW.toName());//创建商户时默认为新入驻商户

            insertCm.setCreatedDate(new Date());
            insertCm.setModifiedDate(new Date());
            insertCm.setMerchantType(CreditMerchantTypeEnum.ENTERPRISE.toName()); //默认为企业征信


            //判断审核状态
//            if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_SUCCESS.getDescription())){
//                insertCm.setAuditStatus(MerchantAuditEnum.WAIT_BUSINESS.getCode());
//            }else if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_REJECTED.getDescription())){
//                insertCm.setAuditStatus(MerchantAuditEnum.FAIL_RISK.getCode());
//            }else if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_ING.getDescription())){
//                insertCm.setAuditStatus(MerchantAuditEnum.WAIT_RISK.getCode());
//            }else{
//                insertCm.setAuditStatus(MerchantAuditEnum.NOT_CERTIFIED.getCode());
//            }

            if (MercCaRasAuditEnum.enumValueOfDes(gmqResp.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_ING){
                insertCm.setAuditStatus(MerchantAuditEnum.WAIT_RISK.getCode());
                insertCm.setMerchantName(gmqResp.getCompanyName());
            }else if (MercCaRasAuditEnum.enumValueOfDes(gmqResp.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_SUCCESS){
                insertCm.setAuditStatus(MerchantAuditEnum.PASS_BUSINESS.getCode());
                insertCm.setMerchantName(gmqResp.getCompanyName());
            }else if (MercCaRasAuditEnum.enumValueOfDes(gmqResp.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_SUCCESS){
                insertCm.setAuditStatus(MerchantAuditEnum.CER_EXPIRE.getCode());
                insertCm.setMerchantName(gmqResp.getCompanyName());
            }else {
                insertCm.setAuditStatus(MerchantAuditEnum.NOT_CERTIFIED.getCode());
                insertCm.setMerchantName(gmqResp.getCompanyName());
            }

            int resultInsert = merchantService.insertSelective(insertCm);
            if (resultInsert > 0){
                logger.info("insert new merchant success, creditMerchant:{}",ReflectionToStringBuilder.toString(insertCm));
            }else {
                logger.error("insert new merchant error, creditMerchant:{}", ReflectionToStringBuilder.toString(insertCm));
                throw new SQLException("insert new merchant error");
            }

            merchantId = insertCm.getMerchantId();
        }

        CreditRequestParam<UserQueryParam> requestParam = new  CreditRequestParam<UserQueryParam>();
        UserQueryParam userQueryParam = new UserQueryParam();
        userQueryParam.setLoginName(loginName);   //登录名可能会变的
//        userQueryParam.setEmail(email);
//        userQueryParam.setPhone(phone);
        userQueryParam.setOperatorId(operatorId);
        userQueryParam.setLoginInfoId(loginInfoId);
        userQueryParam.setCompanyUserId(companyUserId);
        userQueryParam.setUserStatus(CreditUserEnum.OPEN.getCode());
        userQueryParam.setMerchantId(merchantId);
        if (StringUtils.isNotBlank(jrId)){
            userQueryParam.setJrId(jrId);
        }
        requestParam.setParam(userQueryParam);

        CreditResponseData<Integer> creditUserResponseData = creditUserFacade.insert(requestParam);

        if (creditUserResponseData.isSuccess() && creditUserResponseData.getData() > 0){
            logger.info("creditUserFacade.insert success, requestParam:{}", ReflectionToStringBuilder.toString(requestParam));
            return true;
        }else {
            logger.error("creditUserFacade.insert error, response:{}", ReflectionToStringBuilder.toString(creditUserResponseData));
            throw new SQLException("creditUserFacade.insert error");
        }


    }


    /**
     * 初始化用户和商户
     * @param merchantNo
     * @param operator
     * @param loginName
     * @return
     * @throws Exception
     * @@see initSuperUserAndMerchant
     */
    @Deprecated
    private boolean initUserAndMerchant(String merchantNo,String operator,String loginName, String phone) throws Exception{
        MerchantQueryParam merchantQryParam = new MerchantQueryParam();
        if (StringUtils.isBlank(merchantNo)){
            logger.error("merchantNo is null");
            throw new IllegalArgumentException("merchantNo is null");
        }

        //获取金融id
        RequestParam<GatewayPortalUserRequest> gatewayPortalUserRequestParam = new RequestParam<GatewayPortalUserRequest>();
        GatewayPortalUserRequest gatewayPortalUserRequest = new GatewayPortalUserRequest();
        gatewayPortalUserRequest.setMerchantNo(merchantNo);
        gatewayPortalUserRequest.setUserName(loginName);
        gatewayPortalUserRequestParam.setParam(gatewayPortalUserRequest);
        logger.info("queryMerchantInfoByNoAndEmail response, request：{}", GsonUtil.getInstance().toJson(gatewayPortalUserRequestParam));
        ResponseData<String> merchantInfo = gatewayPortalFacade.queryMerchantInfoByNoAndEmail(gatewayPortalUserRequestParam);
        logger.info("queryMerchantInfoByNoAndEmail response, responseData：{}", GsonUtil.getInstance().toJson(merchantInfo));
        String jrId = null;
        if (merchantInfo.isSuccess() && merchantInfo.getData() != null){
            HashMap<String,Object> resData = GsonUtil.getInstance().fromJson(merchantInfo.getData(), new TypeToken<HashMap<String,Object>>() {}.getType());
            jrId = (String)resData.get("jrid");
            phone = (String)resData.get("phone");
            if (StringUtils.isBlank(jrId)){
                logger.error("queryMerchantInfoByNoAndEmail error, jrId is null, loginName:{}",loginName);
//                throw new Exception("jrId is null");
            }
        }else {
            logger.error("queryMerchantInfoByNoAndEmail error, loginName:{} or merchantNo:{} is not correct", loginName, merchantNo);
            return false;
        }


        merchantQryParam.setMerchantNo(merchantNo);

        List<CreditMerchant> creditMerchantList = merchantService.queryMerchantByParam(merchantQryParam);

        Integer merchantId;
        //如果已经存在商户，则按情况更新MerchantType
        if (creditMerchantList != null && creditMerchantList.size() == 1 && creditMerchantList.get(0).getMerchantNo().equals(merchantNo)){
            logger.info("CreditMerchant exists,will change merchantType");
            CreditMerchant creditMerchant = new CreditMerchant();
            creditMerchant.setMerchantId(creditMerchantList.get(0).getMerchantId());
            if (creditMerchantList.get(0).getMerchantType().equals(CreditMerchantTypeEnum.PERSON.toName())){
                creditMerchant.setMerchantType(CreditMerchantTypeEnum.ALL.toName());
            }else {
                creditMerchant.setMerchantType(CreditMerchantTypeEnum.ENTERPRISE.toName());
            }

            CreditMerchant cm = new CreditMerchant();
            cm.setMerchantNo(merchantNo);
            GatewayMerchantQueryResponse gmqResp = merchantService.queryMerchantInfoByHttp(cm);
            //判断审核状态
//            if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_SUCCESS.getDescription())){
//                creditMerchant.setAuditStatus(MerchantAuditEnum.WAIT_BUSINESS.getCode());
//            }else if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_REJECTED.getDescription())){
//                creditMerchant.setAuditStatus(MerchantAuditEnum.FAIL_RISK.getCode());
//            }else if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_ING.getDescription())){
//                creditMerchant.setAuditStatus(MerchantAuditEnum.WAIT_RISK.getCode());
//            }else{
//                creditMerchant.setAuditStatus(MerchantAuditEnum.NOT_CERTIFIED.getCode());
//            }

            if (MercCaRasAuditEnum.enumValueOfDes(gmqResp.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_ING){
                creditMerchant.setAuditStatus(MerchantAuditEnum.WAIT_RISK.getCode());
                creditMerchant.setMerchantName(gmqResp.getCompanyName());
            }else if (MercCaRasAuditEnum.enumValueOfDes(gmqResp.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_SUCCESS){
                CreditMerchant creditMerchantDB = creditMerchantList.get(0);

//                    creditMerchant.setAuditStatus(MerchantAuditEnum.WAIT_BUSINESS.getCode());
                creditMerchant.setAuditStatus(MerchantAuditEnum.PASS_BUSINESS.getCode());
                creditMerchant.setMerchantName(gmqResp.getCompanyName());

            }else if (MercCaRasAuditEnum.enumValueOfDes(gmqResp.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_EXPIRE){
                creditMerchant.setAuditStatus(MerchantAuditEnum.CER_EXPIRE.getCode());
                creditMerchant.setMerchantName(gmqResp.getCompanyName());
            }else {
                creditMerchant.setAuditStatus(MerchantAuditEnum.NOT_CERTIFIED.getCode());
                creditMerchant.setMerchantName(gmqResp.getCompanyName());
            }

            creditMerchant.setModifiedDate(new Date());
            creditMerchant.setModifier(operator);  //一般为系统用户
            //这里没有判断更新审核状态
            int resultUpdate = merchantService.updateByPrimaryKeySelective(creditMerchant);
            if (resultUpdate > 0){
                logger.info("update merchantType success, creditMerchant:{}",ReflectionToStringBuilder.toString(creditMerchant));
            }else {
                logger.error("update merchantType error, creditMerchant:{}", ReflectionToStringBuilder.toString(creditMerchant));
                throw new IllegalArgumentException("update merchantType error");
            }
            merchantId = creditMerchant.getMerchantId();

        }else {
            //如果不存在，则需要插入新的商户信息
            CreditMerchant cm = new CreditMerchant();
            cm.setMerchantNo(merchantNo);
            GatewayMerchantQueryResponse gmqResp = merchantService.queryMerchantInfoByHttp(cm);

            if (gmqResp == null || gmqResp.getMerchant() == null){
                logger.error("merchantNo is not exist");
                throw new IllegalArgumentException("merchantNo is not exist");
            }

            CreditMerchant insertCm = new  CreditMerchant();

            insertCm.setMerchantNo(merchantNo);
            insertCm.setMerchantName(gmqResp.getCompanyName());
            insertCm.setCreator(operator);  //一般为系统用户
            insertCm.setModifier(operator);  //一般为系统用户
            insertCm.setMerchantStatus(OpenOrCloseStatusEnum.OPEN.toName());//创建商户时默认为开通open
            insertCm.setCallModel(AccessCallModeEnum.DEBUG.toName());//创建商户时默认为联调模式
            insertCm.setMerchantResource(CreditMerchantResourceEnum.NEW.toName());//创建商户时默认为新入驻商户

            insertCm.setCreatedDate(new Date());
            insertCm.setModifiedDate(new Date());
            insertCm.setMerchantType(CreditMerchantTypeEnum.ENTERPRISE.toName()); //默认为企业征信


            //判断审核状态
//            if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_SUCCESS.getDescription())){
//                insertCm.setAuditStatus(MerchantAuditEnum.WAIT_BUSINESS.getCode());
//            }else if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_REJECTED.getDescription())){
//                insertCm.setAuditStatus(MerchantAuditEnum.FAIL_RISK.getCode());
//            }else if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_ING.getDescription())){
//                insertCm.setAuditStatus(MerchantAuditEnum.WAIT_RISK.getCode());
//            }else{
//                insertCm.setAuditStatus(MerchantAuditEnum.NOT_CERTIFIED.getCode());
//            }

            if (MercCaRasAuditEnum.enumValueOfDes(gmqResp.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_ING){
                insertCm.setAuditStatus(MerchantAuditEnum.WAIT_RISK.getCode());
                insertCm.setMerchantName(gmqResp.getCompanyName());
            }else if (MercCaRasAuditEnum.enumValueOfDes(gmqResp.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_SUCCESS){
                insertCm.setAuditStatus(MerchantAuditEnum.PASS_BUSINESS.getCode());
                insertCm.setMerchantName(gmqResp.getCompanyName());
            }else if (MercCaRasAuditEnum.enumValueOfDes(gmqResp.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_SUCCESS){
                insertCm.setAuditStatus(MerchantAuditEnum.CER_EXPIRE.getCode());
                insertCm.setMerchantName(gmqResp.getCompanyName());
            }else {
                insertCm.setAuditStatus(MerchantAuditEnum.NOT_CERTIFIED.getCode());
                insertCm.setMerchantName(gmqResp.getCompanyName());
            }

            int resultInsert = merchantService.insertSelective(insertCm);
            if (resultInsert > 0){
                logger.info("insert new merchant success, creditMerchant:{}",ReflectionToStringBuilder.toString(insertCm));
            }else {
                logger.error("insert new merchant error, creditMerchant:{}", ReflectionToStringBuilder.toString(insertCm));
                throw new SQLException("insert new merchant error");
            }

            merchantId = insertCm.getMerchantId();
        }

        CreditRequestParam<UserQueryParam> requestParam = new  CreditRequestParam<UserQueryParam>();
        UserQueryParam userQueryParam = new UserQueryParam();
        userQueryParam.setLoginName(loginName);
//        userQueryParam.setEmail(email);
        userQueryParam.setPhone(phone);
        userQueryParam.setUserStatus(CreditUserEnum.OPEN.getCode());
        userQueryParam.setMerchantId(merchantId);
        if (StringUtils.isNotBlank(jrId)){
            userQueryParam.setJrId(jrId);
        }
        requestParam.setParam(userQueryParam);

        CreditResponseData<Integer> creditUserResponseData = creditUserFacade.insert(requestParam);

        if (creditUserResponseData.isSuccess() && creditUserResponseData.getData() > 0){
            logger.info("creditUserFacade.insert success, requestParam:{}", ReflectionToStringBuilder.toString(requestParam));
            return true;
        }else {
            logger.error("creditUserFacade.insert error, response:{}", ReflectionToStringBuilder.toString(creditUserResponseData));
            throw new SQLException("creditUserFacade.insert error");
        }

    }
}
