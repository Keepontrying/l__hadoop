package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;
import java.util.List;

public class ProductStrategyQueryParam implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3627516716326867406L;
	/**
     * 合同ID，依据合同查询策略列表
     */
    private Integer contractId;
    /**
     * 状态，OpenOrCloseStatusEnum枚举定义对象
     */
    private String strategyStatus;
    
    /**
     * 商户ID，依据商户查询策略列表
     */
    private Integer merchantId;

	/**
	 * 商户号
	 */
	private String merchantNo;
	/**
	 * 产品
	 */
	private Integer productId;
    /**
     * ProductChargeTypeEnum枚举定义对象
     * 
     * merchantId不为空时，清结算账户关系表类型
     * single时，relation_id对应merchant表中merchant_id
     * package时，relation_id对应strategy表中strategy_id
     * 
     * contractId不为空时，对应策略表类型
     */
    private List<String> chargeTypeList;
    /**
     * 策略ID，依据策略查询策略对象
     */
    private Integer strategyId;
    /**
     * 结束时间
     */
    private String finishTime;
    /**
     * 合同ID列表
     */
    private List<Integer> contractIdList;
	/**
	 * vip监控标识：YES-vip监控；NO-普通使用
	 */
    private String vipMonitorFlag;

	public Integer getContractId() {
		return contractId;
	}

	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}

	public String getStrategyStatus() {
		return strategyStatus;
	}

	public void setStrategyStatus(String strategyStatus) {
		this.strategyStatus = strategyStatus;
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public Integer getStrategyId() {
		return strategyId;
	}

	public void setStrategyId(Integer strategyId) {
		this.strategyId = strategyId;
	}


	public List<String> getChargeTypeList() {
		return chargeTypeList;
	}

	public void setChargeTypeList(List<String> chargeTypeList) {
		this.chargeTypeList = chargeTypeList;
	}

	public String getFinishTime() {
		return finishTime;
	}

	public void setFinishTime(String finishTime) {
		this.finishTime = finishTime;
	}

	public List<Integer> getContractIdList() {
		return contractIdList;
	}

	public void setContractIdList(List<Integer> contractIdList) {
		this.contractIdList = contractIdList;
	}

	public String getMerchantNo() {
		return merchantNo;
	}

	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getVipMonitorFlag() {
		return vipMonitorFlag;
	}

	public void setVipMonitorFlag(String vipMonitorFlag) {
		this.vipMonitorFlag = vipMonitorFlag;
	}
}
