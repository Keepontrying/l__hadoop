package com.jd.jr.boss.credit.authen.core.dao;

import com.wangyin.boss.credit.admin.entity.mini.CreditDueSampleBase;
import com.wangyin.boss.credit.admin.entity.mini.CreditDueSamplePay;
import com.wangyin.boss.credit.admin.entity.mini.CreditDueSamplePic;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Description: 拓客巡检支付信息表 数据持久层
 * User: yangjinlin@jd.com
 * Date: 2018/5/24 21:31
 * Version: 1.0
 */
@Repository
public interface CreditDueSamplePayDao {
    /**
     * 批量落地拓客巡检样本支付信息
     * @param samplePayList
     */
    void saveBatchDueSamplePay(List<CreditDueSamplePay> samplePayList);
}
