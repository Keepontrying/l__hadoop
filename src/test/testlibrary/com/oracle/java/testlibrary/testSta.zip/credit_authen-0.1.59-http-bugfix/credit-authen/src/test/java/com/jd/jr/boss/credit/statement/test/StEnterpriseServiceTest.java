/**
 * <p>项目名称：credit-authen-core<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2019年1月31日</li>
 * <li>3、开发时间：下午2:58:22</li>
 * <li>4、作          者：fangzhigang</li>
 * <li>5、包路径名：com.jd.jr.boss.credit.authen.statement</li>
 * <li>6、文件名称：StEnterpriseServiceTest.java</li>
 * </ul>
 */
package com.jd.jr.boss.credit.statement.test;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;
import com.jd.jr.boss.credit.authen.statement.beans.dto.StEnterpriseAccountDTO;
import com.jd.jr.boss.credit.authen.statement.beans.dto.StEnterpriseInfoDTO;
import com.jd.jr.boss.credit.authen.statement.dao.StEnterpriseAccountMapper;
import com.jd.jr.boss.credit.authen.statement.dao.StUploadRecordMapper;
import com.jd.jr.boss.credit.authen.statement.service.StEnterpriseService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.key.server.DeviceCryptoService;


/**
 * <ul>
 * <li>1、开发日期：2019年1月31日</li>
 * <li>2、开发时间：下午2:58:22</li>
 * <li>3、作          者：fangzhigang</li>
 * <li>4、类型名称：StEnterpriseServiceTest</li>
 * <li>5、类型意图：</li>
 * </ul>
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring/spring-authen.xml" })
public class StEnterpriseServiceTest {
	
	@Resource
	private StEnterpriseService stEnterpriseService;
	
	@Resource
	private DeviceCryptoService deviceCryptoService;
	
	@Resource
	private StEnterpriseAccountMapper stEnterpriseAccountMapper;

    private static Logger log = LoggerFactory.getLogger(StEnterpriseServiceTest.class);
//
//	@Test 
//	public void addEntInfoTest() {
//		try {
//			StEnterpriseInfoDTO stEntInfoParam = new StEnterpriseInfoDTO();
//			List<StEnterpriseAccountDTO> stEnterpriseAccountParamList = new ArrayList<StEnterpriseAccountDTO>();
//			StEnterpriseAccountDTO entAccount = new StEnterpriseAccountDTO();
//			
////			String encrypt = deviceCryptoService.encryptString("cme_04_001", "622518801138823房志刚".getBytes());
////			byte[] decryptString = deviceCryptoService.decryptString("cme_04_001", encrypt);
////			log.info("解密后数据：" + decryptString);
////			log.info("解密后数据字符串：" + new String(decryptString,"UTF-8"));
////			entAccount.setAccountNo(encrypt);
//			entAccount.setAccountNo("908234ikhdhsf82347523742o93328489034905");
//			entAccount.setAccountNoEncrypt("IEW987983J98F32JH32JK");
//			entAccount.setBankCode("ICBC");
//			entAccount.setAccountType("HK");
//			entAccount.setBillType("KL");
//			entAccount.setCreater("FZG");
//			entAccount.setModifier("FZG");
//			
//			stEnterpriseAccountParamList.add(entAccount);
//			stEntInfoParam.setStEnterpriseAccountDTOList(stEnterpriseAccountParamList);
//			stEntInfoParam.setCompanyName("小米科技有限公司");
//			stEntInfoParam.setOrgNo("T7834798238X");
//			stEntInfoParam.setMerchantNo("101");
//			stEntInfoParam.setActualController("雷军");
//			stEntInfoParam.setIdCardNo("410422");
//			stEntInfoParam.setLegalRepresent("雷军的秘书");
//			stEntInfoParam.setRegNo("G8923749X");
//			stEntInfoParam.setUserPin("JDPIN_0087932");
//			stEntInfoParam.setGroupId("1");
//			stEntInfoParam.setCreater("fzg");
//			stEntInfoParam.setModifier("fzg");
//			
//			long t1 = System.currentTimeMillis();
//			
//			JSON.toJSONString(stEntInfoParam);
//			
//			long t2 = System.currentTimeMillis();
////			
////			JSONUtils.toJSON(stEntInfoParam);
////			
////			long t3 = System.currentTimeMillis();
////			
////			GsonUtils.toJson(stEntInfoParam);
////			
////			long t4 = System.currentTimeMillis();
//			
//			
//			
//			log.info("FastJson耗时："+(t2-t1));
////			log.info("jackson耗时："+(t3-t2));
////			log.info("Gson耗时："+(t4-t3));
//			
//			
////			Response<?> addEntInfo = stEnterpriseService.addEntInfo(stEntInfoParam);
////			System.err.println("返回结果"+GsonUtil.getInstance().toJson(addEntInfo));
//		} catch (Exception e) {
//			log.info("测试未通过>>>>>",e);
//		}
//	}
//	public static void main(String[] args) {
//		StEnterpriseInfoDTO stEntInfoParam = new StEnterpriseInfoDTO();
//		List<StEnterpriseAccountDTO> stEnterpriseAccountParamList = new ArrayList<StEnterpriseAccountDTO>();
//		StEnterpriseAccountDTO entAccount = new StEnterpriseAccountDTO();
//		
////		String encrypt = deviceCryptoService.encryptString("cme_04_001", "622518801138823房志刚".getBytes());
////		byte[] decryptString = deviceCryptoService.decryptString("cme_04_001", encrypt);
////		log.info("解密后数据：" + decryptString);
////		log.info("解密后数据字符串：" + new String(decryptString,"UTF-8"));
////		entAccount.setAccountNo(encrypt);
//		entAccount.setAccountNo("908234ikhdhsf82347523742o93328489034905");
//		entAccount.setAccountNoEncrypt("IEW987983J98F32JH32JK");
//		entAccount.setBankCode("ICBC");
//		entAccount.setAccountType("HK");
//		entAccount.setBillType("KL");
//		entAccount.setCreater("FZG");
//		entAccount.setModifier("FZG");
//		
//		stEnterpriseAccountParamList.add(entAccount);
//		stEntInfoParam.setStEnterpriseAccountDTOList(stEnterpriseAccountParamList);
//		stEntInfoParam.setCompanyName("小米科技有限公司");
//		stEntInfoParam.setOrgNo("T7834798238X");
//		stEntInfoParam.setMerchantNo("101");
//		stEntInfoParam.setActualController("雷军");
//		stEntInfoParam.setIdCardNo("410422");
//		stEntInfoParam.setLegalRepresent("雷军的秘书");
//		stEntInfoParam.setRegNo("G8923749X");
//		stEntInfoParam.setUserPin("JDPIN_0087932");
//		stEntInfoParam.setGroupId("1");
//		stEntInfoParam.setCreater("fzg");
//		stEntInfoParam.setModifier("fzg");
//		
////		long t1 = System.currentTimeMillis();
////		JSON.toJSONString(stEntInfoParam);
////		long t2 = System.currentTimeMillis();
////		JsonUtil.toJson(stEntInfoParam);
////		JSONUtils.toJSON(stEntInfoParam);
////		
//		long t3 = System.currentTimeMillis();
////		
////		GsonUtils.toJson(stEntInfoParam);
//		String string = stEntInfoParam.toString();
//		System.out.println(string);
////		
//		long t4 = System.currentTimeMillis();
//		
//		
//		
////		log.info("FastJson耗时："+(t2-t1));
////		log.info("jackson耗时："+(t3-t2));
//		log.info("Gson耗时："+(t4-t3));
//	}
//	
//	@Test 
//	public void exportEntInfoTest() {
//		try {
//			StEnterpriseInfoDTO stEntInfoParam = new StEnterpriseInfoDTO();
//			stEntInfoParam.setMerchantNo("101");
//			stEnterpriseService.exportEntInfo(stEntInfoParam);
//		} catch (Exception e) {
//			log.info("测试未通过>>>>>",e);
//		}
//	}
	
	@Resource
	private StUploadRecordMapper mapper;
	@Test 
	public void mapperTest() {
	    try {
	        int updateByStatus = mapper.updateByStatus("WAIT", 1);
	        System.out.println(updateByStatus+"OK");
	    } catch (Exception e) {
	        log.info("测试未通过>>>>>",e);
	    }
	}
	


}
