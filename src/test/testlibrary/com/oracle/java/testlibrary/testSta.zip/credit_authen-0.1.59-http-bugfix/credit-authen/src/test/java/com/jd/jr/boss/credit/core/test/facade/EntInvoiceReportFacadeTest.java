package com.jd.jr.boss.credit.core.test.facade;

import com.jd.fastjson.JSON;
import com.jd.jr.boss.credit.facade.authen.api.EntInvoiceReportFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.EntInvoiceReportAuthParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.AntiMoneyLaunderFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.ResultData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.CdAntiMoneyLaunderParam;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.antiMoneyLaunder.chinaData.ChinaDataAntiMoneyLaunderResp;
import com.jd.jr.boss.credit.gateway.account.utils.SerialNoUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author ：zhanghui12
 * @date ：Created in 2019/3/20 11:39
 * @description：
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})
public class EntInvoiceReportFacadeTest {
    @Resource
    EntInvoiceReportFacade entInvoiceReportFacade;

    @Test
    public void testFacade(){
        CreditRequestParam<EntInvoiceReportAuthParam> requestParam=new CreditRequestParam<EntInvoiceReportAuthParam>();
        requestParam.setTradeNo(SerialNoUtils.createSerialNo("TRADE"));
        requestParam.setSystemId("a3884c68df2711e7a293ecf4bbcdd49c");
        EntInvoiceReportAuthParam param=new EntInvoiceReportAuthParam();
        List<String[]> files=new ArrayList<>();
        String[] digitFile=new String[3];
        digitFile[0]="digitFile";
        digitFile[1]="open_201903_14e1664435154e2faaa385e4e93b3c0a.png";//不能为空
        digitFile[2]="2019-06-01";
        files.add(digitFile);
        param.setAuthType(files);
        param.setCreditCode("1111");
        param.setMerchantNo("1111");
        param.setNoticeUrl("1111");
        param.setTaxNo("1111");
        param.setUnionId("1111");
        requestParam.setParam(param);
        CreditResponseData responseData=entInvoiceReportFacade.saveAuthOrder(requestParam);
        System.out.println(JSON.toJSONString(responseData));
    }
}
