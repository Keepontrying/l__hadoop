package com.jd.jr.boss.credit.authen.core.enums;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 确认合同传入参数
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */

public enum PaymentDetailsColumnEnum {

    NULL(-1, null, null),

    /**
     * 名称
     */
    PRODUCTNAME(0, "productName", "名称"),
    /**
     * 包量金额
     */
    AMOUNT(1, "amount", "包量金额"),
    /**
     * 包量次数
     */
    PACKETCOUNT(2, "packetCount", "包量次数"),
    /**
     * 开始时间
     */
    STARTTIME(3, "startTime", "开始时间"),
    
    /**
     * 结束时间
     */
    FINISHTIME(4, "finishTime", "结束时间");

    private Integer code;
    private String name;
    private String description;


    /**
     * @param description 中文描述
     */
    PaymentDetailsColumnEnum(String description) {
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param description 中文描述
     */
    PaymentDetailsColumnEnum(Integer code, String description) {
        this.code = code;
        this.description = description;
    }

    /**
     * @param name        英文编码名称
     * @param description 中文描述
     */
    PaymentDetailsColumnEnum(String name, String description) {
        this.name = name;
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param name        英文编码名称
     * @param description 中文描述
     */
    PaymentDetailsColumnEnum(Integer code, String name, String description) {
        this.code = code;
        this.name = name;
        this.description = description;
    }


    /**
     * 获取枚举类型数值编码
     */
    public Integer toCode() {
        return this.code == null ? this.ordinal() : this.code;
    }

    /**
     * 获取枚举类型英文编码名称
     */
    public String toName() {
        return this.name == null ? this.name() : this.name;
    }

    /**
     * 获取枚举类型中文描述
     */
    public String toDescription() {
        return this.description;
    }

    /**
     * 获取枚举类型中文描述
     */
    public String toString() {
        return this.description;
    }

    /**
     * 按数值获取对应的枚举类型
     *
     * @param code 数值
     * @return 枚举类型
     */
    public static PaymentDetailsColumnEnum enumValueOf(Integer code) {
        PaymentDetailsColumnEnum[] values = PaymentDetailsColumnEnum.values();
        PaymentDetailsColumnEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (code != null && code.equals(values[i].toCode())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 按英文编码获取对应的枚举类型
     *
     * @param name 英文编码
     * @return 枚举类型
     */
    public static PaymentDetailsColumnEnum enumValueOf(String name) {
        PaymentDetailsColumnEnum[] values = PaymentDetailsColumnEnum.values();
        PaymentDetailsColumnEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (name != null && name.equalsIgnoreCase(values[i].toName())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 获取枚举类型的所有<数字编码,中文描述>对
     *
     * @return
     */
    public static Map<Integer, String> toCodeDescriptionMap() {
        LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
        for (int i = 0; i < PaymentDetailsColumnEnum.values().length; i++) {
            if (PaymentDetailsColumnEnum.values()[i] != NULL) {
                map.put(PaymentDetailsColumnEnum.values()[i].toCode(), PaymentDetailsColumnEnum.values()[i].toDescription());
            }
        }
        return map;
    }

    /**
     * 获取枚举类型的所有<英文编码名称,中文描述>对
     *
     * @return
     */
    public static Map<String, String> toNameDescriptionMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        for (int i = 0; i < PaymentDetailsColumnEnum.values().length; i++) {
            if (PaymentDetailsColumnEnum.values()[i] != NULL) {
                map.put(PaymentDetailsColumnEnum.values()[i].toName(), PaymentDetailsColumnEnum.values()[i].toDescription());
            }
        }
        return map;
    }

}
