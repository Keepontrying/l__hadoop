package com.jd.jr.boss.credit.authen.core.facade;

import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.facade.authen.api.CreditDealFlowFacade;

/** 
* @desciption : 交易流水facade实现类
* @author : yangjinlin@jd.com
* @date ：2018年4月23日 下午5:24:28 
* @version 1.0 
* @return  */
@Service("creditDealFlowFacade")
public class CreditDealFlowFacadeImpl implements CreditDealFlowFacade {

	

}
