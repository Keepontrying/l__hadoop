package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.Date;

import com.jd.jr.boss.credit.facade.authen.enums.ElaneDataEnum;

public class CreditElaneParam implements Serializable {
    private static final long serialVersionUID = 3462318651906694800L;
    private Long id;

    private String dataType;

    private ElaneDataEnum status;

    private String carrierCode;

    private String bl;

    private String containerNumber;

    private String querytype;

    private String vslname;

    private String voycode;

    private Date createdDate;

    private Date modifiedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType == null ? null : dataType.trim();
    }

    public ElaneDataEnum getStatus() {
		return status;
	}

	public void setStatus(ElaneDataEnum status) {
		this.status = status;
	}

	public String getCarrierCode() {
        return carrierCode;
    }

    public void setCarrierCode(String carrierCode) {
        this.carrierCode = carrierCode == null ? null : carrierCode.trim();
    }

    public String getBl() {
        return bl;
    }

    public void setBl(String bl) {
        this.bl = bl == null ? null : bl.trim();
    }

    public String getContainerNumber() {
        return containerNumber;
    }

    public void setContainerNumber(String containerNumber) {
        this.containerNumber = containerNumber == null ? null : containerNumber.trim();
    }

    public String getQuerytype() {
        return querytype;
    }

    public void setQuerytype(String querytype) {
        this.querytype = querytype == null ? null : querytype.trim();
    }

    public String getVslname() {
        return vslname;
    }

    public void setVslname(String vslname) {
        this.vslname = vslname == null ? null : vslname.trim();
    }

    public String getVoycode() {
        return voycode;
    }

    public void setVoycode(String voycode) {
        this.voycode = voycode == null ? null : voycode.trim();
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
}