package com.jd.jr.boss.credit.authen.core.facade.external;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.jd.jr.boss.credit.authen.core.beans.entity.CreditProductMenu;
import com.jd.jr.boss.credit.authen.core.beans.entity.ProductItemShow;
import com.jd.jr.boss.credit.authen.core.beans.entity.ProductToBuyShow;
import com.jd.jr.boss.credit.authen.core.enums.CreditProductChildMenuEnum;
import com.jd.jr.boss.credit.facade.authen.api.CreditProductFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.ProductItemQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditExRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.external.api.CreditExProductFacade;
import com.jd.jr.boss.credit.facade.external.beans.entity.CreditItemSkuEntity;
import com.jd.jr.boss.credit.facade.external.beans.entity.CreditProductMenuEntity;
import com.jd.jr.boss.credit.facade.external.beans.request.MerchantReq;
import com.jd.jr.boss.credit.facade.external.beans.request.ProductItemCustomQueryReq;
import com.jd.jr.boss.credit.facade.external.beans.request.ProductItemQueryReq;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditItemResp;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditProductMenuResp;
import com.jd.jr.boss.credit.facade.external.enums.CreditItemEnum;
import com.jd.jr.boss.credit.facade.external.enums.CreditProductChargeStatusEnum;
import com.jd.jr.boss.credit.facade.external.enums.CreditProductSortEnum;
import com.jd.jr.boss.credit.facade.external.enums.ProductChargeTypeEnum;
import com.wangyin.boss.credit.admin.entity.CreditItem;
import com.wangyin.boss.credit.admin.entity.CreditItemSku;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @author jiangbo
 * @since 2017/3/29
 */
@Service("creditExProductFacade")
public class CreditExProductFacadeImpl implements CreditExProductFacade {
    private static Logger logger = LoggerFactory.getLogger(CreditExProductFacadeImpl.class);

    @Autowired
    CreditProductFacade creditProductFacade;

    /**
     * 1、服务关停：服务列表和产品购买中心可以看到，不能使用，可以购买；
     * 2、黑名单：服务列表和产品购买中心可以都看不到，不能使用也不能购买
     * 3、下架：服务列表购买了可以看到，也可以用，产品购买中心看不到，也不能买
     * @param requestParam
     * @return
     */
    public CreditResponseData<CreditProductMenuResp> queryProductItem(CreditExRequestParam<ProductItemQueryReq> requestParam) {
        CreditRequestParam<ProductItemQueryParam> request = new CreditRequestParam<ProductItemQueryParam>();
        CreditResponseData<CreditProductMenuResp> creditExResponseData = new CreditResponseData<CreditProductMenuResp>();

        CreditProductMenuResp creditProductMenuResp = new CreditProductMenuResp();

        try{
            ProductItemQueryParam productItemQueryParam = new ProductItemQueryParam();
            productItemQueryParam.setMerchantNo(requestParam.getParam().getMerchantNo());

            productItemQueryParam.setChargeStatus(CreditProductChargeStatusEnum.NOTFREE.toName());
            productItemQueryParam.setItemStatus(CreditItemEnum.SHELVE.getCode());
            productItemQueryParam.setProductSort(CreditProductSortEnum.CREDIT_SERVICE.toName());

            request.setParam(productItemQueryParam);

            //查看全部可用的CreditItem
            CreditResponseData<List<CreditItem>> responseData = creditProductFacade.queryProductItem(request);

            CreditProductMenu creditProductMenu = new CreditProductMenu();
            LinkedHashMap<String, CreditProductMenuEntity> menu = creditProductMenu.getMenu();

            if (!responseData.isSuccess() || responseData.getData() == null){
                creditExResponseData.setMessage(responseData.getMessage());
                creditExResponseData.setCode(responseData.getCode());
                creditExResponseData.setSuccess(responseData.isSuccess());
                logger.info("queryProductItem creditExResponseData:{}", JSONObject.toJSONString(creditExResponseData));
                return  creditExResponseData;
            } else if (responseData.getData() != null){
                this.setValid(responseData.getData(),menu);
            }

            //查询用户可用的CreditItem
            if (StringUtils.isNotBlank(request.getParam().getMerchantNo())){
                CreditResponseData<List<CreditItem>> responseDataShow = creditProductFacade.queryProductShowItem(request);

                if (!responseDataShow.isSuccess() || responseDataShow.getData() == null){
                    creditExResponseData.setMessage(responseData.getMessage());
                    creditExResponseData.setCode(responseData.getCode());
                    creditExResponseData.setSuccess(responseData.isSuccess());
                    logger.info("queryProductItem creditExResponseShowData:{}", JSONObject.toJSONString(creditExResponseData));
                    return  creditExResponseData;
                }else if (responseDataShow.getData() != null){
                    this.setValid(responseDataShow.getData(),menu);
                }
            }

            this.cleanMenu(menu);
            ArrayList<CreditProductMenuEntity> menuList = new ArrayList(menu.values());

            creditProductMenuResp.setMenu(menuList);
            creditExResponseData.setData(creditProductMenuResp);
            creditExResponseData.setMessage(responseData.getMessage());
            creditExResponseData.setCode(responseData.getCode());
            creditExResponseData.setSuccess(responseData.isSuccess());
        }catch (Exception e){
            logger.error("queryProductItem error, requestParam:{}", JSONObject.toJSONString(requestParam),e);
            creditExResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }

        logger.info("queryProductItem creditExResponseData:{}", JSONObject.toJSONString(creditExResponseData));

        return creditExResponseData;
    }


    /**
     * 1、服务关停：服务列表和产品购买中心可以看到，不能使用，可以购买；
     * 2、黑名单：服务列表和产品购买中心可以都看不到，不能使用也不能购买
     * 3、下架：服务列表购买了可以看到，也可以用，产品购买中心看不到，也不能买
     * @param requestParam
     * @return
     */
    public CreditResponseData<CreditProductMenuResp> queryProductItemCustom(CreditExRequestParam<ProductItemCustomQueryReq> requestParam) {
        CreditRequestParam<ProductItemQueryParam> request = new CreditRequestParam<ProductItemQueryParam>();
        CreditResponseData<CreditProductMenuResp> creditExResponseData = new CreditResponseData<CreditProductMenuResp>();

        CreditProductMenuResp creditProductMenuResp = new CreditProductMenuResp();
        try{
            ProductItemQueryParam productItemQueryParam = new ProductItemQueryParam();
            productItemQueryParam.setMerchantNo(requestParam.getParam().getMerchantNo());
            productItemQueryParam.setChargeStatus(CreditProductChargeStatusEnum.NOTFREE.toName());
            productItemQueryParam.setItemStatus(CreditItemEnum.SHELVE.getCode());
            productItemQueryParam.setProductSort(CreditProductSortEnum.CREDIT_SERVICE.toName());
            request.setParam(productItemQueryParam);

            //查看全部可用的CreditItem
            CreditResponseData<List<CreditItem>> responseData = creditProductFacade.queryProductItem(request);

            CreditProductMenu creditProductMenu = new CreditProductMenu();
            LinkedHashMap<String, CreditProductMenuEntity> menu = creditProductMenu.getMenu();

            if (!responseData.isSuccess() || responseData.getData() == null){
                creditExResponseData.setMessage(responseData.getMessage());
                creditExResponseData.setCode(responseData.getCode());
                creditExResponseData.setSuccess(responseData.isSuccess());
                logger.info("queryProductItemCustom creditExResponseData:{}", GsonUtil.getInstance().toJson(creditExResponseData));
                return  creditExResponseData;
            } else if (responseData.getData() != null){
                this.setValid(responseData.getData(),menu);
            }

            //查询用户可用的CreditItem
            if (StringUtils.isNotBlank(request.getParam().getMerchantNo())){
                CreditResponseData<List<CreditItem>> responseDataShow = creditProductFacade.queryProductShowItem(request);

                if (!responseDataShow.isSuccess() || responseDataShow.getData() == null){
                    creditExResponseData.setMessage(responseData.getMessage());
                    creditExResponseData.setCode(responseData.getCode());
                    creditExResponseData.setSuccess(responseData.isSuccess());
                    logger.info("queryProductItemCustom creditExResponseShowData:{}", GsonUtil.getInstance().toJson(creditExResponseData));
                    return  creditExResponseData;
                }else if (responseDataShow.getData() != null){
                    this.setValid(responseDataShow.getData(),menu);
                }
            }
            this.cleanMenu2(menu, 7);

            ArrayList<CreditProductMenuEntity> menuList = new ArrayList(menu.values());

            creditProductMenuResp.setMenu(menuList);
            creditExResponseData.setData(creditProductMenuResp);
            creditExResponseData.setMessage(responseData.getMessage());
            creditExResponseData.setCode(responseData.getCode());
            creditExResponseData.setSuccess(responseData.isSuccess());
        }catch (Exception e){
            logger.error("queryProductItemCustom error, requestParam:{}", GsonUtil.getInstance().toJson(requestParam),e);
            creditExResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }

        logger.info("queryProductItemCustom creditExResponseData:{}", GsonUtil.getInstance().toJson(creditExResponseData));

        return creditExResponseData;
    }

    /**
     * 查询可购买的产品及产品包
     * 所有上架商品 - 商户黑名单产品
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<CreditProductMenuResp> queryAvailableItem(CreditExRequestParam<MerchantReq> requestParam) {
        CreditRequestParam<ProductItemQueryParam> request = new CreditRequestParam<ProductItemQueryParam>();
        CreditResponseData<CreditProductMenuResp> creditExResponseData = new CreditResponseData<CreditProductMenuResp>();

        CreditProductMenuResp creditProductMenuResp = new CreditProductMenuResp();

        try{
            ProductItemQueryParam productItemQueryParam = new ProductItemQueryParam();
            productItemQueryParam.setMerchantNo(requestParam.getParam().getMerchantNo());

            productItemQueryParam.setChargeStatus(CreditProductChargeStatusEnum.NOTFREE.toName());
            productItemQueryParam.setItemStatus(CreditItemEnum.SHELVE.getCode());
            productItemQueryParam.setProductSort(CreditProductSortEnum.CREDIT_SERVICE.toName());

            request.setParam(productItemQueryParam);

            //查看全部可用的CreditItem
            CreditResponseData<List<CreditItem>> responseData = creditProductFacade.queryProductItem(request);

            if (!responseData.isSuccess() || responseData.getData() == null){
                creditExResponseData.setMessage(responseData.getMessage());
                creditExResponseData.setCode(responseData.getCode());
                creditExResponseData.setSuccess(responseData.isSuccess());
                logger.info("queryAvailableItem creditExResponseData:{}", GsonUtil.getInstance().toJson(creditExResponseData));
                return  creditExResponseData;
            } else if (responseData.getData() != null){
                ProductToBuyShow show=new ProductToBuyShow();
                Map<String,ProductItemShow> itemShowMap=show.getItemMap();
                for (CreditItem item : responseData.getData()) {
                    String productCode = item.getProductCode();
                    ProductItemShow itemShow = itemShowMap.get(productCode);
                    if (itemShow != null) {
                        itemShow.setShow(true);
                        itemShow.setShowName(item.getProductName());
                        BeanUtils.copyProperties(item,itemShow);
                    }
                }

                ArrayList<CreditProductMenuEntity> menuList = this.genMenuList(show);

                creditProductMenuResp.setMenu(menuList);
                creditExResponseData.setData(creditProductMenuResp);
                creditExResponseData.setMessage(responseData.getMessage());
                creditExResponseData.setCode(responseData.getCode());
                creditExResponseData.setSuccess(responseData.isSuccess());
            }

        }catch (Exception e){
            logger.error("queryAvailableItem error, requestParam:{}", GsonUtil.getInstance().toJson(requestParam),e);
            creditExResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }

        logger.info("queryAvailableItem creditExResponseData:{}", GsonUtil.getInstance().toJson(creditExResponseData));

        return creditExResponseData;
    }

    private ArrayList<CreditProductMenuEntity> genMenuList(ProductToBuyShow show){
        ArrayList<CreditProductMenuEntity> entityList=new ArrayList<CreditProductMenuEntity>();
        LinkedHashMap<String,List<ProductItemShow>> menuMap =show.getMenuMap();
        for(String menuName:menuMap.keySet()){
            CreditProductMenuEntity entity=new CreditProductMenuEntity();
            entity.setDisplayName(menuName);

            List<ProductItemShow> itemShows=menuMap.get(menuName);
            List<CreditProductMenuEntity> subMenu=new ArrayList<>();
            itemShows.forEach(itemShow->{
                if(itemShow.isShow()) {
                    CreditProductMenuEntity subEntity = new CreditProductMenuEntity();
                    subEntity.setValid(true);
                    subEntity.setMenuLevel(2);
                    subEntity.setIconCode(itemShow.getIconClass());
                    subEntity.setDisplayName(itemShow.getShowName());
                    subEntity.setCode(itemShow.getProductCode());
                    CreditItemResp itemResp=new CreditItemResp();
                    BeanUtils.copyProperties(itemShow,itemResp);
                    if(itemShow.getCreditItemSkuList()!=null){
                        List<CreditItemSkuEntity> skuEntityList=new ArrayList<CreditItemSkuEntity>();
                        itemShow.getCreditItemSkuList().forEach(itemSku->{
                            if("PACKAGE".equals(itemSku.getChargeType())) {//只展示包量sku
                                CreditItemSkuEntity skuEntity = new CreditItemSkuEntity();
                                BeanUtils.copyProperties(itemSku, skuEntity);
                                skuEntity.setChargeType(ProductChargeTypeEnum.enumValueOf(itemSku.getChargeType()));
                                skuEntityList.add(skuEntity);
                            }
                        });
                        itemResp.setCreditItemSkuList(skuEntityList);
                    }
                    subEntity.setCreditItem(itemResp);
                    subMenu.add(subEntity);
                }
            });
            entity.setSubMenu(subMenu);
            if(!subMenu.isEmpty()) {
                entity.setValid(true);
                entity.setMenuLevel(1);
                entityList.add(entity);
            }
        }
        return entityList;
    }

    /**
     * 查询所有已上架产品
     *
     * @param queryParam
     * @return
     */
    @Override
    public CreditResponseData<CreditProductMenuResp> queryShelvedProductItem(CreditExRequestParam queryParam) {
        CreditResponseData<CreditProductMenuResp> creditExResponseData = new CreditResponseData<CreditProductMenuResp>();
        CreditProductMenuResp creditProductMenuResp = new CreditProductMenuResp();
        try{
            ProductToBuyShow show=new ProductToBuyShow();
            HashMap<String, ProductItemShow> itemMap=show.getItemMap();
            itemMap.values().forEach(itemShow->{
                itemShow.setShow(true);
            });
            ArrayList<CreditProductMenuEntity> menuList = this.genMenuList(show);
            creditProductMenuResp.setMenu(menuList);
            creditExResponseData.setData(creditProductMenuResp);

        }catch (Exception e){
            logger.error("queryShelvedProductItem error", e);
            creditExResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }

        logger.info("queryShelvedProductItem creditExResponseData:{}", GsonUtil.getInstance().toJson(creditExResponseData));

        return creditExResponseData;
    }


    private void setValid(List<CreditItem> creditItemList, LinkedHashMap<String, CreditProductMenuEntity> menu){
        for (CreditItem creditItem:creditItemList){
            CreditItemResp creditItemResp = new CreditItemResp();
            String productCode = creditItem.getProductCode();

            for (CreditProductChildMenuEnum creditProductChildMenuEnum : CreditProductChildMenuEnum.values()) {
                if (creditProductChildMenuEnum.toParentCode() != null && productCode.equals(creditProductChildMenuEnum.toParentCode())) {
                    CreditProductMenuEntity creditProductMenuEntity = menu.get(creditProductChildMenuEnum.toName());
                    if (creditProductMenuEntity != null){
                        creditProductMenuEntity.setValid(true);
                        menu.get(creditProductMenuEntity.getParentCode()).setValid(true);
                        BeanUtils.copyProperties(creditItem, creditItemResp);
                        creditProductMenuEntity.setCreditItem(creditItemResp);
                    }
                }
            }

            CreditProductMenuEntity creditProductMenuEntity = menu.get(productCode);
            if (creditProductMenuEntity != null){
                creditProductMenuEntity.setValid(true);
                menu.get(creditProductMenuEntity.getParentCode()).setValid(true);
                BeanUtils.copyProperties(creditItem, creditItemResp);
                creditProductMenuEntity.setCreditItem(creditItemResp);
            }

        }


    }

    /**
     * 1、去掉valid为false的数据
     * 2、去掉冗余数据，即menu的map里不需要非level为1的CreditProductMenuEntity
     * 3、仅对二级目录有用，二级以上的目录需要修改代码
     */
    private void cleanMenu(LinkedHashMap<String, CreditProductMenuEntity> menu) {
        LinkedHashMap<String, CreditProductMenuEntity> menuClone = new LinkedHashMap<String, CreditProductMenuEntity>();
        menuClone.putAll(menu); //浅拷贝

        for (String key : menuClone.keySet()) {
            CreditProductMenuEntity creditProductMenuEntity = menu.get(key);
            //非1级和false的去掉
            if (creditProductMenuEntity.getMenuLevel() != 1 || creditProductMenuEntity.isValid() == false){
                menu.remove(key);
            }else{
                List<CreditProductMenuEntity> subMenu = creditProductMenuEntity.getSubMenu();

                if (subMenu != null && subMenu.size() > 0){
                    List<CreditProductMenuEntity> subMenuClone = new ArrayList<CreditProductMenuEntity>(subMenu); //浅拷贝

                    //子菜单里去掉为false的对象
                    for (CreditProductMenuEntity subCreditProductMenuEntity: subMenuClone){
                        if (subCreditProductMenuEntity.isValid() == false){
                            subMenu.remove(subCreditProductMenuEntity);
                        }
                    }
                }


            }

        }
    }


    /**
     * 1、去掉valid为false的数据
     * 2、去掉冗余数据，只保留level为2的产品
     */
    private void cleanMenu2(LinkedHashMap<String, CreditProductMenuEntity> menu, Integer limit) {
        LinkedHashMap<String, CreditProductMenuEntity> menuClone = new LinkedHashMap<String, CreditProductMenuEntity>();
        menuClone.putAll(menu); //浅拷贝

        int index = 0;

        for (String key : menuClone.keySet()) {
            CreditProductMenuEntity creditProductMenuEntity = menu.get(key);

            if (creditProductMenuEntity.getMenuLevel() == 1 || creditProductMenuEntity.isValid() == false){
                menu.remove(key);
                continue;
            }else {
                index++;
            }

            if (limit != null && index > limit){
                menu.remove(key);
            }

        }
    }


}
