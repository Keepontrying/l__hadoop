package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;
import java.util.Date;

public class ContractUpdateParam implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5610392538704587942L;
	/**
     * 合同ID
     */
    private Integer contractId;
    /**
     * 合同状态
     */
    private String contractStatus;
    /**
     * 合同确认时间
     */
    private Date ensureTime;
    /**
     * 合同修改时间
     */
    private Date modifiedDate;

	public Integer getContractId() {
		return contractId;
	}

	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}

	public String getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public Date getEnsureTime() {
		return ensureTime;
	}

	public void setEnsureTime(Date ensureTime) {
		this.ensureTime = ensureTime;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
