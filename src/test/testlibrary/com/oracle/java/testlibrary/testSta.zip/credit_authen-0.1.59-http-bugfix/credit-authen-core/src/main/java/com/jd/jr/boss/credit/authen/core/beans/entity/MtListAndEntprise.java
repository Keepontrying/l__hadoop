package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * created by ChenKaiJu on 2018/9/20  10:01
 */
public class MtListAndEntprise implements Serializable {
    private static final long serialVersionUID = -3648604163806923812L;
    private String systemId;

    private Integer entpriseId;

    private Date createdDate;

    private String listMonitored;

    private Date listBeginDate;

    private Date listEndDate;

    private Date modifiedDate;

    private String entName;

    private String creditCode;

    private String regNo;

    private String createSystemId;

    private String modifier;

    private String entMonitored;

    private Date entBeginDate;

    private Date entEndDate;

    private String extraMsg;

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public Integer getEntpriseId() {
        return entpriseId;
    }

    public void setEntpriseId(Integer entpriseId) {
        this.entpriseId = entpriseId;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getListMonitored() {
        return listMonitored;
    }

    public void setListMonitored(String listMonitored) {
        this.listMonitored = listMonitored;
    }

    public Date getListBeginDate() {
        return listBeginDate;
    }

    public void setListBeginDate(Date listBeginDate) {
        this.listBeginDate = listBeginDate;
    }

    public Date getListEndDate() {
        return listEndDate;
    }

    public void setListEndDate(Date listEndDate) {
        this.listEndDate = listEndDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getEntName() {
        return entName;
    }

    public void setEntName(String entName) {
        this.entName = entName;
    }

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getCreateSystemId() {
        return createSystemId;
    }

    public void setCreateSystemId(String createSystemId) {
        this.createSystemId = createSystemId;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public String getEntMonitored() {
        return entMonitored;
    }

    public void setEntMonitored(String entMonitored) {
        this.entMonitored = entMonitored;
    }

    public Date getEntBeginDate() {
        return entBeginDate;
    }

    public void setEntBeginDate(Date entBeginDate) {
        this.entBeginDate = entBeginDate;
    }

    public Date getEntEndDate() {
        return entEndDate;
    }

    public void setEntEndDate(Date entEndDate) {
        this.entEndDate = entEndDate;
    }

    public String getExtraMsg() {
        return extraMsg;
    }

    public void setExtraMsg(String extraMsg) {
        this.extraMsg = extraMsg;
    }
}
