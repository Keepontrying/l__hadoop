package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.facade.authen.beans.param.VipMonitorCycleReportQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.VipMonitorReportQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditVipMonitorCycleReport;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import java.util.Date;
import java.util.List;

@Repository
public interface CreditVipMonitorCycleReportDao {

    /**
     * 保存报表数据
     * @param record
     * @return
     */
    int insert(CreditVipMonitorCycleReport record);

    /**
     * 查询vip报表数据
     * @param vipId
     * @param curr
     * @return
     */
    List<CreditVipMonitorCycleReport> selectByVip(@Param("vipId") Integer vipId, @Param("curr") Boolean curr);
    /**
     * 查询vip报表数据
     * @param groupId
     * @param curr
     * @return
     */
    List<CreditVipMonitorCycleReport> selectByVipAndGroup(@Param("vipId") Integer vipId,@Param("groupId") Integer groupId, @Param("curr") Boolean curr);

    /**
     * 按照时间和商户号查询报表数据
     * @param queryParam
     * @return
     */
    List<CreditVipMonitorCycleReport> selectReportList(VipMonitorReportQueryParam queryParam);

    /**
     * 按照vipId更新数据
     * @param record
     * @return
     */
    int updateCurrFlagByVip(CreditVipMonitorCycleReport record);
    /**
     * 按照更新数据
     * @param record
     * @return
     */
    int updateByParam(CreditVipMonitorCycleReport record);
    /**
     * 按照vipId更新数据
     * @param record
     * @return
     */
    int updateCurrFlagByVipAndGroup(CreditVipMonitorCycleReport record);

    /**
     * 删除指定账期指定vip的数据
     * @param vipId
     * @param cycleDate
     * @return
     */
    @Delete({
            "delete from credit_vip_monitor_cycle_report",
            "where vip_id = #{vipId,jdbcType=INTEGER} and group_id = #{groupId,jdbcType=INTEGER} and cycle_date = #{cycleDate,jdbcType=DATE}"
    })
    int deleteByVipAndGroup(@Param("vipId") Integer vipId,@Param("groupId") Integer groupId,@Param("cycleDate") Date cycleDate);
    /**
     * 删除指定账期指定vip的数据
     * @param vipId
     * @param cycleDate
     * @return
     */
    @Delete({
            "delete from credit_vip_monitor_cycle_report",
            "where vip_id = #{vipId,jdbcType=INTEGER} and cycle_date = #{cycleDate,jdbcType=DATE}"
    })
    int deleteByVip(@Param("vipId") Integer vipId,@Param("cycleDate") Date cycleDate);


    /**
     * 按照条件查询report
     * @param queryParam
     * @return
     */
    List<CreditVipMonitorCycleReport> selectCycleReportList(VipMonitorCycleReportQueryParam queryParam);
}