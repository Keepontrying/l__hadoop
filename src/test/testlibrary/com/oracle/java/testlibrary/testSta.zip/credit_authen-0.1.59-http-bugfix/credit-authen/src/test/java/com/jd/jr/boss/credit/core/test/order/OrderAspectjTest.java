package com.jd.jr.boss.credit.core.test.order;

import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;
import com.jd.jr.boss.credit.domain.common.enums.CreditPaymentChannelEnum;
import com.jd.jr.boss.credit.facade.authen.api.CreditOrderFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.SubOrderQueryParam;
import com.jd.jr.boss.credit.facade.site.api.CreditPaymentFacade;
import com.jd.jr.boss.credit.facade.site.api.dto.request.payment.PaymentReceiptPushRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.payment.PaymentReceiptQueryRequest;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.Set;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})

public class OrderAspectjTest {
    @Resource
    private CreditOrderFacade orderFacade;

    @Test
    public void mainTest() {
        SubOrderQueryParam requestParam = new SubOrderQueryParam();
        requestParam.setStart(0);
        requestParam.setLimit(10);
//        requestParam.setChargeType("PACKAGE");
//        requestParam.setOrderMainId(1);
//        requestParam.setOrderId(2);
//        requestParam.setMerchantNo("4");
//        requestParam.setProductId(3);
        requestParam.setCreditType("ENTERPRISE");
        requestParam.setStatus("VALID");
        Page<CreditOrder> pageData = orderFacade.querySubOrder(requestParam);
        System.out.println(GsonUtil.getInstance().toJson(pageData));
    }


}
