package com.jd.jr.boss.credit.authen.core.jms.customs;

import com.google.gson.JsonSyntaxException;
import com.jd.jmq.client.consumer.MessageListener;
import com.jd.jmq.common.message.Message;
import com.jd.jmq.fastjson.JSON;
import com.jd.jr.boss.credit.authen.core.beans.entity.CustomsMqBatchVo;
import com.jd.jr.boss.credit.authen.core.constants.AsyncChargeConstants;
import com.jd.jr.boss.credit.authen.core.enums.CustomsClearStatusErrorEnum;
import com.jd.jr.boss.credit.authen.core.service.CreditChargeService;
import com.jd.jr.boss.credit.authen.core.service.CreditCustomsService;
import com.jd.jr.boss.credit.authen.core.service.CreditQueryBatchService;
import com.jd.jr.boss.credit.authen.core.service.MsgProducerService;
import com.jd.jr.boss.credit.domain.common.entity.CreditCustoms;
import com.jd.jr.boss.credit.domain.common.entity.CreditQueryBatch;
import com.jd.jr.boss.credit.domain.common.enums.CreditChannelInterfaceCodeInsCodeEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditChannelTypeEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditQueryBatchTypeEnum;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.common.utils.SerialNoUtil;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.DoChargeFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.ResultData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.CustomParam;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.response.ResultDataEnum;
import com.jd.jsf.gd.util.StringUtils;
import com.wangyin.boss.credit.admin.entity.InterfaceFlow;
import com.wangyin.boss.credit.admin.enums.EnterpriseProductEnum4Common;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.utils.GsonUtil;
import com.wangyin.rediscluster.client.CacheClusterClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/** 
* @desciption : 海关MQ返回的处理
* @author : yangjinlin@jd.com
* @date ：2017年8月27日 下午3:56:29 
* @version 1.0 
* @return  */
@Component("creditCustomsListener")
public class CreditCustomsListener implements MessageListener {
	
    private static Logger LOGGER = LoggerFactory.getLogger(CreditCustomsListener.class);
    
    private static final String CUSTOMS_RESULT_DATA_CODE_FAIL = "1";//1不成功,为1时message不为空,其他项都不返回
    
    @Resource
    private CreditCustomsService customsService;
    
    @Resource
    private CreditQueryBatchService queryBatchService;

    @Resource
    protected CacheClusterClient cacheClusterClient;
    
    @Autowired
    private DoChargeFacade doChargeFacade;

    @Resource
    private CreditChargeService creditChargeService;

    @Resource
    private MsgProducerService msgProducerService;
    
	private final String CUSTOMS_PROCESS_COUNT_KEY_PREFIX = "BATCH_QUERY_CUSTOMS_PROCESS_COUNT_";
	private final String CUSTOMS_SUCCESS_COUNT_KEY_PREFIX = "BATCH_QUERY_CUSTOMS_SUCCESS_COUNT_";
	private final String CUSTOMS_STATUS_QRYING = "查询中";
	private final String CUSTOMS_STATUS_NO_FUNDS = "余额不足";

    @Override
    public void onMessage(List<Message> messages) throws Exception {
        if (messages == null || messages.isEmpty()) {
        	LOGGER.warn("CreditCustomsListener message is null");
            return;
        }

        for (Message message : messages) {
            String objectJson = message.getText();
            LOGGER.info("======CreditCustomsListener message handle start======, body part:{}",objectJson);
            CustomsMqBatchVo batchMqVo = new CustomsMqBatchVo();
            boolean refundRedisResult = false;
            String balanceKey = null;
            long amount = 1;//批次回量均为1---即次数
            try {
            	batchMqVo = JSON.parseObject(objectJson,CustomsMqBatchVo.class);
            	LOGGER.info("CreditCustomsListener parse object batchMqVo:{}",GsonUtil.getInstance().toJson(batchMqVo));
            } catch (JsonSyntaxException e) {
            	LOGGER.error("message json format error："+objectJson);
                continue;
            }

            try {
            	if(null == batchMqVo){
            		LOGGER.info("format batchMqVo error,batchMqVo:{}", GsonUtil.getInstance().toJson(batchMqVo));
                    continue;
            	}
            	if(CUSTOMS_RESULT_DATA_CODE_FAIL.equalsIgnoreCase(batchMqVo.getCode())){
            		LOGGER.info("CreditCustomsListener return message tells error, message:{}", objectJson);
                    continue;
            	}
            	if(StringUtil.isBlank(batchMqVo.getBatchtoken()) || StringUtil.isBlank(batchMqVo.getTxtCode())){
            		LOGGER.info("batchToken or txtcode is null, batchToken:{}, txtcode:{}", batchMqVo.getBatchtoken(), batchMqVo.getTxtCode());
                    continue;
            	}
				BatchQueryParam queryParam = new BatchQueryParam();
				queryParam.setBatchNoToken(batchMqVo.getBatchtoken());
				CreditQueryBatch queryBatch = queryBatchService.queryBatchNoPage(queryParam);
				if (queryBatch == null) {
					LOGGER.info("CreditCustomsListener can not find batch info, batchtoken:" + batchMqVo.getBatchtoken());
					continue;
				}
                balanceKey = "balance_" + queryBatch.getMerchantNo()+ "_"+EnterpriseProductEnum4Common.ENTERPRISE_CUSTOMS_QUERY.toName();
                refundRedisResult = creditChargeService.refundRedisBanlance(balanceKey, amount);
                LOGGER.info("CreditCustomsListener refundRedisResult :{}", refundRedisResult);
				List<String> resultList = new ArrayList<String>();
				for(CustomsClearStatusErrorEnum clearStatus : CustomsClearStatusErrorEnum.values()){
					if(null == clearStatus.toName() || "NULL".equals(clearStatus.toName())){
						continue;
					}else{
						resultList.add(clearStatus.toDescription());
					}
				}
				CreditCustoms customsUpdate = new CreditCustoms();
            	customsUpdate.setBatchNoToken(batchMqVo.getBatchtoken());
            	customsUpdate.setTxtcode(batchMqVo.getTxtCode());
            	customsUpdate.setQueryType(CreditQueryBatchTypeEnum.CUSTOMS.toName());
            	customsUpdate.setHistoryLinks(batchMqVo.getHistory());
            	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date crawlerDate = sdf.parse(batchMqVo.getCrawlerDate());
            	customsUpdate.setCrawlerDate(crawlerDate);
            	customsUpdate.setModifiedDate(new Date());
            	customsUpdate.setModifier("SYSTEM");
                CreditRequestParam<CustomParam> requestParam4Charge = new CreditRequestParam<CustomParam>();
                CustomParam customPrm = new CustomParam();
                customPrm.setTxtCode(batchMqVo.getTxtCode());
                String tradeNo = SerialNoUtil.createSerialNo("CECSTM");

            	if(!CUSTOMS_STATUS_QRYING.equalsIgnoreCase(batchMqVo.getResult()) && !CUSTOMS_STATUS_NO_FUNDS.equalsIgnoreCase(batchMqVo.getResult()) ){    //有终态
            		customsUpdate.setClearStatus(StringUtils.isEmpty(batchMqVo.getResult()) ? CUSTOMS_STATUS_QRYING : batchMqVo.getResult());
            		Long progressCount = cacheClusterClient.incr(CUSTOMS_PROCESS_COUNT_KEY_PREFIX+queryBatch.getId());
                    if(progressCount.equals(1L)){
                        cacheClusterClient.expire(CUSTOMS_PROCESS_COUNT_KEY_PREFIX+queryBatch.getId(),24*3600);
                    }
                    if(null == queryBatch.getProgress() ){
                    queryBatch.setProgress(BigDecimal.valueOf(progressCount).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(queryBatch.getBatchCount()), 2, BigDecimal.ROUND_HALF_UP ));
                    }else if(null != queryBatch.getProgress() && queryBatch.getProgress().compareTo(new BigDecimal("100.00")) <= 0 ){
                    	queryBatch.setProgress(BigDecimal.valueOf(progressCount).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(queryBatch.getBatchCount()), 2, BigDecimal.ROUND_HALF_UP ));
                    }
                    if(!resultList.contains(batchMqVo.getResult())){//错误信息不包含在内则默认为清关终态
                    	Long successCount = cacheClusterClient.incr(CUSTOMS_SUCCESS_COUNT_KEY_PREFIX+queryBatch.getId());
                        if(successCount.equals(1L)){
                            cacheClusterClient.expire(CUSTOMS_SUCCESS_COUNT_KEY_PREFIX+queryBatch.getId(),24*3600);
                        }
                        if(null == queryBatch.getSuccessRate()){
                        queryBatch.setSuccessRate(BigDecimal.valueOf(successCount).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(queryBatch.getBatchCount()), 2, BigDecimal.ROUND_HALF_UP ));
                        }else if(null != queryBatch.getSuccessRate() && queryBatch.getSuccessRate().compareTo(new BigDecimal("100.00")) <= 0 ){
                        	queryBatch.setSuccessRate(BigDecimal.valueOf(successCount).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(queryBatch.getBatchCount()), 2, BigDecimal.ROUND_HALF_UP ));
                    }
            	}
                    if(StringUtils.isNotBlank(batchMqVo.getCode()) && "0".equalsIgnoreCase(batchMqVo.getCode())){//爬取成功
                        //有终态时才扣除费用，否则不扣除
                        customPrm.setDoCharge(true);
                        customPrm.setCode(batchMqVo.getResult());
                        requestParam4Charge.setParam(customPrm);
                        requestParam4Charge.setSystemId(batchMqVo.getSystemId());//systemId  待数据部发出的海关mq改造完毕后给出
                        requestParam4Charge.setTradeNo(tradeNo);
                        LOGGER.info("creditCustomsListener-doChargeFacade.payCustom requestParam: {}", GsonUtil.getInstance().toJson(requestParam4Charge));
                        CreditResponseData<ResultData<CustomParam, String>> chargeResp = doChargeFacade.payCustom(requestParam4Charge);
                        LOGGER.info("creditCustomsListener-doChargeFacade.payCustom requestParam responseData: {}", GsonUtil.getInstance().toJson(chargeResp));
                        if(null != chargeResp ){
                            tradeNo = chargeResp.getTradeNo();
            	}
                        if(null != chargeResp && chargeResp.isSuccess()){
                        }else{
                            LOGGER.info("creditCustomsListener-doChargeFacade.payCustom failed, cant update status to success end.");
                            if(ResultDataEnum.RESULT_BALANCE_LACK.toName().equals(chargeResp.getCode())||ResultDataEnum.RESULT_SERVICE_NOSTRATEGY.toName().equals(chargeResp.getCode())){
                                customsUpdate.setClearStatus(AsyncChargeConstants.ASYNC_CHARGE_RESPONSE_MESSAGE_NO_FUNDS);
                            }else {
                                customsUpdate.setClearStatus(AsyncChargeConstants.ASYNC_CHARGE_RESPONSE_MESSAGE_FAIL_FUNDS);
                            }
                        }
                    }else{//爬取不成功
                        //非终态时仅产生业务流水
                        customPrm.setDoCharge(true);
                        customPrm.setCode(batchMqVo.getResult());
                        requestParam4Charge.setParam(customPrm);
                        requestParam4Charge.setSystemId(batchMqVo.getSystemId());//systemId  待数据部发出的海关mq改造完毕后给出
                        requestParam4Charge.setTradeNo(tradeNo);
                        LOGGER.info("creditCustomsListener-doChargeFacade.payCustom requestParam: {}", GsonUtil.getInstance().toJson(requestParam4Charge));
                        CreditResponseData<ResultData<CustomParam, String>> chargeResp = doChargeFacade.payCustom(requestParam4Charge);
                        if(null != chargeResp ){
                            tradeNo = chargeResp.getTradeNo();
                        }
                    }
            	}else{
                    customsUpdate.setClearStatus(CUSTOMS_STATUS_QRYING);
                }

                try {
                    InterfaceFlow interfaceFlow = new InterfaceFlow();
                    interfaceFlow.setInsCode(CreditChannelInterfaceCodeInsCodeEnum.customsQuerySingle.getInsCode());//
                    interfaceFlow.setInterfaceCode(CreditChannelInterfaceCodeInsCodeEnum.customsQuerySingle.getInterfaceCode());//
                    interfaceFlow.setTradeNo(tradeNo);
                    Date date = new Date();
                    interfaceFlow.setRequestTime(date);
                    interfaceFlow.setResponseTime(date);
                    interfaceFlow.setReturnCode(batchMqVo.getCode());
                    interfaceFlow.setReturnStatus(org.apache.commons.lang3.StringUtils.isNotBlank(batchMqVo.getCode())&&("0".equals(batchMqVo.getCode())) ? "true" : "false");
                    String requestParamStr = GsonUtil.getInstance().toJson(customPrm);
                    interfaceFlow.setRequestParam(requestParamStr);
                    interfaceFlow.setReturnMsg(null);
                    interfaceFlow.setResponseParam(objectJson);
                    interfaceFlow.setChannel(CreditChannelTypeEnum.DATA_DEPARTMENT + "");
                    interfaceFlow.setFromCache(false);
                    msgProducerService.sendChannelLogFmqMsg(interfaceFlow);
                    LOGGER.info("CreditCustomsListener sendChannelLogFmqMsg success, mq: {}", GsonUtil.getInstance().toJson(interfaceFlow));
                } catch (Exception e) {
                    LOGGER.error("CreditCustomsListener sendChannelLogFmqMsg error, {}", e);
                }

            	Integer updateCount = customsService.updateCustomsandBatchInfo(customsUpdate);
            	queryBatch.setModifier("SYSTEM");
            	queryBatch.setModifiedDate(new Date());
            	queryBatchService.updateQueryBatch(queryBatch);
            	LOGGER.info("======CreditCustomsListener message handle end======");
            } catch (Exception e) {
            	LOGGER.error("CreditCustomsListener handle error,{}", e);
            	continue;
            }finally {
                if(!refundRedisResult){//上方退还预扣失败，则再次尝试回量预扣款
                    refundRedisResult = creditChargeService.refundRedisBanlance(balanceKey, amount);
            }
        }
    }
    }
    
}
