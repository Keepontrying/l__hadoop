package com.jd.jr.boss.credit.core.test.Diligence;

import com.jd.jr.boss.credit.domain.common.entity.CreditCustoms;
import com.jd.jr.boss.credit.facade.authen.api.CreditDiligenceFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditQueryBatchFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.CustomsQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.DueStatusParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.PayMerchantCheckDuplicateParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.PayMerchantCheckResponse;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.SampleFinishEntity;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import javax.annotation.Resource;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})

public class DiligenceTest {
    @Resource
    private CreditDiligenceFacade creditDiligenceFacade;

    @Test
    public void doPaySampleStatusTest() {
        CreditRequestParam<DueStatusParam> requestParam = new CreditRequestParam<DueStatusParam>();
        DueStatusParam param = new DueStatusParam();
        param.setProjectId("12340faf-b4a0-43e7-9ea3-aa14985c8071");
        param.setSampleId("1805213490700002");
        param.setStatus("FINISH");
        requestParam.setParam(param);
        CreditResponseData<String> pageData = creditDiligenceFacade.doPaySampleStatus(requestParam);
        System.out.println("-----------"+GsonUtil.getInstance().toJson(pageData));
    }

    @Test
    public void doPayMerchantCheckTest() {
        CreditRequestParam<PayMerchantCheckDuplicateParam> requestParam = new CreditRequestParam<PayMerchantCheckDuplicateParam>();
        PayMerchantCheckDuplicateParam param = new PayMerchantCheckDuplicateParam();
        param.setStoreName("龙记香港茶餐厅");
        param.setStoreAddress("上海市长宁区天山路317号");
        requestParam.setParam(param);
        CreditResponseData<PayMerchantCheckResponse> pageData = creditDiligenceFacade.doPayMerchantCheck(requestParam);
        System.out.println("-----------"+GsonUtil.getInstance().toJson(pageData));
    }

    @Test
    public void mainTest1() {
        CreditRequestParam<SampleFinishEntity> param = new CreditRequestParam<SampleFinishEntity>();
        SampleFinishEntity queryParam=new SampleFinishEntity();
        queryParam.setSampleId("LJ062E7F725D9523DE70");
        queryParam.setSftpDir("/upload/mini/shuzhe/LJ062E7F725D9523DE70");
        queryParam.setSyncFinishTime("2018-01-29");
        param.setParam(queryParam);
        CreditResponseData<String> pageData = creditDiligenceFacade.doSimpleFinish(param);
        System.out.println("-----------"+GsonUtil.getInstance().toJson(pageData));
    }


}
