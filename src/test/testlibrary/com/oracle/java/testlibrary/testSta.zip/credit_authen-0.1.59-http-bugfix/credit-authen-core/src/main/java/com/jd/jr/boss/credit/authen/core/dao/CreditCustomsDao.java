package com.jd.jr.boss.credit.authen.core.dao;

import java.util.List;

import com.jd.jr.boss.credit.domain.common.entity.CreditCustomsBatch;
import org.springframework.stereotype.Repository;

import com.jd.jr.boss.credit.domain.common.entity.CreditCustoms;
import com.jd.jr.boss.credit.facade.authen.beans.param.CustomsQueryParam;

/** 
* @desciption : 海关dao数据接口类
* @author : yangjinlin@jd.com
* @date ：2017年7月21日 下午5:30:23 
* @version 1.0 
* @return  */
@Repository
public interface CreditCustomsDao {


	/**
	 * 多条件查询报关单号
	 * @param customsQryPrm
	 * @return
	 */
    List<CreditCustoms> queryCustomsByPrm(CustomsQueryParam customsQryPrm);
	/**
	 * 查询报关单号 不分页
	 * @param customsQryPrm
	 * @return
	 */
    List<CreditCustoms> queryCustoms(CustomsQueryParam customsQryPrm);
	/**
	 * 统计多条件查询报关单号 count
	 * @param customsQryPrm
	 * @return
	 */
    Integer queryCustomsByPrmCount(CustomsQueryParam customsQryPrm);

	/**
	 * 多条件更新报关单号信息
	 * @param creditCustoms
	 * @return
	 */
    Integer updateCustomsandBatchInfo(CreditCustoms creditCustoms);
	/**
	 * 新增报关批次信息
	 * @param customsBatch
	 * @return
	 */
    Integer addCustomsBatch(CreditCustomsBatch customsBatch);
	/**
	 * 批量插入报关单号信息
	 * @param custmosList
	 */
    void addBatchCustoms(List<CreditCustoms> custmosList);

}
