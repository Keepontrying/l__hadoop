package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.facade.authen.beans.entity.CreditProductAuthenEntity;
import org.springframework.stereotype.Repository;

/**
 * 类描述：
 *
 * @author liangyuwu
 * @Time 2018/6/6 14:58
 */
@Repository
public interface CreditProductAuthenHistoryDao {
    int insert(CreditProductAuthenEntity entity);
}
