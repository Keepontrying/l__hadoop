package com.jd.jr.boss.credit.authen.core.exception;

/**
 * @author huangzhiqiang
 * @data 2017/9/12
 */
public class CreditSignCodeException extends BaseException{

    public CreditSignCodeException(String message){
        super(message);
    }
}
