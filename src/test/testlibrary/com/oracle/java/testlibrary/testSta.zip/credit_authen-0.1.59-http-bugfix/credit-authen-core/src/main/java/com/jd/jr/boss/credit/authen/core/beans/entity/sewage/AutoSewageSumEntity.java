package com.jd.jr.boss.credit.authen.core.beans.entity.sewage;

import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.basic.AlterRecordEntity;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.basic.BranchRecordEntity;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.basic.MainStaffEntity;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.basic.ShareHolderEntity;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.negative.AbnormalEntity;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.negative.PunishmentEntity;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.*;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.court.EntCourtNoticeData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.court.EntOpenCourtData;
import com.wangyin.boss.credit.admin.enums.CreditRiskWarnLevelEnum;

import java.io.Serializable;
import java.util.List;

/**
 * 排污总结果
 */
public class AutoSewageSumEntity extends AutoSewageEntity implements Serializable {

	private static final long serialVersionUID = 3429631328937230643L;
	/**
	 * 查询入参
	 */
	private String queryString;
	/**
	 * 企业分支机构信息
	 */
	private List<BranchRecordEntity> branchRecordList;
	/**
	 * 企业历史变更信息
	 */
	private List<AlterRecordEntity> alterRecordList;
	/**
	 * 企业股东及出资信息
	 */
	private List<ShareHolderEntity> shareHolderList;
	/**
	 * 主要人员
	 */
	private List<MainStaffEntity> mainStaffList;
	/**
	 * 对外投资
	 */
	private List<EntInvQueryData> invList;
	/**
	 * 动产抵押
	 */
	private List<MortgageInfoData> mortgageList;
	/**
	 * 股权出质登记
	 */
	private List<EquityInfoData> equityList;
	/**
	 * 抽查检查
	 */
	private List<CheckInfoData> checkInfoList;
	/**
	 * 行政处罚
	 */
	private List<PunishmentEntity> punishmentEntities;
	/**
	 * 列入经营异常名录
	 */
	private List<AbnormalEntity> abnormalEntities;
	/**
	 * 严重违法信息
	 */
	private List<IllegalInfoData> illegalList;
	/**
	 * 失信被执行人
	 */
	private List<PunishBreakQueryData> punishBreakList;
	/**
	 * 法院裁判
	 */
	private List<EntLawsuitInfoData> entLawsuitList;
	/**
	 * 被执行人信息
	 */
	private List<PunishedQueryData> punishedList;
	/**
	 * 开庭公告
	 */
	private List<EntOpenCourtData> openCourtList;
	/**
	 * 法院公告
	 */
	private List<EntCourtNoticeData> courtNoticeList;

    /**
     * 内外部标识
     */
    private String entInnerFlag;
    /**
     * 风险等级
     */
    private String riskLevel = CreditRiskWarnLevelEnum.NO_RISK.toDescription();
	/**
	 * 小分组
	 */
	private String relationGroup;
	/**
	 * 大分组
	 */
	private String group;
	public String getQueryString() {
		return queryString;
	}

	public void setQueryString(String queryString) {
		this.queryString = queryString;
	}

	public List<BranchRecordEntity> getBranchRecordList() {
		return branchRecordList;
	}

	public void setBranchRecordList(List<BranchRecordEntity> branchRecordList) {
		this.branchRecordList = branchRecordList;
	}

	public List<AlterRecordEntity> getAlterRecordList() {
		return alterRecordList;
	}

	public void setAlterRecordList(List<AlterRecordEntity> alterRecordList) {
		this.alterRecordList = alterRecordList;
	}

	public List<ShareHolderEntity> getShareHolderList() {
		return shareHolderList;
	}

	public void setShareHolderList(List<ShareHolderEntity> shareHolderList) {
		this.shareHolderList = shareHolderList;
	}

	public List<MainStaffEntity> getMainStaffList() {
		return mainStaffList;
	}

	public void setMainStaffList(List<MainStaffEntity> mainStaffList) {
		this.mainStaffList = mainStaffList;
	}

	public List<EntInvQueryData> getInvList() {
		return invList;
	}

	public void setInvList(List<EntInvQueryData> invList) {
		this.invList = invList;
	}

	public List<MortgageInfoData> getMortgageList() {
		return mortgageList;
	}

	public void setMortgageList(List<MortgageInfoData> mortgageList) {
		this.mortgageList = mortgageList;
	}

	public List<EquityInfoData> getEquityList() {
		return equityList;
	}

	public void setEquityList(List<EquityInfoData> equityList) {
		this.equityList = equityList;
	}

	public List<CheckInfoData> getCheckInfoList() {
		return checkInfoList;
	}

	public void setCheckInfoList(List<CheckInfoData> checkInfoList) {
		this.checkInfoList = checkInfoList;
	}

	public List<PunishmentEntity> getPunishmentEntities() {
		return punishmentEntities;
	}

	public void setPunishmentEntities(List<PunishmentEntity> punishmentEntities) {
		this.punishmentEntities = punishmentEntities;
	}

	public List<AbnormalEntity> getAbnormalEntities() {
		return abnormalEntities;
	}

	public void setAbnormalEntities(List<AbnormalEntity> abnormalEntities) {
		this.abnormalEntities = abnormalEntities;
	}

	public List<IllegalInfoData> getIllegalList() {
		return illegalList;
	}

	public void setIllegalList(List<IllegalInfoData> illegalList) {
		this.illegalList = illegalList;
	}

	public List<PunishBreakQueryData> getPunishBreakList() {
		return punishBreakList;
	}

	public void setPunishBreakList(List<PunishBreakQueryData> punishBreakList) {
		this.punishBreakList = punishBreakList;
	}

	public List<EntLawsuitInfoData> getEntLawsuitList() {
		return entLawsuitList;
	}

	public void setEntLawsuitList(List<EntLawsuitInfoData> entLawsuitList) {
		this.entLawsuitList = entLawsuitList;
	}

	public List<PunishedQueryData> getPunishedList() {
		return punishedList;
	}

	public void setPunishedList(List<PunishedQueryData> punishedList) {
		this.punishedList = punishedList;
	}

	public List<EntOpenCourtData> getOpenCourtList() {
		return openCourtList;
	}

	public void setOpenCourtList(List<EntOpenCourtData> openCourtList) {
		this.openCourtList = openCourtList;
	}

	public List<EntCourtNoticeData> getCourtNoticeList() {
		return courtNoticeList;
	}

	public void setCourtNoticeList(List<EntCourtNoticeData> courtNoticeList) {
		this.courtNoticeList = courtNoticeList;
	}

    public String getEntInnerFlag() {
        return entInnerFlag;
    }

    public void setEntInnerFlag(String entInnerFlag) {
        this.entInnerFlag = entInnerFlag;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

	public String getRelationGroup() {
		return relationGroup;
	}

	public void setRelationGroup(String relationGroup) {
		this.relationGroup = relationGroup;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}
}
