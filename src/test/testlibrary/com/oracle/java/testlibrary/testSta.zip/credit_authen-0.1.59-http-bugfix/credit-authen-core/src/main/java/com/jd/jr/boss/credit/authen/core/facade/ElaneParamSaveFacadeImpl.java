package com.jd.jr.boss.credit.authen.core.facade;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.jd.jr.boss.credit.authen.core.beans.entity.CreditElaneParam;
import com.jd.jr.boss.credit.authen.core.service.ElaneParamSaveService;
import com.jd.jr.boss.credit.facade.authen.api.ElaneParamSaveFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.ElaneParam;
import com.jd.jr.boss.credit.facade.authen.enums.ElaneDataEnum;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.ShippingCodeEnum;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.utils.GsonUtil;

@Component
public class ElaneParamSaveFacadeImpl implements  ElaneParamSaveFacade {

	@Resource
	private ElaneParamSaveService  elaneParamSaveService;
	
	private static final Logger log = LoggerFactory.getLogger(ElaneParamSaveFacadeImpl.class);
	
	@Override
	public CreditResponseData<String> saveParam(CreditRequestParam<ElaneParam> reqParam) {
		log.info("保存参数信息开始"+GsonUtil.getInstance().toJson(reqParam));
		CreditResponseData<String> response = new CreditResponseData<String>();
		try {
				ElaneParam param = reqParam.getParam();
				CreditElaneParam creditElaneParam = new CreditElaneParam();
				creditElaneParam.setBl(param.getBl());
				creditElaneParam.setCarrierCode(param.getCarrierCode());
				creditElaneParam.setContainerNumber(param.getContainerNumber());
				creditElaneParam.setDataType(param.getDataType());
				creditElaneParam.setStatus(ElaneDataEnum.INIT);
				creditElaneParam.setQuerytype(param.getQueryType());
				creditElaneParam.setVslname(param.getVslName());
				creditElaneParam.setVoycode(param.getVoyCode());
				CreditResponseData<Integer> result = elaneParamSaveService.saveParam(creditElaneParam);
				if("DUP".equals(result.getCode())) {
					response.setCode(ShippingCodeEnum.DUPLICATION.name());
					return response;
				}else if(1 == result.getData()){
					response.setCode(ShippingCodeEnum.PRE_FEE.name());
					return response;
				}
			response.setSuccess(true);
		}catch(Exception e) {
			log.error("保存有异常",e);
			response.setSuccess(false);
			response.setCode("ERROR");
		}
		return response;
	}

}
