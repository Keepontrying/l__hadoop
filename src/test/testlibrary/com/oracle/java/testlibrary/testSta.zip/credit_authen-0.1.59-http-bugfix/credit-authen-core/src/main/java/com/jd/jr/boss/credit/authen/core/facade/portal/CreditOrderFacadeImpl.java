package com.jd.jr.boss.credit.authen.core.facade.portal;

import com.jd.jr.boss.credit.authen.core.beans.request.OrderMainQueryParam;
import com.jd.jr.boss.credit.authen.core.service.OrderService;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrderMain;
import com.jd.jr.boss.credit.facade.authen.api.CreditOrderFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.MainOrderQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.OrderRemainQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.SubOrderQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.CreditOrderRemain;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * Created by anmeng on 2017/3/22.
 */
@Service("creditOrderFacade")
public class CreditOrderFacadeImpl implements CreditOrderFacade {

    private static Logger logger = LoggerFactory.getLogger(CreditOrderFacadeImpl.class);

    @Resource
    private OrderService orderService;

    /**
     * 查询主订单信息
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditPage<CreditOrderMain> queryOrderMain(MainOrderQueryParam requestParam) {
        CreditPage<CreditOrderMain> result = orderService.queryOrderMainList(new OrderMainQueryParam(requestParam));
        return result;
    }

    /**
     * 查询单个订单详情
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<CreditOrderMain> queryMainOrderDetail(CreditRequestParam<CreditOrderMain> requestParam) {
        CreditResponseData<CreditOrderMain> responseData = new CreditResponseData<CreditOrderMain>();
        CreditOrderMain orderMain = requestParam.getParam();
        OrderMainQueryParam queryParam=new OrderMainQueryParam();
        queryParam.setMerchantNo(orderMain.getMerchantNo());
        queryParam.setOrderMainId(orderMain.getOrderMainId());
        orderMain = orderService.queryOrderMainDetail(queryParam);
        responseData.setData(orderMain);
        return responseData;
    }

    /**
     * 创建订单
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<CreditOrderMain> createOrder(CreditRequestParam<CreditOrderMain> requestParam) {
        CreditResponseData<CreditOrderMain> responseData = new CreditResponseData<CreditOrderMain>();
        try {
            CreditOrderMain orderMain = requestParam.getParam();
            orderService.createMainOrder(orderMain);
            responseData.setData(orderMain);
        } catch (Exception e) {
            logger.error(e);
            throw new RuntimeException("创建订单失败！");
        }
        return responseData;
    }

    /**
     * 线下打款确认
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<CreditOrderMain> offLinePayConfirm(CreditRequestParam<CreditOrderMain> requestParam) {
        CreditResponseData<CreditOrderMain> responseData = new CreditResponseData<CreditOrderMain>();
        CreditOrderMain orderParam = requestParam.getParam();
        orderParam.setPaymentTime(new Date());
        orderService.confirmReceivePay(orderParam);
        return responseData;
    }

    /**
     * 线上页面确认线下订单
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<CreditOrderMain> confirmOffLineOrder(CreditRequestParam<CreditOrderMain> requestParam) {
        CreditResponseData<CreditOrderMain> responseData = new CreditResponseData<CreditOrderMain>();
        CreditOrderMain orderMain = requestParam.getParam();
        orderMain.setModifier(requestParam.getOperator());
        orderMain=orderService.confirmOffLineOrder(orderMain);
        responseData.setData(orderMain);
        return responseData;
    }

    /**
     * 查询商户订单信息
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditPage<CreditOrder> querySubOrder(SubOrderQueryParam requestParam) {
        return orderService.queryOrderList(requestParam);
    }

    @Override
    public CreditResponseData<CreditOrderMain> cancelOrder(CreditRequestParam<CreditOrderMain> requestParam) {
        CreditResponseData<CreditOrderMain> responseData = new CreditResponseData<CreditOrderMain>();
        try {
            CreditOrderMain orderParam = requestParam.getParam();
            OrderMainQueryParam queryParam=new OrderMainQueryParam();
            queryParam.setOrderMainId(orderParam.getOrderMainId());
            queryParam.setMerchantNo(orderParam.getMerchantNo());
            orderParam = orderService.cancelMainOrder(queryParam);
            responseData.setData(orderParam);
        } catch (Exception e) {
            logger.error(e.getMessage());
            responseData.setResponseMessage(ResponseMessage.BUSINESS_EXCEPTION);
            responseData.setMessage(e.getMessage());
        }
        return responseData;
    }

    /**
     * 查询订单余量
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditPage<CreditOrderRemain> queryOrderRemained(OrderRemainQueryParam requestParam) {
        SubOrderQueryParam queryParam = new SubOrderQueryParam();
        queryParam.setMerchantNo(requestParam.getMerchantNo());
        queryParam.setStatus(requestParam.getOrderStatus());
        queryParam.setStart(requestParam.getStart());
        queryParam.setLimit(requestParam.getLimit());
        return orderService.queryOrderRemainList(queryParam);
    }

    /**
     * 创建后付费订单
     * 根据合同ID
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData createPostOrder(CreditRequestParam<CreditContract> requestParam) {
        CreditResponseData responseData=new CreditResponseData();
        CreditContract contract=requestParam.getParam();
        orderService.createPostOrder(contract.getContractId(),null);
        return responseData;
    }

	@Override
	public List<CreditOrder> queryContractOrder(SubOrderQueryParam orderQueryParam) {
		return orderService.queryContractOrder(orderQueryParam);
	}

	@Override
	public List<CreditContract> queryContractByOrderInfo(SubOrderQueryParam requestParam) {
		return orderService.queryContractByOrderInfo(requestParam);
	}

}
