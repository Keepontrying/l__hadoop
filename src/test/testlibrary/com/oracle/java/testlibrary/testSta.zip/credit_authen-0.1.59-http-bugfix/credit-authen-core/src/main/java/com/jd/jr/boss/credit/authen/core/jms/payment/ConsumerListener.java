package com.jd.jr.boss.credit.authen.core.jms.payment;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.JsonSyntaxException;
import com.jd.jmq.client.consumer.MessageListener;
import com.jd.jmq.common.message.Message;
import com.jd.jmq.fastjson.JSON;
import com.jd.jr.boss.credit.authen.core.biz.AccountManageBiz;
import com.jd.jr.boss.credit.authen.core.service.PaymentService;
import com.jd.jr.boss.credit.domain.common.constants.PaymentOrderConstants;
import com.jd.jr.boss.credit.domain.common.entity.CreditPayment;
import com.jd.jr.boss.credit.domain.common.enums.CreditPaymentChannelEnum;
import com.jd.jr.boss.credit.domain.common.enums.PaymentStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.ProductChargeTypeEnum;
import com.wangyin.boss.payment.common.entity.PaymentNotice;
import com.wangyin.boss.payment.common.enums.PaymentResultEnum;
import com.wangyin.commons.util.Logger;
import com.wangyin.operation.utils.GsonUtil;
import com.wangyin.rediscluster.client.CacheClusterClient;

@Component("paymentConsumerListener")
public class ConsumerListener implements MessageListener {
    private Logger logger = new Logger(ConsumerListener.class);
    @Autowired
    protected CacheClusterClient cacheClusterClient;
    @Autowired
    private AccountManageBiz accountManageBiz;

    @Autowired
    private PaymentService paymentService;

    @Override
    public void onMessage(List<Message> messages) throws Exception  {
        long startTime = System.currentTimeMillis();
        if (messages == null || messages.isEmpty()) {
        	logger.warn("paymentConsumerListener message is null");
            return;
        }
        for(Message message : messages){
        	String objectJson = message.getText();
        	logger.info("paymentConsumerListener message, body part:{}",objectJson);
        	PaymentNotice paymentNotice = new PaymentNotice();
        	try {
        		paymentNotice = JSON.parseObject(objectJson,PaymentNotice.class);
        		logger.info("paymentConsumerListener parse object paymentNotice:{}",GsonUtil.getInstance().toJson(paymentNotice));
            } catch (JsonSyntaxException e) {
            	logger.error("message json format error："+objectJson);
                continue;
            }
        	try {
                if (paymentNotice != null && PaymentOrderConstants.PARAM_OUTPUT_SYSTEMID.equalsIgnoreCase(paymentNotice.getSystemId())) {
                    //缴费结果成功
                    if (PaymentResultEnum.SUCCESS.name().equalsIgnoreCase(paymentNotice.getPaymentResult())) {
                        String paymentResultCache = cacheClusterClient.get(paymentNotice.getPaymentId());

                        if (StringUtils.isBlank(paymentResultCache)) {

                            String requestCode = paymentNotice.getRequestCode();
                            String merchantNo = paymentNotice.getMerchantNo();
                            CreditPayment paymentRecord=paymentService.decodeRequestCode(requestCode);
                            paymentRecord.setMerchantNo(merchantNo);
                            CreditPaymentChannelEnum paymentChannel=paymentRecord.getPayChannel();
                            BigDecimal amount = paymentNotice.getAmount();
                            String outPayId = paymentNotice.getPaymentId();
                            Date finishTime = paymentNotice.getFinishTime();
                            //单笔缴费
                            if (CreditPaymentChannelEnum.SINGLE.equals(paymentChannel)
                                    || CreditPaymentChannelEnum.SINGLE_MANUAL.equals(paymentChannel)) {
                                //充值
                                this.dealSinglePaymentCallBack(merchantNo, amount);
                            } else if (CreditPaymentChannelEnum.PACKAGE.equals(paymentChannel)) {
                                //包量缴费,缴费单请求Id为合同ID，依据合同ID查询包量产品
                                //缴费单请求Id不为空
                                if (StringUtils.isBlank(paymentNotice.getRequestCode())) {
                                    //缴费单请求Id为空
                                    logger.error("paymentonMessage 缴费单请求Id为空:" + GsonUtil.getInstance().toJson(paymentNotice));
                                    throw new Exception("缴费单请求Id为空");
                                }
                                Integer contractId = Integer.parseInt(paymentRecord.getContractId());
                                accountManageBiz.updatePackageCharge(contractId, finishTime);
                            } else if (CreditPaymentChannelEnum.PACKAGE_MANUAL.equals(paymentChannel)) {
                                //后台触发包量缴费,缴费单请求Id为订购ID
                                if (StringUtils.isBlank(paymentNotice.getRequestCode())) {
                                    //缴费单请求Id为空
                                    logger.error("paymentonMessage 缴费单请求Id为空:" + GsonUtil.getInstance().toJson(paymentNotice));
                                    throw new Exception("缴费单请求Id为空");
                                }
                                Integer orderId = Integer.parseInt(paymentRecord.getOrderId());
                                accountManageBiz.updateOnePackageCharge(orderId, finishTime);
                            }
                            cacheClusterClient.set(paymentNotice.getPaymentId(), GsonUtil.getInstance().toJson(paymentNotice));

                            //保存缴费记录
                            if (CreditPaymentChannelEnum.SINGLE.equals(paymentChannel)) {
                                this.createSinglePaymentRecord(paymentRecord, outPayId, finishTime, amount);
                            } else {
                                this.updatePaymentStatus(paymentRecord, outPayId, paymentChannel, finishTime);
                            }
                        }else{
                            throw new Exception("重复缴费单号"+paymentResultCache);
                        }
                    } else {
                        //缴费失败
                        logger.error("paymentonMessage 缴费失败:" + GsonUtil.getInstance().toJson(paymentNotice));
                        throw new Exception("缴费失败");
                    }
                    logger.info("paymentonMessage 缴费通知处理完成：" + (System.currentTimeMillis() - startTime) + "ms " + GsonUtil.getInstance().toJson(paymentNotice));

                }
            } catch (Exception e) {
                logger.error("paymentonMessage 缴费异常:" + e.getMessage());
            }
        }
        
    }

    /**
     * 处理单笔缴费的充值
     *
     * @param merchantNo
     * @param amount
     * @throws Exception
     */
    private void dealSinglePaymentCallBack(String merchantNo, BigDecimal amount) throws Exception {
        //单笔缴费,依据商户号对账户进行充值
        if (StringUtils.isBlank(merchantNo)) {
            logger.error("paymentonMessage 商户不存在:", merchantNo);
            throw new RuntimeException("商户不存在");
        }

        if (amount == null) {
            logger.error("paymentonMessage 充值金额不存在:", amount);
            throw new RuntimeException("充值金额不存在");
        }
        Long amountLong = amount.longValue();
        accountManageBiz.updateSingleCharge(merchantNo, amountLong);
    }

    private void createSinglePaymentRecord(CreditPayment creditPayment, String payId, Date finishTime, BigDecimal amount) {
        //保存缴费记录
        creditPayment.setOutPayId(payId);
        creditPayment.setAmount(amount);
        creditPayment.setPayTime(finishTime);
        creditPayment.setPayStatus(PaymentStatusEnum.PAYED.getCode());
        creditPayment.setStrategyChargeType(ProductChargeTypeEnum.SINGLE);
        paymentService.createPaymentRecord(creditPayment);
    }

    /**
     * 更新缴费单状态
     *
     * @param payId
     * @param paymentChannel
     * @param finishTime
     */
    private void updatePaymentStatus(CreditPayment creditPayment, String payId, CreditPaymentChannelEnum paymentChannel, Date finishTime) {
        //保存缴费记录
        creditPayment.setOutPayId(payId);
        creditPayment.setPayChannel(paymentChannel);
        creditPayment.setPayTime(finishTime);
        creditPayment.setPayStatus(PaymentStatusEnum.PAYED.getCode());
        paymentService.updatePaymentStatus(creditPayment);
    }

}
