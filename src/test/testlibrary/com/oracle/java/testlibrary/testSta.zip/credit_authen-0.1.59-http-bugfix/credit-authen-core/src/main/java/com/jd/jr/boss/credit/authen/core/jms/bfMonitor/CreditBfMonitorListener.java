package com.jd.jr.boss.credit.authen.core.jms.bfMonitor;

import com.google.gson.JsonSyntaxException;
import com.jd.fastjson.JSONArray;
import com.jd.jmq.client.consumer.MessageListener;
import com.jd.jmq.common.message.Message;
import com.jd.jr.boss.credit.authen.core.beans.entity.VipResultEntity;
import com.jd.jr.boss.credit.authen.core.beans.entity.mongo.MongoRiskWarnTaskProductResult;
import com.jd.jr.boss.credit.authen.core.constants.SystemConstants;
import com.jd.jr.boss.credit.authen.core.exception.CreditVipDbException;
import com.jd.jr.boss.credit.authen.core.service.CreditUserService;
import com.jd.jr.boss.credit.authen.core.service.MongoService;
import com.jd.jr.boss.credit.authen.core.service.VipService;
import com.jd.jr.boss.credit.authen.core.service.VipTaskExecuteService;
import com.jd.jr.boss.credit.domain.common.enums.OpenOrCloseStatusEnum;
import com.jd.jr.boss.credit.facade.authen.beans.param.VipTaskDtoQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.VipTaskProductsQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.antiMoneyLaunder.chinaData.ChinaDataAntiMoneyLaunderResp;
import com.jd.jr.boss.credit.gateway.unc.utils.FlowNoUtils;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.boss.credit.admin.entity.CreditVipTask;
import com.wangyin.boss.credit.admin.entity.CreditVipTaskProduct;
import com.wangyin.boss.credit.admin.entity.CreditVipTaskProductResult;
import com.wangyin.boss.credit.admin.enums.*;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption : 最终受益人变更的消息
 * @date ：2019/1/22 11:17
 * @return
 */
@Service("creditBfMonitorListener")
public class CreditBfMonitorListener implements MessageListener {
    private static Logger LOGGER = LoggerFactory.getLogger(CreditBfMonitorListener.class);

    @Autowired
    private VipService vipService;
    @Autowired
    private VipTaskExecuteService vipTaskExecuteService;
    @Autowired
    private MongoService mongoService;
    @Autowired
    CreditUserService userService;

    @Override
    public void onMessage(List<Message> list) throws Exception {
        if (CollectionUtils.isEmpty(list)) {
            LOGGER.warn("CreditBfMonitorListener message is null");
            return;
        }
        for (Message message : list) {
            String objectJson = message.getText();
            LOGGER.info("======CreditBfMonitorListener message handle start======, body part:{}", objectJson);
            List<CreditVipTask> vipTaskList = new ArrayList<>();
            try {
                Calendar now = Calendar.getInstance();
                Date triggerTimeDate = now.getTime();
                // 先确定该变更为该用户systemid监控下所对应的变更，其他systemid的信息则不处理,目前的mq不含systemid和entName
                List<Map<String,String>> listObjectSec = JSONArray.parseObject(objectJson,List.class);
                LOGGER.info("利用JSONArray中的parseArray方法并指定返回类型来解析json数组字符串");
                for(Map<String,String> mapList : listObjectSec){
                    if(!mapList.containsKey("userPin") ){
                        LOGGER.error("CreditBfMonitorListener mq userPin or entName is null, mq text mapList:", mapList);
                        continue;
                    }
                    String userPin = mapList.get("userPin");
                    String entName = mapList.get("entName");
                    String result = mapList.get("result");

                    CreditUser userParam=new CreditUser();
                    userParam.setUserPin(userPin);
                    List<CreditUser> userList = userService.selectCreditUserByParam(userParam);
                    if(CollectionUtils.isEmpty(userList)){
                        LOGGER.error("CreditBfMonitorListener exsit, reason: query userList is empty,userPin:", userPin);
                        continue;
                    }
                    VipTaskDtoQueryParam queryParam=new VipTaskDtoQueryParam();
                    queryParam.setLimit(1);
                    queryParam.setEntName(entName);
                    queryParam.setTaskStatus(OpenOrCloseStatusEnum.OPEN.toName());
                    queryParam.setQueryType(CreditSewageQueryTypeEnum.PRO.toName());
                    queryParam.setUserPin(userPin);
                    CreditPage<CreditVipTask> resultPage =vipService.queryVipTaskList(queryParam);
                    LOGGER.info("CreditBfMonitorListener queryVipTaskList,{}" ,GsonUtil.getInstance().toJson(resultPage) );
                    if(null!= resultPage && resultPage.isSuccess() && CollectionUtils.isNotEmpty(resultPage.getRows())){
                        vipTaskList = resultPage.getRows();
                    }else{
                        LOGGER.info("CreditBfMonitorListener userPin:{}, entName:{} vipTask doesnt exsit or open.",userPin, entName);
                        continue;
                    }
                    for(CreditVipTask creditVipTask: vipTaskList){
                        CreditVipTaskExecutionModeEnum creditVipTaskExecutionModeEnum = CreditVipTaskExecutionModeEnum.VIP_EXECUTION_MODE_AUTOMATIC;
                        List<VipResultEntity<Object>> entInvResultDataList = new ArrayList<VipResultEntity<Object>>();
                        List<CreditVipTaskProduct> creditVipTaskProductList = new ArrayList<>();
                        VipTaskProductsQueryParam vipTaskProRelationPrm = new VipTaskProductsQueryParam();
                        vipTaskProRelationPrm.setTaskId(creditVipTask.getTaskId());
                        vipTaskProRelationPrm.setDataStatus(CreditOpenStatusEnum.OPEN.toName());
                        vipTaskProRelationPrm.setProductCode(EnterpriseProductEnum4Common.ENTERPRISE_CHINADATA_BF_MONITOR_LIST.toName());
                        creditVipTaskProductList = vipService.queryVipTaskProductByParams(vipTaskProRelationPrm); //查出该目标企业的关联企业所监控的产品
                        LOGGER.info("queryVipTaskProductByParams responseData.",GsonUtil.getInstance().toJson(creditVipTaskProductList));
                        if(CollectionUtils.isEmpty(creditVipTaskProductList)){
                            LOGGER.info("CreditBfMonitorListener has no data to handle, requestParam:{}", GsonUtil.getInstance().toJson(vipTaskProRelationPrm));
                            continue;
                        }
                        CreditVipTaskProduct creditVipTaskProduct = new  CreditVipTaskProduct();
                        creditVipTaskProduct.setTaskProductId(creditVipTaskProductList.get(0).getTaskProductId());
                        creditVipTaskProduct.setRelationType(creditVipTaskProductList.get(0).getRelationType());
                        List<ChinaDataAntiMoneyLaunderResp> respLinksNodesList = new ArrayList<ChinaDataAntiMoneyLaunderResp>();
                        try {
                            CreditVipTaskProductResult creditVipTaskProductResult = new CreditVipTaskProductResult();
                            creditVipTaskProductResult.setTaskProductId(creditVipTaskProduct.getTaskProductId());
                            creditVipTaskProductResult.setTriggerTime(triggerTimeDate);
                            creditVipTaskProductResult.setCreator(SystemConstants.PARAM_INPUT_OPERATOR);
                            creditVipTaskProductResult.setCreatedDate(new Date());
                            creditVipTaskProductResult.setModifier(SystemConstants.PARAM_INPUT_OPERATOR);
                            creditVipTaskProductResult.setModifiedDate(new Date());
                            creditVipTaskProductResult.setExecutionMode(creditVipTaskExecutionModeEnum.getCode());
                            creditVipTaskProductResult.setSubProductCode(VipResultSubProductCodeEnum.NOSUB.getCode());
                            ChinaDataAntiMoneyLaunderResp respLinksNodes= com.alibaba.fastjson.JSON.parseObject(result,ChinaDataAntiMoneyLaunderResp.class);
                            respLinksNodesList.add(respLinksNodes);
                            creditVipTaskProductResult.setResultListSize(respLinksNodes.getNodes().size());
                            creditVipTaskProductResult.setResultType(CreditVipResultTypeEnum.RESULT_TYPE_SUCCESS.getCode());
                            creditVipTaskProductResult.setCompressType(CreditVipCompressTypeEnum.NON.getCode());
                            creditVipTaskProductResult.setInitialization(CreditVipInitializationEnum.INITIALIZATION_NO.getCode());
//                                creditVipTaskProductResult.setResultIdContrast();
                            creditVipTaskProductResult.setResultUpdateStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode());
                            List<Object> updateData = new ArrayList();
                            for (int i = 0; i < respLinksNodesList.size(); i++) {
                                updateData.add(respLinksNodesList.get(i));
                            }

                            String resultUpdateInfo = GsonUtil.getInstance().toJson(updateData);
                            MongoRiskWarnTaskProductResult vipTskResult = this.buildMongoRiskWarnTaskProductResult(triggerTimeDate, creditVipTaskProductResult, updateData);
                            MongoRiskWarnTaskProductResult addResult = mongoService.addRiskWarnUpdateInfo(vipTskResult);
                            if(null != addResult && StringUtils.isNotBlank(addResult.getId())){ //存储mongodb 成功
                                resultUpdateInfo = addResult.getId();
                                creditVipTaskProductResult.setCompressType(CreditVipCompressTypeEnum.MONGONOZIP.getCode());
                            }else{
                                creditVipTaskProductResult.setCompressType(CreditVipCompressTypeEnum.GZIP.getCode());
                            }
                            creditVipTaskProductResult.setUpdateInfo(resultUpdateInfo);

                            int resultCount = vipService.insertSelectiveCreditVipTaskProductResult(creditVipTaskProductResult);
                            if (resultCount > 0) {
                                //
                                //更新vipTask状态
                                CreditVipTask creditVipTaskUpdate = new CreditVipTask();
                                creditVipTaskUpdate.setTaskId(creditVipTask.getTaskId());
                                creditVipTaskUpdate.setModifier(SystemConstants.PARAM_INPUT_OPERATOR);
                                creditVipTaskUpdate.setModifiedDate(new Date());
                                creditVipTaskUpdate.setTriggerTime(triggerTimeDate);
                                creditVipTaskUpdate.setTaskResult(CreditVipTaskResultEnum.TASK_UPDATE_UPDATE.getCode());

                                try {
                                    int resultCount4UpdateTask = vipService.updateTaskByPrimaryKeySelective(creditVipTaskUpdate);
                                    if (resultCount > 0) {
                                        LOGGER.info("CreditBfMonitorListener handle taskResult updateTaskByPrimaryKeySelective success, taskId:{}", creditVipTaskUpdate.getTaskId());
                                    } else {
                                        LOGGER.error("CreditBfMonitorListener handle taskResult updateTaskByPrimaryKeySelective failed, resultCount:{}", resultCount);
                                        continue;
                                    }
                                } catch (Exception e) {
                                    LOGGER.error("CreditBfMonitorListener handle taskResult updateTaskByPrimaryKeySelective error ,{}", e);
                                }
                                //保存vip监控预警结果
                                vipTaskExecuteService.vipMonitorResultAlarm(creditVipTask.getVipId(), triggerTimeDate);
                                //发送预警、变更信息
                                vipTaskExecuteService.senRiskWarnChangeInfoWxAEmailCallback(userList.get(0), creditVipTask.getVipId());
                                LOGGER.info("CreditBfMonitorListener handle taskResult insertSelectiveCreditVipTaskProductResult success, resultId:{}", creditVipTaskProductResult.getResultId());
                            } else {
                                LOGGER.error("CreditBfMonitorListener handle taskResult insertSelectiveCreditVipTaskProductResult failed, resultCount:{}", resultCount);
                            }
                        } catch (Exception e) {
                            LOGGER.error("CreditBfMonitorListener handle taskResult error:{}", e);
                        }
                    }
                }
            } catch (Exception e) {
                LOGGER.error("CreditBfMonitorListener handle error," ,e );
                continue;
            }
        }


    }

    /**
     * 构造mongodb 存储变更结果入参
     * @param triggerTimeDate
     * @param creditVipTaskProductResult
     * @param updateData
     * @return
     */
    private MongoRiskWarnTaskProductResult buildMongoRiskWarnTaskProductResult(Date triggerTimeDate, CreditVipTaskProductResult creditVipTaskProductResult, List<Object> updateData) {
        MongoRiskWarnTaskProductResult vipTskResult = new MongoRiskWarnTaskProductResult();
        try {
            vipTskResult.setTaskProductId(creditVipTaskProductResult.getTaskProductId());
            vipTskResult.setUpdateInfo(GsonUtil.getInstance().toJson(updateData));
            vipTskResult.setResultType(creditVipTaskProductResult.getResultType());
            vipTskResult.setResultListSize(creditVipTaskProductResult.getResultListSize());
            vipTskResult.setTriggerTime(triggerTimeDate);
            vipTskResult.setResultIdContrast(creditVipTaskProductResult.getResultIdContrast());
            vipTskResult.setShareholderStr(creditVipTaskProductResult.getShareholderStr());
            vipTskResult.setFringgFlag(creditVipTaskProductResult.getFringgFlag());
            vipTskResult.setCreator(SystemConstants.PARAM_INPUT_OPERATOR);
            vipTskResult.setCreatedDate(new Date());
            vipTskResult.setModifier(SystemConstants.PARAM_INPUT_OPERATOR);
            vipTskResult.setModifiedDate(new Date());
        } catch (Exception e) {
            LOGGER.error("vip job, saveProductSuccessResult buildMongoRiskWarnTaskProductResult ,error:{}", e);
        }
        return vipTskResult;
    }


}
