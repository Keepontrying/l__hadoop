package com.jd.jr.boss.credit.authen.core.beans.entity.microSmallBusinesses;

import java.io.Serializable;

/**
 * 既然怀涛定义了，那就封装一下吧
 *
 * @author huangzhiqiang
 * @data 2018/3/27
 */
public class Basic4Huaitao implements Serializable {
    private static final long serialVersionUID = -5159484034350946919L;

    private String code;
    private String result;
    private String msg;
    private Company data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Company getData() {
        return data;
    }

    public void setData(Company data) {
        this.data = data;
    }
}
