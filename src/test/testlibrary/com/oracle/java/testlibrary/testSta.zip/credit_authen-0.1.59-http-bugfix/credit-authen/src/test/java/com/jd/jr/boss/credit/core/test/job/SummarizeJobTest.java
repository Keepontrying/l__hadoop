package com.jd.jr.boss.credit.core.test.job;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.jd.jr.boss.credit.authen.core.scheduler.CallCaseSummarizeJob;

/**
 * 
 * <ul>
 * <li>1、开发日期：2018年1月15日</li>
 * <li>2、开发时间：上午10:43:38</li>
 * <li>3、作 者：zhanghui12</li>
 * <li>4、类型名称：SummarizeJobTest</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/spring-authen.xml" })

public class SummarizeJobTest {

	@Autowired
	private CallCaseSummarizeJob callCaseSummarizeJob;

	@Test
	public void testJob() throws Exception {
		callCaseSummarizeJob.doJob(null);

	}

}
