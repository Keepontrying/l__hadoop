package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;

/**
 * created by ChenKaiJu on 2018/7/31  11:40
 */
public class AntiMoneyLQueryParam implements Serializable {
    private static final long serialVersionUID = 1576273519894861617L;
    String startTime;
    String endTime;



    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }
}
