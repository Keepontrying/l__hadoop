package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.request.VipTriggerQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditVipWithTime;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CreditVipWithTimeDao {

    /**
     * 根据条件查询包含执行时间的vip对象
     * @param vipTriggerQueryParam
     * @return
     */
    List<CreditVipWithTime> selectVipWithTimeByParam(VipTriggerQueryParam vipTriggerQueryParam);

    /**
     * 批量新增vip监控调度时间
     * @param creditVipTimeList
     * @return
     */
	Integer insertBatchVipTime(List<CreditVipWithTime> creditVipTimeList);

}