package com.jd.jr.boss.credit.authen.core.beans.entity.autoSewage;

import java.io.Serializable;

/**
 * Created by liuwei55@jd.com
 *
 * @version 1.0
 * @date : 2018/11/20.
 * @return
 */
public class AutoSewageProAnalysisReport  implements Serializable {
    private static final long serialVersionUID = 795847513174922308L;
    /**
     * 目标企业数
     */
    private int entNum;
    /**
     * 目标企业查的数
     */
    private int oldEntSuccessNum;
    /**
     * 关联企业数
     */
    private int relEntNum;
    /**
     * 总企业数
     */
    private int sumEntNum;
    //目标企业----------------
    /**
     * 目标企业高风险 企业数
     */
    private int highEntNum;
    /**
     * 目标企业中风险 企业数
     */
    private int midEntNum;
    /**
     * 目标企业低风险 企业数
     */
    private int lowEntNum;
    /**
     * 目标企业未命中策略 企业数
     */
    private int unEntNum;
    /**
     * 目标企业查无数据 企业数
     */
    private int noDataNum;
    //关联企业------------------
    /**
     * 关联企业高风险 企业数
     */
    private int relHighEntNum;
    /**
     * 关联企业中风险 企业数
     */
    private int relMidEntNum;
    /**
     * 关联企业低风险 企业数
     */
    private int relLowEntNum;
    /**
     * 关联企业未命中策略 企业数
     */
    private int relUnEntNum;
    /**
     * 关联企业查无数据 企业数
     */
    private int relNoDataNum;
    /**
     * 查询日期
     */
    private String queryDate;
    /**
     * 分组个数
     */
    private int groupNum;
    public int getEntNum() {
        return entNum;
    }

    public void setEntNum(int entNum) {
        this.entNum = entNum;
    }

    public int getOldEntSuccessNum() {
        return oldEntSuccessNum;
    }

    public void setOldEntSuccessNum(int oldEntSuccessNum) {
        this.oldEntSuccessNum = oldEntSuccessNum;
    }

    public int getRelEntNum() {
        return relEntNum;
    }

    public void setRelEntNum(int relEntNum) {
        this.relEntNum = relEntNum;
    }

    public int getSumEntNum() {
        return sumEntNum;
    }

    public void setSumEntNum(int sumEntNum) {
        this.sumEntNum = sumEntNum;
    }

    public int getHighEntNum() {
        return highEntNum;
    }

    public void setHighEntNum(int highEntNum) {
        this.highEntNum = highEntNum;
    }

    public int getMidEntNum() {
        return midEntNum;
    }

    public void setMidEntNum(int midEntNum) {
        this.midEntNum = midEntNum;
    }

    public int getLowEntNum() {
        return lowEntNum;
    }

    public void setLowEntNum(int lowEntNum) {
        this.lowEntNum = lowEntNum;
    }

    public int getUnEntNum() {
        return unEntNum;
    }

    public void setUnEntNum(int unEntNum) {
        this.unEntNum = unEntNum;
    }

    public int getNoDataNum() {
        return noDataNum;
    }

    public void setNoDataNum(int noDataNum) {
        this.noDataNum = noDataNum;
    }

    public int getRelHighEntNum() {
        return relHighEntNum;
    }

    public void setRelHighEntNum(int relHighEntNum) {
        this.relHighEntNum = relHighEntNum;
    }

    public int getRelMidEntNum() {
        return relMidEntNum;
    }

    public void setRelMidEntNum(int relMidEntNum) {
        this.relMidEntNum = relMidEntNum;
    }

    public int getRelLowEntNum() {
        return relLowEntNum;
    }

    public void setRelLowEntNum(int relLowEntNum) {
        this.relLowEntNum = relLowEntNum;
    }

    public int getRelUnEntNum() {
        return relUnEntNum;
    }

    public void setRelUnEntNum(int relUnEntNum) {
        this.relUnEntNum = relUnEntNum;
    }

    public int getRelNoDataNum() {
        return relNoDataNum;
    }

    public void setRelNoDataNum(int relNoDataNum) {
        this.relNoDataNum = relNoDataNum;
    }

    public String getQueryDate() {
        return queryDate;
    }

    public void setQueryDate(String queryDate) {
        this.queryDate = queryDate;
    }

    public int getGroupNum() {
        return groupNum;
    }

    public void setGroupNum(int groupNum) {
        this.groupNum = groupNum;
    }
}
