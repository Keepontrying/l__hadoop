package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.domain.common.entity.CreditPostBillMonth;
import com.jd.jr.boss.credit.domain.common.entity.CreditPostBillMonthProduct;
import com.jd.jr.boss.credit.facade.authen.beans.param.PostBillQueryParam;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by anmeng on 2017/9/12.
 */
@Repository
public interface CreditPostBillDao {
    /**
     * 创建月账单
     * @param billMonth
     * @return
     */
    int insert(CreditPostBillMonth billMonth);

    /**
     * 查询月账单
     * @param queryParam
     * @return
     */
    List<CreditPostBillMonth> query(PostBillQueryParam queryParam);

    /**
     * 查询月账单总条数
     * @param queryParam
     * @return
     */
    Long queryCount(PostBillQueryParam queryParam);

    /**
     * 插入月账单的分产品汇总
     * @param productList
     * @return
     */
    int insertProductSum(List<CreditPostBillMonthProduct> productList);

    /**
     * 查询月账单下面产品汇总
     * @param billId
     * @return
     */
    List<CreditPostBillMonthProduct> queryProductSum(Integer billId);

    /**
     * 更新账单状态
     * @param billMonth
     * @return
     */
    int updateBillStatus(CreditPostBillMonth billMonth);
}
