package com.jd.jr.boss.credit.authen.core.facade.external;

import com.google.common.base.Preconditions;
import com.jd.jr.boss.credit.authen.core.service.CreditUserService;
import com.jd.jr.boss.credit.authen.core.service.WxOrderService;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.entity.merchant.MerchantUserWithJdpin;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.request.merchant.GatewayPortalUserRequest;
import com.jd.jr.boss.credit.credit.gateway.merchantca.facade.merchant.GatewayMerchantFacade;
import com.jd.jr.boss.credit.facade.common.dto.CreditExRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.external.api.CreditExWxOrderFacade;
import com.jd.jr.boss.credit.facade.external.beans.request.WxOrderReq;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditWxOrderResp;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.boss.credit.admin.entity.CreditWanxiangOrder;
import com.wangyin.boss.credit.admin.enums.CreditUserEnum;
import com.wangyin.boss.credit.admin.enums.CreditWxOrderStatusEnum;
import com.wangyin.boss.credit.admin.enums.MerchantAuditEnum;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 万象
 */
@Service("creditExWxOrderFacade")
public class CreditExWxOrderFacadeImpl implements CreditExWxOrderFacade {

    private Logger logger= LoggerFactory.getLogger(CreditExWxOrderFacadeImpl.class);

    @Autowired
    private WxOrderService wxOrderService;

    @Autowired
    private GatewayMerchantFacade gatewayMerchantFacade;

    @Autowired
    private CreditUserService creditUserService;

    /**
     * 创建万象订单
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<CreditWxOrderResp> createOrder(CreditExRequestParam<WxOrderReq> requestParam) {
        CreditResponseData<CreditWxOrderResp> creditExResponseData = new CreditResponseData<CreditWxOrderResp>();
        creditExResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
        creditExResponseData.setCode(ResponseMessage.SUCCESS.name());
        creditExResponseData.setSuccess(true);

        CreditWxOrderResp creditWxOrderResp = new CreditWxOrderResp();
        creditWxOrderResp.setSuccess(true);
        creditExResponseData.setData(creditWxOrderResp);

        String merchantNo = null;
        WxOrderReq wxOrderReq = null;
        int creditWanxiangOrderId = 0;

        try{
            Preconditions.checkNotNull(requestParam,"queryParam is null");
            wxOrderReq = requestParam.getParam();
            Preconditions.checkNotNull(wxOrderReq, "wxOrderReq is null");
            Preconditions.checkNotNull(wxOrderReq.getBalanceRecharge(), "balance4Recharge is null");
            Preconditions.checkNotNull(wxOrderReq.getJdpin(), "jdpin is null");
            Preconditions.checkNotNull(wxOrderReq.getWxPaymentTime(), "wxPaymentTime is null");
            Preconditions.checkNotNull(wxOrderReq.getWxOrderId(), "wxOrderId is null");
            Preconditions.checkNotNull(wxOrderReq.getWxOrderTime(), "wxOrderTime is null");
            Preconditions.checkNotNull(wxOrderReq.getWxAppVersions(), "wxAppVersions is null");
            Preconditions.checkNotNull(wxOrderReq.getWxAppVerName(), "wxAppVerName is null");
            Preconditions.checkNotNull(wxOrderReq.getPayType(), "payType is null");

            Pattern pattern= Pattern.compile("^(([1-9]{1}\\d*)|([0]{1}))(\\.(\\d){0,2})?$");
            Matcher match=pattern.matcher(wxOrderReq.getBalanceRecharge());
            Preconditions.checkArgument(match.matches(), "balance4Recharge 必须是数字类型，且小数点后不能超过两位");

            Preconditions.checkArgument(StringUtils.isNotBlank(wxOrderReq.getBalanceRecharge()) && StringUtils.isNotBlank(wxOrderReq.getJdpin())
                    && StringUtils.isNotBlank(wxOrderReq.getWxOrderId()) && StringUtils.isNotBlank(wxOrderReq.getWxAppVersions())
                    && StringUtils.isNotBlank(wxOrderReq.getWxAppVerName()) && StringUtils.isNotBlank(wxOrderReq.getPayType()), "参数不能为空");


        }catch (Exception e){
            logger.error("createOrder requestParam:{}", GsonUtil.getInstance().toJson(requestParam), e);
            creditExResponseData.setMessage(e.getMessage());
            creditExResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
            creditExResponseData.setSuccess(false);
            creditWxOrderResp.setSuccess(false);
            return creditExResponseData;
        }

        try {
            CreditWanxiangOrder creditWanxiangOrder = new CreditWanxiangOrder();
            //先存库，保存起来
            BeanUtils.copyProperties(wxOrderReq, creditWanxiangOrder);
            creditWanxiangOrder.setStatus(CreditWxOrderStatusEnum.NON_RECHARGE.getCode());  //初始化,未充值
            creditWanxiangOrder.setRemark("初始化存储");
            creditWanxiangOrder.setCreator(requestParam.getBussId());
            creditWanxiangOrder.setCreatedDate(new Date());
            creditWanxiangOrder.setModifier(requestParam.getBussId());
            creditWanxiangOrder.setModifiedDate(new Date());
            logger.info("wxOrderService.insertSelective, creditWanxiangOrder:{}", GsonUtil.getInstance().toJson(creditWanxiangOrder));
            int result = wxOrderService.insertSelective(creditWanxiangOrder);
            logger.info("wxOrderService.insertSelective, result:{}", GsonUtil.getInstance().toJson(result));

            creditWanxiangOrderId = creditWanxiangOrder.getId();

            //根据京东pin查询用户信息
            RequestParam<GatewayPortalUserRequest> requestJdpinParam = new RequestParam<GatewayPortalUserRequest>();
            GatewayPortalUserRequest requestJdpin = new GatewayPortalUserRequest();
            requestJdpin.setJdpin(wxOrderReq.getJdpin());
            requestJdpinParam.setParam(requestJdpin);
            ResponseData<MerchantUserWithJdpin> merchantUserResponseData;
            MerchantUserWithJdpin merchantUserWithJdpin = null;
            logger.info("gatewayMerchantFacade.queryUsersInfoByJdPin, requestJdpinParam:{}", GsonUtil.getInstance().toJson(requestJdpinParam));
            merchantUserResponseData = gatewayMerchantFacade.queryUsersInfoByJdPin(requestJdpinParam);
            logger.info("gatewayMerchantFacade.queryUsersInfoByJdPin, merchantUserResponseData:{}", GsonUtil.getInstance().toJson(merchantUserResponseData));
            if (merchantUserResponseData.isSuccess() == true && merchantUserResponseData.getData() != null && merchantUserResponseData.getData().getLoginame() != null) {
                merchantUserWithJdpin = merchantUserResponseData.getData();
            } else {
                //jdpin不存在，未绑定钱包账户
                logger.warn("queryUsersInfoByJdPin error");

                CreditWanxiangOrder creditWanxiangOrderStatusJdpin = new CreditWanxiangOrder();
                creditWanxiangOrderStatusJdpin.setId(creditWanxiangOrder.getId());
                creditWanxiangOrderStatusJdpin.setStatus(CreditWxOrderStatusEnum.NON_RECHARGE.getCode());
                creditWanxiangOrderStatusJdpin.setRemark("未绑定钱包账户");
                creditWanxiangOrderStatusJdpin.setModifier(requestParam.getBussId());
                creditWanxiangOrderStatusJdpin.setModifiedDate(new Date());
                logger.info("wxOrderService.updateByPrimaryKeySelective, creditWanxiangOrder:{}", GsonUtil.getInstance().toJson(creditWanxiangOrderStatusJdpin));
                int resultUp = wxOrderService.updateByPrimaryKeySelective(creditWanxiangOrderStatusJdpin);
                logger.info("wxOrderService.updateByPrimaryKeySelective, result:{}", GsonUtil.getInstance().toJson(resultUp));
            }

            //查询是否是征信的用户
            CreditUser creditUser = new CreditUser();
            creditUser.setLoginName(merchantUserWithJdpin.getLoginame());
            logger.info("creditUserService.selectCreditUserByParam, creditUser:{}", GsonUtil.getInstance().toJson(creditUser));
            List<CreditUser> creditUserList = creditUserService.selectCreditUserByParamSkipCache(creditUser);
            logger.info("creditUserService.selectCreditUserByParam, creditUserList:{}", GsonUtil.getInstance().toJson(creditUserList));
            if (creditUserList != null && creditUserList.size() > 0) {   //用户存在
                CreditUser creditUserResp = creditUserList.get(0);
                if (creditUserResp.getAuditStatus() != null && creditUserResp.getAuditStatus().equals(MerchantAuditEnum.PASS_BUSINESS.getCode()) &&
                        creditUserResp.getUserStatus() != null && creditUserResp.getUserStatus().equals(CreditUserEnum.OPEN.getCode())) {   //判断是否审核通过，判断用户是否有效
                    merchantNo = creditUserResp.getMerchantNo();

                    //更新信息，添加商户id
                    CreditWanxiangOrder creditWanxiangOrderStatus = new CreditWanxiangOrder();
                    creditWanxiangOrderStatus.setId(creditWanxiangOrder.getId());
                    creditWanxiangOrderStatus.setMerchantNo(merchantNo);
                    creditWanxiangOrderStatus.setMerchantId(creditUserResp.getMerchantId());
                    creditWanxiangOrderStatus.setRemark("用户状态有效");
                    creditWanxiangOrderStatus.setModifier(requestParam.getBussId());
                    creditWanxiangOrderStatus.setModifiedDate(new Date());
                    logger.info("wxOrderService.updateByPrimaryKeySelective, creditWanxiangOrder:{}", GsonUtil.getInstance().toJson(creditWanxiangOrderStatus));
                    int resultUp = wxOrderService.updateByPrimaryKeySelective(creditWanxiangOrderStatus);
                    logger.info("wxOrderService.updateByPrimaryKeySelective, result:{}", GsonUtil.getInstance().toJson(resultUp));

                } else {  //如果无有效用户
                    logger.warn("CreditExWxOrderFacade user is not valid,creditUser:{}", GsonUtil.getInstance().toJson(creditUserResp));
                    CreditWanxiangOrder creditWanxiangOrderStatus = new CreditWanxiangOrder();
                    creditWanxiangOrderStatus.setId(creditWanxiangOrder.getId());
                    creditWanxiangOrderStatus.setStatus(CreditWxOrderStatusEnum.NON_RECHARGE.getCode());
                    creditWanxiangOrderStatus.setRemark("用户状态无效");
                    creditWanxiangOrderStatus.setModifier(requestParam.getBussId());
                    creditWanxiangOrderStatus.setModifiedDate(new Date());
                    logger.info("wxOrderService.updateByPrimaryKeySelective, creditWanxiangOrder:{}", GsonUtil.getInstance().toJson(creditWanxiangOrderStatus));
                    int resultUp = wxOrderService.updateByPrimaryKeySelective(creditWanxiangOrderStatus);
                    logger.info("wxOrderService.updateByPrimaryKeySelective, result:{}", GsonUtil.getInstance().toJson(resultUp));

                    return creditExResponseData;
                }
            }else {
                return creditExResponseData;
            }

        } catch (Exception e) {
            logger.error("createOrder manage wxOrder error ", e);

            if (creditWanxiangOrderId > 0){
                wxOrderService.updateErrorMsg(creditWanxiangOrderId, e.getMessage(), requestParam.getBussId());
            }

            creditExResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
            creditExResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
            creditExResponseData.setSuccess(false);
            creditWxOrderResp.setSuccess(false);
            return creditExResponseData;
        }

        //创建万象订单
        try {
            wxOrderService.createWxOrder(merchantNo, requestParam.getBussId(), wxOrderReq, creditWanxiangOrderId);
        } catch (Exception e) {
            logger.error("wxOrderService.createWxOrder, error", e);

            if (creditWanxiangOrderId > 0){
                wxOrderService.updateErrorMsg(creditWanxiangOrderId, e.getMessage(), requestParam.getBussId());
            }
            creditExResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditExResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditExResponseData.setSuccess(false);
            creditWxOrderResp.setSuccess(false);
            return creditExResponseData;
        }

        return creditExResponseData;
    }




}
