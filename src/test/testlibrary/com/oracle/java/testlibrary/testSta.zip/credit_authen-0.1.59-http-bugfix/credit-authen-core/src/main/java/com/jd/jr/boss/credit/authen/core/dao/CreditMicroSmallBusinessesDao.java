package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.entity.microSmallBusinesses.Company;
import com.jd.jr.boss.credit.authen.core.beans.entity.microSmallBusinesses.PolicySupportInfo;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2018/3/26
 */
@Repository
public interface CreditMicroSmallBusinessesDao {

    Long insertCompany(Company company);

    void insertPolicySupportInfo(PolicySupportInfo policySupportInfo);

}
