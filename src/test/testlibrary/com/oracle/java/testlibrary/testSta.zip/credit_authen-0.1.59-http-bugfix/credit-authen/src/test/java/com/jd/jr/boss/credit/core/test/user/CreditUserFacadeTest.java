package com.jd.jr.boss.credit.core.test.user;

import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.entity.merchant.MerchantUsers;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.request.merchant.GatewayPortalUserRequest;
import com.jd.jr.boss.credit.credit.gateway.merchantca.exception.MerchantException;
import com.jd.jr.boss.credit.credit.gateway.merchantca.facade.merchant.GatewayMerchantFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditUserFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.UserQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.List;

import static junit.framework.Assert.assertTrue;

/**
 * @author jiangbo
 * @since 2017/3/29
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})

public class CreditUserFacadeTest{
    @Resource
    CreditUserFacade creditUserFacade;
//    @Resource
//    private GatewayMerchantFacade gatewayMerchantFacade;

    @Test
    public void selectCreditUserByParamTest(){
        CreditRequestParam requestParam4QryUserList = new CreditRequestParam();
        UserQueryParam creditUser4Group = new UserQueryParam();
        creditUser4Group.setMerchantId(1076);
        requestParam4QryUserList.setParam(creditUser4Group);
        List<CreditUser> userList4Group = creditUserFacade.selectCreditUserByParam4Common(requestParam4QryUserList);
        System.out.println("resp : " + GsonUtil.getInstance().toJson(userList4Group));
    }

    @Test
    public void selectSingleCreditUserByParam(){
        CreditRequestParam<UserQueryParam> requestParam = new CreditRequestParam<UserQueryParam>();
        UserQueryParam userQueryParam = new UserQueryParam();
        userQueryParam.setLoginName("qcredit@a.com");
        requestParam.setParam(userQueryParam);
//        CreditResponseData<CreditUser> responseData = creditUserFacade.selectSingleCreditUserByParam(requestParam);
//        System.out.println( ReflectionToStringBuilder.toString(responseData));
//        assertTrue(responseData.isSuccess());
    }

//    @Test
//    public void selectMerchantUsers() throws MerchantException {
//        RequestParam<GatewayPortalUserRequest> requestParam = new RequestParam<GatewayPortalUserRequest>();
//        GatewayPortalUserRequest userRequest = new GatewayPortalUserRequest();
//        userRequest.setUserName("pikaqiu");
//        requestParam.setParam(userRequest);
//        Page<MerchantUsers> page = gatewayMerchantFacade.queryUsersInfoByPrm(requestParam);
//        assertTrue(page.isSuccess());
//    }

}
