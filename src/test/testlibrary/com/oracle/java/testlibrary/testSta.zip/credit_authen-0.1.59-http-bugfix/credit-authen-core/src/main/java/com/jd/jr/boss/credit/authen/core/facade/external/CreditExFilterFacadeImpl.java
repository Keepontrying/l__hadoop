package com.jd.jr.boss.credit.authen.core.facade.external;

import com.jd.jr.boss.credit.authen.core.service.CreditFilterService;
import com.jd.jr.boss.credit.facade.common.dto.CreditExRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.external.api.CreditExFilterFacade;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditFilterResp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author huangzhiqiang
 * @data 2017/9/21
 */
@Service("creditExFilterFacade")
public class CreditExFilterFacadeImpl implements CreditExFilterFacade {

    @Autowired
    private CreditFilterService filterService;

    @Override
    public CreditResponseData<CreditFilterResp> getFilter(CreditExRequestParam queryParam) {
        CreditResponseData<CreditFilterResp> responseData = new CreditResponseData();
        CreditFilterResp filterResp = new CreditFilterResp();
        filterResp.setProvince(filterService.queryProvince());
        filterResp.setIndustry(filterService.queryIndustry());
        filterResp.setRegStatus(filterService.queryRegStatus());
        filterResp.setRegCapital(filterService.queryRegCapital());
        filterResp.setRegTime(filterService.queryRegTime());
        responseData.setData(filterResp);
        return responseData;
    }
}
