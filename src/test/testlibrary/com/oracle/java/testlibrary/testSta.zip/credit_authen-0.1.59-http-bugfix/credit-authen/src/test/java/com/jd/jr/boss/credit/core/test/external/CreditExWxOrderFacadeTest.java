package com.jd.jr.boss.credit.core.test.external;

import com.jd.jr.boss.credit.authen.core.service.CreditFilterService;
import com.jd.jr.boss.credit.core.test.user.BaseTest;
import com.jd.jr.boss.credit.facade.common.dto.CreditExRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.common.entity.Industry;
import com.jd.jr.boss.credit.facade.external.api.CreditExFilterFacade;
import com.jd.jr.boss.credit.facade.external.api.CreditExWxOrderFacade;
import com.jd.jr.boss.credit.facade.external.beans.request.WxOrderReq;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditFilterResp;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditWxOrderResp;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.List;

/**
 *
 * @author jiangbo
 */
public class CreditExWxOrderFacadeTest extends BaseTest {

    @Autowired
    private CreditExWxOrderFacade creditExWxOrderFacade;

    @Autowired
    private CreditFilterService filterService;

    @Test
    public void testQueryFilter() {
        CreditExRequestParam<WxOrderReq> requestParam = new CreditExRequestParam<WxOrderReq>();
        WxOrderReq wxOrderReq = new WxOrderReq();
        wxOrderReq.setJdpin("pikaqiu1");
        wxOrderReq.setBalanceRecharge("66.11");
        wxOrderReq.setWxPaymentTime(new Date());
        wxOrderReq.setWxOrderId("3fda1");
        wxOrderReq.setPayType("ddsfddd12");
        wxOrderReq.setWxAppVerName("基础版");
        wxOrderReq.setWxAppVersions("1.0");
        wxOrderReq.setWxOrderTime(new Date());

        requestParam.setBussId("credit_wanxiang");
        requestParam.setSystemId("credit_wanxiang");
        requestParam.setToken("36a1c6edbf5b426a80b3cc04e07fc153");

        requestParam.setParam(wxOrderReq);

        CreditResponseData<CreditWxOrderResp> resp = creditExWxOrderFacade.createOrder(requestParam);
        System.out.println("+++++++++++++++++");
        System.out.println(GsonUtil.getInstance().toJson(resp));
        System.out.println("=================");
        System.out.println(GsonUtil.getInstance().toJson(requestParam));
    }


    @Test
    public void queryIndustry() {
        List<Industry> industryList=  filterService.queryIndustry();
        System.out.println("=================");
        System.out.println(GsonUtil.getInstance().toJson(industryList));
    }
}
