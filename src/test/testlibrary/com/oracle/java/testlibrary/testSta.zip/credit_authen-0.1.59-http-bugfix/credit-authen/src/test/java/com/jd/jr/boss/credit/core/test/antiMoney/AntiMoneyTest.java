package com.jd.jr.boss.credit.core.test.antiMoney;

import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.EntBfMonitorListFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.ResultData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.EntBfMonitorParam;
import com.wangyin.boss.credit.admin.enums.AccessCallModeEnum;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption : 最终受益人(反洗钱)测试类
 * @date ：2019/1/17 15:18
 * @return
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})
public class AntiMoneyTest {

    @Resource
    EntBfMonitorListFacade entBfMonitorListFacade;

    @Test
    public void testBFListOpt() throws Exception {
        CreditRequestParam<EntBfMonitorParam> requestParam=new CreditRequestParam<>();
        requestParam.setTradeNo("YJLTEST201901070001");
        requestParam.setOperator("hello119@qq.com");
        requestParam.setSystemId("a3888199df2711e7a293ecf4bbcdd49c");//userId字段
        requestParam.setArg(AccessCallModeEnum.VIPFLAG.toName());
        EntBfMonitorParam bfPrm = new EntBfMonitorParam();
        bfPrm.setType("1");
        bfPrm.setCompanyName("小米科技有限责任公司");
        requestParam.setParam(bfPrm);
        CreditResponseData<ResultData<EntBfMonitorParam, String>> response = entBfMonitorListFacade.bfMonitorOpt(requestParam);
        System.out.println("response:" + GsonUtil.getInstance().toJson(response));
    }
}
