package com.jd.jr.boss.credit.authen.core.beans.request;

import com.jd.jr.boss.credit.domain.common.enums.CreditPurchaseTypeEnum;

import java.io.Serializable;
import java.util.List;

public class ContractQueryParam implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -856160167903380899L;
	/**
     * 合同ID
     */
    private Integer contractId;
    /**
     * 合同状态
     */
    private List<String> contractStatusList; 
    
    /**
     * 结束时间
     */
    private String finishTime;

	/**
	 * 用于筛选当前日期有效的合同
	 */
	private String filterDate;
    /**
     * 商户ID
     */
    private Integer merchantId;
    /**
     * 商户号
     */
    private String merchantNo;

	private String creditType;//征信类型 企业 个人
	private String contractSource;//线上 线下

	private CreditPurchaseTypeEnum purchaseType;//付费方式

    private String productCode;//产品编码
    private String contractStatus;//合同状态

	public Integer getContractId() {
		return contractId;
	}

	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}


	public List<String> getContractStatusList() {
		return contractStatusList;
	}

	public void setContractStatusList(List<String> contractStatusList) {
		this.contractStatusList = contractStatusList;
	}

	public String getFinishTime() {
		return finishTime;
	}

	public void setFinishTime(String finishTime) {
		this.finishTime = finishTime;
	}

	public Integer getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(Integer merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantNo() {
		return merchantNo;
	}

	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}

	public String getCreditType() {
		return creditType;
	}

	public void setCreditType(String creditType) {
		this.creditType = creditType;
	}

	public String getContractSource() {
		return contractSource;
	}

	public void setContractSource(String contractSource) {
		this.contractSource = contractSource;
	}

	public String getFilterDate() {
		return filterDate;
	}

	public void setFilterDate(String filterDate) {
		this.filterDate = filterDate;
	}

	public CreditPurchaseTypeEnum getPurchaseType() {
		return purchaseType;
	}

	public void setPurchaseType(CreditPurchaseTypeEnum purchaseType) {
		this.purchaseType = purchaseType;
	}

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getContractStatus() {
        return contractStatus;
    }

    public void setContractStatus(String contractStatus) {
        this.contractStatus = contractStatus;
    }
}
