package com.jd.jr.boss.credit.authen.core.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.jd.jr.boss.credit.authen.core.beans.entity.CreditElaneParam;

@Repository
public interface CreditElaneParamMapper {
    int deleteByPrimaryKey(Long id);

    int insert(CreditElaneParam record);

    int insertSelective(CreditElaneParam record);

    CreditElaneParam selectByPrimaryKey(Long id);
    
    CreditElaneParam selectByMerchantNoBl(CreditElaneParam creditElaneParam);
    
    List<CreditElaneParam> selectSelective(CreditElaneParam creditElaneParam);

    int updateByPrimaryKeySelective(CreditElaneParam record);

    int updateByPrimaryKey(CreditElaneParam record);
}