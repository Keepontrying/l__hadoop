package com.jd.jr.boss.credit.core.test;

import com.jd.fastjson.JSON;
import com.jd.jr.boss.credit.facade.authen.api.PopRelationBatchFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.PopRelationParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * created by ChenKaiJu on 2018/12/11  14:51
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})
public class PopRelationBatchFacadeTest {

    @Resource
    PopRelationBatchFacade popRelationBatchFacade;

    @Test
    public void test(){
        CreditRequestParam<PopRelationParam> requestParam=new CreditRequestParam<PopRelationParam>();
        PopRelationParam param=new PopRelationParam();
        param.setFileId("2_1812_6_367");
        param.setTotalCount(4);
        param.setFileName("pop批量查询.xls");
        param.setMerchantId(1066);
        param.setMerchantNo("110040816");
        param.setOperator("liuwei55@jd.com");
        requestParam.setParam(param);
        CreditResponseData responseData=popRelationBatchFacade.batchQuery(requestParam);
        System.out.println(JSON.toJSONString(responseData));
    }

}
