package com.jd.jr.boss.credit.core.test;

import com.jd.fastjson.JSON;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.AntiMoneyLaunderFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.ResultData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.CdAntiMoneyLaunderParam;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.antiMoneyLaunder.chinaData.ChinaDataAntiMoneyLaunderResp;
import com.jd.jr.boss.credit.gateway.account.utils.SerialNoUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * created by ChenKaiJu on 2018/7/30  10:56
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})
public class AntiMoneyFacadeTest {

    @Resource
    AntiMoneyLaunderFacade antiMoneyLaunderFacade;

    @Test
    public void testFacade(){
        CreditRequestParam<CdAntiMoneyLaunderParam> requestParam=new CreditRequestParam<CdAntiMoneyLaunderParam>();
        requestParam.setTradeNo(SerialNoUtils.createSerialNo("TRADE"));
        requestParam.setSystemId("a3884c68df2711e7a293ecf4bbcdd49c");
        CdAntiMoneyLaunderParam param=new CdAntiMoneyLaunderParam();
        param.setEntName("北京小米电子软件技术有限公司");
        requestParam.setParam(param);
        CreditResponseData<ResultData<CdAntiMoneyLaunderParam, ChinaDataAntiMoneyLaunderResp>> responseData=antiMoneyLaunderFacade.cdDetailQuery(requestParam);
        System.out.println(JSON.toJSONString(responseData));
    }
}
