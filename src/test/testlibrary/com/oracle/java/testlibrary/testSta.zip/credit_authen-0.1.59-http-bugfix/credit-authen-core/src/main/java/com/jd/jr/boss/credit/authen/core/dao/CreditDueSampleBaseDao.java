package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.facade.authen.beans.param.mini.CreditDueSampleBaseQueryParam;
import com.wangyin.boss.credit.admin.entity.mini.CreditDueSampleBase;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Description: 拓客巡检样本详情基本信息表
 * User: yangjinlin@jd.com
 * Date: 2018/5/24 21:30
 * Version: 1.0
 */
@Repository
public interface CreditDueSampleBaseDao {
    /**
     * 多条件查询拓客巡检基本信息  List
     * @param dueBaseQryPrm
     * @return
     */
    List<CreditDueSampleBase> queryDueSampleBaseByPrm(CreditDueSampleBaseQueryParam dueBaseQryPrm);

    /**
     * 新增拓客巡检基本信息
     * @param param
     * @return
     */
    Integer addDueSampleBase(CreditDueSampleBase param);

    /**
     * 根据主键id删除拓客巡检基本信息
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Integer id);

    /**
     *  根据主键id更新拓客巡检基本信息
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(CreditDueSampleBase record);

    /**
     * 根据服务单编号更新拓客巡检基本信息
     * @param param
     * @return
     */
    int updateDueBaseBySampleNo(CreditDueSampleBase param);

    /**
     * 批量落地拓客巡检基本样本信息
     * @param sampleList
     */
    void saveBatchDueSample(List<CreditDueSampleBase> sampleList);

}
