package com.jd.jr.boss.credit.core.test;

import com.jd.jr.boss.credit.authen.core.dao.CreditFilterDao;
import com.jd.jr.boss.credit.core.test.user.BaseTest;
import com.jd.jr.boss.credit.facade.authen.api.CreditFilterFacade;
import com.jd.jr.boss.credit.facade.common.entity.Industry;
import com.jd.jr.boss.credit.facade.common.entity.Province;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2017/9/12
 */
public class CreditFilterFacadeTest extends BaseTest {

    @Autowired
    private CreditFilterFacade creditFilterFacade;

    @Autowired
    private CreditFilterDao creditFilterDao;

    @Test
    public void testQueryProvince(){
//        List<Province> provinceList= creditFilterFacade.queryProvince();
//        for(Province p : provinceList){
//            System.out.println(p);
//        }
    }

    @Test
    public void testQueryIndustry(){
        List<Industry> industries= creditFilterDao.queryIndustry();
        System.out.println("=================");
        System.out.println(GsonUtil.getInstance().toJson(industries));
    }
}
