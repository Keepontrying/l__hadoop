package com.jd.jr.boss.credit.authen.core.beans.entity.carLoan;

import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.EntInvQueryData;

import java.io.Serializable;
import java.util.List;

/**
 * 关联查询
 * @author tangmingbo
 *
 */
public class RelationEntInfoData implements Serializable{

	private static final long serialVersionUID = 2936531965994611042L;
	/**
	 * 企业数
	 */
	private int entNum;
	/**
	 * 关联企业工商信息
	 */
	private ReStatisticDesc reStatisticDesc;
	/**
	 * 企业股东个数
	 */
	private int entShareNum;
	/**
	 * 自然人股东个数
	 */
	private int personShareNum;
	/**
     * 大股东关联 》25%(只存放的企业股东)
	 */
	private List<EntInfo> majorShareList;
	/**
	 * 法定代表人为原始企业法人的公司个数
	 */
	private int frEntNum;
	/**
	 * 100%控股企业数量
	 */
	private int holdEntNum;
	/**
	 * 对外投资总额
	 */
	private String invAmount;
	/**
	 * 对外投资 》25%
	 */
	private List<EntInfo> entinvList;
	/**
	 * 对外投资关联方 企业
	 */
	private List<EntInvQueryData> invQueryDataList;
	/**
	 * 董高监
	 */
	private List<EntInfo> directorList;

	public int getEntNum() {
		return entNum;
	}

	public void setEntNum(int entNum) {
		this.entNum = entNum;
	}

	public ReStatisticDesc getReStatisticDesc() {
		return reStatisticDesc;
	}

	public void setReStatisticDesc(ReStatisticDesc reStatisticDesc) {
		this.reStatisticDesc = reStatisticDesc;
	}

	public int getEntShareNum() {
		return entShareNum;
	}

	public void setEntShareNum(int entShareNum) {
		this.entShareNum = entShareNum;
	}

	public int getPersonShareNum() {
		return personShareNum;
	}

	public void setPersonShareNum(int personShareNum) {
		this.personShareNum = personShareNum;
	}

	public List<EntInfo> getMajorShareList() {
		return majorShareList;
	}

	public void setMajorShareList(List<EntInfo> majorShareList) {
		this.majorShareList = majorShareList;
	}

	public int getFrEntNum() {
		return frEntNum;
	}

	public void setFrEntNum(int frEntNum) {
		this.frEntNum = frEntNum;
	}

	public int getHoldEntNum() {
		return holdEntNum;
	}

	public void setHoldEntNum(int holdEntNum) {
		this.holdEntNum = holdEntNum;
	}

	public String getInvAmount() {
		return invAmount;
	}

	public void setInvAmount(String invAmount) {
		this.invAmount = invAmount;
	}

	public List<EntInfo> getEntinvList() {
		return entinvList;
	}

	public void setEntinvList(List<EntInfo> entinvList) {
		this.entinvList = entinvList;
	}

	public List<EntInvQueryData> getInvQueryDataList() {
		return invQueryDataList;
	}

	public void setInvQueryDataList(List<EntInvQueryData> invQueryDataList) {
		this.invQueryDataList = invQueryDataList;
	}

	public List<EntInfo> getDirectorList() {
		return directorList;
	}

	public void setDirectorList(List<EntInfo> directorList) {
		this.directorList = directorList;
	}
}
