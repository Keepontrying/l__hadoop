package com.jd.jr.boss.credit.authen.core.facade.portal;

import java.util.List;

import com.jd.jr.boss.credit.authen.core.service.PostBillService;
import com.jd.jr.boss.credit.domain.common.entity.CreditPostBillMonth;
import com.jd.jr.boss.credit.facade.authen.beans.param.PostBillQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.CreditBillMerchantSum;
import com.wangyin.operation.common.beans.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.authen.core.service.BillService;
import com.jd.jr.boss.credit.facade.authen.api.CreditBillFacade;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.entity.CreditBill;
import com.wangyin.commons.util.Logger;
import com.wangyin.operation.common.enums.ResponseMessage;

/** 
* @desciption : 账单查询facade实现类
* @author : yangjinlin@jd.com
* @date ：2017年4月5日 下午3:06:12 
* @version 1.0 
* @return  */
@Service("creditBillFacade")
public class CreditBillFacadeImpl implements CreditBillFacade {

	private Logger logger = new Logger(CreditBillFacadeImpl.class);
	@Autowired
	private BillService billService;

	@Autowired
	private PostBillService postBillService;
	
	@Override
	public CreditResponseData<List<CreditBill>> queryBillList4Chart(CreditRequestParam<CreditBill> reqParam) {

		CreditResponseData<List<CreditBill>> respData = new CreditResponseData<List<CreditBill>>();
		try {
			List<CreditBill> billList = billService.queryBillList4Chart(reqParam.getParam());
			respData.setData(billList);
		} catch (Exception e) {
			logger.error(e);
			respData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
		}
		return respData;
	}

	@Override
	public Page<CreditPostBillMonth> queryPostBill(PostBillQueryParam queryParam) {
		try {
			return postBillService.queryPostBillMonth(queryParam);
		} catch (Exception e) {
			throw new RuntimeException("查询失败!");
		}
	}

	@Override
	public CreditPostBillMonth detailPostBill(PostBillQueryParam queryParam) {
		return postBillService.detailPostBill(queryParam);
	}

	/**
	 * 查询商户统计信息
	 * 包量调用量+单笔消费金额
	 *
	 * @param requestParam 商户号+起止日期
	 * @return 包量调用量+单笔消费金额
	 */
	@Override
	public CreditResponseData<CreditBillMerchantSum> queryMerchantBillSum(CreditRequestParam<CreditBill> requestParam) {
		CreditResponseData<CreditBillMerchantSum> responseData=new CreditResponseData<>();
		CreditBill param=requestParam.getParam();
		CreditBillMerchantSum sum=billService.queryMerchantSum(param);
		responseData.setData(sum);
		return responseData;
	}

}
