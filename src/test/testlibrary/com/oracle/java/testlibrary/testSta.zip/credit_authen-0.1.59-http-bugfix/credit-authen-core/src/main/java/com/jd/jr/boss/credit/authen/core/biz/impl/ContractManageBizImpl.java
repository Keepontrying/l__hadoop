package com.jd.jr.boss.credit.authen.core.biz.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;

import com.jd.jr.boss.credit.authen.core.beans.entity.ContractDetailsEntity;
import com.jd.jr.boss.credit.authen.core.beans.entity.ContractQueryEntity;
import com.jd.jr.boss.credit.authen.core.beans.request.AccountQueryParam;
import com.jd.jr.boss.credit.authen.core.beans.request.ContractPageQueryParam;
import com.jd.jr.boss.credit.authen.core.beans.request.ContractQueryParam;
import com.jd.jr.boss.credit.authen.core.beans.request.ContractUpdateParam;
import com.jd.jr.boss.credit.authen.core.biz.ContractManageBiz;
import com.jd.jr.boss.credit.authen.core.service.AccountService;
import com.jd.jr.boss.credit.authen.core.service.ContractService;
import com.jd.jr.boss.credit.authen.core.task.AccountOrPaymentService;
import com.jd.jr.boss.credit.domain.common.enums.ContractStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.OpenOrCloseStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.ProductChargeTypeEnum;
import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractDetailsRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractQueryRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractVerifyRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.contract.ContractContentResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.contract.ContractDetailsResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.contract.ContractQueryResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.contract.ContractStrategyResponse;
import com.jd.jr.boss.credit.facade.site.api.enums.request.ContractVerifyRequestEnum;
import com.jd.jr.boss.credit.facade.site.api.enums.response.ContractDetailsResponseEnum;
import com.jd.jr.boss.credit.facade.site.api.enums.response.ContractManageResponseEnum;
import com.wangyin.admin.frame.template.Template;
import com.wangyin.admin.frame.template.imp.FreeMarkRender;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import com.wangyin.commons.util.Logger;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.Response;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;

@Service
public class ContractManageBizImpl implements ContractManageBiz{
    private Logger logger = new Logger(ContractManageBizImpl.class);
    @Autowired
    private ContractService contractService;
    @Autowired
    private AccountService accountService;
    @Autowired
    private AccountOrPaymentService accountOrPaymentService;
    /**
     * 分页查询合同
     * @param contractQueryRequest
     * @return
     */
    @SuppressWarnings("serial")
	@Override
	public void queryContractPage(ContractQueryRequest contractQueryRequest,Page<ContractQueryResponse> page) throws Exception {
		logger.info("queryContractPage 查询参数:"+ GsonUtil.getInstance().toJson(contractQueryRequest));
		long startTime = System.currentTimeMillis();
		//查询参数
		ContractPageQueryParam contractPageQueryParam = new ContractPageQueryParam();
		//设置分页开始索引和每页条数
		if(contractQueryRequest.getPageSize()!=null){
			contractPageQueryParam.setLimit(contractQueryRequest.getPageSize());
		}
		if(contractQueryRequest.getPageNo()!=null){
			contractPageQueryParam.setStart((contractQueryRequest.getPageNo()-1)*contractPageQueryParam.getLimit());
			}
		contractPageQueryParam.setMarchantNo(contractQueryRequest.getMerchantNo());
		contractPageQueryParam.setMerchantCode(contractQueryRequest.getMerchantCode());
		List<String> contractStatusList = new ArrayList<String>(){
			{
			add(ContractStatusEnum.NOAUDIT.toName());
			add(ContractStatusEnum.RISK_NOPASS.toName());
//			add(ContractStatusEnum.CANCEL_AUDIT.toName());
//			add(ContractStatusEnum.TERMINATE_AUDIT.toName());
			}
			};
		contractPageQueryParam.setContractStatusList(contractStatusList );
		
		Integer contractCount = contractService.queryContractPageCount(contractPageQueryParam);
		List<ContractQueryEntity> contractList = contractService.queryContractPage(contractPageQueryParam);
		logger.info("contractList 查询结果："+ (System.currentTimeMillis()-startTime)+" ms;"+GsonUtil.getInstance().toJson(contractList));
		if(contractList!=null&&contractList.size()>0){
			//存在结果则写入列表
			List<ContractQueryResponse> contractResponseList = new ArrayList<ContractQueryResponse>();
			for(ContractQueryEntity entity:contractList){
				ContractQueryResponse contractStrategyResponse = new ContractQueryResponse();
				contractStrategyResponse.setContractId(entity.getContractId());
				contractStrategyResponse.setContractNo(entity.getContractNo());
				if(ContractStatusEnum.NOPAY.toName().equalsIgnoreCase(entity.getContractStatus())
						||ContractStatusEnum.CANCEL_AUDIT.toName().equalsIgnoreCase(entity.getContractStatus())
						||ContractStatusEnum.TERMINATE_AUDIT.toName().equalsIgnoreCase(entity.getContractStatus())
						){ 
					//待缴费状态返回给企业站时将状态置为有效状态，保证状态一致
					contractStrategyResponse.setContractStatus(ContractStatusEnum.VALID);
				}else if(ContractStatusEnum.CANCEL.toName().equalsIgnoreCase(entity.getContractStatus())){
					contractStrategyResponse.setContractStatus(ContractStatusEnum.CLOSE);
				}else{
					contractStrategyResponse.setContractStatus(ContractStatusEnum.enumValueOf(entity.getContractStatus().toUpperCase()));
				}
				contractStrategyResponse.setFinishTime(entity.getFinishTime());
				contractStrategyResponse.setMerchantCode(entity.getMerchantCode());
				contractStrategyResponse.setMerchantNo(entity.getMerchantNo());
				contractStrategyResponse.setProductName(ContractDetailsResponseEnum.PRODUCT_NAME);
				contractStrategyResponse.setProductService(entity.getProductNames()); //查询合同对应的所有产品名称
				contractStrategyResponse.setStartTime(entity.getStartTime());
				contractResponseList.add(contractStrategyResponse);
			}
			page.setRows(contractResponseList);
		    page.setTotal(contractCount);
		}else{
			page.setResponseMessage(ResponseMessage.NOT_EXIST);
		}
	}
    /**
     * 合同包含产品详情
     * @param contractDetailsRequest
     * @return
     */
	@Override
	public void queryContractDetails(
			ContractDetailsRequest contractDetailsRequest,ResponseData<ContractDetailsResponse> responseData) throws Exception {
		logger.info("queryContractDetails 查询参数:"+ GsonUtil.getInstance().toJson(contractDetailsRequest));
		long startTime = System.currentTimeMillis();
		ContractQueryParam contractQueryParam = new ContractQueryParam();
		contractQueryParam.setContractId(contractDetailsRequest.getContractId()); 
		ContractDetailsEntity contractDetails=contractService.queryContractDetailsById(contractQueryParam);
		logger.info("queryContractDetails 查询结果："+ (System.currentTimeMillis()-startTime)+" ms;"+GsonUtil.getInstance().toJson(contractDetails));
		if(contractDetails!=null){
			//存在结果则写入列表
			//合同详情中合同信息
			ContractDetailsResponse contractResponse = new ContractDetailsResponse();
			contractResponse.setContractId(contractDetails.getContractId());
			contractResponse.setContractNo(contractDetails.getContractNo());
			contractResponse.setContractStatus(ContractStatusEnum.valueOf(contractDetails.getContractStatus()));
			contractResponse.setFinishTime(contractDetails.getFinishTime());
			contractResponse.setMerchantCode(contractDetails.getMerchantCode());
			contractResponse.setMerchantNo(contractDetails.getMerchantNo());
			contractResponse.setProductName(ContractDetailsResponseEnum.PRODUCT_NAME);
			contractResponse.setProductService(contractDetails.getProductNames()); 
			contractResponse.setStartTime(contractDetails.getStartTime());
			//合同详情中计费产品信息
			List<ContractStrategyResponse> strategyList = new ArrayList<ContractStrategyResponse>();
			for(CreditProductStrategy entity:contractDetails.getStrategyList()){
				ContractStrategyResponse contractStrategyResponse = new ContractStrategyResponse();
				contractStrategyResponse.setStrategyId(entity.getStrategyId()); 
				contractStrategyResponse.setContractId(entity.getContractId()); 
				contractStrategyResponse.setProductName(entity.getProductName());
				contractStrategyResponse.setChargeType(ProductChargeTypeEnum.enumValueOf(entity.getChargeType()));
				contractStrategyResponse.setAmount(entity.getAmount());
				contractStrategyResponse.setPacketCount(entity.getPacketCount());
				contractStrategyResponse.setPrice(entity.getPrice()); 
				contractStrategyResponse.setStartTime(entity.getStartTime());
				contractStrategyResponse.setFinishTime(entity.getFinishTime());
				contractStrategyResponse.setStrategyStatus(OpenOrCloseStatusEnum.enumValueOf(entity.getStrategyStatus())); 
				strategyList.add(contractStrategyResponse);
				contractResponse.setStrategyList(strategyList);
			} 
			responseData.setData(contractResponse); 
		}else{
			responseData.setResponseMessage(ResponseMessage.NOT_EXIST);
		}
	}
	@Override
	public void queryContractContent(
			ContractDetailsRequest contractContentRequest,ResponseData<ContractContentResponse> responseData) throws Exception {
		logger.info("queryContractContent 查询参数:"+ GsonUtil.getInstance().toJson(contractContentRequest));
//		long startTime = System.currentTimeMillis();
		//查询合同内容
		ContractQueryParam contractQueryParam = new ContractQueryParam();
		contractQueryParam.setContractId(contractContentRequest.getContractId());
		CreditContract contract = contractService.queryContractById(contractQueryParam); 
		AccountQueryParam accountQueryParam = new AccountQueryParam();
		accountQueryParam.setContractId(contractContentRequest.getContractId()); 
		CreditMerchant creditMerchant = accountService.queryMerchantInfo(accountQueryParam );
		if(contract!=null){
			String downloadPath = makeHtml(contract.getContractId()+"",contract.getContractPath());
			ContractContentResponse contractContentResponse = new ContractContentResponse();
			contractContentResponse.setDownloadPath(contract.getContractPath());  
			contractContentResponse.setHtmlPath(downloadPath); 
			contractContentResponse.setMerchantNo(creditMerchant.getMerchantNo());
			contractContentResponse.setMerchantCode(creditMerchant.getMerchantCode());
			responseData.setData(contractContentResponse); 
		}else{
			responseData.setResponseMessage(ResponseMessage.NOT_EXIST);
			logger.error("queryContractContent 合同不存在:"+ GsonUtil.getInstance().toJson(responseData));
		}
	}
	/**
	 * 生成合同预览html
	 * @param fileName  存储的ptf和html名称，传入合同ID
	 * @param contractPath 数据库保存原始地址
	 * @throws Exception
	 */
	private String makeHtml(String fileName,String contractPath) throws Exception { 
		//生成html
        FreeMarkRender render = new FreeMarkRender(); 
        Template t = new Template();
        String ftlPath = ConfigUtil.getString("contract.view.template.path");
        File  ftlFile = ResourceUtils.getFile(ResourceUtils.CLASSPATH_URL_PREFIX+ftlPath);
        t.setPath(ftlFile.getAbsolutePath());
        String baseHtmlPath = ConfigUtil
                .getString("contract.view.template.baseHtmlPath");
        File file = new File(baseHtmlPath +fileName+".html");
//        if (!file.exists()) {
        	Map<String,Object> map = new HashMap<String, Object>();
        	map.put("filePath", ConfigUtil.getString("contract.view.html.baseUrl")+fileName+".pdf");
        	map.put("jsPath", ConfigUtil.getString("contract.view.html.jsPath"));
        	String parent = file.getParent();
            File dir = new File(parent);
            if(!dir.exists()){
            	dir.mkdirs();
            }
        	  FileOutputStream fos = null;
              PrintStream p = null;
              try {
                  fos = new FileOutputStream(file);
                  p = new PrintStream(fos);
                  p.print(render.renderAsString(t, map));
                  p.flush();
                  logger.info("makeHtml 创建html页面成功:",file.getAbsolutePath());
              } finally {
                  if (null != p) {
                      p.close();
                  }
                  if (null != fos) {
                      try {
                          fos.close();
                      } catch (IOException e) {
                          e.printStackTrace();
                      }
                  }
              }
//        }
        //拷贝pdf
        String destPdfPath = ConfigUtil.getString("contract.view.template.baseHtmlPath");
        File destPdfFile = new File(destPdfPath +fileName+".pdf");
//        if(!destPdfFile.exists()){
        	//拷贝文件到nfs目录
        	 String srcPdfPath = ConfigUtil.getString("contract.view.template.basePdfPath");
             File srcPdfFile = new File(srcPdfPath +contractPath);
             if(srcPdfFile.exists()){
            	 FileUtils.copyFile(srcPdfFile, destPdfFile);
            	 logger.info("makeHtml 拷贝pdf文件成功:",destPdfFile.getAbsolutePath());
             }
//        }
        return file.getName();
    }

	@Override
	public void updateContractVerify(
			ContractVerifyRequest contractVerifyRequest,Response response) throws Exception {
		ContractUpdateParam contractUpdateParam = new ContractUpdateParam();
		contractUpdateParam.setContractId(contractVerifyRequest.getContractId());
		contractUpdateParam.setModifiedDate(new Date());
		contractUpdateParam.setEnsureTime(new Date()); 
		if(contractVerifyRequest.getVerifyStatus().toName().equalsIgnoreCase(ContractVerifyRequestEnum.PASS.toName())){
			//待缴费
			contractUpdateParam.setContractStatus(ContractStatusEnum.NOPAY.toName());
		}else{
			//不通过
			contractUpdateParam.setContractStatus(ContractStatusEnum.MERCHANT_NOPASS.toName());
		}
		//查询合同内容
		ContractQueryParam contractQueryParam = new ContractQueryParam();
		contractQueryParam.setContractId(contractVerifyRequest.getContractId());
		CreditContract contract = contractService.queryContractById(contractQueryParam); 
		if(contract!=null){
		if(!ContractStatusEnum.NOPAY.toName().equalsIgnoreCase(contract.getContractStatus())&&!ContractStatusEnum.VALID.toName().equalsIgnoreCase(contract.getContractStatus())){
			//未确认过
		logger.info("updateContractVerify 更新参数:"+ GsonUtil.getInstance().toJson(contractUpdateParam));
		Integer verifyResult = contractService.updateContractStatus(contractUpdateParam);
		//确认合同则开通账户和执行缴费
		if(verifyResult>0){
			if(contractVerifyRequest.getVerifyStatus().toName().equalsIgnoreCase(ContractVerifyRequestEnum.PASS.toName())){
			logger.info("updateContractVerify 已经确认合同 :"+ GsonUtil.getInstance().toJson(contractUpdateParam));
			//异步处理缴费单和清结算开户
			accountOrPaymentService.execute(contractVerifyRequest.getContractId()); 
			}else{
				logger.error("updateProductStraStatus 已经否决合同:"+ GsonUtil.getInstance().toJson(contractUpdateParam));
			}
		}else{
			response.setResponseMessage(ResponseMessage.DATABASE_ERROR);
		}
		}
	}else{
		response.setResponseMessage(ResponseMessage.NOT_EXIST);
		response.setCode(ContractManageResponseEnum.PARAM_CONTRACTID_ERROR.toName());
		response.setMessage(ContractManageResponseEnum.PARAM_CONTRACTID_ERROR.toDescription()); 
		logger.error("updateProductStraStatus合同不存在:"+ GsonUtil.getInstance().toJson(contractUpdateParam));
	}
	}
}
