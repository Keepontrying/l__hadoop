package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.domain.common.entity.CreditProductBlack;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by anmeng on 2017/4/6.
 */
@Repository
public interface CreditProductBlackDao {
    /**
     * 查询商户黑名单信息
     * @param queryParam
     * @return
     */
    List<CreditProductBlack> queryProductBlack(CreditProductBlack queryParam);
}
