package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.Date;

public class JsfConfig implements Serializable {
    private static final long serialVersionUID = 4004820361790098340L;
    private Long id;

    /**
                   * 产品id
     */
    private String productCode;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * jsf接口类全路径名
     */
    private String interfaceId;

    /**
     * jsf别名
     */
    private String alias;

    /**
     * jfs参数类型类全路径名
     */
    private String argType;

    /**
     * jsf方法名
     */
    private String methodName;

    /**
     * jsf模板json串
     */
    private String argTemplate;
    /**
     * jsf结果模板
     */
    private String resultTemplate;
    /**
     * 接口负责人
     */
    private String erp;

    private String templateFid;

    private String remark;

    private Date createdDate;

    private Date modifiedDate;

    private String requestDesc;

    private String responseDesc;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(String interfaceId) {
        this.interfaceId = interfaceId == null ? null : interfaceId.trim();
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias == null ? null : alias.trim();
    }

    public String getArgType() {
        return argType;
    }

    public void setArgType(String argType) {
        this.argType = argType == null ? null : argType.trim();
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName == null ? null : methodName.trim();
    }

    public String getArgTemplate() {
        return argTemplate;
    }

    public void setArgTemplate(String argTemplate) {
        this.argTemplate = argTemplate == null ? null : argTemplate.trim();
    }

    public String getErp() {
        return erp;
    }

    public void setErp(String erp) {
        this.erp = erp;
    }

    public String getTemplateFid() {
        return templateFid;
    }

    public void setTemplateFid(String templateFid) {
        this.templateFid = templateFid;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getRequestDesc() {
        return requestDesc;
    }

    public void setRequestDesc(String requestDesc) {
        this.requestDesc = requestDesc;
    }

    public String getResponseDesc() {
        return responseDesc;
    }

    public void setResponseDesc(String responseDesc) {
        this.responseDesc = responseDesc;
    }

	public String getResultTemplate() {
		return resultTemplate;
	}

	public void setResultTemplate(String resultTemplate) {
		this.resultTemplate = resultTemplate;
	}
}