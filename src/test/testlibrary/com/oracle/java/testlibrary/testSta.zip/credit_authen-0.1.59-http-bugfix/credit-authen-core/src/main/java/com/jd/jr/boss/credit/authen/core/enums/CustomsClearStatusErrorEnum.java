package com.jd.jr.boss.credit.authen.core.enums;

import java.util.LinkedHashMap;
import java.util.Map;


/** 
* @desciption : 海关MQ返回的清关状态
* @author : yangjinlin@jd.com
* @date ：2017年8月29日 上午10:56:29 
* @version 1.0 
* @return  */
public enum CustomsClearStatusErrorEnum {
	NULL(-1, null, null),
	DATA_PARAM_ERROR(0,"501","输入参数有误"),//
	DATA_COOKIE_EXCP(1,"502","获取cookie信息异常"),//
	DATA_MONGODB_EXCP(2,"503","查询mongoDB异常"),//
	DATA_VERIFY_GET_EXCP(3,"504","获取验证码图片信息异常"),//
	DATA_VERIFY_EXCHANGE_EXCP(4,"505","图片转换异常"),//
	DATA_VERIFY_PARSE_EXCP(5,"506","验证码解析异常"),//
	DATA_MONGODB_ERROR(5,"507","查询MongoDB错误"),//
	DATA_PAGE_EXCP(5,"508","获取页面信息异常"),//
	DATA_VERIFY_EROOR(5,"509","验证码不正确"),//
	DATA_PAGE_DOMS_EXCP(5,"510","获取页面元素信息异常"),//
	DATA_MONGODB_SAVE_ERROR(5,"511","数据存入mongoDb异常"),//
	DATA_HISTORYLINKS_ERROR(5,"512","获取历史信息错误"),//
	UNKNOW(5,"4444","未知错误"),//
    ;

    private Integer code;
    private String name;
    private String description;

    /**
     * @param description 中文描述
     */
    CustomsClearStatusErrorEnum(String description) {
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param description 中文描述
     */
    CustomsClearStatusErrorEnum(Integer code, String description) {
        this.code = code;
        this.description = description;
    }

    /**
     * @param name        英文编码名称
     * @param description 中文描述
     */
    CustomsClearStatusErrorEnum(String name, String description) {
        this.name = name;
        this.description = description;
    }

    /**
     * @param code        数字编码
     * @param name        英文编码名称
     * @param description 中文描述
     */
    CustomsClearStatusErrorEnum(Integer code, String name, String description) {
        this.code = code;
        this.name = name;
        this.description = description;
    }


    /**
     * 获取枚举类型数值编码
     */
    public Integer toCode() {
        return this.code == null ? this.ordinal() : this.code;
    }

    /**
     * 获取枚举类型英文编码名称
     */
    public String toName() {
        return this.name == null ? this.name() : this.name;
    }

    /**
     * 获取枚举类型中文描述
     */
    public String toDescription() {
        return this.description;
    }

    /**
     * 获取枚举类型中文描述
     */
    public String toString() {
        return this.description;
    }

    /**
     * 按数值获取对应的枚举类型
     *
     * @param code 数值
     * @return 枚举类型
     */
    public static CustomsClearStatusErrorEnum enumValueOf(Integer code) {
        CustomsClearStatusErrorEnum[] values = CustomsClearStatusErrorEnum.values();
        CustomsClearStatusErrorEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (code != null && code.equals(values[i].toCode())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 按英文编码获取对应的枚举类型
     *
     * @param name 英文编码
     * @return 枚举类型
     */
    public static CustomsClearStatusErrorEnum enumValueOf(String name) {
        CustomsClearStatusErrorEnum[] values = CustomsClearStatusErrorEnum.values();
        CustomsClearStatusErrorEnum v = NULL;
        for (int i = 0; i < values.length; i++) {
            if (name != null && name.equalsIgnoreCase(values[i].toName())) {
                v = values[i];
                break;
            }
        }
        return v;
    }

    /**
     * 获取枚举类型的所有<数字编码,中文描述>对
     *
     * @return
     */
    public static Map<Integer, String> toCodeDescriptionMap() {
        LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
        for (int i = 0; i < CustomsClearStatusErrorEnum.values().length; i++) {
            if (CustomsClearStatusErrorEnum.values()[i] != NULL) {
                map.put(CustomsClearStatusErrorEnum.values()[i].toCode(), CustomsClearStatusErrorEnum.values()[i].toDescription());
            }
        }
        return map;
    }

    /**
     * 获取枚举类型的所有<英文编码名称,中文描述>对
     *
     * @return
     */
    public static Map<String, String> toNameDescriptionMap() {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        for (int i = 0; i < CustomsClearStatusErrorEnum.values().length; i++) {
            if (CustomsClearStatusErrorEnum.values()[i] != NULL) {
                map.put(CustomsClearStatusErrorEnum.values()[i].toName(), CustomsClearStatusErrorEnum.values()[i].toDescription());
            }
        }
        return map;
    }
}
