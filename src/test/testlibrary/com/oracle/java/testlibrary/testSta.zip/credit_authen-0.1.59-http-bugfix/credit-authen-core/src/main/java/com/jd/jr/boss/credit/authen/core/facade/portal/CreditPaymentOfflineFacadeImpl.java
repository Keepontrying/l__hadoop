package com.jd.jr.boss.credit.authen.core.facade.portal;

import com.jd.jr.boss.credit.authen.core.service.PaymentOfflineService;
import com.jd.jr.boss.credit.domain.common.entity.CreditPaymentOffline;
import com.jd.jr.boss.credit.domain.common.entity.CreditPostBillMonth;
import com.jd.jr.boss.credit.facade.authen.api.CreditPaymentOfflineFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.PaymentOfflineQueryParam;
import com.jd.jr.boss.credit.facade.common.exception.CreditApiException;
import com.jd.jr.boss.credit.facade.common.exception.CreditBusinessException;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.beans.Page;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by anmeng on 2017/9/12.
 */
@Component("creditPaymentOfflineFacade")
public class CreditPaymentOfflineFacadeImpl implements CreditPaymentOfflineFacade {

    private Logger logger= LoggerFactory.getLogger(CreditPaymentOfflineFacadeImpl.class);

    @Resource
    private PaymentOfflineService paymentOfflineService;

    /**
     * 查询收款单列表
     *
     * @param queryParam
     * @return
     */
    @Override
    public Page<CreditPaymentOffline> query(PaymentOfflineQueryParam queryParam) {
        Page<CreditPaymentOffline> page= null;
        try {
            page = paymentOfflineService.query(queryParam);
        } catch (Exception e) {
            logger.error(e);
            throw new CreditBusinessException("查询失败");
        }
        return page;
    }

    /**
     * 创建收款单
     *
     * @param paymentOffline
     */
    @Override
    public void create(CreditPaymentOffline paymentOffline) {
        try {
            paymentOfflineService.create(paymentOffline);
        } catch (CreditBusinessException e) {
            throw e;
        }catch (Exception e) {
            logger.error(e);
            throw new CreditBusinessException("创建失败");
        }
    }
}
