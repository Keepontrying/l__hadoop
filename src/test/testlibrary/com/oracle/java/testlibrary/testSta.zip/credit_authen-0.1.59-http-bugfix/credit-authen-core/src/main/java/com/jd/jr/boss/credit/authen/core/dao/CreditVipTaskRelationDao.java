package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.request.VipTaskQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.VipGroupQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditVipGroup;
import com.wangyin.boss.credit.admin.entity.CreditVipGroupUser;
import com.wangyin.boss.credit.admin.entity.CreditVipTask;
import com.wangyin.boss.credit.admin.entity.CreditVipTaskRelation;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption : 风险预警 目标企业关联企业数据接口类
 * @date ：2018/12/19 09:34
 * @return
 */
@Repository
public interface CreditVipTaskRelationDao {

    /**
     * 新增
     * @param record
     * @return
     */
    int insert(CreditVipTaskRelation record);

    /**
     * 批量插入
     * @param userList
     * @return
     */
    int insertBatchRelations(List<CreditVipTaskRelation> userList);
    /**
     * 主键更新
     * @param vipGroupUser
     * @return
     */
    int updateByPrimaryKeySelective(CreditVipTaskRelation vipGroupUser);

    /**
     * 多条件查询  分页
     * @param queryParam
     * @return
     */
    List<CreditVipTaskRelation> selectVipGroupUserPageByParam(VipTaskQueryParam queryParam);

    /**
     * 多条件查询总记录数  分页
     * @param queryParam
     * @return
     */
    Integer selectVipGroupUserPageCountByParam(VipTaskQueryParam queryParam);

    /**
     * 根据商户id和关联企业名称查询 被监控企业task信息
     * @param relationExsitQryPrm
     * @return
     */
    List<CreditVipTask> selectTaskRelationPageByMerchRela(VipTaskQueryParam relationExsitQryPrm);
}
