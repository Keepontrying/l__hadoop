package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;

/**
 * 违章错误信息
 *
 * @author tangmingbo
 * @data 2017/11/01
 */
public class CarIllegalErrEntity implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7082325388128533132L;
	/**
		 * 车牌号
		 */
	    private String plateNumber;
	    /**
	   	 * 车架号，具体是否必填及长度要求参考各城市要求，从【违章查询条件】接口获取
	   	 */
	       private String vin;
	       /**
	   	 * 发动机号，具体是否必填及长度要求参考各城市要求，从【违章查询条件】接口获取
	   	 */
	       private String engineNo;
	       /**
	        * 错误信息
	        */
	       private String msg;
		/**
		 * @return the plateNumber
		 */
		public String getPlateNumber() {
			return plateNumber;
		}
		/**
		 * @param plateNumber the plateNumber to set
		 */
		public void setPlateNumber(String plateNumber) {
			this.plateNumber = plateNumber;
		}
		/**
		 * @return the vin
		 */
		public String getVin() {
			return vin;
		}
		/**
		 * @param vin the vin to set
		 */
		public void setVin(String vin) {
			this.vin = vin;
		}
		/**
		 * @return the engineNo
		 */
		public String getEngineNo() {
			return engineNo;
		}
		/**
		 * @param engineNo the engineNo to set
		 */
		public void setEngineNo(String engineNo) {
			this.engineNo = engineNo;
		}
		/**
		 * @return the msg
		 */
		public String getMsg() {
			return msg;
		}
		/**
		 * @param msg the msg to set
		 */
		public void setMsg(String msg) {
			this.msg = msg;
		}
}
