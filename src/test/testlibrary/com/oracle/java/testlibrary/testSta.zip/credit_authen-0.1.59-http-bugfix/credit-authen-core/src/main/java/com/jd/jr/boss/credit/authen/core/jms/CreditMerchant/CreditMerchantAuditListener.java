package com.jd.jr.boss.credit.authen.core.jms.CreditMerchant;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.jd.jmq.client.consumer.MessageListener;
import com.jd.jmq.common.message.Message;
import com.jd.jr.boss.credit.authen.core.beans.request.MerchantQueryParam;
import com.jd.jr.boss.credit.authen.core.service.MerchantService;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.response.merchant.GatewayMerchantQueryResponse;
import com.jd.jr.boss.credit.credit.gateway.merchantca.enums.MercCaRasAuditEnum;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.enums.MerchantAuditEnum;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;

/**
 * @author jiangbo
 * @since 2017/4/10
 */
@Component("creditMerchantAuditListener")
public class CreditMerchantAuditListener implements MessageListener {

    private static Logger logger = LoggerFactory.getLogger(CreditMerchantAuditListener.class);

    @Autowired
    MerchantService merchantService;
    @Override
    public void onMessage(List<Message> messages) throws Exception {
        if (messages == null || messages.isEmpty()) {
            logger.warn("CreditMerchantAuditListener message is null");
            return;
        }
        for (Message message : messages) {
            String objectJson=message.getText();
            logger.info("======CreditMerchantAuditListener message handle start======, body part:{}",objectJson);
            Gson gson=new Gson();
            HashMap authenticationInfo= null;
            try {
                authenticationInfo = gson.fromJson(objectJson,HashMap.class);
            } catch (JsonSyntaxException e) {
                logger.error("json消息格式错误："+objectJson);
                return;
            }
            try {
                String merchantNo = (String) authenticationInfo.get("merchantNo");
                if (StringUtils.isBlank(merchantNo)){
                    logger.error("CreditMerchantAuditListener, merchantNo is null");
                    return;
                }
                MerchantQueryParam merchantQryParam = new MerchantQueryParam();
                merchantQryParam.setMerchantNo(merchantNo);
                List<CreditMerchant> creditMerchantList = merchantService.queryMerchantByParam(merchantQryParam);
                //如果库里存在该商户
                if (creditMerchantList != null && creditMerchantList.size() == 1 && creditMerchantList.get(0).getMerchantNo().equals(merchantNo)){
                    CreditMerchant creditMerchant = new CreditMerchant();
                    creditMerchant.setMerchantId(creditMerchantList.get(0).getMerchantId());
                    CreditMerchant queryCreditMerchantByHttp = new CreditMerchant();
                    queryCreditMerchantByHttp.setMerchantNo(merchantNo);
                    GatewayMerchantQueryResponse gatewayMerchantQueryResponse = merchantService.queryMerchantInfoByHttp(queryCreditMerchantByHttp);
                    if (!gatewayMerchantQueryResponse.getMerchant().equals(merchantNo)){
                        logger.error("CreditMerchantAuditListener, gatewayMerchantQueryResponse merchantNo is not equals paramMerchantNo:{}", merchantNo);
                        return;
                    }
//                    System.out.println(gatewayMerchantQueryResponse.toString());
                    if (MercCaRasAuditEnum.enumValueOfDes(gatewayMerchantQueryResponse.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_ING){
                        creditMerchant.setAuditStatus(MerchantAuditEnum.WAIT_RISK.getCode());
                        creditMerchant.setMerchantName(gatewayMerchantQueryResponse.getCompanyName());
                    }else if (MercCaRasAuditEnum.enumValueOfDes(gatewayMerchantQueryResponse.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_SUCCESS){
//                        creditMerchant.setAuditStatus(MerchantAuditEnum.WAIT_BUSINESS.getCode());
                        creditMerchant.setAuditStatus(MerchantAuditEnum.PASS_BUSINESS.getCode());
                        creditMerchant.setMerchantName(gatewayMerchantQueryResponse.getCompanyName());
                    }else if (MercCaRasAuditEnum.enumValueOfDes(gatewayMerchantQueryResponse.getMerchantCaStatus()) == MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_EXPIRE){
                        creditMerchant.setAuditStatus(MerchantAuditEnum.CER_EXPIRE.getCode());
                        creditMerchant.setMerchantName(gatewayMerchantQueryResponse.getCompanyName());
                    }else {
                        creditMerchant.setAuditStatus(MerchantAuditEnum.NOT_CERTIFIED.getCode());
                        creditMerchant.setMerchantName(gatewayMerchantQueryResponse.getCompanyName());
                    }
                    //这里没有判断更新审核状态
                    int resultUpdate = merchantService.updateByPrimaryKeySelective(creditMerchant);
                    if (resultUpdate > 0){
                        logger.info("update AuditStatus success, creditMerchant:{}",ReflectionToStringBuilder.toString(creditMerchant));
                    }else {
                        logger.error("update AuditStatus error, creditMerchant:{}", ReflectionToStringBuilder.toString(creditMerchant));
                        return;
                    }
                }else {
                    logger.info("merchantNo:{}, is not credit merchant,skip",merchantNo);
                }
            } catch (Exception e) {
                logger.error("CreditMerchantAuditListener error", e);
            }
        }
    }
}
