package com.jd.jr.boss.credit.authen.core.dao;

import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface CreditVipEventTypeDao {
    /**
     * 通过code获取name
     * @param triggerEventType
     * @return
     */
    String getVipEventTypeName(String triggerEventType);
}