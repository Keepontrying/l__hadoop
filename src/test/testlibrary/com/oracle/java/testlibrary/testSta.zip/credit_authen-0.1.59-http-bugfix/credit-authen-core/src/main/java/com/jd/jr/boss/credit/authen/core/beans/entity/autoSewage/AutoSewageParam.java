package com.jd.jr.boss.credit.authen.core.beans.entity.autoSewage;

import java.io.Serializable;

/**
 * Created by liuwei55@jd.com
 *
 * @version 1.0
 * @date : 2018/3/16.
 * @return
 */
public class AutoSewageParam implements Serializable {

    private static final long serialVersionUID = 8940873635953392215L;
    private String systemId;
    private String fileUrl;
    private String batchNo;
    private String merchantNo;

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }
}
