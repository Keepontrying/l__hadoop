package com.jd.jr.boss.credit.core.test.signCode;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.CreditCompanyInfo;
import com.wangyin.operation.utils.GsonUtil;

public class TaskCallable implements Callable<Map<Integer,List<CompanyParam>>> {
	private static Logger logger = LoggerFactory.getLogger(TaskCallable.class);
	private List<List<String>> dataList;
	private String applyUrl;
	private int threadNum;
	public TaskCallable(List<List<String>> list,String applyUrl,int threadNum) throws Exception {
		this.dataList = list;
		this.applyUrl = applyUrl;
		this.threadNum = threadNum;
	}
	@Override
	public Map<Integer,List<CompanyParam>> call() throws Exception {
		Thread.currentThread().setName("查询企业信息线程-"+threadNum);
		long currentTime = System.currentTimeMillis();
		logger.info(Thread.currentThread().getName()+"，处理开始");
		Map<Integer,List<CompanyParam>> map = new HashMap<Integer, List<CompanyParam>>();
		List<CompanyParam> sheetList = new LinkedList<CompanyParam>();
		int index=(threadNum-1)*dataList.size()+1;
		for(List<String> rows:dataList){
			if(rows!=null&&rows.size()>=1){
			String name = rows.get(0).trim();
			String result=post(applyUrl+name,"","");
			CreditCompanyInfo companyInfo = GsonUtil.getInstance().fromJson(result, CreditCompanyInfo.class);
			CompanyParam company = new CompanyParam();
			company.setSerialNo(index+"");
			company.setName(companyInfo.getOriginalName());
			company.setCreditCode(companyInfo.getCreditCode());
			company.setRegNo(companyInfo.getRegNo());
			company.setOrgNo(companyInfo.getOrgNo());
			sheetList.add(company);
			index++;
			}
		}
		map.put(threadNum, sheetList);
		logger.info(Thread.currentThread().getName()+"，处理完成,耗时s："+(System.currentTimeMillis()-currentTime)/1000);
		return map;
	}
	public static String post(String httpUrl,String merchantNo, String httpArg) {
	    BufferedReader reader = null;
	    String result = null;
	    StringBuffer sbf = new StringBuffer();
	    try {
	        URL url = new URL(httpUrl);
	        HttpURLConnection connection = (HttpURLConnection) url
	                .openConnection();
	        connection.setRequestMethod("POST");
	        //设置传输协议，重要
	        connection.setRequestProperty("Content-Type",
	                        "application/json; charset=utf-8");
	        //设置商户号，重要
	        connection.setRequestProperty("merchantNo",  merchantNo);
	        connection.setDoOutput(true);
	        connection.getOutputStream().write(httpArg.getBytes("UTF-8"));
	        connection.connect();
	        InputStream is = connection.getInputStream();
	        reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
	        String strRead = null;
	        while ((strRead = reader.readLine()) != null) {
	            sbf.append(strRead);
	            sbf.append("\r\n");
	        }
	        result = sbf.toString();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }finally{
	    	try {
	    		if(reader!=null){
				reader.close();
	    		}
			} catch (IOException e) {
				e.printStackTrace();
			}
	    }
	    return result;
	}
}
