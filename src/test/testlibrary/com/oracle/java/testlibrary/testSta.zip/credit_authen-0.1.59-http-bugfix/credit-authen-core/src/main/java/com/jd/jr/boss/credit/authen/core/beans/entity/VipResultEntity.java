package com.jd.jr.boss.credit.authen.core.beans.entity;

import org.apache.poi.ss.formula.functions.T;

import java.io.Serializable;

/**
 * Description:
 * User: yangjinlin@jd.com
 * Date: 2018/8/31 15:32
 * Version: 1.0
 */
public class VipResultEntity<T> implements Serializable {

    private static final long serialVersionUID = -6923257511496959337L;

    public String time;
    public T dataInfo;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public T getDataInfo() {
        return dataInfo;
    }

    public void setDataInfo(T dataInfo) {
        this.dataInfo = dataInfo;
    }
}
