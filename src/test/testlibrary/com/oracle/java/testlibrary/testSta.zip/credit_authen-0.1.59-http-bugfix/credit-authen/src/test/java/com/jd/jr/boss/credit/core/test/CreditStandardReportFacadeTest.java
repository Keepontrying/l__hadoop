package com.jd.jr.boss.credit.core.test;

import com.jd.jr.boss.credit.facade.authen.api.CreditStandardReportFacade;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * Created by zhanghui12 on 2018/5/22.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})
public class CreditStandardReportFacadeTest {
    @Resource
    private CreditStandardReportFacade creditStandardReportFacade;

    @Test
    public void createReportTest(){
        CreditRequestParam<String> requestParam=new CreditRequestParam<String>();
        //201805221032483661777597  北京瑞友科技股份有限公司
        requestParam.setParam("201811150954473151777287");//201808231647223941777584 data
        creditStandardReportFacade.createReport(requestParam);
    }
}
