package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.request.UploadFileQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditUploadFile;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by anmeng on 2017/7/27.
 */
@Repository
public interface CreditUploadFileDao {

    /**
     * 保存上传文件
     * @param creditUploadFile
     */
    int insert(CreditUploadFile creditUploadFile);

    /**
     * 查询上传文件列表
     * @param queryParam
     * @return
     */
    List<CreditUploadFile> selectByParam(UploadFileQueryParam queryParam);

    /**
     * 根据主键id更新文件信息
     * @param uploadFile
     * @return
     */
    int updateFileById(CreditUploadFile uploadFile);
}
