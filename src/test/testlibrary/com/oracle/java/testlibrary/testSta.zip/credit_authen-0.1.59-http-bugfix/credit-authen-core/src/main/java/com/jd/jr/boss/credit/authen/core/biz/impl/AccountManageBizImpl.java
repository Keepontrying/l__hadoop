package com.jd.jr.boss.credit.authen.core.biz.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jd.jr.boss.credit.authen.core.service.*;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;
import com.jd.jr.boss.credit.domain.common.entity.CreditPayment;
import com.jd.jr.boss.credit.domain.common.enums.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.authen.core.beans.entity.ProductStrategyEntity;
import com.jd.jr.boss.credit.authen.core.beans.request.AccountPageQueryParam;
import com.jd.jr.boss.credit.authen.core.beans.request.AccountQueryParam;
import com.jd.jr.boss.credit.authen.core.beans.request.ContractQueryParam;
import com.jd.jr.boss.credit.authen.core.beans.request.ContractUpdateParam;
import com.jd.jr.boss.credit.authen.core.beans.request.ProductStrategyQueryParam;
import com.jd.jr.boss.credit.authen.core.biz.AccountManageBiz;
import com.jd.jr.boss.credit.authen.core.enums.PaymentChannelEnum;
import com.jd.jr.boss.credit.domain.common.constants.PaymentOrderConstants;
import com.jd.jr.boss.credit.facade.authen.beans.param.ProductQueryParam;
import com.jd.jr.boss.credit.facade.site.api.dto.entity.PaymentPackageEntity;
import com.jd.jr.boss.credit.facade.site.api.dto.request.account.AccountChargeRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.account.AccountPackageRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.account.AccountQueryRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.account.AccountDetailsResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.account.AccountPackageResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.account.AccountQueryResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.paymentupdate.PaymentUpdateResponse;
import com.jd.jr.boss.credit.facade.site.api.enums.response.AccountManageResponseEnum;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountConsumeRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountQueryRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountRechargeRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.payment.GatewayPaymentCancelRequest;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccounTradeResponse;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccountQueryResponse;
import com.jd.jr.boss.credit.gateway.account.facade.finance.GatewayAccountFacade;
import com.jd.jr.boss.credit.gateway.account.facade.payment.GatewayPaymentOrderFacade;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditMerchantAccount;
import com.wangyin.boss.credit.admin.entity.CreditProduct;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import com.wangyin.boss.credit.admin.enums.ChargeTypeEnum;
import com.wangyin.boss.payment.api.dto.PaymentOrderResponseDTO;
import com.wangyin.commons.util.Logger;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.Response;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;

@Service
public class AccountManageBizImpl implements AccountManageBiz {
    private Logger logger = new Logger(AccountManageBizImpl.class);
    @Autowired
    private AccountService accountService;
    @Autowired
    private ProductService productService;
    @Autowired
    private ContractService contractService;
    @Autowired
    private GatewayAccountFacade accountFacade;

    @Autowired
    private OrderService orderService;


    @Autowired
    private PaymentService paymentService;

    @Override
    public void updateAccountBalance(
            AccountChargeRequest accountChargeRequest, Response response)
            throws Exception {
        AccountQueryParam accountQueryParam = new AccountQueryParam();
        //依据商户号查询清结算账号
        accountQueryParam.setMerchantNo(accountChargeRequest.getMerchantNo());
        accountQueryParam.setChargeType(ProductChargeTypeEnum.SINGLE.toName());
        CreditMerchantAccount merchantAccount = accountService.queryAccountNo(accountQueryParam);
        //判定该商户是否存在对应清结算账户
        if (merchantAccount != null && StringUtils.isNotBlank(merchantAccount.getAccountNo())) {
            //设置清结算充值参数
            RequestParam<GatewayAccountRechargeRequest> requestParam = new RequestParam<GatewayAccountRechargeRequest>();
            GatewayAccountRechargeRequest rechargeRequest = new GatewayAccountRechargeRequest();
            rechargeRequest.setAccountNo(merchantAccount.getAccountNo());
            rechargeRequest.setTradeAmt(accountChargeRequest.getMoney());
            rechargeRequest.setOrderNo(accountChargeRequest.getTradeNo());
            requestParam.setParam(rechargeRequest);
            logger.info("updateAccountBalance 商户充值参数:" + GsonUtil.getInstance().toJson(requestParam));
            ResponseData<GatewayAccounTradeResponse> chargeResult = accountFacade.accountRecharge(requestParam);
            if (chargeResult.isSuccess()) {
                logger.info("updateAccountBalance 商户充值成功 :" + GsonUtil.getInstance().toJson(chargeResult));
            } else {
                logger.error("updateAccountBalance 商户充值失败:" + GsonUtil.getInstance().toJson(chargeResult));
                response.setResponseMessage(ResponseMessage.DATABASE_ERROR);
            }
        } else {
            logger.error("updateAccountBalance 商户未开户:" + GsonUtil.getInstance().toJson(accountQueryParam));
            response.setResponseMessage(ResponseMessage.NOT_EXIST);
        }
    }

    @Override
    public ResponseData<AccountQueryResponse> queryBalance(
            AccountQueryRequest accountQueryRequest,
            ResponseData<AccountQueryResponse> responseData) throws Exception {
        logger.info("queryBalance 查询参数:" + GsonUtil.getInstance().toJson(accountQueryRequest));
        //依据商户号查询对应的商户信息
        AccountQueryParam accountQueryParam = new AccountQueryParam();
        accountQueryParam.setMerchantNo(accountQueryRequest.getMerchantNo());
        CreditMerchant merchant = accountService.queryMerchantInfo(accountQueryParam);
        if (merchant == null) {
            responseData.setResponseMessage(ResponseMessage.NOT_EXIST);
            responseData.setCode(AccountManageResponseEnum.RESULT_MERCHANTNO_NOTEXIST.toName());
            responseData.setMessage(AccountManageResponseEnum.RESULT_MERCHANTNO_NOTEXIST.toDescription());
            logger.error("queryBalance 账户不存在:" + GsonUtil.getInstance().toJson(merchant));
            return responseData;
        }
        //设置账户号和余额
        AccountQueryResponse accountQueryResponse = new AccountQueryResponse();
        responseData.setData(accountQueryResponse);
        accountQueryResponse.setMerchantId(merchant.getMerchantId());
        accountQueryResponse.setMerchantNo(merchant.getMerchantNo());
        accountQueryResponse.setMerchantName(merchant.getMerchantName());
        accountQueryResponse.setMerchantCode(merchant.getMerchantCode());
        accountQueryResponse.setBalance(0L);
        //依据商户号查询清结算账户号
        accountQueryParam.setChargeType(ProductChargeTypeEnum.SINGLE.toName());
        CreditMerchantAccount merchantAccount = accountService.queryAccountNo(accountQueryParam);
        if (merchantAccount != null) {
            //商户为开通单笔产品则不存在清结算账户，因此默认余额为0
            //依据清结算账号查询余额信息
            RequestParam<GatewayAccountQueryRequest> accountRequestParam = new RequestParam<GatewayAccountQueryRequest>();
            GatewayAccountQueryRequest gatewayAccountQueryRequest = new GatewayAccountQueryRequest();
            gatewayAccountQueryRequest.setAccountNo(merchantAccount.getAccountNo());
            accountRequestParam.setParam(gatewayAccountQueryRequest);
            ResponseData<GatewayAccountQueryResponse> accountResponseData = accountFacade.queryAccountInfo(accountRequestParam);
            if (accountResponseData.isSuccess()) {
                logger.info("queryBalance 单笔清结算余额查询成功:" + GsonUtil.getInstance().toJson(accountResponseData));
                accountQueryResponse.setBalance(accountResponseData.getData().getBalance());
            } else {
                logger.error("queryBalance 单笔清结算余额查询失败:" + GsonUtil.getInstance().toJson(accountResponseData));
            }
        } else {
            logger.error("queryBalance 清结算账户未开户:" + GsonUtil.getInstance().toJson(accountQueryParam));
        }
        if (accountQueryRequest.getStrategyId() != null) {
            //单个计费查询余额
            return queryBalanceByStrategyId(accountQueryRequest.getStrategyId(), responseData);
        } else {
            //所有计费查询
            return queryAccountBalance(merchant.getMerchantId(), responseData);
        }
    }

    /**
     * 查询商户单个计费产品余额
     *
     * @param responseData
     * @return
     * @throws Exception
     */
    private ResponseData<AccountQueryResponse> queryBalanceByStrategyId(Integer strategyId,
                                                                        ResponseData<AccountQueryResponse> responseData) throws Exception {
        //依据策略id查询计费产品详情
        ProductStrategyQueryParam productStrategyQueryParam = new ProductStrategyQueryParam();
        productStrategyQueryParam.setStrategyId(strategyId);
        List<String> chargeTypeList = new ArrayList<String>();
        chargeTypeList.add(ProductChargeTypeEnum.PACKAGE.toName());
        productStrategyQueryParam.setChargeTypeList(chargeTypeList);
//		 productStrategyQueryParam.setStrategyStatus(OpenOrCloseStatusEnum.OPEN.toName());//单个产品可以查询状态已经关闭的
        ProductStrategyEntity productStrategy = productService.queryStrategyById(productStrategyQueryParam);
        logger.info("queryBalanceByStrategyId 计费产品:" + GsonUtil.getInstance().toJson(productStrategy));
        if (productStrategy != null) {
            if (StringUtils.isBlank(productStrategy.getAccountNo())) {
                //不存在清结算账号则退出
                responseData.setResponseMessage(ResponseMessage.NOT_EXIST);
                responseData.setCode(AccountManageResponseEnum.RESULT_ACCOUNT_NOTEXIST.toName());
                responseData.setMessage(AccountManageResponseEnum.RESULT_ACCOUNT_NOTEXIST.toDescription() + ":产品策略ID" + productStrategy.getStrategyId());
                logger.error("queryBalanceByStrategyId 清结算未账户:" + GsonUtil.getInstance().toJson(productStrategy));
                return responseData;
            }
            //依据清结算账号查询余额信息
            RequestParam<GatewayAccountQueryRequest> accountRequestParam = new RequestParam<GatewayAccountQueryRequest>();
            GatewayAccountQueryRequest gatewayAccountQueryRequest = new GatewayAccountQueryRequest();
            gatewayAccountQueryRequest.setAccountNo(productStrategy.getAccountNo());
            accountRequestParam.setParam(gatewayAccountQueryRequest);
            logger.info("queryBalanceByStrategyId 包量清结算账户查询参数:" + GsonUtil.getInstance().toJson(accountRequestParam));
            ResponseData<GatewayAccountQueryResponse> accountResponseData = accountFacade.queryAccountInfo(accountRequestParam);
            if (!accountResponseData.isSuccess()) {
                responseData.setResponseMessage(ResponseMessage.DATABASE_ERROR);
                responseData.setCode(accountResponseData.getCode());
                responseData.setMessage(accountResponseData.getMessage() + ":产品策略ID" + productStrategy.getStrategyId());
                logger.error("queryBalanceByStrategyId 包量清结算余额查询失败:" + GsonUtil.getInstance().toJson(accountResponseData));
                return responseData;
            }
            //设置包量信息和余额
            List<AccountDetailsResponse> accountDetailsList = new ArrayList<AccountDetailsResponse>();
            AccountDetailsResponse accountDetails = new AccountDetailsResponse();
            accountDetails.setStrategyId(productStrategy.getStrategyId());
            accountDetails.setProductId(productStrategy.getProductId());
            accountDetails.setProductName(productStrategy.getProductName());
            accountDetails.setChargeType(ProductChargeTypeEnum.PACKAGE);
            accountDetails.setStartTime(productStrategy.getStartTime());
            accountDetails.setFinishTime(productStrategy.getFinishTime());
            accountDetails.setAmount(productStrategy.getAmount());
            accountDetails.setPacketCount(productStrategy.getPacketCount());
            accountDetails.setBalance(accountResponseData.getData().getBalance());
            accountDetailsList.add(accountDetails);
            responseData.getData().setAccountDetailsList(accountDetailsList);
        } else {
            responseData.setResponseMessage(ResponseMessage.NOT_EXIST);
            responseData.setCode(AccountManageResponseEnum.RESULT_ACCOUNT_NOTEXIST.toName());
            responseData.setMessage(AccountManageResponseEnum.RESULT_ACCOUNT_NOTEXIST.toDescription() + ":产品策略ID" + strategyId);
        }
        return responseData;
    }

    /**
     * 查询商户所有计费产品余额
     * 1、余量查询：单笔，如果当前没有生效计费则推送“当前无生效中单笔计费“，如果有生效中计费则推送单笔计费产品合集
     * 2、余额查询：包量，如果当前有生效计费产品或者未来有计费产品则返回最近一条计费产品，如果当前没有计费产品和未来也没有计费产品，则最近一条过期的计费产品
     *
     * @param responseData
     * @return
     * @throws Exception
     */
    private ResponseData<AccountQueryResponse> queryAccountBalance(Integer merchantId,
                                                                   ResponseData<AccountQueryResponse> responseData) throws Exception {
//		long startTime = System.currentTimeMillis();
        StringBuffer singleProductBuffer = new StringBuffer();
        int singleProductId = 0;
        List<AccountDetailsResponse> accountDetailsList = new ArrayList<AccountDetailsResponse>();
        responseData.getData().setAccountDetailsList(accountDetailsList);
        //依据商户id查询计费产品详情
        ProductStrategyQueryParam productStrategyQueryParam = new ProductStrategyQueryParam();
        productStrategyQueryParam.setMerchantId(merchantId);
        //查询商户对应的合同列表，且状态为有效和履行结束
        ContractQueryParam contractQueryParam = new ContractQueryParam();
        contractQueryParam.setMerchantId(merchantId);
        List<String> contractStatusList = new ArrayList<String>();
        contractStatusList.add(ContractStatusEnum.VALID.toName());
        contractStatusList.add(ContractStatusEnum.TERMINATE.toName());
        contractQueryParam.setContractStatusList(contractStatusList);
        List<CreditContract> contractList = contractService.queryContractByParam(contractQueryParam);
        if (contractList != null && contractList.size() > 0) {
            List<Integer> contractIdList = new ArrayList<Integer>();
            for (CreditContract contract : contractList) {
                contractIdList.add(contract.getContractId());
            }
            //将查询的的合同ID加入计费列表查询参数
            productStrategyQueryParam.setContractIdList(contractIdList);
            //		 productStrategyQueryParam.setStrategyStatus(OpenOrCloseStatusEnum.OPEN.toName()); //所有计费只查询状态正常的
//		 productStrategyQueryParam.setChargeType(ProductChargeTypeEnum.PACKAGE.toName());
            //过期产品不查询且状态应该置为无效
            List<ProductStrategyEntity> productStrategyList = productService.queryStrategyList(productStrategyQueryParam);
            logger.info("queryAccountBalance 计费产品列表:" + GsonUtil.getInstance().toJson(productStrategyList));
            /**
             * 依据商户ID查询有效征信产品信息，相同单笔产品只显示其中一条，相同包量产品只显示其中一条
             * 过期产品不查询
             */
            if (productStrategyList != null && productStrategyList.size() > 0) {
                Map<String, ProductStrategyEntity> validProductMap = new HashMap<String, ProductStrategyEntity>();
                long currentDate = new Date().getTime();
                RequestParam<GatewayAccountQueryRequest> accountRequestParam = new RequestParam<GatewayAccountQueryRequest>();
                GatewayAccountQueryRequest gatewayAccountQueryRequest = new GatewayAccountQueryRequest();
                for (ProductStrategyEntity productStrategy : productStrategyList) {
                    Date strategyStartDate = new DateTime(productStrategy.getStartTime()).toDate();
                    Date strategyFinishDate = new DateTime(productStrategy.getFinishTime()).plusDays(1).toDate();
                    String key = productStrategy.getChargeType() + productStrategy.getProductId();
            /*if(currentDate>=strategyFinishDate.getTime()){
                //防止过期产品状态仍为正常状态的产品加入列表
				if(ChargeTypeEnum.SINGLE.getCode().equalsIgnoreCase(productStrategy.getChargeType())){
					//包量产品如果没有有效计费或者未来没有有效计费，则选取最近一条过期的计费产品
					continue;
				}
			}*/
                    if (ChargeTypeEnum.PACKAGE.toName().equalsIgnoreCase(productStrategy.getChargeType())) {
                        //单笔和包量相同的产品全部筛选出一条
                        if (!validProductMap.containsKey(key)) {
                            //不存在并且在有效期内的则添加到map中
                            //防止过期产品状态仍为正常状态的产品加入列表
//				if(currentDate<strategyFinishDate.getTime()){
                            validProductMap.put(key, productStrategy);
//				}
                        } else {
                            ProductStrategyEntity existProduct = validProductMap.get(key);
                            Date existStartDate = new DateTime(existProduct.getStartTime()).toDate();
                            Date existFinishDate = new DateTime(existProduct.getFinishTime()).plusDays(1).toDate();
                            //存在多条记录，新产品策略有效期包含该当前时间，已存策略有效期在当前时间之后
                            if (existFinishDate.getTime() <= currentDate && strategyFinishDate.getTime() <= currentDate) {
                                //过期产品和过期产品比较0
                                if (existFinishDate.getTime() == strategyFinishDate.getTime()) {
                                    //结束日期一样则去开始时间靠后的
                                    if (existStartDate.getTime() == strategyStartDate.getTime()) {
                                        //开始日期一样，取创建时间晚的
                                        if (existProduct.getStrategyId() < productStrategy.getStrategyId()) {
                                            validProductMap.put(key, productStrategy);
                                        }
                                    } else if (existStartDate.getTime() < strategyStartDate.getTime()) {
                                        //开始日期不一样，取开始时间晚的
                                        validProductMap.put(key, productStrategy);
                                    }
                                } else if (existFinishDate.getTime() < strategyFinishDate.getTime()) {
                                    //结束时间不一样，取结束时间晚的
                                    validProductMap.put(key, productStrategy);
                                }
                            } else if ((existFinishDate.getTime() <= currentDate && strategyStartDate.getTime() > currentDate) ||
                                    ((existFinishDate.getTime() <= currentDate || existStartDate.getTime() > currentDate) && strategyStartDate.getTime() <= currentDate && strategyFinishDate.getTime() > currentDate)) {
                                //过期产品和有效期内比较1
                                //过期产品和即将生效比较2
                                //即将 生效和有效期产品比较2
                                validProductMap.put(key, productStrategy);
                            } else if ((existStartDate.getTime() <= currentDate && existFinishDate.getTime() > currentDate
                                    && strategyStartDate.getTime() <= currentDate && strategyFinishDate.getTime() > currentDate) ||
                                    (existStartDate.getTime() > currentDate && strategyStartDate.getTime() > currentDate)) {
                                //有效期内产品和有效期内产品比较0
                                //即将生效和有即将生效比较0
                                //新产品策略和已存策略有效期全都包含当前时间
                                //新产品策略和已存策略有效期全都在当前时间之后
//					if(existProduct.getStartTime().getTime()<=currentDate&&strategyStartDate.getTime()<=currentDate)
//					if(strategyStartDate.getTime()>currentDate&&existProduct.getStartTime().getTime()>currentDate)
                                //查询已经存在计费的余额
                                gatewayAccountQueryRequest.setAccountNo(existProduct.getAccountNo());
                                accountRequestParam.setParam(gatewayAccountQueryRequest);
                                ResponseData<GatewayAccountQueryResponse> existAccount = accountFacade.queryAccountInfo(accountRequestParam);
                                //查询新计费的余额
                                gatewayAccountQueryRequest.setAccountNo(productStrategy.getAccountNo());
                                accountRequestParam.setParam(gatewayAccountQueryRequest);
                                ResponseData<GatewayAccountQueryResponse> newAccount = accountFacade.queryAccountInfo(accountRequestParam);
                                if (existStartDate.getTime() == strategyStartDate.getTime()) {
                                    //开始日期一样则去结束时间靠前的
                                    if (existFinishDate.getTime() == strategyFinishDate.getTime()) {
                                        //结束时间一样，取创建时间早的
                                        if (existProduct.getStrategyId() > productStrategy.getStrategyId()) {
                                            if (existAccount.isSuccess() && newAccount.isSuccess()) {
                                                if (newAccount.getData().getBalance() != 0) {
                                                    //已经存在计费余额为0
                                                    validProductMap.put(key, productStrategy);
                                                } else {
                                                    if (existAccount.getData().getBalance() == 0) {
                                                        //已经存在计费余额不为0，新计费不为0
                                                        validProductMap.put(key, productStrategy);
                                                    }
                                                }
                                            }
                                        } else {
                                            if (existAccount.isSuccess() && newAccount.isSuccess()) {
                                                if (existAccount.getData().getBalance() == 0) {
                                                    if (newAccount.getData().getBalance() != 0) {
                                                        //已经存在计费余额不为0，新计费不为0
                                                        validProductMap.put(key, productStrategy);
                                                    }
                                                }
                                            }
                                        }
                                    } else if (existFinishDate.getTime() > strategyFinishDate.getTime()) {
                                        //结束时间不一样，取结束时间早的
                                        if (existAccount.isSuccess() && newAccount.isSuccess()) {
                                            if (existAccount.getData().getBalance() == 0) {
                                                //已经存在计费余额为0
                                                validProductMap.put(key, productStrategy);
                                            } else {
                                                if (newAccount.getData().getBalance() != 0) {
                                                    //已经存在计费余额不为0，新计费不为0
                                                    validProductMap.put(key, productStrategy);
                                                }
                                            }
                                        }
                                    }
                                } else if (existStartDate.getTime() > strategyStartDate.getTime()) {
                                    //开始时间不一样，取开始时间早的
                                    if (existAccount.isSuccess() && newAccount.isSuccess()) {
                                        if (existAccount.getData().getBalance() == 0) {
                                            //已经存在计费余额为0
                                            validProductMap.put(key, productStrategy);
                                        } else {
                                            if (newAccount.getData().getBalance() != 0) {
                                                //已经存在计费余额不为0，新计费不为0
                                                validProductMap.put(key, productStrategy);
                                            }
                                        }
                                    }
                                }
                            }
                            //有效期内产品和过期产品比较1
                            //有效期内产品和即将生效比较3
                            //即将 生效和过期产品比较2
                        }
                    } else {
                        //单笔只取在有效期内的计费产品
                        if (strategyStartDate.getTime() <= currentDate && currentDate < strategyFinishDate.getTime()) {
                            if (!validProductMap.containsKey(key)) {
                                //不存在并且在有效期内的则添加到map中
                                validProductMap.put(key, productStrategy);
                            } else {
                                ProductStrategyEntity existProduct = validProductMap.get(key);
                                Date existStartDate = new DateTime(existProduct.getStartTime()).toDate();
                                Date existFinishDate = new DateTime(existProduct.getFinishTime()).plusDays(1).toDate();
                                //新产品策略和已存策略有效期全都包含当前时间
                                if (existStartDate.getTime() == strategyStartDate.getTime()) {
                                    //开始日期一样则去结束时间靠前的
                                    if (existFinishDate.getTime() == strategyFinishDate.getTime()) {
                                        //结束时间一样，取创建时间早的
                                        if (existProduct.getStrategyId() > productStrategy.getStrategyId()) {
                                            validProductMap.put(key, productStrategy);
                                        }
                                    } else if (existFinishDate.getTime() > strategyFinishDate.getTime()) {
                                        //结束时间不一样，取结束时间早的
                                        validProductMap.put(key, productStrategy);
                                    }
                                } else if (existStartDate.getTime() > strategyStartDate.getTime()) {
                                    //开始时间不一样，取开始时间早的
                                    validProductMap.put(key, productStrategy);
                                }
                            }
                        }
                    }
                }
                logger.info("queryAccountBalance 有效计费产品筛选后列表:" + GsonUtil.getInstance().toJson(validProductMap));
                /********包量产品中无有效产品则筛选已经过期的产品************/
                /*** 设置返回详情数据 ***/

                for (ProductStrategyEntity productStrategy : validProductMap.values()) {
                    if (ProductChargeTypeEnum.PACKAGE.toName().equalsIgnoreCase(productStrategy.getChargeType())) {
                        AccountDetailsResponse accountDetails = new AccountDetailsResponse();
                        //多条相同计费，筛选出一条
                        if (StringUtils.isBlank(productStrategy.getAccountNo())) {
                            //不存在清结算账号则退出
//					responseData.setResponseMessage(ResponseMessage.NOT_EXIST);
//					responseData.setCode(AccountManageResponseEnum.RESULT_ACCOUNT_NOTEXIST.toName());
//					responseData.setMessage(AccountManageResponseEnum.RESULT_ACCOUNT_NOTEXIST.toDescription()+":产品策略ID"+productStrategy.getStrategyId());
                            logger.error("queryAccountBalance 清结算未账户:" + GsonUtil.getInstance().toJson(productStrategy));
//					break;
                            continue;
                        }
                        //依据清结算账号查询余额信息
                        gatewayAccountQueryRequest.setAccountNo(productStrategy.getAccountNo());
                        accountRequestParam.setParam(gatewayAccountQueryRequest);
                        logger.info("queryAccountBalance 包量清结算账户查询参数:" + GsonUtil.getInstance().toJson(accountRequestParam));
                        ResponseData<GatewayAccountQueryResponse> accountResponseData = accountFacade.queryAccountInfo(accountRequestParam);
                        if (!accountResponseData.isSuccess()) {
//					 	responseData.setResponseMessage(ResponseMessage.DATABASE_ERROR);
//						responseData.setCode(accountResponseData.getCode());
//						responseData.setMessage(accountResponseData.getMessage()+":产品策略ID"+productStrategy.getStrategyId());
                            logger.error("queryAccountBalance 包量清结算余额查询失败:" + GsonUtil.getInstance().toJson(accountResponseData));
//						break;
                            continue;
                        }
                        //设置包量信息和余额

                        accountDetails.setStrategyId(productStrategy.getStrategyId());
                        accountDetails.setProductId(productStrategy.getProductId());
                        accountDetails.setProductName(productStrategy.getProductName());
                        accountDetails.setChargeType(ProductChargeTypeEnum.PACKAGE);
                        accountDetails.setStartTime(productStrategy.getStartTime());
                        accountDetails.setFinishTime(productStrategy.getFinishTime());
                        accountDetails.setAmount(productStrategy.getAmount());
                        accountDetails.setPacketCount(productStrategy.getPacketCount());
                        accountDetails.setBalance(accountResponseData.getData().getBalance());
                        accountDetailsList.add(accountDetails);
                    } else {
                        //单笔
                        //设置单笔信息
                        singleProductBuffer.append(productStrategy.getProductName()).append("、");
                        singleProductId = productStrategy.getProductId();
//				accountDetails.setStrategyId(productStrategy.getStrategyId());
//				accountDetails.setProductId(productStrategy.getProductId());
//				accountDetails.setProductName(productStrategy.getProductName());
//				accountDetails.setChargeType(ProductChargeTypeEnum.SINGLE);
//				accountDetails.setBalance(responseData.getData().getBalance());
//				accountDetailsList.add(accountDetails);
                    }
                }
            }
        }
        AccountDetailsResponse accountDetails = new AccountDetailsResponse();
        String singleProduct = singleProductBuffer.toString();
        if (StringUtils.isNotBlank(singleProduct)) {
            //存在单笔，单笔单独处理，将所有单笔产品显示成一条记录
            accountDetails.setBalance(responseData.getData().getBalance());
            accountDetails.setProductName(singleProduct.substring(0, singleProduct.length() - 1));
            accountDetails.setProductId(singleProductId);
        } else {
            //不存在单笔，显示默认信息
            accountDetails.setBalance(responseData.getData().getBalance());
            accountDetails.setProductName("当前无生效中单笔计费");
        }
        accountDetails.setChargeType(ProductChargeTypeEnum.SINGLE);
        accountDetailsList.add(accountDetails);
        //结果排序，单笔靠前，包量依据录入时间倒序排列
        Collections.sort(accountDetailsList, new Comparator<AccountDetailsResponse>() {
            @Override
            public int compare(AccountDetailsResponse newResponse,
                               AccountDetailsResponse oldResponse) {
                int flag = oldResponse.getChargeType().toName().compareToIgnoreCase(newResponse.getChargeType().toName());
                if (flag == 0) {
                    if (ProductChargeTypeEnum.PACKAGE.toName().equalsIgnoreCase(newResponse.getChargeType().toName())) {
                        //包量，依据产品排序
                        return oldResponse.getProductId().compareTo(newResponse.getProductId());
                    }
                }
                return flag;
            }
        });
        return responseData;
    }

    /**
     * 分页查询包量列表
     *
     * @param accountPackageRequest
     * @return
     */
    @Override
    public void queryPackagePage(AccountPackageRequest accountPackageRequest, Page<AccountDetailsResponse> page) throws Exception {
        logger.info("queryPackagePage 查询参数:" + GsonUtil.getInstance().toJson(accountPackageRequest));
        long startTime = System.currentTimeMillis();
        //查询参数
        AccountPageQueryParam accountPageQueryParam = new AccountPageQueryParam();
        //查询商户对应的合同列表，且状态为有效和履行结束
        ContractQueryParam contractQueryParam = new ContractQueryParam();
        contractQueryParam.setMerchantNo(accountPackageRequest.getMerchantNo());
        List<String> contractStatusList = new ArrayList<String>();
        contractStatusList.add(ContractStatusEnum.VALID.toName());
        contractStatusList.add(ContractStatusEnum.TERMINATE.toName());
        contractQueryParam.setContractStatusList(contractStatusList);
        List<CreditContract> contractList = contractService.queryContractByParam(contractQueryParam);
        List<AccountDetailsResponse> accountResponseList = new ArrayList<AccountDetailsResponse>();
        Integer contractCount = 0;
        if (contractList != null && contractList.size() > 0) {
            List<Integer> contractIdList = new ArrayList<Integer>();
            for (CreditContract contract : contractList) {
                contractIdList.add(contract.getContractId());
            }
            //将查询的的合同ID加入计费列表查询参数
            accountPageQueryParam.setContractIdList(contractIdList);
            //设置分页开始索引和每页条数
            if (accountPackageRequest.getPageSize() != null) {
                accountPageQueryParam.setLimit(accountPackageRequest.getPageSize());
            }
            if (accountPackageRequest.getPageNo() != null) {
                accountPageQueryParam.setStart((accountPackageRequest.getPageNo() - 1) * accountPageQueryParam.getLimit());
            }
            accountPageQueryParam.setMarchantNo(accountPackageRequest.getMerchantNo());
            accountPageQueryParam.setProductId(accountPackageRequest.getProductId());
            accountPageQueryParam.setChargeType(ProductChargeTypeEnum.PACKAGE.toName());
            contractCount = productService.queryPackagePageCount(accountPageQueryParam);
            List<ProductStrategyEntity> strategyList = productService.queryPackagePage(accountPageQueryParam);
            logger.info("queryPackagePage 查询结果：" + (System.currentTimeMillis() - startTime) + " ms;" + GsonUtil.getInstance().toJson(strategyList));
            if (strategyList != null && strategyList.size() > 0) {
                //存在结果则写入列表
                RequestParam<GatewayAccountQueryRequest> accountRequestParam = new RequestParam<GatewayAccountQueryRequest>();
                GatewayAccountQueryRequest gatewayAccountQueryRequest = new GatewayAccountQueryRequest();
                for (ProductStrategyEntity productStrategy : strategyList) {
                    AccountDetailsResponse accountDetailsResponse = new AccountDetailsResponse();
                    accountDetailsResponse.setStrategyId(productStrategy.getStrategyId());
                    accountDetailsResponse.setChargeType(ProductChargeTypeEnum.enumValueOf(productStrategy.getChargeType().toUpperCase()));
                    accountDetailsResponse.setProductId(productStrategy.getProductId());
                    accountDetailsResponse.setProductName(productStrategy.getProductName());
                    accountDetailsResponse.setStartTime(productStrategy.getStartTime());
                    accountDetailsResponse.setFinishTime(productStrategy.getFinishTime());
                    accountDetailsResponse.setAmount(productStrategy.getAmount());//查询合同对应的所有产品名称
                    accountDetailsResponse.setPacketCount(productStrategy.getPacketCount());
                    accountDetailsResponse.setStrategyStatus(CreditStrategyStatusEnum.valueOf(productStrategy.getStrategyStatus()));
                    accountDetailsResponse.setBalance(0L);
                    accountResponseList.add(accountDetailsResponse);
                    if (StringUtils.isBlank(productStrategy.getAccountNo())) {
                        //不存在清结算账号则退出
//					page.setResponseMessage(ResponseMessage.NOT_EXIST);
//					page.setCode(AccountManageResponseEnum.RESULT_ACCOUNT_NOTEXIST.toName());
//					page.setMessage(AccountManageResponseEnum.RESULT_ACCOUNT_NOTEXIST.toDescription()+":产品策略ID"+productStrategy.getStrategyId());
                        logger.error("queryPackagePage 清结算未账户:" + GsonUtil.getInstance().toJson(productStrategy));
                        continue;
                    }
                    //依据清结算账号查询余额信息
                    gatewayAccountQueryRequest.setAccountNo(productStrategy.getAccountNo());
                    accountRequestParam.setParam(gatewayAccountQueryRequest);
                    logger.info("queryPackagePage 包量清结算账户查询参数:" + GsonUtil.getInstance().toJson(accountRequestParam));
                    ResponseData<GatewayAccountQueryResponse> accountResponseData = accountFacade.queryAccountInfo(accountRequestParam);
                    if (!accountResponseData.isSuccess()) {
//					 page.setResponseMessage(ResponseMessage.DATABASE_ERROR);
//					 page.setCode(accountResponseData.getCode());
//					 page.setMessage(accountResponseData.getMessage()+":产品策略ID"+productStrategy.getStrategyId());
                        logger.error("queryPackagePage 包量清结算余额查询失败:" + GsonUtil.getInstance().toJson(accountResponseData));
                        continue;
                    }
                    accountDetailsResponse.setBalance(accountResponseData.getData().getBalance());
                }

//		}else{
//			page.setResponseMessage(ResponseMessage.NOT_EXIST);
            }
        }
        //设置返回参数
        AccountPackageResponse accountPackageResponse = new AccountPackageResponse();
        //查询商户号和账户代码
        AccountQueryParam accountQueryParam = new AccountQueryParam();
        accountQueryParam.setMerchantNo(accountPackageRequest.getMerchantNo());
        CreditMerchant merchant = accountService.queryMerchantInfo(accountQueryParam);
        if (merchant != null) {
            accountPackageResponse.setMerchantNo(merchant.getMerchantNo());
            accountPackageResponse.setMerchantCode(merchant.getMerchantCode());
        }
        //查询产品名称
        ProductQueryParam ProductQueryParam = new ProductQueryParam();
        ProductQueryParam.setProductId(accountPackageRequest.getProductId());
        CreditProduct product = productService.queryProductById(ProductQueryParam);
        if (product != null) {
            accountPackageResponse.setProductName(product.getProductName());
        }
        page.setExtend(accountPackageResponse);
        page.setRows(accountResponseList);
        page.setTotal(contractCount);
    }

    /**
     * 单笔缴费
     *
     * @param merchantNo
     * @param chargeAmt
     * @throws Exception
     */
    @Override
    public void updateSingleCharge(String merchantNo, Long chargeAmt) throws Exception {
        String accountNo = this.getSingleAccountNo(merchantNo);
        if (StringUtils.isNotBlank(accountNo)) {
            ResponseData<GatewayAccounTradeResponse> rechargeResponse = this.rechargeAccount(accountNo, chargeAmt, PaymentChannelEnum.ONLINE.toName());
            if (!rechargeResponse.isSuccess()) {
                throw new RuntimeException("充值失败");
            }
        }
    }

    @Override
    public void updatePackageCharge(Integer contractId, Date finishTime) throws Exception {
        //包量缴费,缴费单请求Id为合同ID，依据合同ID查询包量产品
        if (null == this.updateContractStatusValid(contractId)) {
            //未查询到缴费单
            logger.error("updatePackageCharge 未查询到合同信息:" + GsonUtil.getInstance().toJson(contractId));
            throw new Exception("未查询到合同信息");
        }
        //查询缴费单包含的计费产品
        ProductStrategyQueryParam strategyQueryParam = new ProductStrategyQueryParam();
        strategyQueryParam.setContractId(contractId);
        List<String> chargeTypeList = new ArrayList<String>();
        chargeTypeList.add(ProductChargeTypeEnum.PACKAGE.toName());
        chargeTypeList.add(ProductChargeTypeEnum.SINGLE.toName());
        strategyQueryParam.setChargeTypeList(chargeTypeList);
        List<ProductStrategyEntity> productList = productService.queryStrategyList(strategyQueryParam);
        //遍历所有的计费产品，修改计费状态为正常
        for (ProductStrategyEntity productStrategy : productList) {
            if (ProductChargeTypeEnum.PACKAGE.toName().equalsIgnoreCase(productStrategy.getChargeType())) {
                //包量做重置并且将计费状态开启
                if (StringUtils.isBlank(productStrategy.getAccountNo())) {
                    //未查询到清结算账户名
                    logger.error("updatePackageCharge 未查询到清结算账户名:" + GsonUtil.getInstance().toJson(productStrategy));
                    throw new Exception("未查询到清结算账户名");
                }
                //将余额同步余额系统
                String accountNo = productStrategy.getAccountNo();
                Long chargeAmt = Long.parseLong(productStrategy.getPacketCount() + "");
                if (!this.rechargeAccount(accountNo, chargeAmt, PaymentChannelEnum.ONLINE.toName()).isSuccess()) {
                    throw new Exception("清结算充值失败");
                } else {
                    //修改计费产品状态
                    Integer strategyId = productStrategy.getStrategyId();
                    this.updateStrategyStatusOpen(strategyId, finishTime);
                }
            } else {
                //单笔计费产品仅更新状态，finishiTime字段为空
                Integer strategyId = productStrategy.getStrategyId();
                this.updateStrategyStatusOpen(strategyId, null);
            }
            //更新订购有效性
            CreditOrder order=new CreditOrder();
            order.setStatus(CreditOrderStatusEnum.VALID);
            order.setStrategyId(productStrategy.getStrategyId());
            order.setValidTime(finishTime);
            orderService.updateCreditOrderValidity(order);
        }
    }

    @Override
    public void updateOnePackageCharge(Integer orderId, Date finishTime) {
        try {
            CreditOrder order=orderService.queryCreditOrderById(orderId);

            ProductStrategyQueryParam param=new ProductStrategyQueryParam();
            param.setStrategyId(order.getStrategyId());
            List<String> chargeList=new ArrayList<String>();
            chargeList.add(ProductChargeTypeEnum.PACKAGE.toName());
            param.setChargeTypeList(chargeList);
            ProductStrategyEntity strategyEntity=productService.queryStrategyById(param);

            //包量做重置并且将计费状态开启
            if (StringUtils.isBlank(strategyEntity.getAccountNo())) {
                //未查询到清结算账户名
                logger.error("updatePackageCharge 未查询到清结算账户名:" + GsonUtil.getInstance().toJson(strategyEntity));
                throw new Exception("未查询到清结算账户名");
            }
            //将余额同步余额系统
            String accountNo = strategyEntity.getAccountNo();
            Long chargeAmt = Long.parseLong(strategyEntity.getPacketCount() + "");
            this.rechargeAccount(accountNo, chargeAmt, PaymentChannelEnum.ONLINE.toName());
            //更新订购有效性
            order.setValidTime(finishTime);
            order.setStatus(CreditOrderStatusEnum.VALID);
            orderService.updateCreditOrderValidity(order);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void resetSingleBalance(String merchantNo, Long chargeAmt,
                                   ResponseData<PaymentUpdateResponse> responseData) throws Exception {
        logger.info("resetSingleBalance 单笔充值:" + merchantNo + ",chargeAmt:" + chargeAmt);
        //依据商户号查询清结算账号
        String accountNo = getSingleAccountNo(merchantNo);
        //判定该商户是否存在对应清结算账户
        if (StringUtils.isNotBlank(accountNo)) {
            responseData.getData().setResponseMessage(ResponseMessage.DATABASE_ERROR);
            //1.查询账户是否存在余额
            ResponseData<GatewayAccountQueryResponse> balanceResponse = balanceAccount(accountNo);
            if (balanceResponse.isSuccess()) {
                //2.将余额置为零
                if (balanceResponse.getData().getBalance() != 0) {
                    ResponseData<GatewayAccounTradeResponse> consumeResponse = consumeAccount(accountNo, balanceResponse.getData().getBalance(), PaymentChannelEnum.OFFLINE.toName());
                    if (consumeResponse.isSuccess()) {
                        //3.对账户进行充值
                        //4.设置充值返回结果
                        ResponseData<GatewayAccounTradeResponse> rechargeResponse = rechargeAccount(accountNo, chargeAmt, PaymentChannelEnum.OFFLINE.toName());
                        if (rechargeResponse.isSuccess()) {
                            responseData.getData().setResponseMessage(ResponseMessage.SUCCESS);
                        }
                    }
                } else {
                    //3.对账户进行充值
                    //4.设置充值返回结果
                    ResponseData<GatewayAccounTradeResponse> rechargeResponse = rechargeAccount(accountNo, chargeAmt, PaymentChannelEnum.OFFLINE.toName());
                    if (rechargeResponse.isSuccess()) {
                        responseData.getData().setResponseMessage(ResponseMessage.SUCCESS);
                    }
                }

            }
        } else {
            responseData.getData().setResponseMessage(ResponseMessage.NOT_EXIST);
        }
    }

    @Override
    public void resetPackageBalance(List<PaymentPackageEntity> paymentSreategyList, ResponseData<PaymentUpdateResponse> responseData) throws Exception {
        logger.info("resetPackageBalance 包量充值:" + GsonUtil.getInstance().toJson(paymentSreategyList));
        //获取去重合同列表和包量计费充值金额
        if (paymentSreategyList != null && paymentSreategyList.size() > 0) {
            Date finishTime = null;
            List<PaymentPackageEntity> paymentPackageList = new ArrayList<PaymentPackageEntity>();
            responseData.getData().setPaymentPackageList(paymentPackageList);
            Map<Integer, Integer> remainMap = new HashMap<Integer, Integer>();
            List<Integer> contractIdList = new ArrayList<Integer>();
            for (PaymentPackageEntity steategy : paymentSreategyList) {
                remainMap.put(steategy.getStrategyId(), steategy.getRemainCount());
                if (!contractIdList.contains(steategy.getContractId())&&NumberUtils.isDigits(String.valueOf(steategy.getRemainCount()))) {
                    contractIdList.add(steategy.getContractId());
                }
            }
            //遍历合同列表修改合同状态
            ProductStrategyQueryParam strategyQueryParam = new ProductStrategyQueryParam();
            List<String> chargeTypeList = new ArrayList<String>();
            strategyQueryParam.setChargeTypeList(chargeTypeList);
            for (Integer contractId : contractIdList) {
                //依据合同ID作废缴费单
                this.cancelPaymentOrder(responseData.getData().getMerchantNo(), contractId);
                //修改合同状态
                this.updateContractStatusValid(contractId);
                strategyQueryParam.setContractId(contractId);
                chargeTypeList.add(ProductChargeTypeEnum.PACKAGE.toName());
                chargeTypeList.add(ProductChargeTypeEnum.SINGLE.toName());
                List<ProductStrategyEntity> productList = productService.queryStrategyList(strategyQueryParam);
                //修改单笔产品状态
                //查询缴费单包含的计费产品
                for (ProductStrategyEntity productStrategy : productList) {
                    if (ProductChargeTypeEnum.PACKAGE.toName().equalsIgnoreCase(productStrategy.getChargeType())) {
                        //包量缴费,缴费单请求Id为合同ID，依据合同ID查询包量产品
                        //包量做重置并且将计费状态开启
                        if (remainMap.containsKey(productStrategy.getStrategyId())) {
                            //遍历合同列表修改包量产品状态并将包量产品账户进行充值
                            String accountNo = productStrategy.getAccountNo();
                            Integer remainCount = remainMap.get(productStrategy.getStrategyId());
                            PaymentPackageEntity paymentPackage = new PaymentPackageEntity();
                            paymentPackage.setContractId(contractId);
                            paymentPackage.setRemainCount(remainCount);
                            paymentPackage.setStrategyId(productStrategy.getStrategyId());
                            paymentPackage.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
                            paymentPackageList.add(paymentPackage);
                            if (StringUtils.isBlank(accountNo)) {
                                //未查询到清结算账户名
                                logger.error("paymentonMessage 未查询到清结算账户名:" + GsonUtil.getInstance().toJson(productStrategy));
                                paymentPackage.setResponseMessage(ResponseMessage.NOT_EXIST);
                                continue;
                            }
                            if (NumberUtils.isDigits(String.valueOf(remainCount))) {
                                //包量计费充值金额
                                //1.查询账户是否存在余额
                                ResponseData<GatewayAccountQueryResponse> balanceResponse = balanceAccount(accountNo);
                                if (balanceResponse.isSuccess()) {
                                    //2.将余额置为零
                                    if (balanceResponse.getData().getBalance() != 0) {
                                        ResponseData<GatewayAccounTradeResponse> consumeResponse = consumeAccount(accountNo, balanceResponse.getData().getBalance(), PaymentChannelEnum.OFFLINE.toName());
                                        if (consumeResponse.isSuccess()) {
                                            //3.对账户进行充值
                                            //4.设置充值返回结果
                                            ResponseData<GatewayAccounTradeResponse> rechargeResponse = rechargeAccount(accountNo, Long.parseLong(remainCount + ""), PaymentChannelEnum.OFFLINE.toName());
                                            if (rechargeResponse.isSuccess()) {
                                                paymentPackage.setResponseMessage(ResponseMessage.SUCCESS);
                                            }
                                        }
                                    } else {
                                        //3.对账户进行充值
                                        //4.设置充值返回结果
                                        ResponseData<GatewayAccounTradeResponse> rechargeResponse = rechargeAccount(accountNo, Long.parseLong(remainCount + ""), PaymentChannelEnum.OFFLINE.toName());
                                        if (rechargeResponse.isSuccess()) {
                                            paymentPackage.setResponseMessage(ResponseMessage.SUCCESS);
                                        }
                                    }

                                }
                                //设置缴费成功时间
                                finishTime = new Date();
                            } else {
                                paymentPackage.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
                            }
                        }
                        //修改计费产品状态
                        Integer strategyId = productStrategy.getStrategyId();
                        this.updateStrategyStatusOpen(strategyId, finishTime);
                    } else {
                        //单笔计费产品仅更新状态，finishiTime字段为空
                        Integer strategyId = productStrategy.getStrategyId();
                        this.updateStrategyStatusOpen(strategyId, null);
                    }

                    //更新订购有效性
                    CreditOrder order=new CreditOrder();
                    order.setStatus(CreditOrderStatusEnum.VALID);
                    order.setStrategyId(productStrategy.getStrategyId());
                    order.setValidTime(finishTime);
                    orderService.updateCreditOrderValidity(order);
                }
            }
        }
    }

    /**
     * 根据合同ID作废缴费单
     *
     * @param merchantNo
     * @return
     * @throws Exception
     */
    private void cancelPaymentOrder(String merchantNo, Integer contractId) throws Exception {
        CreditPayment payment=new CreditPayment();
        payment.setPayChannel(CreditPaymentChannelEnum.PACKAGE);
        payment.setMerchantNo(merchantNo);
        payment.setContractId(contractId+"");
        paymentService.cancelPayment(payment);
    }

    /**
     * 根据商户号查询商户在余额系统中的账户号
     *
     * @param merchantNo
     * @return
     * @throws Exception
     */
    private String getSingleAccountNo(String merchantNo) throws Exception {
        AccountQueryParam accountQueryParam = new AccountQueryParam();
        //依据商户号查询清结算账号
        accountQueryParam.setMerchantNo(merchantNo);
        CreditMerchantAccount merchantAccount = null;
        accountQueryParam.setChargeType(ProductChargeTypeEnum.SINGLE.toName());
        merchantAccount = accountService.queryAccountNo(accountQueryParam);
        if (merchantAccount == null || StringUtils.isBlank(merchantAccount.getAccountNo())) {
            logger.error("getSingleAccountNo 商户未开户:" + GsonUtil.getInstance().toJson(accountQueryParam));
            return "";
        } else {
            return merchantAccount.getAccountNo();
        }
    }

    /**
     * 商户充值
     *
     * @param accountNo
     * @param chargeAmt
     */
    private ResponseData<GatewayAccounTradeResponse> rechargeAccount(String accountNo, Long chargeAmt, String remark) {

        RequestParam<GatewayAccountRechargeRequest> requestParam = new RequestParam<GatewayAccountRechargeRequest>();
        GatewayAccountRechargeRequest rechargeRequest = new GatewayAccountRechargeRequest();
        rechargeRequest.setAccountNo(accountNo);
        rechargeRequest.setTradeAmt(chargeAmt);
        rechargeRequest.setTradeDesc(remark);
        requestParam.setParam(rechargeRequest);
        logger.info("rechargeAccount 商户充值参数:" + GsonUtil.getInstance().toJson(requestParam));
        ResponseData<GatewayAccounTradeResponse> chargeResult = accountFacade.accountRecharge(requestParam);
        if (chargeResult.isSuccess()) {
            logger.info("rechargeAccount 商户充值成功 :" + GsonUtil.getInstance().toJson(chargeResult));
        } else {
            logger.error("rechargeAccount 商户充值失败:" + GsonUtil.getInstance().toJson(chargeResult));
        }
        return chargeResult;
    }

    /**
     * 商户消费
     *
     * @param accountNo
     * @param consumeAmt
     */
    private ResponseData<GatewayAccounTradeResponse> consumeAccount(String accountNo, Long consumeAmt, String remark) {

        RequestParam<GatewayAccountConsumeRequest> accountConsumeRequest = new RequestParam<GatewayAccountConsumeRequest>();
        GatewayAccountConsumeRequest consumeRequest = new GatewayAccountConsumeRequest();
        consumeRequest.setAccountNo(accountNo);
        consumeRequest.setTradeAmt(consumeAmt);
        consumeRequest.setTradeDesc(remark);
        accountConsumeRequest.setParam(consumeRequest);
        ResponseData<GatewayAccounTradeResponse> consumeResponse = accountFacade.accountConsume(accountConsumeRequest);
        if (consumeResponse.isSuccess()) {
            logger.info("consumeAccount 商户消费成功 :" + GsonUtil.getInstance().toJson(consumeResponse));
        } else {
            logger.error("consumeAccount 商户消费失败:" + GsonUtil.getInstance().toJson(consumeResponse));
        }
        return consumeResponse;
    }

    /**
     * 商户余额查询
     *
     * @param accountNo
     */
    private ResponseData<GatewayAccountQueryResponse> balanceAccount(String accountNo) {

        RequestParam<GatewayAccountQueryRequest> accountRequestParam = new RequestParam<GatewayAccountQueryRequest>();
        GatewayAccountQueryRequest gatewayAccountQueryRequest = new GatewayAccountQueryRequest();
        gatewayAccountQueryRequest.setAccountNo(accountNo);
        accountRequestParam.setParam(gatewayAccountQueryRequest);
        ResponseData<GatewayAccountQueryResponse> balanceResponse = accountFacade.queryAccountInfo(accountRequestParam);
        if (balanceResponse.isSuccess()) {
            logger.info("balanceAccount 商户余额查询成功 :" + GsonUtil.getInstance().toJson(accountRequestParam));
        } else {
            logger.error("balanceAccount 商户余额查询失败:" + GsonUtil.getInstance().toJson(accountRequestParam));
        }
        return balanceResponse;
    }

    /**
     * 更新合同信息为有效
     *
     * @param contractId
     * @throws Exception
     */
    private Integer updateContractStatusValid(Integer contractId) throws Exception {
        ContractQueryParam contractQueryParam = new ContractQueryParam();
        contractQueryParam.setContractId(contractId);
        CreditContract contract = contractService.queryContractById(contractQueryParam);
        //存在缴费单请求Id
        Integer verifyResult = null;
        if (contract != null) {
            //包量缴费成功，修改合同状态为有效
            if (ContractStatusEnum.NOPAY.toName().equalsIgnoreCase(contract.getContractStatus())) {
                //待缴费状态时修改合同状态为有效
                ContractUpdateParam contractUpdateParam = new ContractUpdateParam();
                contractUpdateParam.setContractId(contract.getContractId());
                contractUpdateParam.setContractStatus(ContractStatusEnum.VALID.toName());
                contractUpdateParam.setModifiedDate(new Date());
                verifyResult = contractService.updateContractStatus(contractUpdateParam);
                if (verifyResult > 0) {
                    logger.info("updateContractStatusValid 修改合同状态为有效，成功 :" + GsonUtil.getInstance().toJson(contractUpdateParam));
                } else {
                    logger.error("updateContractStatusValid 修改合同状态为有效，失败:" + GsonUtil.getInstance().toJson(contractUpdateParam));
                }
            }
        }
        return verifyResult;
    }

    /**
     * 更新计费产品状态
     *
     * @param strategyId
     * @param finishiTime
     */
    private Integer updateStrategyStatusOpen(Integer strategyId, Date finishiTime) throws Exception {
        CreditProductStrategy productStatusRequest = new CreditProductStrategy();
        productStatusRequest.setStrategyId(strategyId);
        productStatusRequest.setStrategyStatus(OpenOrCloseStatusEnum.OPEN.toName());
        if (finishiTime != null) {
            productStatusRequest.setPaymentDate(finishiTime);
        }
        productStatusRequest.setModifiedDate(new Date());
        Integer strategyUpdateResult = productService.updateStrategyStatus(productStatusRequest);
        //充值成功
        if (strategyUpdateResult <= 0) {
            //修改状态失败
            logger.error("paymentonMessage 缴费单产品修改状态失败:" + GsonUtil.getInstance().toJson(productStatusRequest));
        } else {
            logger.info("paymentonMessage 缴费单产品修改状态成功:" + GsonUtil.getInstance().toJson(productStatusRequest));
        }
        return strategyUpdateResult;
    }

}
