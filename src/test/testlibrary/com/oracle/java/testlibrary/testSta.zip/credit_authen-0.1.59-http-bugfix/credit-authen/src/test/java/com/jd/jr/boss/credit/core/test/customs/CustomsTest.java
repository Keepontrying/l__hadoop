package com.jd.jr.boss.credit.core.test.customs;

import com.jd.jr.boss.credit.domain.common.entity.CreditCustoms;
import com.jd.jr.boss.credit.domain.common.entity.CreditCustomsBatch;
import com.jd.jr.boss.credit.facade.authen.api.CreditContractFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditQueryBatchFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.CustomsQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.OnlineContactCreateParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.common.beans.enums.SortDir;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})

public class CustomsTest {
    @Resource
    private CreditQueryBatchFacade creditQueryBatchFacade;

//    @Test
    public void mainTest() {
//        CustomsQueryParam queryParam=new CustomsQueryParam();
//        queryParam.setLimit(10);
//        queryParam.setSortDir(SortDir.ASC);
//        queryParam.setStart(0);
//        queryParam.setMerchantNo("110040816");
//        queryParam.setBatchId(1);
//        CreditPage<CreditCustomsBatch> pageData = creditQueryBatchFacade.queryCustomsHistory(queryParam);
//        System.out.println("-----------"+GsonUtil.getInstance().toJson(pageData));
    }

        @Test
    public void mainTest1() {
        CustomsQueryParam queryParam=new CustomsQueryParam();
        queryParam.setBatchId(1);
        queryParam.setLimit(10);
        queryParam.setStart(0);
        queryParam.setMerchantNo("110040816");
        queryParam.setTxtcode("122312312");
        queryParam.setClearStatus("已结关");
        CreditPage<CreditCustoms> pageData = creditQueryBatchFacade.queryCustomsHistoryDetails(queryParam);
        System.out.println("-----------"+GsonUtil.getInstance().toJson(pageData));
    }


}
