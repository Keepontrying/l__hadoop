package com.jd.jr.boss.credit.core.test.user;

import com.jd.jr.boss.credit.facade.authen.api.CreditRegisterFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.FacadePortalUserRequest;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author jiangbo
 * @since 2017/3/30
 */
public class CreditRegisterFacadeTest extends BaseTest {


    @Autowired
    CreditRegisterFacade creditRegisterFacade;

    @Before
    public void setUp() throws Exception {

    }

    @After
    public void tearDown() throws Exception {

    }


    @Test
    public void testRegisterUser() throws Exception{
//        GatewayPortalUserRequest param = new GatewayPortalUserRequest();
//        param.setUserName("nihao123@gmail.com");
//        param.setPassWord("111");
//        param.setPassWordType("0");
//        param.setPhone("123456789");
//        CreditRequestParam<GatewayPortalUserRequest> creditRequestParam = new CreditRequestParam<GatewayPortalUserRequest>();
//        creditRequestParam.setParam(param);
//        CreditResponseData<Integer> res = creditRegisterFacade.registerUser(creditRequestParam);
//        System.out.println(res);
//        assertTrue(res.isSuccess());
    }


    @Test
    public void checkEmailExsit() throws Exception{
//        GatewayPortalUserRequest param = new GatewayPortalUserRequest();
//        param.setUserName("nihao121@gmail.com");
////        param.setPassWord("111");
////        param.setPassWordType("0");
////        param.setPhone("123456789");
//        CreditRequestParam<GatewayPortalUserRequest> creditRequestParam = new CreditRequestParam<GatewayPortalUserRequest>();
//        creditRequestParam.setParam(param);
//        CreditResponseData<Boolean> res = creditRegisterFacade.checkEmailExsit(creditRequestParam);
//        System.out.println(res);
//        assertTrue(res.isSuccess());
    }


    @Test
    public void login() throws Exception{
//        GatewayPortalUserRequest param = new GatewayPortalUserRequest();
//        param.setUserName("nihao123@gmail.com");
//        param.setPassWord(PWDUtil.encrypt("111"));
////        param.setPassWordType("0");
////        param.setPhone("123456789");
//        CreditRequestParam<GatewayPortalUserRequest> creditRequestParam = new CreditRequestParam<GatewayPortalUserRequest>();
//        creditRequestParam.setParam(param);
//        CreditResponseData<CreditUser> res = creditRegisterFacade.login(creditRequestParam);
//        System.out.println(res);
//        assertTrue(res.isSuccess());
    }

    @Test
    public void sendRegisterEmail() throws Exception{
//        FacadePortalUserRequest param = new FacadePortalUserRequest();
//        param.setUserName("jbwin@126.com");
//        param.setPassWordType("0");
//        param.setPhone("123456789");
//        CreditRequestParam<FacadePortalUserRequest> creditRequestParam = new CreditRequestParam<FacadePortalUserRequest>();
//        creditRequestParam.setParam(param);
//        CreditResponseData<Integer> res = creditRegisterFacade.sendRegisterEmail(creditRequestParam);
//        System.out.println(res);
//        assertTrue(res.isSuccess());
    }
}
