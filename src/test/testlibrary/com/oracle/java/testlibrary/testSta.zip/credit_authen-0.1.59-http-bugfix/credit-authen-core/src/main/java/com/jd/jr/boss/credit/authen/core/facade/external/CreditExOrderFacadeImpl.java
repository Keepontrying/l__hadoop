package com.jd.jr.boss.credit.authen.core.facade.external;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.jd.jr.boss.credit.authen.core.beans.entity.ProductToBuyShow;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrderMain;
import com.jd.jr.boss.credit.domain.common.enums.CreditOrderPayTypeEnum;
import com.jd.jr.boss.credit.domain.common.enums.MainOrderSourceEnum;
import com.jd.jr.boss.credit.facade.authen.api.CreditContractFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditOrderFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.MainOrderQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.OnlineContactCreateParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.OnlineContractQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditExRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.external.api.CreditExOrderFacade;
import com.jd.jr.boss.credit.facade.external.beans.request.*;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditCashierResp;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditContractResp;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditOrderMainResp;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditOrderResp;
import com.jd.jr.boss.credit.facade.external.enums.ContractStatusEnum;
import com.jd.jr.boss.credit.facade.external.enums.CreditOrderMainStatusEnum;
import com.jd.jr.boss.credit.facade.external.enums.ProductChargeTypeEnum;
import com.jd.jr.gyl.base.cashier.sdk.export.request.ReqInfo;
import com.jd.jr.gyl.base.cashier.sdk.export.util.Common;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.enums.CreditContractSourceEnum;
import com.wangyin.boss.credit.admin.enums.CreditTypeEnum;
import com.wangyin.boss.credit.admin.enums.MerchantTypeEnum;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by anmeng on 2018/5/29.
 */
@Service("creditExOrderFacade")
public class CreditExOrderFacadeImpl implements CreditExOrderFacade {
    private Logger logger= LoggerFactory.getLogger(CreditExOrderFacadeImpl.class);

    private final Long platId= ConfigUtil.getLong("cashier.platId");
    private final String signPriKey=ConfigUtil.getString("cashier.rsa.sign.privateKey");
    private final String encryptPubKey=ConfigUtil.getString("cashier.rsa.encrypt.publicKey");
    private final String merchantNum=ConfigUtil.getString("cashier.merchant.num");
    private final String categoryCode=ConfigUtil.getString("cashier.categoryCode");
    private final Integer orderType=ConfigUtil.getInt("cashier.orderType");
    private final Long cashierVer=ConfigUtil.getLong("cashier.ver");
    private final String merchantName=ConfigUtil.getString("cashier.merchant.name");
    private final String orderNoPrefix=ConfigUtil.getString("cashier.orderNoPrefix");

    @Autowired
    private CreditOrderFacade creditOrderFacade;

    @Autowired
    private CreditContractFacade creditContractFacade;

    /**
     * 校验当前商户是否有有效的线上合同
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<Boolean> validOnlineContractStatus(CreditExRequestParam<MerchantReq> requestParam) {
        CreditResponseData<Boolean> responseData=new CreditResponseData<Boolean>();
        MerchantReq req=requestParam.getParam();

        OnlineContractQueryParam queryPageParam=new OnlineContractQueryParam();
        queryPageParam.setMerchantNo(req.getMerchantNo());

        List<String> contractStatusList=new ArrayList<String>();
        contractStatusList.add(ContractStatusEnum.VALID.toName());
        queryPageParam.setContractStatusList(contractStatusList);

        List<String> contractSourceList=new ArrayList<String>();
        contractSourceList.add(CreditContractSourceEnum.ONLINE.toName());
        queryPageParam.setContractSourceList(contractSourceList);

        queryPageParam.setCreditType(CreditTypeEnum.ENTERPRISE.toName());
        try {
            CreditPage<CreditContract> contractPage=creditContractFacade.queryCreditContractList(queryPageParam);
            if(contractPage.getTotal()>0){
                responseData.setData(true);
            }else{
                responseData.setData(false);
            }
        } catch (Exception e) {
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            logger.error("查询合同签订信息失败！");
        }
        logger.info("response data:"+ JSONObject.toJSONString(responseData));
        return responseData;
    }

    /**
     * 查询合同信息
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<List<CreditContractResp>> queryContract(CreditExRequestParam<ContractQueryReq> requestParam) {

        CreditResponseData<List<CreditContractResp>> exResponseData=new CreditResponseData<>();

        ContractQueryReq queryReq=requestParam.getParam();
        OnlineContractQueryParam queryPageParam =new OnlineContractQueryParam();
        queryPageParam.setMerchantNo(queryReq.getMerchantNo());
        if(queryReq.getStatus()!=null) {
            queryPageParam.setContractStatusList(Lists.newArrayList(queryReq.getStatus().toName()));
        }
        queryPageParam.setCreditType(CreditTypeEnum.ENTERPRISE.toName());
        if(queryReq.getPageIndex()==null||queryReq.getPageSize()==null){
            queryPageParam.setStart(0);
            queryPageParam.setLimit(10);
        }else {
            queryPageParam.setStart((queryReq.getPageIndex() - 1) * queryReq.getPageSize());
            queryPageParam.setLimit(queryReq.getPageSize());
        }
        CreditPage<CreditContract> responseData=creditContractFacade.queryCreditContractList(queryPageParam);
        if(responseData.isSuccess()){
            List<CreditContractResp> contractRespList=new ArrayList<>();
            List<CreditContract> contractList= responseData.getRows();
            contractList.forEach(contract->{
                CreditContractResp resp=new CreditContractResp();
                BeanUtils.copyProperties(contract,resp);
                contractRespList.add(resp);
            });
            exResponseData.setData(contractRespList);
        }else{
            exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        logger.info("response data:"+ JSONObject.toJSONString(exResponseData));
        return exResponseData;
    }

    /**
     * 提交订单接口
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<CreditOrderMainResp> submitOrder(CreditExRequestParam<OrderCreateReq> requestParam) {

        CreditResponseData<CreditOrderMainResp> exResponseData=new CreditResponseData<>();

        OrderCreateReq createReq=requestParam.getParam();
        String operator=requestParam.getOperator();
        if(createReq.getSkuList()==null||createReq.getSkuList().isEmpty()){
            logger.error("submitOrder fail, skuList is null");
            exResponseData.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
            return exResponseData;
        }

        //创建合同
        OnlineContactCreateParam param = new OnlineContactCreateParam();
        param.setMerchantNo(createReq.getMerchantNo());
        param.setCreditType(CreditTypeEnum.ENTERPRISE.toName());
        List<Integer> skuIds = createReq.getSkuList();

        param.setItemSkuList(skuIds);
        param.setOperator(operator);
        ResponseData<CreditContract> contractResponse = creditContractFacade.createOnlineContract(param);
        if (!contractResponse.isSuccess()) {
            logger.error("创建线上合同失败：" + JSONObject.toJSONString(contractResponse));
            exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            exResponseData.setMessage(contractResponse.getMessage());
            exResponseData.setCode(contractResponse.getCode());
            return exResponseData;
        }
        CreditContract contract = contractResponse.getData();


        try {
            //创建订单
            CreditRequestParam<CreditOrderMain> orderCreateParam = new CreditRequestParam<>();
            CreditOrderMain orderMain=new CreditOrderMain();
            orderMain.setContractId(contract.getContractId());
            orderMain.setOrderSource(MainOrderSourceEnum.ONLINE);
            orderMain.setOrderOwnedNo(createReq.getMerchantNo());
            orderMain.setOrderOwnedType(MerchantTypeEnum.ENTERPRISE.getCode());
            orderMain.setPayType(CreditOrderPayTypeEnum.CASHIER);
            orderMain.setCreator(operator);
            orderMain.setModifier(operator);
            orderMain.setCreditType(CreditTypeEnum.ENTERPRISE.toName());
            List<CreditOrder> subList=new ArrayList<>();
            skuIds.forEach(skuId->{
                CreditOrder order=new CreditOrder();
                order.setSkuId(skuId);
                subList.add(order);
            });
            orderMain.setSubOrderList(subList);
            orderCreateParam.setParam(orderMain);
            CreditResponseData<CreditOrderMain> responseData = creditOrderFacade.createOrder(orderCreateParam);
            if (!responseData.isSuccess()) {
                logger.error(JSONObject.toJSONString(responseData));
                throw new RuntimeException("创建订单失败！");
            }
            orderMain = responseData.getData();
            CreditOrderMainResp orderMainResp=new CreditOrderMainResp();
            BeanUtils.copyProperties(orderMain,orderMainResp);
            exResponseData.setData(orderMainResp);
        } catch (RuntimeException e) {
            exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        logger.info("response data:"+ JSONObject.toJSONString(exResponseData));
        return exResponseData;
    }

    /**
     * 根据订单ID取消订单
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData cancelOrder(CreditExRequestParam<OrderMainQueryReq> requestParam) {
        CreditResponseData exResponseData=new CreditResponseData();
        if(requestParam.getParam()==null||requestParam.getParam().getOrderMainId()==null){
            exResponseData.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
            return exResponseData;
        }
        Integer orderMainId=requestParam.getParam().getOrderMainId();
        String merchantNo=requestParam.getParam().getMerchantNo();

        try {
            CreditRequestParam<CreditOrderMain> cancelParam = new CreditRequestParam<>();
            CreditOrderMain orderMain = new CreditOrderMain();
            orderMain.setOrderMainId(orderMainId);
            orderMain.setOrderOwnedNo(merchantNo);
            cancelParam.setParam(orderMain);
            CreditResponseData<CreditOrderMain> responseData=creditOrderFacade.cancelOrder(cancelParam);
            if(!responseData.isSuccess()){
                exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            }
        } catch (Exception e) {
            exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        logger.info("response data:"+ JSONObject.toJSONString(exResponseData));
        return exResponseData;
    }

    /**
     * 查询订单列表
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<List<CreditOrderMainResp>> queryOrder(CreditExRequestParam<OrderMainQueryReq> requestParam) {
        CreditResponseData<List<CreditOrderMainResp>> exResponseData=new CreditResponseData<>();
        OrderMainQueryReq req=requestParam.getParam();
        MainOrderQueryParam queryParam = new MainOrderQueryParam();
        queryParam.setMerchantNo(req.getMerchantNo());
        queryParam.setOrderStatus((req.getOrderStatus()==null)?"":req.getOrderStatus().getCode());
        queryParam.setStart((req.getPageIndex()-1)*req.getPageSize());
        queryParam.setLimit(req.getPageSize());
        CreditPage<CreditOrderMain> page=creditOrderFacade.queryOrderMain(queryParam);
        if(page.isSuccess()){
            List<CreditOrderMain> orderList=page.getRows();
            if(orderList!=null){
                List<CreditOrderMainResp> respList=new ArrayList<>();
                orderList.forEach(orderMain -> {
                    CreditOrderMainResp resp=new CreditOrderMainResp();
                    BeanUtils.copyProperties(orderMain,resp);
                    resp.setOrderStatus(CreditOrderMainStatusEnum.valueOf(orderMain.getOrderStatus().getCode()));
                    respList.add(resp);
                });
                exResponseData.setData(respList);
            }
        }else{
            exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        logger.info("response data:"+ JSONObject.toJSONString(exResponseData));
        return exResponseData;
    }

    /**
     * 查询主订单明细
     *
     * @param requestParam 主订单ID
     * @return
     */
    @Override
    public CreditResponseData<CreditOrderMainResp> queryOrderDetail(CreditExRequestParam<OrderMainQueryReq> requestParam) {
        CreditResponseData<CreditOrderMainResp> exResponseData=new CreditResponseData<>();
        if(requestParam.getParam()==null||requestParam.getParam().getOrderMainId()==null){
            exResponseData.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
            return exResponseData;
        }
        Integer orderMainId=requestParam.getParam().getOrderMainId();
        String merchantNo=requestParam.getParam().getMerchantNo();

        CreditRequestParam<CreditOrderMain> queryParam = new CreditRequestParam<>();
        CreditOrderMain orderMain = new CreditOrderMain();
        orderMain.setOrderMainId(orderMainId);
        orderMain.setOrderOwnedNo(merchantNo);
        queryParam.setParam(orderMain);
        CreditResponseData<CreditOrderMain> responseData = creditOrderFacade.queryMainOrderDetail(queryParam);
        if(responseData.isSuccess()){
            orderMain=responseData.getData();
            CreditOrderMainResp resp=new CreditOrderMainResp();
            BeanUtils.copyProperties(orderMain,resp);
            resp.setOrderStatus(CreditOrderMainStatusEnum.valueOf(orderMain.getOrderStatus().getCode()));
            if(orderMain.getSubOrderList()!=null){
                List<CreditOrderResp> subOrderList=new ArrayList<>();
                ProductToBuyShow toBuyShow=new ProductToBuyShow();
                orderMain.getSubOrderList().forEach(subOrder->{
                    CreditOrderResp orderResp=new CreditOrderResp();
                    BeanUtils.copyProperties(subOrder,orderResp);
                    orderResp.setStrategyChargeType(ProductChargeTypeEnum.enumValueOf(subOrder.getStrategyChargeType().toName()));
                    if(toBuyShow.getItemMap().get(subOrder.getProductCode())!=null){
                        orderResp.setIconCode(toBuyShow.getItemMap().get(subOrder.getProductCode()).getIconClass());
                    }else{
                        orderResp.setIconCode(toBuyShow.getDefaultIcon());
                    }
                    subOrderList.add(orderResp);
                });
                resp.setSubOrderList(subOrderList);
            }
            exResponseData.setData(resp);
        }else{
            exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        logger.info("response data:"+ JSONObject.toJSONString(exResponseData));
        return exResponseData;
    }

    /**
     * 组装收银台所需参数
     *
     * @param requestParam
     * @return
     */
    @Override
    public CreditResponseData<CreditCashierResp> generateCashierParam(CreditExRequestParam<GenCashierParamReq> requestParam) {
        GenCashierParamReq req=requestParam.getParam();
        CreditResponseData<CreditCashierResp> exResponseData=new CreditResponseData<>();
        CreditCashierResp cashierResp=new CreditCashierResp();
        cashierResp.setPlatId(this.platId);
        cashierResp.setVer(this.cashierVer);

        try {
            Integer orderMainId=req.getOrderMainId();
            CreditRequestParam<CreditOrderMain> queryParam = new CreditRequestParam<CreditOrderMain>();
            CreditOrderMain orderMain = new CreditOrderMain();
            orderMain.setOrderMainId(orderMainId);
            queryParam.setParam(orderMain);
            CreditResponseData<CreditOrderMain> responseData = creditOrderFacade.queryMainOrderDetail(queryParam);
            if(responseData.isSuccess()) {
                orderMain=responseData.getData();
                ReqInfo reqInfo = new ReqInfo();
                reqInfo.setOrderId(this.orderNoPrefix + orderMain.getOrderNo());
                reqInfo.setPayMoney(BigDecimal.valueOf(orderMain.getOrderAmount()).divide(BigDecimal.valueOf(100)).setScale(2, BigDecimal.ROUND_HALF_UP));
                reqInfo.setVer(this.cashierVer + "");
                reqInfo.setCreateTime(orderMain.getCreatedDate());
                reqInfo.setReturnUrl(req.getReturnUrl());
                reqInfo.setDetailUrl(req.getDetailUrl());
                reqInfo.setCompanyName(this.merchantName);
                reqInfo.setJrid(req.getJrId());
                reqInfo.setCompanyCode(this.merchantNum);
                reqInfo.setOrderType(this.orderType);
                reqInfo.setCategoryCode(this.categoryCode);
                String productNameStr = orderMain.getProductNameStr();
                String[] productItemArr = productNameStr.split(",");
                String tradeName = (productItemArr.length == 1) ? productItemArr[0] : (productItemArr[0] + "等");
                reqInfo.setOrderInfo(tradeName);
                reqInfo.setPayExpireTime(null);
                reqInfo.setExtend("");
                String context = Common.getContextStr(encryptPubKey, signPriKey, reqInfo, this.platId);
                cashierResp.setContext(context);
                exResponseData.setData(cashierResp);
            }else{
                logger.error("查询订单信息失败",exResponseData.getMessage());
                exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            }
        } catch (Exception e) {
            logger.error("获取支付参数失败",e);
            exResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        logger.info("response data:"+ JSONObject.toJSONString(exResponseData));
        return exResponseData;
    }
}
