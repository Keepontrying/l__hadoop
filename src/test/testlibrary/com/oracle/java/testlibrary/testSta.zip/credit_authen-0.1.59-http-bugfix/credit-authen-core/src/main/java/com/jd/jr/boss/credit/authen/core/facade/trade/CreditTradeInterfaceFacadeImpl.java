package com.jd.jr.boss.credit.authen.core.facade.trade;

import com.alibaba.fastjson.JSON;
import com.jd.jr.boss.credit.authen.core.service.ForeignCallbackNoticeService;
import com.jd.jr.boss.credit.authen.core.task.AutoSewageChildService;
import com.jd.jr.boss.credit.domain.common.entity.CreditCallbackUrl;
import com.jd.jr.boss.credit.domain.common.enums.CreditCallbackBusinessTypeEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditCallbackTyeEnum;
import com.jd.jr.boss.credit.domain.common.enums.OpenOrCloseStatusEnum;
import com.jd.jr.boss.credit.facade.authen.api.CreditTradeInterfaceFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.CallbackUrlQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.EntQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.BasicInfoQueryFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.DoChargeFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.ResultData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.external.ExternalArgs;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.EnterpriseQueryParam;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.BasicInfoQueryData;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.EnterpriseProductEnum;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.RequestReferEnum;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.response.ResultDataEnum;
import com.wangyin.boss.credit.admin.enums.AccessCallModeEnum;
import com.wangyin.boss.credit.admin.enums.CreditSewageQueryTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditSourceEnum;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * @author trade调用接口
 * @since 2017/3/29
 */
@Service("creditTradeInterfaceFacade")
public class CreditTradeInterfaceFacadeImpl implements CreditTradeInterfaceFacade {
    private static Logger logger = LoggerFactory.getLogger(CreditTradeInterfaceFacadeImpl.class);
    @Resource
    private ForeignCallbackNoticeService foreignCallbackNoticeService;
    @Autowired
    private BasicInfoQueryFacade basicInfoQueryFacade;
    @Autowired
    AutoSewageChildService autoSewageChildService;
    @Autowired
    private DoChargeFacade doChargeFacade;
    @Override
    public CreditResponseData<String> doSewage(CreditRequestParam<EntQueryParam> request) {
        logger.info("接受到trade 入参：{}", JSON.toJSONString(request));
        CreditResponseData creditResponseData = new CreditResponseData();
        try {
            //验证入参
            List<String> callBackUrls = verifyParam(request,creditResponseData);
            if(creditResponseData.isSuccess()){
                EntQueryParam entQueryParam = new EntQueryParam();
                entQueryParam.setResource(CreditSourceEnum.API.toName());
                SimpleDateFormat sf =new SimpleDateFormat("yyyy-MM-dd");
                Calendar c = Calendar.getInstance();
                //默认两年
                entQueryParam.setEndFilterDateStr(sf.format(c.getTime()));
                c.add(Calendar.YEAR,-2);
                entQueryParam.setStartFilterDateStr(sf.format(c.getTime()));
                CreditRequestParam<EnterpriseQueryParam> requestParam = new CreditRequestParam<EnterpriseQueryParam>();
                EnterpriseQueryParam enterpriseQueryParam = new EnterpriseQueryParam();
                enterpriseQueryParam.setEnterpriseName(request.getParam().getQueryString());
                enterpriseQueryParam.setPageNo("1");
                enterpriseQueryParam.setPageSize("10000");
                BeanUtils.copyProperties(request,requestParam,"param");
                requestParam.setParam(enterpriseQueryParam);
                ExternalArgs arg = new ExternalArgs();
                arg.setReferEnum(RequestReferEnum.API);
                arg.setCallMode(AccessCallModeEnum.SEWAGE.toName());
                requestParam.setArg(arg);
                logger.info("调用基本信息入参：{}",JSON.toJSONString(requestParam));
                CreditResponseData<ResultData<EnterpriseQueryParam, BasicInfoQueryData>> resp = basicInfoQueryFacade.query(requestParam);
                if(resp.isSuccess()){
                    //调用计费接口
                    CreditRequestParam<String>  batchCharge = new CreditRequestParam<String>();
                    batchCharge.setSystemId(requestParam.getSystemId());
                    ExternalArgs argCharge = new ExternalArgs();
                    argCharge.setReferEnum(RequestReferEnum.API);
                    batchCharge.setArg(argCharge);
                    batchCharge.setTradeNo(requestParam.getTradeNo());
                    batchCharge.setParam(request.getParam().getQueryString());
                    CreditResponseData<ResultData<String, String>> batchRes = doChargeFacade.payPaiwu(batchCharge);
                    if(batchRes.isSuccess()) {//异步处理
                        if(CreditSewageQueryTypeEnum.PRO.toName().equals(request.getParam().getQueryType())){
                            autoSewageChildService.execute(callBackUrls,resp.getData().getResult(), request.getParam().getMerchantNo(), requestParam,entQueryParam);
                        }else {
                            autoSewageChildService.execute(callBackUrls,resp.getData().getResult(), request.getParam().getMerchantNo(), requestParam,entQueryParam);
                        }
                    }else{
                        logger.error("计费失败，{}",JSON.toJSONString(batchRes));
                        creditResponseData.setSuccess(false);
                        creditResponseData.setCode(resp.getCode());
                        creditResponseData.setMessage(resp.getMessage());
                    }
                }else {
                    logger.error("调用基本信息失败，{}",JSON.toJSONString(resp));
                    creditResponseData.setSuccess(false);
                    creditResponseData.setCode(resp.getCode());
                    creditResponseData.setMessage(resp.getMessage());
                }
            }
        } catch (Exception e) {
            creditResponseData.setSuccess(false);
            creditResponseData.setCode(ResultDataEnum.RESULT_SERVICE_FAIL.toName());
            creditResponseData.setMessage(ResultDataEnum.RESULT_SERVICE_FAIL.toDescription());
            logger.error("查询异常，{}",e);
        }
        logger.info("接受到trade 返回参数：{}", JSON.toJSONString(creditResponseData));
        return creditResponseData;
    }
    private List<String> verifyParam(CreditRequestParam<EntQueryParam> requestParam,CreditResponseData creditResponseData){
        if(StringUtils.isBlank(requestParam.getSystemId())){
            creditResponseData.setSuccess(false);
            creditResponseData.setCode(ResultDataEnum.REQUEST_USERID_REQUIRED.toName());
            creditResponseData.setMessage(ResultDataEnum.REQUEST_USERID_REQUIRED.toDescription());
        }
        if(StringUtils.isBlank(requestParam.getParam().getMerchantNo())){
            creditResponseData.setSuccess(false);
            creditResponseData.setCode(ResultDataEnum.RESULT_MERCHANT_NOTEXIST.toName());
            creditResponseData.setMessage(ResultDataEnum.RESULT_MERCHANT_NOTEXIST.toDescription());
        }else {
            CallbackUrlQueryParam callbackUrlQueryParam = new CallbackUrlQueryParam();
            callbackUrlQueryParam.setMerchantNo(requestParam.getParam().getMerchantNo());
            callbackUrlQueryParam.setProductCode(EnterpriseProductEnum.ENTERPRISE_ELIMINATE_NEGATIVE_REPORT.toName());
            callbackUrlQueryParam.setBusinessType(CreditCallbackBusinessTypeEnum.RESULT.toName());
            callbackUrlQueryParam.setUserPin(requestParam.getSystemId());
            callbackUrlQueryParam.setUrlStatus(OpenOrCloseStatusEnum.OPEN.toName());
            callbackUrlQueryParam.setCallBackType(CreditCallbackTyeEnum.url.getCode());
            List<CreditCallbackUrl> callbackUrlList = foreignCallbackNoticeService.queryCallbackUrlListByPrm(callbackUrlQueryParam);
            if(CollectionUtils.isEmpty(callbackUrlList)){
                creditResponseData.setSuccess(false);
                creditResponseData.setCode(ResultDataEnum.RESULT_URL_REQUIRED.toName());
                creditResponseData.setMessage(ResultDataEnum.RESULT_URL_REQUIRED.toDescription());
            }else {
                List<String> callBackUrls = new ArrayList<>();
                for(CreditCallbackUrl callbackUrl:callbackUrlList){
                    callBackUrls.add(callbackUrl.getCallbackUrl());
                }
                return callBackUrls;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        System.out.println("25%".compareTo("10.20%"));
    }

}
