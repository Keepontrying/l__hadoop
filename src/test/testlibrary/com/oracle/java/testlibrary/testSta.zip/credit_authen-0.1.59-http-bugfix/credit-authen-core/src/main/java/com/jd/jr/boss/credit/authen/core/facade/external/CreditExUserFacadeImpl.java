package com.jd.jr.boss.credit.authen.core.facade.external;

import com.jd.jdjr.commons.api.domain.SystemInfo;
import com.jd.jr.boss.credit.facade.authen.api.CreditRegisterFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditUserFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.FacadePortalSuperUserRequest;
import com.jd.jr.boss.credit.facade.authen.beans.param.UserQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditExRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.external.api.CreditExUserFacade;
import com.jd.jr.boss.credit.facade.external.beans.request.RegisterReq;
import com.jd.jr.boss.credit.facade.external.beans.request.UserQueryReq;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditRegisterResp;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditUserInterResp;
import com.jd.jr.esu.caservice.api.domain.common.LoginAccountRequest;
import com.jd.jr.esu.caservice.api.domain.common.LoginAccountResult;
import com.jd.jr.esu.caservice.api.domain.vo.login.LoginRequestVo;
import com.jd.jr.esu.caservice.api.domain.vo.login.LoginResultVo;
import com.jd.jr.esu.caservice.api.domain.vo.wrapper.OperatorWrapperRequestVo;
import com.jd.jr.esu.caservice.api.domain.vo.wrapper.OperatorWrapperResultVo;
import com.jd.jr.esu.caservice.api.enums.EmOperatorType;
import com.jd.jr.esu.caservice.api.service.login.LoginService;
import com.jd.jr.esu.caservice.api.service.wrapper.OpWrapperService;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author jiangbo
 * @since 2017/3/29
 */
@Service("creditExUserFacade")
public class CreditExUserFacadeImpl implements CreditExUserFacade {
    private static Logger logger = LoggerFactory.getLogger(CreditExUserFacadeImpl.class);

    @Autowired
    CreditUserFacade creditUserFacade;
    @Autowired
    protected LoginService loginService;

    public String sysIdQueryLoginInfo = ConfigUtil.getString("caservice.loginService.queryLoginInfo.sysId");
    public String  tokenQueryLoginInfo = ConfigUtil.getString("caservice.loginService.queryLoginInfo.token");
//
    public String sysIdQueryOperatorByLoginInfoAndOwner = ConfigUtil.getString("caservice.opWrapperService.queryOperatorByLoginInfoAndOwner.sysId");
    public String  tokenQueryOperatorByLoginInfoAndOwner = ConfigUtil.getString("caservice.opWrapperService.queryOperatorByLoginInfoAndOwner.token");
//
//    @Autowired
//    CompanyUserInfoQueryService companyUserInfoQueryService;
//
//    public String sysIdCompanyUser = ConfigUtil.getString("cuservice.companyUserInfoQueryService.querySingleCompanyUser.sysId");
//    public String  tokenCompanyUser = ConfigUtil.getString("cuservice.companyUserInfoQueryService.querySingleCompanyUser.token");

    @Autowired
    OpWrapperService opWrapperService;

    public CreditResponseData<CreditUserInterResp> queryCreditUserByParam(CreditExRequestParam<UserQueryReq> requestParam) {
        CreditResponseData<CreditUserInterResp> creditExResponseData = new CreditResponseData<CreditUserInterResp>();
        CreditRequestParam<UserQueryParam> request = new CreditRequestParam<UserQueryParam>();
        UserQueryParam userQueryParam = new UserQueryParam();
//        userQueryParam.setLoginName(requestParam.getParam().getEmail());
        BeanUtils.copyProperties(requestParam.getParam(), userQueryParam);
        request.setParam(userQueryParam);

        //CA006402(根据登录信息和商户号查询操作员信息)
        LoginAccountRequest<OperatorWrapperRequestVo> loginAccountRequest = new LoginAccountRequest<OperatorWrapperRequestVo>();
        SystemInfo systemInfo = new SystemInfo();
        systemInfo.setToken(tokenQueryOperatorByLoginInfoAndOwner);
        systemInfo.setSysId(sysIdQueryOperatorByLoginInfoAndOwner);
        loginAccountRequest.setSystemInfo(systemInfo);

        OperatorWrapperRequestVo operatorWrapperRequestVo = new OperatorWrapperRequestVo();
        operatorWrapperRequestVo.setOwner(requestParam.getOperator());
        operatorWrapperRequestVo.setQueryType(EmOperatorType.LOGIN_NAME);
        operatorWrapperRequestVo.setQueryValue(requestParam.getParam().getEmail());
        loginAccountRequest.setParam(operatorWrapperRequestVo);

        logger.info("queryCreditUserByParam opWrapperService.queryOperatorByLoginInfoAndOwner, request:{}", GsonUtil.getInstance().toJson(loginAccountRequest));
        LoginAccountResult<OperatorWrapperResultVo> loginAccountResult = opWrapperService.queryOperatorByLoginInfoAndOwner(loginAccountRequest);
        logger.info("queryCreditUserByParam opWrapperService.queryOperatorByLoginInfoAndOwner, loginAccountResult:{}", GsonUtil.getInstance().toJson(loginAccountResult));
        if (loginAccountResult != null && loginAccountResult.getCode().equals("00000") && loginAccountResult.getData() != null){
            OperatorWrapperResultVo operatorWrapperResultVo = loginAccountResult.getData();
            userQueryParam.setOperatorId(operatorWrapperResultVo.getOperatorId());
            userQueryParam.setLoginInfoId(operatorWrapperResultVo.getLoginInfoId());
            userQueryParam.setCompanyUserId(operatorWrapperResultVo.getCompanyUserId());
        }else {
            logger.error("queryCreditUserByParam opWrapperService.queryOperatorByLoginInfoAndOwner error, loginAccountResult:{}", GsonUtil.getInstance().toJson(loginAccountResult));

            creditExResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
            creditExResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
            creditExResponseData.setSuccess(false);
            creditExResponseData.setData(null);
            return  creditExResponseData;
        }

//        CreditResponseData<CreditUser> responseData = creditUserFacade.selectSingleCreditUserByParam(request);
        CreditResponseData<CreditUser> responseData = creditUserFacade.selectSingleCreditSuperUserByParam(request);

        creditExResponseData = new CreditResponseData<CreditUserInterResp>();
        if (responseData.getData() != null){
            CreditUserInterResp creditUserInterResp = new CreditUserInterResp();
            BeanUtils.copyProperties(responseData.getData(), creditUserInterResp,new String[]{"userId"});
            creditUserInterResp.setUserId(responseData.getData().getUserPin());
            creditExResponseData.setData(creditUserInterResp);
        }

        creditExResponseData.setMessage(responseData.getMessage());
        creditExResponseData.setCode(responseData.getCode());
        creditExResponseData.setSuccess(responseData.isSuccess());
        logger.info("queryCreditUserByParam creditExResponseData:{}", GsonUtil.getInstance().toJson(creditExResponseData));

        return creditExResponseData;
    }

    @Autowired
    CreditRegisterFacade creditRegisterFacade;

    public CreditResponseData<CreditRegisterResp> registerUser(CreditExRequestParam<RegisterReq> requestParam) throws Exception {
        CreditResponseData<CreditRegisterResp> creditExResponseData = new CreditResponseData<CreditRegisterResp>();
        try {
            CreditRequestParam<FacadePortalSuperUserRequest> request = new CreditRequestParam<FacadePortalSuperUserRequest>();
            FacadePortalSuperUserRequest facadePortalSuperUserRequest = new FacadePortalSuperUserRequest();
            BeanUtils.copyProperties(requestParam.getParam(), facadePortalSuperUserRequest);
            request.setOperator(requestParam.getOperator()==null?"mobile":requestParam.getOperator()); //记录创建来源系统
            request.setSystemId(requestParam.getSystemId());
            request.setParam(facadePortalSuperUserRequest);



            RegisterReq registerReq = requestParam.getParam();

            //CA006402(根据登录信息和商户号查询操作员信息)
            LoginAccountRequest<OperatorWrapperRequestVo> loginAccountRequest = new LoginAccountRequest<OperatorWrapperRequestVo>();
            SystemInfo systemInfo = new SystemInfo();
            systemInfo.setToken(tokenQueryOperatorByLoginInfoAndOwner);
            systemInfo.setSysId(sysIdQueryOperatorByLoginInfoAndOwner);
            loginAccountRequest.setSystemInfo(systemInfo);

            OperatorWrapperRequestVo operatorWrapperRequestVo = new OperatorWrapperRequestVo();
            operatorWrapperRequestVo.setOwner(registerReq.getMerchantNo());
            operatorWrapperRequestVo.setQueryType(EmOperatorType.LOGIN_NAME);
            operatorWrapperRequestVo.setQueryValue(registerReq.getUserName());
            loginAccountRequest.setParam(operatorWrapperRequestVo);

            logger.info("registerExUser opWrapperService.queryOperatorByLoginInfoAndOwner, request:{}", GsonUtil.getInstance().toJson(loginAccountRequest));
            LoginAccountResult<OperatorWrapperResultVo> loginAccountResult = opWrapperService.queryOperatorByLoginInfoAndOwner(loginAccountRequest);
            logger.info("registerExUser opWrapperService.queryOperatorByLoginInfoAndOwner, loginAccountResult:{}", GsonUtil.getInstance().toJson(loginAccountResult));
            if (loginAccountResult != null && loginAccountResult.getCode().equals("00000") && loginAccountResult.getData() != null){
                OperatorWrapperResultVo operatorWrapperResultVo = loginAccountResult.getData();
                facadePortalSuperUserRequest.setOperatorId(operatorWrapperResultVo.getOperatorId());
                facadePortalSuperUserRequest.setLoginInfoId(operatorWrapperResultVo.getLoginInfoId());
                facadePortalSuperUserRequest.setCompanyUserId(operatorWrapperResultVo.getCompanyUserId());
            }else {
                logger.error("opWrapperService.queryOperatorByLoginInfoAndOwner error, loginAccountResult:{}", GsonUtil.getInstance().toJson(loginAccountResult));
                creditExResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
                creditExResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
                creditExResponseData.setSuccess(false);
                creditExResponseData.setData(null);
                return  creditExResponseData;
            }

            //查询jrid
            LoginAccountRequest queryLoginInfoRequest = new LoginAccountRequest();

            SystemInfo systemInfoLoginAccount = new SystemInfo();
            systemInfoLoginAccount.setSysId(sysIdQueryLoginInfo);
            systemInfoLoginAccount.setToken(tokenQueryLoginInfo);

            queryLoginInfoRequest.setSystemInfo(systemInfoLoginAccount);

            LoginRequestVo loginRequestVo = new LoginRequestVo();
            loginRequestVo.setParamType("4");
            loginRequestVo.setParamValue(facadePortalSuperUserRequest.getLoginInfoId());
            queryLoginInfoRequest.setParam(loginRequestVo);

            LoginAccountResult<LoginResultVo> queryLoginInfoResult = loginService.queryLoginInfo(queryLoginInfoRequest);
            String jrid = null;
            if (queryLoginInfoResult != null && queryLoginInfoResult.getCode() != null && queryLoginInfoResult.getCode().equals("00000") && queryLoginInfoResult.getData() != null){
                jrid = queryLoginInfoResult.getData().getJrid();
            }else {
                logger.error("loginService.queryLoginInfo get email error, queryLoginInfoResult:{}", GsonUtil.getInstance().toJson(queryLoginInfoResult));
                creditExResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
                creditExResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
                creditExResponseData.setSuccess(false);
                creditExResponseData.setData(null);
                return  creditExResponseData;
            }

            facadePortalSuperUserRequest.setJrid(jrid);

//            CreditResponseData<Boolean> responseData = creditRegisterFacade.registerUser(request);

            //使用超级账户注册
            CreditResponseData<Boolean> responseData = creditRegisterFacade.registerSuperUser(request);

            if (responseData.getData() != null) {
                CreditRegisterResp creditRegisterResp = new CreditRegisterResp();
                creditRegisterResp.setRegisterSuccess(responseData.getData());
                creditExResponseData.setData(creditRegisterResp);
                if (creditRegisterResp.isRegisterSuccess() == true) {    //如果注册成功，查询用户信息

                    CreditExRequestParam<UserQueryReq> requestParamCreditUser = new CreditExRequestParam<UserQueryReq>();
                    UserQueryReq userQueryReq = new UserQueryReq();
                    userQueryReq.setEmail(requestParam.getParam().getUserName());
                    requestParamCreditUser.setParam(userQueryReq);
                    requestParamCreditUser.setOperator(registerReq.getMerchantNo());
                    logger.info("registerUser isRegisterSuccess is true, queryCreditUserByParam:{}", GsonUtil.getInstance().toJson(requestParamCreditUser));
                    CreditResponseData<CreditUserInterResp> creditResponseCreditUserResp = this.queryCreditUserByParam(requestParamCreditUser);
                    logger.info("registerUser isRegisterSuccess is true, creditResponseCreditUserResp:{}", GsonUtil.getInstance().toJson(creditResponseCreditUserResp));
                    if (creditResponseCreditUserResp.isSuccess() == true && creditResponseCreditUserResp.getData() != null) {
                        creditRegisterResp.setCreditUserResp(creditResponseCreditUserResp.getData());
                        creditExResponseData.setData(creditRegisterResp);
                    } else {
                        //查询用户信息失败，返回错误结果。
                        logger.error("registerUser queryCreditUserByParam is not success");
                        creditExResponseData.setSuccess(false);
                        creditExResponseData.setCode(creditResponseCreditUserResp.getCode());
                        creditExResponseData.setMessage(creditResponseCreditUserResp.getMessage());
                        logger.info("registerUser creditExResponseData:{}", GsonUtil.getInstance().toJson(creditExResponseData));
                        return creditExResponseData;
                    }
                }
            }


            creditExResponseData.setMessage(responseData.getMessage());
            creditExResponseData.setCode(responseData.getCode());
            creditExResponseData.setSuccess(responseData.isSuccess());
            logger.info("registerUser creditExResponseData:{}", GsonUtil.getInstance().toJson(creditExResponseData));
        }catch (Exception e){
            logger.error("registerUser requestParam:{}", GsonUtil.getInstance().toJson(requestParam), e);
            creditExResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditExResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditExResponseData.setSuccess(false);
            creditExResponseData.setData(null);
        }



        return creditExResponseData;
    }

}
