package com.jd.jr.boss.credit.authen.core.constants;
/** 
* @desciption : hsp常量类
* @author : yangjinlin@jd.com
* @date ：2017年7月25日 下午9:34:18 
* @version 1.0 
* @return  */
public class HspConstant {
	
	/*---------------------  HSP文件系统       start    -------------------*/
	/**
	 * 文件系统的连接串
	 */
	public static final String HSP_CONNECT_STRING = "hsp.connect.string";
	/**
	 * 用户ID：征信门户
	 */
	public static final String HSP_PORTAL_APPID = "hsp.portal.appid";
	/**
	 * 用户密码：征信门户
	 */
	public static final String HSP_PORTAL_APPPWD = "hsp.portal.apppwd";
	/**
	 * http server域名
	 */
	public static final String HSP_HTTPSERVER_URL = "hsp.httpserver.url";
	/**
	 * mini文件在hsp上的路径
	 */
	public static final String HSP_PORTAL_MINI_PATH = "hsp.portal.mini.path";
	/**
	 * mini文件在hsp上的路径
	 */
	public static final String HSP_PORTAL_ELIMNEGREPORT_ZIP_PATH = "hsp.portal.elimNegReport.zip.path";
	
	/**
	 * mini文件在hsp上的路径
	 */
	public static final String HSP_PORTAL_MINI_PATH_SFTP = "hsp.portal.mini.path.sftp";
	/**
	 * 标准信用报告在hsp上的路径
	 */
	public static final String HSP_PORTAL_STANDARD_REPORT_PATH = "hsp.portal.standard.report.path";
	/**
	 * 反洗钱批量查询结果文件在hsp上的路径
	 */
	public static final String HSP_PORTAL_ANTI_MONEY_PATH = "hsp.portal.anti.money.path";

    /**
     * 车贷信用报告在hsp上的路径
     */
    public static final String HSP_PORTAL_CARLOAN_REPORT_PATH = "hsp.portal.carloan.report.path";
	/**
	 * 疑似企业关系批量查询结果文件在hsp上的路径
	 */
	public static final String HSP_ENT_PERSON_RELATION_PATH = "hsp.portal.ent.person.relation.path";
	/**
	 * 发票识别批量查询在hsp上的路径
	 */
	public static final String HSP_PORTAL_OCR_INVOICE_PATH = "hsp.portal.ocr.invoice.path";

	/**
	 * POP关联批量查询在hsp上的路径
	 */
	public static final String HSP_PORTAL_POP_RELATION_PATH = "hsp.portal.pop.relation.path";

	/*---------------------  HSP文件系统       end    -------------------*/

}
