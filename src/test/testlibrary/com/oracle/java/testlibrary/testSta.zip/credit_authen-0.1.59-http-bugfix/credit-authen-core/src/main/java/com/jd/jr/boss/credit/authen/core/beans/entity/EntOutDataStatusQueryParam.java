package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;

/**
 * @Auther: anmeng
 * @Date: 2018/12/12 09:58
 * @Description:
 */
public class EntOutDataStatusQueryParam implements Serializable {
    private static final long serialVersionUID = 6425320313715296101L;

    private String dt;
    private String status;
    private String interfaceCode;
    private String batchId;//批次号

    private int limit;
    private int start;

    public String getDt() {
        return dt;
    }

    public void setDt(String dt) {
        this.dt = dt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getInterfaceCode() {
        return interfaceCode;
    }

    public void setInterfaceCode(String interfaceCode) {
        this.interfaceCode = interfaceCode;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }
}
