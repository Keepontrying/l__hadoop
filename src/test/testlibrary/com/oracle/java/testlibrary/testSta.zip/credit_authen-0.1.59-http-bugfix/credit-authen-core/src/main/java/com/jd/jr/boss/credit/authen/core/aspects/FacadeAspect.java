package com.jd.jr.boss.credit.authen.core.aspects;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.utils.SystemInfoUtil;
import com.jd.jr.boss.credit.facade.common.dto.CreditExRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.common.dto.SystemInfo;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.Date;

/**
 *
 */
@Component
@Aspect
public class FacadeAspect {

    private static Logger logger= LoggerFactory.getLogger(FacadeAspect.class);


    @Around("execution(* com.jd.jr.boss.credit.authen.core.facade.external.*FacadeImpl.*(..))")
    public Object preHandle(ProceedingJoinPoint  point) {
        Date startTime = new Date();
        Object[] args = point.getArgs();
        CreditExRequestParam requestParam = (CreditExRequestParam) args[0];
        SystemInfo systemInfo = new SystemInfo();
        BeanUtils.copyProperties(requestParam, systemInfo);

        Signature sig = point.getSignature();
        MethodSignature msig = null;
        if (!(sig instanceof MethodSignature)) {
            throw new IllegalArgumentException("该注解只能用于方法");
        }
        msig = (MethodSignature) sig;
        Object target = point.getTarget();
        Method currentMethod = null;
        try {
            currentMethod = target.getClass().getMethod(msig.getName(), msig.getParameterTypes());
            logger.info("{},param:{}",currentMethod.getName(), JSONObject.toJSONString(args));
        } catch (NoSuchMethodException e) {
            logger.error("",e);
        }

        if (!systemInfo.getBussId().equals("credit_wanxiang") && currentMethod.getName().equals("createOrder")){
            logger.error("SystemInfoUtil check false,systemInfo:{}",  JSONObject.toJSONString(systemInfo));
            CreditResponseData creditExResponseData = new CreditResponseData();
            creditExResponseData.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
            return creditExResponseData;
        }


        if (!SystemInfoUtil.check(systemInfo)){
            logger.error("SystemInfoUtil check false,systemInfo:{}",  JSONObject.toJSONString(systemInfo));
            CreditResponseData creditExResponseData = new CreditResponseData();
            creditExResponseData.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
            return creditExResponseData;
        }

        try {
            return point.proceed();
        } catch (Throwable throwable) {
            logger.error("facade aspect processed fail ",throwable);
            CreditResponseData creditExResponseData = new CreditResponseData();
            creditExResponseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            return creditExResponseData;
        }
    }

}
