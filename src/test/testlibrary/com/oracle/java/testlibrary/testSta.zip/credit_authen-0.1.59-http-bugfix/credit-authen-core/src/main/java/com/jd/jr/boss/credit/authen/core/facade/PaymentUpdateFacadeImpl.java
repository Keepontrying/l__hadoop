package com.jd.jr.boss.credit.authen.core.facade;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.authen.core.biz.AccountManageBiz;
import com.jd.jr.boss.credit.facade.site.api.CreditPaymentUpdateFacade;
import com.jd.jr.boss.credit.facade.site.api.dto.request.paymentupdate.PaymentUpdateRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.paymentupdate.PaymentUpdateResponse;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;

/**
 * Created by anmeng on 2016/11/22.
 */
@Service("paymentUpdateFacade")
public class PaymentUpdateFacadeImpl implements CreditPaymentUpdateFacade {

    private Logger logger = LoggerFactory.getLogger(PaymentUpdateFacadeImpl.class);

    @Autowired
    private AccountManageBiz accountManageBiz;


    @Override
    public ResponseData<PaymentUpdateResponse> updatePaymentStatus(RequestParam<PaymentUpdateRequest> requestParam) {
        logger.info("PaymentUpdateFacadeImpl 手动更新缴费信息参数：", GsonUtil.getInstance().toJson(requestParam.getParam()));
        ResponseData<PaymentUpdateResponse> result=new ResponseData<PaymentUpdateResponse>();
        try {
        PaymentUpdateRequest req = requestParam.getParam();
        String merchantNo = req.getMerchantNo();
        if(StringUtils.isBlank(merchantNo)){
        	result.setResponseMessage(ResponseMessage.PARAM_IS_REQUIRED);
        	result.setMessage("商户号不能为空"); 
        	return result;
        }
        Long money = req.getMoney();
        
        PaymentUpdateResponse data = new PaymentUpdateResponse();
		data.setMerchantNo(merchantNo);
		data.setMoney(money); 
		data.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
		result.setData(data );
            //如果money不为空，则对商户的单笔账户进行充值
            if (NumberUtils.isDigits(String.valueOf(money))) {
                accountManageBiz.resetSingleBalance(merchantNo, money,result);
            }
            //处理包量list，处理合同状态及资费余量信息
            accountManageBiz.resetPackageBalance(req.getPaymentPackageList(),result);
            logger.info("updatePaymentStatus 手动充值返回结果："+GsonUtil.getInstance().toJson(result));  
        } catch (Exception e) {
            logger.error("手工更新缴费信息失败！",e);
            result.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        return result;
    }
}
