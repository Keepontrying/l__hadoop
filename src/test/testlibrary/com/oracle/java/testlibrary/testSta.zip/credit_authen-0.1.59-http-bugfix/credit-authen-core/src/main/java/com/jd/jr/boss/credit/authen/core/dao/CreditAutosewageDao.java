package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.facade.authen.beans.param.WxUserParam;
import com.wangyin.boss.credit.admin.entity.CreditAutosewageUrl;
import com.wangyin.boss.credit.admin.entity.CreditWxUser;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 *  排污跑批url信息记录表
 * @author liuwei
 * @since 2017.03.29
 */
@Repository
public interface CreditAutosewageDao {
	/**
	 * 获取用户绑定信息
	 * @return
	 */
	List<CreditAutosewageUrl> getByParam(CreditAutosewageUrl creditAutosewageUrl);
	/**
	 * 插入绑定信息
	 * @return
	 */
	boolean insertAutosewageUrl(CreditAutosewageUrl creditAutosewageUrl);

}