package com.jd.jr.boss.credit.core.test.listener;

		import com.jd.jmq.common.message.Message;
		import com.jd.jr.boss.credit.authen.core.jms.weixin.CreditWeixinListener;
		import org.junit.Test;
		import org.junit.runner.RunWith;
		import org.springframework.test.context.ContextConfiguration;
		import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


		import javax.annotation.Resource;
		import java.util.ArrayList;
		import java.util.List;

/**
 * @desciption : 海关mq测试类
 * @author : liuwei@jd.com
 * @date ：2017年7月20日 下午5:56:59
 * @version 1.0
 * @return  */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/spring-authen.xml" })

public class WxListenerTest {

	@Resource
	private CreditWeixinListener creditWeixinListener;

	@Test
	public void testMessage() throws Exception {

		List<Message> messages = new ArrayList<Message>();
		Message message = new Message();
//		message.setText("{\"eventKey\":\"\",\"eventType\":\"subscribe\",\"fromUserName\":\"oCMLOwqdnFSc-t_vS8Dt9YaFJx9U\",\"msgType\":\"event\",\"systemId\":\"test_lw\",\"time\":1503306739525}\n");
//		message.setText("{\"eventKey\":\"myWarning\",\"eventType\":\"CLICK\",\"fromUserName\":\"oCMLOwqdnFSc-t_vS8Dt9YaFJx9U\",\"msgType\":\"event\",\"systemId\":\"test_lw\",\"time\":1503031135871}\n");
//		message.setText("{\"eventKey\":\"creditInfo\",\"eventType\":\"CLICK\",\"fromUserName\":\"oCMLOwqdnFSc-t_vS8Dt9YaFJx9U\",\"msgType\":\"event\",\"systemId\":\"test_lw\",\"time\":1504592282037}");
//		message.setText("{\"eventType\":\"TEMPLATESENDJOBFINISH\",\"fromUserName\":\"oCMLOwqdnFSc-t_vS8Dt9YaFJx9U\",\"msgType\":\"event\",\"systemId\":\"test_lw\",\"time\":1504593598405}");
		message.setText("{\"eventKey\":\"creditInfo\",\"eventType\":\"CLICK\",\"fromUserName\":\"oCMLOwkIUXjO6NNBcqKXdPoXQGXM\",\"msgType\":\"event\",\"systemId\":\"test_lw\",\"time\":1504595996844}");
		messages.add(message);
//		creditWeixinListener.onMessage(messages);

	}


}
