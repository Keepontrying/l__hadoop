package com.jd.jr.boss.credit.authen.core.dao;

import com.wangyin.boss.credit.admin.entity.CreditMerchantLogo;
import org.springframework.stereotype.Repository;

/**
 * Created by zhanghui12 on 2018/5/15.
 * 标准信用报告——商户logo数据层
 */
@Repository
public interface CreditMerchantLogoDao {
    /**
     * 添加商户logo
     *
     * @param merchantLogo
     * @return
     */
    Integer addLogo(CreditMerchantLogo merchantLogo);

    /**
     * 修改商户logo
     *
     * @param merchantLogo
     * @return
     */
    int updateLogo(CreditMerchantLogo merchantLogo);

    /**
     * 查询商户logo
     *
     * @param merchantLogo
     * @return
     */
    CreditMerchantLogo queryLogo(CreditMerchantLogo merchantLogo);


}
