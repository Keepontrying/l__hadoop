package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.request.NetTrackerEntQueryParam;
import com.jd.jr.boss.credit.domain.common.entity.CreditNetTrackerEnterprise;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Created by anmeng on 2017/10/26.
 */
@Repository
public interface CreditNetTrackerEnterpriseDao {

    int insert(CreditNetTrackerEnterprise enterprise);

    int update(CreditNetTrackerEnterprise enterprise);

    List<CreditNetTrackerEnterprise> query(NetTrackerEntQueryParam queryParam);

    int queryCount(NetTrackerEntQueryParam queryParam);

    /**
     * 查询单个监控企业
     * 企业id+商户id
     * 监控id
     * @param queryParam
     * @return
     */
    CreditNetTrackerEnterprise querySingle(NetTrackerEntQueryParam queryParam);

    /**
     * 统计分组数量
     * @param merchantId
     * @return
     */
    List<Map<String,Number>> queryGroupStatistics(Integer merchantId);

}
