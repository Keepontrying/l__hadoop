package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;

/**
 * Created by anmeng on 2016/12/13.
 */
public class AccessDetailsQueryParamExtend extends AccessDetailsQueryParam implements Serializable {

    private static final long serialVersionUID = 3280540638110479435L;

    /**
     * 商户号
     */
    private String merchantNo;

    /**
     * 商户账户代码
     */
    private String merchantCode;

    /**
     * 产品名称
     */
    private Integer productId;
    /**
     * 调用模式
     */
    private String callMode;

    /**
     * 商户业务流水号
     */
    private String orderNo;

    /**
     * 计费策略ID
     */
    private Integer strategyId;

    private String creditType;//PERSON ENTERPRISE

    /**
     * 分页参数
     */
    private Integer start;
    private Integer limit;

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getCallMode() {
        return callMode;
    }

    public void setCallMode(String callMode) {
        this.callMode = callMode;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Integer getStrategyId() {
        return strategyId;
    }

    public void setStrategyId(Integer strategyId) {
        this.strategyId = strategyId;
    }

    public String getMerchantCode() {
        return merchantCode;
    }

    public void setMerchantCode(String merchantCode) {
        this.merchantCode = merchantCode;
    }

    public String getCreditType() {
        return creditType;
    }

    public void setCreditType(String creditType) {
        this.creditType = creditType;
    }
}
