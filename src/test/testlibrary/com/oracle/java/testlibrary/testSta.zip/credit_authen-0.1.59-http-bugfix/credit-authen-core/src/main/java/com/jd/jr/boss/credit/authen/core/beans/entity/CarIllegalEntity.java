package com.jd.jr.boss.credit.authen.core.beans.entity;

import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.car.CarIllegalQueryDetails;

import java.io.Serializable;

/**
 * 违章详情
 *
 * @author tangmingbo
 * @data 2017/11/01
 */
public class CarIllegalEntity extends CarIllegalQueryDetails implements Serializable {

	private static final long serialVersionUID = -4699695897025075467L;
	/**
		 * 车牌号
		 */
	    private String plateNumber;
	    /**
	   	 * 车架号，具体是否必填及长度要求参考各城市要求，从【违章查询条件】接口获取
	   	 */
	       private String vin;
	       /**
	   	 * 发动机号，具体是否必填及长度要求参考各城市要求，从【违章查询条件】接口获取
	   	 */
	       private String engineNo;
	/**
	 * 未处理违章总罚款
	 */
    private String totalFine;
    /**
	 * 未处理违章总扣分
	 */
    private int totalPoints;
    /**
	 * 未处理违章条数
	 */
    private int untreated;
    /**
   	 * 违章处理状态：1：未处理，2：处理中，3：已处理
   	 */
       private String processStatusStr;
       /**
   	 * 违章缴费状态 不返回表示无法获取该信息，1-未缴费 2-已缴费
   	 */
       private String paymentStatusStr;
	/**
	 * @return the totalFine
	 */
	public String getTotalFine() {
		return totalFine;
	}
	/**
	 * @param totalFine the totalFine to set
	 */
	public void setTotalFine(String totalFine) {
		this.totalFine = totalFine;
	}
	/**
	 * @return the totalPoints
	 */
	public int getTotalPoints() {
		return totalPoints;
	}
	/**
	 * @param totalPoints the totalPoints to set
	 */
	public void setTotalPoints(int totalPoints) {
		this.totalPoints = totalPoints;
	}
	/**
	 * @return the untreated
	 */
	public int getUntreated() {
		return untreated;
	}
	/**
	 * @param untreated the untreated to set
	 */
	public void setUntreated(int untreated) {
		this.untreated = untreated;
	}
	/**
	 * @return the plateNumber
	 */
	public String getPlateNumber() {
		return plateNumber;
	}
	/**
	 * @param plateNumber the plateNumber to set
	 */
	public void setPlateNumber(String plateNumber) {
		this.plateNumber = plateNumber;
	}
	/**
	 * @return the vin
	 */
	public String getVin() {
		return vin;
	}
	/**
	 * @param vin the vin to set
	 */
	public void setVin(String vin) {
		this.vin = vin;
	}
	/**
	 * @return the engineNo
	 */
	public String getEngineNo() {
		return engineNo;
	}
	/**
	 * @param engineNo the engineNo to set
	 */
	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}
	/**
	 * @return the processStatusStr
	 */
	public String getProcessStatusStr() {
		return processStatusStr;
	}
	/**
	 * @param processStatusStr the processStatusStr to set
	 */
	public void setProcessStatusStr(String processStatusStr) {
		this.processStatusStr = processStatusStr;
	}
	/**
	 * @return the paymentStatusStr
	 */
	public String getPaymentStatusStr() {
		return paymentStatusStr;
	}
	/**
	 * @param paymentStatusStr the paymentStatusStr to set
	 */
	public void setPaymentStatusStr(String paymentStatusStr) {
		this.paymentStatusStr = paymentStatusStr;
	}
}
