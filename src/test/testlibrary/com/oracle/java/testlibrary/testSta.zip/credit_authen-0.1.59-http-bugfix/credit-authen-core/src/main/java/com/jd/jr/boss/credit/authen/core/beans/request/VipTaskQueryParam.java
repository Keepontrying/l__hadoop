package com.jd.jr.boss.credit.authen.core.beans.request;

import com.wangyin.operation.common.beans.PageQuery;

import java.io.Serializable;

/**
 * @author jiangbo
 * @since 2017/6/15
 */
public class VipTaskQueryParam extends PageQuery implements Serializable{

    private static final long serialVersionUID = 2581021826702706183L;

    /**
     * vipid
     */
    private Integer vipId;
    /**
     * 任务状态
     */
    private String taskStatus;
    private Integer taskId;
    /**
     * 关联规则id
     */
    private Integer alarmRuleId;
    /**
     * 监控结果
     */
    private String taskResult;
    /**
     * 商户号
     */
    private String merchantNo;
    private String relationStatus;//关联企业的生效状态
    private String entNameRelation;//关联企业名称
    private String certificateNumber;//关联企业证件号
    private String startCreateDateStr;//开始创建日期
    private String endCreateDateStr;//截止创建日期
    private Integer merchantId;// 商户Id
    private Integer relationId;// 关联企业Id
    private Integer groupId;//关联id

    public Integer getVipId() {
        return vipId;
    }

    public void setVipId(Integer vipId) {
        this.vipId = vipId;
    }

    public String getTaskStatus() {
        return taskStatus;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

	public Integer getTaskId() {
		return taskId;
	}

	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}


    public String getTaskResult() {
        return taskResult;
    }

    public void setTaskResult(String taskResult) {
        this.taskResult = taskResult;
    }

    public Integer getAlarmRuleId() {
        return alarmRuleId;
    }

    public void setAlarmRuleId(Integer alarmRuleId) {
        this.alarmRuleId = alarmRuleId;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public String getRelationStatus() {
        return relationStatus;
    }

    public void setRelationStatus(String relationStatus) {
        this.relationStatus = relationStatus;
    }

    public String getEntNameRelation() {
        return entNameRelation;
    }

    public void setEntNameRelation(String entNameRelation) {
        this.entNameRelation = entNameRelation;
    }

    public String getCertificateNumber() {
        return certificateNumber;
    }

    public void setCertificateNumber(String certificateNumber) {
        this.certificateNumber = certificateNumber;
    }

    public String getStartCreateDateStr() {
        return startCreateDateStr;
    }

    public void setStartCreateDateStr(String startCreateDateStr) {
        this.startCreateDateStr = startCreateDateStr;
    }

    public String getEndCreateDateStr() {
        return endCreateDateStr;
    }

    public void setEndCreateDateStr(String endCreateDateStr) {
        this.endCreateDateStr = endCreateDateStr;
    }

    public Integer getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Integer merchantId) {
        this.merchantId = merchantId;
    }

    public Integer getRelationId() {
        return relationId;
    }

    public void setRelationId(Integer relationId) {
        this.relationId = relationId;
    }

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }
}
