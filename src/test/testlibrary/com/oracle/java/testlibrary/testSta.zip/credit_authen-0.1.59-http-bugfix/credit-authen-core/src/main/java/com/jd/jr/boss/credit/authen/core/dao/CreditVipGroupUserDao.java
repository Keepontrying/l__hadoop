package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.facade.authen.beans.param.VipGroupQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditVipAlarmRuleDetail;
import com.wangyin.boss.credit.admin.entity.CreditVipGroup;
import com.wangyin.boss.credit.admin.entity.CreditVipGroupUser;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption : 风险预警分组用户 数据接口
 * @date ：2018/12/19 09:34
 * @return
 */
@Repository
public interface CreditVipGroupUserDao {

    /**
     * 新增
     * @param record
     * @return
     */
    int insert(CreditVipGroupUser record);

    /**
     * 批量插入
     * @param userList
     * @return
     */
    int insertBatchGroupUsers(List<CreditVipGroupUser> userList);
    /**
     * 主键更新
     * @param vipGroupUser
     * @return
     */
    int updateByPrimaryKeySelective(CreditVipGroupUser vipGroupUser);

    /**
     * 多条件查询  分页
     * @param queryParam
     * @return
     */
    List<CreditVipGroup> selectVipGroupUserPageByParam(VipGroupQueryParam queryParam);

    /**
     * 多条件查询总记录数  分页
     * @param queryParam
     * @return
     */
    Integer selectVipGroupUserPageCountByParam(VipGroupQueryParam queryParam);

    /**
     * 根据userPin查询该用户生效中的所属分组id
     * @param userPin
     * @return
     */
    Integer selectOpenGroupIdByUserPin(String userPin);

    /**
     * 查询分组中的用户信息List 分页
     * @param param
     * @return
     */
    List<CreditVipGroupUser> queryGroupUserListByPrm(VipGroupQueryParam param);

    /**
     * 查询分组中的用户信息List总计数  分页
     * @param param
     * @return
     */
    Integer queryGroupUserListByPrmCount(VipGroupQueryParam param);

    /**
     * 查询 某用户隶属分组内的所有用户的企业征信联系邮箱List
     * @param param
     * @return
     */
    List<String> selectUserInGroupEmailList(VipGroupQueryParam param);

    /**
     * 查询 某用户隶属分组内的所有用户的企业征信联系邮箱List  总数
     * @param param
     * @return
     */
    Integer selectUserInGroupEmailListCount(VipGroupQueryParam param);
}
