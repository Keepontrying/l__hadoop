package com.jd.jr.boss.credit.authen.core.beans.entity.sewage;

import java.io.Serializable;

import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.basic.AlterRecordEntity;

public class AutoSewageAlterEntity extends AlterRecordEntity implements Serializable {


	private static final long serialVersionUID = 6628611493564691779L;
	/**
	 * 公司全称
	 */
	private String enterpriseName;
    /**
     * 内外部标识
     */
    private String entInnerFlag;
    /**
     * 风险等级
     */
    private String riskLevel;

	/**
	 * @return the enterpriseName
	 */
	public String getEnterpriseName() {
		return enterpriseName;
	}

	/**
	 * @param enterpriseName the enterpriseName to set
	 */
	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}

    public String getEntInnerFlag() {
        return entInnerFlag;
    }

    public void setEntInnerFlag(String entInnerFlag) {
        this.entInnerFlag = entInnerFlag;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }
}
