package com.jd.jr.boss.credit.authen.core.dao;

import com.wangyin.boss.credit.admin.entity.CreditVipAllCompanyCount;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface CreditVipAllCompanyCountDao {

    /**
     * 查询总体企业变更数量
     * @param beginDate
     * @param endDate
     * @return
     */
    List<CreditVipAllCompanyCount> query(@Param("beginDate") Date beginDate, @Param("endDate") Date endDate);

    /**
     * 保存企业总体数量
     * @param countEntity
     * @return
     */
    int insert(CreditVipAllCompanyCount countEntity);

    int deleteByPrimary(Integer id);
}