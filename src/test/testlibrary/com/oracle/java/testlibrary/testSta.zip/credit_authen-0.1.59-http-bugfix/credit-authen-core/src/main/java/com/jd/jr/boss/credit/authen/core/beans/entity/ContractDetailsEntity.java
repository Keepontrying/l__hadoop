package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.List;

import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;

/**
 *  企业站合同查询结果
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
public class ContractDetailsEntity extends ContractQueryEntity implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4108963654283821146L;
	private List<CreditProductStrategy> strategyList;

	public List<CreditProductStrategy> getStrategyList() {
		return strategyList;
	}

	public void setStrategyList(List<CreditProductStrategy> strategyList) {
		this.strategyList = strategyList;
	}    
}
