package com.jd.jr.boss.credit.authen.core.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.jd.jr.boss.credit.facade.authen.beans.param.MiniSampleQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.MiniCommAreaComplQueryParam;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniCommonCompletion;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniSampleBase;

/** 
* @desciption : 征信mini尽调时效dao
* @author : yangjinlin@jd.com
* @date ：2017年9月18日 下午9:41:11 
* @version 1.0 
* @return  */
@Repository
public interface CreditMiniCommonCompletionDao {

	/**
	 * 查询mini尽调时效List
	 * @param queryParam
	 * @return
	 */
	List<CreditMiniCommonCompletion> queryValidSampleCompletionList(MiniCommAreaComplQueryParam queryParam);


}
