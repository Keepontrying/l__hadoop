package com.jd.jr.boss.credit.authen.core.constants;

/**
 * @author jiangbo
 * @since 2017/4/18
 */
public class CacheConstants {

//    public static final int CREDIT_USER_INFO_EXPIRE =   2 * 60; //用户信息缓存2分

    public static String CACHE_DATA_PREFIX = "DATA_";
    public static String CACHE_ENT_CARLOAN_BASE = "ENT_CARLOAN_BASE_";//车贷基础报告
    public static String CACHE_ENT_CARLOAN_SELFRISK = "ENT_CARLOAN_SELFRISK_";//车贷自身风险
    public static String CACHE_ENT_CARLOAN_AROUNDRISK = "ENT_CARLOAN_AROUNDRISK_";//车贷周边风险

}
