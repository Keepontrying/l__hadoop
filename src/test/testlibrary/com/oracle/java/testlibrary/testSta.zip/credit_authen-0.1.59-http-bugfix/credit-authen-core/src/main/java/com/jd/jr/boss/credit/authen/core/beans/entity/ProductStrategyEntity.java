package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.Date;

import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;

/**
 *  合同包含产品实体类
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
public class ProductStrategyEntity  extends CreditProductStrategy  implements Serializable{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -5286845723736008819L;
	 /**
     * 账户代码
     */
    private String merchantCode;
    /**
     * 清结算账户
     */
    private String accountNo;
    /**
     * 合同销售人员
     */
    private String salesManager;
    /**
     * 合同到期日
     */
    private Date deadline;
    /**
     * 征信类型 : PERSON-个人征信;ENTERPRISE-企业征信
     */
    private String creditType;
    /**
     * 合同类型：ONLINE-线上； OFFLINE-线下
     */
    private String contractSource;
    
	public String getMerchantCode() {
		return merchantCode;
	}
	public void setMerchantCode(String merchantCode) {
		this.merchantCode = merchantCode;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getSalesManager() {
		return salesManager;
	}
	public void setSalesManager(String salesManager) {
		this.salesManager = salesManager;
	}
	public Date getDeadline() {
		return deadline;
	}
	public void setDeadline(Date deadline) {
		this.deadline = deadline;
	}
	public String getCreditType() {
		return creditType;
	}
	public void setCreditType(String creditType) {
		this.creditType = creditType;
	}
	public String getContractSource() {
		return contractSource;
	}
	public void setContractSource(String contractSource) {
		this.contractSource = contractSource;
	}
	
}
