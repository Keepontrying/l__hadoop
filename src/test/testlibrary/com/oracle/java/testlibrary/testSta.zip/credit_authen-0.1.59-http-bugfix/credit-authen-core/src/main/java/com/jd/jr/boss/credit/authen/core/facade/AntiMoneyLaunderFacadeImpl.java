package com.jd.jr.boss.credit.authen.core.facade;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.service.AntiMoneyLaunderService;
import com.jd.jr.boss.credit.facade.authen.api.AntiMoneyLaunderAuthenFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.AntiMoneyBatchQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.creditReport.CreateReportResponse;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * Created by zhanghui12 on 2018/6/22.
 * 反洗钱受益所有人查询服务
 */
@Service("antiMoneyLaunderAuthenFacade")
public class AntiMoneyLaunderFacadeImpl implements AntiMoneyLaunderAuthenFacade {
    private Logger logger = LoggerFactory.getLogger(AntiMoneyLaunderFacadeImpl.class);
    @Autowired
    private AntiMoneyLaunderService antiMoneyLaunderService;
    @Override
    public CreditResponseData batchQuery(CreditRequestParam<AntiMoneyBatchQueryParam> requestParam) {
        logger.info("AntiMoneyLaunder batchQuery begin,param:{}", JSONObject.toJSONString(requestParam));
        CreditResponseData creditResponseData = new CreditResponseData();
        CreateReportResponse result = new CreateReportResponse();
        try {
            if (requestParam == null || requestParam.getParam() == null||StringUtil.isEmpty(requestParam.getParam().getFileId())||0==requestParam.getParam().getTotalCount()) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                logger.error("AntiMoneyLaunder batchQuery error, requestParam is null");
                return creditResponseData;
            }
            Date now = new Date();
            logger.info("AntiMoneyLaunder batchQuery save to database");
            String batchNo = null;
            try {
                batchNo = antiMoneyLaunderService.saveBatchAndOrder(requestParam.getParam());
            } catch (Exception e) {
                logger.info(e.getMessage());
            }
            if (StringUtil.isNotEmpty(batchNo)) {
                logger.info("异步调用下单接口");
                antiMoneyLaunderService.batchTrade(requestParam.getParam(), batchNo);
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setSuccess(true);
                creditResponseData.setData(result);
            } else {
                creditResponseData.setMessage(ResponseMessage.BUSINESS_EXCEPTION.getDesc());
                creditResponseData.setCode(ResponseMessage.BUSINESS_EXCEPTION.name());
                creditResponseData.setSuccess(false);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            logger.info("batchTrade finished,response:{}", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }
}
