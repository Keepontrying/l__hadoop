package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.entity.JsfConfig;
import com.jd.jr.boss.credit.facade.authen.beans.entity.JsfConfigBean;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JsfConfigMapper {
    int deleteByPrimaryKey(Long id);

    int insert(JsfConfig record);

    int insertSelective(JsfConfig record);

    JsfConfig selectByPrimaryKey(Long id);
    /**
     * 根据产品id查询jsf配置
     * @param id
     * @return
     */
    JsfConfig selectByProductCode(int productId);

    int updateByPrimaryKeySelective(JsfConfig record);

    int updateByPrimaryKey(JsfConfig record);

    int selectCountBy(JsfConfigBean configBean);

    List<JsfConfig> selectList(JsfConfigBean configBean);

    List<String> getJsfConfigList(JsfConfigBean param);

    List<JsfConfig> getMethodListBy(JsfConfigBean param);
}