package com.jd.jr.boss.credit.core.test;

import com.jd.finance.common.utils.GsonUtils;
import com.jd.jr.boss.credit.domain.common.entity.CreditQueryBatch;
import com.jd.jr.boss.credit.domain.common.enums.CreditQueryBatchTypeEnum;
import com.jd.jr.boss.credit.facade.authen.api.CreditQueryBatchFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.VipTaskDtoQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.boss.credit.admin.entity.CreditVipGroupUser;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption :
 * @date ：2019/3/13 21:54
 * @return
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})
public class CreditQueryBatchTest {
    @Resource
    private CreditQueryBatchFacade creditQueryBatchFacade;

    @Test
    public void selectGroupIdByUserPinTest(){
        BatchQueryParam param = new BatchQueryParam();
        param.setMerchantNo("110046292");
        param.setStart((1 - 1) * 10);
        param.setLimit(10);
        param.setQueryType(CreditQueryBatchTypeEnum.ELIMINATE_NEGATIVE.toName());
        CreditUser userPrm = new CreditUser();
        List<CreditVipGroupUser> creditUserList = new ArrayList<>();
        CreditVipGroupUser creditUser1 = new CreditVipGroupUser();
        creditUser1.setGroupSplitFlag("NO");
        creditUser1.setUserPin("1329355a827f4a9b9972eab26750892d");
        creditUser1.setValidStatus("OPEN");
        creditUserList.add(creditUser1);
        CreditVipGroupUser creditUser2 = new CreditVipGroupUser();
        creditUser2.setGroupSplitFlag("NO");
        creditUser2.setUserPin("0a74277a3d704fd38ca744eef7e4f4d5");
        creditUser2.setValidStatus("OPEN");
        creditUserList.add(creditUser2);
        CreditVipGroupUser creditUser3 = new CreditVipGroupUser();
        creditUser3.setGroupSplitFlag("NO");
        creditUser3.setUserPin("a5176b29df1040d096c82d720c44d12f");
        creditUser3.setValidStatus("OPEN");
        creditUserList.add(creditUser3);
        userPrm.setGroupUserList(creditUserList);
        param.setCreditUser(userPrm);
        CreditPage<CreditQueryBatch> respPage =  creditQueryBatchFacade.queryBatchHistory(param);
        System.out.println("respPage : " + GsonUtil.getInstance().toJson(respPage));
    }

}
