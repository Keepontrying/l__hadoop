package com.jd.jr.boss.credit.authen.core.enums;

/**
 * 百望授权审核状态枚举
 */
public enum AuthStatus {
    WAITING("01","待审核"),
    PASS("02","通过"),
    NOT_PASS("03","不通过"),
    PASS_NO_DATA("04","审核通过未采集到数据"),;
    private String code;
    private String desc;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    AuthStatus(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }
    public static AuthStatus enumValueOf(String code) {
        AuthStatus[] values = AuthStatus.values();
        AuthStatus v = null;
        for (int i = 0; i < values.length; i++) {
            if (values[i].getCode().equalsIgnoreCase(code)) {
                v = values[i];
                break;
            }
        }
        return v;
    }
}
