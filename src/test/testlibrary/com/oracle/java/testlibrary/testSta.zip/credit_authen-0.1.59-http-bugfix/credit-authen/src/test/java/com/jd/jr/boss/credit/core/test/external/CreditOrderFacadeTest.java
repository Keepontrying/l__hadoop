package com.jd.jr.boss.credit.core.test.external;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.jd.jr.boss.credit.facade.common.dto.CreditExRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.external.api.CreditExOrderFacade;
import com.jd.jr.boss.credit.facade.external.beans.request.*;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditCashierResp;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditContractResp;
import com.jd.jr.boss.credit.facade.external.beans.response.CreditOrderMainResp;
import com.jd.jr.boss.credit.facade.external.enums.ContractStatusEnum;
import com.jd.jr.boss.credit.facade.external.enums.CreditOrderMainStatusEnum;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/**
 * Created by anmeng on 2018/5/29.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:springtest/jsf-consumer.xml" })
public class CreditOrderFacadeTest {

    @Autowired
    private CreditExOrderFacade creditExOrderFacade;

    @Test
    public void testValidOnlineContractStatus(){
        CreditExRequestParam<MerchantReq> requestParam=new CreditExRequestParam<MerchantReq>();
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        MerchantReq req=new MerchantReq();
        req.setMerchantNo("110038298");
        requestParam.setParam(req);

        CreditResponseData<Boolean> responseData= creditExOrderFacade.validOnlineContractStatus(requestParam);
        System.out.println(JSONObject.toJSONString(responseData));
    }

    @Test
    public void testQueryContract(){
        CreditExRequestParam<ContractQueryReq> requestParam=new CreditExRequestParam<>();
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        ContractQueryReq req=new ContractQueryReq();
        req.setMerchantNo("110038298");
        req.setStatus(ContractStatusEnum.VALID);
        req.setPageSize(10);
        req.setPageIndex(1);
        requestParam.setParam(req);

        CreditResponseData<List<CreditContractResp>> responseData= creditExOrderFacade.queryContract(requestParam);
        System.out.println(JSONObject.toJSONString(responseData));
    }

    @Test
    public void testCreateOrder(){
        CreditExRequestParam<OrderCreateReq> requestParam=new CreditExRequestParam<>();
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        OrderCreateReq req=new OrderCreateReq();
        req.setMerchantNo("110038298");
        req.setSkuList(Lists.newArrayList(10000,443,538,577,581,589,633,635));
        requestParam.setParam(req);
        CreditResponseData<CreditOrderMainResp> responseData=creditExOrderFacade.submitOrder(requestParam);
        System.out.println(JSONObject.toJSONString(responseData));
    }

    @Test
    public void testCancelOrder(){
        CreditExRequestParam<OrderMainQueryReq> requestParam=new CreditExRequestParam<>();
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        OrderMainQueryReq req=new OrderMainQueryReq();
        req.setOrderMainId(1549);
        requestParam.setParam(req);
        CreditResponseData<CreditOrderMainResp> responseData=creditExOrderFacade.cancelOrder(requestParam);
        System.out.println(JSONObject.toJSONString(responseData));
    }

    @Test
    public void testQueryOrder(){
        CreditExRequestParam<OrderMainQueryReq> requestParam=new CreditExRequestParam<>();
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        OrderMainQueryReq req=new OrderMainQueryReq();
        req.setMerchantNo("110038298");
//        req.setOrderStatus(CreditOrderMainStatusEnum.CANCELED);
        req.setPageIndex(1);
        req.setPageSize(10);
        requestParam.setParam(req);
        CreditResponseData<List<CreditOrderMainResp>> responseData=creditExOrderFacade.queryOrder(requestParam);
        System.out.println(JSONObject.toJSONString(responseData));
    }

    @Test
    public void testQueryOrderDetail(){
        CreditExRequestParam<OrderMainQueryReq> requestParam=new CreditExRequestParam<>();
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        OrderMainQueryReq req=new OrderMainQueryReq();
        req.setOrderMainId(1549);
        requestParam.setParam(req);
        CreditResponseData<CreditOrderMainResp> responseData=creditExOrderFacade.queryOrderDetail(requestParam);
        System.out.println(JSONObject.toJSONString(responseData));
    }

    @Test
    public void testGenerateCashierParam(){
        CreditExRequestParam<GenCashierParamReq> requestParam=new CreditExRequestParam<>();
        requestParam.setBussId("credit");
        requestParam.setSystemId("credit_mobile");
        requestParam.setToken("2686f89bcc4246538834045d3b3e61a7");
        requestParam.setOperator("hehe");

        GenCashierParamReq req=new GenCashierParamReq();
        req.setJrId("xxxx");
        req.setOrderMainId(1471);
        req.setReturnUrl("http://");
        req.setDetailUrl("http://");
        requestParam.setParam(req);
        CreditResponseData<CreditCashierResp> responseData=creditExOrderFacade.generateCashierParam(requestParam);
        System.out.println(JSONObject.toJSONString(responseData));
    }
}
