package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;
import java.util.List;

import com.wangyin.operation.common.beans.PageQuery;

public class ContractPageQueryParam extends PageQuery implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -320837725982571581L;

	/**
     * 商户号
     */
    private String marchantNo;

    /**
     * 账户代码
     */
    private String merchantCode;
    /**
     * 不查询合同状态列表
     */
    private List<String> contractStatusList;
    
    public String getMarchantNo() {
		return marchantNo;
	}

	public void setMarchantNo(String marchantNo) {
		this.marchantNo = marchantNo;
	}

	public String getMerchantCode() {
		return merchantCode;
	}

	public void setMerchantCode(String merchantCode) {
		this.merchantCode = merchantCode;
	}

	public List<String> getContractStatusList() {
		return contractStatusList;
	}

	public void setContractStatusList(List<String> contractStatusList) {
		this.contractStatusList = contractStatusList;
	}
}
