package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.facade.authen.beans.param.BatchDataQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.BatchDataEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BatchProcessingMapper {

    int selectCount(BatchDataQueryParam param);

    List<BatchDataEntity> selectList(BatchDataQueryParam param);

    int insert(BatchDataEntity batchDataEntity);

    int updateByPrimaryKey(BatchDataEntity batchDataEntity);
}
