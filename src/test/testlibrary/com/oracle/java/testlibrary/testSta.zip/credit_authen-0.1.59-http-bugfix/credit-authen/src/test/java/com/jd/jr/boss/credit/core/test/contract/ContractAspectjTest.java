//package com.jd.jr.boss.credit.core.test.contract;
//
//import javax.annotation.Resource;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//import org.springframework.test.context.transaction.TransactionConfiguration;
//
//import com.jd.jr.boss.credit.facade.site.api.CreditContractFacade;
//import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractDetailsRequest;
//import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractQueryRequest;
//import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractVerifyRequest;
//import com.jd.jr.boss.credit.facade.site.api.dto.response.contract.ContractContentResponse;
//import com.jd.jr.boss.credit.facade.site.api.dto.response.contract.ContractDetailsResponse;
//import com.jd.jr.boss.credit.facade.site.api.dto.response.contract.ContractQueryResponse;
//import com.jd.jr.boss.credit.facade.site.api.enums.request.ContractVerifyRequestEnum;
//import com.wangyin.operation.common.beans.Page;
//import com.wangyin.operation.common.beans.RequestParam;
//import com.wangyin.operation.common.beans.Response;
//import com.wangyin.operation.common.beans.ResponseData;
//import com.wangyin.operation.utils.GsonUtil;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = { "classpath:springtest/spring-dubbo-consumer.xml" })
//@TransactionConfiguration
//public class ContractAspectjTest  {
//	@Resource
//	private CreditContractFacade contractFacade;
//
//	@Test
//	public void testMain() {
//		try {
//			String merchantNo="110029819";
//			String merchantCode="110029819001";
//			Integer contractId = 360;
////			query(merchantNo,merchantCode);
////			details(contractId,merchantNo,merchantCode);
////			content(contractId,merchantNo,merchantCode);
//			//确认合同时需要确认合同状态不为待确认状态，否则手动修改数据库状态
//			verify(contractId,merchantNo,merchantCode);
//			//1.确认合同修改状态
//			//2.确认开户情况，单笔唯一账户，包量唯一账户
//			//3.确认缴费单生成状态
//			//4.确认单笔产品状态修改为open，包量产品状态为close
//			//4.确认缴费单接收状态，单笔账户充值，包量账户充值并修改状态为open
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//	}
//	 /**
//     * 合同查询
//     * @param contractQueryRequest
//     * @return
//     */
//    public void query(String merchantNo,String merchantCode){
//    	RequestParam<ContractQueryRequest> requestParam = new RequestParam<ContractQueryRequest>();
//    	ContractQueryRequest contractQueryRequest = new ContractQueryRequest();
//    	contractQueryRequest.setMerchantNo(merchantNo);
//    	contractQueryRequest.setMerchantCode(merchantCode);
//    	contractQueryRequest.setPageNo(1);
//    	contractQueryRequest.setPageSize(40);
//    	requestParam.setParam(contractQueryRequest);
//    	Page<ContractQueryResponse> page = contractFacade.query(requestParam);
//    	if(page.isSuccess()){
//    	for(ContractQueryResponse rr:page.getRows()){
//    		System.out.println(rr.getContractStatus().toName());
//    		System.out.println(rr.getContractStatus().toDescription());
//    	}
//    	}
//    	System.out.println(GsonUtil.getInstance().toJson(page));
//    }
//    /**
//     * 合同包含产品详情
//     * @param contractDetailsRequest
//     * @return
//     */
//    public void details(Integer contractId,String merchantNo,String merchantCode){
//    	RequestParam<ContractDetailsRequest> requestParam = new RequestParam<ContractDetailsRequest>();
//    	ContractDetailsRequest contractDetailsRequest = new ContractDetailsRequest();
//    	contractDetailsRequest.setContractId(contractId);
//    	contractDetailsRequest.setMerchantNo(merchantNo);
//    	contractDetailsRequest.setMerchantCode(merchantCode);
//    	requestParam.setParam(contractDetailsRequest);
//    	ResponseData<ContractDetailsResponse> responseData = contractFacade.details(requestParam);
//    	System.out.println(GsonUtil.getInstance().toJson(responseData));
//    }
//    /**
//     * 合同协议内容
//     * @param contractContentRequest
//     * @return
//     */
//    public void content(Integer contractId,String merchantNo,String merchantCode){
//    	RequestParam<ContractDetailsRequest> requestParam = new RequestParam<ContractDetailsRequest>();
//    	ContractDetailsRequest contractDetailsRequest = new ContractDetailsRequest();
//    	contractDetailsRequest.setContractId(contractId);
//    	contractDetailsRequest.setMerchantNo(merchantNo);
//    	contractDetailsRequest.setMerchantCode(merchantCode);
//    	requestParam.setParam(contractDetailsRequest);
//    	ResponseData<ContractContentResponse> responseData = contractFacade.content(requestParam);
//    	System.out.println(GsonUtil.getInstance().toJson(responseData));
//    }
//    /**
//     * 合同确认结果
//     * @param contractVerifyRequest
//     * @return
//     */
//    public void verify(Integer contractId,String merchantNo,String merchantCode){
//    	RequestParam<ContractVerifyRequest> requestParam = new RequestParam<ContractVerifyRequest>();
//    	ContractVerifyRequest contractVerifyRequest = new ContractVerifyRequest();
//    	contractVerifyRequest.setContractId(contractId);
//    	contractVerifyRequest.setMerchantNo(merchantNo);
//    	contractVerifyRequest.setMerchantCode(merchantCode);
//    	contractVerifyRequest.setVerifyStatus(ContractVerifyRequestEnum.PASS);
//    	requestParam.setParam(contractVerifyRequest);
//    	Response response = contractFacade.verify(requestParam);
//    	System.out.println(GsonUtil.getInstance().toJson(response));
//    }
//
//}
