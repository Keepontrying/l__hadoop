package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;

/**
 * Created by zhanghui12 on 2018/9/30.
 * 发票对象
 */
public class InvoiceEntity implements Serializable{

    private static final long serialVersionUID = -8966031672099862431L;
    private String filePath;//发票路径
    private String code;//发票代码
    private String number;//发票号码
    private String createDate;//开票日期
    private String checkCode;//校验码
    private String machineNo;//机器编号
    private String verifyNum;//查验次数
    private String verifyDate;//查验时间
    private String source;//发票出处
    private String buyerDom;//购方地址、电话
    private String buyerName;//购方名称
    private String buyerAccount;//购方银行账号
    private String buyerTaxNo;//购方纳税人识别号
    private String sellerDom;//销方地址、电话
    private String sellerName;//销方名称
    private String sellerAccount;//销方银行账号
    private String sellerTaxNo;//销方纳税人识别号
    private String remark;//备注
    private String goods;//货物信息
    private String totalAmount;//合计金额
    private String totalTax;//合计税额
    private String amountCapital;//价税合计大写
    private String amountOrdinary;//价税合计小写
    private String isCanceled;//是否作废 N：不作废Y：作废

    private String type;//发票种类

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getCheckCode() {
        return checkCode;
    }

    public void setCheckCode(String checkCode) {
        this.checkCode = checkCode;
    }

    public String getMachineNo() {
        return machineNo;
    }

    public void setMachineNo(String machineNo) {
        this.machineNo = machineNo;
    }

    public String getVerifyNum() {
        return verifyNum;
    }

    public void setVerifyNum(String verifyNum) {
        this.verifyNum = verifyNum;
    }

    public String getVerifyDate() {
        return verifyDate;
    }

    public void setVerifyDate(String verifyDate) {
        this.verifyDate = verifyDate;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getBuyerDom() {
        return buyerDom;
    }

    public void setBuyerDom(String buyerDom) {
        this.buyerDom = buyerDom;
    }

    public String getBuyerName() {
        return buyerName;
    }

    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public String getBuyerAccount() {
        return buyerAccount;
    }

    public void setBuyerAccount(String buyerAccount) {
        this.buyerAccount = buyerAccount;
    }

    public String getBuyerTaxNo() {
        return buyerTaxNo;
    }

    public void setBuyerTaxNo(String buyerTaxNo) {
        this.buyerTaxNo = buyerTaxNo;
    }

    public String getSellerDom() {
        return sellerDom;
    }

    public void setSellerDom(String sellerDom) {
        this.sellerDom = sellerDom;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public String getSellerAccount() {
        return sellerAccount;
    }

    public void setSellerAccount(String sellerAccount) {
        this.sellerAccount = sellerAccount;
    }

    public String getSellerTaxNo() {
        return sellerTaxNo;
    }

    public void setSellerTaxNo(String sellerTaxNo) {
        this.sellerTaxNo = sellerTaxNo;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getGoods() {
        return goods;
    }

    public void setGoods(String goods) {
        this.goods = goods;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getTotalTax() {
        return totalTax;
    }

    public void setTotalTax(String totalTax) {
        this.totalTax = totalTax;
    }

    public String getAmountCapital() {
        return amountCapital;
    }

    public void setAmountCapital(String amountCapital) {
        this.amountCapital = amountCapital;
    }

    public String getAmountOrdinary() {
        return amountOrdinary;
    }

    public void setAmountOrdinary(String amountOrdinary) {
        this.amountOrdinary = amountOrdinary;
    }

    public String getIsCanceled() {
        return isCanceled;
    }

    public void setIsCanceled(String isCanceled) {
        this.isCanceled = isCanceled;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
