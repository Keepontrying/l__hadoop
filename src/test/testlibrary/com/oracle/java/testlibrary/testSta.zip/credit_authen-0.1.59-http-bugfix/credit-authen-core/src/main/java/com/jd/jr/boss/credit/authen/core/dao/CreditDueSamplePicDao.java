package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.facade.authen.beans.param.mini.CreditDueSampleBaseQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.CreditDueSamplePicQueryParam;
import com.wangyin.boss.credit.admin.entity.mini.CreditDueSampleBase;
import com.wangyin.boss.credit.admin.entity.mini.CreditDueSamplePic;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Description: 拓客巡检样本图片表 数据持久层
 * User: yangjinlin@jd.com
 * Date: 2018/5/24 21:31
 * Version: 1.0
 */
@Repository
public interface CreditDueSamplePicDao {
    /**
     * 批量落地支付拓客图片信息
     * @param samplePicList
     */
    void saveBatchDueSamplePic(List<CreditDueSamplePic> samplePicList);
    /**
     * 多条件查询拓客巡检基本信息  List
     * @param dueBaseQryPrm
     * @return
     */
    List<CreditDueSamplePic> queryDueSamplePicByPrm(CreditDueSamplePicQueryParam dueBaseQryPrm);

    /**
     * 根据拓客巡检图片信息主键id更新相关内容
     * @param picModify
     */
    void updateByPrimaryKeySelective(CreditDueSamplePic picModify);
}
