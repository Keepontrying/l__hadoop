package com.jd.jr.boss.credit.core.test.job;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.jd.jr.boss.credit.authen.core.scheduler.ElaneFileReadJob;
import com.jd.jr.boss.credit.authen.core.service.ShippingDataQueryService;
import com.wangyin.schedule.client.job.TaskResult;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring/spring-authen.xml" })

public class ElaneTest {

	@Autowired
	private ElaneFileReadJob elaneFileReadJob;
	
	@Autowired
	private ShippingDataQueryService shippingDataQueryService;
	
//	@Test
//	public void Test1() {
//		try {
//			TaskResult doTask = elaneFileReadJob.doTask(null);
//			System.out.println(doTask);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
	
	@Test
	public void Test2() {
		try {
			shippingDataQueryService.task("EL");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
