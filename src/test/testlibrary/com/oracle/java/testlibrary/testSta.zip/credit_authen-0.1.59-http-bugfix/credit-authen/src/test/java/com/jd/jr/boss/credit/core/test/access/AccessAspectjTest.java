package com.jd.jr.boss.credit.core.test.access;

import com.jd.jr.boss.credit.domain.common.enums.ProductTableEnum;
import com.jd.jr.boss.credit.domain.common.enums.SuccessOrFailStatusEnum;
import com.jd.jr.boss.credit.facade.site.api.CreditAccessFacade;
import com.jd.jr.boss.credit.facade.site.api.dto.PageWithParam;
import com.jd.jr.boss.credit.facade.site.api.dto.request.access.AccessMakeRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.access.AccessQueryFileRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.access.AccessQueryRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.access.AccessQueryFileResponse;
import com.jd.jr.boss.credit.facade.site.api.dto.response.access.AccessQueryResponse;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:springtest/spring-dubbo-consumer.xml" })

public class AccessAspectjTest {
	@Resource
	private CreditAccessFacade accessFacade;
	
	@Test
	public void testQueryAccessList() {
		try {

			DateFormat df=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			String merchantNo="110031419";
			String merchantCode="";
			RequestParam<AccessQueryRequest> requestRequestParam=new RequestParam<AccessQueryRequest>();
			AccessQueryRequest accessQueryRequest=new AccessQueryRequest();
			accessQueryRequest.setMerchantNo(merchantNo);
			accessQueryRequest.setMerchantCode(merchantCode);
			accessQueryRequest.setProductName(ProductTableEnum.BANK_VERIFY);
			accessQueryRequest.setStartTime(df.parse("2016-01-01 00:00:00"));
			accessQueryRequest.setFinishTime(df.parse("2016-12-31 00:00:00"));
			accessQueryRequest.setStatus(SuccessOrFailStatusEnum.SUCCESS);
			accessQueryRequest.setPageNo(1);
			accessQueryRequest.setPageSize(100);
			requestRequestParam.setParam(accessQueryRequest);

			PageWithParam<AccessQueryResponse> page= accessFacade.queryAccessList(requestRequestParam);
			System.out.println(GsonUtil.getInstance().toJson(page));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Test
	public void testMakeFile() {
		try {
			DateFormat df=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			String merchantNo="110031419";
			String merchantCode="";
			RequestParam<AccessMakeRequest> requestRequestParam=new RequestParam<AccessMakeRequest>();
			AccessMakeRequest accessQueryRequest=new AccessMakeRequest();
			accessQueryRequest.setMerchantNo(merchantNo);
			accessQueryRequest.setMerchantCode(merchantCode);
			accessQueryRequest.setProductName(ProductTableEnum.BANK_VERIFY);
			accessQueryRequest.setStartTime(df.parse("2016-01-01 00:00:00"));
			accessQueryRequest.setFinishTime(df.parse("2016-12-31 00:00:00"));
			accessQueryRequest.setStatus(SuccessOrFailStatusEnum.SUCCESS);
			requestRequestParam.setParam(accessQueryRequest);
			accessFacade.makeFile(requestRequestParam);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
@Test
	public void testQueryFileList(){
		try {
			DateFormat df=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			String merchantNo="110031419";
			String merchantCode="";
			RequestParam<AccessQueryFileRequest> requestRequestParam=new RequestParam<AccessQueryFileRequest>();
			AccessQueryFileRequest accessQueryRequest=new AccessQueryFileRequest();
			accessQueryRequest.setMerchantNo(merchantNo);
			accessQueryRequest.setMerchantCode(merchantCode);
//			accessQueryRequest.setStartTime(df.parse("2016-01-01 00:00:00"));
//			accessQueryRequest.setFinishTime(df.parse("2016-12-31 00:00:00"));
			accessQueryRequest.setPageNo(1);
			accessQueryRequest.setPageSize(10);
			requestRequestParam.setParam(accessQueryRequest);

			PageWithParam<AccessQueryFileResponse> page=accessFacade.queryFileList(requestRequestParam);
			System.out.println(GsonUtil.getInstance().toJson(page));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}
