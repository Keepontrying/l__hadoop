package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.domain.common.entity.signcode.CreditSignCodeInfo;
import com.jd.jr.boss.credit.domain.common.entity.signcode.CreditSignCodeInfo;
import com.jd.jr.boss.credit.facade.authen.beans.param.CustomsQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.SigncodeQueryParam;

import java.util.List;

import org.springframework.stereotype.Repository;

/**
 * 中证码详情
 * @author huangzhiqiang
 * @data 2017/8/31
 */
@Repository
public interface CreditSignCodeInfoDao {

    /**
     * 插入中证码信息
     * @param signCodeInfo
     * @return
     */
    void insert(CreditSignCodeInfo signCodeInfo);

    /**
     * 多条件查询中证码信息  分页 
     * @param queryParam
     * @return
     */
    List<CreditSignCodeInfo> querySigncodeByPrm(SigncodeQueryParam queryParam);

	/**
	 * 多条件查询中证码信息总记录数  分页
	 * @param queryParam
	 * @return
	 */
    Integer querySigncodeByPrmCount(SigncodeQueryParam queryParam);

}
