package com.jd.jr.boss.credit.authen.core.scheduler;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.authen.core.constants.SystemConstants;
import com.jd.jr.boss.credit.authen.core.service.CreditLogService;
import com.jd.jr.boss.credit.authen.core.utils.DateUtils;
import com.jd.jr.boss.credit.domain.common.entity.CreditCallTimesGather;
import com.jd.jr.boss.credit.facade.authen.beans.param.CallTimesGatherQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.param.CreditLogQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.CreditTradeLogInfo;
import com.wangyin.schedule.client.job.ScheduleContext;
import com.wangyin.schedule.client.job.SchedulerJob;

/** 
* @desciption : 每日汇总产品调用量
* @author : yangjinlin@jd.com
* @date ：2018年4月10日 下午6:28:51 
* @version 1.0 
* @return  */
@Service
@Deprecated
public class CallTimesGatherJob implements SchedulerJob {

	private static final Logger LOGGER = LoggerFactory.getLogger(CallTimesGatherJob.class);
	
//	@Autowired
//	private CreditDealFlowService dealFlowService;
	@Autowired
	private CreditLogService creditLogService;
	
	@Override
	public void doJob(ScheduleContext scheduleContext) throws Exception {
		Long startTimeMillis = System.currentTimeMillis();
		LOGGER.info("==========CallTimesGatherJob start=========", this.getClass());
		try {
			Map<String, String> userDefineParams = scheduleContext.getParameters();
			// 获取json中以userDefine为key的参数
			String startTime = userDefineParams.get("startTime");
			String finishTime = userDefineParams.get("finishTime");
			if (StringUtils.isBlank(startTime)) {
				startTime = DateTime.now().minusDays(1).toString("yyyy-MM-dd");
			} else {
				startTime = DateTime.parse(startTime).toString("yyyy-MM-dd");
			}
			if (StringUtils.isBlank(finishTime)) {
				finishTime = DateTime.now().toString("yyyy-MM-dd");
			} else {
				finishTime = DateTime.parse(finishTime).toString("yyyy-MM-dd");
			}
			CreditLogQueryParam tradeLogQueryParam = new CreditLogQueryParam();
			tradeLogQueryParam.setStartOccursDateStr(startTime);
			tradeLogQueryParam.setEndOccursDateStr(finishTime);
//			dealFlowQueryParam.setAccessStatus(AccessStatusEnum.SUCCESS.toName());
//			dealFlowQueryParam.setRequestStep(AccessRequestStepEnum.FIRST.toName());
			List<CreditTradeLogInfo> tradeLogList = creditLogService.queryCallTimesGatherTradeLogListFromEs(tradeLogQueryParam);
			LOGGER.info("======== startTime:{}---finishTime:{} records size:{}", startTime, finishTime, tradeLogList.size());
			//group by merchant_no product_id charge_type resource access_status created_date ，统计出调用量
			if(CollectionUtils.isNotEmpty(tradeLogList) && tradeLogList.size() >0 ){
				for(CreditTradeLogInfo tradeLog : tradeLogList){
					CreditCallTimesGather callTimesGather = new CreditCallTimesGather();
					callTimesGather.setStartDate(DateUtils.formatDateSP(tradeLog.getOccursDate()));
					callTimesGather.setGatherNo(tradeLog.getMerchantNo() + "-"
							+ new DateTime(callTimesGather.getStartDate()).toString("yyyyMMdd") + "-"
							+ tradeLog.getProductId());
					callTimesGather.setMonthDate(new DateTime(callTimesGather.getStartDate()).toString("yyyy-MM"));
					callTimesGather.setMerchantNo(tradeLog.getMerchantNo());
					callTimesGather.setMerchantName(tradeLog.getMerchantName());
					callTimesGather.setProductId(tradeLog.getProductId().intValue());
					callTimesGather.setProductCode(tradeLog.getProductCode());
					callTimesGather.setProductName(tradeLog.getProductName());
//					callTimesGather.setChargeType(tradeLog.getChargeType());
					callTimesGather.setResource(tradeLog.getResource());
					callTimesGather.setAccessStatus(tradeLog.getAccessStatus());
					callTimesGather.setStepStatus(tradeLog.getStepStatus());
					callTimesGather.setCallMode(tradeLog.getCallMode());
					callTimesGather.setCallTimes(tradeLog.getCount());
					callTimesGather.setCreator(SystemConstants.PARAM_INPUT_OPERATOR);
					callTimesGather.setUserPin(tradeLog.getUserPin());
					callTimesGather.setCreatedDate(new Date());
					callTimesGather.setModifier(SystemConstants.PARAM_INPUT_OPERATOR);
					callTimesGather.setModifiedDate(new Date());
					// 先查询该汇总记录一否已被汇总过
					CallTimesGatherQueryParam callTimesGatherPrm = new CallTimesGatherQueryParam();
					callTimesGatherPrm.setMerchantNo(tradeLog.getMerchantNo());
					callTimesGatherPrm.setProductId(tradeLog.getProductId().intValue());
					callTimesGatherPrm.setAccessStatus(tradeLog.getAccessStatus());
					callTimesGatherPrm.setStepStatus(tradeLog.getStepStatus());
					callTimesGatherPrm.setCallMode(tradeLog.getCallMode());
					callTimesGatherPrm.setStartDate(new DateTime(callTimesGather.getStartDate()).toString("yyyy-MM-dd"));
					callTimesGatherPrm.setResource(tradeLog.getResource());
					callTimesGatherPrm.setUserPin(tradeLog.getUserPin());
					List<CreditCallTimesGather> callTimesGatherList = creditLogService.queryCallTimesGatherTradeLogList(callTimesGatherPrm);
					if(CollectionUtils.isNotEmpty(callTimesGatherList) && callTimesGatherList.size()>0){
						//该汇总记录已存在，则更新
						callTimesGather.setId(callTimesGatherList.get(0).getId());
						creditLogService.updateCallTimesGatherById(callTimesGather);
					}else {
						//该汇总记录不存在，则新增
						Integer resultId = creditLogService.insertCallTimesGather(callTimesGather);
					}
				}
			}
			
		} catch (Exception e) {
			LOGGER.error("CallTimesGatherJob failed, {}", e);
			e.printStackTrace();
		}
		Long endTimeMillis = System.currentTimeMillis();
		LOGGER.info("=============CallTimesGatherJob end，total time: "+((startTimeMillis - endTimeMillis) / 1000)+" s ==============");

	}

}
