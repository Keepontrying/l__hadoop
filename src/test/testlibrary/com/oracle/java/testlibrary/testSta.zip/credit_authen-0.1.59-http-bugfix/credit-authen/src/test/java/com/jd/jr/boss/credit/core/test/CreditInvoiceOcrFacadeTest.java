package com.jd.jr.boss.credit.core.test;

import com.jd.jr.boss.credit.domain.common.entity.CreditQueryBatch;
import com.jd.jr.boss.credit.facade.authen.api.CreditInvoiceOcrFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchInvoiceOcrParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * Created by zhanghui12 on 2018/9/28.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})
public class CreditInvoiceOcrFacadeTest {

    @Resource
    private CreditInvoiceOcrFacade creditInvoiceOcrFacade;
    @Test
    public void batchTradeTest(){
        CreditRequestParam<BatchInvoiceOcrParam> requestParam=new CreditRequestParam<>();
        BatchInvoiceOcrParam param =new BatchInvoiceOcrParam();
        param.setCount(61);
//        param.setFileId("1_1810_4_201");//
//        param.setFileName("test.rar");
        param.setFileId("1_181113_1_19");
        param.setFileName("发票.rar");
        param.setMerchantId(1143);
        param.setMerchantNo("110047704");
        param.setOperator("zhanghui001@jd.com");
        requestParam.setParam(param);
        CreditResponseData response = creditInvoiceOcrFacade.batchTrade(requestParam);
    }
    @Test
    public void batchQueryTest(){
        CreditRequestParam<BatchQueryParam> requestParam=new CreditRequestParam<>();
        BatchQueryParam param =new BatchQueryParam();
        param.setSort("desc");
        param.setQueryType("INVOICE_OCR_BATCH_QUERY");
        param.setStart(0);
        param.setLimit(10);
        requestParam.setParam(param);
        CreditPage<CreditQueryBatch> response = creditInvoiceOcrFacade.batchQuery(requestParam);
    }
}
