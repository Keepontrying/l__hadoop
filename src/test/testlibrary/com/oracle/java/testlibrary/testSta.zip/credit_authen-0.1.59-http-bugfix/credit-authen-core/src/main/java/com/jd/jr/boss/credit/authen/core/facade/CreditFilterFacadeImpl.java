package com.jd.jr.boss.credit.authen.core.facade;

import com.jd.jr.boss.credit.authen.core.service.CreditFilterService;
import com.jd.jr.boss.credit.facade.authen.api.CreditFilterFacade;
import com.jd.jr.boss.credit.facade.authen.beans.response.CreditFilterResp;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.commons.util.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author huangzhiqiang
 * @data 2017/9/12
 */
@Service("creditFilterFacade")
public class CreditFilterFacadeImpl implements CreditFilterFacade {
    private Logger logger = new Logger(CreditFilterFacadeImpl.class);

    @Autowired
    private CreditFilterService creditFilterService;

    @Override
    public CreditResponseData<CreditFilterResp> getFilter() {
        CreditResponseData<CreditFilterResp> responseData = new CreditResponseData();
        CreditFilterResp filterResp = new CreditFilterResp();
        filterResp.setProvince(creditFilterService.queryProvince());
        filterResp.setIndustry(creditFilterService.queryIndustry());
        filterResp.setRegStatus(creditFilterService.queryRegStatus());
        filterResp.setRegCapital(creditFilterService.queryRegCapital());
        filterResp.setRegTime(creditFilterService.queryRegTime());
        responseData.setData(filterResp);
        return responseData;
    }
}
