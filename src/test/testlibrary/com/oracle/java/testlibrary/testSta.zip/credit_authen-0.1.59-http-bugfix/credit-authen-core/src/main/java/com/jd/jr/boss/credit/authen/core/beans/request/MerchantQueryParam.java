package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;
import java.util.List;

/**
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption : 征信商户查询参数类
 * @date ：2017年1月22日 下午4:09:12
 * @return
 */
public class MerchantQueryParam implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 7722905686045513092L;

    private Integer merchantId;//征信商户ID

    private String merchantNo;//商户号

    private String merchantName;//商户名称

    private String merchantStatus;//商户状态

    private String auditStatus;//审批状态

    private String userId;

    private String userPin;

    private String userStatus;

    private List<String> merchantType;

    public Integer getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Integer merchantId) {
        this.merchantId = merchantId;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getMerchantStatus() {
        return merchantStatus;
    }

    public void setMerchantStatus(String merchantStatus) {
        this.merchantStatus = merchantStatus;
    }

    public String getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(String auditStatus) {
        this.auditStatus = auditStatus;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserStatus() {
        return userStatus;
    }

    public String getUserPin() {
        return userPin;
    }

    public void setUserPin(String userPin) {
        this.userPin = userPin;
    }

    public void setUserStatus(String userStatus) {
        this.userStatus = userStatus;
    }

    public List<String> getMerchantType() {
        return merchantType;
    }

    public void setMerchantType(List<String> merchantType) {
        this.merchantType = merchantType;
    }
}
