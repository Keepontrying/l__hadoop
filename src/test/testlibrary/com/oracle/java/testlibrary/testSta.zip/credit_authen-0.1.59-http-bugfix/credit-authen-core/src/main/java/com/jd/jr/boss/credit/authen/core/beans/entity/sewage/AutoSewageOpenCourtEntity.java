package com.jd.jr.boss.credit.authen.core.beans.entity.sewage;

import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.court.EntOpenCourtData;

import java.io.Serializable;

public class AutoSewageOpenCourtEntity extends EntOpenCourtData implements Serializable {

	private static final long serialVersionUID = 5277288565848734502L;
	/**
	 * 公司全称
	 */
	private String enterpriseName;
    /**
     * 内外部标识
     */
    private String entInnerFlag;
    /**
     * 风险等级
     */
    private String riskLevel;

	/**
	 * @return the enterpriseName
	 */
	public String getEnterpriseName() {
		return enterpriseName;
	}

	/**
	 * @param enterpriseName the enterpriseName to set
	 */
	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}

    public String getEntInnerFlag() {
        return entInnerFlag;
    }

    public void setEntInnerFlag(String entInnerFlag) {
        this.entInnerFlag = entInnerFlag;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }
}
