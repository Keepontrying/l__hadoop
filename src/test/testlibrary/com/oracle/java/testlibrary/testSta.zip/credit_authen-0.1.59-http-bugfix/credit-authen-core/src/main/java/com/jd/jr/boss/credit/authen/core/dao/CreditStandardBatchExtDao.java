package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.facade.authen.beans.param.BatchCreateReportParam;
import com.wangyin.boss.credit.admin.entity.CreditStandardBatchExt;
import org.springframework.stereotype.Repository;

/**
 * Created by zhanghui12 on 2018/5/17.
 */
@Repository
public interface CreditStandardBatchExtDao {

    Integer saveStandardBatch(CreditStandardBatchExt batchExt);

    int updateAuthFile(BatchCreateReportParam param);
}
