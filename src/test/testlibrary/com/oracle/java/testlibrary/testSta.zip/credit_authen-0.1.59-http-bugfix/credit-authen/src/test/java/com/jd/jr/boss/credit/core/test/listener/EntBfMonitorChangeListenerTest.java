package com.jd.jr.boss.credit.core.test.listener;

import com.jd.jr.boss.credit.authen.core.jms.entbfmt.EntBfMonitorChangeListener;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.jdjr.fmq.common.message.Message;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
/**
 * created by ChenKaiJu on 2018/9/20  14:01
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:spring/spring-authen.xml" })
public class EntBfMonitorChangeListenerTest {

    @Resource
    EntBfMonitorChangeListener entBfMonitorChangeListener;
    @Test
    public void testMessage() throws Exception {
        List<Message> messages = new ArrayList<Message>();
        String[] entlist={"安徽丰逸商贸有限公司","上海宾爵电子商务有限公司","北京京东世纪贸易有限公司","北京火力全开科技有限公司","小米科技有限责任公司","北京小米电子软件技术有限公司","华泰证券股份有限公司","杭州市地铁集团有限责任公司","北京字节跳动网络技术有限公司","华泰证券股份有限公司666"};
        for(String entName:entlist){
            Message message = new Message();
            String msg="{\"entName\": \""+entName+"\"}";
            message.setText(msg);
            messages.add(message);
        }
        entBfMonitorChangeListener.onMessage(messages);
    }
}
