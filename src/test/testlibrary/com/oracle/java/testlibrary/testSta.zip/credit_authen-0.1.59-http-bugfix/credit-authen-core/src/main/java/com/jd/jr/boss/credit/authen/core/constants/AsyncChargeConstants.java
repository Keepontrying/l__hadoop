package com.jd.jr.boss.credit.authen.core.constants;

/**
 * Description: 异步扣费常量类
 * User: yangjinlin@jd.com
 * Date: 2018/7/6 18:10
 * Version: 1.0
 */
public class AsyncChargeConstants {

    /**
     * 后置扣费时的余额不足
     */
    public static final String ASYNC_CHARGE_RESPONSE_MESSAGE_NO_FUNDS = "余额不足";

    /**
     * 后置扣费时的余额不足
     */
    public static final String ASYNC_CHARGE_RESPONSE_MESSAGE_FAIL_FUNDS = "计费失败";



}
