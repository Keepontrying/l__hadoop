package com.jd.jr.boss.credit.authen.core.dao;

import java.util.List;

import com.jd.jr.boss.credit.facade.authen.beans.response.CreditMerchantEntity;
import org.springframework.stereotype.Repository;

import com.jd.jr.boss.credit.authen.core.beans.request.MerchantQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.CreditMerchantEntity;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 征信商户查询数据层
 *
 * @author : yangjinlin@jd.com
 * @version 1.0
 * @desciption :
 * @date ：2017年1月22日 下午4:47:35
 * @return
 */
@Repository
public interface CreditMerchantDao {

    /**
     * 根据商户查询参数类查询征信商户
     *
     * @param merchantQryParam
     * @return
     */
    List<CreditMerchant> queryMerchantByParam(MerchantQueryParam merchantQryParam);

    /**
     * 添加商户信息
     *
     * @param creditMerchant
     * @return
     */
    int insertSelective(CreditMerchant creditMerchant);

    /**
     * 修改商户信息
     *
     * @param creditMerchant
     * @return
     */
    int updateByPrimaryKeySelective(CreditMerchant creditMerchant);

    /**
     * 查询商户信息
     *
     * @param merchantQueryParam
     * @return
     */
    CreditMerchantEntity queryMerchantInfo(MerchantQueryParam merchantQueryParam);

}
