package com.jd.jr.boss.credit.authen.core.dao;

import org.springframework.stereotype.Repository;

/**
 * 类描述：
 *
 * @author liangyuwu
 * @Time 2018/6/7 15:15
 */
@Repository
public interface CreditAuthenProductDao {
    int selectSelective(String productCode);
}
