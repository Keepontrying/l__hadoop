package com.jd.jr.boss.credit.authen.core.jms.autoSewage;

import com.jd.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.dao.CreditAutosewageDao;
import com.jd.jr.boss.credit.authen.core.task.AutoSewageParentService;
import com.jdjr.fmq.client.consumer.MessageListener;
import com.jdjr.fmq.common.message.Message;
import com.wangyin.boss.credit.admin.entity.CreditAutosewageUrl;
import com.wangyin.rediscluster.client.CacheClusterClient;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * 排污处理
 * @author for liuwei
 * @since 2017/7/6
 */
@Component("autoSewageListener")
public class AutoSewageListener implements MessageListener {
	
    private static Logger logger = LoggerFactory.getLogger(AutoSewageListener.class);
    @Resource
    private AutoSewageParentService autoSewageParentService;
    @Resource
    protected CacheClusterClient cacheClusterClient;
    @Resource
    protected CreditAutosewageDao creditAutosewageDao;

    @Override
    public void onMessage(List<Message> messages) throws Exception {

        logger.info("======autoSewageListener handler start======");
        if (messages == null || messages.isEmpty()) {
            logger.info("autoSewageListener message is null");
            return;
        }
        for (Message message : messages) {
            String objectJson = message.getText();
            //String systemId,String file,String batchNo,String merchantNo
            logger.info("autoSewageListener message, body part:{}", objectJson);
            JSONObject returnData = JSONObject.parseObject(objectJson);
            String systemId = returnData.getString("systemId");
            String fileUrl = returnData.getString("fileUrl");
            String batchNo = returnData.getString("batchNo");
            String merchantNo = returnData.getString("merchantNo");
            //查询url是否已经消费过，防止重复消费
            CreditAutosewageUrl param = new CreditAutosewageUrl();
            param.setFileUrl(fileUrl);
            List<CreditAutosewageUrl> urls = creditAutosewageDao.getByParam(param);
            if(CollectionUtils.isEmpty(urls)){//防止重复消费
                //缓存中ip是否在处理  如果没有直接抛出异常
                InetAddress address = InetAddress.getLocalHost();
                String ipAddress = "paiwu_"+address.getHostAddress();
                String ipAddressValue = cacheClusterClient.get(ipAddress);
                if(StringUtils.isNotBlank(ipAddressValue)){//此服务器存在正在执行的任务
                    throw new Exception("目标服务器存在正在执行的任务");
                }else {//执行任务
                    cacheClusterClient.set(ipAddress,"YES");
                    try{
                        //存储url
                        CreditAutosewageUrl creditAutosewageUrl = new CreditAutosewageUrl();
                        creditAutosewageUrl.setFileUrl(fileUrl);
                        creditAutosewageUrl.setBatchNo(batchNo);
                        creditAutosewageUrl.setMerchantNo(merchantNo);
                        creditAutosewageUrl.setSystemId(systemId);
                        creditAutosewageUrl.setCreatedDate(new Date());
                        creditAutosewageUrl.setModifiedDate(new Date());
                        creditAutosewageUrl.setStatus("VALID");//VALID 有效;INVALID无效
                        creditAutosewageDao.insertAutosewageUrl(creditAutosewageUrl);
                    }catch (Exception e){
                        logger.error("排污存储url失败 ,part data {}",e);
                    }
                    autoSewageParentService.doExecute(ipAddress,systemId,fileUrl,batchNo,merchantNo);
                }
            }
        }
        logger.info("======autoSewageListener handler end======");
    }
}
