package com.jd.jr.boss.credit.authen.core.dao;

import org.springframework.stereotype.Repository;

/**
 * created by ChenKaiJu on 2018/9/19  17:03
 */
@Repository
public interface CreditCallBackDao {

    public String queryCallBackUrlForBfmt(String systemId);
}
