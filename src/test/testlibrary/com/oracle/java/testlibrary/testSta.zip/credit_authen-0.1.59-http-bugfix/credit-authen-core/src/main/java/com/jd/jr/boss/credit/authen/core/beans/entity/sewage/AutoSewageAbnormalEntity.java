package com.jd.jr.boss.credit.authen.core.beans.entity.sewage;

import java.io.Serializable;

import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.negative.AbnormalEntity;

/** 
* @desciption : 自动排污：异常经营目录
* @author : yangjinlin@jd.com
* @date ：2017年12月18日 下午6:02:02 
* @version 1.0 
* @return  */
public class AutoSewageAbnormalEntity extends AbnormalEntity implements Serializable {

	private static final long serialVersionUID = -3818822401114830494L;
	
	/**
	 * 公司全称
	 */
	private String enterpriseName;
    /**
     * 内外部标识
     */
    private String entInnerFlag;
    /**
     * 风险等级
     */
    private String riskLevel;

	public String getEnterpriseName() {
		return enterpriseName;
	}

	public void setEnterpriseName(String enterpriseName) {
		this.enterpriseName = enterpriseName;
	}

    public String getEntInnerFlag() {
        return entInnerFlag;
    }

    public void setEntInnerFlag(String entInnerFlag) {
        this.entInnerFlag = entInnerFlag;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }
}
