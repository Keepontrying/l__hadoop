package com.jd.jr.boss.credit.authen.core.scheduler;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;
import com.jd.jr.boss.credit.authen.core.utils.DateUtils;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.admin.frame.utils.SFTPUtil;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.schedule.client.job.ScheduleContext;
import com.wangyin.schedule.client.job.ScheduleFlowTask;
import com.wangyin.schedule.client.job.TaskResult;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 反洗钱 下载文件
 *
 * @author huangzhiqiang
 * @data 2018/9/25
 */
@Service
public class BiDataBeneficiaryFileJob implements ScheduleFlowTask {
    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(BiDataBeneficiaryFileJob.class);

    private final String BIDATA_SFTP_HOST = ConfigUtil.getString("sftp.host.bidata");
    private final String BIDATA_SFTP_PORT = ConfigUtil.getString("sftp.port.bidata");
    private final String BIDATA_SFTP_USERNAME = ConfigUtil.getString("sftp.user.bidata");
    private final String BIDATA_SFTP_PASSWORD = ConfigUtil.getString("sftp.password.bidata");

    private final String JD_SFTP_HOST = ConfigUtil.getString("sftp.host");
    private final String JD_SFTP_PORT = ConfigUtil.getString("sftp.port");
    private final String JD_SFTP_USERNAME = ConfigUtil.getString("sftp.userName");
    private final String JD_SFTP_PRIVATEKEY = ConfigUtil.getString("sftp.privateKey");

    private static final String BIDATA_SFTP_PAHT = "/data/monitor/result/";

    @Override
    public TaskResult doTask(ScheduleContext scheduleContext) throws Exception {
        Map<String, String> userDefineParams = scheduleContext.getParameters();
        String beginDate = userDefineParams.get("beginDate");
        String endDate = userDefineParams.get("endDate");
        String remoteFilePath;
        if (StringUtils.isBlank(beginDate) || StringUtils.isBlank(endDate)) {
            remoteFilePath = BIDATA_SFTP_PAHT + DateUtils.getYestaday();
            copyFile(remoteFilePath);
        } else {
            List<String> fileNameList = new ArrayList<>();
            DateTimeFormatter format = DateTimeFormat.forPattern("yyyyMMdd");
            DateTime temp = DateTime.parse(beginDate, format);
            DateTime endDate2 = DateTime.parse(endDate, format);
            while (temp.isBefore(endDate2)) {
                fileNameList.add(BIDATA_SFTP_PAHT + temp.toString(format));
                temp = temp.plusDays(1);
            }
            for (String aFileNameList : fileNameList) {
                remoteFilePath = aFileNameList;
                copyFile(remoteFilePath);
            }
        }
        return TaskResult.SUCCESS_BLANK;
    }

    private void copyFile(String remoteFilePath) throws SftpException {
        ChannelSftp BidataSftp = SFTPClient(BIDATA_SFTP_HOST, BIDATA_SFTP_PORT, BIDATA_SFTP_USERNAME, BIDATA_SFTP_PASSWORD, null);
        ChannelSftp JDSftp = SFTPClient(JD_SFTP_HOST, JD_SFTP_PORT, JD_SFTP_USERNAME, null, JD_SFTP_PRIVATEKEY);
        boolean isDir = SFTPUtil.isDirExist(BidataSftp, remoteFilePath);
        if (isDir) {
            List<String> fileList = SFTPUtil.listFiles(BidataSftp, remoteFilePath, 1);
            for (String fileName : fileList) {
                InputStream file = BidataSftp.get(fileName);
                String directory = "upload/beneficiary" + remoteFilePath.substring(remoteFilePath.lastIndexOf("/"), remoteFilePath.length());
                if (!SFTPUtil.isDirExist(JDSftp, directory)) {
                    SFTPUtil.createDir(JDSftp, directory);// 1:创建目录成功
                }
                JDSftp.cd(directory);
                JDSftp.put(file, fileName.substring(fileName.lastIndexOf("/") + 1, fileName.length()));
            }
        } else {
            logger.info("目标路径不存在：{}", remoteFilePath);
        }
    }

    private ChannelSftp SFTPClient(String host, String port, String usre, String password, String priKeyPath) {
        logger.info("创建sftp客户端: {}, {}, {}, {}, {}", host, port, usre, password, priKeyPath);
        ChannelSftp sftp = null;
        try {
            int port2 = Integer.parseInt(port);
            priKeyPath = BiDataBeneficiaryFileJob.class.getResource("/").toString().substring(5) + priKeyPath;
            if (StringUtil.isBlank(password)) {
                sftp = SFTPUtil.connect(host, port2, usre, priKeyPath, null);
            } else {
                sftp = SFTPUtil.connect(host, port2, usre, password);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sftp;
    }
}
