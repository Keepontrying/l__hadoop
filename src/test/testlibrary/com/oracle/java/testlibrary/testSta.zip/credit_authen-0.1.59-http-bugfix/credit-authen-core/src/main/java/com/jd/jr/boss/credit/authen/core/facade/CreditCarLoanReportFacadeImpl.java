package com.jd.jr.boss.credit.authen.core.facade;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.service.CreditCarLoanReportService;
import com.jd.jr.boss.credit.authen.core.service.FileService;
import com.jd.jr.boss.credit.authen.core.task.CreditAsyncExcuteCommonService;
import com.jd.jr.boss.credit.facade.authen.api.CreditCarLoanReportFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.CarLoanReportBatchQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.CarLoanReportQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.CarLoanReportTaskAddQueryParam;
import com.jd.jr.boss.credit.facade.authen.enums.CarLoanReportPartResultTypeEnum;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.carLoanReport.AssociatedPersonnel;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.EntCarLoanReportQueryParam;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.PersonnelTypeEnum;
import com.wangyin.boss.credit.admin.entity.CreditReportQueryCarloan;
import com.wangyin.boss.credit.admin.enums.CreditCarLoanCreditDescEnum;
import com.wangyin.boss.credit.admin.enums.CreditSewageQueryTypeEnum;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;
import com.wangyin.rediscluster.client.CacheClusterClient;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Description: 车贷报告接口实现类
 * User: yangjinlin@jd.com
 * Date: 2018/6/12 21:23
 * Version: 1.0
 */
@Service("creditCarLoanReportFacade")
public class CreditCarLoanReportFacadeImpl implements CreditCarLoanReportFacade {

    private static Logger LOGGER = LoggerFactory.getLogger(CreditCarLoanReportFacadeImpl.class);

    @Autowired
    private CreditCarLoanReportService creditCarLoanReportService;

    @Autowired
    private CreditAsyncExcuteCommonService asyncExcuteCommonService;

    @Resource
    protected CacheClusterClient cacheClusterClient;

    @Resource
    private FileService fileService;

    @Override
    public CreditPage<CreditReportQueryCarloan> queryCarLoanReportPage(CreditRequestParam<CarLoanReportQueryParam> requestParam) {
        LOGGER.info("queryCarLoanReportList requestParam, {}", GsonUtil.getInstance().toJson(requestParam));
        CreditPage<CreditReportQueryCarloan> creditResponseData = new CreditPage<CreditReportQueryCarloan>();
        try {
            if (requestParam == null ) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                LOGGER.error("queryCarLoanReportList request failed, reason:  requestParam is null");
                return creditResponseData;
            }
            if (requestParam.getParam() == null ) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                LOGGER.error("queryCarLoanReportList request failed, reason:  requestParam is null");
                return creditResponseData;
            }
            CarLoanReportQueryParam queryParam = requestParam.getParam();
            creditResponseData = creditCarLoanReportService.queryCarLoanReportList(queryParam);

        } catch (Exception e) {
            LOGGER.error("queryCarLoanReportList failed, {}", e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            LOGGER.info("queryCarLoanReportList end,responseData, {} ", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }

    @Override
    public CreditResponseData addCarLoanReportQueryTask(CreditRequestParam<CarLoanReportTaskAddQueryParam> requestParam) {
        LOGGER.info("addCarLoanReportQueryTask requestParam, {}", GsonUtil.getInstance().toJson(requestParam));
        CreditResponseData creditResponseData = new CreditResponseData();
        try {
            if (requestParam == null ) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                LOGGER.error("addCarLoanReportQueryTask request failed, reason:  requestParam is null");
                return creditResponseData;
            }
            if (StringUtils.isBlank(requestParam.getOperator()) || requestParam.getParam() == null ) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                LOGGER.error("addCarLoanReportQueryTask request failed, reason:  requestParam is null");
                return creditResponseData;
            }
            CarLoanReportTaskAddQueryParam queryParam = requestParam.getParam();
            String operator = requestParam.getOperator();
            String systemId = requestParam.getSystemId();
            // 任务落库并返回给上游告知任务提交成功---此时产出表记录id
            CreditReportQueryCarloan addCarLoanReportResponse  = creditCarLoanReportService.addCarLoanReportQueryTask(queryParam, operator);
            if(null != addCarLoanReportResponse && null != addCarLoanReportResponse.getId()){
                creditResponseData.setSuccess(true);
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
                // 任务落地成功则  异步调用trade接口，进行数据加工---全程携带表记录的id
                if(null!= requestParam.getParam() && StringUtils.isNotBlank(requestParam.getParam().getQueryType())
                        && CreditSewageQueryTypeEnum.PRO.toName().equalsIgnoreCase(requestParam.getParam().getQueryType())){//增值版
                    LOGGER.info("queryCarLoanReport-pro start handle");
                    // 发起定制报告 增值版的 查询和处理
                    asyncExcuteCommonService.queryCarLoanReportPro(addCarLoanReportResponse, requestParam);
                }else{
                    LOGGER.info("queryCarLoanReport-base start handle");
                    asyncExcuteCommonService.queryCarLoanReport(addCarLoanReportResponse, queryParam, systemId);
                }
            }else{
                creditResponseData.setSuccess(false);
                creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
                creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            }
        } catch (Exception e) {
            LOGGER.error("addCarLoanReportQueryTask exception, {}", e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            LOGGER.info("addCarLoanReportQueryTask end,responseData, {} ", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }

    @Override
    public CreditResponseData<String> queryCarLoanPartResult(CreditRequestParam<CarLoanReportQueryParam> requestParam) {
        //根据不同入参查询不同部分的结果
        LOGGER.info("queryCarLoanPartResult requestParam, {}", GsonUtil.getInstance().toJson(requestParam));
        CreditResponseData creditResponseData = new CreditResponseData();
        try {
            if (requestParam == null ) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                LOGGER.error("queryCarLoanPartResult request failed, reason:  requestParam is null");
                return creditResponseData;
            }
            if (requestParam.getParam() == null ) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                LOGGER.error("queryCarLoanPartResult request failed, reason:  requestParam is null");
                return creditResponseData;
            }
            CarLoanReportQueryParam queryParam = requestParam.getParam();
            String resultType = CarLoanReportPartResultTypeEnum.enumValueOf(queryParam.getResultPartType()).toName();
            if(StringUtils.isBlank(resultType)){
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                LOGGER.error("queryCarLoanPartResult request failed, reason:  requestParam is null");
                return creditResponseData;
            }
            queryParam.setResultPartType(resultType);
            CreditPage<CreditReportQueryCarloan> creditResponsePage = creditCarLoanReportService.queryCarLoanReportList(queryParam);
            String key = "";
            Object object = null;
            if(null != creditResponsePage && creditResponsePage.isSuccess() && CollectionUtils.isNotEmpty(creditResponsePage.getRows())){
                CreditReportQueryCarloan carLoanReport = creditResponsePage.getRows().get(0);
                if(CarLoanReportPartResultTypeEnum.BASE_REPORT_KEY.toName().equalsIgnoreCase(resultType)){//获取基本报告数据
                    key = carLoanReport.getBaseReportKey();
                    object = getObjectFromCache(key, object);
                    String multiRiskLevel = "";
                    JSONObject initResult = new JSONObject();
                    if(null != object ){
                        initResult = new JSONObject(JSONObject.parseObject(object.toString()));
                    }
                    initResult.put("refuseCounts", carLoanReport.getRefuseCounts());
                    initResult.put("focusCounts", carLoanReport.getFocusCounts());
                    initResult.put("selfCounts", carLoanReport.getSelfCounts());
                    initResult.put("aroundCounts", carLoanReport.getAroundCounts());
                    if(null != carLoanReport && carLoanReport.getRefuseCounts()>0){
                        multiRiskLevel = CreditCarLoanCreditDescEnum.REFUSE_DESC.toDescription();
                    }else{
                        multiRiskLevel =  CreditCarLoanCreditDescEnum.FOCUS_DESC.toDescription();
                    }
                    initResult.put("multiRiskLevel",multiRiskLevel);
                    initResult.put("resultFileUrl", carLoanReport.getResultFileUrl());
                    if(null != carLoanReport && StringUtils.isBlank(carLoanReport.getMultiRiskLevel())){//为空则更新，否则不更新
                        CreditReportQueryCarloan carLoanReport4Update = new CreditReportQueryCarloan();
                        carLoanReport4Update.setId(carLoanReport.getId());
                        carLoanReport4Update.setMultiRiskLevel(multiRiskLevel);
                        Integer updateId = creditCarLoanReportService.updateCarLoanReportInfoById(carLoanReport4Update);
                    }
                    object = initResult;
                    LOGGER.info("queryCarLoanPartResult getBaseReportKeyValue ," +  object.toString());
                }else if(CarLoanReportPartResultTypeEnum.SELF_INFO_KEY.toName().equalsIgnoreCase(resultType)){//自身风险
                    key = carLoanReport.getSelfInfoKey();
                    object = getObjectFromCache(key, object);
                    LOGGER.info("queryCarLoanPartResult SelfInfoKeyValue ," + object.toString());
                }else if(CarLoanReportPartResultTypeEnum.AROUND_INFO_KEY.toName().equalsIgnoreCase(resultType)){//周边风险
                    key = carLoanReport.getAroundInfoKey();
                    object = getObjectFromCache(key, object);
                    LOGGER.info("queryCarLoanPartResult AroundInfoValue ," + object.toString());
                }

            }else{
                creditResponseData.setMessage(ResponseMessage.NOT_EXIST.getDesc());
                creditResponseData.setCode(ResponseMessage.NOT_EXIST.name());
                creditResponseData.setSuccess(false);
            }

            creditResponseData.setData(null == object ? "" : object.toString());
            creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
            creditResponseData.setCode(ResponseMessage.SUCCESS.name());
            creditResponseData.setSuccess(true);
        } catch (Exception e) {
            LOGGER.error("queryCarLoanPartResult exception, {}", e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            LOGGER.info("queryCarLoanPartResult end,responseData, {} ", JSONObject.toJSONString(creditResponseData));
        }
        return creditResponseData;
    }

    @Override
    public CreditResponseData<String> carloanReportPdfSupplyHandle(CreditRequestParam<CarLoanReportQueryParam> requestParam) {
        CreditResponseData<String> creditResponseData = new CreditResponseData<String>();
        try {
            CarLoanReportQueryParam queryParam = requestParam.getParam();
            CreditResponseData<String> serviceResp = creditCarLoanReportService.carloanReportPdfSupplyHandle(queryParam);
        } catch (Exception e) {
            LOGGER.error("queryCarLoanPartResult exception, {}", e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        }
        return creditResponseData;
    }

    @Override
    public CreditResponseData addCarLoanReportBatchQuery(CreditRequestParam<CarLoanReportBatchQueryParam> requestParam) {
        // 同步：批次信息落库，告知门户批次提交成功
        LOGGER.info("addCarLoanReportBatchQuery requestParam, {}", GsonUtil.getInstance().toJson(requestParam));
        CreditResponseData creditResponseData = new CreditResponseData();
        try {
            CarLoanReportBatchQueryParam batchQueryParam = requestParam.getParam();
            if (requestParam == null ) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                LOGGER.info("addCarLoanReportBatchQuery request failed, reason:  requestParam is null");
                return creditResponseData;
            }
            if (StringUtils.isBlank(requestParam.getOperator()) || batchQueryParam == null ) {
                creditResponseData.setMessage(ResponseMessage.PARAM_ILLEGAL.getDesc());
                creditResponseData.setCode(ResponseMessage.PARAM_ILLEGAL.name());
                creditResponseData.setSuccess(false);
                LOGGER.info("addCarLoanReportBatchQuery request failed, reason:  requestParam is null");
                return creditResponseData;
            }
            int batchId = creditCarLoanReportService.addCarLoanReportBatchQuery(requestParam);
            if(0 == batchId){// 数据落地异常
                creditResponseData.setSuccess(false);
                creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
                creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
                return creditResponseData;
            }else{
                creditResponseData.setSuccess(true);
                creditResponseData.setCode(ResponseMessage.SUCCESS.name());
                creditResponseData.setMessage(ResponseMessage.SUCCESS.getDesc());
//                if(null!= batchQueryParam && StringUtils.isNotBlank(batchQueryParam.getQueryType())
//                        && CreditSewageQueryTypeEnum.PRO.toName().equalsIgnoreCase(batchQueryParam.getQueryType())){//增值版
//                    LOGGER.info("queryCarLoanReportBatch-pro start handle");
//                    // 发起定制报告 增值版的 查询和处理
//                    asyncExcuteCommonService.queryCarLoanReportProBatch(requestParam, batchId);
//                }else{
                    LOGGER.info("queryCarLoanReportBatch-base start handle");
                    // 异步：多线程处理，调用单笔车贷查trade逻辑，生成对应数据落地生成hsp文件，最好能在批次的维度上生成压缩包(内含整个批次的企业拒绝关注数、各个企业的车贷excel)
                    asyncExcuteCommonService.queryCarLoanReportBatch(requestParam, batchId);
//                }

            }
        } catch (Exception e) {
            LOGGER.error("addCarLoanReportBatchQuery error, {}", e);
            creditResponseData.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
            creditResponseData.setCode(ResponseMessage.SYSTEM_ERROR.name());
            creditResponseData.setSuccess(false);
        } finally {
            LOGGER.info("addCarLoanReportBatchQuery end,responseData, {} ", JSONObject.toJSONString(creditResponseData));
        }


        return creditResponseData;
    }



    /**
     * 从缓存中获取数据
     * @param key
     * @param object
     * @return
     */
    private Object getObjectFromCache(String key, Object object) {
        if(StringUtils.isNotBlank(key)){
            try {
                LOGGER.error("queryCarLoanPartResult cacheClusterClient key :" + key);
                object = cacheClusterClient.get(key);
            } catch (Exception e) {
                LOGGER.error("queryCarLoanPartResult-cacheClusterClient 获取缓存异常,{}", e);
            }
        }
        return object;
    }
}
