package com.jd.jr.boss.credit.authen.core.constants;

/**
 * 缴费单常量
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */

public class SystemConstants {

    /**
     * 操作员
     */
    public static final String PARAM_INPUT_OPERATOR = "SYSTEM";

    /**
     * BD和运营的邮件地址
     */
    public static final String WARNING_BDSALES_EMAIL = "warning.bdsales.email";

    /**
     * ES全量预警邮箱地址
     */
    public static final String ES_DOCS_WARNING_EMAIL = "es.docs.warning.email";
    /**
     * 黄赌毒 jmq
     */
    public static final String ANTIFRAUD_PROVIDER_JMQ = "jmq.antifraud.provider";
    /**
     * 排污 fmq
     */
    public static final String AUTOSEWAGE_FMQ = "fmq.finance.autosewage.notify";
    /**
     * 标准报告邮件通知模板
     */
    public static final String STANDARD_REPORT_EMAIL = "standard.report.finish.email";
    /**
     * 标准报告微信通知模板
     */
    public static final String STANDARD_REPORT_WX = "standard.report.finish.wx";
    /**
     * 蓝鲸监控 被监控企业 自动关闭
     */
    public static final String VIP_TASK_AUTO_CLOSE_REMARK = "实际数监控数大于有效监控数，自动关闭多余任务";
    /**
     * 蓝鲸监控 被监控企业 人工关闭
     */
    public static final String VIP_TASK_MAN_CLOSE_REMARK = "用户手动取消监控";
    /**
     * 蓝鲸监控 默认分组名称
     */
    public static final String VIP_TASK_MAN_GROUP_INIT = "默认分组";

    /**
     * 商户产品调用失败率过高预警 邮件通知模板
     */
    public static final String MERCHPROD_CALLTIMES_WARNING = "credit.merchprod.calltimes.warning";
    /**
     * UNC 研发的邮件地址
     */
    public static final String UNC_RD_RECEIVER = "unc.rd.receiver";

    /**
     * 商户产品调用失败率过高预警 邮件通知模板
     */
    public static final String EVLUATION_VIP_CHANGE = "credit.evluation.vip.change";

    /**
     * 排污报告 NFS 路径
     */
    public static final String NFS_ENT_AUTOSEWAGE_PATH = "nfs.portal.ent.autosewage.path";
    /**
     * 排污报告 NFS 路径
     */
    public static final String CREDIT_DATE_TO_STR_YMDHMS = "yyyy-MM-dd HH:mm:ss";





}
