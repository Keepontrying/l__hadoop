package com.jd.jr.boss.credit.authen.core.facade;

import java.util.List;

import com.jd.jr.boss.credit.domain.common.entity.CreditMerchantChannelGather;
import com.jd.jr.boss.credit.facade.authen.beans.param.MerchantChannelQueryParam;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.authen.core.service.CreditLogService;
import com.jd.jr.boss.credit.domain.common.entity.CreditCallTimesGather;
import com.jd.jr.boss.credit.facade.authen.api.CreditLogFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.CallTimesGatherQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;

/**
* @desciption : 业务日志流水接口实现类
* @author : yangjinlin@jd.com
* @date ：2018年4月26日 下午4:11:35
* @version 1.0
* @return  */
@Service("creditLogFacade")
public class CreditLogFacadeImpl implements CreditLogFacade {

    private static Logger logger = LoggerFactory.getLogger(CreditLogFacadeImpl.class);

	@Autowired
	private CreditLogService creditLogService;

	@Override
	public CreditResponseData<List<CreditCallTimesGather>> queryTradeLogCallTimesGatherList(
			CallTimesGatherQueryParam queryParam) {
		CreditResponseData<List<CreditCallTimesGather>> responseData = new CreditResponseData<List<CreditCallTimesGather>>();
		List<CreditCallTimesGather> callTimesList = creditLogService.queryCallTimesGatherTradeLogList(queryParam);
		responseData.setData(callTimesList);
		return responseData;
	}

	@Override
	public int queryTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam) {
		return creditLogService.queryCallTimesGatherTradeLogListCount(queryParam);
	}

	@Override
	public int queryMerchTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam) {
	    logger.info("queryMerchTradeLogCallTimesGatherListCount queryParam: {}", queryParam);
		return creditLogService.queryMerchTradeLogCallTimesGatherListCount(queryParam);
	}

	@Override
	public CreditResponseData<List<CreditCallTimesGather>> queryMerchTradeLogCallTimesGatherList(
			CallTimesGatherQueryParam queryParam) {
		CreditResponseData<List<CreditCallTimesGather>> responseData = new CreditResponseData<List<CreditCallTimesGather>>();
		List<CreditCallTimesGather> callTimesList = creditLogService.queryMerchTradeLogCallTimesGatherList(queryParam);
		responseData.setData(callTimesList);
		return responseData;
	}

	@Override
	public int queryMerchProdTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam) {
		return creditLogService.queryMerchProdTradeLogCallTimesGatherListCount(queryParam);
	}

	@Override
	public CreditResponseData<List<CreditCallTimesGather>> queryMerchProdTradeLogCallTimesGatherList(
			CallTimesGatherQueryParam queryParam) {
		CreditResponseData<List<CreditCallTimesGather>> responseData = new CreditResponseData<List<CreditCallTimesGather>>();
		List<CreditCallTimesGather> callTimesList = creditLogService.queryMerchProdTradeLogCallTimesGatherList(queryParam);
		responseData.setData(callTimesList);
		return responseData;
	}

	@Override
	public int queryMerchProdStepTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam) {
		return creditLogService.queryMerchProdStepTradeLogCallTimesGatherListCount(queryParam);
	}

	@Override
	public CreditResponseData<List<CreditCallTimesGather>> queryMerchProdStepTradeLogCallTimesGatherList(
			CallTimesGatherQueryParam queryParam) {
		CreditResponseData<List<CreditCallTimesGather>> responseData = new CreditResponseData<List<CreditCallTimesGather>>();
		List<CreditCallTimesGather> callTimesList = creditLogService.queryMerchProdStepTradeLogCallTimesGatherList(queryParam);
		responseData.setData(callTimesList);
		return responseData;
	}

	@Override
	public int queryMerchProdResoTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam) {
		return creditLogService.queryMerchProdResoTradeLogCallTimesGatherListCount(queryParam);
	}

	@Override
	public CreditResponseData<List<CreditCallTimesGather>> queryMerchProdResoTradeLogCallTimesGatherList(
			CallTimesGatherQueryParam queryParam) {
		CreditResponseData<List<CreditCallTimesGather>> responseData = new CreditResponseData<List<CreditCallTimesGather>>();
		List<CreditCallTimesGather> callTimesList = creditLogService.queryMerchProdResoTradeLogCallTimesGatherList(queryParam);
		responseData.setData(callTimesList);
		return responseData;
	}

	@Override
	public CreditResponseData<List<CreditCallTimesGather>> queryResoTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam) {
		CreditResponseData<List<CreditCallTimesGather>> responseData = new CreditResponseData<List<CreditCallTimesGather>>();
		List<CreditCallTimesGather> callTimesList = creditLogService.queryResoTradeLogCallTimesGatherList(queryParam);
		responseData.setData(callTimesList);
		return responseData;
	}

	@Override
	public int queryMerchantChannelGatherListCount(MerchantChannelQueryParam queryParam) {
		return creditLogService.queryMerchantChannelGatherListCount(queryParam);
	}

	@Override
	public CreditResponseData<List<CreditMerchantChannelGather>> queryMerchantChannelGatherList(MerchantChannelQueryParam queryParam) {
		CreditResponseData<List<CreditMerchantChannelGather>> responseData = new CreditResponseData<List<CreditMerchantChannelGather>>();
		List<CreditMerchantChannelGather> merchantChannelList = creditLogService.queryMerchantChannelInfoList(queryParam);
		responseData.setData(merchantChannelList);
		return responseData;
	}

	@Override
	public int selectCountMerchantChannelGatherByParam(MerchantChannelQueryParam queryParam) {
		return creditLogService.selectCountMerchantChannelGatherByParam(queryParam);
	}

    @Override
    public int queryProdTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam) {
        return creditLogService.queryProdTradeLogCallTimesGatherListCount(queryParam);
    }

    @Override
    public CreditResponseData<List<CreditCallTimesGather>> queryProdTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam) {
        CreditResponseData<List<CreditCallTimesGather>> responseData = new CreditResponseData<List<CreditCallTimesGather>>();
        List<CreditCallTimesGather> callTimesList = creditLogService.queryProdTradeLogCallTimesGatherList(queryParam);
        responseData.setData(callTimesList);
        return responseData;
    }


}
