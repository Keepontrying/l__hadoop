package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 中证码详情
 *
 * @author huangzhiqiang
 * @data 2017/8/31
 */
public class SignCodeInfo implements Serializable {
    private static final long serialVersionUID = -7841660810398004576L;
    private Integer id;
    private String entNameCN;
    private String entNameEN;
    private String creditCode;
    private String orgNo;
    private Long signNo;
    private String regType;
    private String regNo;
    private String taxNoNational;
    private String taxNoLand;
    private Integer batchId;
    private String creator;
    private Date createdDate;
    private String modifier;
    private Date modifiedDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEntNameCN() {
        return entNameCN;
    }

    public void setEntNameCN(String entNameCN) {
        this.entNameCN = entNameCN;
    }

    public String getEntNameEN() {
        return entNameEN;
    }

    public void setEntNameEN(String entNameEN) {
        this.entNameEN = entNameEN;
    }

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode;
    }

    public String getOrgNo() {
        return orgNo;
    }

    public void setOrgNo(String orgNo) {
        this.orgNo = orgNo;
    }

    public Long getSignNo() {
        return signNo;
    }

    public void setSignNo(Long signNo) {
        this.signNo = signNo;
    }

    public String getRegType() {
        return regType;
    }

    public void setRegType(String regType) {
        this.regType = regType;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getTaxNoNational() {
        return taxNoNational;
    }

    public void setTaxNoNational(String taxNoNational) {
        this.taxNoNational = taxNoNational;
    }

    public String getTaxNoLand() {
        return taxNoLand;
    }

    public void setTaxNoLand(String taxNoLand) {
        this.taxNoLand = taxNoLand;
    }

    public Integer getBatchId() {
        return batchId;
    }

    public void setBatchId(Integer batchId) {
        this.batchId = batchId;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }
}
