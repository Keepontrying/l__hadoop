package com.jd.jr.boss.credit.core.test.mini;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jcraft.jsch.ChannelSftp;
import com.jd.jr.boss.credit.authen.core.utils.HttpsUtil;
import com.jd.jr.boss.credit.authen.core.utils.SFTPClient;
import com.jd.jr.boss.credit.facade.authen.api.CreditDiligenceFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.DueStatusParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.PayMerchantCheckDuplicateParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.PayMerchantCheckResponse;
import com.jd.jr.boss.credit.facade.channel.enterprise.beans.response.due.PayMerchantExpandMaterialBean;
import com.jd.jr.boss.credit.facade.channel.enterprise.beans.response.due.PayMerchantExpandPayBean;
import com.jd.jr.boss.credit.facade.common.constants.SFTPConstants;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.admin.frame.utils.SFTPUtil;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import javax.annotation.Resource;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** 
* @desciption : Mini尽调测试类
* @author : yangjinlin@jd.com
* @date ：2017年10月16日 下午9:56:59 
* @version 1.0 
* @return  */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})

public class MiniDueTest {

    @Resource
    private CreditDiligenceFacade creditDiligenceFacade;


	@Test
	public void payFileUploadToPay(){
		try {
			String url = "https://market-front.jdpay.com/merchant/service/att/upload";//http://172.25.49.215:8080/merchant/check/checkDuplicate
//			String url = "https://market-front-inner.jdpay.local/merchant/service/att/upload";//本地和测试环境调内网域名是调不通的
//			String url = "http://172.25.49.215:8080/merchant/check/checkDuplicate";
			Map<String,String> paramMap = new HashMap<String, String>();
			paramMap.put("serviceRecordNo", "PS201805301138520000CAE7AB98B1");
			paramMap.put("recordType", "MATERIAL_RECORD");
			paramMap.put("picType", "STORE_CASHIER_DES");
//			Gson gson = new GsonBuilder().disableHtmlEscaping().create();
//			String httpArg = gson.toJson(paramMap);
//			File file = null;
//			try {
//				String localFilePath = "E:/6470051.jpg";
//				file = new File(localFilePath);
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//			String resultStr = HttpsUtil.uploadFilePost( url, file,"file", paramMap);
//			System.out.println("----resultStr:" + resultStr );

//            String sftpFilepath = "/upload/mini/shuzhe/1805213597500002/019774f16063adb19b23d4c82da1afaf.jpg";
//            String sftpFileName= "019774f16063adb19b23d4c82da1afaf.jpg";
			String sftpFilepath = "/upload/mini/shuzhe/1805255982800002/4ea6b8cd175d506b9199999b5e378f9e.png";
			String sftpFileName= "4ea6b8cd175d506b9199999b5e378f9e.png";
			ChannelSftp sftp  = null;
			InputStream inputStream = null;
			//获取自己数组
			byte[] getData = null;
			try {
				String host = "172.25.61.4";
				String username = "shuzhe";
				String priKeyPath = "E://id_rsa_credit_mini_sz";
				Integer port = Integer.parseInt("20000");
				System.out.println("【秘钥路径】：" + priKeyPath);
				try {
					sftp = SFTPUtil.connect(host, port, username, priKeyPath, null);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(sftp.isConnected()){
					System.out.println("【sftp 成功】");
				}else{
					System.out.println("【sftp 失败】");
					return;
				}
				if(sftp.isConnected()){
					System.out.println("【sftp 成功】");
				}else{
					System.out.println("【sftp 失败】");
				}
				inputStream = SFTPUtil.getInputStreamFile(sftp, sftpFilepath);
				getData = SFTPUtil.inputStreamToByte(inputStream);
			} catch (Exception e) {
				System.out.println("SFTPUtil.connect failed , {}");
				e.printStackTrace();
			}finally {
				inputStream.close();
			}
			File tempFile = null;
			try {
				int splitIndex = sftpFileName.lastIndexOf(".");
				String prefix = sftpFileName.substring(0,splitIndex);
				String suffix = sftpFileName.substring(splitIndex);
				if(prefix.length()<3){
					prefix = prefix+"00";
				}
				try {
					tempFile = File.createTempFile("100",".jpg");
					FileUtils.writeByteArrayToFile(tempFile, getData);
				} catch (IOException e) {
					System.out.println("----cant find file. " );
					e.printStackTrace();
				}
				String resultStr = HttpsUtil.uploadFilePost( url, tempFile,"file", paramMap, suffix);
				System.out.println("----resultStr:" + resultStr );
			} catch (Exception e) {
				e.printStackTrace();
			}


		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void payExpand(){
		try {
			String url = "https://market-front.jdpay.com/merchant/service/expand";
			Map<String,Object> paramMap = new HashMap<String, Object>();
			paramMap.put("serviceRecordNo", "PS201805250102030000JLTEST0001");
			paramMap.put("serviceBatch", "2018052300");
			paramMap.put("dealerNo", "ZXTEST001");// 支付给的线上服务商编号ZXTEST001
			paramMap.put("employePinId", "yjltest");
			paramMap.put("storeName", "测试商店小区店");
			paramMap.put("merchantName", "我是测试商店名称");
			paramMap.put("merchantType", "2233");
			paramMap.put("provinceCode", "110000");
			paramMap.put("cityCode", "110100");
			paramMap.put("countyCode", "110105");
			paramMap.put("street", "科创十一街");
			paramMap.put("storeAddress", "255 号");
			paramMap.put("storeLat", "39.9152478");
			paramMap.put("storeLng", "116.4038206");
			paramMap.put("contact", "张腾");
			paramMap.put("trained", "true");
			paramMap.put("contactPhone", "18514788222");
			paramMap.put("supportPayMode", "QRCODE");
			List<String> supportPayAll = new ArrayList<String>();
			supportPayAll.add("WECHAT");
			supportPayAll.add("ALIPAY");
			supportPayAll.add("MEITUAN");
			paramMap.put("supportPayAll", supportPayAll);
			List<PayMerchantExpandMaterialBean> materialList = new ArrayList<PayMerchantExpandMaterialBean>();
			PayMerchantExpandMaterialBean material1 = new PayMerchantExpandMaterialBean();
			material1.setMaterialQuantity(5);
			material1.setMaterialType("LED");
			PayMerchantExpandMaterialBean material2 = new PayMerchantExpandMaterialBean();
			material2.setMaterialQuantity(10);
			material2.setMaterialType("L_CARD");
			materialList.add(material1);
			materialList.add(material2);
			paramMap.put("materialList", materialList);

			List<PayMerchantExpandPayBean> payLists = new ArrayList<PayMerchantExpandPayBean>();
			PayMerchantExpandPayBean pay1 = new PayMerchantExpandPayBean();
			pay1.setOrderNo("1059152724270679947148");
			pay1.setRecordType("ADD");
			pay1.setStatus("NORMAL");
			pay1.setTerminalNo("123456");
			pay1.setTerminalType("POS");
			pay1.setuMerchantNo("834161055410255");
			pay1.setPayMode("QRCODE");
			payLists.add(pay1);
			paramMap.put("payList", payLists);

			Gson gson = new GsonBuilder().disableHtmlEscaping().create();
			String httpArg = gson.toJson(paramMap);
			String resultStr = HttpsUtil.doPost(url, httpArg);
			System.out.println("-payExpand---resultStr:" + resultStr );
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

    @Test
    public void doSimple(){
    	CreditRequestParam<List<DueStatusParam>> requestParam = new CreditRequestParam<List<DueStatusParam>>();
    	List<DueStatusParam> dueStatusParamList = new ArrayList<DueStatusParam>();
    	DueStatusParam DueStatus = new DueStatusParam();
    	DueStatus.setSampleId("LJB97CDA21D4209AEA5A");// mock 线上数据  LJB97CDA21D4209AEA5A
    	DueStatus.setStatus("FINISH");
    	dueStatusParamList.add(DueStatus);
    	requestParam.setParam(dueStatusParamList);
    	creditDiligenceFacade.doSimple(requestParam);
    }
    
//    @Test
    public void doProject(){
    	CreditRequestParam<DueStatusParam> requestParam = new CreditRequestParam<DueStatusParam>();
    	DueStatusParam dueStatus = new DueStatusParam();
    	dueStatus.setProjectId("MNPROJ201710110714121248815");
    	dueStatus.setCheckState("2");
    	dueStatus.setRemark("抬头讲故事");
    	requestParam.setParam(dueStatus);
    	creditDiligenceFacade.doProject(requestParam);
    }

    @Test
    public void doPayMerchantFuzzySearch(){
        CreditRequestParam<PayMerchantCheckDuplicateParam> requestParam = new CreditRequestParam<PayMerchantCheckDuplicateParam>();
        PayMerchantCheckDuplicateParam fuzzyPrm = new PayMerchantCheckDuplicateParam();
        fuzzyPrm.setStoreName("必胜客");
        fuzzyPrm.setCountyCode("110112");
        requestParam.setParam(fuzzyPrm);
        CreditResponseData<PayMerchantCheckResponse> reponse = creditDiligenceFacade.doPayMerchantFuzzySearch(requestParam);
        System.out.println("doPayMerchantFuzzySearch reponse: " + GsonUtil.getInstance().toJson(reponse));
    }

}
