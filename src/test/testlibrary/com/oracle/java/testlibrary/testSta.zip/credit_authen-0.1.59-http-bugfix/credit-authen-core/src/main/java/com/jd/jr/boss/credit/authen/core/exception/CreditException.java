package com.jd.jr.boss.credit.authen.core.exception;

/**
 * @author: liuhuawei
 * @since: 14-6-3 下午3:15
 * @version: 1.0.0
 */
public class CreditException extends BaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1066922463769034687L;
}
