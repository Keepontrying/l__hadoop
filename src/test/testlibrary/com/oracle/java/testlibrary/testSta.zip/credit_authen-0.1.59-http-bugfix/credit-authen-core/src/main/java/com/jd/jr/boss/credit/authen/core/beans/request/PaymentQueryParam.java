package com.jd.jr.boss.credit.authen.core.beans.request;

import com.jd.jr.boss.credit.domain.common.enums.PaymentStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.ProductChargeTypeEnum;

import java.io.Serializable;
import java.util.List;

/**
 * Created by anmeng on 2016/12/20.
 */
public class PaymentQueryParam implements Serializable{

    private static final long serialVersionUID = 3504061811828285781L;
    private String beginTime;//开始时间

    private String endTime;//结束时间

    private String merchantNo;//商户号

    private PaymentStatusEnum payStatus;//支付状态

    private ProductChargeTypeEnum strategyChargeType;//计费类型

    private List<String> orderIdList;//订购列表

    public String getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public PaymentStatusEnum getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(PaymentStatusEnum payStatus) {
        this.payStatus = payStatus;
    }

    public ProductChargeTypeEnum getStrategyChargeType() {
        return strategyChargeType;
    }

    public void setStrategyChargeType(ProductChargeTypeEnum strategyChargeType) {
        this.strategyChargeType = strategyChargeType;
    }

    public List<String> getOrderIdList() {
        return orderIdList;
    }

    public void setOrderIdList(List<String> orderIdList) {
        this.orderIdList = orderIdList;
    }
}
