package com.jd.jr.boss.credit.authen.core.dao;

import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CreditProductStrategyDao {

    /**
     * 根据查询条件查询计费策略数据 分页
     * @param creditProductStrategy 服务产品计费策略实体
     * @return
     */
	List<CreditProductStrategy> selectOneByParam(CreditProductStrategy creditProductStrategy);

}