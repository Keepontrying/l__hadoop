package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.Date;

public class CreditBfChangeRecord implements Serializable {
    private static final long serialVersionUID = 5187752565957605241L;
    private Integer id;

    private Integer entpriseId;

    private Date modifiedDate;

    private String isPushed;

    private Date pushDate;

    private Date createdDate;

    private String isChanged;

    private Date changeDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getEntpriseId() {
        return entpriseId;
    }

    public void setEntpriseId(Integer entpriseId) {
        this.entpriseId = entpriseId;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getIsPushed() {
        return isPushed;
    }

    public void setIsPushed(String isPushed) {
        this.isPushed = isPushed == null ? null : isPushed.trim();
    }

    public Date getPushDate() {
        return pushDate;
    }

    public void setPushDate(Date pushDate) {
        this.pushDate = pushDate;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getIsChanged() {
        return isChanged;
    }

    public void setIsChanged(String isChanged) {
        this.isChanged = isChanged == null ? null : isChanged.trim();
    }

    public Date getChangeDate() {
        return changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }
}