package com.jd.jr.boss.credit.core.test.jdbiz;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.jd.fastjson.JSONObject;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.entity.merchant.MerchantUsers;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.request.merchant.GatewayPortalUserRequest;
import com.jd.jr.boss.credit.credit.gateway.merchantca.constance.GatewayPortalConstance;
import com.jd.jr.boss.credit.credit.gateway.merchantca.exception.MerchantException;
import com.jd.jr.boss.credit.credit.gateway.merchantca.facade.merchant.GatewayMerchantFacade;
import com.jd.jr.merchant.customer.ServiceControllerFacade;
import com.jd.jr.merchant.customer.common.RequestMessage;
import com.jd.jr.merchant.customer.common.ResponseMessage;
import com.wangyin.admin.frame.utils.BASE64;
import com.wangyin.admin.frame.utils.DES;
import com.wangyin.admin.frame.utils.MD5;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : 企业站相关接口测试类
* @author : yangjinlin@jd.com
* @date ：2017年8月16日 下午6:41:03 
* @version 1.0 
* @return  */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springtest/jsf-consumer.xml"})
//@ContextConfiguration(locations = { "classpath*:spring-authen.xml" })

public class CustomerTest {

	private static Logger logger = LoggerFactory.getLogger(CustomerTest.class);
	
	@Autowired
	private ServiceControllerFacade serviceControllerFacade;
	
//	@Autowired
//	private GatewayMerchantFacade gatewayMerchantFacade;
	
	@Test
	public void queryMerchantAllUsers() throws MerchantException{
		String id = new SimpleDateFormat("yyyymmddhhMMss").format(new Date());
		Map<String, String> data = new HashMap<String, String>();
		data.put("owner", "110014408");
//		data.put("loginame", "1013260030@qq.com");
		data.put("sysid", GatewayPortalConstance.PORTAL_INTERF_SYSID);
		logger.info("请求商户列表查询未加密前的参数data:"+GsonUtil.getInstance().toJson(data));
		Map<String, Object> dataWraper = new HashMap<String, Object>();
		dataWraper.put("serviceParam", data);
		
		String keyStr = id + "MARRY123QAZ" + "0001";
		GsonBuilder gsonBuilder = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss");
		String dataJson;
		try {
			dataJson = DES.encrypt(gsonBuilder.create().toJson(dataWraper), BASE64.encode(keyStr.getBytes()), "UTF-8");
		} catch (Exception e) {
			throw new MerchantException("调用加密方法失败！",e);
		}
		
		RequestMessage requestMessage = new RequestMessage();
		requestMessage.setReqid(id);
		requestMessage.setData(dataJson);
		requestMessage.setSystem("0001");
		requestMessage.setType("I0020008");
		try {
			requestMessage.setSign(MD5.md5(dataJson,keyStr));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ResponseMessage responseMessage = serviceControllerFacade.doRequest(requestMessage);
		logger.info("===========responseMessage.getData()=============="+responseMessage.getData());
		JSONObject jsStr = JSONObject.parseObject(responseMessage.getData()); 
		Page<MerchantUsers> resData1 = GsonUtil.getInstance().fromJson(jsStr.toString(), new TypeToken<Page<MerchantUsers>>() {}.getType());
		logger.info("===========gsonBuilder2=============="+gsonBuilder.create().toJson(resData1));
		
	}
	
//    @Test
//    public void queryUsersInfoByPrm() throws Exception{
//    	RequestParam<GatewayPortalUserRequest> requestParam = new RequestParam<GatewayPortalUserRequest>();
//    	GatewayPortalUserRequest userRequest = new GatewayPortalUserRequest();
//    	userRequest.setMerchantNo("110027214");
//    	requestParam.setParam(userRequest);
//    	Page<MerchantUsers> page = gatewayMerchantFacade.queryUsersInfoByPrm(requestParam);
//    	logger.info("===========page:"+ GsonUtil.getInstance().toJson(page));
//    }
	
	
}
