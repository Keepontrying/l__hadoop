package com.jd.jr.boss.credit.authen.core.facade.portal;

import com.jd.fastjson.JSONArray;
import com.jd.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.beans.request.ProductStrategyQueryParam;
import com.jd.jr.boss.credit.authen.core.beans.request.VipTaskQueryParam;
import com.jd.jr.boss.credit.authen.core.service.*;
import com.jd.jr.boss.credit.domain.common.enums.CreditYesOrNoEnum;
import com.jd.jr.boss.credit.facade.authen.api.CreditVipStatisticFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.*;
import com.jd.jr.boss.credit.facade.authen.beans.response.*;
import com.jd.jr.boss.credit.facade.authen.beans.response.vipMonitor.AlarmLevelRatioResp;
import com.jd.jr.boss.credit.facade.authen.beans.response.vipMonitor.UpdateRatioResp;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.common.enums.ResponseCodeEnum;
import com.jd.jr.boss.credit.facade.common.exception.CreditApiException;
import com.jd.jr.boss.credit.facade.common.utils.SerialNoUtil;
import com.jd.jr.boss.credit.facade.enterprise.trade.api.EntBfMonitorListFacade;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.ResultData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.expand.*;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.request.EntBfMonitorParam;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.NegativeInfoQueryData;
import com.jd.jr.boss.credit.facade.enterprise.trade.beans.response.antiMoneyLaunder.chinaData.ChinaDataAntiMoneyLaunderResp;
import com.jd.jr.boss.credit.facade.enterprise.trade.enums.response.ResultDataEnum;
import com.wangyin.boss.credit.admin.entity.*;
import com.wangyin.boss.credit.admin.enums.*;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * @desciption : vip监控
 * @author : liuwei55@jd.com
 * @date ：2017年4月5日 下午3:06:12
 * @version 1.0
 * @return  */
@Service("creditVipStatisticFacade")
public class CreditVipStatisticFacadeImpl implements CreditVipStatisticFacade {

	private static Logger logger = LoggerFactory.getLogger(CreditVipStatisticFacadeImpl.class);
	public static final String RESULT_BALANCE_LACK_MESSAGE  = "当前无可用余量，可拨打屏幕下方的服务热线进行购买";
	@Autowired
	private BillService billService;
	@Autowired
	private VipService vipService;
	@Autowired
	private VipTaskExecuteService vipTaskExecuteService;
	@Autowired
	private VipAlarmService vipAlarmService;
	@Autowired
	EntRelationQueryService entRelationQueryService;
    @Autowired
    CreditVipTaskRelationService creditVipTaskRelationService;
    @Autowired
    CreditVipGroupUserService creditVipGroupUserService;
    @Autowired
    CreditVipGroupService creditVipGroupService;
    @Resource
    EntBfMonitorListFacade entBfMonitorListFacade;

	@Override
	public CreditResponseData<List<VipStatisticBean>> queryVipStatistic(CreditRequestParam<VipStatisticQueryParam> reqParam) {
		CreditResponseData<List<VipStatisticBean>> respData = new CreditResponseData<List<VipStatisticBean>>();
		List<VipStatisticBean> vipStatisticBeans = new ArrayList<VipStatisticBean>();
		String merchantNo =  reqParam.getParam().getMerchantNo();
		ProductStrategyQueryParam strategyQueryParam = new ProductStrategyQueryParam();
		strategyQueryParam.setMerchantNo(merchantNo);
		strategyQueryParam.setVipMonitorFlag(VipMonitorFlagEnum.YES.toName());
		List<Integer> productIds = new ArrayList<Integer>();
		HashMap<Integer,VipStatisticBean> map = new HashMap<Integer, VipStatisticBean>();
		try {
			List<CreditProductSecond> products = vipService.queryVipProducts(reqParam.getParam().getMerchantId());
			if(CollectionUtils.isNotEmpty(products)){
				for (CreditProductSecond product:products){
					productIds.add(product.getProductId());
					VipStatisticBean vipStatisticBean = new VipStatisticBean();
//					vipStatisticBean.setProductName(product.getProductName());////? 暂时先把name去掉，看看又没啥影响 --- 波哥mark
					vipStatisticBean.setProductId(product.getProductId());
					vipStatisticBean.setCount(0);
					map.put(product.getProductId(),vipStatisticBean);
				}
			}
			VipStatisticQueryParam param =reqParam.getParam();
			param.setProductIds(productIds);
			try {
				List<CreditBill> billList = billService.queryStatisticCount(param);
				if(CollectionUtils.isNotEmpty(billList)){
					for(CreditBill bill:billList){
						VipStatisticBean vipStatisticBean =map.get(bill.getProductId());
						vipStatisticBean.setCount(bill.getPacketCount());
					}
				}
			} catch (Exception e) {
				logger.error("查询vip统计结果失败：",e);
				respData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
			}
		}catch (Exception e){
			logger.error("查询产品报错：",e);
		}
		vipStatisticBeans=new ArrayList<VipStatisticBean>(map.values());
		respData.setData(vipStatisticBeans);
		return respData;
	}

	@Override
	public CreditResponseData<CreditMonitorEntRemain> queryMonitorEnt(CreditRequestParam<VipQueryParam> reqParam) {
		CreditResponseData<CreditMonitorEntRemain> responseData = new CreditResponseData<CreditMonitorEntRemain>();
		CreditMonitorEntRemain entRemain =null;
		VipQueryParam param = reqParam.getParam();
		try {
			entRemain =vipService.queryMonitorEnt(param);

		}catch (Exception e){
			logger.error("查询企业监控异常：",e);
		}
		responseData.setData(entRemain);
		return responseData;
	}

	@Override
	public CreditPage<CreditVipTask> queryVipTaskList(VipTaskDtoQueryParam queryParam) {
		return vipService.queryVipTaskList(queryParam);
	}

	@Override
	public CreditPage<CreditVipAlarmResult> queryVipChangeInfo(VipChangeQueryParam queryParam) {
		return vipAlarmService.queryVipChangeInfo(queryParam);
	}

	@Override
	public List<CreditProductSecond> queryVipProducts(int merchantId){
        List<CreditProductSecond> products = vipService.queryVipProducts(merchantId);
        return products;
	}

	@Override
	public Integer updateMonitorStatus(VipTaskDtoQueryParam queryParam) {
		Integer res = vipService.updateMonitorStatus(queryParam);
        try {
            VipTaskDtoQueryParam queryParam4Qry = new VipTaskDtoQueryParam();
            queryParam4Qry.setLimit(1);
            queryParam4Qry.setTaskIds(queryParam.getTaskIds());
            CreditPage<CreditVipTask> resultPage =vipService.queryVipTaskList(queryParam);
            if(null!= resultPage && resultPage.isSuccess() && CollectionUtils.isNotEmpty(resultPage.getRows())){
                CreditVipTask task = resultPage.getRows().get(0);
                if(StringUtil.isNotBlank(queryParam.getTaskStatus()) && CreditOpenStatusEnum.CLOSE.toName().equalsIgnoreCase(queryParam.getTaskStatus())
                        && StringUtils.isNotBlank(task.getQueryType()) && CreditSewageQueryTypeEnum.PRO.toName().equalsIgnoreCase(task.getQueryType())){// 增值版取消监控时同步调用
                    CreditRequestParam<EntBfMonitorParam> requestParam4BfCancel = new CreditRequestParam<>();
                    requestParam4BfCancel.setTradeNo(SerialNoUtil.createSerialNo("VIPBF"));
                    requestParam4BfCancel.setOperator(queryParam.getModifier());
                    requestParam4BfCancel.setSystemId(task.getUserPin());//userId字段
                    requestParam4BfCancel.setArg(AccessCallModeEnum.VIPFLAG.toName());
                    EntBfMonitorParam bfPrm = new EntBfMonitorParam();
                    bfPrm.setType("2");// //【必填】操作类型，1 添加或修改， 2 删除
                    bfPrm.setCompanyName(task.getEntName());
                    requestParam4BfCancel.setParam(bfPrm);
                    CreditResponseData<ResultData<EntBfMonitorParam, String>> response4BfCancel = entBfMonitorListFacade.bfMonitorOpt(requestParam4BfCancel);
                    if(null != response4BfCancel && response4BfCancel.isSuccess()){//删除成功
                        logger.info("updateMonitorStatus entBfMonitorListFacade.bfMonitorOpt cancel success, responseData:{}", GsonUtil.getInstance().toJson(response4BfCancel));
                    }else{
                        logger.info("updateMonitorStatus entBfMonitorListFacade.bfMonitorOpt cancel failed, responseData:{}", GsonUtil.getInstance().toJson(response4BfCancel));
                    }
                }
            }
        } catch (Exception e) {
            logger.error("updateMonitorStatus entBfMonitorListFacade.bfMonitorOpt cancel error, ", e);
        }

        return res;
	}

	@Override
	public List<CreditVipTaskProduct> queryVipTaskProducts(VipTaskProductsQueryParam vipProductQryPrm) {
		return vipService.queryVipTaskProducts(vipProductQryPrm);
	}

	/**
	 * 配置vip监控企业
	 *
	 * @param vipTaskParam
	 * @return
	 */
	@Override
	public CreditResponseData addVipCompany(CreditRequestParam<CreditVipTask> vipTaskParam) {
		CreditResponseData responseData=new CreditResponseData();
		CreditVipTask vipTask=vipTaskParam.getParam();
		String operator=vipTaskParam.getOperator();
		vipTask.setCreator(operator);
		try {
			int count=vipService.addVipTask(vipTask);
			if(count==0){
				responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
				responseData.setMessage("添加失败！");
			}else{
				responseData.setResponseMessage(ResponseMessage.SUCCESS);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
			responseData.setMessage(e.getMessage());
		}
		return responseData;
	}

	@Override
	public CreditResponseData<CreditVipTaskResultEnum> modifyBlackLists(
			CreditRequestParam<VipTaskMergeParam> requestParam) {
		CreditResponseData<CreditVipTaskResultEnum> responseData = new CreditResponseData<CreditVipTaskResultEnum>();

		VipTaskQueryParam vipTaskPrm = new VipTaskQueryParam();
		vipTaskPrm.setTaskId(Integer.valueOf(requestParam.getParam().getTaskId()));
		VipTaskProductsQueryParam vipProdPrm = new VipTaskProductsQueryParam();
		vipProdPrm.setTaskId(Integer.valueOf(requestParam.getParam().getTaskId()));
		vipProdPrm.setProductCode(EnterpriseProductEnum4Common.ENTERPRISE_BLACKLIST_QUERY.toName());

		CreditVipTaskResultEnum modifyResponse = null;
		try {
			List<CreditVipTask> vipTaskList = vipService.queryVipTask(vipTaskPrm);
			logger.info("modifyBlackLists vipService.queryVipTask() response: {}", GsonUtil.getInstance().toJson(vipTaskList));
			List<CreditVipTaskProduct> vipTaskProductList = vipService.queryVipTaskProductByParams(vipProdPrm);
			logger.info("modifyBlackLists vipService.queryVipTaskProductByParams response: {}", GsonUtil.getInstance().toJson(vipTaskList));
			modifyResponse = vipTaskExecuteService.tradeExecute(vipTaskList.get(0), vipTaskProductList.get(0), requestParam.getParam().getCreditUser(), new Date(), CreditVipTaskExecutionModeEnum.VIP_EXECUTION_MODE_MANUAL);

			//针对手动刷新黑名单，特殊处理，如果有变化，查监控预警表
			if(modifyResponse.equals(CreditVipTaskResultEnum.TASK_UPDATE_UPDATE)){
				CreditVipAlarmDetailResult alarmDetailResult=new CreditVipAlarmDetailResult();
				alarmDetailResult.setTriggerEvent(VipAlarmEventEnum.blackUpdate.getCode());
				alarmDetailResult.setAlarmLevel("");
				alarmDetailResult.setCreatedDate(new Date());
				alarmDetailResult.setModifiedDate(new Date());
				alarmDetailResult.setTriggerEventType(VipAlarmEventEnum.blackUpdate.getEventType());
				alarmDetailResult.setTriggerTime(new Date());
				alarmDetailResult.setTaskId(vipTaskList.get(0).getTaskId());
				vipAlarmService.createAlarmDetailResult(alarmDetailResult);
			}

		} catch (Exception e) {
			logger.error("modifyBlackLists exception ", e.getMessage());
			responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
			responseData.setMessage(e.getMessage());
		}
		responseData.setData(modifyResponse);
		return responseData;
	}

	@Override
	public CreditPage<CreditVip> selectVipMerchantPageByParam(VipMerchantQueryParam queryParam) {
		CreditPage<CreditVip> result = vipService.selectVipMerchantPageByParam(queryParam);
        return result;
	}

	@Override
	public CreditPage<CreditVipTask> selectVipTaskPageByParam(VipTaskDtoQueryParam queryParam) {
		return vipService.selectVipTaskPageByParam(queryParam);
	}

	/**
	 * 获取更新详情
	 * @param queryParam
	 * @return
	 */
	@Override
	public CreditModifyDetail queryModifyDetail(VipTaskProductsResultQueryParam queryParam) {
		String productCode = queryParam.getProductCode();
		CreditModifyDetail modifyDetail = new CreditModifyDetail();
		List<CreditModifyStatus> modifyStatuses = new ArrayList<CreditModifyStatus>();
		CreditModifyStatus modifyStatus = new CreditModifyStatus();
		boolean history = "YES".equals(queryParam.getHistory());
		if(!history){
			SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
			queryParam.setTriggerTime(sf.format(new Date()));
		}
        logger.info("queryModifyDetail-queryVipTaskProductsResult productCode:{}, param:{}", queryParam.getProductCode(), GsonUtil.getInstance().toJson(queryParam));
        List<CreditVipTaskProductResult> results = new ArrayList<>();
		try {
		    if(StringUtils.isNotBlank(queryParam.getRelationType()) && CreditYesOrNoEnum.YES.toName().equals(queryParam.getRelationType().toUpperCase())){// 查询关联企业的变更详情
                modifyDetail.setRelationType(queryParam.getRelationType().toUpperCase());
                results = vipService.queryVipTaskProductsResult(queryParam);
            }else if(StringUtils.isNotBlank(queryParam.getRelationType()) && CreditYesOrNoEnum.NO.toName().equals(queryParam.getRelationType().toUpperCase())){ // 否则视为查询目标企业的变更详情
                modifyDetail.setRelationType(queryParam.getRelationType().toUpperCase());
                results = vipService.queryVipTaskProductsResult(queryParam);
            }else{
                results = vipService.queryVipTaskProductsResult(queryParam);
            }
		    logger.info("queryModifyDetail-queryVipTaskProductsResult productCode:{}, results:{}", queryParam.getProductCode(), GsonUtil.getInstance().toJson(results));
            modifyDetail.setProductCode(queryParam.getProductCode());
			if(CollectionUtils.isNotEmpty(results)){
				//取最新一条的数据更新状态 如果第一条为错误或者无更新，则错误或者无更新 （查询历史除外）
				CreditVipTaskProductResult vipTaskProductResult = results.get(0);
				//取最近的有更新且返回结果正确的数据，如果没有的话就取用第一条记录,防止同一天多次跑批造成漏失中间变更的情况
				for (CreditVipTaskProductResult creditVipTaskProductResult : results){
					if (creditVipTaskProductResult != null && creditVipTaskProductResult.getResultUpdateStatus().equals(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode())
							&&creditVipTaskProductResult.getResultType().equals(CreditVipResultTypeEnum.RESULT_TYPE_SUCCESS.getCode())){
						vipTaskProductResult = creditVipTaskProductResult;
					}
				}
				String updateStatus = vipTaskProductResult.getResultUpdateStatus();
				String info = vipTaskProductResult.getUpdateInfo();
				if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(updateStatus)){//有更新
					modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
					modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
				}else if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_NOT_UPDATE.getCode().equals(updateStatus)){//无更新
					modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_NOT_UPDATE);
					modifyStatus.setMsg("暂无更新数据");
				}else if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UNKNOWN.getCode().equals(updateStatus)){//更新失败
					modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UNKNOWN);
					String msg = ResultDataEnum.RESULT_SERVICE_FAIL.toDescription();
					String code = "";
					//解析json 得到失败原因
					if(StringUtils.isNotBlank(info)){
						JSONObject object = JSONObject.parseObject(info);
						code = object.get("code")+"";
						if(ResultDataEnum.RESULT_BALANCE_LACK.toName().equals(code)||ResultDataEnum.RESULT_SERVICE_NOSTRATEGY.toName().equals(code)){
							msg = RESULT_BALANCE_LACK_MESSAGE;
						}else {
							msg = object.get("message") +"";
						}
					}
					modifyStatus.setMsg(msg);
				}

				if(EnterpriseProductEnum4Common.ENTERPRISE_BASIC_QUERY.toName().equals(productCode)){//企业基本信息
					List<AlterRecordEntityExpand> list = new ArrayList<AlterRecordEntityExpand>();
					for (CreditVipTaskProductResult result:results){
						String resultUpdateStatus = result.getResultUpdateStatus();
						String updateInfo = result.getUpdateInfo();
						if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
							//解析json
							if(StringUtils.isNotBlank(updateInfo)){
								List<AlterRecordEntityExpand> entityList = JSONArray.parseArray(updateInfo,AlterRecordEntityExpand.class);
								if(CollectionUtils.isNotEmpty(entityList)){
								    for(AlterRecordEntityExpand expand : entityList){
                                        expand.setEntNameRelation(result.getEntNameRelation());
                                    }
                                }
								list.addAll(entityList);
							}
							modifyDetail.setData(list);
						}
					}
					if(history&&CollectionUtils.isNotEmpty(list)){//查询历史并且有数据 则修改状态为有更新,防止出现有变更但变更内容为空的差异数据的出现
						modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
						modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
					}
				}else if(EnterpriseProductEnum4Common.ENTERPRISE_ENTINV_QUERY.toName().equals(productCode)){//企业对外投资信息
					List<EntInvQueryDataExpand> list = new ArrayList<>();
					for (CreditVipTaskProductResult result:results){
						String resultUpdateStatus = result.getResultUpdateStatus();
						String updateInfo = result.getUpdateInfo();
						if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0 ){//有更新
							//解析json
							if(StringUtils.isNotBlank(updateInfo)){
								List<EntInvQueryDataExpand> queryList = JSONArray.parseArray(updateInfo,EntInvQueryDataExpand.class);
                                if(CollectionUtils.isNotEmpty(queryList)){
                                    for(EntInvQueryDataExpand expand : queryList){
                                        expand.setEntNameRelation(result.getEntNameRelation());
                                    }
                                }
								list.addAll(queryList);
								modifyDetail.setData(list);
							}
						}
					}
					if(history&&CollectionUtils.isNotEmpty(list)){//查询历史并且有数据 则修改状态为有更新
						modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
						modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
					}
				}else if((EnterpriseProductEnum4Common.ENTERPRISE_NEGATIVE_QUERY.toName()).equals(productCode)){//负面信息
					//经营异常名单
					List<AbnormalEntityExpand> abnormalEntities = new ArrayList<AbnormalEntityExpand>();
					//行政处罚
                    NegativeInfoQueryDataExpand data = new NegativeInfoQueryDataExpand();
					List<PunishmentEntityExpand> punishmentEntities = new ArrayList<PunishmentEntityExpand>();
					CreditModifyStatus modifyStatus1 = new CreditModifyStatus();
					modifyStatus1.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_NOT_UPDATE);
					modifyStatus1.setMsg("暂无更新数据");
					CreditModifyStatus modifyStatus2 = new CreditModifyStatus();
					modifyStatus2.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_NOT_UPDATE);
					modifyStatus2.setMsg("暂无更新数据");
					boolean abnormalNew =true;//最新的一条
					boolean punishmentNew =true;//最新的一条
					if(CollectionUtils.isNotEmpty(results)){
						for (CreditVipTaskProductResult result:results){
							String subProductCode =result.getSubProductCode();
							if(VipResultSubProductCodeEnum.ABNORMAL.getCode().equals(subProductCode)){//经营异常
								String resultUpdateStatus = result.getResultUpdateStatus();
								String updateInfo = result.getUpdateInfo();
								if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
									if(abnormalNew){
										modifyStatus1.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
										abnormalNew = false;
									}
									//解析json
									if(StringUtils.isNotBlank(updateInfo)){
										List<AbnormalEntityExpand> list = JSONArray.parseArray(updateInfo,AbnormalEntityExpand.class);
                                        if(CollectionUtils.isNotEmpty(list)){
                                            for(AbnormalEntityExpand expand : list){
                                                expand.setEntNameRelation(result.getEntNameRelation());
                                            }
                                        }
										abnormalEntities.addAll(list);
										data.setAbnormalEntities(abnormalEntities);
										modifyDetail.setData(data);
									}
								}else if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus)&&abnormalNew){//无更新
									modifyStatus1.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_NOT_UPDATE);
									modifyStatus1.setMsg("暂无更新数据");
									abnormalNew = false;
								}else if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UNKNOWN.getCode().equals(resultUpdateStatus)&&abnormalNew){//更新失败
									modifyStatus1.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UNKNOWN);
									String msg = ResultDataEnum.RESULT_SERVICE_FAIL.toDescription();
									String code ="";
									//解析json 得到失败原因
									if(StringUtils.isNotBlank(updateInfo)){
										JSONObject object = JSONObject.parseObject(updateInfo);
										code = object.get("code")+"";
										if(ResultDataEnum.RESULT_BALANCE_LACK.toName().equals(code)||ResultDataEnum.RESULT_SERVICE_NOSTRATEGY.toName().equals(code)){
											msg = RESULT_BALANCE_LACK_MESSAGE;
										}else {
											msg = object.get("message") +"";
										}
									}
									abnormalNew = false;
									modifyStatus1.setMsg(msg);
								}
							}else if(VipResultSubProductCodeEnum.PUNISHMENT.getCode().equals(subProductCode)){//行政处罚
								String resultUpdateStatus = result.getResultUpdateStatus();
								String updateInfo = result.getUpdateInfo();
								if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
									if(punishmentNew){
										modifyStatus2.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
										punishmentNew = false;
									}
									//解析json
									if(StringUtils.isNotBlank(updateInfo)){
										List<PunishmentEntityExpand> list = JSONArray.parseArray(updateInfo,PunishmentEntityExpand.class);
                                        if(CollectionUtils.isNotEmpty(list)){
                                            for(PunishmentEntityExpand expand : list){
                                                expand.setEntNameRelation(result.getEntNameRelation());
                                            }
                                        }
										punishmentEntities.addAll(list);
										data.setPunishmentEntities(punishmentEntities);
										modifyDetail.setData(data);
									}
								}else if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_NOT_UPDATE.getCode().equals(resultUpdateStatus)&&punishmentNew){
									modifyStatus2.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_NOT_UPDATE);
									modifyStatus2.setMsg("暂无更新数据");
									punishmentNew = false;
								}else if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UNKNOWN.getCode().equals(resultUpdateStatus)&&punishmentNew){//更新失败
									modifyStatus2.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UNKNOWN);
									String msg = ResultDataEnum.RESULT_SERVICE_FAIL.toDescription();
									String code = "";
									//解析json 得到失败原因
									if(StringUtils.isNotBlank(updateInfo)){
										JSONObject object = JSONObject.parseObject(updateInfo);
										code = object.get("code")+"";
										if(ResultDataEnum.RESULT_BALANCE_LACK.toName().equals(code)||ResultDataEnum.RESULT_SERVICE_NOSTRATEGY.toName().equals(code)){
											msg = RESULT_BALANCE_LACK_MESSAGE;
										}else {
											msg = object.get("message") +"";
										}
									}
									punishmentNew = false;
									modifyStatus2.setMsg(msg);
								}
							}
						}
					}
					if(history&&CollectionUtils.isNotEmpty(abnormalEntities)){//查询历史需要查询所有数据
						modifyStatus1.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
					}
					if(history&&CollectionUtils.isNotEmpty(punishmentEntities)){//查询历史需要查询所有数据
						modifyStatus2.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
					}
					modifyStatuses.clear();
					modifyStatuses.add(modifyStatus1);
					modifyStatuses.add(modifyStatus2);
					modifyDetail.setModifyStatus(modifyStatuses);
					return modifyDetail;
				}else if(EnterpriseProductEnum4Common.ENTERPRISE_PUNISHBREAK_QUERY.toName().equals(productCode)){//企业失信被执行信息
					List<PunishBreakQueryDataExpand>  queryDatas = new ArrayList<>();
					for (CreditVipTaskProductResult result:results){
						String resultUpdateStatus = result.getResultUpdateStatus();
						String updateInfo = result.getUpdateInfo();
						if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
							//解析json
							if(StringUtils.isNotBlank(updateInfo)){
								List<PunishBreakQueryDataExpand> entityList = JSONArray.parseArray(updateInfo,PunishBreakQueryDataExpand.class);
                                if(CollectionUtils.isNotEmpty(entityList)){
                                    for(PunishBreakQueryDataExpand expand : entityList){
                                        expand.setEntNameRelation(result.getEntNameRelation());
                                    }
                                }
								queryDatas.addAll(entityList);
							}
							modifyDetail.setData(queryDatas);
						}
					}
					if(history&&CollectionUtils.isNotEmpty(queryDatas)){//查询历史并且有数据 则修改状态为有更新
						modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
						modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
					}
				}else if(EnterpriseProductEnum4Common.ENTERPRISE_BLACKLIST_QUERY.toName().equals(productCode)){//企业黑名单
					List<BlackListEntity>  queryData = new ArrayList<BlackListEntity>();
					for (CreditVipTaskProductResult result:results){
						String resultUpdateStatus = result.getResultUpdateStatus();
						String updateInfo = result.getUpdateInfo();
						if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
							//解析json
							DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							if(StringUtils.isNotBlank(updateInfo)){
								BlackListEntity blackListEntity =new BlackListEntity();
								String hitStr = updateInfo;
								blackListEntity.setModifyDate(result.getModifiedDate());
								blackListEntity.setModifyDateStr(result.getModifiedDate()==null?"":df.format(result.getModifiedDate()));
								if("NOT_HIT".equals(hitStr)){
									blackListEntity.setHitStr("否");
								}else if("HIT".equals(hitStr)){
									blackListEntity.setHitStr("是");
								}
								queryData.add(blackListEntity);
							}
							modifyDetail.setData(queryData);
						}
					}
					if(history&&CollectionUtils.isNotEmpty(queryData)){//查询历史并且有数据 则修改状态为有更新
						modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
						modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
					}
				}else if(EnterpriseProductEnum4Common.ENTERPRISE_LAWSUITINFO_QUERY.toName().equals(productCode)){//法院裁判信息
					List<EntLawsuitInfoDataExpand>  queryDatas = new ArrayList<>();
					for (CreditVipTaskProductResult result:results){
						String resultUpdateStatus = result.getResultUpdateStatus();
						String updateInfo = result.getUpdateInfo();
						if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
							modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
							//解析json
							if(StringUtils.isNotBlank(updateInfo)){
								List<EntLawsuitInfoDataExpand> entityList = JSONArray.parseArray(updateInfo,EntLawsuitInfoDataExpand.class);
                                if(CollectionUtils.isNotEmpty(entityList)){
                                    for(EntLawsuitInfoDataExpand expand : entityList){
                                        expand.setEntNameRelation(result.getEntNameRelation());
                                    }
                                }
								queryDatas.addAll(entityList);
							}
							modifyDetail.setData(queryDatas);
						}
					}
					if(history&&CollectionUtils.isNotEmpty(queryDatas)){//查询历史并且有数据 则修改状态为有更新
						modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
						modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
					}
				}else if(EnterpriseProductEnum4Common.ENTERPRISE_QUALIFY_VERIFY.toName().equals(productCode)){//企业资质认证

					List<EntQualifyVerifyDataExpand>  queryDatas = new ArrayList<>();
					for (CreditVipTaskProductResult result:results){
						String resultUpdateStatus = result.getResultUpdateStatus();
						String updateInfo = result.getUpdateInfo();
						if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
							//解析json
							if(StringUtils.isNotBlank(updateInfo)){
								JSONArray entityList = JSONArray.parseArray(updateInfo);
                                EntQualifyVerifyDataExpand verifyData = new EntQualifyVerifyDataExpand();
                                verifyData.setEntNameRelation(result.getEntNameRelation());
								StringBuffer detail = new StringBuffer();
								for(int i=0;i<entityList.size();i++){
									detail.append(entityList.get(i));
									detail.append(",");
								}
								if(detail!=null&&detail.length()>0){
									verifyData.setQualificationNames(detail.substring(0,detail.length()-1).toString());
									verifyData.setQualificationCount(entityList.size()+"");
									queryDatas.add(verifyData);
								}
							}
							modifyDetail.setData(queryDatas);
						}
					}
					if(history&&CollectionUtils.isNotEmpty(queryDatas)){//查询历史并且有数据 则修改状态为有更新
						modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
						modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
					}
				}else if(EnterpriseProductEnum4Common.ENTERPRISE_EQUITYINFO_QUERY.toName().equals(productCode)){//股权质押信息
					List<EquityInfoDataExpand>  equityInfoDatas = new ArrayList<EquityInfoDataExpand>();
					for (CreditVipTaskProductResult result:results){
						String resultUpdateStatus = result.getResultUpdateStatus();
						String updateInfo = result.getUpdateInfo();
						if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
							//解析json
							if(StringUtils.isNotBlank(updateInfo)){
								List<EquityInfoDataExpand> queryList = JSONArray.parseArray(updateInfo,EquityInfoDataExpand.class);
                                if(CollectionUtils.isNotEmpty(queryList)){
                                    for(EquityInfoDataExpand expand : queryList){
                                        expand.setEntNameRelation(result.getEntNameRelation());
                                    }
                                }
								equityInfoDatas.addAll(queryList);
								modifyDetail.setData(equityInfoDatas);
							}
						}
					}
					if(history&&CollectionUtils.isNotEmpty(equityInfoDatas)){//查询历史并且有数据 则修改状态为有更新
						modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
						modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
					}
				}else if(EnterpriseProductEnum4Common.ENTERPRISE_MORTGAGEINFO_QUERY.toName().equals(productCode)){//动产抵押信息
					List<MortgageInfoDataExpand>  mortgageInfoDatas = new ArrayList<>();
					for (CreditVipTaskProductResult result:results){
						String resultUpdateStatus = result.getResultUpdateStatus();
						String updateInfo = result.getUpdateInfo();
						if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
							//解析json
							if(StringUtils.isNotBlank(updateInfo)){
								List<MortgageInfoDataExpand> queryList = JSONArray.parseArray(updateInfo,MortgageInfoDataExpand.class);
                                if(CollectionUtils.isNotEmpty(queryList)){
                                    for(MortgageInfoDataExpand expand : queryList){
                                        expand.setEntNameRelation(result.getEntNameRelation());
                                    }
                                }
								mortgageInfoDatas.addAll(queryList);
								modifyDetail.setData(mortgageInfoDatas);
							}
						}
					}
					if(history&&CollectionUtils.isNotEmpty(mortgageInfoDatas)){//查询历史并且有数据 则修改状态为有更新
						modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
						modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
					}
				}else if(EnterpriseProductEnum4Common.ENTERPRISE_ILLEGALINFO_QUERY.toName().equals(productCode)){//企业严重违法信息
					List<IllegalInfoDataExpand>  illegalInfoDatas = new ArrayList<>();
					for (CreditVipTaskProductResult result:results){
						String resultUpdateStatus = result.getResultUpdateStatus();
						String updateInfo = result.getUpdateInfo();
						if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
							//解析json
							if(StringUtils.isNotBlank(updateInfo)){
								List<IllegalInfoDataExpand> queryList = JSONArray.parseArray(updateInfo,IllegalInfoDataExpand.class);
                                if(CollectionUtils.isNotEmpty(queryList)){
                                    for(IllegalInfoDataExpand expand : queryList){
                                        expand.setEntNameRelation(result.getEntNameRelation());
                                    }
                                }
								illegalInfoDatas.addAll(queryList);
								modifyDetail.setData(illegalInfoDatas);
							}
						}
					}
					if(history&&CollectionUtils.isNotEmpty(illegalInfoDatas)){//查询历史并且有数据 则修改状态为有更新
						modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
						modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
					}
				}else if(EnterpriseProductEnum4Common.ENTERPRISE_CHECKINFO_QUERY.toName().equals(productCode)){   //抽查检查
					List<CheckInfoDataExpand>  checkInfoDatas = new ArrayList<CheckInfoDataExpand>();
					for (CreditVipTaskProductResult result:results){
						String resultUpdateStatus = result.getResultUpdateStatus();
						String updateInfo = result.getUpdateInfo();
						if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
							//解析json
							if(StringUtils.isNotBlank(updateInfo)){
								List<CheckInfoDataExpand> queryList = JSONArray.parseArray(updateInfo,CheckInfoDataExpand.class);
                                if(CollectionUtils.isNotEmpty(queryList)){
                                    for(CheckInfoDataExpand expand : queryList){
                                        expand.setEntNameRelation(result.getEntNameRelation());
                                    }
                                }
								checkInfoDatas.addAll(queryList);
								modifyDetail.setData(checkInfoDatas);
							}
						}
					}
					if(history&&CollectionUtils.isNotEmpty(checkInfoDatas)){//查询历史并且有数据 则修改状态为有更新
						modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
						modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
					}
				}else if(EnterpriseProductEnum4Common.ENTERPRISE_PUNISHED_QUERY.toName().equals(productCode)){   //被执行人
                    List<PunishedQueryDataExpand>  punishedDataDatas = new ArrayList<PunishedQueryDataExpand>();
                    for (CreditVipTaskProductResult result:results){
                        String resultUpdateStatus = result.getResultUpdateStatus();
                        String updateInfo = result.getUpdateInfo();
                        if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
                            //解析json
                            if(StringUtils.isNotBlank(updateInfo)){
                                List<PunishedQueryDataExpand> queryList = JSONArray.parseArray(updateInfo,PunishedQueryDataExpand.class);
                                if(CollectionUtils.isNotEmpty(queryList)){
                                    for(PunishedQueryDataExpand expand : queryList){
                                        expand.setEntNameRelation(result.getEntNameRelation());
                                    }
                                }
                                punishedDataDatas.addAll(queryList);
                                modifyDetail.setData(punishedDataDatas);
                            }
                        }
                    }
                    if(history&&CollectionUtils.isNotEmpty(punishedDataDatas)){//查询历史并且有数据 则修改状态为有更新
                        modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
                        modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
                    }
                }else if(EnterpriseProductEnum4Common.ENTERPRISE_COURT_NOTICE.toName().equals(productCode)){   //法院公告
                    List<EntCourtNoticeDataExpand> courtNoticeDataDatas = new ArrayList<EntCourtNoticeDataExpand>();
                    for (CreditVipTaskProductResult result:results){
                        String resultUpdateStatus = result.getResultUpdateStatus();
                        String updateInfo = result.getUpdateInfo();
                        if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
                            //解析json
                            if(StringUtils.isNotBlank(updateInfo)){
                                List<EntCourtNoticeDataExpand> queryList = JSONArray.parseArray(updateInfo,EntCourtNoticeDataExpand.class);
                                if(CollectionUtils.isNotEmpty(queryList)){
                                    for(EntCourtNoticeDataExpand expand : queryList){
                                        expand.setEntNameRelation(result.getEntNameRelation());
                                    }
                                }
                                courtNoticeDataDatas.addAll(queryList);
                                modifyDetail.setData(courtNoticeDataDatas);
                            }
                        }
                    }
                    if(history&&CollectionUtils.isNotEmpty(courtNoticeDataDatas)){//查询历史并且有数据 则修改状态为有更新
                        modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
                        modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
                    }
                }else if(VipResultSubProductCodeEnum.ENT_LAWSUITINFO_PERSON_QUERY.getCode().equals(productCode)){   //个人法院裁判
                    List<LawsuitInfoDetailDataExpand>  dataDatas = new ArrayList<>();
                    for (CreditVipTaskProductResult result:results){
                        String resultUpdateStatus = result.getResultUpdateStatus();
                        String updateInfo = result.getUpdateInfo();
                        if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
                            //解析json
                            if(StringUtils.isNotBlank(updateInfo)){
                                List<LawsuitInfoDetailDataExpand> queryList = JSONArray.parseArray(updateInfo,LawsuitInfoDetailDataExpand.class);
                                if(CollectionUtils.isNotEmpty(queryList)){
                                    for(LawsuitInfoDetailDataExpand expand : queryList){
                                        expand.setEntNameRelation(result.getEntNameRelation());
                                    }
                                }
                                dataDatas.addAll(queryList);
                                modifyDetail.setData(dataDatas);
                            }
                        }
                    }
                    if(history&&CollectionUtils.isNotEmpty(dataDatas)){//查询历史并且有数据 则修改状态为有更新
                        modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
                        modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
                    }
                }else if(EnterpriseProductEnum4Common.ENTERPRISE_PUNISHBREAK_PERSON_QUERY.toName().equals(productCode)){   //个人 失信被执行
                    List<PunishBreakQueryDataExpand>  dataDatas = new ArrayList<>();
                    for (CreditVipTaskProductResult result:results){
                        String resultUpdateStatus = result.getResultUpdateStatus();
                        String updateInfo = result.getUpdateInfo();
                        if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
                            //解析json
                            if(StringUtils.isNotBlank(updateInfo)){
                                List<PunishBreakQueryDataExpand> queryList = JSONArray.parseArray(updateInfo,PunishBreakQueryDataExpand.class);
                                if(CollectionUtils.isNotEmpty(queryList)){
                                    for(PunishBreakQueryDataExpand expand : queryList){
                                        expand.setEntNameRelation(result.getEntNameRelation());
                                    }
                                }
                                dataDatas.addAll(queryList);
                                modifyDetail.setData(dataDatas);
                            }
                        }
                    }
                    if(history&&CollectionUtils.isNotEmpty(dataDatas)){//查询历史并且有数据 则修改状态为有更新
                        modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
                        modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
                    }
                }else if(EnterpriseProductEnum4Common.ENTERPRISE_PUNISHED_PERSON_QUERY.toName().equals(productCode)){   //个人 被执行人
                    List<PunishedQueryDataExpand>  dataDatas = new ArrayList<>();
                    for (CreditVipTaskProductResult result:results){
                        String resultUpdateStatus = result.getResultUpdateStatus();
                        String updateInfo = result.getUpdateInfo();
                        if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
                            //解析json
                            if(StringUtils.isNotBlank(updateInfo)){
                                List<PunishedQueryDataExpand> queryList = JSONArray.parseArray(updateInfo,PunishedQueryDataExpand.class);
                                if(CollectionUtils.isNotEmpty(queryList)){
                                    for(PunishedQueryDataExpand expand : queryList){
                                        expand.setEntNameRelation(result.getEntNameRelation());
                                    }
                                }
                                dataDatas.addAll(queryList);
                                modifyDetail.setData(dataDatas);
                            }
                        }
                    }
                    if(history&&CollectionUtils.isNotEmpty(dataDatas)){//查询历史并且有数据 则修改状态为有更新
                        modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
                        modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
                    }
                }else if(EnterpriseProductEnum4Common.ENTERPRISE_CHINADATA_BF_MONITOR_LIST.toName().equals(productCode)){   //最终受益人
                    List<ChinaDataAntiMoneyLaunderResp>  dataDatas = new ArrayList<>();
                    for (CreditVipTaskProductResult result:results){
                        String resultUpdateStatus = result.getResultUpdateStatus();
                        String updateInfo = result.getUpdateInfo();
                        if(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getCode().equals(resultUpdateStatus) && result.getResultListSize() != 0){//有更新
                            //解析json
                            if(StringUtils.isNotBlank(updateInfo)){
                                List<ChinaDataAntiMoneyLaunderResp> queryList = JSONArray.parseArray(updateInfo,ChinaDataAntiMoneyLaunderResp.class);
                                dataDatas.addAll(queryList);
                                modifyDetail.setData(dataDatas);
                            }
                        }
                    }
                    if(history&&CollectionUtils.isNotEmpty(dataDatas)){//查询历史并且有数据 则修改状态为有更新
                        modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE);
                        modifyStatus.setMsg(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UPDATE.getDescription());
                    }
                }

			}else{//增加两次
				modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_NOT_UPDATE);
				modifyStatus.setMsg("暂无更新数据");
				modifyStatuses.add(modifyStatus);
			}
			modifyStatuses.add(modifyStatus);
			modifyDetail.setModifyStatus(modifyStatuses);
		}catch (Exception e){
			modifyStatus.setStatus(CreditVipResultUpdateStatusEnum.RESULT_UPDATE_UNKNOWN);
			modifyStatus.setMsg(ResultDataEnum.RESULT_SERVICE_FAIL.toDescription());
			List<CreditModifyStatus> modifyStatuss = new ArrayList<CreditModifyStatus>();
			modifyStatuss.add(modifyStatus);
			modifyDetail.setModifyStatus(modifyStatuss);
			logger.error("调用更新详情失败",e);
		}finally {
            logger.info("queryModifyDetail-queryVipTaskProductsResult productCode:{}, responseData modifyDetail:{}", queryParam.getProductCode(), GsonUtil.getInstance().toJson(modifyDetail));
        }

		return modifyDetail;
	}


	@Override
	public int batchModifyVipMerchantMonitorStatus(CreditRequestParam<CreditVip> param) throws Exception {
		CreditVip creditVip = param.getParam();
		int batchModifyCount = 0;
		try {
			batchModifyCount = vipService.batchModifyVipMerchantMonitorStatus(creditVip);
		} catch (Exception e) {
			logger.error("vipService.batchModifyVipMerchantMonitorStatus() exception , "+ e);
			throw new Exception("批量更新vip监控 状态异常");
		}
		return batchModifyCount;
	}

	@Override
	public CreditVip selectByMerchantId(CreditRequestParam<CreditVip> param) {
		CreditVip creditVip = param.getParam();
		return vipService.selectByMerchantId(creditVip.getMerchantId());
	}

	@Override
	public int insertVipMerchant(CreditRequestParam<CreditVip> param) {
		CreditVip creditVip = param.getParam();
		vipService.insertVipMerchant(creditVip);
		Integer vipId = creditVip.getVipId();
		return vipId;
	}

	@Override
	public Integer insertBatchVipTime(CreditRequestParam<List<CreditVipWithTime>> timeParam) {
		List<CreditVipWithTime> creditVipTimeList = timeParam.getParam();
		return vipService.insertBatchVipTime(creditVipTimeList);
	}

	/**
	 * 查询监控方案列表
	 *
	 * @param param
	 * @return
	 */
	@Override
	public CreditPage<CreditVipAlarmRule> queryAlarmRule(VipAlarmRuleQueryParam param) {
        CreditPage<CreditVipAlarmRule> ruleList= null;
		try {
			ruleList = vipAlarmService.queryRuleList(param);
		} catch (Exception e) {
			e.printStackTrace();
			throw new CreditApiException(ResponseCodeEnum.INTERFACE_ERROR);
		}
		return ruleList;
	}

	/**
	 * 查询监控方案详情
	 *
	 * @param param
	 * @return
	 */
	@Override
	public CreditVipAlarmRule queryAlarmRuleDetail(VipAlarmRuleQueryParam param) {
		Integer ruleId=param.getRuleId();
		if(ruleId==null){
			throw new CreditApiException(ResponseCodeEnum.INVALID_PARAM);
		}
		CreditVipAlarmRule rule=vipAlarmService.queryRuleDetailById(ruleId);
		return rule;
	}

	/**
	 * 更新规则信息
	 *
	 * @param ruleParam
	 * @return
	 */
	@Override
	public int updateAlarmRule(CreditVipAlarmRule ruleParam) {
		return vipAlarmService.updateAlarmRule(ruleParam);
	}

	/**
	 * 关联规则和企业
	 *
	 * @param taskList
	 * @return
	 */
	@Override
	public int relAlarmRuleAndTask(List<CreditVipTask> taskList) {
		return vipAlarmService.relTaskRule(taskList);
	}

	/**
	 * 查询监控企业变更率
	 *
	 * @param param
	 * @return
	 */
	@Override
	public List<UpdateRatioResp> queryUpdateRatio(VipMonitorReportQueryParam param) {
		return vipAlarmService.queryEntUpdateRatio(param);
	}

	/**
	 * 查询监控红橙红占比
	 *
	 * @param param
	 * @return
	 */
	@Override
	public List<AlarmLevelRatioResp> queryAlarmLevelRatio(VipMonitorReportQueryParam param) {
		return vipAlarmService.queryAlarmLevelRatio(param);
	}

	@Override
	public Integer insertAlarmRule(CreditVipAlarmRule vipAlarmRule) {
		Integer insertCount = vipAlarmService.insertAlarmRule(vipAlarmRule);
		return vipAlarmRule.getId();
	}

	/**
	 * 批量插入vip监控方案详情
	 */
	@Override
	public int insertBatchVipAlarmRuleDetails(List<CreditVipAlarmRuleDetail> alarmRuleDetailList) {
        List<CreditVipAlarmRuleDetail> alarmRuleDetailList4Add = new ArrayList<>();
        List<String> eventCodelist = new ArrayList<>();
        for(VipAlarmEventEnum eventEnum : VipAlarmEventEnum.values()){
            if(null == eventEnum){continue;}
            if(StringUtils.isNotBlank(eventEnum.getCode()) && CreditOpenStatusEnum.OPEN.toName().equalsIgnoreCase(eventEnum.getEventStatus())
                    && !eventCodelist.contains(eventEnum.getCode())){
                eventCodelist.add(eventEnum.getCode());
            }else {
                continue;
            }
        }
        if(CollectionUtils.isNotEmpty(alarmRuleDetailList)){
            Integer reuleId = alarmRuleDetailList.get(0).getRelRuleId();
            for(String eventCode : eventCodelist){
                CreditVipAlarmRuleDetail ruleDetailNew = new CreditVipAlarmRuleDetail();
                ruleDetailNew.setRelRuleId(reuleId);
                ruleDetailNew.setTriggerEvent(eventCode);
                ruleDetailNew.setTriggerEventType(VipAlarmEventEnum.enumValueOfCode(eventCode).getEventType());
                ruleDetailNew.setAlarmLevel(VipAlarmLevelEnum.YELLOW.getCode());
                ruleDetailNew.setCreatedDate(new Date());
                ruleDetailNew.setModifiedDate(new Date());
                for(CreditVipAlarmRuleDetail ruleDetail : alarmRuleDetailList){
                    if(StringUtils.isNotBlank(ruleDetail.getTriggerEvent())
                            && eventCode.equalsIgnoreCase(ruleDetail.getTriggerEvent())
                            && !alarmRuleDetailList4Add.contains(ruleDetail)){
                        ruleDetailNew.setTriggerEvent(ruleDetail.getTriggerEvent());
                        ruleDetailNew.setTriggerEventType(VipAlarmEventEnum.enumValueOfCode(ruleDetail.getTriggerEvent()).getEventType());
                        ruleDetailNew.setAlarmLevel(VipAlarmLevelEnum.enumValueOf(ruleDetail.getAlarmLevel()).getCode());
                        ruleDetailNew.setCreatedDate(new Date());
                        ruleDetailNew.setModifiedDate(new Date());
//                        alarmRuleDetailList4Add.add(ruleDetailNew);
//                        break;
                    }
                }
                alarmRuleDetailList4Add.add(ruleDetailNew);
            }
        }else{
            logger.error("insertBatchVipAlarmRuleDetails alarmRuleDetailList 约定不可为空，最少要在0中给出relRuleId,alarmRuleDetailList size:"+alarmRuleDetailList.size());
        }

		return vipAlarmService.insertBatchVipAlarmRuleDetails(alarmRuleDetailList4Add);
	}

	/**
	 * 根据规则id查询应用该规则的监控企业
	 *
	 * @param ruleId
	 * @return
	 */
	@Override
	public List<CreditVipTask> queryVipTaskByRule(Integer ruleId) {
		VipTaskQueryParam queryParam=new VipTaskQueryParam();
		queryParam.setAlarmRuleId(ruleId);
		return vipService.queryVipTask(queryParam);
	}

	/**
	 * 查询监控数据
	 *
	 * @param param
	 * @return
	 */
	@Override
	public List<CreditVipMonitorCycleReport> queryVipMonitorCycleReport(VipMonitorCycleReportQueryParam param) {
		return vipAlarmService.queryVipMonitorCycleReport(param);
	}

	@Override
	public List<CreditVip> selectCreditVipByPrm(VipMerchantQueryParam vipMerchantQryPrm) {
		return vipService.selectCreditVipByPrm(vipMerchantQryPrm);
	}

	@Override
	public Integer deleteVipTriggerTime(CreditVipWithTime creditVipWithTime) {
		return vipService.deleteVipTriggerTime(creditVipWithTime);
	}

	@Override
	public Integer updateVipMerchant(CreditVip creditVip) {
		return vipService.updateVipMerchant(creditVip);
	}

    @Override
    public CreditResponseData addVipCompanyList(CreditRequestParam<List<CreditVipTask>> vipTaskParamList) {
        CreditResponseData responseData=new CreditResponseData();
        List<CreditVipTask> vipTaskList=vipTaskParamList.getParam();
        try {
            // 上游传参必须给定task 的queryType，否则默认为基础版base
            int count=vipService.addVipTaskList(vipTaskList, vipTaskParamList.getSystemId());
            if(count==0){
                logger.info("addVipCompanyList success.");
                responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
                responseData.setMessage("添加失败！");
            }else{
                logger.info("addVipCompanyList failed.");
                responseData.setResponseMessage(ResponseMessage.SUCCESS);
            }

        } catch (Exception e) {
            logger.error("addVipCompanyList error, {}", e);
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            responseData.setMessage(e.getMessage());
        }
        return responseData;
    }

    @Override
    public CreditResponseData<List<CreditVipTask>> queryMerchantVipTaskList(CreditRequestParam<VipTaskDtoQueryParam> queryParam) {
        CreditResponseData<List<CreditVipTask>> responseData = new CreditResponseData<List<CreditVipTask>>();
        try {
            logger.info("queryMerchantVipTaskList reqeustParam:{}",GsonUtil.getInstance().toJson(queryParam));
            if(null != queryParam && null != queryParam.getParam() && StringUtils.isNotBlank(queryParam.getParam().getMerchantNo())){
                List<CreditVipTask> vipTaskList = vipService.queryVipTaskListWithMerch(queryParam.getParam());
                responseData.setData(vipTaskList);
            }else{
                responseData.setSuccess(false);
                responseData.setCode(ResultDataEnum.REQUEST_PARAM_REQUIRED.toName());
                responseData.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
            }
        } catch (Exception e) {
            logger.error("queryMerchantVipTaskList error, {}", e);
            responseData.setSuccess(false);
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        logger.info("queryMerchantVipTaskList responseData:{}",GsonUtil.getInstance().toJson(responseData));
        return responseData;
    }

    @Override
    public CreditResponseData<List<CreditModifyDetail>> queryModifyDetailList4Api(CreditRequestParam<VipTaskProductsResultQueryParam> queryParam) {
        CreditResponseData<List<CreditModifyDetail>> responseData = new CreditResponseData<List<CreditModifyDetail>>();
        try {
            logger.info("queryMerchantVipTaskList requestParam:{}",GsonUtil.getInstance().toJson(queryParam));
            List<CreditModifyDetail> modifyDetailkList = new ArrayList<>();
            if(null != queryParam && null != queryParam.getParam() && null != queryParam.getParam().getTaskId()
                    && StringUtils.isNotBlank(queryParam.getParam().getHistory()) ){
                VipTaskProductsResultQueryParam resultQryPrm = queryParam.getParam();
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_BASIC_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询目标企业
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_LAWSUITINFO_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询目标企业
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_COURT_NOTICE.toName(), CreditYesOrNoEnum.NO.toName()); // 查询目标企业
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_PUNISHBREAK_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询目标企业
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_PUNISHED_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询目标企业
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_MORTGAGEINFO_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询目标企业
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_EQUITYINFO_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询目标企业
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_ILLEGALINFO_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询目标企业
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_CHECKINFO_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询目标企业
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_NEGATIVE_QUERY.toName(), CreditYesOrNoEnum.NO.toName());//负面信息 // 查询目标企业
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_PUNISHED_PERSON_QUERY.toName(), CreditYesOrNoEnum.NO.toName());// 个人被执行人信息 // 查询目标企业
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_CHINADATA_BF_MONITOR_LIST.toName(), CreditYesOrNoEnum.NO.toName());// 受益人变更监控 // 查询目标企业
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_PUNISHBREAK_PERSON_QUERY.toName(), CreditYesOrNoEnum.NO.toName());//  个人失信被执行人 // 查询目标企业
                this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, VipResultSubProductCodeEnum.ENT_LAWSUITINFO_PERSON_QUERY.getCode(), CreditYesOrNoEnum.NO.toName());//  个人法院裁判文书 // 查询目标企业
                try {
                    VipTaskDtoQueryParam queryParam4Task = new VipTaskDtoQueryParam();
                    queryParam4Task.setLimit(1);
                    List<String> taskIds = new ArrayList<String>();
                    taskIds.add(queryParam.getParam().getTaskId().toString());
                    queryParam4Task.setTaskIds(taskIds);
                    CreditPage<CreditVipTask> resultPage =this.queryVipTaskList(queryParam4Task);
                    if(null!=resultPage && resultPage.isSuccess() && CollectionUtils.isNotEmpty(resultPage.getRows()) && CreditSewageQueryTypeEnum.PRO.toName().equalsIgnoreCase(resultPage.getRows().get(0).getQueryType())){
                        this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_BASIC_QUERY.toName(), CreditYesOrNoEnum.YES.toName()); // 查询关联企业
                        this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_LAWSUITINFO_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询关联企业
                        this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_COURT_NOTICE.toName(), CreditYesOrNoEnum.NO.toName()); // 查询关联企业
                        this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_PUNISHBREAK_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询关联企业
                        this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_PUNISHED_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询关联企业
                        this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_MORTGAGEINFO_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询关联企业
                        this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_EQUITYINFO_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询关联企业
                        this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_ILLEGALINFO_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询关联企业
                        this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_CHECKINFO_QUERY.toName(), CreditYesOrNoEnum.NO.toName()); // 查询关联企业
                        this.buildRiskWarningProductQryModifyDetail(modifyDetailkList, resultQryPrm, EnterpriseProductEnum4Common.ENTERPRISE_NEGATIVE_QUERY.toName(), CreditYesOrNoEnum.NO.toName());//负面信息  // 查询关联企业
                        responseData.setData(modifyDetailkList);
                    }
                } catch (Exception e) {
                    logger.error("queryModifyDetailList4Api 4 Relation error, {}", e);
                }
            }else{
                responseData.setSuccess(false);
                responseData.setCode(ResultDataEnum.REQUEST_PARAM_REQUIRED.toName());
                responseData.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
            }
        } catch (Exception e) {
            logger.error("queryModifyDetailList4Api error, {}", e);
            responseData.setSuccess(false);
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        logger.info("queryModifyDetailList4Api responseData:{}",GsonUtil.getInstance().toJson(responseData));
        return responseData;
    }

    @Override
    public CreditResponseData<String> updateAlarmRuleAndDetail4Api(CreditRequestParam<CreditVipAlarmRule> creditRequestParam) {

        CreditResponseData<String> responseData = new CreditResponseData<String>();
        try {
            CreditVipAlarmRule vipAlarmRule  = creditRequestParam.getParam();
            if(null!= vipAlarmRule && null != vipAlarmRule.getId()){
                int result = vipAlarmService.updateAlarmRuleAndDetail4Api(vipAlarmRule);
                if(0 == result){
                    logger.error("updateAlarmRuleAndDetail4Api vipAlarmService.updateAlarmRuleAndDetail4Api failed. ");
                    responseData.setSuccess(false);
                    responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
                }
            }else{
                responseData.setSuccess(false);
                responseData.setCode(ResultDataEnum.REQUEST_PARAM_REQUIRED.toName());
                responseData.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
            }
        } catch (Exception e) {
            logger.error("updateAlarmRuleAndDetail4Api error, {}", e);
            responseData.setSuccess(false);
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        return responseData;
    }

	/**
	 * 关联企业查询
	 * @param queryParam
	 * @return
	 */
	@Override
	public CreditResponseData<List<String>> queryRelationEnt(CreditRequestParam<String> queryParam) {
		CreditResponseData<List<String>> responseData = new CreditResponseData<List<String>>();
		try {
			logger.info("queryRelationEnt reqeustParam:{}",GsonUtil.getInstance().toJson(queryParam));
			if(null != queryParam && null != queryParam.getParam() && StringUtils.isNotBlank(queryParam.getParam())){
				responseData=entRelationQueryService.queryRelationEnt(queryParam);
			}else{
				responseData.setSuccess(false);
				responseData.setCode(ResultDataEnum.REQUEST_PARAM_REQUIRED.toName());
				responseData.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
			}
		} catch (Exception e) {
			logger.error("queryRelationEnt error, {}", e);
			responseData.setSuccess(false);
			responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
		}
		logger.info("queryRelationEnt responseData:{}",GsonUtil.getInstance().toJson(responseData));
		return responseData;
	}

    @Override
    public CreditResponseData<List<CreditVipTask>> verifyMerchantVipTaskList(CreditRequestParam<VipTaskDtoQueryParam> queryParam) {
        CreditResponseData<List<CreditVipTask>> responseData = new CreditResponseData<List<CreditVipTask>>();
        List<CreditVipTask> vipTaskList = new ArrayList<>();
        try {
            logger.info("verifyMerchantVipTaskList reqeustParam:{}",GsonUtil.getInstance().toJson(queryParam));
            if(null != queryParam && null != queryParam.getParam() && null != queryParam.getParam().getMerchantId()){
                vipTaskList = vipService.queryVipTaskListWithMerch(queryParam.getParam());
                if(CollectionUtils.isEmpty(vipTaskList)){ // 查询关联企业是否有效
                    VipTaskQueryParam relationExsitQryPrm = new VipTaskQueryParam();
                    relationExsitQryPrm.setRelationStatus(CreditOpenStatusEnum.OPEN.toName());
                    relationExsitQryPrm.setMerchantId(queryParam.getParam().getMerchantId());
                    relationExsitQryPrm.setEntNameRelation(queryParam.getParam().getEntName());
                    vipTaskList = creditVipTaskRelationService.selectTaskRelationPageByMerchRela(relationExsitQryPrm);
                }
                responseData.setData(vipTaskList);
            }else{
                responseData.setSuccess(false);
                responseData.setCode(ResultDataEnum.REQUEST_PARAM_REQUIRED.toName());
                responseData.setResponseMessage(ResponseMessage.PARAM_ILLEGAL);
            }
        } catch (Exception e) {
            logger.error("queryMerchantVipTaskList error, {}", e);
            responseData.setSuccess(false);
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
        }
        logger.info("queryMerchantVipTaskList responseData:{}",GsonUtil.getInstance().toJson(responseData));
        return responseData;
    }

    @Override
    public Integer selectGroupIdByUserPin(CreditRequestParam<VipTaskDtoQueryParam> queryParam) {
        return null;
    }

    @Override
    public CreditPage<CreditVipGroup> selectVipGroupPageByParam(CreditRequestParam<VipGroupQueryParam> queryParam) {
        return null;
    }

    @Override
    public Integer insertBatchGroupUsers(CreditRequestParam<List<CreditVipGroupUser>> queryParam) {
        return null;
    }

    @Override
    public Integer insertCreditGroup(CreditRequestParam<CreditVipGroup> queryParam) {
        return null;
    }

    @Override
    public CreditPage<CreditVipGroupUser> selectGroupUserList(CreditRequestParam<VipGroupQueryParam> creditRequestParam) {
        return null;
    }

    @Override
    public CreditResponseData cleanDataVipGroup(CreditRequestParam<String> creditRequestParam) {
        return null;
    }


    /**
     * 构造每个产品的变更详情查询
     * @param modifyDetailkList
     * @param resultQryPrm
     * @param productCode
     * @param queryType NO-目标企业；YES-关联企业
     */
    private void buildRiskWarningProductQryModifyDetail(List<CreditModifyDetail> modifyDetailkList, VipTaskProductsResultQueryParam resultQryPrm,
                                                        String productCode, String queryType) {
        try {
            resultQryPrm.setProductCode(productCode);
            if(EnterpriseProductEnum4Common.ENTERPRISE_NEGATIVE_QUERY.toName().equalsIgnoreCase(productCode) ){
                CreditModifyDetail<NegativeInfoQueryData> baseInfoModifyDetail = this.queryModifyDetail(resultQryPrm);
                baseInfoModifyDetail.setProductCode(productCode);
                if(null != baseInfoModifyDetail && CollectionUtils.isNotEmpty(baseInfoModifyDetail.getModifyStatus())){
                    List<CreditModifyStatus> modifyStatuss = baseInfoModifyDetail.getModifyStatus();
                    CreditModifyStatus modifyStatus1 = modifyStatuss.get(1);//行政处罚
                    CreditModifyDetail baseInfoModifyDetail1 = new CreditModifyDetail();
                    baseInfoModifyDetail1.setProductCode(EnterpriseProductEnum4Common.ENTERPRISE_PUNISHMENT_QUERY.toName());
                    List<CreditModifyStatus> modifyStatus1List = new ArrayList<>();
                    modifyStatus1List.add(modifyStatus1);
                    baseInfoModifyDetail1.setModifyStatus(modifyStatus1List);
                    if(null != baseInfoModifyDetail.getData() && null != baseInfoModifyDetail.getData().getPunishmentEntities()){
                        baseInfoModifyDetail1.setData(baseInfoModifyDetail.getData().getPunishmentEntities());
                    }else{
                        baseInfoModifyDetail1.setData(baseInfoModifyDetail.getModifyStatus().get(1).getMsg());
                    }
                    modifyDetailkList.add(baseInfoModifyDetail1);
                    CreditModifyStatus modifyStatus0 = modifyStatuss.get(0);//列入经营异常名单查询
                    CreditModifyDetail baseInfoModifyDetail0 = new CreditModifyDetail();
                    baseInfoModifyDetail0.setProductCode(EnterpriseProductEnum4Common.ENTERPRISE_ABNORMAL_QUERY.toName());
                    List<CreditModifyStatus> modifyStatus0List = new ArrayList<>();
                    modifyStatus0List.add(modifyStatus0);
                    baseInfoModifyDetail0.setModifyStatus(modifyStatus0List);
                    if(null != baseInfoModifyDetail.getData() && null != baseInfoModifyDetail.getData().getAbnormalEntities()){
                        baseInfoModifyDetail0.setData(baseInfoModifyDetail.getData().getAbnormalEntities());
                    }else{
                        baseInfoModifyDetail0.setData(baseInfoModifyDetail.getModifyStatus().get(0).getMsg());
                    }
                    modifyDetailkList.add(baseInfoModifyDetail0);
                }
            }else{
                CreditModifyDetail baseInfoModifyDetail = this.queryModifyDetail(resultQryPrm);
                baseInfoModifyDetail.setProductCode(productCode);
                modifyDetailkList.add(baseInfoModifyDetail);
            }
        } catch (Exception e) {
            logger.error("buildRiskWarningProductQryModifyDetail handle error,{}", e);
        }

    }


}
