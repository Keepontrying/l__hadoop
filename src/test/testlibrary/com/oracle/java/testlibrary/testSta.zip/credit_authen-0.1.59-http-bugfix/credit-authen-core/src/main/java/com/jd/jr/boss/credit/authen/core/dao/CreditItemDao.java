package com.jd.jr.boss.credit.authen.core.dao;

import com.wangyin.boss.credit.admin.entity.CreditItem;
import com.wangyin.boss.credit.admin.entity.CreditItemSku;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by anmeng on 2017/3/28.
 */
@Repository
public interface CreditItemDao {

    /**
     * 查询标准产品列表,带sku列表
     * @param param
     * @return
     */
    List<CreditItem> selectItemAndSkuByParam(CreditItem param);

    /**
     * 查询标准产品列表,不带sku列表
     * @param param
     * @return
     */
    List<CreditItem> selectItemByParam(CreditItem param);

    /**
     * 查询标准产品套餐包
     * @param skuId
     * @return
     */
    CreditItemSku getCreditItemSkuById(Integer skuId);

    /**
     * 查询sku历史
     * @param skuId
     * @return
     */
    CreditItemSku getCreditItemSkuHisBySkuId(Integer skuId);

    /**
     *  查询sku信息
     * @param sku
     * @return
     */
    List<CreditItemSku> getCreditItemSkuByParam(CreditItemSku sku);

    /**
     * 查询已订购产品
     * @param param
     * @return
     */
    List<CreditItem> selectItemAndProdStratParam(CreditItem param);
}
