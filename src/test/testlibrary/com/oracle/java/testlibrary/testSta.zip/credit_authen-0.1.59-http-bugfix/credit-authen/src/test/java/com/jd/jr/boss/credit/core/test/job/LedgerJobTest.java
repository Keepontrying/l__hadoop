package com.jd.jr.boss.credit.core.test.job;

import com.jd.jr.boss.credit.authen.core.scheduler.LedgerJop;
import com.jd.jr.boss.credit.authen.core.scheduler.VipJop;
import com.wangyin.schedule.client.job.ScheduleContext;
import com.wangyin.schedule.httpclient.response.SimpleHttpResponse;
import com.wangyin.schedule.sdk.response.TaskGetResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author jiangbo
 * @since 2017/6/23
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:spring/spring-authen.xml" })

public class LedgerJobTest {
    @Autowired
    private LedgerJop ledgerJop;

    @Test
    public void testJob() throws Exception {
        SimpleHttpResponse response=SimpleHttpResponse.createInstance().setReturnCode(200).setResponseBody("{taskId:1}").build();
        ledgerJop.doJob(new ScheduleContext(new TaskGetResponse(response),null));
    }



}
