package com.jd.jr.boss.credit.authen.core.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.wangyin.boss.credit.admin.entity.CreditSummarize;

/**
 * 
 * <ul>
 * <li>1、开发日期：2018年1月15日</li>
 * <li>2、开发时间：上午10:01:38</li>
 * <li>3、作 者：zhanghui12</li>
 * <li>4、类型名称：CreditSummarizeDao</li>
 * <li>5、类型意图：征信产品调用汇总dao</li>
 * </ul>
 *
 */
@Repository
public interface CreditSummarizeDao {

	int saveSummarize(CreditSummarize creditSummarize);

	CreditSummarize querySummarize(CreditSummarize creditSummarize);

	int updateSummarize(CreditSummarize creditSummarize);

	List<CreditSummarize> querySummarizeList(String month);
}
