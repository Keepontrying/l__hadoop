package com.jd.jr.boss.credit.authen.core.beans.entity;

import com.github.pagehelper.Page;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by anmeng on 2018/1/19.
 */
public class DBPageBean<T> implements Serializable{
    private static final long serialVersionUID = 638683075396385513L;

    private long total;
    private List<T> rows;

    public DBPageBean(){

    }

    public DBPageBean(List<T> list){
        if (list instanceof Page) {
            Page page = (Page) list;
            this.total=page.getTotal();
            //直接返回result的时候jsf序列化有问题，只能重新包一个ArrayList
            this.rows=new ArrayList<T>(page.getResult());
        }else if(list instanceof Collection){
            this.rows = list;
        }
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    public List<T> getRows() {
        return rows;
    }

    public void setRows(List<T> rows) {
        this.rows = rows;
    }

    public CreditPage<T> getCreditPage(){
        CreditPage<T> creditPage = new CreditPage<T>();
        creditPage.setTotal(this.total);
        creditPage.setRows(this.rows);
        return creditPage;
    }
}
