package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.domain.common.entity.CreditCustomsBatch;
import com.jd.jr.boss.credit.domain.common.entity.CreditQueryBatch;
import com.jd.jr.boss.credit.domain.common.entity.StandardReportBatch;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.CustomsQueryParam;
import org.springframework.stereotype.Repository;

import java.util.List;

/** 
* @desciption : 海关批次dao数据接口类
* @author : liuwei55@jd.com
* @date ：2017年7月21日 下午5:30:23 
* @version 1.0 
* @return  */
@Repository
public interface CreditQueryBatchDao {

	/**
	 * 更新批量信息
	 * @param creditQueryBatch
	 * @return
	 */
    Integer updateQueryBatch(CreditQueryBatch creditQueryBatch);

	/**
	 * 查询海关批量
	 * @param customsQryPrm
	 * @return
	 */
    List<CreditCustomsBatch> queryCustomsBatchs(CustomsQueryParam customsQryPrm);
	/**
	 * 查询批量查询历史记录   分页
	 * @param queryParam
	 * @return
	 */
    List<CreditQueryBatch> queryBatchHistory(BatchQueryParam queryParam);
	/**
	 * 查询批量查询历史记录总记录数   分页
	 * @param queryParam
	 * @return
	 */
    Integer queryBatchHistoryCount(BatchQueryParam queryParam);

	/**
	 * 新增批量文件落库信息
	 * @param customsBatch
	 * @return
	 */
    Integer addBatchInfo(CreditQueryBatch customsBatch);

	/**
	 * 标准信用报告查询：同时返回文件id
	 * @return
	 */
	List<StandardReportBatch> queryStandardBatchHistory(BatchQueryParam queryParam);

	/**
	 * 修改标准报告
	 * @param standardReportBatch
	 * @return
	 */
    Integer updateStandardBatch(StandardReportBatch standardReportBatch);

	/**
	 * 根据批次号查询结果文件
	 * @param batchNo
	 * @return
	 */
    String queryResultFileId(String batchNo);
}
