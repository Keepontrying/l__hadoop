package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;

public class AccountQueryParam implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3794644634692255966L;
	/**
     * 商户号
     */
    private String merchantNo;
    /**
     * 清结算账户关系表类型：single-单笔，package-包量
     * single时，relation_id对应merchant表中merchant_id
     * package时，relation_id对应strategy表中strategy_id
     */
    private String chargeType;
    /**
     * 合同ID
     */
    private Integer contractId;
    /**
     * 关系表ID
     */
    private Integer relationtId;
    /**
     * 状态
     */
    private String accountStatus;
    

	public String getMerchantNo() {
		return merchantNo;
	}

	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public Integer getContractId() {
		return contractId;
	}

	public void setContractId(Integer contractId) {
		this.contractId = contractId;
	}

	public Integer getRelationtId() {
		return relationtId;
	}

	public void setRelationtId(Integer relationtId) {
		this.relationtId = relationtId;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

}
