package com.jd.jr.boss.credit.authen.core.facade.portal;

import java.util.List;

import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.authen.core.service.CreditCustomsService;
import com.jd.jr.boss.credit.authen.core.service.CreditInvoiceVerifyService;
import com.jd.jr.boss.credit.authen.core.service.CreditMiniService;
import com.jd.jr.boss.credit.authen.core.service.CreditQueryBatchService;
import com.jd.jr.boss.credit.authen.core.service.SignCodeInfoService;
import com.jd.jr.boss.credit.authen.core.service.SignCodeService;
import com.jd.jr.boss.credit.authen.core.task.CreditAsyncExcuteCommonService;
import com.jd.jr.boss.credit.domain.common.entity.CreditCustoms;
import com.jd.jr.boss.credit.domain.common.entity.CreditCustomsBatch;
import com.jd.jr.boss.credit.domain.common.entity.CreditQueryBatch;
import com.jd.jr.boss.credit.domain.common.entity.invoiceVerify.CreditInvoiceVerify;
import com.jd.jr.boss.credit.domain.common.entity.invoiceVerify.CreditInvoiceVerifyBatch;
import com.jd.jr.boss.credit.domain.common.entity.invoiceVerify.CreditInvoiceVerifyGoods;
import com.jd.jr.boss.credit.domain.common.entity.signcode.CreditSignCode;
import com.jd.jr.boss.credit.domain.common.entity.signcode.CreditSignCodeInfo;
import com.jd.jr.boss.credit.facade.authen.api.CreditQueryBatchFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.CustomsQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.InvoiceQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.MiniProjectQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.MiniSampleQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.SigncodeQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.MiniCommAreaComplDetailQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.MiniCommAreaComplQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniCommonArea;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniCommonAreaCompletion;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniCommonAreaDetail;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniCommonCompletion;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniProject;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniSampleBase;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniSampleBatch;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniSampleCall;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniSamplePic;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniSampleTape;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniSampleTouch;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniSampleVideo;


/**
 * @desciption : 批量查询facade接口实现类
 * @author : yangjinlin5@jd.com
 * @date ：2017年8月5日 下午3:06:12
 * @version 1.0
 * @return  */
@Service("creditQueryBatchFacade")
public class CreditQueryBatchFacadeImpl implements CreditQueryBatchFacade {

	@Autowired
	private CreditQueryBatchService queryBatchService;
	@Autowired
	private CreditCustomsService creditCustomsService;
	@Autowired
	private CreditInvoiceVerifyService invoiceVerifyService;
	@Autowired
	private SignCodeService signcodeService;
	@Autowired
	private SignCodeInfoService signCodeInfoService;
	@Autowired
	private CreditMiniService miniService;
	@Autowired
    private CreditAsyncExcuteCommonService asyncExcuteCommonService;

	@Override
	public CreditPage<CreditCustoms> queryCustomsHistoryDetails(CustomsQueryParam queryParam) {
		return creditCustomsService.queryCustomsHistoryDetails(queryParam);
	}

	@Override
	public int addBatchCustoms(CreditRequestParam<CreditCustomsBatch> requestParam) {
		return creditCustomsService.addBatchCustoms(requestParam);
	}
	@Override
	public Integer addBatchInvoice(CreditRequestParam<CreditInvoiceVerifyBatch> requestParam,String batchType) {
		return invoiceVerifyService.addBatchInvoice(requestParam,batchType);
	}

	@Override
	public CreditPage<CreditQueryBatch> queryBatchHistory(BatchQueryParam queryParam) {
		return queryBatchService.queryBatchHistory(queryParam);
	}

	@Override
	public CreditPage<CreditInvoiceVerify> queryInvoiceDetailData(InvoiceQueryParam queryParam) {
		return invoiceVerifyService.queryInvoiceDetailData(queryParam);
	}

	@Override
	public CreditPage<CreditInvoiceVerifyGoods> queryInvoiceGoodsData(InvoiceQueryParam queryParam) {
		return invoiceVerifyService.queryInvoiceGoodsData(queryParam);
	}

	@Override
	public CreditPage<CreditSignCode> querySigncodeBatchHistory(BatchQueryParam queryParam) {
		return signcodeService.querySigncodeBatchHistory(queryParam);
	}

	@Override
	public CreditPage<CreditSignCodeInfo> querySigncodeDetailData(SigncodeQueryParam queryPageParam) {
		return signCodeInfoService.querySigncodeDetailData(queryPageParam);
	}

	@Override
	public CreditPage<CreditMiniProject> queryMiniProject(MiniProjectQueryParam queryParam) {
		return miniService.queryMiniProject(queryParam);
	}

	@Override
	public CreditPage<CreditMiniSampleBase> queryMiniSample(MiniSampleQueryParam queryParam) {
		return miniService.queryMiniSample(queryParam);
	}

	@Override
	public Integer addMiniSampleSingleSubmit(CreditMiniSampleBase param) {
		return miniService.addMiniSampleSingleSubmit(param);
	}

	@Override
	public List<CreditMiniCommonCompletion> queryValidSampleCompletionList(MiniCommAreaComplQueryParam queryParam) {
		return miniService.queryValidSampleCompletionList(queryParam);
	}

	@Override
	public List<CreditMiniSampleBase> queryMiniCommonAreaComplByPrm(MiniSampleQueryParam queryParam) {
		return miniService.queryMiniCommonAreaComplByPrm(queryParam);
	}

	@Override
	public Integer saveBatchSample(CreditRequestParam<CreditMiniSampleBatch> addBatchSampleParam) {
		return miniService.saveBatchSample(addBatchSampleParam);
	}

	@Override
	public List<CreditMiniCommonArea> queryValidMiniAreaList(MiniCommAreaComplQueryParam queryParam) {
		return miniService.queryValidMiniAreaList(queryParam);
	}

	@Override
	public List<CreditMiniCommonArea> queryValidMiniAreaCompList(MiniCommAreaComplQueryParam queryParam) {
		return miniService.queryValidMiniAreaCompList(queryParam);
	}

	@Override
	public CreditResponseData<String> addMiniProject(CreditMiniProject creditMiniProject) {
		return miniService.addMiniProject(creditMiniProject);
	}
	@Override
	public CreditResponseData<String> modifyMiniProject(CreditMiniProject creditMiniProject) {
		return miniService.modifyMiniProject(creditMiniProject);
	}

	@Override
	public CreditMiniSampleBase querySampleDetailBaseById(MiniSampleQueryParam queryParam) {
		return miniService.querySampleDetailBaseById(queryParam);
	}

	@Override
	public List<CreditMiniSamplePic> querySampleDetailPicListById(MiniSampleQueryParam queryParam) {
		return miniService.querySampleDetailPicListById(queryParam);
	}

	@Override
	public CreditPage<CreditMiniSampleTape> querySampleDetailTapeListById(MiniSampleQueryParam queryParam) {
		return miniService.querySampleDetailTapeListById(queryParam);
	}

	@Override
	public List<CreditMiniSampleCall> querySampleDetailCallListById(MiniSampleQueryParam queryParam) {
		return miniService.querySampleDetailCallListById(queryParam);
	}

	@Override
	public boolean modifyMiniSampleBySampleIds(CreditMiniSampleBase sampleBase) {
		return miniService.modifyMiniSampleBySampleIds(sampleBase);
	}

	@Override
	public List<CreditMiniSampleTouch> querySampleDetailTouchListById(MiniSampleQueryParam queryParam) {
		return miniService.querySampleDetailTouchListById(queryParam);
	}

	@Override
	public List<CreditMiniSampleVideo> querySampleDetailVedioListById(MiniSampleQueryParam queryParam) {
		return miniService.querySampleDetailVedioListById(queryParam);
	}

	@Override
	public Integer addBatchInfo(CreditRequestParam<CreditQueryBatch> addElimNegReportPrm) {
		return queryBatchService.addBatchInfo(addElimNegReportPrm);
	}

	@Override
	public List<CreditMiniCommonArea> queryValidAreaListByPrm(
			MiniCommAreaComplQueryParam detailQueryPrm) {
		return miniService.queryValidAreaListByPrm(detailQueryPrm);
	}

	@Override
	public Integer addMiniAreas(CreditMiniCommonArea areaEntity) {
		return miniService.addMiniAreas(areaEntity);
	}

	@Override
	public Integer addMiniAreasCompletion(CreditMiniCommonAreaCompletion areaCompletionEntity) {
		return miniService.addMiniAreasCompletion(areaCompletionEntity);
	}

	@Override
	public List<CreditMiniCommonAreaDetail> queryValidMiniAreaDetailList(
			MiniCommAreaComplDetailQueryParam areaComplDetailQryPrm) {
		return miniService.queryValidMiniAreaDetailList(areaComplDetailQryPrm);
	}

	@Override
	public boolean exportSamplesZipFiles(MiniSampleQueryParam queryParam, String emailReal) {
		boolean resultFlag = true;
		asyncExcuteCommonService.exportSamplesZipFiles(queryParam, emailReal);
		return resultFlag;
	}
}
