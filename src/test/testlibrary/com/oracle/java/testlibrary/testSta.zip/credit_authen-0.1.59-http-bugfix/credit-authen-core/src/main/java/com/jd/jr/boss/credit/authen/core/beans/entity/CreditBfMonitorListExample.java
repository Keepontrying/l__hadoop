package com.jd.jr.boss.credit.authen.core.beans.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CreditBfMonitorListExample implements Serializable {
    private static final long serialVersionUID = 1456251599811248489L;
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CreditBfMonitorListExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andSystemIdIsNull() {
            addCriterion("system_id is null");
            return (Criteria) this;
        }

        public Criteria andSystemIdIsNotNull() {
            addCriterion("system_id is not null");
            return (Criteria) this;
        }

        public Criteria andSystemIdEqualTo(String value) {
            addCriterion("system_id =", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdNotEqualTo(String value) {
            addCriterion("system_id <>", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdGreaterThan(String value) {
            addCriterion("system_id >", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdGreaterThanOrEqualTo(String value) {
            addCriterion("system_id >=", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdLessThan(String value) {
            addCriterion("system_id <", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdLessThanOrEqualTo(String value) {
            addCriterion("system_id <=", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdLike(String value) {
            addCriterion("system_id like", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdNotLike(String value) {
            addCriterion("system_id not like", value, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdIn(List<String> values) {
            addCriterion("system_id in", values, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdNotIn(List<String> values) {
            addCriterion("system_id not in", values, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdBetween(String value1, String value2) {
            addCriterion("system_id between", value1, value2, "systemId");
            return (Criteria) this;
        }

        public Criteria andSystemIdNotBetween(String value1, String value2) {
            addCriterion("system_id not between", value1, value2, "systemId");
            return (Criteria) this;
        }

        public Criteria andEntpriseIdIsNull() {
            addCriterion("entprise_id is null");
            return (Criteria) this;
        }

        public Criteria andEntpriseIdIsNotNull() {
            addCriterion("entprise_id is not null");
            return (Criteria) this;
        }

        public Criteria andEntpriseIdEqualTo(Integer value) {
            addCriterion("entprise_id =", value, "entpriseId");
            return (Criteria) this;
        }

        public Criteria andEntpriseIdNotEqualTo(Integer value) {
            addCriterion("entprise_id <>", value, "entpriseId");
            return (Criteria) this;
        }

        public Criteria andEntpriseIdGreaterThan(Integer value) {
            addCriterion("entprise_id >", value, "entpriseId");
            return (Criteria) this;
        }

        public Criteria andEntpriseIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("entprise_id >=", value, "entpriseId");
            return (Criteria) this;
        }

        public Criteria andEntpriseIdLessThan(Integer value) {
            addCriterion("entprise_id <", value, "entpriseId");
            return (Criteria) this;
        }

        public Criteria andEntpriseIdLessThanOrEqualTo(Integer value) {
            addCriterion("entprise_id <=", value, "entpriseId");
            return (Criteria) this;
        }

        public Criteria andEntpriseIdIn(List<Integer> values) {
            addCriterion("entprise_id in", values, "entpriseId");
            return (Criteria) this;
        }

        public Criteria andEntpriseIdNotIn(List<Integer> values) {
            addCriterion("entprise_id not in", values, "entpriseId");
            return (Criteria) this;
        }

        public Criteria andEntpriseIdBetween(Integer value1, Integer value2) {
            addCriterion("entprise_id between", value1, value2, "entpriseId");
            return (Criteria) this;
        }

        public Criteria andEntpriseIdNotBetween(Integer value1, Integer value2) {
            addCriterion("entprise_id not between", value1, value2, "entpriseId");
            return (Criteria) this;
        }

        public Criteria andCreatedDateIsNull() {
            addCriterion("created_date is null");
            return (Criteria) this;
        }

        public Criteria andCreatedDateIsNotNull() {
            addCriterion("created_date is not null");
            return (Criteria) this;
        }

        public Criteria andCreatedDateEqualTo(Date value) {
            addCriterion("created_date =", value, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateNotEqualTo(Date value) {
            addCriterion("created_date <>", value, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateGreaterThan(Date value) {
            addCriterion("created_date >", value, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateGreaterThanOrEqualTo(Date value) {
            addCriterion("created_date >=", value, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateLessThan(Date value) {
            addCriterion("created_date <", value, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateLessThanOrEqualTo(Date value) {
            addCriterion("created_date <=", value, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateIn(List<Date> values) {
            addCriterion("created_date in", values, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateNotIn(List<Date> values) {
            addCriterion("created_date not in", values, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateBetween(Date value1, Date value2) {
            addCriterion("created_date between", value1, value2, "createdDate");
            return (Criteria) this;
        }

        public Criteria andCreatedDateNotBetween(Date value1, Date value2) {
            addCriterion("created_date not between", value1, value2, "createdDate");
            return (Criteria) this;
        }

        public Criteria andListMonitoredIsNull() {
            addCriterion("list_monitored is null");
            return (Criteria) this;
        }

        public Criteria andListMonitoredIsNotNull() {
            addCriterion("list_monitored is not null");
            return (Criteria) this;
        }

        public Criteria andListMonitoredEqualTo(String value) {
            addCriterion("list_monitored =", value, "listMonitored");
            return (Criteria) this;
        }

        public Criteria andListMonitoredNotEqualTo(String value) {
            addCriterion("list_monitored <>", value, "listMonitored");
            return (Criteria) this;
        }

        public Criteria andListMonitoredGreaterThan(String value) {
            addCriterion("list_monitored >", value, "listMonitored");
            return (Criteria) this;
        }

        public Criteria andListMonitoredGreaterThanOrEqualTo(String value) {
            addCriterion("list_monitored >=", value, "listMonitored");
            return (Criteria) this;
        }

        public Criteria andListMonitoredLessThan(String value) {
            addCriterion("list_monitored <", value, "listMonitored");
            return (Criteria) this;
        }

        public Criteria andListMonitoredLessThanOrEqualTo(String value) {
            addCriterion("list_monitored <=", value, "listMonitored");
            return (Criteria) this;
        }

        public Criteria andListMonitoredLike(String value) {
            addCriterion("list_monitored like", value, "listMonitored");
            return (Criteria) this;
        }

        public Criteria andListMonitoredNotLike(String value) {
            addCriterion("list_monitored not like", value, "listMonitored");
            return (Criteria) this;
        }

        public Criteria andListMonitoredIn(List<String> values) {
            addCriterion("list_monitored in", values, "listMonitored");
            return (Criteria) this;
        }

        public Criteria andListMonitoredNotIn(List<String> values) {
            addCriterion("list_monitored not in", values, "listMonitored");
            return (Criteria) this;
        }

        public Criteria andListMonitoredBetween(String value1, String value2) {
            addCriterion("list_monitored between", value1, value2, "listMonitored");
            return (Criteria) this;
        }

        public Criteria andListMonitoredNotBetween(String value1, String value2) {
            addCriterion("list_monitored not between", value1, value2, "listMonitored");
            return (Criteria) this;
        }

        public Criteria andListBeginDateIsNull() {
            addCriterion("list_begin_date is null");
            return (Criteria) this;
        }

        public Criteria andListBeginDateIsNotNull() {
            addCriterion("list_begin_date is not null");
            return (Criteria) this;
        }

        public Criteria andListBeginDateEqualTo(Date value) {
            addCriterion("list_begin_date =", value, "listBeginDate");
            return (Criteria) this;
        }

        public Criteria andListBeginDateNotEqualTo(Date value) {
            addCriterion("list_begin_date <>", value, "listBeginDate");
            return (Criteria) this;
        }

        public Criteria andListBeginDateGreaterThan(Date value) {
            addCriterion("list_begin_date >", value, "listBeginDate");
            return (Criteria) this;
        }

        public Criteria andListBeginDateGreaterThanOrEqualTo(Date value) {
            addCriterion("list_begin_date >=", value, "listBeginDate");
            return (Criteria) this;
        }

        public Criteria andListBeginDateLessThan(Date value) {
            addCriterion("list_begin_date <", value, "listBeginDate");
            return (Criteria) this;
        }

        public Criteria andListBeginDateLessThanOrEqualTo(Date value) {
            addCriterion("list_begin_date <=", value, "listBeginDate");
            return (Criteria) this;
        }

        public Criteria andListBeginDateIn(List<Date> values) {
            addCriterion("list_begin_date in", values, "listBeginDate");
            return (Criteria) this;
        }

        public Criteria andListBeginDateNotIn(List<Date> values) {
            addCriterion("list_begin_date not in", values, "listBeginDate");
            return (Criteria) this;
        }

        public Criteria andListBeginDateBetween(Date value1, Date value2) {
            addCriterion("list_begin_date between", value1, value2, "listBeginDate");
            return (Criteria) this;
        }

        public Criteria andListBeginDateNotBetween(Date value1, Date value2) {
            addCriterion("list_begin_date not between", value1, value2, "listBeginDate");
            return (Criteria) this;
        }

        public Criteria andListEndDateIsNull() {
            addCriterion("list_end_date is null");
            return (Criteria) this;
        }

        public Criteria andListEndDateIsNotNull() {
            addCriterion("list_end_date is not null");
            return (Criteria) this;
        }

        public Criteria andListEndDateEqualTo(Date value) {
            addCriterion("list_end_date =", value, "listEndDate");
            return (Criteria) this;
        }

        public Criteria andListEndDateNotEqualTo(Date value) {
            addCriterion("list_end_date <>", value, "listEndDate");
            return (Criteria) this;
        }

        public Criteria andListEndDateGreaterThan(Date value) {
            addCriterion("list_end_date >", value, "listEndDate");
            return (Criteria) this;
        }

        public Criteria andListEndDateGreaterThanOrEqualTo(Date value) {
            addCriterion("list_end_date >=", value, "listEndDate");
            return (Criteria) this;
        }

        public Criteria andListEndDateLessThan(Date value) {
            addCriterion("list_end_date <", value, "listEndDate");
            return (Criteria) this;
        }

        public Criteria andListEndDateLessThanOrEqualTo(Date value) {
            addCriterion("list_end_date <=", value, "listEndDate");
            return (Criteria) this;
        }

        public Criteria andListEndDateIn(List<Date> values) {
            addCriterion("list_end_date in", values, "listEndDate");
            return (Criteria) this;
        }

        public Criteria andListEndDateNotIn(List<Date> values) {
            addCriterion("list_end_date not in", values, "listEndDate");
            return (Criteria) this;
        }

        public Criteria andListEndDateBetween(Date value1, Date value2) {
            addCriterion("list_end_date between", value1, value2, "listEndDate");
            return (Criteria) this;
        }

        public Criteria andListEndDateNotBetween(Date value1, Date value2) {
            addCriterion("list_end_date not between", value1, value2, "listEndDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateIsNull() {
            addCriterion("modified_date is null");
            return (Criteria) this;
        }

        public Criteria andModifiedDateIsNotNull() {
            addCriterion("modified_date is not null");
            return (Criteria) this;
        }

        public Criteria andModifiedDateEqualTo(Date value) {
            addCriterion("modified_date =", value, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateNotEqualTo(Date value) {
            addCriterion("modified_date <>", value, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateGreaterThan(Date value) {
            addCriterion("modified_date >", value, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateGreaterThanOrEqualTo(Date value) {
            addCriterion("modified_date >=", value, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateLessThan(Date value) {
            addCriterion("modified_date <", value, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateLessThanOrEqualTo(Date value) {
            addCriterion("modified_date <=", value, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateIn(List<Date> values) {
            addCriterion("modified_date in", values, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateNotIn(List<Date> values) {
            addCriterion("modified_date not in", values, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateBetween(Date value1, Date value2) {
            addCriterion("modified_date between", value1, value2, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andModifiedDateNotBetween(Date value1, Date value2) {
            addCriterion("modified_date not between", value1, value2, "modifiedDate");
            return (Criteria) this;
        }

        public Criteria andIsPushedIsNull() {
            addCriterion("is_pushed is null");
            return (Criteria) this;
        }

        public Criteria andIsPushedIsNotNull() {
            addCriterion("is_pushed is not null");
            return (Criteria) this;
        }

        public Criteria andIsPushedEqualTo(String value) {
            addCriterion("is_pushed =", value, "isPushed");
            return (Criteria) this;
        }

        public Criteria andIsPushedNotEqualTo(String value) {
            addCriterion("is_pushed <>", value, "isPushed");
            return (Criteria) this;
        }

        public Criteria andIsPushedGreaterThan(String value) {
            addCriterion("is_pushed >", value, "isPushed");
            return (Criteria) this;
        }

        public Criteria andIsPushedGreaterThanOrEqualTo(String value) {
            addCriterion("is_pushed >=", value, "isPushed");
            return (Criteria) this;
        }

        public Criteria andIsPushedLessThan(String value) {
            addCriterion("is_pushed <", value, "isPushed");
            return (Criteria) this;
        }

        public Criteria andIsPushedLessThanOrEqualTo(String value) {
            addCriterion("is_pushed <=", value, "isPushed");
            return (Criteria) this;
        }

        public Criteria andIsPushedLike(String value) {
            addCriterion("is_pushed like", value, "isPushed");
            return (Criteria) this;
        }

        public Criteria andIsPushedNotLike(String value) {
            addCriterion("is_pushed not like", value, "isPushed");
            return (Criteria) this;
        }

        public Criteria andIsPushedIn(List<String> values) {
            addCriterion("is_pushed in", values, "isPushed");
            return (Criteria) this;
        }

        public Criteria andIsPushedNotIn(List<String> values) {
            addCriterion("is_pushed not in", values, "isPushed");
            return (Criteria) this;
        }

        public Criteria andIsPushedBetween(String value1, String value2) {
            addCriterion("is_pushed between", value1, value2, "isPushed");
            return (Criteria) this;
        }

        public Criteria andIsPushedNotBetween(String value1, String value2) {
            addCriterion("is_pushed not between", value1, value2, "isPushed");
            return (Criteria) this;
        }

        public Criteria andPushDateIsNull() {
            addCriterion("push_date is null");
            return (Criteria) this;
        }

        public Criteria andPushDateIsNotNull() {
            addCriterion("push_date is not null");
            return (Criteria) this;
        }

        public Criteria andPushDateEqualTo(Date value) {
            addCriterion("push_date =", value, "pushDate");
            return (Criteria) this;
        }

        public Criteria andPushDateNotEqualTo(Date value) {
            addCriterion("push_date <>", value, "pushDate");
            return (Criteria) this;
        }

        public Criteria andPushDateGreaterThan(Date value) {
            addCriterion("push_date >", value, "pushDate");
            return (Criteria) this;
        }

        public Criteria andPushDateGreaterThanOrEqualTo(Date value) {
            addCriterion("push_date >=", value, "pushDate");
            return (Criteria) this;
        }

        public Criteria andPushDateLessThan(Date value) {
            addCriterion("push_date <", value, "pushDate");
            return (Criteria) this;
        }

        public Criteria andPushDateLessThanOrEqualTo(Date value) {
            addCriterion("push_date <=", value, "pushDate");
            return (Criteria) this;
        }

        public Criteria andPushDateIn(List<Date> values) {
            addCriterion("push_date in", values, "pushDate");
            return (Criteria) this;
        }

        public Criteria andPushDateNotIn(List<Date> values) {
            addCriterion("push_date not in", values, "pushDate");
            return (Criteria) this;
        }

        public Criteria andPushDateBetween(Date value1, Date value2) {
            addCriterion("push_date between", value1, value2, "pushDate");
            return (Criteria) this;
        }

        public Criteria andPushDateNotBetween(Date value1, Date value2) {
            addCriterion("push_date not between", value1, value2, "pushDate");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}