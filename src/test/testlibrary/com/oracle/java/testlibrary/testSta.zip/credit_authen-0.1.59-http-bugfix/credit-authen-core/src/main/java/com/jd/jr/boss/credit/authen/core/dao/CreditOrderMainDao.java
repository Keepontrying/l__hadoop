package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.request.OrderMainQueryParam;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrderMain;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

/**
 * Created by anmeng on 2017/3/22.
 */
@Repository
public interface CreditOrderMainDao {
    /**
     * 查询主订单列表
     * @param queryParam
     * @return
     */
    List<CreditOrderMain> query(OrderMainQueryParam queryParam);

    /**
     * 查询满足条件的订单数量
     * @param queryParam
     * @return
     */
    Integer queryCount(OrderMainQueryParam queryParam);

    /**
     * 创建主订单
     * @param creditOrderMain
     */
    void create(CreditOrderMain creditOrderMain);

    /**
     * 更新主订单支付状态
     * @param creditOrderMain
     */
    void updateOrderMainPayStatus(CreditOrderMain creditOrderMain);

    /**
     *查询订单详情
     * @param orderMainId
     */
    CreditOrderMain querySingleOrder(Integer orderMainId);

    /**
     * 批量更新失效的订单
     * @param expiredTime
     * @return
     */
    List<Integer> queryExpiredOrder(Date expiredTime);

    /**
     * 更新订单报账状态
     * @param orderMain
     */
    void updateOrderLedgerStatus(CreditOrderMain orderMain);

}
