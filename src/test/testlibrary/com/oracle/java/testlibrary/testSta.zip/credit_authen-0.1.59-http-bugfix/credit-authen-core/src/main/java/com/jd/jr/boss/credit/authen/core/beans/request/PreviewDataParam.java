package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;
import java.util.List;

public class PreviewDataParam implements Serializable {
	private static final long serialVersionUID = 8862622557676204783L;
	private List<String> entNameList;
	private String merchantNo;
	private String productId;
	public List<String> getEntNameList() {
		return entNameList;
	}
	public void setEntNameList(List<String> entNameList) {
		this.entNameList = entNameList;
	}
	public String getMerchantNo() {
		return merchantNo;
	}
	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
}
