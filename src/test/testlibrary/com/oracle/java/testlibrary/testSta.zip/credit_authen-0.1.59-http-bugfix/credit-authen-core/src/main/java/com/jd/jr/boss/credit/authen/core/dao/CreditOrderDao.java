package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.request.OrderQueryParam;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrderMini;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrderStandardReport;
import com.wangyin.boss.credit.admin.entity.CreditContract;

import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by anmeng on 2017/1/4.
 */
@Repository
public interface CreditOrderDao {
    /**
     * 新增订购信息
     * @param creditOrder
     * @return
     */
    Integer insertCreditOrder(CreditOrder creditOrder);

    /**
     * 更新订购的有效信息
     * 更新status和validTime字段
     * @param creditOrder
     */
    void updateCreditValidity(CreditOrder creditOrder);

    /**
     * 更新订单信息
     * @param creditOrder
     */
    void updateCreditOrder(CreditOrder creditOrder);

    /**
     * 查询订购信息
     * @param queryParam
     * @return
     */
    List<CreditOrder> queryCreditOrder(OrderQueryParam queryParam);

    /**
     * 按照主键查询订购信息
     * @param queryParam
     * @return
     */
    CreditOrder queryCreditOrderById(OrderQueryParam queryParam);

    /**
     * 按照计费策略更新订购有效信息
     * @param creditOrder
     */
    void updateCreditValidityByStrategy(CreditOrder creditOrder);

    /**
     * 按照主订单更新订购有效信息
     * @param creditOrder
     */
    void updateCreditValidityByMainOrder(CreditOrder creditOrder);

    /**
     * 查询订单及产品信息
     * @param queryParam
     * @return
     */
    List<CreditOrder> queryCreditOrderWithProduct(OrderQueryParam queryParam);

    /**
     * 查询订单及产品信息数量
     * @param queryParam
     * @return
     */
    Integer queryCreditOrderWithProductCount(OrderQueryParam queryParam);

    /**
     * 查询同一产品的订单
     * @param orderId
     * @return
     */
    List<CreditOrder> queryTheSameProdOrder(Integer orderId);

    /**
     * 查询合同下的订单信息
     * @param orderQueryPrm 
     * @return
     */
    List<CreditOrder> queryContractOrder(OrderQueryParam orderQueryPrm);

	/**
	 * 根据订单信息查询合同信息 
	 * @param orderQueryPrm
	 * @return
	 */
    List<CreditContract> queryContractByOrderInfo(OrderQueryParam orderQueryPrm);

	/**
	 * 为特殊产品 mini尽调 创建特殊订单附属信息
	 * @param orderMini
	 * @return
	 */
    Integer insertCreditOrderMini(CreditOrderMini orderMini);

    /**
     * 为特殊产品 格兰德标准报告 创建特殊订单附属信息
     * @param orderReport
     * @return
     */
    Integer insertCreditOrderStandardReport(CreditOrderStandardReport orderReport);

}
