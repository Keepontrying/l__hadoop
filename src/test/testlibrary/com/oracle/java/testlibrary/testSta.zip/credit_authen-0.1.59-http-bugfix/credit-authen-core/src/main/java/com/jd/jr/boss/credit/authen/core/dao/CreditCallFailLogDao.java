package com.jd.jr.boss.credit.authen.core.dao;

import com.wangyin.boss.credit.admin.entity.CreditCallFailLog;
import org.springframework.stereotype.Repository;

/**
 * 排污api失败记录表
 * @author liuwei
 * @since 2017.03.29
 */
@Repository
public interface CreditCallFailLogDao {
	/**
	 * 记录排污
	 * @return
	 */
	boolean insertCallFailLog(CreditCallFailLog log);

}