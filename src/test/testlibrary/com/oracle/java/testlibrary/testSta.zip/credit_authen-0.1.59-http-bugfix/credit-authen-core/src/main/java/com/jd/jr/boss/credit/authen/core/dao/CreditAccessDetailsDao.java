package com.jd.jr.boss.credit.authen.core.dao;

import java.util.List;

import com.jd.jr.boss.credit.authen.core.beans.request.AccessDetailsQueryParamExtend;
import com.jd.jr.boss.credit.facade.authen.beans.param.AccessDetailQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditAccessDetails;
import org.springframework.stereotype.Repository;

import com.jd.jr.boss.credit.authen.core.beans.entity.AccessDetailsEntity;
import com.jd.jr.boss.credit.authen.core.beans.request.AccessDetailsQueryParam;

/**
 *  业务详情管理
 *
 * @author: tangmingbo
 * @since: 16-7-04 上午11:26
 * @version: 1.0.0
 */
@Repository
public interface CreditAccessDetailsDao {
    /**
     * 汇总交易详情数据
     * @param accessDetailsQueryParam
     * @return
     * @throws Exception
     */
    List<AccessDetailsEntity> querySumAccessDetails(AccessDetailsQueryParam accessDetailsQueryParam) throws Exception;

    /**
     * 查询访问详单列表
     * @return
     */
    List<CreditAccessDetails> queryAccessDetails(AccessDetailsQueryParamExtend accessDetailsQueryParam);

    /**
     * 查询访问详单列表数量
     * @param accessDetailsQueryParam
     * @return
     */
    Integer queryAccessDetailCount(AccessDetailsQueryParamExtend accessDetailsQueryParam);

	/**
	 * 企业征信门户查询征信产品历史消费记录---分页
	 * @param queryPageParam
	 * @return
	 */
    List<CreditAccessDetails> query(AccessDetailQueryParam queryPageParam);

	/**
	 * 企业征信门户查询征信产品历史消费记录总记录数---分页
	 * @param queryPageParam
	 * @return
	 */
    Integer queryCount(AccessDetailQueryParam queryPageParam);

}
