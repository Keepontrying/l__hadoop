package com.jd.jr.boss.credit.authen.core.beans.entity.carLoan;

import java.io.Serializable;

/**
 * 企业信息
 * @author tangmingbo
 *
 */
public class StatisticDesc implements Serializable{
	private static final long serialVersionUID = 2936531965994611042L;
	//法人变更时间
	private String frAlterDate;
	//法人变更前内容
	private String frAlterBf;
	//法人变更后内容
	private String frAlterAfter;

	//注册资本变更时间
	private String regCapAlterDate;
	//yes：减资  no：增资
	private String isReduce;
	private String regCapAlterBef;
	private String regCapAlterAfter;
	//股东变更时间
	private String shareAlterDate;
	private String shareAlterBef;
	private String shareAlterAfter;
	//企业名称变更时间
	private String entNameAlterDate;
	private String entNameAlterBef;
	private String entNameAlterAfter;
	//经营地址变更时间
	private String domAlterDate;
	private String domAlterBef;
	private String domAlterAfter;
	//经营范围变更时间
	private String opScopeAlterDate;
	private String opScopeAlterBef;
	private String opScopeAlterAfter;
	//经营风险条数
	private int operateRiskNum;
	//列入经营异常条数
	private int abnormalNum;
	//行政处罚时间
	private String punishmentDate;
	//行政处罚原因
	private String punishmentReason;
	//行政处罚内容
	private String punishmentContent;
	//行政处罚条数
	private int punishmentNum;
	//动产抵押条数
	private int mortgageNum;
	//股权质押 条数
	private int equityNum;
	//严重违法条数
	private int illegalNum;
	//抽查检查条数
	private int checkInfoNum;
	//企业失信条数
	private int punishBreakNum;
	//企业失信未履行条数
	private int unPunishBreakNum;
	//被执行执行数量
	private int punishedNum;
	 //被执行执行标的金额
	private String punishedAmount;
	//法院裁判数量
	private int lawsuitNum;
	//重大税收违法
	private int majorTaxNum;
	//个人失信描述
	private String perPunishbreakMsg;
	//个人被执行描述
	private String perPunishedMsg;
	//个人涉诉说明
	private String perLasuitMsg;
	//个人黑名单说明
	private String perBlackListMsg;
	//个人多头借贷说明
	private String perLoanInfoMsg;

	public String getFrAlterDate() {
		return frAlterDate;
	}

	public void setFrAlterDate(String frAlterDate) {
		this.frAlterDate = frAlterDate;
	}

	public String getFrAlterBf() {
		return frAlterBf;
	}

	public void setFrAlterBf(String frAlterBf) {
		this.frAlterBf = frAlterBf;
	}

	public String getFrAlterAfter() {
		return frAlterAfter;
	}

	public void setFrAlterAfter(String frAlterAfter) {
		this.frAlterAfter = frAlterAfter;
	}

	public String getRegCapAlterDate() {
		return regCapAlterDate;
	}

	public void setRegCapAlterDate(String regCapAlterDate) {
		this.regCapAlterDate = regCapAlterDate;
	}

	public String getIsReduce() {
		return isReduce;
	}

	public void setIsReduce(String isReduce) {
		this.isReduce = isReduce;
	}

	public String getRegCapAlterBef() {
		return regCapAlterBef;
	}

	public void setRegCapAlterBef(String regCapAlterBef) {
		this.regCapAlterBef = regCapAlterBef;
	}

	public String getRegCapAlterAfter() {
		return regCapAlterAfter;
	}

	public void setRegCapAlterAfter(String regCapAlterAfter) {
		this.regCapAlterAfter = regCapAlterAfter;
	}

	public String getShareAlterDate() {
		return shareAlterDate;
	}

	public void setShareAlterDate(String shareAlterDate) {
		this.shareAlterDate = shareAlterDate;
	}

	public String getShareAlterBef() {
		return shareAlterBef;
	}

	public void setShareAlterBef(String shareAlterBef) {
		this.shareAlterBef = shareAlterBef;
	}

	public String getShareAlterAfter() {
		return shareAlterAfter;
	}

	public void setShareAlterAfter(String shareAlterAfter) {
		this.shareAlterAfter = shareAlterAfter;
	}

	public String getEntNameAlterDate() {
		return entNameAlterDate;
	}

	public void setEntNameAlterDate(String entNameAlterDate) {
		this.entNameAlterDate = entNameAlterDate;
	}

	public String getEntNameAlterBef() {
		return entNameAlterBef;
	}

	public void setEntNameAlterBef(String entNameAlterBef) {
		this.entNameAlterBef = entNameAlterBef;
	}

	public String getEntNameAlterAfter() {
		return entNameAlterAfter;
	}

	public void setEntNameAlterAfter(String entNameAlterAfter) {
		this.entNameAlterAfter = entNameAlterAfter;
	}

	public String getDomAlterDate() {
		return domAlterDate;
	}

	public void setDomAlterDate(String domAlterDate) {
		this.domAlterDate = domAlterDate;
	}

	public String getDomAlterBef() {
		return domAlterBef;
	}

	public void setDomAlterBef(String domAlterBef) {
		this.domAlterBef = domAlterBef;
	}

	public String getDomAlterAfter() {
		return domAlterAfter;
	}

	public void setDomAlterAfter(String domAlterAfter) {
		this.domAlterAfter = domAlterAfter;
	}

	public String getOpScopeAlterDate() {
		return opScopeAlterDate;
	}

	public void setOpScopeAlterDate(String opScopeAlterDate) {
		this.opScopeAlterDate = opScopeAlterDate;
	}

	public String getOpScopeAlterBef() {
		return opScopeAlterBef;
	}

	public void setOpScopeAlterBef(String opScopeAlterBef) {
		this.opScopeAlterBef = opScopeAlterBef;
	}

	public String getOpScopeAlterAfter() {
		return opScopeAlterAfter;
	}

	public void setOpScopeAlterAfter(String opScopeAlterAfter) {
		this.opScopeAlterAfter = opScopeAlterAfter;
	}

    public int getOperateRiskNum() {
        return operateRiskNum;
    }

    public void setOperateRiskNum(int operateRiskNum) {
        this.operateRiskNum = operateRiskNum;
    }

    public int getAbnormalNum() {
		return abnormalNum;
	}

	public void setAbnormalNum(int abnormalNum) {
		this.abnormalNum = abnormalNum;
	}

	public String getPunishmentDate() {
		return punishmentDate;
	}

	public void setPunishmentDate(String punishmentDate) {
		this.punishmentDate = punishmentDate;
	}

	public String getPunishmentReason() {
		return punishmentReason;
	}

	public void setPunishmentReason(String punishmentReason) {
		this.punishmentReason = punishmentReason;
	}

	public String getPunishmentContent() {
		return punishmentContent;
	}

	public void setPunishmentContent(String punishmentContent) {
		this.punishmentContent = punishmentContent;
	}

	public int getPunishmentNum() {
		return punishmentNum;
	}

	public void setPunishmentNum(int punishmentNum) {
		this.punishmentNum = punishmentNum;
	}

	public int getMortgageNum() {
		return mortgageNum;
	}

	public void setMortgageNum(int mortgageNum) {
		this.mortgageNum = mortgageNum;
	}


	public int getEquityNum() {
		return equityNum;
	}

	public void setEquityNum(int equityNum) {
		this.equityNum = equityNum;
	}


	public int getIllegalNum() {
		return illegalNum;
	}

	public void setIllegalNum(int illegalNum) {
		this.illegalNum = illegalNum;
	}

	public int getCheckInfoNum() {
		return checkInfoNum;
	}

	public void setCheckInfoNum(int checkInfoNum) {
		this.checkInfoNum = checkInfoNum;
	}

	public int getPunishBreakNum() {
		return punishBreakNum;
	}

	public void setPunishBreakNum(int punishBreakNum) {
		this.punishBreakNum = punishBreakNum;
	}

	public int getUnPunishBreakNum() {
		return unPunishBreakNum;
	}

	public void setUnPunishBreakNum(int unPunishBreakNum) {
		this.unPunishBreakNum = unPunishBreakNum;
	}

	public int getPunishedNum() {
		return punishedNum;
	}

	public void setPunishedNum(int punishedNum) {
		this.punishedNum = punishedNum;
	}

	public String getPunishedAmount() {
		return punishedAmount;
	}

	public void setPunishedAmount(String punishedAmount) {
		this.punishedAmount = punishedAmount;
	}

	public int getLawsuitNum() {
		return lawsuitNum;
	}

	public void setLawsuitNum(int lawsuitNum) {
		this.lawsuitNum = lawsuitNum;
	}

	public int getMajorTaxNum() {
		return majorTaxNum;
	}

	public void setMajorTaxNum(int majorTaxNum) {
		this.majorTaxNum = majorTaxNum;
	}

	public String getPerPunishbreakMsg() {
		return perPunishbreakMsg;
	}

	public void setPerPunishbreakMsg(String perPunishbreakMsg) {
		this.perPunishbreakMsg = perPunishbreakMsg;
	}

	public String getPerPunishedMsg() {
		return perPunishedMsg;
	}

	public void setPerPunishedMsg(String perPunishedMsg) {
		this.perPunishedMsg = perPunishedMsg;
	}

	public String getPerLasuitMsg() {
		return perLasuitMsg;
	}

	public void setPerLasuitMsg(String perLasuitMsg) {
		this.perLasuitMsg = perLasuitMsg;
	}

	public String getPerBlackListMsg() {
		return perBlackListMsg;
	}

	public void setPerBlackListMsg(String perBlackListMsg) {
		this.perBlackListMsg = perBlackListMsg;
	}

	public String getPerLoanInfoMsg() {
		return perLoanInfoMsg;
	}

	public void setPerLoanInfoMsg(String perLoanInfoMsg) {
		this.perLoanInfoMsg = perLoanInfoMsg;
	}
}
