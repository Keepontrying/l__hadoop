package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.domain.common.entity.CreditQueryBatch;
import com.jd.jr.boss.credit.facade.authen.beans.param.CarLoanReportQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditReportQueryCarloan;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Description:
 * User: yangjinlin@jd.com
 * Date: 2018/6/12 21:45
 * Version: 1.0
 */
@Repository
public interface CreditCarLoanReportDao {

    /**
     *多条件查询车道报告查询任务历史记录List
     * @param queryParam
     * @return
     */
    List<CreditReportQueryCarloan> queryCarLoanListByPrm(CarLoanReportQueryParam queryParam);

    /**
     * 多条件查询车贷历史提交任务  总数
     * @param queryParam
     * @return
     */
    Integer queryCarLoanByPrmCount(CarLoanReportQueryParam queryParam);

    /**
     * 新增车道报告查询任务
     * @param carLoanReport
     * @return
     */
    Integer addCarLoanQueryTask(CreditReportQueryCarloan carLoanReport);

    /**
     * 根据主键进行更新
     * @param carLoan
     * @return
     */
    int updateByPrimaryKeySelective(CreditReportQueryCarloan carLoan);

    /**
     * 批量新增车贷信息
     * @param carLoanList
     */
    void addBatchCarloan(List<CreditReportQueryCarloan> carLoanList);
}
