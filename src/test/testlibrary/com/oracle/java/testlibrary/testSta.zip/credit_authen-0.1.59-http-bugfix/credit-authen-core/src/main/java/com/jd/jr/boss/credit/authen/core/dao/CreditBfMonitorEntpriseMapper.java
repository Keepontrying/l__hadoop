package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.entity.CreditBfMonitorEntprise;
import com.jd.jr.boss.credit.authen.core.beans.entity.CreditBfMonitorEntpriseExample;
import com.jd.jr.boss.credit.facade.channel.enterprise.beans.response.EntBasicInfo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CreditBfMonitorEntpriseMapper {
    long countByExample(CreditBfMonitorEntpriseExample example);

    int deleteByExample(CreditBfMonitorEntpriseExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CreditBfMonitorEntprise record);

    int insertSelective(CreditBfMonitorEntprise record);

    List<CreditBfMonitorEntprise> selectByExample(CreditBfMonitorEntpriseExample example);

    CreditBfMonitorEntprise selectByPrimaryKey(Integer id);

    List<CreditBfMonitorEntprise>  selectSystAndEnt(EntBasicInfo basicInfo);

    int updateByExampleSelective(@Param("record") CreditBfMonitorEntprise record, @Param("example") CreditBfMonitorEntpriseExample example);

    int updateByExample(@Param("record") CreditBfMonitorEntprise record, @Param("example") CreditBfMonitorEntpriseExample example);

    int updateByPrimaryKeySelective(CreditBfMonitorEntprise record);

    int updateByPrimaryKey(CreditBfMonitorEntprise record);
}