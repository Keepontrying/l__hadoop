package com.jd.jr.boss.credit.authen.core.beans.entity.sewage;

import com.jd.jr.boss.credit.facade.enterprise.trade.beans.entity.basic.BasicInfoEntity;

import java.io.Serializable;

public class AutoSewageEntity extends BasicInfoEntity  implements Serializable {

	private static final long serialVersionUID = -3349948912548975872L;
	/**
	 * 是否命中黑名单
	 */
	private String hit;
	/**
	 * 黑名单来源
	 */
	private String hitStr;
	/**
	 * 是否列入经营异常名录
	 */
	private String abnormal;
	/**
	 * 是否有严重违法信息
	 */
	private String illegal;
	/**
	 * 是否有法院裁判信息
	 */
	private String lawsuit;
	/**
	 * 是否失信被执行
	 */
	private String punishedBreak;
	/**
	 * 是否被执行人信息
	 */
	private String punished;
	/**
	 * 是否有开庭公告
	 */
	private String openCourt;
	/**
	 * 是否有法院公告
	 */
	private String courtNotice;
	/**
	 * 标的金额汇总（执行中的）
	 */
	private String subjectAmount;
	/**
	 * 是否有注册资本变少记录
	 */
	private String regCapLow;
	/**
	 * 是否有变更记录
	 */
	private String alterRecord;
	/**
	 * 负责人变更次数
	 */
	private String legalPersonCount;
	/**
	 * 被担保人债权数额汇总
	 */
	private String mortAmount;
	
	/**
	 * 出质股权数额汇总
	 */
	private String equityAmount;
	/**
	 * 未正常的抽查检查结果条数
	 */
	private String checkResultCount;
	/**
	 * 行政处罚条数
	 */
	private String punishmentCount;
	/**
	 * 股东名称1
	 */
	private String shareHolder1;
	/**
	 * 是否列入经营异常名录
	 */
	private String abnormal1;
	/**
	 * 是否涉及严重违法信息
	 */
	private String illegal1;
	/**
	 * 是否是失信被执行人
	 */
	private String punishedBreak1;
	/**
	 * 是否有法院裁判记录
	 */
	private String lawsuit1;
	/**
	 * 法院裁判金额汇总
	 */
	private String lawsuitAmount1;
	/**
	 * 股东名称2
	 */
	private String shareHolder2;
	/**
	 * 是否列入经营异常名录
	 */
	private String abnormal2;
	/**
	 * 是否涉及严重违法信息
	 */
	private String illegal2;
	/**
	 * 是否是失信被执行人
	 */
	private String punishedBreak2;
	/**
	 * 是否有法院裁判记录
	 */
	private String lawsuit2;
	/**
	 * 法院裁判金额汇总
	 */
	private String lawsuitAmount2;
	
	/**
	 * 对外投资名称1
	 */
	private String investment1;
	/**
	 * 是否列入经营异常名录
	 */
	private String abnormal3;
	/**
	 * 是否涉及严重违法信息
	 */
	private String illegal3;
	/**
	 * 是否是失信被执行人
	 */
	private String punishedBreak3;
	/**
	 * 是否有法院裁判记录
	 */
	private String lawsuit3;
	/**
	 * 法院裁判金额汇总
	 */
	private String lawsuitAmount3;
	
	/**
	 * 对外投资名称2
	 */
	private String investment2;
	/**
	 * 是否列入经营异常名录
	 */
	private String abnormal4;
	/**
	 * 是否涉及严重违法信息
	 */
	private String illegal4;
	/**
	 * 是否是失信被执行人
	 */
	private String punishedBreak4;
	/**
	 * 是否有法院裁判记录
	 */
	private String lawsuit4;
	/**
	 * 法院裁判金额汇总
	 */
	private String lawsuitAmount4;

    /**
     * 个人股东名称1
     */
    private String shareHolderPer1;
    /**
     * 个人股东名称2
     */
    private String shareHolderPer2;
    /**
     * 个人股东名称3
     */
    private String shareHolderPer3;
    /**
     * 企业股东名称拼串
     */
    private String shareHolderEnt;
    /**
     * 对外投资企业名称拼串
     */
    private String entInv;
    /**
     * 董事
     */
    private String director;
    /**
     * 监事
     */
    private String supervisor;
    /**
     * 经理
     */
    private String manager;
	/**
	 * 评分分
	 */
	private String score;

	/**
	 * @return the hit
	 */
	public String getHit() {
		return hit;
	}
	/**
	 * @param hit the hit to set
	 */
	public void setHit(String hit) {
		this.hit = hit;
	}
	/**
	 * @return the hitStr
	 */
	public String getHitStr() {
		return hitStr;
	}
	/**
	 * @param hitStr the hitStr to set
	 */
	public void setHitStr(String hitStr) {
		this.hitStr = hitStr;
	}
	/**
	 * @return the abnormal
	 */
	public String getAbnormal() {
		return abnormal;
	}
	/**
	 * @param abnormal the abnormal to set
	 */
	public void setAbnormal(String abnormal) {
		this.abnormal = abnormal;
	}
	/**
	 * @return the illegal
	 */
	public String getIllegal() {
		return illegal;
	}
	/**
	 * @param illegal the illegal to set
	 */
	public void setIllegal(String illegal) {
		this.illegal = illegal;
	}
	/**
	 * @return the lawsuit
	 */
	public String getLawsuit() {
		return lawsuit;
	}
	/**
	 * @param lawsuit the lawsuit to set
	 */
	public void setLawsuit(String lawsuit) {
		this.lawsuit = lawsuit;
	}
	/**
	 * @return the punished
	 */
	public String getPunished() {
		return punished;
	}
	/**
	 * @param punished the punished to set
	 */
	public void setPunished(String punished) {
		this.punished = punished;
	}
	/**
	 * @return the openCourt
	 */
	public String getOpenCourt() {
		return openCourt;
	}
	/**
	 * @param openCourt the openCourt to set
	 */
	public void setOpenCourt(String openCourt) {
		this.openCourt = openCourt;
	}
	/**
	 * @return the courtNotice
	 */
	public String getCourtNotice() {
		return courtNotice;
	}
	/**
	 * @param courtNotice the courtNotice to set
	 */
	public void setCourtNotice(String courtNotice) {
		this.courtNotice = courtNotice;
	}
	/**
	 * @return the subjectAmount
	 */
	public String getSubjectAmount() {
		return subjectAmount;
	}
	/**
	 * @param subjectAmount the subjectAmount to set
	 */
	public void setSubjectAmount(String subjectAmount) {
		this.subjectAmount = subjectAmount;
	}
	/**
	 * @return the regCapLow
	 */
	public String getRegCapLow() {
		return regCapLow;
	}
	/**
	 * @param regCapLow the regCapLow to set
	 */
	public void setRegCapLow(String regCapLow) {
		this.regCapLow = regCapLow;
	}
	/**
	 * @return the alterRecord
	 */
	public String getAlterRecord() {
		return alterRecord;
	}
	/**
	 * @param alterRecord the alterRecord to set
	 */
	public void setAlterRecord(String alterRecord) {
		this.alterRecord = alterRecord;
	}
	/**
	 * @return the legalPersonCount
	 */
	public String getLegalPersonCount() {
		return legalPersonCount;
	}
	/**
	 * @param legalPersonCount the legalPersonCount to set
	 */
	public void setLegalPersonCount(String legalPersonCount) {
		this.legalPersonCount = legalPersonCount;
	}
	/**
	 * @return the mortAmount
	 */
	public String getMortAmount() {
		return mortAmount;
	}
	/**
	 * @param mortAmount the mortAmount to set
	 */
	public void setMortAmount(String mortAmount) {
		this.mortAmount = mortAmount;
	}
	/**
	 * @return the equityAmount
	 */
	public String getEquityAmount() {
		return equityAmount;
	}
	/**
	 * @param equityAmount the equityAmount to set
	 */
	public void setEquityAmount(String equityAmount) {
		this.equityAmount = equityAmount;
	}
	/**
	 * @return the checkResultCount
	 */
	public String getCheckResultCount() {
		return checkResultCount;
	}
	/**
	 * @param checkResultCount the checkResultCount to set
	 */
	public void setCheckResultCount(String checkResultCount) {
		this.checkResultCount = checkResultCount;
	}
	/**
	 * @return the punishmentCount
	 */
	public String getPunishmentCount() {
		return punishmentCount;
	}
	/**
	 * @param punishmentCount the punishmentCount to set
	 */
	public void setPunishmentCount(String punishmentCount) {
		this.punishmentCount = punishmentCount;
	}
	/**
	 * @return the shareHolder1
	 */
	public String getShareHolder1() {
		return shareHolder1;
	}
	/**
	 * @param shareHolder1 the shareHolder1 to set
	 */
	public void setShareHolder1(String shareHolder1) {
		this.shareHolder1 = shareHolder1;
	}
	/**
	 * @return the abnormal1
	 */
	public String getAbnormal1() {
		return abnormal1;
	}
	/**
	 * @param abnormal1 the abnormal1 to set
	 */
	public void setAbnormal1(String abnormal1) {
		this.abnormal1 = abnormal1;
	}
	/**
	 * @return the illegal1
	 */
	public String getIllegal1() {
		return illegal1;
	}
	/**
	 * @param illegal1 the illegal1 to set
	 */
	public void setIllegal1(String illegal1) {
		this.illegal1 = illegal1;
	}
	/**
	 * @return the punishedBreak1
	 */
	public String getPunishedBreak1() {
		return punishedBreak1;
	}
	/**
	 * @param punishedBreak1 the punishedBreak1 to set
	 */
	public void setPunishedBreak1(String punishedBreak1) {
		this.punishedBreak1 = punishedBreak1;
	}
	/**
	 * @return the lawsuit1
	 */
	public String getLawsuit1() {
		return lawsuit1;
	}
	/**
	 * @param lawsuit1 the lawsuit1 to set
	 */
	public void setLawsuit1(String lawsuit1) {
		this.lawsuit1 = lawsuit1;
	}
	/**
	 * @return the lawsuitAmount1
	 */
	public String getLawsuitAmount1() {
		return lawsuitAmount1;
	}
	/**
	 * @param lawsuitAmount1 the lawsuitAmount1 to set
	 */
	public void setLawsuitAmount1(String lawsuitAmount1) {
		this.lawsuitAmount1 = lawsuitAmount1;
	}
	/**
	 * @return the shareHolder2
	 */
	public String getShareHolder2() {
		return shareHolder2;
	}
	/**
	 * @param shareHolder2 the shareHolder2 to set
	 */
	public void setShareHolder2(String shareHolder2) {
		this.shareHolder2 = shareHolder2;
	}
	/**
	 * @return the abnormal2
	 */
	public String getAbnormal2() {
		return abnormal2;
	}
	/**
	 * @param abnormal2 the abnormal2 to set
	 */
	public void setAbnormal2(String abnormal2) {
		this.abnormal2 = abnormal2;
	}
	/**
	 * @return the illegal2
	 */
	public String getIllegal2() {
		return illegal2;
	}
	/**
	 * @param illegal2 the illegal2 to set
	 */
	public void setIllegal2(String illegal2) {
		this.illegal2 = illegal2;
	}
	/**
	 * @return the punishedBreak2
	 */
	public String getPunishedBreak2() {
		return punishedBreak2;
	}
	/**
	 * @param punishedBreak2 the punishedBreak2 to set
	 */
	public void setPunishedBreak2(String punishedBreak2) {
		this.punishedBreak2 = punishedBreak2;
	}
	/**
	 * @return the lawsuit2
	 */
	public String getLawsuit2() {
		return lawsuit2;
	}
	/**
	 * @param lawsuit2 the lawsuit2 to set
	 */
	public void setLawsuit2(String lawsuit2) {
		this.lawsuit2 = lawsuit2;
	}
	/**
	 * @return the lawsuitAmount2
	 */
	public String getLawsuitAmount2() {
		return lawsuitAmount2;
	}
	/**
	 * @param lawsuitAmount2 the lawsuitAmount2 to set
	 */
	public void setLawsuitAmount2(String lawsuitAmount2) {
		this.lawsuitAmount2 = lawsuitAmount2;
	}
	/**
	 * @return the investment1
	 */
	public String getInvestment1() {
		return investment1;
	}
	/**
	 * @param investment1 the investment1 to set
	 */
	public void setInvestment1(String investment1) {
		this.investment1 = investment1;
	}
	/**
	 * @return the abnormal3
	 */
	public String getAbnormal3() {
		return abnormal3;
	}
	/**
	 * @param abnormal3 the abnormal3 to set
	 */
	public void setAbnormal3(String abnormal3) {
		this.abnormal3 = abnormal3;
	}
	/**
	 * @return the illegal3
	 */
	public String getIllegal3() {
		return illegal3;
	}
	/**
	 * @param illegal3 the illegal3 to set
	 */
	public void setIllegal3(String illegal3) {
		this.illegal3 = illegal3;
	}
	/**
	 * @return the punishedBreak3
	 */
	public String getPunishedBreak3() {
		return punishedBreak3;
	}
	/**
	 * @param punishedBreak3 the punishedBreak3 to set
	 */
	public void setPunishedBreak3(String punishedBreak3) {
		this.punishedBreak3 = punishedBreak3;
	}
	/**
	 * @return the lawsuit3
	 */
	public String getLawsuit3() {
		return lawsuit3;
	}
	/**
	 * @param lawsuit3 the lawsuit3 to set
	 */
	public void setLawsuit3(String lawsuit3) {
		this.lawsuit3 = lawsuit3;
	}
	/**
	 * @return the lawsuitAmount3
	 */
	public String getLawsuitAmount3() {
		return lawsuitAmount3;
	}
	/**
	 * @param lawsuitAmount3 the lawsuitAmount3 to set
	 */
	public void setLawsuitAmount3(String lawsuitAmount3) {
		this.lawsuitAmount3 = lawsuitAmount3;
	}
	/**
	 * @return the investment2
	 */
	public String getInvestment2() {
		return investment2;
	}
	/**
	 * @param investment2 the investment2 to set
	 */
	public void setInvestment2(String investment2) {
		this.investment2 = investment2;
	}
	/**
	 * @return the abnormal4
	 */
	public String getAbnormal4() {
		return abnormal4;
	}
	/**
	 * @param abnormal4 the abnormal4 to set
	 */
	public void setAbnormal4(String abnormal4) {
		this.abnormal4 = abnormal4;
	}
	/**
	 * @return the illegal4
	 */
	public String getIllegal4() {
		return illegal4;
	}
	/**
	 * @param illegal4 the illegal4 to set
	 */
	public void setIllegal4(String illegal4) {
		this.illegal4 = illegal4;
	}
	/**
	 * @return the punishedBreak4
	 */
	public String getPunishedBreak4() {
		return punishedBreak4;
	}
	/**
	 * @param punishedBreak4 the punishedBreak4 to set
	 */
	public void setPunishedBreak4(String punishedBreak4) {
		this.punishedBreak4 = punishedBreak4;
	}
	/**
	 * @return the lawsuit4
	 */
	public String getLawsuit4() {
		return lawsuit4;
	}
	/**
	 * @param lawsuit4 the lawsuit4 to set
	 */
	public void setLawsuit4(String lawsuit4) {
		this.lawsuit4 = lawsuit4;
	}
	/**
	 * @return the lawsuitAmount4
	 */
	public String getLawsuitAmount4() {
		return lawsuitAmount4;
	}
	/**
	 * @param lawsuitAmount4 the lawsuitAmount4 to set
	 */
	public void setLawsuitAmount4(String lawsuitAmount4) {
		this.lawsuitAmount4 = lawsuitAmount4;
	}
	/**
	 * @return the punishedBreak
	 */
	public String getPunishedBreak() {
		return punishedBreak;
	}
	/**
	 * @param punishedBreak the punishedBreak to set
	 */
	public void setPunishedBreak(String punishedBreak) {
		this.punishedBreak = punishedBreak;
	}

    public String getShareHolderPer1() {
        return shareHolderPer1;
    }

    public void setShareHolderPer1(String shareHolderPer1) {
        this.shareHolderPer1 = shareHolderPer1;
    }

    public String getShareHolderPer2() {
        return shareHolderPer2;
    }

    public void setShareHolderPer2(String shareHolderPer2) {
        this.shareHolderPer2 = shareHolderPer2;
    }

    public String getShareHolderPer3() {
        return shareHolderPer3;
    }

    public void setShareHolderPer3(String shareHolderPer3) {
        this.shareHolderPer3 = shareHolderPer3;
    }

    public String getShareHolderEnt() {
        return shareHolderEnt;
    }

    public void setShareHolderEnt(String shareHolderEnt) {
        this.shareHolderEnt = shareHolderEnt;
    }

    public String getEntInv() {
        return entInv;
    }

    public void setEntInv(String entInv) {
        this.entInv = entInv;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(String supervisor) {
        this.supervisor = supervisor;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}
}
