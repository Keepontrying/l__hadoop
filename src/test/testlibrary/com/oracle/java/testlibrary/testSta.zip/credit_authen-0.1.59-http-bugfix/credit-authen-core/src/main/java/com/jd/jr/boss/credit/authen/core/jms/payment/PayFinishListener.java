package com.jd.jr.boss.credit.authen.core.jms.payment;

import com.jd.jmq.client.consumer.MessageListener;
import com.jd.jmq.common.message.Message;
import com.jd.jmq.fastjson.JSON;
import com.jd.jmq.fastjson.JSONObject;
import com.jd.jr.boss.credit.authen.core.service.OrderService;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrderMain;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.rediscluster.client.CacheClusterClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * Created by anmeng on 2017/3/31.
 */
@Service("payFinishListener")
public class PayFinishListener implements MessageListener {

    private Logger logger= LoggerFactory.getLogger(PayFinishListener.class);

    @Resource
    private OrderService orderService;

    @Autowired
    protected CacheClusterClient cacheClusterClient;

    private final String platId=ConfigUtil.getString("cashier.platId");
    private final String orderNoPrefix=ConfigUtil.getString("cashier.orderNoPrefix");

    @Override
    public void onMessage(List<Message> messages) throws Exception {
        if (messages == null || messages.isEmpty()) {
            return;
        }

        for (Message message : messages) {
            String dataJSONStr=message.getText();
            try {
                JSONObject notify=JSON.parseObject(dataJSONStr);
                String messagePlat=notify.getString("platId");
                if(messagePlat!=null&&messagePlat.equals(this.platId)){
                    logger.info(String.format("收到一条对公收银台消息,消息主题（队列名）：%s,内容是：%s,业务ID为:%s", message.getTopic(), message.getText(),message.getBusinessId()));
                    String messageOrderNo=notify.getString("orderId");
                    String orderNo="";
                    if(messageOrderNo!=null&&messageOrderNo.length()>orderNoPrefix.length()){
                        orderNo=messageOrderNo.substring(orderNoPrefix.length());
                    }else{
                        logger.error("订单号错误："+messageOrderNo);
                        continue;
                    }

                    if(cacheClusterClient.exists("PAY_ORDER_NO_"+orderNo)){
                        logger.warn("重复消息："+orderNo);
                        continue;
                    }
                    CreditOrderMain orderMain=new CreditOrderMain();
                    orderMain.setOrderNo(orderNo);
                    if(notify.getLong("successTime")!=null){
                        orderMain.setPaymentTime(new Date(notify.getLong("successTime")));
                    }else{
                        logger.warn("支付完成消息中缺少successTime字段，使用当前时间");
                        orderMain.setPaymentTime(new Date());
                    }
                    orderMain.setOutPayId(notify.getString("tradeId"));

                    orderService.confirmReceivePay(orderMain);
                    cacheClusterClient.set("PAY_ORDER_NO_"+orderNo,dataJSONStr);
                    cacheClusterClient.expire("PAY_ORDER_NO_"+orderNo,86400);
                    logger.info("消息处理完成:"+ message.getText());
                }
            } catch (Exception e) {
                logger.error("消息处理失败:"+ e.getMessage());
            }

        }
    }
}
