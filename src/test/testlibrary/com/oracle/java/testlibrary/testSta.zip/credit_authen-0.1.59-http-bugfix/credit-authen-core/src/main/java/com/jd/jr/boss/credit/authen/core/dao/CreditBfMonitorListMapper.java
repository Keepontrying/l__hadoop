package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.entity.CreditBfMonitorList;
import com.jd.jr.boss.credit.authen.core.beans.entity.CreditBfMonitorListExample;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CreditBfMonitorListMapper {
    long countByExample(CreditBfMonitorListExample example);

    int deleteByExample(CreditBfMonitorListExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(CreditBfMonitorList record);

    int insertSelective(CreditBfMonitorList record);

    List<CreditBfMonitorList> selectByExample(CreditBfMonitorListExample example);

    CreditBfMonitorList selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") CreditBfMonitorList record, @Param("example") CreditBfMonitorListExample example);

    int updateByExample(@Param("record") CreditBfMonitorList record, @Param("example") CreditBfMonitorListExample example);

    int updateByPrimaryKeySelective(CreditBfMonitorList record);

    int updateByPrimaryKey(CreditBfMonitorList record);

    /**
     * 根据多入参查询被监控企业list
     * @param monitorPrm
     * @return
     */
    List<CreditBfMonitorList> queryBfMonitorListGroupByFlagMark(CreditBfMonitorList monitorPrm);
}