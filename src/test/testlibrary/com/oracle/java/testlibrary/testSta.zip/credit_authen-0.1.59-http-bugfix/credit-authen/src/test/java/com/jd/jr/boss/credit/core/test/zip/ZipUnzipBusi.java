package com.jd.jr.boss.credit.core.test.zip;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpException;
import com.jd.finance.common.utils.GsonUtils;
import com.jd.jr.boss.credit.authen.core.utils.FileUtils;
import com.jd.jr.boss.credit.domain.common.enums.HspDirRightsEnum;
import com.jd.jr.boss.credit.domain.common.enums.HspRetCodeEnum;
import com.wangyin.admin.frame.utils.SFTPUtil;
import com.wangyin.hsp.client.HSPClient;
import com.wangyin.hsp.client.HSPConfig;
import com.wangyin.hsp.client.NetFile;
import com.wangyin.hsp.client.model.result.DirCountResult;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** 
* @desciption : 
* @author : yangjinlin@jd.com
* @date ：2017年12月11日 下午2:42:49 
* @version 1.0 
* @return  */
public class ZipUnzipBusi {
	
	private static Logger LOGGER = LoggerFactory.getLogger(ZipUnzipBusi.class);

	public static void main1(String[] args)  {
		
		//连接SFTP
		String host = "172.25.61.4";
        String username = "credit_enterprise";
        String priKeyPath = "E://id_rsa_credit_enterprise";
        Integer port = Integer.parseInt("20000");
        LOGGER.info("【秘钥路径】：" + priKeyPath);
        ChannelSftp sftp = null;
		try {
			sftp = SFTPUtil.connect(host, port, username, priKeyPath, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(sftp.isConnected()){
        	LOGGER.info("【sftp 成功】");
		}else{
			LOGGER.error("【sftp 失败】");
			return;
		}
		Vector vec = new Vector();
		try {
			vec = SFTPUtil.listFiles(sftp, "/upload/elimNegReport/user_upload/20171207");
			for(int i = 0;i < vec.size();i++){
				System.out.println("munu or file:" + vec.get(i).toString());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//读取文件 生成压缩包
//		byte[] resultByte = null;
//		String sftpFilePath = "/upload/elimNegReport/user_upload/20171207/110042475_1512614826381_纳易贷需排污客户 2017.12.06.xlsx";
//		InputStream is = null;
//		ByteArrayOutputStream byout = new ByteArrayOutputStream();
//		ZipOutputStream zos = new ZipOutputStream(byout);
//		byte[] buffer1 = new byte[1024];
//		try {
//			is = SFTPUtil.getInputStreamFile(sftp, sftpFilePath);
//		} catch (SftpException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		String fileRootPath = "这是压缩根目录";
//		String filePicPath = "";
//		filePicPath = fileRootPath + "/调查问卷/";
//		String randomStr = String.valueOf((int)(10000+Math.random()*99000));
//		BufferedInputStream entryStream = new BufferedInputStream( is, 1024);
//        ZipEntry entry = new ZipEntry(filePicPath + "hh" + "_" +randomStr + ".xlsx");
//        int tmp = 0;
//        try {
//			zos.putNextEntry(entry);
//			while ((tmp = entryStream.read(buffer1, 0, 1024)) != -1) {
//			    zos.write(buffer1, 0 ,tmp);
//			}
//			is.close();
//	        zos.closeEntry();
//			zos.close();
//		} catch (Exception e) {
//			LOGGER.info("create fileZip failed," + e.getMessage());
//			e.printStackTrace();
//		}
//        
//        resultByte = byout.toByteArray();
//        System.out.println("--------resultByte ------------");
//        try {
//			byout.close();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
		
	}
	
	
	public static void main4(String[] args) throws Exception {
		//连接SFTP
		String host = "172.25.61.4";
        String username = "credit_enterprise";
        String priKeyPath = "E://id_rsa_credit_enterprise";
        Integer port = Integer.parseInt("20000");
        LOGGER.info("【秘钥路径】：" + priKeyPath);
        ChannelSftp sftp = null;
		try {
			sftp = SFTPUtil.connect(host, port, username, priKeyPath, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(sftp.isConnected()){
        	LOGGER.info("【sftp 成功】");
		}else{
			LOGGER.error("【sftp 失败】");
			return;
		}
		
		String sftpFilePath = "/upload/elimNegReport/user_upload/20171207";
		List<String> fileList = new ArrayList<String>();
		fileList = SFTPUtil.listFiles(sftp, sftpFilePath, 1);
		ByteArrayOutputStream byout = new ByteArrayOutputStream();
		ZipOutputStream zos = new ZipOutputStream(byout);
		byte[] resultByte = new byte[1024];
		for(String str : fileList){
			System.out.println("----str :" + str);
			InputStream is = null;
			try {
				is = SFTPUtil.getInputStreamFile(sftp, str);
			} catch (SftpException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String fileRootPath = "这是压缩根目录";
			String randomStr = String.valueOf((int)(10000+Math.random()*99000));
			String filePicPath = randomStr+"_"+str.substring(str.lastIndexOf("/")+1,str.length());
			BufferedInputStream entryStream = new BufferedInputStream( is, 1024);
	        ZipEntry entry = new ZipEntry(filePicPath);
	        int tmp = 0;
	        try {
				zos.putNextEntry(entry);
				while ((tmp = entryStream.read(resultByte, 0, 1024)) != -1) {
				    zos.write(resultByte, 0 ,tmp);
				}
				is.close();
			} catch (Exception e) {
				LOGGER.info("create fileZip failed," + e.getMessage());
				e.printStackTrace();
			}
		}
		zos.closeEntry();
		zos.close();
		resultByte = byout.toByteArray();
        System.out.println("--------resultByte ------------");
        try {
			byout.close();
		} catch (IOException e) {
			e.printStackTrace();
		}	
        
      String filename = "我是最终目的"+ "_" + System.currentTimeMillis() + ".zip";
      String fid="";
      String finalPath = "/portal/elimNegReport/zip";
      HSPConfig hspConfig= new HSPConfig("domain=172.25.47.92:8008,172.25.47.93:8008;token=172.25.47.95:8010;AKSServiceAlias=AKS-JSF-7e474d52c9e1fb97ff35840205c2a87e;", 17, "zxmh20170519");
		hspConfig.setHttpServerUrl("http://172.25.47.95");
		HSPClient hspClient = new HSPClient(hspConfig);
		NetFile netfile = new NetFile(hspClient);
		String dateStr = (new SimpleDateFormat("yyyyMMdd")).format(new Date());
		finalPath = finalPath+"/"+dateStr;
		String pathInHsp = "";
		String[] paths = null;
		DirCountResult dirCount = hspClient.dirCount(finalPath);
		if(HspRetCodeEnum.SUCCESS.toCode() == dirCount.retcode && 0!= dirCount.count){//目录已存在
			pathInHsp = finalPath;
			LOGGER.info("[hspDirCreate-hspClient.dirCount],"+finalPath+"  has existed ,retcode:" + dirCount.retcode+", means "+HspRetCodeEnum.enumValueOf(dirCount.retcode));
		}else{
			paths = finalPath.substring(1).split("/");
			for(String strPath :  Arrays.asList(paths)){
				pathInHsp = pathInHsp+"/"+strPath;
				DirCountResult dirCountResult = hspClient.dirCount(pathInHsp);
				LOGGER.info("------hspClient.dirCount, " + GsonUtil.getInstance().toJson(dirCountResult));
				if(HspRetCodeEnum.ERROR_DIR_NOTEXISTS.toCode() == dirCountResult.retcode){//-30表示 目录不存在
					int retcode = hspClient.dirCreate(pathInHsp, HspDirRightsEnum.EXTENDS_PARENT.toCode());
					if(HspRetCodeEnum.SUCCESS.toCode() != retcode){
						int delcode = hspClient.dirDelete(pathInHsp, false);
						LOGGER.info("----hspClient.dirDelete, " + delcode);
						break;
					}
				}
			}
		}
		DirCountResult confirmPath = hspClient.dirCount(pathInHsp);
		if(HspRetCodeEnum.ERROR_DIR_NOTEXISTS.toCode() == confirmPath.retcode){//目录不存在
			LOGGER.info("[hspNetfileCreateByName-hspClient.dirCount] confirmPath, " + GsonUtil.getInstance().toJson(confirmPath));
			throw new Exception();
		}
		if (!netfile.CreateByName(pathInHsp+"/"+ filename, resultByte.length)) {//创建文件路径失败
			LOGGER.debug("[hspNetfileCreateByName()-netfile.CreateByName()] fail");
			throw new Exception();
		} else {
			String origFid = netfile.GetFid();
			boolean result =  netfile.Write(resultByte);
			LOGGER.info("[hspNetfileCreateByName()-netfile.Write()] result, "+result);
			if(true == result){
				fid = origFid;
			}
		}
		if(StringUtils.isBlank(fid)){
			LOGGER.info("[hspNetfileCreateByName()] fileupload fail ,reason-fid : " + fid);
			throw new Exception();
		}else{
			LOGGER.info("[hspNetfileCreateByName()] fileupload success ,fid : " + fid);
		}
      
      LOGGER.info("ZIPFILE buffer, " + resultByte);
      LOGGER.info("========= file zip done ========");
		
	}
	
	public static void main(String[] args) {
        String strPath ="D:\\testNfsZip";
        File dir = new File(strPath);
        List<File> fileList = new ArrayList<>();
        fileList = FileUtils.getFileList(strPath);
        ByteArrayOutputStream byout = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(byout);
        byte[] resultByte = new byte[1024];
        for(File file : fileList){
            System.out.println("----str :" + GsonUtil.getInstance().toJson(file));
            InputStream is = null;
            try {
                is = new FileInputStream(file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            String fileRootPath = "这是压缩根目录";
            String randomStr = String.valueOf((int)(10000+Math.random()*99000));
            String filePicPath = file.getPath().substring(file.getPath().lastIndexOf("\\")+1, file.getPath().length());
            BufferedInputStream entryStream = new BufferedInputStream( is, 1024);
            ZipEntry entry = new ZipEntry(filePicPath);
            int tmp = 0;
            try {
                zos.putNextEntry(entry);
                while ((tmp = entryStream.read(resultByte, 0, 1024)) != -1) {
                    zos.write(resultByte, 0 ,tmp);
                }
                is.close();
            } catch (Exception e) {
                LOGGER.info("create fileZip failed," + e.getMessage());
                e.printStackTrace();
            }
        }
        try {
            zos.closeEntry();
            zos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        resultByte = byout.toByteArray();
        System.out.println("--------resultByte ------------");
        try {
            byout.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String randomStr1 = String.valueOf((int)(10000+Math.random()*99000));
        FileUtils.getFile(resultByte,"D:", randomStr1+"test.zip");
        String filename = "我是最终目的"+ "_" + System.currentTimeMillis() + ".zip";
        String fid="";
        String finalPath = "/portal/ziptest/sewage";

        String connectString ="domain=hsp-domain-mater.jdfin.local:8008,hsp-domain-slaver.jdfin.local:8008;token=hsp-token.jdfin.local:80;AKSServiceAlias=AKS-JSF;";
        int applicationId = 17;
        String applicationPwd ="zxmh20170519";
        String httpServerUrl ="http://hsp.jdpay.com";
        HSPConfig hspConfig= new HSPConfig(connectString, applicationId, applicationPwd);
        hspConfig.setHttpServerUrl(httpServerUrl);
        HSPClient hspClient = new HSPClient(hspConfig);

        NetFile netfile = new NetFile(hspClient);
        String dateStr = (new SimpleDateFormat("yyyyMMdd")).format(new Date());
        finalPath = finalPath+"/"+dateStr;
        String pathInHsp = "";
        String[] paths = null;
        DirCountResult dirCount = hspClient.dirCount(finalPath);
        if(HspRetCodeEnum.SUCCESS.toCode() == dirCount.retcode && 0!= dirCount.count){//目录已存在
            pathInHsp = finalPath;
            LOGGER.info("[hspDirCreate-hspClient.dirCount],"+finalPath+"  has existed ,retcode:" + dirCount.retcode+", means "+HspRetCodeEnum.enumValueOf(dirCount.retcode));
        }else{
            paths = finalPath.substring(1).split("/");
            for(String strPath1 :  Arrays.asList(paths)){
                pathInHsp = pathInHsp+"/"+strPath1;
                DirCountResult dirCountResult = hspClient.dirCount(pathInHsp);
                LOGGER.info("------hspClient.dirCount, " + GsonUtil.getInstance().toJson(dirCountResult));
                if(HspRetCodeEnum.ERROR_DIR_NOTEXISTS.toCode() == dirCountResult.retcode){//-30表示 目录不存在
                    int retcode = hspClient.dirCreate(pathInHsp, HspDirRightsEnum.EXTENDS_PARENT.toCode());
                    if(HspRetCodeEnum.SUCCESS.toCode() != retcode){
                        int delcode = hspClient.dirDelete(pathInHsp, false);
                        LOGGER.info("----hspClient.dirDelete, " + delcode);
                        break;
                    }
                }
            }
        }
        DirCountResult confirmPath = hspClient.dirCount(pathInHsp);
        if(HspRetCodeEnum.ERROR_DIR_NOTEXISTS.toCode() == confirmPath.retcode){//目录不存在
            LOGGER.info("[hspNetfileCreateByName-hspClient.dirCount] confirmPath, " + GsonUtil.getInstance().toJson(confirmPath));
        }
        if (!netfile.CreateByName(pathInHsp+"/"+ filename, resultByte.length)) {//创建文件路径失败
            LOGGER.debug("[hspNetfileCreateByName()-netfile.CreateByName()] fail");
        } else {
            String origFid = netfile.GetFid();
            boolean result =  netfile.Write(resultByte);
            LOGGER.info("[hspNetfileCreateByName()-netfile.Write()] result, "+result);
            if(true == result){
                fid = origFid;
            }
        }
        if(StringUtils.isBlank(fid)){
            LOGGER.info("[hspNetfileCreateByName()] fileupload fail ,reason-fid : " + fid);
        }else{
            LOGGER.info("[hspNetfileCreateByName()] fileupload success ,fid : " + fid);
        }

        LOGGER.info("ZIPFILE buffer, " + resultByte);
        LOGGER.info("========= file zip done ========");
	}
	
}
