package com.jd.jr.boss.credit.authen.core.facade.portal;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.authen.core.service.ProductService;
import com.jd.jr.boss.credit.facade.authen.api.CreditProductFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.ProductItemQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.ProductItemSkuQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.ProductQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.entity.CreditItem;
import com.wangyin.boss.credit.admin.entity.CreditItemSku;
import com.wangyin.boss.credit.admin.entity.CreditProduct;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.enums.ResponseMessage;

/**
 * Created by anmeng on 2017/3/28.
 */
@Service("creditProductFacade")
public class CreditProductFacadeImpl implements CreditProductFacade {

    private Logger logger= LoggerFactory.getLogger(CreditProductFacadeImpl.class);

    @Resource
    private ProductService productService;

    /**
     * 查询标准产品列表
     *
     * @param queryParam
     * @return
     */
    @Override
    public CreditResponseData<List<CreditItem>> queryProductItem(CreditRequestParam<ProductItemQueryParam> queryParam) {
        CreditResponseData<List<CreditItem>> responseData=new CreditResponseData<List<CreditItem>>();
        try {
            ProductItemQueryParam itemQueryParam=queryParam.getParam();
            List<CreditItem> itemList=productService.queryProductItem(itemQueryParam);
            responseData.setData(itemList);
        } catch (Exception e) {
            logger.error(e);
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            responseData.setMessage(e.getMessage());
        }

        return responseData;
    }

    /**
     * 查询标准产品SKU信息
     *
     * @param queryParam
     * @return
     */
    @Override
    public CreditResponseData<List<CreditItemSku>> queryItemSku(CreditRequestParam<ProductItemSkuQueryParam> queryParam) {
        CreditResponseData<List<CreditItemSku>> responseData=new CreditResponseData<List<CreditItemSku>>();
        try {
            ProductItemSkuQueryParam skuQueryParam=queryParam.getParam();
            List<CreditItemSku> skus=productService.queryItemSku(skuQueryParam);
            responseData.setData(skus);
        } catch (Exception e) {
            logger.error(e);
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            if(e.getMessage()!=null) {
                responseData.setMessage(e.getMessage());
            }
        }
        return responseData;
    }

	@Override
	public CreditResponseData<List<CreditItem>> queryProductShowItem(
			CreditRequestParam<ProductItemQueryParam> queryParam) {
		
		CreditResponseData<List<CreditItem>> responseData=new CreditResponseData<List<CreditItem>>();
        try {
            ProductItemQueryParam itemQueryParam=queryParam.getParam();
            if(StringUtils.isBlank(itemQueryParam.getMerchantNo())){
            	responseData.setCode("MERCHANTNO_REQUIRED");
            	responseData.setSuccess(false);
            	responseData.setMessage("商户号不可为空");
            	return responseData;
            }
            List<CreditItem> itemList=productService.queryProductShowItem(itemQueryParam);
            responseData.setData(itemList);
        } catch (Exception e) {
            logger.error(e);
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            responseData.setMessage(e.getMessage());
        }

        return responseData;
	}

    /**
     * 查询单个标准产品详情
     *
     * @param queryParam
     * @return
     */
    @Override
    public CreditResponseData<CreditItem> queryProductItemDetail(CreditRequestParam<Integer> queryParam) {
        CreditResponseData<CreditItem> responseData=new CreditResponseData<CreditItem>();
        try {
            Integer itemId=queryParam.getParam();
            CreditItem item=productService.queryProductItemById(itemId);
            responseData.setData(item);
        } catch (Exception e) {
            logger.error(e);
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            responseData.setMessage(e.getMessage());
        }
        return responseData;
    }

	@Override
	public CreditResponseData<List<CreditProduct>> queryProductListByPrm(
			CreditRequestParam<ProductQueryParam> queryParam) {
		CreditResponseData<List<CreditProduct>> responseData = new CreditResponseData<List<CreditProduct>>();
		try {
			List<CreditProduct> productList = productService.queryProductListByPrm(queryParam.getParam());
			responseData.setData(productList);
		} catch (Exception e) {
			logger.error(e);
            responseData.setResponseMessage(ResponseMessage.SYSTEM_ERROR);
            responseData.setMessage(e.getMessage());
		}
		return responseData;
	}

    @Override
    public void doSuperProductCenter(Map<Integer, String> map) {

    }
}
