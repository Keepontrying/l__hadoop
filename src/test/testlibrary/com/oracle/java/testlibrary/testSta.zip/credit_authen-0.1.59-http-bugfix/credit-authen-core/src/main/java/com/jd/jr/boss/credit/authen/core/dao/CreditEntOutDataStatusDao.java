package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.entity.EntOutDataStatusQueryParam;
import com.jd.jr.boss.credit.domain.common.entity.CreditEntOutDataStatus;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Auther: anmeng
 * @Date: 2018/12/11 18:53
 * @Description:
 */
@Repository
public interface CreditEntOutDataStatusDao {
    /**
     * 查询
     * @param param
     * @return
     */
    public List<CreditEntOutDataStatus> query(EntOutDataStatusQueryParam param);

    /**
     * 修改状态
     * @param status
     */
    public void updateStatus(CreditEntOutDataStatus status);
    /**
     * 根据企业名字修改状态
     * @param status
     */
    public void updateStatusByName(CreditEntOutDataStatus status);
}
