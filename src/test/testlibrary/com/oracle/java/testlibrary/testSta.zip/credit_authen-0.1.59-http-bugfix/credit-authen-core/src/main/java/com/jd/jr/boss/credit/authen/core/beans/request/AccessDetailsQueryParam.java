package com.jd.jr.boss.credit.authen.core.beans.request;

import java.io.Serializable;

public class AccessDetailsQueryParam implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5379958492221770428L;
	/**
     * 开始时间
     */
    private String startTime;
    /**
     * 结束时间
     */
    private String finishTime;
    /**
     * 请求步骤
     */
    private String requestStep;
    public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getFinishTime() {
		return finishTime;
	}
	public void setFinishTime(String finishTime) {
		this.finishTime = finishTime;
	}
	public String getRequestStep() {
		return requestStep;
	}
	public void setRequestStep(String requestStep) {
		this.requestStep = requestStep;
	}
	public String getAccessStatus() {
		return accessStatus;
	}
	public void setAccessStatus(String accessStatus) {
		this.accessStatus = accessStatus;
	}
	/**
     * 业务状态
     */
    private String accessStatus;
}
