package com.jd.jr.boss.credit.authen.core.dao;

import com.jd.jr.boss.credit.authen.core.beans.request.PaymentQueryParam;
import com.jd.jr.boss.credit.domain.common.entity.CreditPayment;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by anmeng on 2016/12/20.
 */
@Repository
public interface CreditPaymentDao {
    /**
     * 新增缴费记录
     * @param creditPayment
     * @return
     */
    Integer insertPayment(CreditPayment creditPayment);

    /**
     *  查询缴费记录列表
     * @return
     */
    List<CreditPayment> queryPaymentRecord(PaymentQueryParam paymentQueryParam);

    /**
     * 更新缴费单状态
     * @param creditPayment
     */
    Integer updatePaymentStatus(CreditPayment creditPayment);
}
