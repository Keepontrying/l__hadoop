package com.wangyin.boss.credit.admin.service;

import java.util.List;

import com.wangyin.boss.credit.admin.entity.CreditChangeRecord;

/**
 * 产品变更记录service
 * @author wyhaozhihong
 *
 */
public interface CreditChangeRecordService {
	
	/**
	 * 新增变更记录
	 * @author wyhaozhihong
	 * @param creditChangeRecord
	 */
	int insertRecord(CreditChangeRecord creditChangeRecord);
	
	/**
	 * 更改关联ID查询变更记录信息
	 * @author wyhaozhihong
	 * @param strategyId
	 * @return
	 */
	List<CreditChangeRecord> selectCredChanRecdsByConfigId(Integer strategyId);

}
