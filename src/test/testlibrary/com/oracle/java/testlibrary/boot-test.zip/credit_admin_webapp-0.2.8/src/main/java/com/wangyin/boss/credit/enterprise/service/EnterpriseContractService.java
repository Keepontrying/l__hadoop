package com.wangyin.boss.credit.enterprise.service;

import java.util.List;

import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.enterprise.entity.EnterpriseProductItemSkuModel;
import com.wangyin.operation.beans.UploadFile;
import org.apache.poi.ss.formula.functions.T;

/** 
* @desciption : 企业征信合同service接口类
* @author : yangjinlin@jd.com
* @date ：2017年3月17日 下午4:32:46 
* @version 1.0 
* @return  */
public interface EnterpriseContractService {

	/**
	 * 多条件分页查询查询企业征信合同
	 * @param creditContract 合同实体类
	 * @return
	 */
	List<CreditContract> selectEnterpContByParam(CreditContract creditContract);

	/**
	 * 多条件分页查询查询企业征信合同总记录数
	 * @param creditContract 合同实体类
	 * @return
	 */
	int selectEnterpContCountByParam(CreditContract creditContract);
	/**
	 * 创建企业征信合同
	 * @param creditContract
	 * @param creditMerchant
	 * @param enterpriseProductItemSkuModel
	 * @return
	 * @throws Exception 
	 */
	int createEnterpContract(CreditContract creditContract, CreditMerchant creditMerchant,
			EnterpriseProductItemSkuModel enterpriseProductItemSkuModel) throws Exception;

	/**
	 * 审核操作时更新合同状态及相关数据同步变更
	 * @param creditContract
	 * @return
	 */
	int modifyContractByPrimaryKey(CreditContract creditContract);

    /**
     * 日常文件下载
     * @param list
     * @param titles
     * @param properties
     * @param originalName
     * @return
     */
    UploadFile downCreditEnterContract(List<CreditContract> list, String[] titles, String[] properties, String originalName);
}
