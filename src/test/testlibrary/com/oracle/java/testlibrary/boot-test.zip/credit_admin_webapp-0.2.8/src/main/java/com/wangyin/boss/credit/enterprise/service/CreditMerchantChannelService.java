package com.wangyin.boss.credit.enterprise.service;

import com.jd.jr.boss.credit.domain.common.entity.CreditMerchantChannelGather;
import com.jd.jr.boss.credit.facade.authen.beans.param.MerchantChannelQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditChnProdIns;
import com.wangyin.boss.credit.enterprise.beans.CreditChannelProdInsQueryParam;
import com.wangyin.boss.credit.enterprise.entity.CreditChannelProdIns;
import com.wangyin.boss.credit.enterprise.entity.CreditChnMerchantInsRel;
import com.wangyin.boss.credit.enterprise.entity.CreditChnProd;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Description: 商户渠道service接口类
 * User: yangjinlin@jd.com
 * Date: 2018/5/15 21:35
 * Version: 1.0
 */
public interface CreditMerchantChannelService {


    /**
     * 查询商户渠道汇总信息   总计数
     * @param queryParam
     * @return
     */
    int queryMerchantChannelGatherListCount(MerchantChannelQueryParam queryParam);

    /**
     * 查询商户渠道汇总信息List
     * @param queryParam
     * @return
     */
    List<CreditMerchantChannelGather> queryMerchantChannelGatherList(MerchantChannelQueryParam queryParam);

    /**
     * 统计成功或失败笔数
     * @param queryParam
     * @return
     */
    int selectCountMerchantChannelGatherByParam(MerchantChannelQueryParam queryParam);

    /**
     * 查询渠道产品实例  总数
     * @param queryParam
     * @return
     */
    int queryChannelProdInsListCount(CreditChannelProdInsQueryParam queryParam);

    /**
     *  查询渠道产品实例 List
     * @param queryParam
     * @return
     */
    List<CreditChnProdIns> queryChannelProdInsList(CreditChannelProdInsQueryParam queryParam);

    /**
     *  查询全部渠道产品实例 List
     * @param queryParam
     * @return
     */
    List<CreditChnProd> queryAllChannelProdList(CreditChnProd queryParam);

    /**
     * 查询用户对应产品渠道
     * @param creditChnMerchantInsRel
     * @return
     */
    Set<CreditChannelProdIns> queryChannelsBy(CreditChnMerchantInsRel creditChnMerchantInsRel);

    /**
     * 保存渠道实例信息
     * @param queryParam
     * @param userName
     * @return
     */
    int saveOrUpdate(CreditChannelProdInsQueryParam queryParam, String userName);

    /**
     * 修改路由权重
     * @param start
     * @param userName
     * @return
     */
    Map<String,Object> sortMerchantChannel(Map<String,Object> start, String userName);
}
