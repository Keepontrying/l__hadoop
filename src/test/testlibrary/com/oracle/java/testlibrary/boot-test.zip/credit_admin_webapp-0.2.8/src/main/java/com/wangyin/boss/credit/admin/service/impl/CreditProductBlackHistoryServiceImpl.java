package com.wangyin.boss.credit.admin.service.impl;

import com.wangyin.boss.credit.admin.dao.CreditProductBlackHistoryMapper;
import com.wangyin.boss.credit.admin.dao.CreditProductBlackMapper;
import com.wangyin.boss.credit.admin.entity.CreditProductBlack;
import com.wangyin.boss.credit.admin.entity.CreditProductBlackHistory;
import com.wangyin.boss.credit.admin.service.CreditProductBlackHistoryService;
import com.wangyin.boss.credit.admin.service.CreditProductBlackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;


/**
 * @desciption : 产品黑名单历史接口方法实现类
 * @author : liuwei55@jd.com
 * @date ：2017年4月10日 下午20:37:55
 * @version 1.0
 * @return  */
@Service
public class CreditProductBlackHistoryServiceImpl implements CreditProductBlackHistoryService {

	@Autowired
	private CreditProductBlackHistoryMapper creditProductBlackHistoryMapper;

	@Override
	public List<CreditProductBlackHistory> selectCreProdBlHisByBlackId(Map<String,Object> map) {
		return creditProductBlackHistoryMapper.selectCreProdBlHisByBlackId(map);
	}

	@Override
	public int selectCountHisByBlackId(Map<String,Object> map) {
		return creditProductBlackHistoryMapper.selectCountHisByBlackId(map);
	}
}
