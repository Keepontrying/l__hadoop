package com.wangyin.boss.credit.enterprise.service.impl;

import com.jd.jr.boss.credit.domain.common.entity.CreditCallTimesGather;
import com.jd.jr.boss.credit.domain.common.enums.CreditPurchaseTypeEnum;
import com.jd.jr.boss.credit.facade.authen.api.CreditLogFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.CallTimesGatherQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.elasticsearch.api.CreditLogSearchFacade;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.param.ChannelLogQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.param.CreditDealFlowQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.param.CreditLogQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.CreditChannelLogInfo;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.CreditDealFlowInfo;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.CreditTradeLogInfo;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.QueryCountEntity;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.enums.*;
import com.wangyin.boss.credit.admin.utils.ExcelUtil;
import com.wangyin.boss.credit.enterprise.service.CreditLogService;
import com.wangyin.operation.beans.UploadFile;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/** 
* @desciption : 交易流水service接口实现类
* @author : yangjinlin@jd.com
* @date ：2018年4月23日 下午5:04:46 
* @version 1.0 
* @return  */
@Service
public class CreditLogServiceImpl implements CreditLogService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CreditLogServiceImpl.class);
	
	@Resource
	private CreditLogFacade creditLogFacade;
	
	@Resource
	private CreditLogSearchFacade creditLogSearchFacade;
	
	@Override
	public int queryTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam) {
		
		return creditLogFacade.queryTradeLogCallTimesGatherListCount(queryParam);
	}

	@Override
	public List<CreditCallTimesGather> queryTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam) {
		List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
		try {
			CreditResponseData<List<CreditCallTimesGather>> responseData = creditLogFacade.queryTradeLogCallTimesGatherList(queryParam);
			if(null != responseData && responseData.isSuccess()){
				callTimesGatherList = responseData.getData();
			}else{
				LOGGER.info("creditDealFlowFacade.queryCallTimesGatherList failed, {}", GsonUtil.getInstance().toJson(responseData) );
			}
		} catch (Exception e) {
			LOGGER.info("queryCallTimesGatherList failed, {}", e );
		}
		return callTimesGatherList;
	}

	@Override
	public int queryMerchTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam) {
		return creditLogFacade.queryMerchTradeLogCallTimesGatherListCount(queryParam);
	}

	@Override
	public List<CreditCallTimesGather> queryMerchTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam) {
		List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
		try {
			CreditResponseData<List<CreditCallTimesGather>> responseData = creditLogFacade.queryMerchTradeLogCallTimesGatherList(queryParam);
			if(null != responseData && responseData.isSuccess()){
				callTimesGatherList = responseData.getData();
			}else{
				LOGGER.info("creditDealFlowFacade.queryMerchTradeLogCallTimesGatherList failed, {}", GsonUtil.getInstance().toJson(responseData) );
			}
		} catch (Exception e) {
			LOGGER.info("queryMerchTradeLogCallTimesGatherList failed, {}", e );
		}
		return callTimesGatherList;
	}

	@Override
	public int queryMerchProdTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam) {
		return creditLogFacade.queryMerchProdTradeLogCallTimesGatherListCount(queryParam);
	}

	@Override
	public List<CreditCallTimesGather> queryMerchProdTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam) {
		List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
		try {
			CreditResponseData<List<CreditCallTimesGather>> responseData = creditLogFacade.queryMerchProdTradeLogCallTimesGatherList(queryParam);
			if(null != responseData && responseData.isSuccess()){
				callTimesGatherList = responseData.getData();
			}else{
				LOGGER.info("creditDealFlowFacade.queryMerchProdTradeLogCallTimesGatherList failed, {}", GsonUtil.getInstance().toJson(responseData) );
			}
		} catch (Exception e) {
			LOGGER.info("queryMerchProdTradeLogCallTimesGatherList failed, {}", e );
		}
		return callTimesGatherList;
	}

	@Override
	public int queryMerchProdStepTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam) {
		return creditLogFacade.queryMerchProdStepTradeLogCallTimesGatherListCount(queryParam);
	}

	@Override
	public List<CreditCallTimesGather> queryMerchProdStepTradeLogCallTimesGatherList(
			CallTimesGatherQueryParam queryParam) {
		List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
		try {
			CreditResponseData<List<CreditCallTimesGather>> responseData = creditLogFacade.queryMerchProdStepTradeLogCallTimesGatherList(queryParam);
			if(null != responseData && responseData.isSuccess()){
				callTimesGatherList = responseData.getData();
			}else{
				LOGGER.info("creditDealFlowFacade.queryMerchProdStepTradeLogCallTimesGatherList failed, {}", GsonUtil.getInstance().toJson(responseData) );
			}
		} catch (Exception e) {
			LOGGER.info("queryMerchProdStepTradeLogCallTimesGatherList failed, {}", e );
		}
		return callTimesGatherList;
	}

	@Override
	public int queryMerchProdResoTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam) {
		return creditLogFacade.queryMerchProdResoTradeLogCallTimesGatherListCount(queryParam);
	}

	@Override
	public List<CreditCallTimesGather> queryMerchProdResoTradeLogCallTimesGatherList(
			CallTimesGatherQueryParam queryParam) {
		List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
		try {
			CreditResponseData<List<CreditCallTimesGather>> responseData = creditLogFacade.queryMerchProdResoTradeLogCallTimesGatherList(queryParam);
			if(null != responseData && responseData.isSuccess()){
				callTimesGatherList = responseData.getData();
			}else{
				LOGGER.info("creditDealFlowFacade.queryMerchProdResoTradeLogCallTimesGatherList failed, {}", GsonUtil.getInstance().toJson(responseData) );
			}
		} catch (Exception e) {
			LOGGER.error("queryMerchProdResoTradeLogCallTimesGatherList failed, {}", e );
		}
		return callTimesGatherList;
	}

	@Override
	public CreditPage<CreditTradeLogInfo> queryTradeLogPage(CreditLogQueryParam queryParam) {
		CreditPage<CreditTradeLogInfo> tradeLogPage = null;
		try {
			LOGGER.info("[CreditLogServiceImpl-queryTradeLogList] requestParam: {}, countFeil: {}", GsonUtil.getInstance().toJson(queryParam) );
			tradeLogPage = creditLogSearchFacade.queryTradeLogList(queryParam);
			LOGGER.info("[CreditLogServiceImpl-queryTradeLogList] reaponseData, {}", GsonUtil.getInstance().toJson(tradeLogPage));
		} catch (Exception e) {
			LOGGER.error("[CreditLogServiceImpl-queryTradeLogList] failed, {}", e);
		}
		return tradeLogPage;
	}

	@Override
	public CreditResponseData<List<QueryCountEntity>> countCreditLogByField(CreditLogQueryParam queryParam,
			String countField) {
		CreditResponseData<List<QueryCountEntity>> countFieldResp = null;
		try {
			LOGGER.info("[CreditLogServiceImpl-countCreditLogByField] requestParam: {}, countFeild: {}", GsonUtil.getInstance().toJson(queryParam), countField);
			countFieldResp = creditLogSearchFacade.countCreditLogByField(queryParam, countField);
			LOGGER.info("[CreditLogServiceImpl-countCreditLogByField] reaponseData, {}", GsonUtil.getInstance().toJson(countFieldResp));
		} catch (Exception e) {
			LOGGER.error("[CreditLogServiceImpl-countCreditLogByField] failed, {}", e);
		}
		return countFieldResp;
	}

	@Override
	public List<CreditCallTimesGather> queryResoTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam) {
		List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
		try {
			CreditResponseData<List<CreditCallTimesGather>> responseData = creditLogFacade.queryResoTradeLogCallTimesGatherList(queryParam);
			if(null != responseData && responseData.isSuccess()){
				callTimesGatherList = responseData.getData();
			}else{
				LOGGER.info("creditDealFlowFacade.queryResoTradeLogCallTimesGatherList failed, {}", GsonUtil.getInstance().toJson(responseData) );
			}
		} catch (Exception e) {
			LOGGER.error("queryResoTradeLogCallTimesGatherList failed, {}", e );
		}
		return callTimesGatherList;
	}

	@Override
	public CreditPage<CreditChannelLogInfo> queryChannelLogList(ChannelLogQueryParam queryParam) {
		CreditPage<CreditChannelLogInfo> channelLogPage = null;
		try {
            LOGGER.info("[CreditLogServiceImpl-doQueryChannelLogList] requestParam: {}, countFeil: {}", GsonUtil.getInstance().toJson(queryParam) );
			channelLogPage = creditLogSearchFacade.queryChannelLogList(queryParam);
            LOGGER.info("[CreditLogServiceImpl-doQueryChannelLogList] responseData: {}, ", GsonUtil.getInstance().toJson(channelLogPage) );
		} catch (Exception e) {
			LOGGER.error("[CreditLogServiceImpl-doQueryChannelLogList] failed, {}", e);
		}
		return channelLogPage;
	}

	@Override
	public CreditResponseData<List<QueryCountEntity>> countChannelLogByField(ChannelLogQueryParam queryParam, String countField) {
		CreditResponseData<List<QueryCountEntity>> countFieldResp = null;
		try {
			LOGGER.info("[CreditLogServiceImpl-countChannelLogByField] requestParam: {}, countFeild: {}", GsonUtil.getInstance().toJson(queryParam), countField);
			countFieldResp = creditLogSearchFacade.countChannelLogByField(queryParam, countField);
			LOGGER.info("[CreditLogServiceImpl-countChannelLogByField] reaponseData, {}", GsonUtil.getInstance().toJson(countFieldResp));
		} catch (Exception e) {
			LOGGER.error("[CreditLogServiceImpl-countChannelLogByField] failed, {}", e);
		}
		return countFieldResp;
	}

    @Override
    public UploadFile downTradeLogQueryResult(CreditLogQueryParam queryParam) {
        LOGGER.info("start downTradeLogQueryResult start.");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        ExcelUtil excelUtil = new ExcelUtil();
        String startDate = sdf.format(new Date());
        LOGGER.info("startDate=" + startDate);
        String path = ConfigUtil.getString("app.credit.downloadpath");
        String date = (new SimpleDateFormat("yyyyMMddHHmmSS")).format(new Date());
        String month = date.substring(0, 6);
        String day = date.substring(6, 14);
        String randomStr = String.valueOf((int)(1000000+Math.random()*9900000));
        String name = "/AccessDetailQueryResult/" + month + "/业务流水查询结果_"+ day +randomStr + ".xlsx";
        String dir = path + name;
        String pathName = "/accessDetail" + name;
        String originalName = "业务流水查询结果.xlsx";
        String[] titles = { "业务流水号","商户号","商户名称","产品名称", "业务状态","详细状态","请求参数","返回参数","请求时间","响应时间","调用模式","调用来源", "接口请求流水号","底层接口返回码","创建人"};
        String[] properties = { "tradeNo","merchantNo","merchantName", "productName", "accessStatus","stepStatus", "requestParam", "responseParam", "requestTime", "responseTime", "callMode","resource","orderNo","responseCode","creator"};
        OutputStream outputStream = null;
        String workSheetName = "业务流水查询结果";
        int start = 0;
        int limit = 5000000;
        try {
            File file = new File(dir);
            if (!file.getParentFile().exists()) {
                if (!file.getParentFile().mkdirs()) {
                }
            }
            if (!file.exists()) {
                file.createNewFile();
            }
            outputStream = new FileOutputStream(file);
            SXSSFWorkbook wb = new SXSSFWorkbook(500);//// 创建工作薄
            Sheet sheet = null;//// 声明工作表
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            for (int i = 1;; i++) {
                List<CreditTradeLogInfo> resultList = selectTradeLogByParam(queryParam);
                for (CreditTradeLogInfo tradeLogInfo : resultList) {
                    tradeLogInfo.setAccessStatus(AccessStatusEnum.enumValueOf(tradeLogInfo.getAccessStatus()).toDescription());
                    tradeLogInfo.setStepStatus(AccessStepStatusEnum.enumValueOf(tradeLogInfo.getStepStatus()).toDescription());
                    tradeLogInfo.setCallMode(AccessCallModeEnum.enumValueOf(tradeLogInfo.getCallMode()).toDescription());
                    tradeLogInfo.setResource(CreditSourceEnum.enumValueOf(tradeLogInfo.getResource()).toDescription());
                    //在excel中将空数据展示为 -
                    tradeLogInfo.setMerchantNo(tradeLogInfo.getMerchantNo() == null ? "-":tradeLogInfo.getMerchantNo());
                    tradeLogInfo.setMerchantName(tradeLogInfo.getMerchantName() == null ?"-":tradeLogInfo.getMerchantName());
                    tradeLogInfo.setProductName(tradeLogInfo.getProductName() == null ?"-":tradeLogInfo.getProductName());
                    tradeLogInfo.setAccessStatus(tradeLogInfo.getAccessStatus() == null ?"-":tradeLogInfo.getAccessStatus());
                    tradeLogInfo.setStepStatus(tradeLogInfo.getStepStatus() == null ?"-":tradeLogInfo.getStepStatus());
                    tradeLogInfo.setRequestParam(tradeLogInfo.getRequestParam() == null ? "-" : tradeLogInfo.getRequestParam());
                    tradeLogInfo.setResponseParam(tradeLogInfo.getResponseParam() == null ? "-" : tradeLogInfo.getResponseParam());
                    tradeLogInfo.setRequestTime(tradeLogInfo.getRequestTime() == null ? "-" : tradeLogInfo.getRequestTime());
                    tradeLogInfo.setResponseTime(tradeLogInfo.getResponseTime() == null ? "-" : tradeLogInfo.getResponseTime());
                    tradeLogInfo.setCallMode(tradeLogInfo.getCallMode() == null ?"-":tradeLogInfo.getCallMode());
                    tradeLogInfo.setResource(tradeLogInfo.getResource() == null ? "-":tradeLogInfo.getResource());
                    tradeLogInfo.setOrderNo(tradeLogInfo.getOrderNo() == null ? "-":tradeLogInfo.getOrderNo());
                    tradeLogInfo.setResponseCode(tradeLogInfo.getResponseCode() == null ? "-":tradeLogInfo.getResponseCode());
                    tradeLogInfo.setCreator(tradeLogInfo.getCreator() == null ?"-":tradeLogInfo.getCreator());
                }
                if(i == 1 && resultList.size() == 0){
                    sheet = excelUtil.export(wb, workSheetName, titles, sheet);
                    break;
                }
                start = i * limit;
                LOGGER.info("resultList.size()=" + resultList.size());
                int rowNum = 0;
                if (i != 1) {
                    rowNum = (i - 1) * limit;
                }
                sheet = excelUtil.export(wb, outputStream, workSheetName, titles,
                        properties, resultList, "", CreditTradeLogInfo.class, sheet,  rowNum);
                if (resultList.size() < limit) {// 最后一批则跳出循环
                    break;
                }
            }
            wb.write(outputStream);
            wb.dispose();
        } catch (Exception e) {
            LOGGER.error("downTradeLogQueryResult create result excel error,{}", e);
        } finally {
            try {
                outputStream.flush();
                outputStream.close();
            } catch (IOException e) {
                LOGGER.error(" error,{}", e);
            }
        }
        UploadFile uploadfile = new UploadFile();
        uploadfile.setPathname(pathName);
        uploadfile.setOriginalName(originalName);
        uploadfile.setVersion("2.0");
        uploadfile.setTemp(true);
        LOGGER.info("ending downTradeLogQueryResult download end.");
        String endDate = sdf.format(new Date());
        return uploadfile;
    }

    @Override
    public UploadFile downMerchTradeLogCallTimes(CallTimesGatherQueryParam queryParam) {
        LOGGER.info("start downMerchTradeLogCallTimes start.");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        ExcelUtil excelUtil = new ExcelUtil();
        String startDate = sdf.format(new Date());
        LOGGER.info("startDate=" + startDate);
        String path = ConfigUtil.getString("app.credit.downloadpath");
        String date = (new SimpleDateFormat("yyyyMMddHHmmSS")).format(new Date());
        String month = date.substring(0, 6);
        String day = date.substring(6, 14);
        String randomStr = String.valueOf((int)(1000000+Math.random()*9900000));
        String name = "/AccessDetailQueryResult/" + month + "/业务流水商户维度调用量查询结果_"+ day +randomStr + ".xlsx";
        String dir = path + name;
        String pathName = "/accessDetail" + name;
        String originalName = "业务流水商户维度调用量查询结果.xlsx";
        String[] titles = { "商户号","商户名称","总调用量", "成功调用量","失败调用量","失败比例(%)"};
        String[] properties = { "merchantNo","merchantName", "callTotal", "callTimes","failCount", "failRate"};
        OutputStream outputStream = null;
        String workSheetName = "业务流水商户维度调用量查询结果";
        int start = 0;
        int limit = 5000000;
        try {
            File file = new File(dir);
            if (!file.getParentFile().exists()) {
                if (!file.getParentFile().mkdirs()) {
                }
            }
            if (!file.exists()) {
                file.createNewFile();
            }
            outputStream = new FileOutputStream(file);
            SXSSFWorkbook wb = new SXSSFWorkbook(500);//// 创建工作薄
            Sheet sheet = null;//// 声明工作表
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            for (int i = 1;; i++) {
                List<CreditCallTimesGather> resultList = this.queryMerchTradeLogCallTimesGatherList(queryParam);
                for(CreditCallTimesGather callTimes : resultList){
                    int failCount = callTimes.getCallTotal()-callTimes.getCallTimes();
                    callTimes.setFailCount(failCount);
                    BigDecimal fail = new BigDecimal(failCount).divide(new BigDecimal(callTimes.getCallTotal()), 4,
                            RoundingMode.FLOOR);
                    DecimalFormat failRate = new DecimalFormat("###.##");
                    callTimes.setFailRate(failRate.format(fail.multiply(new BigDecimal(100))) + "%");
                }
                if(i == 1 && resultList.size() == 0){
                    sheet = excelUtil.export(wb, workSheetName, titles, sheet);
                    break;
                }
                start = i * limit;
                LOGGER.info("resultList.size()=" + resultList.size());
                int rowNum = 0;
                if (i != 1) {
                    rowNum = (i - 1) * limit;
                }
                sheet = excelUtil.export(wb, outputStream, workSheetName, titles,
                        properties, resultList, "", CreditCallTimesGather.class, sheet,  rowNum);
                if (resultList.size() < limit) {// 最后一批则跳出循环
                    break;
                }
            }
            wb.write(outputStream);
            wb.dispose();
        } catch (Exception e) {
            LOGGER.error("downMerchTradeLogCallTimes create result excel error,{}", e);
        } finally {
            try {
                outputStream.flush();
                outputStream.close();
            } catch (IOException e) {
                LOGGER.error(" error,{}", e);
            }
        }
        UploadFile uploadfile = new UploadFile();
        uploadfile.setPathname(pathName);
        uploadfile.setOriginalName(originalName);
        uploadfile.setVersion("2.0");
        uploadfile.setTemp(true);
        LOGGER.info("ending downMerchTradeLogCallTimes download end.");
        String endDate = sdf.format(new Date());
        return uploadfile;
    }

    @Override
    public UploadFile downMerchProdTradeLogCallTimes(CallTimesGatherQueryParam queryParam) {
        LOGGER.info("start downMerchProdTradeLogCallTimes start.");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        ExcelUtil excelUtil = new ExcelUtil();
        String startDate = sdf.format(new Date());
        LOGGER.info("startDate=" + startDate);
        String path = ConfigUtil.getString("app.credit.downloadpath");
        String date = (new SimpleDateFormat("yyyyMMddHHmmSS")).format(new Date());
        String month = date.substring(0, 6);
        String day = date.substring(6, 14);
        String randomStr = String.valueOf((int)(1000000+Math.random()*9900000));
        String name = "/AccessDetailQueryResult/" + month + "/业务流水商户产品维度调用量查询结果_"+ day +randomStr + ".xlsx";
        String dir = path + name;
        String pathName = "/accessDetail" + name;
        String originalName = "业务流水商户产品维度调用量查询结果.xlsx";
        String[] titles = { "商户号","商户名称","产品名称","总调用量", "成功调用量","失败调用量","失败比例(%)"};
        String[] properties = { "merchantNo","merchantName", "productName", "callTotal", "callTimes","failCount", "failRate"};
        OutputStream outputStream = null;
        String workSheetName = "业务流水商户产品维度调用量查询结果";
        int start = 0;
        int limit = 5000000;
        try {
            File file = new File(dir);
            if (!file.getParentFile().exists()) {
                if (!file.getParentFile().mkdirs()) {
                }
            }
            if (!file.exists()) {
                file.createNewFile();
            }
            outputStream = new FileOutputStream(file);
            SXSSFWorkbook wb = new SXSSFWorkbook(500);//// 创建工作薄
            Sheet sheet = null;//// 声明工作表
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            for (int i = 1;; i++) {
                List<CreditCallTimesGather> resultList = this.queryMerchProdTradeLogCallTimesGatherList(queryParam);
                for(CreditCallTimesGather callTimes : resultList){
                    int failCount = callTimes.getCallTotal()-callTimes.getCallTimes();
                    callTimes.setFailCount(failCount);
                    BigDecimal fail = new BigDecimal(failCount).divide(new BigDecimal(callTimes.getCallTotal()), 4,
                            RoundingMode.FLOOR);
                    DecimalFormat failRate = new DecimalFormat("###.##");
                    callTimes.setFailRate(failRate.format(fail.multiply(new BigDecimal(100))) + "%");
                }
                if(i == 1 && resultList.size() == 0){
                    sheet = excelUtil.export(wb, workSheetName, titles, sheet);
                    break;
                }
                start = i * limit;
                LOGGER.info("downMerchProdTradeLogCallTimes resultList.size()=" + resultList.size());
                int rowNum = 0;
                if (i != 1) {
                    rowNum = (i - 1) * limit;
                }
                sheet = excelUtil.export(wb, outputStream, workSheetName, titles,
                        properties, resultList, "", CreditCallTimesGather.class, sheet,  rowNum);
                if (resultList.size() < limit) {// 最后一批则跳出循环
                    break;
                }
            }
            wb.write(outputStream);
            wb.dispose();
        } catch (Exception e) {
            LOGGER.error("downMerchProdTradeLogCallTimes create result excel error,{}", e);
        } finally {
            try {
                outputStream.flush();
                outputStream.close();
            } catch (IOException e) {
                LOGGER.error("downMerchProdTradeLogCallTimes error,{}", e);
            }
        }
        UploadFile uploadfile = new UploadFile();
        uploadfile.setPathname(pathName);
        uploadfile.setOriginalName(originalName);
        uploadfile.setVersion("2.0");
        uploadfile.setTemp(true);
        LOGGER.info("ending downMerchProdTradeLogCallTimes download end.");
        String endDate = sdf.format(new Date());
        return uploadfile;
    }

    @Override
    public UploadFile downTradeLogCallTimes(List<CreditCallTimesGather> callTimesGatherList, String[] titles, String[] properties,  String fileName) {
        LOGGER.info("start downTradeLogCallTimes start.");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        ExcelUtil excelUtil = new ExcelUtil();
        String startDate = sdf.format(new Date());
        LOGGER.info("startDate=" + startDate);
        String path = ConfigUtil.getString("app.credit.downloadpath");
        String date = (new SimpleDateFormat("yyyyMMddHHmmSS")).format(new Date());
        String month = date.substring(0, 6);
        String day = date.substring(6, 14);
        String randomStr = String.valueOf((int)(1000000+Math.random()*9900000));
        String name = "/AccessDetailQueryResult/" + month + "/"+ fileName + "_"+ day +randomStr + ".xlsx";
        String dir = path + name;
        String pathName = "/accessDetail" + name;
        String originalName = fileName + ".xlsx";
        OutputStream outputStream = null;
        String workSheetName = fileName;
        int start = 0;
        int limit = 5000000;
        try {
            File file = new File(dir);
            if (!file.getParentFile().exists()) {
                if (!file.getParentFile().mkdirs()) {
                }
            }
            if (!file.exists()) {
                file.createNewFile();
            }
            outputStream = new FileOutputStream(file);
            SXSSFWorkbook wb = new SXSSFWorkbook(500);//// 创建工作薄
            Sheet sheet = null;//// 声明工作表
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            for (int i = 1;; i++) {
                if(i == 1 && callTimesGatherList.size() == 0){
                    sheet = excelUtil.export(wb, workSheetName, titles, sheet);
                    break;
                }
                start = i * limit;
                LOGGER.info("downTradeLogCallTimes resultList.size()=" + callTimesGatherList.size());
                int rowNum = 0;
                if (i != 1) {
                    rowNum = (i - 1) * limit;
                }
                sheet = excelUtil.export(wb, outputStream, workSheetName, titles,
                        properties, callTimesGatherList, "", CreditCallTimesGather.class, sheet,  rowNum);
                if (callTimesGatherList.size() < limit) {// 最后一批则跳出循环
                    break;
                }
            }
            wb.write(outputStream);
            wb.dispose();
        } catch (Exception e) {
            LOGGER.error("downTradeLogCallTimes create result excel error,{}", e);
        } finally {
            try {
                outputStream.flush();
                outputStream.close();
            } catch (IOException e) {
                LOGGER.error("downTradeLogCallTimes error,{}", e);
            }
        }
        UploadFile uploadfile = new UploadFile();
        uploadfile.setPathname(pathName);
        uploadfile.setOriginalName(originalName);
        uploadfile.setVersion("2.0");
        uploadfile.setTemp(true);
        LOGGER.info("ending downTradeLogCallTimes download end.");
        String endDate = sdf.format(new Date());
        return uploadfile;
    }

    @Override
    public int queryProdTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam) {
        return creditLogFacade.queryProdTradeLogCallTimesGatherListCount(queryParam);
    }

    @Override
    public List<CreditCallTimesGather> queryProdTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam) {
        List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
        try {
            CreditResponseData<List<CreditCallTimesGather>> responseData = creditLogFacade.queryProdTradeLogCallTimesGatherList(queryParam);
            if(null != responseData && responseData.isSuccess()){
                callTimesGatherList = responseData.getData();
            }else{
                LOGGER.info("creditDealFlowFacade.queryMerchProdStepTradeLogCallTimesGatherList failed, {}", GsonUtil.getInstance().toJson(responseData) );
            }
        } catch (Exception e) {
            LOGGER.info("queryMerchProdStepTradeLogCallTimesGatherList failed, {}", e );
        }
        return callTimesGatherList;
    }

    public List<CreditTradeLogInfo> selectTradeLogByParam(CreditLogQueryParam queryParam) {
        List<CreditTradeLogInfo> tradeLogInfoList = new ArrayList<CreditTradeLogInfo>();
        CreditResponseData<List<CreditTradeLogInfo>> respData = creditLogSearchFacade.queryScrollTradeLogList(queryParam);
        if(null!=respData && respData.isSuccess() && CollectionUtils.isNotEmpty(respData.getData())){
            tradeLogInfoList = respData.getData();
            LOGGER.info("selectTradeLogByParam- creditLogSearchFacade.queryScrollTradeLogList success, responseData size : {},", respData.getData().size());
        }else{
            LOGGER.info("selectTradeLogByParam- creditLogSearchFacade.queryScrollTradeLogList failed.");
        }
        return tradeLogInfoList;
    }


}
