package com.wangyin.boss.credit.admin.service;

import java.util.List;

import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategyAllow;

/**
 * 计费策略服务类
 * Created by wyhaozhihong on 2016/6/29.
 */

public interface CreditProductStrategyService {
	
	/**
	 * 新增计费策略数据
	 * @param record
	 * @return
	 */
    int insert(CreditProductStrategy record);

    /**
     * 根据查询条件查询计费策略数据 分页
     * @param creditProductStrategy
     * @return
     */
	List<CreditProductStrategy> selectByParam(CreditProductStrategy creditProductStrategy);
	
	/**
	 * 根据查询条件 查询计费策略总条数
	 * @param creditProductStrategy
	 * @return
	 */
	int selectCountByParam(CreditProductStrategy creditProductStrategy);
	
	/**
	 * 根据主键操作计费策略信息
	 * @param creditProductStrategy
	 * @return
	 */
	int updateByPrimaryKey(CreditProductStrategy creditProductStrategy);
	
	/**
	 * 根据主键删除数据
	 * @author wyhaozhihong
	 * @param strategyId
	 * @return
	 */
	int deleteByStrategyId(Integer strategyId);
	
	/**
	 * 根据主键查询计费策略信息
	 * @author wyhaozhihong
	 * @param strategyId
	 * @return
	 */
	CreditProductStrategy selectByStrategyId(Integer strategyId);
	
	/**
	 * 根据主键修改计费策略信息
	 * @author wyhaozhihong
	 * @param creditProductStrategy
	 * @return
	 */
	int updateByStrategyId(CreditProductStrategy creditProductStrategy);

	List<CreditProductStrategy> selectBatchByPrimaryKey(List<String> strategyIds);
	
	/**
	 * 根据条件查询商户维度的 计费信息 分页
	 * @param creditProductStrategy
	 * @return
	 */
	List<CreditProductStrategyAllow> selectMerchantStrategyByParam(CreditProductStrategyAllow creditProductStrategy);
	
	/**
	 * 根据条件查询商户维度的 计费信息 总条数
	 * @param creditProductStrategy
	 * @return
	 */
	int selectMerchantStrategyCountByParam(CreditProductStrategy creditProductStrategy);

	/**
	 * 关联商户账务表查询商户余量   分页
	 * @param creditProductStrategy
	 * @return
	 */
	List<CreditProductStrategyAllow> selectMercAllowanceByParam(CreditProductStrategyAllow creditProductStrategy);

	/**
	 * 关联商户账务表查询商户余量   分页信息
	 * @param creditProductStrategy
	 * @return
	 */
	int selectMercAllowanceCountByParam(CreditProductStrategy creditProductStrategy);

	/**
	 * 根据商户号查询计费策略list
	 * @param cps
	 * @return
	 */
	List<CreditProductStrategy> selectByMerchantNo(CreditProductStrategy cps);
	
	/**
	 * 根据条件更新计费的状态
	 * @param creditProductStrategy 服务产品计费策略实体
	 * @return
	 */
	int updateStatusForClose(CreditProductStrategy creditProductStrategy);

	/**
	 * 根据参数查询计费list 带征信类型参数
	 * @param productStrategy
	 * @return
	 */
	List<CreditProductStrategy> selectStrategyListByParam(CreditProductStrategy productStrategy);
	/**
	 * 根据参数查询计费list 并根据productId\merchantId去重复
	 * @param productStrategy
	 * @return
	 */
	List<CreditProductStrategy> selectDisStrategyListByParam(CreditProductStrategy productStrategy);

	/**
	 * 根据productId\merchantId\productType  查询计费list 带征信类型参数
	 * @param productStrategy
	 * @return
	 */
	List<CreditProductStrategy> selectStrategyListByProMerId(CreditProductStrategy productStrategy);

}
