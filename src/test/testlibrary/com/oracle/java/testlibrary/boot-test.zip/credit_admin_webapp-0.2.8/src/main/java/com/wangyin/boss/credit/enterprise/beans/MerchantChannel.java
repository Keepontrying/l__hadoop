package com.wangyin.boss.credit.enterprise.beans;

import java.io.Serializable;
import java.util.Date;

import com.wangyin.operation.common.beans.PageQuery;

/**
 * @author fangzhigang
 * @data 20181226
 */
public class MerchantChannel extends PageQuery implements Serializable {

	private static final long serialVersionUID = 1L;
	private String loginName;//主键Id
    private String merchantName;//商户名称
    private String merchantNo;//商户号
    private String productCode;//产品编码
    private String productName;//产品名称
    private String creator;//创建人
    private String modifier;//修改人
    private Date createdDate;//创建时间
    private Date modifiedDate;//修改时间
    
    private String insCode;//产品实例Id
    private String insName;//产品实例名称
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getModifier() {
		return modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getInsCode() {
		return insCode;
	}
	public void setInsCode(String insCode) {
		this.insCode = insCode;
	}
	public String getInsName() {
		return insName;
	}
	public void setInsName(String insName) {
		this.insName = insName;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getMerchantNo() {
		return merchantNo;
	}
	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
