package com.wangyin.boss.credit.admin.controller;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wangyin.commons.util.Logger;
import com.wangyin.operation.beans.UserModel;

public class BaseController {
	
	private static final Logger LOGGER = new Logger();
	/**
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toPage.view")
	public Map<String, String> toPage(@RequestParam Map<String, String> map) {
		return map;
	}
	
	/**
	 * 通过单点获取到当前登录人名称
	 * @author wyhaozhihong
	 * @param user
	 * @return
	 * @throws Exception 
	 */
	public String getLoginRealName(String user) throws Exception{
		//userName是登录名,RealName是中文别名,getLoginRealName()返回的是userName
		if(StringUtils.isNotBlank(user)){
			UserModel userModel = new UserModel(user);
			if(StringUtils.isNotBlank(userModel.getUserName())){
				return userModel.getUserName();
			}else{
				throw new Exception("无法获取当前登登录人信息");
			}
		}else{
			throw new Exception("无法获取登录人信息");
		}
	}
	
	@ExceptionHandler
    @ResponseBody
    public Object excepResponse(Throwable e) {
        
		LOGGER.warn("exception:", e);
		return new Exception("System Exception! ");
    }
	
}
