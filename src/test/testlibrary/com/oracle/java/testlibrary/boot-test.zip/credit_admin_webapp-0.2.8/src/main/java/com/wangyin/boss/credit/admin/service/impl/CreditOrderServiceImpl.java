package com.wangyin.boss.credit.admin.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;

import com.jd.jr.boss.credit.domain.common.enums.*;
import com.wangyin.boss.credit.admin.enums.EnterpriseProductEnum4Common;
import com.wangyin.boss.credit.admin.enums.MerchantClassifyEnum;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrderMain;
import com.jd.jr.boss.credit.facade.authen.api.CreditOrderFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.MainOrderQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.SubOrderQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.beans.param.OrderPageQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import com.wangyin.boss.credit.admin.enums.CreditMerchantTypeEnum;
import com.wangyin.boss.credit.admin.service.CreditOrderService;
import com.wangyin.boss.credit.admin.service.CreditProductStrategyService;
import com.wangyin.boss.credit.enterprise.constants.SpecialProductConstant;

/**
 * Created by anmeng on 2017/3/24.
 */
@Service
public class CreditOrderServiceImpl implements CreditOrderService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CreditOrderServiceImpl.class);

    @Resource
    private CreditOrderFacade creditOrderFacade;

    @Resource
    private CreditProductStrategyService creditProductStrategyService;

    @Override
    public void createOffLineOrder(CreditOrderMain orderMain) {

        orderMain.setOrderSource(MainOrderSourceEnum.OFFLINE);
        orderMain.setOrderOwnedType(CreditMerchantTypeEnum.ENTERPRISE.toName());
        orderMain.setPayType(CreditOrderPayTypeEnum.REMIT);

        //对于自定义包，更新总价格和包的次数
        List<CreditOrder> subOrderList=orderMain.getSubOrderList();
        for(CreditOrder subOrder:subOrderList){
            Integer strategyId=subOrder.getStrategyId();
            CreditProductStrategy productStrategy=creditProductStrategyService.selectByStrategyId(strategyId);
            if(ProductChargeTypeEnum.CUSTOM.toName().equals(productStrategy.getChargeType())){
                if(subOrder.getQuantity()==null){
                    throw new RuntimeException("定制包订购数量不能为空！");
                }
                Integer quantity=subOrder.getQuantity();
                Long price=productStrategy.getPrice();
                Long amount=quantity*price;
                productStrategy.setAmount(amount);
                productStrategy.setPacketCount(quantity);
                creditProductStrategyService.updateByStrategyId(productStrategy);
            }
//            subOrder.setFreeTime(productStrategy.getFreeTimes());
            subOrder.setUnitPrice(productStrategy.getPrice());
            subOrder.setMerchantNo(productStrategy.getMerchantNo());
            subOrder.setExpiredTime(productStrategy.getFinishTime());
            subOrder.setValidTime(productStrategy.getStartTime());
            subOrder.setCreator(orderMain.getCreator());
            subOrder.setModifier(orderMain.getModifier());
            subOrder.setOrderAmount(productStrategy.getAmount());
            subOrder.setQuantity(productStrategy.getPacketCount());
            subOrder.setSource(CreditOrderSourceEnum.MANUAL);
            subOrder.setStrategyChargeType(ProductChargeTypeEnum.enumValueOf(productStrategy.getChargeType()));
            subOrder.setVipMonitorFlag(productStrategy.getVipMonitorFlag());//添加vip监控标识
            subOrder.setPurchaseType(CreditPurchaseTypeEnum.getEnumByCode(productStrategy.getPurchaseType()));
            subOrder.setProductId(productStrategy.getProductId());
        	subOrder.setProductName(productStrategy.getProductName());
        	if(subOrder.getProductName().equalsIgnoreCase(EnterpriseProductEnum4Common.ENTERPRISE_MINI_DUE.toDescription())
        			&& StringUtils.isNotBlank(productStrategy.getRemarks())
        			&& productStrategy.getRemarks().contains("+")){
        		subOrder.setMiniCompletionPriceType(productStrategy.getRemarks());
        	}
        	
        }
        
        CreditRequestParam<CreditOrderMain> requestParam=new CreditRequestParam<CreditOrderMain>();
        CreditResponseData<CreditOrderMain> responseData = new CreditResponseData<CreditOrderMain>();
        try {
        	//调用authen保存订单
            requestParam.setParam(orderMain);
            responseData = creditOrderFacade.createOrder(requestParam);
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info("createOffLineOrder failed," , e);
		}

        if(!responseData.isSuccess()){
            throw new RuntimeException("操作接口异常："+ responseData.getMessage());
        }


    }

    @Override
    public CreditPage<CreditOrderMain> queryCreditOrderMain(OrderPageQueryParam queryParam) {
        DateFormat dateDF=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        MainOrderQueryParam orderQuery=new MainOrderQueryParam();
        orderQuery.setStart(queryParam.getStart());
        orderQuery.setLimit(queryParam.getLimit());
        orderQuery.setBeginTime(queryParam.getStartCreateDate());
        orderQuery.setEndTime(queryParam.getEndCreateDate());
        orderQuery.setMerchantNo(queryParam.getMerchantNo());
        orderQuery.setMerchantName(queryParam.getMerchantName());
        orderQuery.setOrderMainNo(queryParam.getOrderNo());
        orderQuery.setOrderSource(queryParam.getOrderSource());
        orderQuery.setOrderStatus(queryParam.getOrderStatus());
        orderQuery.setMerchantClassify(queryParam.getMerchantClassify());
        if(CreditYesOrNoEnum.YES.toName().equalsIgnoreCase(queryParam.getSignStatus())){//已签约：非测试商户且有合同,学帅说 未归类属于未签约
            List<String> merchantClassifyList = new ArrayList<String>();
            merchantClassifyList.add(MerchantClassifyEnum.FINANCE.getCode());
            merchantClassifyList.add(MerchantClassifyEnum.NON_FINANCE.getCode());
            merchantClassifyList.add(MerchantClassifyEnum.JUSTICE_DEPARTMENT.getCode());
            merchantClassifyList.add(MerchantClassifyEnum.OTHER.getCode());
            orderQuery.setMerchantClassifyList(merchantClassifyList);
        }else if(CreditYesOrNoEnum.NO.toName().equalsIgnoreCase(queryParam.getSignStatus())){
            List<String> merchantClassifyList = new ArrayList<String>();
            merchantClassifyList.add(MerchantClassifyEnum.TEST.getCode());
            merchantClassifyList.add(MerchantClassifyEnum.WAIT.getCode());
            orderQuery.setMerchantClassifyList(merchantClassifyList);
        }
        CreditPage<CreditOrderMain> responseData=creditOrderFacade.queryOrderMain(orderQuery);
        return responseData;
    }

    @Override
    public CreditOrderMain queryOrderMainDetail(Integer orderMainId) {
        CreditRequestParam<CreditOrderMain> requestParam=new CreditRequestParam<CreditOrderMain>();
        CreditOrderMain orderMain=new CreditOrderMain();
        orderMain.setOrderMainId(orderMainId);
        requestParam.setParam(orderMain);
        CreditResponseData<CreditOrderMain> responseData= creditOrderFacade.queryMainOrderDetail(requestParam);
        return responseData.getData();
    }

    @Override
    public void confirmReceive(Integer orderMainId) {
        CreditRequestParam<CreditOrderMain> requestParam=new CreditRequestParam<CreditOrderMain>();
        CreditOrderMain orderMain=new CreditOrderMain();
        orderMain.setOrderMainId(orderMainId);
        requestParam.setParam(orderMain);
        creditOrderFacade.offLinePayConfirm(requestParam);
    }

    @Override
    public CreditPage<CreditOrder> querySubOrder(SubOrderQueryParam requestParam) {
        return creditOrderFacade.querySubOrder(requestParam);
    }

	@Override
	public List<CreditOrder> queryContractOrder(SubOrderQueryParam orderQueryParam) {
		return creditOrderFacade.queryContractOrder(orderQueryParam);
	}

	@Override
	public List<CreditContract> queryContractByOrderInfo(SubOrderQueryParam requestParam) {
		return creditOrderFacade.queryContractByOrderInfo(requestParam);
	}

}
