package com.wangyin.boss.credit.admin;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wangyin.boss.credit.admin.dao.CreditProductStrategyMapper;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import com.wangyin.boss.credit.admin.service.CreditProductStrategyService;

/**
 * 产品计费测试类
 * 
 * @author wyhaozhihong
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:applicationContext.xml" })
public class CreditProductStrategyTest {

	@Autowired
	CreditProductStrategyService creditProductStrategyService;
	
	@Autowired
	CreditProductStrategyMapper creditProductStrategyMapper;
	
	@Test
	public void creditProductStrateTest(){
		CreditProductStrategy record = new CreditProductStrategy();
		record.setProductName("身份证认证");
		record.setChargeType("package");
		record.setAmount(100L);
		record.setPacketCount(10);
		
		/*默认值*/
		record.setCreator("system");
		record.setCreatedDate(new Date());
		record.setModifier("system");
		record.setModifiedDate(new Date());
		
		
		/*隐藏域*/
		record.setProductId(1);
		record.setMerchantNo("111222");
		record.setMerchantName("hzhtest");
		
		/*设置默认值，创建完合同后需要更新成具体值*/
		record.setContractId(0);
		record.setMerchantId(0);
		
		/*待确认*/
		record.setStrategyStatus("open");
		record.setPrice(0L);
		record.setStartTime(new Date());
		record.setFinishTime(new Date());
		
		creditProductStrategyService.insert(record);
	}
	
	@Test
	public void selectByParam(){
		CreditProductStrategy creditProductStrategy = new CreditProductStrategy();
		creditProductStrategy.setStart("0");
		creditProductStrategy.setLimit("10");
		String[] s = "&33&32&31".substring(1).split("&");
		creditProductStrategy.setStrategyIds(Arrays.asList(s));
		List<CreditProductStrategy> list = creditProductStrategyMapper.selectByParam(creditProductStrategy);
		int count = creditProductStrategyMapper.selectCountByParam(creditProductStrategy);
		System.out.println(list.size());
	}
	
	@Test
	public void bathTest(){
		CreditProductStrategy creditProductStrategy = new CreditProductStrategy();
		String[] strategyIds = new String[]{"7","8"};
		creditProductStrategy.setStrategyIds(Arrays.asList(strategyIds));
		creditProductStrategy.setStrategyStatus("open");
		//creditProductStrategyMapper.updateBatchByPrimaryKeySelective(creditProductStrategy);
		
		List<CreditProductStrategy> list = creditProductStrategyMapper.selectBatchByPrimaryKey(Arrays.asList(strategyIds));
		System.out.println(list.size());
	}

}
