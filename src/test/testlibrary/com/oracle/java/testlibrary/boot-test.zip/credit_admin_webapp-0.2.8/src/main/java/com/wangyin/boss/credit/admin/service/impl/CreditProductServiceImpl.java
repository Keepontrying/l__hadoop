package com.wangyin.boss.credit.admin.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.facade.authen.api.CreditProductFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.ProductQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.dao.CreditProductMapper;
import com.wangyin.boss.credit.admin.entity.CreditProduct;
import com.wangyin.boss.credit.admin.service.CreditProductService;

@Service
public class CreditProductServiceImpl implements CreditProductService {
	
	@Autowired
	private CreditProductMapper creditProductMapper;

	@Resource
	private CreditProductFacade creditProductFacade;
	
	@Override
	public List<CreditProduct> select(CreditProduct cp) {
		return creditProductMapper.select(cp);
	}

	@Override
	public int selectCount(CreditProduct cp) {
		return creditProductMapper.selectCount(cp);
	}

	@Override
	public List<CreditProduct> selectAvailableCreditProductToItem() {
		return creditProductMapper.selectAvailableCreditProductToItem();
	}

	@Override
	public List<CreditProduct> queryEnterpriseProduct(CreditProduct cp) {
		return creditProductMapper.queryEnterpriseProduct(cp);
	}

	@Override
	public List<CreditProduct> queryProductListByPrm(ProductQueryParam productQryPrm) {
		CreditRequestParam<ProductQueryParam> queryParam = new CreditRequestParam<ProductQueryParam>();
		queryParam.setParam(productQryPrm);
		CreditResponseData<List<CreditProduct>> responseData = creditProductFacade.queryProductListByPrm(queryParam);
		if(null != responseData && responseData.isSuccess() && CollectionUtils.isNotEmpty(responseData.getData())){
			return responseData.getData();
		}else{
			return null;
		}
	}

}
