package com.wangyin.boss.credit.enterprise.service.impl;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.enterprise.constants.HspConstant;
import com.wangyin.boss.credit.enterprise.service.HspService;
import com.wangyin.hsp.client.HSPClient;
import com.wangyin.hsp.client.HSPConfig;

/** 
* @desciption : 
* @author : yangjinlin@jd.com
* @date ：2017年10月24日 下午4:18:57 
* @version 1.0 
* @return  */
@Service
public class HspServiceImpl implements HspService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(HspServiceImpl.class);

	@Override
	public String createHspUrlByFid(String hspFid, String filename) {
		if(StringUtils.isBlank(hspFid) || StringUtils.isBlank(filename)){
			return null;
		}
		String connectString = ConfigUtil.getString(HspConstant.HSP_CONNECT_STRING);
		int appid = Integer.valueOf(ConfigUtil.getString(HspConstant.HSP_PORTAL_APPID));
		String apppwd = ConfigUtil.getString(HspConstant.HSP_PORTAL_APPPWD);
		String httpServerUrl = ConfigUtil.getString(HspConstant.HSP_HTTPSERVER_URL);
		HSPConfig hspConfig = new HSPConfig(connectString, appid, apppwd);
		hspConfig.setHttpServerUrl(httpServerUrl);
		HSPClient hspClient = new HSPClient(hspConfig);
		String hspUrl = ""; 
		try {
			hspUrl = hspClient.getUrl(hspFid, 0, filename);//
			LOGGER.info("----fid: " + hspFid + ", url: "+hspUrl);
	    } catch (Exception e) {
	        e.printStackTrace();
	        LOGGER.debug("[createHspUrlByFid] fail, fid:"+hspFid);
	    }
		return hspUrl;
	}

	
	
}
