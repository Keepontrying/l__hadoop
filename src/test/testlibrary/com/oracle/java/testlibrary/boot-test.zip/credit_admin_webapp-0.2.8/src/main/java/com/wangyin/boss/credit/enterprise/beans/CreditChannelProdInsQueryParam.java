package com.wangyin.boss.credit.enterprise.beans;

import java.io.Serializable;
import java.util.Date;

import com.wangyin.operation.common.beans.PageQuery;

/**
 * Description: 渠道产品实例查询入参
 * User: yangjinlin@jd.com
 * Date: 2018/9/10 15:29
 * Version: 1.0
 */
public class CreditChannelProdInsQueryParam extends PageQuery implements Serializable {

	private static final long serialVersionUID = 4759490869079972819L;
	private Integer insId;//主键Id
    private String insCode;//产品实例Id
    private String insName;//产品实例名称
    private String productCode;//产品编码
    private Integer weight;//权重
    private String insStatus;//产品实例状态
    private Date createdDate;//创建时间
    private Date modifiedDate;//修改时间
    
    private String merchantName;//商户名称
    private String merchantNo;//商户号


    private Integer currentPage=1;//当前页码
    //创建开始时间,查询条件中时间控件输入框使用
    private String startCreateDateStr;
    //创建结束时间,查询条件中时间控件输入框使用
    private String endCreateDateStr;

    public Integer getInsId() {
        return insId;
    }

    public void setInsId(Integer insId) {
        this.insId = insId;
    }

    public String getInsCode() {
        return insCode;
    }

    public void setInsCode(String insCode) {
        this.insCode = insCode;
    }

    public String getInsName() {
        return insName;
    }

    public void setInsName(String insName) {
        this.insName = insName;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public String getInsStatus() {
        return insStatus;
    }

    public void setInsStatus(String insStatus) {
        this.insStatus = insStatus;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getStartCreateDateStr() {
        return startCreateDateStr;
    }

    public void setStartCreateDateStr(String startCreateDateStr) {
        this.startCreateDateStr = startCreateDateStr;
    }

    public String getEndCreateDateStr() {
        return endCreateDateStr;
    }

    public void setEndCreateDateStr(String endCreateDateStr) {
        this.endCreateDateStr = endCreateDateStr;
    }

    @Override
    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getMerchantNo() {
		return merchantNo;
	}

	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}
}
