package com.wangyin.boss.credit.admin;

import static junit.framework.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.boss.credit.admin.service.CreditUserService;

/**
 * @author jiangbo
 * @since 2017/3/20
 */
public class CreditUserTest extends BaseTest{

    @Autowired
    CreditUserService creditUserService;
    /**
     * <p>
     * 添加：2017-01-13
     * </p>
     * 用途：TODO
     *
     */
    @Before
    public void setUp() {
    }

    /**
     * <p>
     * 添加：2017-01-13
     * </p>
     * 用途：TODO
     *
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
    }

    /**
     * Test method for
     * {@link CreditUserService}
     * @throws Exception
     */
    @Test
    public void testSelectCreditUserByParam() throws Exception {
        CreditUser creditUser = new CreditUser();
        creditUser.setUserStatus("OPEN");

        System.out.println(creditUserService.selectCreditUserByParam(creditUser));
        assertTrue(true);
    }


}
