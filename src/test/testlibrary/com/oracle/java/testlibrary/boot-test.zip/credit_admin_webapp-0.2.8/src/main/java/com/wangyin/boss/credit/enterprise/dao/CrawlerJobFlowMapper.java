package com.wangyin.boss.credit.enterprise.dao;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobFlow;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResultsQueryParam;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2018/11/28
 */
@SqlMapper
@Component
public interface CrawlerJobFlowMapper {

    Long insertOrUpadte(CrawlerJobFlow flow);

    List<CrawlerJobFlow> queryList(CrawlerJobResultsQueryParam param);
}
