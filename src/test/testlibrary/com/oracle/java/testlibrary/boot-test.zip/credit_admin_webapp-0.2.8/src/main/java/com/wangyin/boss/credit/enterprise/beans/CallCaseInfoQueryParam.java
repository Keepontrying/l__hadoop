package com.wangyin.boss.credit.enterprise.beans;

import java.io.Serializable;

/**
 * Description: 调用量分情况查询入参
 * User: yangjinlin@jd.com
 * Date: 2018/5/11 17:59
 * Version: 1.0
 */
public class CallCaseInfoQueryParam implements Serializable {


    private String merchantNo;
    private String merchantName;
    private String productNo;
    private String productName;
    private String beginDate;
    private String endDate;

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getProductNo() {
        return productNo;
    }

    public void setProductNo(String productNo) {
        this.productNo = productNo;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
}
