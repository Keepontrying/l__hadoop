package com.wangyin.boss.credit.admin.publicSentiment;

import com.jdjr.fmq.common.message.Message;
import com.wangyin.boss.credit.enterprise.fmq.CrawlerJobListener;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2018/12/3
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class CrawlerJobListenerTest {

    @Resource
    private CrawlerJobListener listener;

    @Test
    public void test() throws Exception {
        List<Message> messageList = new ArrayList<>();
        Message message = new Message();
        String str = "	{\"code\":\"0000\",\"msg\":\"\",\"param\":{\"taskId\":\"42\",\"taskNo\":\"LS154354856542442\"},\"time\":\"2018-12-03 16:59:30\"}";
        message.setText(str);
        messageList.add(message);
        listener.onMessage(messageList);
    }

}
