package com.wangyin.boss.credit.admin.dao;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditCost;
import com.wangyin.boss.credit.admin.entity.CreditProductBlack;
import com.wangyin.boss.credit.admin.entity.CreditProductBlackHistory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/** 
* @desciption : 产品黑名单历史配置 mapper映射类
* @author : liuwei55@jd.com
* @date ：2017年4月10日 下午20:46:58
* @version 1.0 
* @return  */

@SqlMapper
@Component
public interface CreditProductBlackHistoryMapper {

	/**
     * 插入产品黑名单历史配置
     * @param creditProductBlackHistory
     * @return
     */
	int addCreProdBlackHistory(CreditProductBlackHistory creditProductBlackHistory);
	/**
	 *@desc 根据查询blackId  产品黑名单历史配置  分页
	 *@Author liuwei55@jd.com
	 *@Date 2017/4/10 20:39
	 */
	List<CreditProductBlackHistory> selectCreProdBlHisByBlackId(Map<String,Object> map);
	/**
	 * 根据查询条件查询  产品黑名单配置  总条数
	 * @return
	 */
	int selectCountHisByBlackId(Map<String,Object> map);

}
