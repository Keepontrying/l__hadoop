package com.wangyin.boss.credit.admin.service;

import java.text.ParseException;
import java.util.List;

import com.wangyin.boss.credit.admin.entity.CreditCost;

/**
 * 接口成本配置服务类
 * @author wyhaozhihong
 *
 */
public interface CreditCostService {
	
	/**
	 * 根据条件查询 接口成本配置 分页
	 * @param creditCost
	 * @return
	 */
	List<CreditCost> selectByParam(CreditCost creditCost);
	
	/**
	 * 根据条件查询 接口成本配置总条数
	 * @param creditCost
	 * @return
	 */
	int selectCountByParam(CreditCost creditCost);
	
	/**
	 * 新增数据
	 * @param creditCost
	 * @return
	 * @throws ParseException 
	 */
	int insert(CreditCost creditCost) throws ParseException;
	
	/**
	 * 更新数据
	 * @param creditCost1
	 */
	int update(CreditCost creditCost1);

}
