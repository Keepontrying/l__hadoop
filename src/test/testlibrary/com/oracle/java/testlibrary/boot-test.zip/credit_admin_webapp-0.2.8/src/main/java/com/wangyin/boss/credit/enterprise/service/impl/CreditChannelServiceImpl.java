package com.wangyin.boss.credit.enterprise.service.impl;

import com.wangyin.admin.frame.utils.JSONUtils;
import com.wangyin.boss.credit.enterprise.beans.CreditChannelQueryParam;
import com.wangyin.boss.credit.enterprise.dao.CreditChnChannelMapper;
import com.wangyin.boss.credit.enterprise.entity.CreditChnChannel;
import com.wangyin.boss.credit.enterprise.service.CreditChannelService;
import com.wangyin.operation.common.beans.PageResult;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;

@Service
public class CreditChannelServiceImpl implements CreditChannelService {
    private static Logger logger = LoggerFactory.getLogger(CreditChannelServiceImpl.class);

    @Autowired
    CreditChnChannelMapper creditChnChannelMapper;

    @Override
    public PageResult<CreditChnChannel> queryChannelList(CreditChannelQueryParam creditChannelQueryParam) {
        logger.info("数据渠道查询参数：" + JSONUtils.toJSON(creditChannelQueryParam));
        PageResult<CreditChnChannel> pageResult = new PageResult<>();
        try {
            int count = creditChnChannelMapper.selectForCount(creditChannelQueryParam);
            List<CreditChnChannel> rows = creditChnChannelMapper.selectForList(creditChannelQueryParam);

            pageResult.setTotal(count);
            pageResult.setSuccess(true);
            pageResult.setRows(rows);
            pageResult.setMessage(ResponseMessage.SUCCESS.getDesc());

        } catch (Exception e) {
            logger.error(e.getMessage());
            pageResult.setSuccess(false);
            pageResult.setMessage(e.getMessage());
        }

        return pageResult;
    }

    @Override
    public Map<String, Object> saveOrUpdate(CreditChannelQueryParam creditChannelQueryParam) {
        logger.info("更新数据渠道参数："+JSONUtils.toJSON(creditChannelQueryParam));
        Map<String, Object> result = new HashMap<>();
        int i = 0;
        if (StringUtils.isEmpty(creditChannelQueryParam.getChannelId())) {
            //插入
            CreditChnChannel creditChnChannel = new CreditChnChannel();
            BeanUtils.copyProperties(creditChannelQueryParam, creditChnChannel);
            creditChnChannel.setCreatedDate(new Date());
            i= creditChnChannelMapper.insertSelective(creditChnChannel);
        }else{
            CreditChnChannel creditChnChannel = new CreditChnChannel();
            BeanUtils.copyProperties(creditChannelQueryParam, creditChnChannel);
            creditChnChannel.setModifier(creditChannelQueryParam.getCreator());
            i = creditChnChannelMapper.updateByPrimaryKeySelective(creditChnChannel);
        }

        if (i > 0) {
            result.put("success", true);
            result.put("message", ResponseMessage.SUCCESS.getDesc());
        }else {
            result.put("success", false);
            result.put("message", ResponseMessage.PARAM_IS_REQUIRED.getDesc());
        }
        return result;
    }

    @Override
    public Map<String, Object> queryChannelInfoById(CreditChannelQueryParam creditChannelQueryParam) {
        logger.info("查询数据渠道参数："+JSONUtils.toJSON(creditChannelQueryParam));
        Map<String, Object> result = new HashMap<>();
        List<CreditChnChannel> rows = creditChnChannelMapper.selectForList(creditChannelQueryParam);

        if (CollectionUtils.isEmpty(rows) || rows.size() != 1) {
            result.put("success", false);
            result.put("message", ResponseMessage.PARAM_ILLEGAL.getDesc());
        } else {
            result.put("success", true);
            result.put("message", ResponseMessage.SUCCESS.getDesc());
            result.put("channelId", rows.get(0).getChannelId());
            result.put("channelName", rows.get(0).getChannelName());
            result.put("channelSubject", rows.get(0).getChannelSubject());
            result.put("remark", rows.get(0).getRemark());
        }
        return result;

    }
}
