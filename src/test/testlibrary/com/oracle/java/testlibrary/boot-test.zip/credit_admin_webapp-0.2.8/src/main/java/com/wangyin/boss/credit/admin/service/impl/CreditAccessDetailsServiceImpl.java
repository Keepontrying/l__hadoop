package com.wangyin.boss.credit.admin.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.dao.CreditAccessDetailsMapper;
import com.wangyin.boss.credit.admin.entity.CreditAccessDetails;
import com.wangyin.boss.credit.admin.enums.AccessCallModeEnum;
import com.wangyin.boss.credit.admin.enums.AccessStatusEnum;
import com.wangyin.boss.credit.admin.enums.AccessStepStatusEnum;
import com.wangyin.boss.credit.admin.enums.ChargeTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditVipMonitorStatusEnum;
import com.wangyin.boss.credit.admin.enums.CreditYesFlagEnum;
import com.wangyin.boss.credit.admin.enums.VipMonitorFlagEnum;
import com.wangyin.boss.credit.admin.service.CreditAccessDetailsService;
import com.wangyin.boss.credit.admin.utils.ExcelUtil;
import com.wangyin.commons.util.Logger;
import com.wangyin.operation.beans.UploadFile;

/**
 * 
 * @author wyhaozhihong
 *
 */
@Service
public class CreditAccessDetailsServiceImpl implements CreditAccessDetailsService {
	
	private static final Logger LOGGER = new Logger();
	
	@Autowired
	CreditAccessDetailsMapper creditAccessDetailsMapper;

	@Override
	public List<CreditAccessDetails> selectByParam(CreditAccessDetails creditAccessDetails) {
		return creditAccessDetailsMapper.selectByParam(creditAccessDetails);
	}

	@Override
	public int selectCountByParam(CreditAccessDetails creditAccessDetails) {
		return creditAccessDetailsMapper.selectCountByParam(creditAccessDetails);
	}

	@Override
	public UploadFile downAccessDetailQueryResult(CreditAccessDetails creditAccessDetails) {
		LOGGER.info("start downAccessDetailQueryResult method");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		ExcelUtil excelUtil = new ExcelUtil();

		String startDate = sdf.format(new Date());
		LOGGER.info("startDate=" + startDate);

		String path = ConfigUtil
				.getString("app.credit.downloadpath");
		String date = (new SimpleDateFormat("yyyyMMddHHmmSS"))
				.format(new Date());
		String month = date.substring(0, 6);
		String day = date.substring(6, 14);
		String name = "/AccessDetailQueryResult/" + month + "/业务详单查询结果"
				+ day + ".xlsx";
		String dir = path + name;
		LOGGER.info("path=" + path + ",dir=" + dir);
		String pathName = "/accessDetail" + name;
		String originalName = "业务详单查询结果.xlsx";

		String[] titles = { "业务流水号","商户号","商户名称","产品名称","蓝鲸灵产品","业务状态","请求参数","返回参数","创建时间","响应时间","计费方式","详细状态","执行计费说明","接口请求流水号","底层接口返回码","调用模式"};
		String[] properties = { "tradeNo","merchantNo","merchantName", "productName", "vipMonitorFlag", "accessStatus", "requestParam", "responseParam", "createdDateStr", "responseTimeStr", "chargeType","stepStatus","remarks","requestNo","returnCode","callMode"}; 
		OutputStream outputStream = null;
		
		String workSheetName = "业务详单查询结果";

		int start = 0;
		int limit = 5000;
		
		creditAccessDetails.setStart(String.valueOf(start));
		creditAccessDetails.setLimit(String.valueOf(limit));
		
		try {
			File file = new File(dir);
			if (!file.getParentFile().exists()) {
				if (!file.getParentFile().mkdirs()) {
				}
			}
			if (!file.exists()) {
				file.createNewFile();
			}

			outputStream = new FileOutputStream(file);

			// 创建工作薄
			SXSSFWorkbook wb = new SXSSFWorkbook(500);

			// 声明工作表
			Sheet sheet = null;
			
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

			for (int i = 1;; i++) {
				List<CreditAccessDetails> resultList = selectByParam(creditAccessDetails);
				for (CreditAccessDetails accessDetail : resultList) {
					accessDetail.setAccessStatus(AccessStatusEnum.enumValueOf(accessDetail.getAccessStatus()).toDescription());
					accessDetail.setChargeType(ChargeTypeEnum.enumValueOf(accessDetail.getChargeType()).toDescription());
					accessDetail.setStepStatus(AccessStepStatusEnum.enumValueOf(accessDetail.getStepStatus()).toDescription());
					accessDetail.setCreatedDateStr(df.format(accessDetail.getCreatedDate()));
					accessDetail.setResponseTimeStr(df.format(accessDetail.getResponseTime()));
					accessDetail.setCallMode(AccessCallModeEnum.enumValueOf(accessDetail.getCallMode()).toDescription());
					accessDetail.setVipMonitorFlag(VipMonitorFlagEnum.enumValueOf(accessDetail.getVipMonitorFlag()).toDescription());
					//在excel中将空数据展示为 - 
					accessDetail.setMerchantNo(accessDetail.getMerchantNo() == null ? "-":accessDetail.getMerchantNo());
					accessDetail.setMerchantName(accessDetail.getMerchantName() == null ?"-":accessDetail.getMerchantName());
					accessDetail.setProductName(accessDetail.getProductName() == null ?"-":accessDetail.getProductName());
					accessDetail.setAccessStatus(accessDetail.getAccessStatus() == null ?"-":accessDetail.getAccessStatus());
					accessDetail.setRequestParam(accessDetail.getRequestParam() == null ? "-":accessDetail.getRequestParam());
					accessDetail.setResponseParam(accessDetail.getResponseParam() == null ?"-":accessDetail.getResponseParam());
					accessDetail.setChargeType(accessDetail.getChargeType() == null ?"-":accessDetail.getChargeType());
					accessDetail.setStepStatus(accessDetail.getStepStatus() == null ?"-":accessDetail.getStepStatus());
					accessDetail.setRemarks(accessDetail.getRemarks() == null ? "-":accessDetail.getRemarks());
					accessDetail.setRequestNo(accessDetail.getRequestNo() == null ? "-":accessDetail.getRequestNo());
					accessDetail.setReturnCode(accessDetail.getReturnCode() == null ?"-":accessDetail.getReturnCode());
					accessDetail.setCallMode(accessDetail.getCallMode() == null ?"-":accessDetail.getCallMode());
					accessDetail.setVipMonitorFlag(accessDetail.getVipMonitorFlag() == null ?"-":accessDetail.getVipMonitorFlag());
					
				}
				
				if(i == 1 && resultList.size() == 0){
					sheet = excelUtil.export(wb, workSheetName, titles, sheet);
					break;
				}
				
				start = i * limit;
				creditAccessDetails.setStart(String.valueOf(start));

				LOGGER.info("resultList.size()=" + resultList.size());
				int rowNum = 0;
				if (i != 1) {
					rowNum = (i - 1) * limit;
				}

				sheet = excelUtil.export(wb, outputStream, workSheetName, titles,
						properties, resultList, "", CreditAccessDetails.class, sheet,
						rowNum);

				if (resultList.size() < limit) {// 最后一批则跳出循环

					break;
				}

			}
			wb.write(outputStream);
			wb.dispose();
		} catch (Exception e) {
			LOGGER.error(e);
		} finally {
			try {
				outputStream.flush();
				outputStream.close();
			} catch (IOException e) {
				LOGGER.error("downAccessDetailQueryResult error, {}", e);
			}
		}

		UploadFile uploadfile = new UploadFile();
		uploadfile.setPathname(pathName);
		uploadfile.setOriginalName(originalName);
		uploadfile.setVersion("2.0");
		uploadfile.setTemp(true);

		LOGGER.info("ending downAccessDetailQueryResult download");

		String endDate = sdf.format(new Date());
		LOGGER.info("endDate=" + endDate);

		return uploadfile;
	}

	@Override
	public CreditAccessDetails selectAccessDetailById(CreditAccessDetails accessDetail) {
		
		return creditAccessDetailsMapper.selectAccessDetailById(accessDetail);
	}

}
