package com.wangyin.boss.credit.enterprise.dao;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.enterprise.beans.SensitiveWordGroup;
import com.wangyin.boss.credit.enterprise.beans.SensitiveWordQueryParam;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2018/11/19
 */
@SqlMapper
@Component
public interface SensitiveWordGroupMapper {

    Long insert(SensitiveWordGroup word);

    void update(SensitiveWordGroup word);

    Integer queryCount(SensitiveWordQueryParam param);

    List<SensitiveWordGroup> query(SensitiveWordQueryParam param);
}
