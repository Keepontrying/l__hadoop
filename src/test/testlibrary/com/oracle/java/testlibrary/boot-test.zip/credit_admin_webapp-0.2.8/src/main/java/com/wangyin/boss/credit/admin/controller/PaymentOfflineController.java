package com.wangyin.boss.credit.admin.controller;

import com.google.common.collect.Lists;
import com.jd.jr.boss.credit.domain.common.entity.CreditPaymentOffline;
import com.jd.jr.boss.credit.domain.common.entity.CreditPaymentOfflineRel;
import com.jd.jr.boss.credit.domain.common.entity.CreditPostBillMonth;
import com.jd.jr.boss.credit.domain.common.enums.PaymentOfflineSourceTypeEnum;
import com.jd.jr.boss.credit.domain.common.enums.PaymentOfflineStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.PostBillStatusEnum;
import com.jd.jr.boss.credit.facade.authen.beans.param.PaymentOfflineQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.PostBillQueryParam;
import com.jd.jr.boss.credit.facade.common.exception.CreditBusinessException;
import com.wangyin.boss.credit.admin.service.PaymentOfflineService;
import com.wangyin.boss.credit.admin.service.PostBillService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.beans.ErrorMessage;
import com.wangyin.operation.common.beans.Page;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by anmeng on 2017/9/14.
 */
@Controller
@RequestMapping("/paymentOffline")
public class PaymentOfflineController extends BaseController{
    private Logger logger= LoggerFactory.getLogger(PaymentOfflineController.class);

    @Resource
    private PaymentOfflineService paymentOfflineService;

    @Resource
    private PostBillService postBillService;

    @ResponseBody
    @RequestMapping("doQueryPayment.do")
    public Map<String, Object> doQueryPayment(@RequestParam Map<String, String> map, PaymentOfflineQueryParam queryParam){
        Map<String,Object> resultMap = new HashMap<String, Object>();
        resultMap.put("success", true);
        resultMap.put("message", "查询成功");
        try {
            Page<CreditPaymentOffline> page= paymentOfflineService.query(queryParam);
            resultMap.put("rows", page.getRows());
            resultMap.put("total", page.getTotal());
            return resultMap;
        } catch (Exception e) {
            logger.error("queryPayment error",e);
            return ErrorMessage.getGridErrorMessage("系统异常");
        }
    }

    @ResponseBody
    @RequestMapping("toCreatePayment.do")
    public Map<String,Object> toCreatePayment(@RequestParam Map<String, String> map){
        Map<String,Object> resultMap = new HashMap<String, Object>();
        resultMap.put("success", true);

        String merchantNo=map.get("merchantNo");
        if(StringUtil.isBlank(merchantNo)){
            resultMap.put("success", false);
            resultMap.put("message", "账单对应商户不存在");
            return resultMap;
        }

        BigDecimal totalAmount=BigDecimal.ZERO;
        Integer merchantId=null;
        String merchantName="";
        PostBillQueryParam queryParam=new PostBillQueryParam();
        queryParam.setMerchantNo(merchantNo);
        queryParam.setStatus(PostBillStatusEnum.UNPAID);
        queryParam.setLimit(Integer.MAX_VALUE);
        Page<CreditPostBillMonth> page=postBillService.query(queryParam);
        List<CreditPostBillMonth> billList=page.getRows();

        for(CreditPostBillMonth bill:billList){
            if(merchantId==null){
                merchantId=bill.getMerchantId();
                merchantName=bill.getMerchantName();
            }
            BigDecimal amount=bill.getAmount();
            totalAmount=totalAmount.add(amount);
        }

        PaymentOfflineQueryParam payParam=new PaymentOfflineQueryParam();
        payParam.setMerchantNo(merchantNo);
        payParam.setStatusList(Lists.newArrayList(PaymentOfflineStatusEnum.PAYING,PaymentOfflineStatusEnum.PAID,PaymentOfflineStatusEnum.PART_DEDUCTED));
        payParam.setLimit(Integer.MAX_VALUE);
        Page<CreditPaymentOffline> payPage= paymentOfflineService.query(payParam);
        List<CreditPaymentOffline> paymentList=payPage.getRows();
        BigDecimal payingAmount=BigDecimal.ZERO;
        BigDecimal noDeductAmount=BigDecimal.ZERO;
        for(CreditPaymentOffline payment:paymentList){
            if(payment.getStatus()==PaymentOfflineStatusEnum.PAYING){
                payingAmount=payingAmount.add(payment.getRemainsAmount());
            }else {
                noDeductAmount=noDeductAmount.add(payment.getRemainsAmount());
            }
        }

        resultMap.put("payingAmount",payingAmount);
        resultMap.put("noDeductAmount",noDeductAmount);
        resultMap.put("totalAmount",totalAmount);
        resultMap.put("merchantId",merchantId);
        resultMap.put("merchantNo",merchantNo);
        resultMap.put("merchantName",merchantName);
        return resultMap;
    }

    @ResponseBody
    @RequestMapping("doCreatePayment.do")
    public Map<String,Object> doCreatePayment(@RequestParam Map<String, String> map,CreditPaymentOffline paymentOffline,String user){
        Map<String,Object> resultMap = new HashMap<String, Object>();
        resultMap.put("success", true);
        resultMap.put("message","创建成功");

        try {
            String realName = getLoginRealName(user);
            paymentOffline.setCreator(realName);
        } catch (Exception e) {
            logger.error(e);
            paymentOffline.setCreator("error");
        }

        try {
            paymentOfflineService.createPaymentOffline(paymentOffline);
        }catch (CreditBusinessException e) {
            logger.error(e);
            resultMap.put("success", false);
            resultMap.put("message",e.getMessage());
        } catch (Exception e) {
            logger.error(e);
            resultMap.put("success", false);
            resultMap.put("message","系统异常");
        }
        return resultMap;
    }
}
