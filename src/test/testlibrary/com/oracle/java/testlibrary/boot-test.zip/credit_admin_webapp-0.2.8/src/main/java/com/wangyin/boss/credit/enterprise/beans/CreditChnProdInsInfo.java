package com.wangyin.boss.credit.enterprise.beans;

import com.wangyin.boss.credit.admin.entity.CreditChnProdIns;

public class CreditChnProdInsInfo extends CreditChnProdIns {

    private String productName;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
}
