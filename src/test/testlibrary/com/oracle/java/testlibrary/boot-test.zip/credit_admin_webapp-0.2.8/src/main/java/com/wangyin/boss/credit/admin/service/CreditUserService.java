package com.wangyin.boss.credit.admin.service;

import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.response.merchant.GatewayMerchantQueryResponse;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.operation.common.beans.Page;

import java.util.List;

/**
 * 用户相关service
 * @author jiangbo
 * @since 20170317
 */
public interface CreditUserService {

    /**
     * 用户信息查询  分页
     * @param creditUser 请求体
     * @return
     */
    List<CreditUser> selectCreditUserByParam(CreditUser creditUser);

    /**
     * 用户信息查询count  分页
     * @param creditUser 请求体
     * @return
     */
    int selectCreditUserCountByParam(CreditUser creditUser);

    /**
     * 根据主键更新用户信息
     *  yangjinlin@jd.com
     * @param creditUser
     * @return
     */
    int modifyUserByPrimaryKey(CreditUser creditUser);
}
