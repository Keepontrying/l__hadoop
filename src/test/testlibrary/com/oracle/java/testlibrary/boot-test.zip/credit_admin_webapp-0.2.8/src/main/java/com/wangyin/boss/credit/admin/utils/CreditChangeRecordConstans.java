package com.wangyin.boss.credit.admin.utils;
/** 
* @desciption : 操作变更记录常量类
* @author : yangjinlin@jd.com
* @date ：2016年8月31日 下午2:20:15 
* @version 1.0 
* @return  */
public class CreditChangeRecordConstans {

	/**
	 * 操作变更记录类型---产品服务配置状态变更
	 */
	public static final String RECORD_CHANGETYPE_PRODUCT = "PRODUCT";
	
	/**
	 * 操作变更记录类型---合同审核变更
	 */
	public static final String RECORD_CHANGETYPE_CONTRACT = "CONTRACT";
	
}
