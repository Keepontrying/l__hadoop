package com.wangyin.boss.credit.admin.controller;

import com.jd.jr.boss.credit.domain.common.entity.CreditPostBillMonth;
import com.jd.jr.boss.credit.facade.authen.beans.param.PostBillQueryParam;
import com.wangyin.boss.credit.admin.service.PostBillService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.beans.ErrorMessage;
import com.wangyin.operation.common.beans.Page;
import org.joda.time.DateTime;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by anmeng on 2017/9/14.
 */
@Controller
@RequestMapping("/postBill")
public class PostBillController {
    private Logger logger = LoggerFactory.getLogger(PostBillController.class);

    @Resource
    private PostBillService postBillService;

    @ResponseBody
    @RequestMapping("doQueryPostBill.do")
    public Map<String,Object> doQueryPostBill(@RequestParam Map<String, String> map, PostBillQueryParam queryParam){
        Map<String,Object> resultMap = new HashMap<String, Object>();
        resultMap.put("success", true);
        resultMap.put("message", "查询成功");
        String billCycle=map.get("billCycle");

        String currMonth=DateTime.now().toString("yyyy-MM");
        if("current".equals(billCycle)){
            String begin=DateTime.now().minusMonths(1).toString("yyyy-MM");
            queryParam.setBillMonthBegin(begin);
            queryParam.setBillMonthEnd(currMonth);
        }else if("last3".equals(billCycle)){
            String begin=DateTime.now().minusMonths(3).toString("yyyy-MM");
            queryParam.setBillMonthBegin(begin);
            queryParam.setBillMonthEnd(currMonth);
        }else if("lasfH".equals(billCycle)){
            String begin=DateTime.now().minusMonths(6).toString("yyyy-MM");
            queryParam.setBillMonthBegin(begin);
            queryParam.setBillMonthEnd(currMonth);
        }else if("lastY".equals(billCycle)){
            String begin=DateTime.now().minusMonths(12).toString("yyyy-MM");
            queryParam.setBillMonthBegin(begin);
            queryParam.setBillMonthEnd(currMonth);
        }
        try {
            Page<CreditPostBillMonth> page= postBillService.query(queryParam);
            resultMap.put("rows", page.getRows());
            resultMap.put("total", page.getTotal());
            return resultMap;
        } catch (Exception e) {
            logger.error("queryPostBill error",e);
            return ErrorMessage.getGridErrorMessage("系统异常");
        }
    }

    @ResponseBody
    @RequestMapping("viewPostBill.do")
    public Map<String,Object> viewPostBill(@RequestParam Map<String, String> map, PostBillQueryParam queryParam){
        Map<String,Object> resultMap = new HashMap<String, Object>();
        resultMap.put("success", true);
        resultMap.put("message", "查询成功");

        try {
            CreditPostBillMonth bill= postBillService.detail(queryParam);
            resultMap.put("bill", bill);
            return resultMap;
        } catch (Exception e) {
            logger.error("queryPostBill error",e);
            return ErrorMessage.getGridErrorMessage("系统异常");
        }
    }
}
