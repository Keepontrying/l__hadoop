package com.wangyin.boss.credit.enterprise.beans;

import com.wangyin.operation.common.beans.PageQuery;

import java.io.Serializable;
import java.util.Date;

/**
 * 舆情监控 - 爬虫任务管理筛选条件
 *
 * @author huangzhiqiang
 * @data 2018/11/20
 */
public class CrawlerJobResultsQueryParam extends PageQuery implements Serializable {

    private Long jobId;

    private Long jobResId;

    private String jobNo;
    /**
     * 任务名称
     */
    private String name;
    /**
     * 任务类别
     */
    private Byte category;
    /**
     * 目标网站
     */
    private String targetUrlCode;
    /**
     * 关键词
     */
    private String word;
    /**
     * 任务总权重
     */
    private Integer jobWeight1;
    private Integer jobWeight2;
    /**
     * 命中总词频
     */
    private Integer jobHit1;
    private Integer jobHit2;
    /**
     * 主敏感词权重
     */
    private Integer wordWeight1;
    private Integer wordWeight2;
    /**
     * 主敏感词词频
     */
    private Integer wordHit1;
    private Integer wordHit2;
    /**
     * 查询时间
     */
    private Date time1;
    private Date time2;
    private String timeStr1;
    private String timeStr2;

    public String getTimeStr1() {
        return timeStr1;
    }

    public void setTimeStr1(String timeStr1) {
        this.timeStr1 = timeStr1;
    }

    public String getTimeStr2() {
        return timeStr2;
    }

    public void setTimeStr2(String timeStr2) {
        this.timeStr2 = timeStr2;
    }

    private byte state;

    public Long getJobId() {
        return jobId;
    }

    public void setJobId(Long jobId) {
        this.jobId = jobId;
    }

    public Long getJobResId() {
        return jobResId;
    }

    public void setJobResId(Long jobResId) {
        this.jobResId = jobResId;
    }

    public String getJobNo() {
        return jobNo;
    }

    public void setJobNo(String jobNo) {
        this.jobNo = jobNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Byte getCategory() {
        return category;
    }

    public void setCategory(Byte category) {
        this.category = category;
    }

    public String getTargetUrlCode() {
        return targetUrlCode;
    }

    public void setTargetUrlCode(String targetUrlCode) {
        this.targetUrlCode = targetUrlCode;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public Integer getJobWeight1() {
        return jobWeight1;
    }

    public void setJobWeight1(Integer jobWeight1) {
        this.jobWeight1 = jobWeight1;
    }

    public Integer getJobWeight2() {
        return jobWeight2;
    }

    public void setJobWeight2(Integer jobWeight2) {
        this.jobWeight2 = jobWeight2;
    }

    public Integer getJobHit1() {
        return jobHit1;
    }

    public void setJobHit1(Integer jobHit1) {
        this.jobHit1 = jobHit1;
    }

    public Integer getJobHit2() {
        return jobHit2;
    }

    public void setJobHit2(Integer jobHit2) {
        this.jobHit2 = jobHit2;
    }

    public Integer getWordWeight1() {
        return wordWeight1;
    }

    public void setWordWeight1(Integer wordWeight1) {
        this.wordWeight1 = wordWeight1;
    }

    public Integer getWordWeight2() {
        return wordWeight2;
    }

    public void setWordWeight2(Integer wordWeight2) {
        this.wordWeight2 = wordWeight2;
    }

    public Integer getWordHit1() {
        return wordHit1;
    }

    public void setWordHit1(Integer wordHit1) {
        this.wordHit1 = wordHit1;
    }

    public Integer getWordHit2() {
        return wordHit2;
    }

    public void setWordHit2(Integer wordHit2) {
        this.wordHit2 = wordHit2;
    }

    public Date getTime1() {
        return time1;
    }

    public void setTime1(Date time1) {
        this.time1 = time1;
    }

    public Date getTime2() {
        return time2;
    }

    public void setTime2(Date time2) {
        this.time2 = time2;
    }

    public byte getState() {
        return state;
    }

    public void setState(byte state) {
        this.state = state;
    }
}
