package com.wangyin.boss.credit.admin;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.chinabank.core.utils.PWDUtil;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.request.merchant.GatewayPortalUserRequest;
import com.jd.jr.boss.credit.credit.gateway.merchantca.exception.MerchantException;
import com.jd.jr.boss.credit.credit.gateway.merchantca.facade.GatewayPortalFacade;
import com.jd.jr.merchant.customer.ServiceControllerFacade;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : 
* @author : yangjinlin@jd.com
* @date ：2017年3月27日 下午4:22:37 
* @version 1.0 
* @return  */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:applicationContext.xml" })
public class portalInterfaceTest {
	
	@Autowired
    private ServiceControllerFacade serviceControllerFacade;
	
	@Autowired
	private GatewayPortalFacade gatewayPortalFacade;
	
	private static Logger LOGGER = LoggerFactory.getLogger(portalInterfaceTest.class);
	
	/*
	 * jinlin@jd.com  operation 
     * 商户号：110037820
	 */
	
//	@Test
	@SuppressWarnings("rawtypes")
	public void registerUser(){
		
		RequestParam<GatewayPortalUserRequest> registerRequestParam = new RequestParam<GatewayPortalUserRequest>();
		GatewayPortalUserRequest request = new GatewayPortalUserRequest();
		request.setUserName("201703290005@jd.com"); // 110037840
		request.setPassWord(PWDUtil.encrypt("yangjinlin"));
		request.setPassWordType("1");//0-不加密；1-加密
		registerRequestParam.setParam(request);
		
		try {
			ResponseData<String> resp = gatewayPortalFacade.registerByBiz(registerRequestParam);
			LOGGER.info("用户注册接口返回结果 :"+GsonUtil.getInstance().toJson(resp));
		} catch (MerchantException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@SuppressWarnings("rawtypes")
//	@Test
	public void checkEmailExsit(){
		
		RequestParam<GatewayPortalUserRequest> registerRequestParam = new RequestParam<GatewayPortalUserRequest>();
		GatewayPortalUserRequest request = new GatewayPortalUserRequest();
		request.setUserName("201703290005@jd.com");
		registerRequestParam.setParam(request);
		
		try {
			ResponseData resp = gatewayPortalFacade.checkEmailExsit(registerRequestParam);
			LOGGER.info("校验邮箱是否存在接口接口返回结果 :"+GsonUtil.getInstance().toJson(resp));
		} catch (MerchantException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@SuppressWarnings("rawtypes")
//	@Test
	public void login(){
		
		RequestParam<GatewayPortalUserRequest> registerRequestParam = new RequestParam<GatewayPortalUserRequest>();
		GatewayPortalUserRequest request = new GatewayPortalUserRequest();
		request.setUserName("201703290004@jd.com");
		request.setPassWord(PWDUtil.encrypt("yangjinlin"));
		registerRequestParam.setParam(request);
		
		try {
			ResponseData resp = gatewayPortalFacade.login(registerRequestParam);
			LOGGER.info("登录接口接口返回结果 :"+GsonUtil.getInstance().toJson(resp));
		} catch (MerchantException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@SuppressWarnings("rawtypes")
//	@Test
	public void resetPwdByEmail(){
		
		RequestParam<GatewayPortalUserRequest> registerRequestParam = new RequestParam<GatewayPortalUserRequest>();
		GatewayPortalUserRequest request = new GatewayPortalUserRequest();
		request.setUserName("201703290005@jd.com");
		request.setMerchantNo("110037840");
		request.setRedirectUrl("www.jd.com");
		registerRequestParam.setParam(request);
		
		try {
			ResponseData resp = gatewayPortalFacade.resetPwdByEmail(registerRequestParam);
			LOGGER.info("登录接口接口返回结果 :"+GsonUtil.getInstance().toJson(resp));
		} catch (MerchantException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	@Test
	public void queryMerchantInfoByNoEmail(){
		RequestParam<GatewayPortalUserRequest> registerRequestParam = new RequestParam<GatewayPortalUserRequest>();
		GatewayPortalUserRequest request = new GatewayPortalUserRequest();
		request.setUserName("201703290005@jd.com");
		request.setMerchantNo("110037840");
		registerRequestParam.setParam(request);
		
		try {
			ResponseData<String> resp = gatewayPortalFacade.queryMerchantInfoByNoAndEmail(registerRequestParam);
			LOGGER.info("根据商户号和邮箱查询商户信息返回结果 :"+GsonUtil.getInstance().toJson(resp));
		} catch (MerchantException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	@SuppressWarnings("rawtypes")
//	@Test
	public void uploadCertFileInfosByHttp(){
		
		//TODO 修改此路径
				String filepath = "E:\\20170328202310.jpg";  //TODO 不同证件上传不同图片
//			    String urlStr = "http://127.0.0.1:8080/upload/uploadEnterPrise.data";
			    //TODO 修改此路径
			    String urlStr = "http://172.24.5.184:8089/upload/uploadEnterPrise.data";  
//				String urlStr = "http://bapi.jdpay.com/upload/uploadEnterPrise.data";
			    //认证文字信息
			    Map<String, String> textMap = new HashMap<String, String>(); 
			    
			    textMap.put("merchantid", "110037840");  
			    textMap.put("catalog", "RealNameCatalog");  
			    textMap.put("businessLicenseCertify.companyname", "金霖测试"); //营业执照公司名
			    textMap.put("businessLicenseCertify.licenseCode", "110001111");//营业执照号  
			    textMap.put("businessLicenseCertify.establishDate", "2003-04-04");  //成立时间
			    textMap.put("businessLicenseCertify.startDate", "2004-01-02");  //开始时间
			    textMap.put("businessLicenseCertify.endDate", "2011-01-01");  //结束时间
			    textMap.put("businessLicenseCertify.province", "河南省");  //河北省
			    textMap.put("businessLicenseCertify.city", "郑州市");   //郑州市
			    textMap.put("businessLicenseCertify.address", "addrest地址");  //
			    textMap.put("businessLicenseCertify.businessScope", "businessScopetest");  //营业范围 最大 400字
			    
			    textMap.put("idCardCertify.code", "idcode110001111");  //法人身份证号码
			    textMap.put("idCardCertify.name", "testIDname");  //法人身份证上姓名
			    textMap.put("idCardCertify.startDate", "2004-01-02");  //法人身份证开始日期
			    textMap.put("idCardCertify.entDate", "2114-01-02");  //法人身份证结束日期
			    
			    textMap.put("proxyIdCertify.code", "idcode110001111");  //身份证号码
			    textMap.put("proxyIdCertify.name", "testIDname");  //身份证上姓名
			    textMap.put("proxyIdCertify.startDate", "2004-01-02");  //开始日期
			    textMap.put("proxyIdCertify.entDate", "2114-01-02");  //结束日期
			    
			    textMap.put("orgCodeCertify.code", "110001111");  //组织结构代码
			    textMap.put("orgCodeCertify.startDate", "2114-01-03");  //组织机构代码开始时间
			    textMap.put("orgCodeCertify.endDate", "2114-01-04");  //组织结构代码证 结束时间
			    
			    
			    textMap.put("taxCertify.taxCode", "110001111"); //税务登记证号码  
			   
			    //需要上传的图片
			    Map<String, String> fileMap = new HashMap<String, String>();
			    fileMap.put("businessLicenseCertify.img", filepath);  //营业执照图片 地址（本地路径）
			    fileMap.put("idCardCertify.img", filepath); //身份证正面图片 地址（本地路径）
			    fileMap.put("idCardCertify.backImg", filepath);//身份背面图片地址（本地路径）
			    fileMap.put("proxyIdCertify.img", filepath); //代理人身份证正面 图片地址（本地路径）
			    fileMap.put("proxyIdCertify.backImg", filepath);//代理人身份证背面图片（本地路径）
			    fileMap.put("orgCodeCertify.img", filepath); //组织机构代码证图片（本地路径）
			    fileMap.put("taxCertify.img", filepath); //税务登记证 图片地址（本地路径）
			    fileMap.put("openAccountCertify.img", filepath); //银行开户正面 图片地址（本地路径）
			    fileMap.put("proxyLetterCertify.img", filepath); //代理人的委托书图片地址（本地路径）
//			    
//			    String ret = HttpUploadUtil.formUpload(urlStr, textMap, fileMap);          
//			    
//			    System.out.println("------------上传测试返回信息--------："+ret);  
		
	}
	
}
