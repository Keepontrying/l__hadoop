package com.wangyin.boss.credit.admin.service;

import java.util.List;

import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;

/**
 * 
 * @author wyhaozhihong
 *
 */
public interface CreditContractService {
	
	/**
	 * 根据查询条件查询合同数据 分页
	 * @param creditContract
	 * @return
	 */
	List<CreditContract> selectByParam(CreditContract creditContract);
	
	/**
	 * 根据条件查询合同数据总条数
	 * @param creditContract
	 * @return
	 */
	int selectCountByParam(CreditContract creditContract);
	
	/**
	 * 根据contractId查询合同数据
	 * @param contractId
	 * @return
	 */
	CreditContract selectByPrimaryKey(Integer contractId);
	
	/**
	 * 上传文件成功后，更新合同文件路径
	 * @param contractId
	 * @param filePath
	 * @return
	 */
	boolean updateContractForUpload(String contractId, String filePath);
	
	/**
	 * 创建征信产品合同
	 * @author wyhaozhihong
	 * @param creditContract
	 * @param creditMerchant 
	 * @return
	 * @throws Exception 
	 */
	int createContract(CreditContract creditContract, CreditMerchant creditMerchant, String[] strategyIds) throws Exception;
	
	/**
	 * 根据主键更新合同数据
	 * @param creditContract
	 * @return
	 */
	int updateContractByPrimaryKey(CreditContract creditContract);
	
	/**
	 * 校验商户号是否是经过实名认证的企业商户
	 * @param merchantNo
	 * @return
	 */
	boolean doValidMerchantNoAuth(String merchantNo);

	/**
	 * 审核合同更新系列操作
	 * @param creditContract
	 * @return
	 */
	int modifyContractByPrimaryKey(CreditContract creditContract);

	/**
	 * 查询待审核合同 分页---用于排序
	 * @param creditContract
	 * @return
	 */
	List<CreditContract> selectAuditByParam(CreditContract creditContract);

	/**
	 * 查询待审核合同 分页---用于排序
	 * @param creditContract
	 * @return
	 */
	int selectCountAuditByParam(CreditContract creditContract);/**
	 /**
	 * 根据商户号查询是够申请过合同
	 * @param merchantNo
	 * @return
	 */
	List<CreditContract> selectContractByMerchantNo(String merchantNo);
	/**
	 * 根据合同参数多维度获取合同list
	 * @param merchantNo
	 * @return
	 */
	List<CreditContract> selectContrByContrParam(CreditContract contract);
	
}
