package com.wangyin.boss.credit.admin.service.impl;

import com.wangyin.boss.credit.admin.dao.CreditItemMapper;
import com.wangyin.boss.credit.admin.dao.CreditItemSkuMapper;
import com.wangyin.boss.credit.admin.entity.CreditItem;
import com.wangyin.boss.credit.admin.entity.CreditItemSku;
import com.wangyin.boss.credit.admin.service.CreditItemService;
import com.wangyin.boss.credit.admin.service.CreditItemSkuService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 *
 * 门户标准产品sku管理
 * @author jiangbo
 * @since 2017/3/17
 */
@Service
public class CreditItemSkuServiceImpl implements CreditItemSkuService {

    private static Logger logger = LoggerFactory.getLogger(CreditItemSkuServiceImpl.class);


    @Autowired
    CreditItemSkuMapper creditItemSkuMapper;


    @Override
    public int insertSelective(CreditItemSku creditItemSku) {
        creditItemSku.setModifiedDate(new Date());
        return creditItemSkuMapper.insertSelective(creditItemSku);
    }

    @Override
    public int updateByPrimaryKeySelective(CreditItemSku creditItemSku) {
        creditItemSku.setModifiedDate(new Date());
        return creditItemSkuMapper.updateByPrimaryKeySelective(creditItemSku);
    }
}
