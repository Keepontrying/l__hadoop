package com.wangyin.boss.credit.admin.dao;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditProductBlack;
import com.wangyin.boss.credit.admin.entity.CreditProductConfig;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/** 
* @desciption : 产品黑名单配置 mapper映射类
* @author : liuwei55@jd.com
* @date ：2017年4月10日 下午20:46:58
* @version 1.0 
* @return  */

@SqlMapper
@Component
public interface CreditProductBlackMapper {

	/**
     * 根据查询条件查询  产品黑名单配置 分页
     * @param creditProductBlack
     * @return
     */
	List<CreditProductBlack> selectCreProdBlackByPams(CreditProductBlack creditProductBlack);

	/**
	 * 根据查询条件查询  产品黑名单配置  总条数
	 * @param creditProductBlack
	 * @return
	 */
	int selectCountByParam(CreditProductBlack creditProductBlack);
	/**
	 * 根据产品黑名单的主键black_id更新  产品黑名单配置表的状态
	 * @param creditProductBlack
	 * @return
	 * @throws Exception
	 */
	int updateCredProdBlackById(CreditProductBlack creditProductBlack);
	/**
	 * 根据查询条件查询  产品黑名单配置 分页
	 * @param blackId
	 * @return
	 */
	CreditProductBlack selectCredProdBlackById(int blackId);
	/**
	 * 插入产品黑名单
	 * @param creditProductBlack
	 * @return
	 * @throws Exception
	 */
	int insertCredProdBlack(CreditProductBlack creditProductBlack);
	/**
	 * 根据查询条件查询  产品黑名单配置
	 * @param map
	 * @return
	 */
	CreditProductBlack selectCredProdBlackByProMerId(Map<String,Integer> map);
}
