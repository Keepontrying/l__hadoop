package com.wangyin.boss.credit.enterprise.service.impl;

import com.jd.jr.boss.credit.facade.authen.api.CreditCarLoanReportFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditQueryBatchFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.CarLoanReportQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.entity.CreditReportQueryCarloan;
import com.wangyin.boss.credit.enterprise.service.CreditCarloanReportService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * Description:
 * User: yangjinlin@jd.com
 * Date: 2018/6/28 16:02
 * Version: 1.0
 */
@Service
public class CreditCarloanReportServiceImpl implements CreditCarloanReportService {

    @Resource
    private CreditCarLoanReportFacade creditCarLoanReportFacade;

    @Override
    public CreditPage<CreditReportQueryCarloan> selectCarloanReportPageByParam(CarLoanReportQueryParam queryParam) {
        CreditRequestParam<CarLoanReportQueryParam> requestParam = new CreditRequestParam<CarLoanReportQueryParam>();
        requestParam.setParam(queryParam);
        return creditCarLoanReportFacade.queryCarLoanReportPage(requestParam);
    }

    @Override
    public CreditResponseData<String> carloanReportPdfSupplyHandle(CarLoanReportQueryParam queryParam) {
        CreditRequestParam<CarLoanReportQueryParam> requestParam = new CreditRequestParam<CarLoanReportQueryParam>();
        requestParam.setParam(queryParam);
        return creditCarLoanReportFacade.carloanReportPdfSupplyHandle(requestParam);
    }
}
