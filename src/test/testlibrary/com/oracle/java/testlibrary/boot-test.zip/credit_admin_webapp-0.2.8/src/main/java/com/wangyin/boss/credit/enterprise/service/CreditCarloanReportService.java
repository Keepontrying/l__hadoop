package com.wangyin.boss.credit.enterprise.service;

import com.jd.jr.boss.credit.facade.authen.beans.param.CarLoanReportQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.entity.CreditReportQueryCarloan;

/**
 * Description: 车贷报告service接口
 * User: yangjinlin@jd.com
 * Date: 2018/6/28 16:01
 * Version: 1.0
 */
public interface CreditCarloanReportService {

    /**
     * 查询车贷报告记录  分页
     * @param queryParam
     * @return
     */
    CreditPage<CreditReportQueryCarloan> selectCarloanReportPageByParam(CarLoanReportQueryParam queryParam);

    /**
     * 补充生成车贷报告--- 运营后台用
     * @param queryParam
     * @return
     */
    CreditResponseData<String> carloanReportPdfSupplyHandle(CarLoanReportQueryParam queryParam);
}
