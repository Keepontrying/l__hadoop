package com.wangyin.boss.credit.admin.entity;
/** 
* @desciption : 
* @author : yangjinlin@jd.com
* @date ：2016年10月19日 下午8:06:26 
* @version 1.0 
* @return  */
public class CreditProductStrategyAllow extends CreditProductStrategy{

	private String accountNo;
	
	private String creditType;

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getCreditType() {
		return creditType;
	}

	public void setCreditType(String creditType) {
		this.creditType = creditType;
	}

	
	
}
