package com.wangyin.boss.credit.enterprise.service;

import java.util.List;

import com.jd.jr.boss.credit.domain.common.entity.CreditCallTimesGather;
import com.jd.jr.boss.credit.facade.authen.beans.param.CallTimesGatherQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.param.ChannelLogQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.param.CreditLogQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.CreditChannelLogInfo;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.CreditTradeLogInfo;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.QueryCountEntity;
import com.wangyin.operation.beans.UploadFile;

/** 
* @desciption : 交易流水service接口类
* @author : yangjinlin@jd.com
* @date ：2018年4月23日 下午5:02:27 
* @version 1.0 
* @return  */
public interface CreditLogService {

	/**
	 * 多条件查询调用量汇总List 个数
	 * @param queryParam
	 * @return
	 */
	public int queryTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam);

	/**
	 * 多条件查询调用量汇总List 
	 * @param queryParam
	 * @return
	 */
	public List<CreditCallTimesGather> queryTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam);

	/**
	 * 商户维度查询调用量汇总List 个数
	 * @param queryParam
	 * @return
	 */
	public int queryMerchTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam);

	/**
	 *  商户维度查询调用量汇总List 
	 * @param queryParam
	 * @return
	 */
	public List<CreditCallTimesGather> queryMerchTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam);

	/**
	 * 商户+产品 维度查询调用量 总数
	 * @param queryParam
	 * @return
	 */
	public int queryMerchProdTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam);

	/**
	 *  商户+产品 维度查询调用量List
	 * @param queryParam
	 * @return
	 */
	public List<CreditCallTimesGather> queryMerchProdTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam);

	/**
	 *  商户+产品+详细状态 维度查询调用量 总数
	 * @param queryParam
	 * @return
	 */
	public int queryMerchProdStepTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam);

	/**
	 * 商户+产品+详细状态 维度查询调用量List
	 * @param queryParam
	 * @return
	 */
	public List<CreditCallTimesGather> queryMerchProdStepTradeLogCallTimesGatherList(
			CallTimesGatherQueryParam queryParam);

	/**
	 * 商户+产品+来源 维度查询调用量 总数
	 * @param queryParam
	 * @return
	 */
	public int queryMerchProdResoTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam);

	/**
	 * 商户+产品+来源 维度查询调用量 总数
	 * @param queryParam
	 * @return
	 */
	public List<CreditCallTimesGather> queryMerchProdResoTradeLogCallTimesGatherList(
			CallTimesGatherQueryParam queryParam);

	/**
	 * 从es查询业务流水日志
	 * @param queryParam
	 * @return
	 */
	public CreditPage<CreditTradeLogInfo> queryTradeLogPage(CreditLogQueryParam queryParam);

	/**
	 * 统计某一字段的分桶情况
	 * @param queryParam
	 * @param countField 字段名称
	 * @return
	 */
	public CreditResponseData<List<QueryCountEntity>> countCreditLogByField(CreditLogQueryParam queryParam,
			String countField);

	/**
	 * 按照来源汇总多条件查询调用量List
	 * @param queryParam
	 * @return
	 */
	public List<CreditCallTimesGather> queryResoTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam);

	/**
	 *  多条件查询渠道日志流水 分页
	 * @param queryParam
	 * @return
	 */
    CreditPage<CreditChannelLogInfo> queryChannelLogList(ChannelLogQueryParam queryParam);

	/**
	 * 根据某字段汇总渠道流水计数
	 * @param queryParam
	 * @param countField
	 * @return
	 */
    CreditResponseData<List<QueryCountEntity>> countChannelLogByField(ChannelLogQueryParam queryParam, String countField);

    /**
     * 多条件筛选下载业务流水
     * @param queryParam
     * @return
     */
    UploadFile downTradeLogQueryResult(CreditLogQueryParam queryParam);

    /**
     * 多条件筛选并下载业务流水商户维度调用量
     * @param queryParam
     * @return
     */
    UploadFile downMerchTradeLogCallTimes(CallTimesGatherQueryParam queryParam);

    /**
     * 多条件筛选并下载业务流水商户产品维度调用量
     * @param queryParam
     * @return
     */
    UploadFile downMerchProdTradeLogCallTimes(CallTimesGatherQueryParam queryParam);

    /**
     * 多条件筛选并下载业务流水商户产品来源维度调用量
     * @param callTimesGatherList
     * @param titles
     * @param properties
     * @param fileName
     * @return
     */
    UploadFile downTradeLogCallTimes(List<CreditCallTimesGather> callTimesGatherList, String[] titles, String[] properties,  String fileName);

    /**
     * 查询 产品维度  业务流水调用量汇总  总计数
     * @param queryParam
     * @return
     */
    int queryProdTradeLogCallTimesGatherListCount(CallTimesGatherQueryParam queryParam);

    /**
     * 查询 产品维度  业务流水调用量汇总  分页
     * @param queryParam
     * @return
     */
    List<CreditCallTimesGather> queryProdTradeLogCallTimesGatherList(CallTimesGatherQueryParam queryParam);
}
