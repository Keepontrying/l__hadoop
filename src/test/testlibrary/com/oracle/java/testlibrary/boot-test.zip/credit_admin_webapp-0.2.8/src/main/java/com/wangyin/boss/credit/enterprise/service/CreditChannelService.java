package com.wangyin.boss.credit.enterprise.service;

import com.wangyin.boss.credit.enterprise.beans.CreditChannelQueryParam;
import com.wangyin.boss.credit.enterprise.entity.CreditChnChannel;
import com.wangyin.operation.common.beans.PageResult;

import java.util.Map;

public interface CreditChannelService {

    PageResult<CreditChnChannel> queryChannelList(CreditChannelQueryParam creditChannelQueryParam);

    Map<String,Object> saveOrUpdate(CreditChannelQueryParam creditChannelQueryParam);

    Map<String,Object> queryChannelInfoById(CreditChannelQueryParam channelId);
}
