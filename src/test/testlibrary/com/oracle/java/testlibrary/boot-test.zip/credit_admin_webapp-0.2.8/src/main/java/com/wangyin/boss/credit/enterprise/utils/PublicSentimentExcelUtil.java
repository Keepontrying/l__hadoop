package com.wangyin.boss.credit.enterprise.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResults;
import com.wangyin.operation.common.beans.Page;
import net.sf.jxls.transformer.XLSTransformer;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * 爬虫结果导出xlsx工具类
 *
 * @author: dongzhihua
 * @time: 2018/12/5 9:27:52
 */
public abstract class PublicSentimentExcelUtil {
    private static Logger logger = LoggerFactory.getLogger(PublicSentimentExcelUtil.class);

    static ObjectMapper mapper = new ObjectMapper();
    static {
        mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
    }

    /**
     * 导出excel
     * @author: dongzhihua
     * @time: 2018/12/5 9:55:39
     */
    public static void export(Page<CrawlerJobResults> query, File template, File target) {
        logger.info("export : {}", target.getName());

        FileInputStream fis = null;
        FileOutputStream fos = null;
        Workbook workbook = null;
        try {

            supplement(query);
            XLSTransformer transformer = new XLSTransformer();
            fis = new FileInputStream(template);
            Map json;
            if (query.getRows() != null) {
                String s1 = mapper.writeValueAsString(query);
                json = mapper.readValue(s1, Map.class);
            } else {
                json = new HashMap();
                json.put("rows", new ArrayList<>());
            }

            workbook = transformer.transformXLS(fis, json);
            FileUtils.forceMkdir(target.getParentFile());
            fos = new FileOutputStream(target);

            range(query, workbook);

            workbook.write(fos);
        } catch (Exception e) {
            throw new RuntimeException("export xlsx:" + e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(fis);
            IOUtils.closeQuietly(fos);
            IOUtils.closeQuietly(workbook);
        }
    }

    /**
     * 补充数据
     * @author: dongzhihua
     * @time: 2018/12/3 22:53:02
     */
    public static void supplement(Page<CrawlerJobResults> query) {
        logger.info("supplement");
        if (query.getRows() == null) {
            return;
        }
        // 按照jobId排序，不然合并单元格没有意义
        query.getRows().sort((o1, o2) -> {
            if (o1.getJobId() == null) {
                return -1;
            }
            if (o2.getJobId() == null) {
                return 1;
            }
            return o2.getJobId().compareTo(o1.getJobId());
        });

        if (query.getRows() != null) {
            for (CrawlerJobResults re : query.getRows()) {
                StringBuilder jobContent = new StringBuilder();
                if (re.getWords() != null) {
                    re.getWords().forEach(w -> jobContent.append('+').append(w.getWord() + '+' + w.getWeight()));
                }
                if (jobContent.length() > 0) {
                    re.setJobContent(jobContent.substring(1));
                }
            }
        }
    }

    /**
     * 合并单元格
     * @author: dongzhihua
     * @time: 2018/12/3 22:53:15
     */
    public static void range(Page<CrawlerJobResults> query, Workbook workbook) {
        if (query.getRows() == null || query.getRows().size() < 2) {
            return;
        }
        // 结果信息列
        Integer[] resultColumns = new Integer[]{1, 7, 8, 9, 10};
        // job信息列
        Integer[] jobColumns = new Integer[]{2, 3, 4, 5, 6};
        try {
            int resultFirstRow = 3;
            int jobFirstRow = 3;
            int resultCount = 0;
            Long prevJobId = null;
            for (CrawlerJobResults r : query.getRows()) {
                logger.debug("range jobId: {}", r.getJobId());
                // 根据敏感词个数，合并结果列，因为关键词不少于两个，所以每次都合并
                logger.debug("range result resultId: {}", r.getId());
                int size = r.getWords().size();
                range(workbook, resultFirstRow, size, resultColumns);
                resultFirstRow += size;

                // 合并job列，检测到jobId发生变化，则合并
                if(prevJobId != null && !r.getJobId().equals(prevJobId)) {
                    logger.debug("range job jobId: {}", r.getJobId());
                    range(workbook, jobFirstRow, resultCount, jobColumns);
                    jobFirstRow += resultCount;
                    resultCount = 0;
                }
                resultCount += size;
                prevJobId = r.getJobId();
            }
            // 如果最后一个job的结果需要合并，一般都需要，因为关键词不少于两个
            range(workbook, jobFirstRow, resultCount, jobColumns);
        } catch (Exception e) {
            logger.error("exportXlsx ", e);
        }
    }

    public static void range(Workbook workbook, int firstRow, int rowCount, Integer[] cols) {

        if (rowCount < 2) {
            return;
        }
        int lastRow = firstRow + rowCount - 1;
        logger.debug("range array : firstRow: {}, lastRow: {}, rowCount: {}", firstRow, lastRow, rowCount);
        for (Integer col : cols) {
            workbook.getSheetAt(0).addMergedRegion(new CellRangeAddress(firstRow, lastRow, col, col));
        }
    }
}
