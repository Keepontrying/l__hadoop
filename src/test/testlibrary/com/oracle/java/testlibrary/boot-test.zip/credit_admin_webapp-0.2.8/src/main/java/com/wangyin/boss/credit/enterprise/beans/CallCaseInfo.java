package com.wangyin.boss.credit.enterprise.beans;

/**
 * 
 * <ul>
 * <li>1、开发日期：2018年1月2日</li>
 * <li>2、开发时间：下午3:03:53</li>
 * <li>3、作 者：zhanghui12</li>
 * <li>4、类型名称：CallCaseInfo</li>
 * <li>5、类型意图：产品调用情况信息</li>
 * </ul>
 *
 */
public class CallCaseInfo {
	/**
	 * 产品名称
	 */
	private String productName;
	/**
	 * 商户名称
	 */
	private String merchantName;
	/**
	 * 商户号
	 */
	private String merchantNo;
	/**
	 * 单笔调用总金额
	 */
	private String singleAmount;
	/**
	 * 单笔调用量
	 */
	private String singleCount;
	/**
	 * 包量调用总金额
	 */
	private String packAmount;
	/**
	 * 包量调用量
	 */
	private String packCount;
	/**
	 * 总金额
	 */
	private String totalAmount;
	/**
	 * 成功总调用量
	 */
	private String totalCount;
	/**
	 * 成功+失败总调用量
	 */
	private String allCount;
	/**
	 * 失败次数
	 */
	private String errorCount;
	/**
	 * 失败比例
	 */
	private String errorRate;
	/**
	 * 总成功数
	 */
	private String successTotalCount;
	/**
	 * 总失败数
	 */
	private String failTotalCount;
	/**
	 * 正常调用总次数
	 */
	private String normalTotalCount;
	/**
	 * 免费调用总次数
	 */
	private String freeTotalCount;
    /**
     * 用户pin
     */
	private String userPin;
    /**
     * 用户隶属部门
     */
	private String departmentDesc;

	public String getAllCount() {
		return allCount;
	}

	public void setAllCount(String allCount) {
		this.allCount = allCount;
	}

	public String getErrorCount() {
		return errorCount;
	}

	public void setErrorCount(String errorCount) {
		this.errorCount = errorCount;
	}

	public String getErrorRate() {
		return errorRate;
	}

	public void setErrorRate(String errorRate) {
		this.errorRate = errorRate;
	}

	public String getMerchantNo() {
		return merchantNo;
	}

	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}

	public String getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSingleAmount() {
		return singleAmount;
	}

	public void setSingleAmount(String singleAmount) {
		this.singleAmount = singleAmount;
	}

	public String getSingleCount() {
		return singleCount;
	}

	public void setSingleCount(String singleCount) {
		this.singleCount = singleCount;
	}

	public String getPackAmount() {
		return packAmount;
	}

	public void setPackAmount(String packAmount) {
		this.packAmount = packAmount;
	}

	public String getPackCount() {
		return packCount;
	}

	public void setPackCount(String packCount) {
		this.packCount = packCount;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getSuccessTotalCount() {
		return successTotalCount;
	}

	public void setSuccessTotalCount(String successTotalCount) {
		this.successTotalCount = successTotalCount;
	}

	public String getNormalTotalCount() {
		return normalTotalCount;
	}

	public void setNormalTotalCount(String normalTotalCount) {
		this.normalTotalCount = normalTotalCount;
	}

	public String getFreeTotalCount() {
		return freeTotalCount;
	}

	public void setFreeTotalCount(String freeTotalCount) {
		this.freeTotalCount = freeTotalCount;
	}

	public String getFailTotalCount() {
		return failTotalCount;
	}

	public void setFailTotalCount(String failTotalCount) {
		this.failTotalCount = failTotalCount;
	}

    public String getUserPin() {
        return userPin;
    }

    public void setUserPin(String userPin) {
        this.userPin = userPin;
    }

    public String getDepartmentDesc() {
        return departmentDesc;
    }

    public void setDepartmentDesc(String departmentDesc) {
        this.departmentDesc = departmentDesc;
    }

    @Override
	public String toString() {
		return "CallCaseInfo [productName=" + productName + ", merchantName=" + merchantName + ", singleAmount="
				+ singleAmount + ", singleCount=" + singleCount + ", packAmount=" + packAmount + ", packCount="
				+ packCount + ", totalAmount=" + totalAmount + "]";
	}


}
