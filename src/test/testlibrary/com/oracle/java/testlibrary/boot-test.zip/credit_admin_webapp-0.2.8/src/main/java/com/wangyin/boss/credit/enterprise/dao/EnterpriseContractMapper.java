package com.wangyin.boss.credit.enterprise.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditContract;

/** 
* @desciption : 企业征信合同数据接口dao
* @author : yangjinlin@jd.com
* @date ：2017年3月17日 下午4:36:12 
* @version 1.0 
* @return  */
@SqlMapper
@Component
public interface EnterpriseContractMapper {

	/**
	 * 多条件分页查询查询企业征信合同
	 * @param creditContract 合同实体类
	 * @return
	 */
	List<CreditContract> selectEnterpContByParam(CreditContract creditContract);

	/**
	 * 多条件分页查询查询企业征信合同总记录数
	 * @param creditContract 合同实体类
	 * @return
	 */
	int selectEnterpContCountByParam(CreditContract creditContract);

	
	
}
