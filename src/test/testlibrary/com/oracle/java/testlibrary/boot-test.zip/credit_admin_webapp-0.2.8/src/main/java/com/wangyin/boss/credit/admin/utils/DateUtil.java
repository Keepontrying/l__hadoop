package com.wangyin.boss.credit.admin.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *  时间工具类
 * @author yangjinlin@jd.com
 *
 */
public class DateUtil {

	/**
	 * 获取date的前一天的日期
	 * 
	 * @param date
	 * @return
	 */
	public static Date getBeforeDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, -1);
		date = calendar.getTime();
		return date;
	}

    /**
     * 获取'yyyy-MM-dd'类型的date的后一天的日期
     * @param dateStr
     * @return
     */
	public static String getAfterDay(String dateStr) {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		try {
			date = df.parse(dateStr);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.add(Calendar.DAY_OF_MONTH, +1);
			date = calendar.getTime();
			return df.format(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 获取某年月的天数
	 * @param year
	 * @param month
	 * @return
	 */
	public static int getDaysByYearMonth(int year, int month) {
		Calendar a = Calendar.getInstance();
		a.set(Calendar.YEAR, year);
		a.set(Calendar.MONTH, month - 1);
		a.set(Calendar.DATE, 1);
		a.roll(Calendar.DATE, -1);
		int maxDate = a.get(Calendar.DATE);
		return maxDate;
	}
	
	/**
	 * 将时间字符串根据指定的转换模式，转换成util Date
	 * @param utilDateStr 时间字符串
	 * @param pattern 转换模式
	 * @return 转换后的时间util Date
	 * @throws ParseException 在转换时出现的转换异常
	 */
	public static java.util.Date parseUtilDate(String utilDateStr, String pattern) throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.parse(utilDateStr);
	}

    /**
     * 两个时间字符串做差并返回秒值
     * @param dateStr1
     * @param dateStr2
     * @return
     * @throws ParseException
     */
    public static int datesReduceReturnSeconds(String dateStr1, String dateStr2) throws ParseException{
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date1 = format.parse(dateStr1);
        Date date2 = format.parse(dateStr2);
        int result = (int) ((date1.getTime() - date2.getTime()) / (1000));//*3600*24
        return result;
    }

    /**
     * 获取当前日期的前几天
     * @param date
     * @return
     */
    public static Date getDaysBeforeDay(Date date, int daysNum) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, daysNum);
        date = calendar.getTime();
        return date;
    }

    public static void main(String[] args) {
        try {
//            int result = DateUtil.datesReduceReturnSeconds("2018-06-28 15:00:08", "2018-06-29 15:00:00");
            Date smday = DateUtil.getDaysBeforeDay(new Date(), -3);
            System.out.println("-----result:" + smday);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
