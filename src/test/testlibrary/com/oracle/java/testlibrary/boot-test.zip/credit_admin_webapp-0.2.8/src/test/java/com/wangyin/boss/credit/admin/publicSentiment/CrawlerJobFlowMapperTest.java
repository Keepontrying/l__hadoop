package com.wangyin.boss.credit.admin.publicSentiment;

import com.wangyin.boss.credit.enterprise.beans.CrawlerJobFlow;
import com.wangyin.boss.credit.enterprise.dao.CrawlerJobFlowMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author huangzhiqiang
 * @data 2018/11/28
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class CrawlerJobFlowMapperTest {

    @Autowired
    private CrawlerJobFlowMapper mapper;

    @Test
    public void insertOrUpdate(){
        CrawlerJobFlow flow = new CrawlerJobFlow();
        flow.setId(8L);
        flow.setJobNo("123123123");
        flow.setPostStr("{\"id\":32,\"name\":\"想睡觉\",\"category\":0,\"targetUrl\":\"https://www.wdzj.com/\",\"targetUrlCode\":\"wdzj\",\"weight\":7,\"words\":[{\"weight\":6,\"jobId\":32,\"id\":76,\"type\":0,\"groupId\":21,\"word\":\"想自由\"},{\"weight\":1,\"jobId\":32,\"id\":77,\"type\":1,\"groupId\":21,\"word\":\"嘎嘎嘎\"}]}");
//        flow.setJobResId();
//        flow.setMessage();
//        flow.setState((byte)2);
        mapper.insertOrUpadte(flow);
    }
}
