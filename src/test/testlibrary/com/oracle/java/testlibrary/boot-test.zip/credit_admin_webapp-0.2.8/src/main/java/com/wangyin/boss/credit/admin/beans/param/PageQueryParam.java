package com.wangyin.boss.credit.admin.beans.param;

import java.io.Serializable;

/**
 * Created by anmeng on 2017/3/25.
 */
public class PageQueryParam implements Serializable {
    private static final long serialVersionUID = 4922664227418593405L;

    // 记录开始index
    private Integer start = 0;

    // 每页条数
    private Integer limit = 10;

    public Integer getStart() {
        return start;
    }

    public void setStart(Integer start) {
        this.start = start;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }
}
