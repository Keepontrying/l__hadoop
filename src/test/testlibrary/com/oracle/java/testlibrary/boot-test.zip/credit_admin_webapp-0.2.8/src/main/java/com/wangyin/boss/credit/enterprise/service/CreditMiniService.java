package com.wangyin.boss.credit.enterprise.service;

import java.util.List;

import com.jd.jr.boss.credit.facade.authen.beans.param.MiniProjectQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.MiniSampleQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.DueStatusParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.MiniCommAreaComplQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniCommonArea;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniProject;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniSampleBase;

/** 
* @desciption : 征信Mini尽调
* @author : yangjinlin@jd.com
* @date ：2017年10月22日 下午4:11:54 
* @version 1.0 
* @return  */
public interface CreditMiniService {

	/**
	 * 查询征信Mini尽调项目信息  分页 
	 * @param queryParam
	 * @return
	 */
	public CreditPage<CreditMiniProject> selectMiniProjectPageByParam(MiniProjectQueryParam queryParam);

	/**
	 * 查询征信Mini尽调样本信息  分页 
	 * @param queryParam
	 * @return
	 */
	public CreditPage<CreditMiniSampleBase> selectMiniSamplePageByParam(MiniSampleQueryParam queryParam);

	/**
	 * 查询有效的省份列表
	 * @param queryParam
	 * @return
	 */
	public List<CreditMiniCommonArea> queryValidMiniAreaList(MiniCommAreaComplQueryParam queryParam);

	/**
	 * 根据样本编号和状态再次发起样本详情的补充完善
	 * @param requestParam
	 * @return
	 */
	public CreditResponseData<String> doCompleSampleDetails(CreditRequestParam<List<DueStatusParam>> requestParam);

}
