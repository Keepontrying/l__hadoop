package com.wangyin.boss.credit.enterprise.controller;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import com.chinabank.core.utils.StringUtil;
import com.jd.jr.boss.credit.domain.common.enums.*;
import com.jd.jr.boss.credit.facade.channel.enterprise.enums.TaxPayerErrorCodeEnum;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.param.ChannelLogQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.param.CreditDealFlowQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.CreditChannelLogInfo;
import com.wangyin.boss.credit.admin.beans.TextValuePairs;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.enums.*;
import com.wangyin.operation.beans.UploadFile;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.jr.boss.credit.domain.common.entity.CreditCallTimesGather;
import com.jd.jr.boss.credit.facade.authen.beans.param.CallTimesGatherQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.param.CreditLogQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.CreditTradeLogInfo;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.QueryCountEntity;
import com.wangyin.boss.credit.admin.controller.BaseController;
import com.wangyin.boss.credit.admin.entity.CreditAccessDetails;
import com.wangyin.boss.credit.enterprise.service.CreditLogService;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : 业务日志controller 
* @author : yangjinlin@jd.com
* @date ：2018年4月26日 下午3:33:19 
* @version 1.0 
* @return  */
@Controller
@RequestMapping("/creditLog")
public class CreditLogController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CreditLogController.class);
	
	private static final Integer splitNumber = 30;
	
	@Autowired
	CreditLogService creditLogService;
	
	/**
	 * 页面跳转
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toTradeLogList.view")
	public Map<String, String> toTradeLogCallTimesList(@RequestParam Map<String, String> map,String merchantNo, String productId, String stepStatus) {
		map.put("merchantNo",merchantNo);
		map.put("productId",productId);
		map.put("stepStatus",AccessStepStatusEnum.enumValueOfByDesc(stepStatus).toName());
		return map;
	}

	/**
	 * 查询商户业务详单数据 分页  --- 变更为 查询商户交易流水信息   分页
	 * @param map
	 * @param queryParam
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryTradeLogList.do")
	public Map<String, Object> doQueryTradeLogListFromEs(@RequestParam Map<String, String> map, CreditLogQueryParam queryParam) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		try {
			List<CreditTradeLogInfo> dealFlowList = new ArrayList<CreditTradeLogInfo>();
			int dealFlowQryTotalCount = 0;
			int successCount = 0;
			int failCount = 0;
			CreditPage<CreditTradeLogInfo> tradeLogPage = creditLogService.queryTradeLogPage(queryParam);
			if(null == tradeLogPage || ( null != tradeLogPage && !tradeLogPage.isSuccess() ) ){
				resultMap.put("rows", dealFlowList);
				resultMap.put("total", dealFlowQryTotalCount);
				resultMap.put("successCount", successCount);
				resultMap.put("failCount", failCount);
				return resultMap;
			}
			
			for(CreditTradeLogInfo tradeLogInfo : tradeLogPage.getRows()){
				tradeLogInfo.setAccessStatus(AccessStatusEnum.enumValueOf(tradeLogInfo.getAccessStatus()).toDescription());
				tradeLogInfo.setStepStatus(AccessStepStatusEnum.enumValueOf(tradeLogInfo.getStepStatus()).toDescription());
				tradeLogInfo.setCallMode(AccessCallModeEnum.enumValueOf(tradeLogInfo.getCallMode()).toDescription());
				tradeLogInfo.setResource(CreditSourceEnum.enumValueOf(tradeLogInfo.getResource()).toDescription());
				tradeLogInfo.setRequestParam(tradeLogInfo.getRequestParam().replace("'", ""));
				tradeLogInfo.setResponseParam(tradeLogInfo.getResponseParam().replace("'", ""));
				if(tradeLogInfo.getRequestParam().length()>splitNumber){
					tradeLogInfo.setRequestParamBrief( StringEscapeUtils.escapeHtml(tradeLogInfo.getRequestParam().substring(0, splitNumber)+"...}"));
				}else{
					tradeLogInfo.setRequestParamBrief( StringEscapeUtils.escapeHtml(tradeLogInfo.getRequestParam())  );
				}
				if(tradeLogInfo.getResponseParam().length()>splitNumber){
					tradeLogInfo.setResponseParamBrief(StringEscapeUtils.escapeHtml(tradeLogInfo.getResponseParam().substring(0, splitNumber)+"...}"));
				}else{
					tradeLogInfo.setResponseParamBrief(StringEscapeUtils.escapeHtml(tradeLogInfo.getResponseParam()));
				}
				tradeLogInfo.setRequestParam(StringEscapeUtils.escapeHtml(tradeLogInfo.getRequestParam()).replace(",", ",<br/>"));
				tradeLogInfo.setResponseParam(StringEscapeUtils.escapeHtml(tradeLogInfo.getResponseParam()).replace(",", ",<br/>"));
				
			}
			resultMap.put("rows", tradeLogPage.getRows());
			resultMap.put("total", tradeLogPage.getTotal());
			String countField = "accessStatus";
			CreditResponseData<List<QueryCountEntity>> countDealFlowByFieldResp = creditLogService.countCreditLogByField(queryParam, countField);
			resultMap.put("successCount", successCount);
			resultMap.put("failCount", failCount);
			if(null == countDealFlowByFieldResp || (null!=countDealFlowByFieldResp && !countDealFlowByFieldResp.isSuccess())){
				return resultMap;
			}
			for(QueryCountEntity qryCountEntity : countDealFlowByFieldResp.getData()){
				if(!resultMap.containsKey("success") && AccessStatusEnum.SUCCESS.toName().equalsIgnoreCase(qryCountEntity.getCountKey())){
					resultMap.put("successCount", qryCountEntity.getCountValue());
					continue;
				} else if( !resultMap.containsKey("fail") &&  AccessStatusEnum.FAIL.toName().equalsIgnoreCase(qryCountEntity.getCountKey())){
					resultMap.put("failCount", qryCountEntity.getCountValue());
					continue;
				}else{
					LOGGER.info("this qryCountEntity neednt show, {}" , GsonUtil.getInstance().toJson(qryCountEntity));
				}
			}
			failCount = (int) (tradeLogPage.getTotal()-Long.valueOf(resultMap.get("successCount").toString()));
			resultMap.put("failCount", failCount);
			
		} catch (Exception e) {
			LOGGER.error("doQueryTradeLogListFromEs failed, {}", e);
			resultMap.put("rows", new ArrayList<CreditAccessDetails>());
			resultMap.put("total", 0);
			resultMap.put("successCount", 0);
			resultMap.put("failCount", 0);
		}
		
		return resultMap;
	}

    /**
     * 下载征信业务流水数据
     * @param params
     * @param queryParam
     * @return
     */
    @RequestMapping("downTradeLogQueryResult.download")
    @ResponseBody
    public UploadFile downTradeLogQueryResult(@RequestParam Map<String, Object> params, CreditLogQueryParam queryParam) {
        return creditLogService.downTradeLogQueryResult(queryParam);
    }
	
	/**
	 * 查询征信业务流水调用次数汇总信息 分页
	 * @param map
	 * @param queryParam
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryTradeLogCallTimesList.do")
	public Map<String, Object> doQueryTradeLogCallTimesList(@RequestParam Map<String, String> map, CallTimesGatherQueryParam queryParam) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
		int callTimesGatherCount = 0 ;
		try {
			callTimesGatherCount = creditLogService.queryTradeLogCallTimesGatherListCount(queryParam);
			if(callTimesGatherCount != 0){
				callTimesGatherList = creditLogService.queryTradeLogCallTimesGatherList(queryParam);
				for(CreditCallTimesGather callTimes : callTimesGatherList){
					callTimes.setAccessStatus(AccessStatusEnum.enumValueOf(callTimes.getAccessStatus()).toDescription());
					callTimes.setStepStatus(AccessStepStatusEnum.enumValueOf(callTimes.getStepStatus()).toDescription());
					callTimes.setResource(CreditSourceEnum.enumValueOf(callTimes.getResource()).toDescription());
					callTimes.setCallMode(AccessCallModeEnum.enumValueOf(callTimes.getCallMode()).toDescription());
				}
			}
		} catch (Exception e) {
			LOGGER.error("doQueryTradeLogCallTimesList failed, {}", e);
		}
		resultMap.put("rows", callTimesGatherList);
		resultMap.put("total", callTimesGatherCount);
		
		return resultMap;
	}
	
	/**
	 * 根据商户维度查询调用量情况
	 * @param map
	 * @param queryParam
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doQueryMerchTradeLogCallTimesList.biz")
	public Map<String, Object> doQueryMerchTradeLogCallTimesList(@RequestParam Map<String, String> map, CallTimesGatherQueryParam queryParam) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
		int callTimesGatherCount = 0 ;
		try {
			callTimesGatherCount = creditLogService.queryMerchTradeLogCallTimesGatherListCount(queryParam);
			if(callTimesGatherCount != 0){
				callTimesGatherList = creditLogService.queryMerchTradeLogCallTimesGatherList(queryParam);
				for(CreditCallTimesGather callTimes : callTimesGatherList){
					int failCount = callTimes.getCallTotal()-callTimes.getCallTimes();
					callTimes.setFailCount(failCount);
					BigDecimal fail = new BigDecimal(failCount).divide(new BigDecimal(callTimes.getCallTotal()), 4,
							RoundingMode.FLOOR);
					DecimalFormat df = new DecimalFormat("###.##");
					callTimes.setFailRate(df.format(fail.multiply(new BigDecimal(100))) + "%");
				}
			}
		} catch (Exception e) {
			LOGGER.error("doQueryMerchTradeLogCallTimesList failed, {}", e);
		}
		resultMap.put("rows", callTimesGatherList);
		resultMap.put("total", callTimesGatherCount);
		return resultMap;
	}
	
	/**
	 * 页面跳转
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toMerchProdTradeLogCallTimesList.view")
	public Map<String, String> toMerchProdTradeLogCallTimesList(@RequestParam Map<String, String> map,String merchantNo) {
		map.put("merchantNo",merchantNo);
		return map;
	}
	
	/**
	 * 根据商户+产品 维度查询调用量情况
	 * @param map
	 * @param queryParam
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doQueryMerchProdTradeLogCallTimesList.do")
	public Map<String, Object> doQueryMerchProdTradeLogCallTimesList(@RequestParam Map<String, String> map, CallTimesGatherQueryParam queryParam) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
		int callTimesGatherCount = 0 ;
		try {
			callTimesGatherCount = creditLogService.queryMerchProdTradeLogCallTimesGatherListCount(queryParam);
			if(callTimesGatherCount != 0){
				callTimesGatherList = creditLogService.queryMerchProdTradeLogCallTimesGatherList(queryParam);
				for(CreditCallTimesGather callTimes : callTimesGatherList){
					int failCount = callTimes.getCallTotal()-callTimes.getCallTimes();
					callTimes.setFailCount(failCount);
					BigDecimal fail = new BigDecimal(failCount).divide(new BigDecimal(callTimes.getCallTotal()), 4,
							RoundingMode.FLOOR);
					DecimalFormat df = new DecimalFormat("###.##");
					callTimes.setFailRate(df.format(fail.multiply(new BigDecimal(100))) + "%");
				}
			}
		} catch (Exception e) {
			LOGGER.error("doQueryMerchProdTradeLogCallTimesList failed, {}", e);
		}
		resultMap.put("rows", callTimesGatherList);
		resultMap.put("total", callTimesGatherCount);
		return resultMap;
	}
	
	/**
	 * 页面跳转
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toMerchProdStepTradeLogCallTimesList.view")
	public Map<String, String> toMerchProdStepTradeLogCallTimesList(@RequestParam Map<String, String> map,String merchantNo, String productId) {
		map.put("merchantNo",merchantNo);
		map.put("productId",productId);
		
		return map;
	}
	
	/**
	 * 根据商户+产品+详细状态 维度查询调用量情况
	 * @param map
	 * @param queryParam
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doQueryMerchProdStepTradeLogCallTimesList.do")
	public Map<String, Object> doQueryMerchProdStepTradeLogCallTimesList(@RequestParam Map<String, String> map, CallTimesGatherQueryParam queryParam) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
		int callTimesGatherCount = 0 ;
		try {
			callTimesGatherCount = creditLogService.queryMerchProdStepTradeLogCallTimesGatherListCount(queryParam);
			if(callTimesGatherCount != 0){
				callTimesGatherList = creditLogService.queryMerchProdStepTradeLogCallTimesGatherList(queryParam);
				for(CreditCallTimesGather callTimes : callTimesGatherList){
					callTimes.setStepStatus(AccessStepStatusEnum.enumValueOf(callTimes.getStepStatus()).toDescription());
					int failCount = callTimes.getCallTotal()-callTimes.getCallTimes();
					callTimes.setFailCount(failCount);
					BigDecimal fail = new BigDecimal(failCount).divide(new BigDecimal(callTimes.getCallTotal()), 4,
							RoundingMode.FLOOR);
					DecimalFormat df = new DecimalFormat("###.##");
					callTimes.setFailRate(df.format(fail.multiply(new BigDecimal(100))));
					if(failCount != 0){
                        callTimes.setParamerrorRate(BigDecimal.valueOf(callTimes.getParamerrorTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString());
                        callTimes.setBillfailRate(BigDecimal.valueOf(callTimes.getBillfailTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString());
                        callTimes.setUsercloseRate(BigDecimal.valueOf(callTimes.getUsercloseTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString());
                        callTimes.setServcloseRate(BigDecimal.valueOf(callTimes.getServcloseTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString());
                        callTimes.setServblackRate(BigDecimal.valueOf(callTimes.getServblackTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString());
                        callTimes.setNobalanceRate(BigDecimal.valueOf(callTimes.getNobalanceTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString());
                        callTimes.setNostrategyRate(BigDecimal.valueOf(callTimes.getNostrategyTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString());
                        callTimes.setInterfailRate(BigDecimal.valueOf(callTimes.getInterfailTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString());
                        callTimes.setNodataRate(BigDecimal.valueOf(callTimes.getNodataTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString());
                        callTimes.setSystemerrorRate(BigDecimal.valueOf(callTimes.getSystemerrorTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString());
                    }else{
                        callTimes.setParamerrorRate("0");
                        callTimes.setBillfailRate("0");
                        callTimes.setUsercloseRate("0");
                        callTimes.setServcloseRate("0");
                        callTimes.setServblackRate("0");
                        callTimes.setNobalanceRate("0");
                        callTimes.setNostrategyRate("0");
                        callTimes.setInterfailRate("0");
                        callTimes.setNodataRate("0");
                        callTimes.setSystemerrorRate("0");
                    }
				}
			}
		} catch (Exception e) {
			LOGGER.error("doQueryMerchProdStepTradeLogCallTimesList failed, {}", e);
		}
		resultMap.put("rows", callTimesGatherList);
		resultMap.put("total", callTimesGatherCount);
		return resultMap;
	}
	
	/**
	 * 根据商户+产品+来源 维度查询调用量情况
	 * @param map
	 * @param queryParam
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doQueryMerchProdResoTradeLogCallTimesList.biz")
	public Map<String, Object> doQueryMerchProdResoTradeLogCallTimesList(@RequestParam Map<String, String> map, CallTimesGatherQueryParam queryParam) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
		List<CreditCallTimesGather> callTimesGatherListNew = new ArrayList<CreditCallTimesGather>();
		List<CreditCallTimesGather> callTimesGatherList4Resource = new ArrayList<CreditCallTimesGather>();
		int callTimesGatherCount = 0 ;
		try {
			callTimesGatherCount = creditLogService.queryMerchProdResoTradeLogCallTimesGatherListCount(queryParam);
			if(callTimesGatherCount != 0){
				callTimesGatherList = creditLogService.queryMerchProdResoTradeLogCallTimesGatherList(queryParam);
				for(CreditCallTimesGather callTimes : callTimesGatherList){
					CreditCallTimesGather  callTimesNew = new CreditCallTimesGather();
                    if(StringUtils.isBlank(queryParam.getMerchantNo()) && null == queryParam.getProductId()
                            && StringUtils.isBlank(queryParam.getResource())){
                        BeanUtils.copyProperties(callTimes, callTimesNew);
                    }
                    callTimesNew.setCallTotal(callTimes.getCallTotal());
                    if(StringUtils.isNotBlank(queryParam.getMerchantNo())){
                        callTimesNew.setMerchantNo(callTimes.getMerchantNo());
                        callTimesNew.setMerchantName(callTimes.getMerchantName());
                    }
					if(null != queryParam.getProductId()){
						callTimesNew.setProductId(callTimes.getProductId());
						callTimesNew.setProductName(callTimes.getProductName());
					}
					if(StringUtils.isNotBlank(callTimesNew.getResource())){
						callTimesNew.setResource(CreditSourceEnum.enumValueOf(callTimesNew.getResource()).toDescription());
					}

					callTimesGatherListNew.add(callTimesNew);
				}
			}
			callTimesGatherList4Resource = creditLogService.queryResoTradeLogCallTimesGatherList(queryParam);
			for(CreditCallTimesGather callTimesGatherNew : callTimesGatherList4Resource){
                callTimesGatherNew.setResource(CreditSourceEnum.enumValueOf(callTimesGatherNew.getResource()).toDescription());
            }
		} catch (Exception e) {
			LOGGER.error("doQueryMerchProdResoTradeLogCallTimesList failed, {}", e);
		}
		resultMap.put("rows", callTimesGatherListNew);
		resultMap.put("total", callTimesGatherCount);
		resultMap.put("callTimesGatherList4Resource", callTimesGatherList4Resource);
		return resultMap;
	}

	/**
	 * 多条件查询渠道日志流水Lsit 分页
	 * @param map
	 * @param queryParam
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doQueryChannelLogList.biz")
	public Map<String, Object> doQueryChannelLogListFromEs(@RequestParam Map<String, String> map, ChannelLogQueryParam queryParam) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		try {
			List<CreditChannelLogInfo> channelLogList = new ArrayList<CreditChannelLogInfo>();
			int totalCount = 0;
			int successCount = 0;
			int failCount = 0;
			CreditPage<CreditChannelLogInfo> channelLogPage = creditLogService.queryChannelLogList(queryParam);
			if(null == channelLogPage || ( null != channelLogPage && !channelLogPage.isSuccess() ) ){
				resultMap.put("rows", channelLogList);
				resultMap.put("total", totalCount);
				resultMap.put("successCount", successCount);
				resultMap.put("failCount", failCount);
				return resultMap;
			}

			for(CreditChannelLogInfo channelLogInfo : channelLogPage.getRows()){
				channelLogInfo.setChannel(CreditChannelTypeEnum.enumValueOf(channelLogInfo.getChannel()).toDescription());
                channelLogInfo.setInterfaceCode(CreditChannelInterfaceCodeInsCodeEnum.enumValueOfInterfaceCode(channelLogInfo.getInterfaceCode()).getDescription());
				channelLogInfo.setReturnStatus(CreditChannelReturnStatusEnum.enumValueOf(channelLogInfo.getReturnStatus()).toDescription());
				channelLogInfo.setRequestParam(channelLogInfo.getRequestParam().replace("'", ""));
				channelLogInfo.setResponseParam(channelLogInfo.getResponseParam().replace("'", ""));
				if(channelLogInfo.getRequestParam().length()>splitNumber){
					channelLogInfo.setRequestParamBrief( StringEscapeUtils.escapeHtml(channelLogInfo.getRequestParam().substring(0, splitNumber)+"...}"));
				}else{
					channelLogInfo.setRequestParamBrief( StringEscapeUtils.escapeHtml(channelLogInfo.getRequestParam())  );
				}
				if(channelLogInfo.getResponseParam().length()>splitNumber){
					channelLogInfo.setResponseParamBrief(StringEscapeUtils.escapeHtml(channelLogInfo.getResponseParam().substring(0, splitNumber)+"...}"));
				}else{
					channelLogInfo.setResponseParamBrief(StringEscapeUtils.escapeHtml(channelLogInfo.getResponseParam()));
				}
				channelLogInfo.setRequestParam(StringEscapeUtils.escapeHtml(channelLogInfo.getRequestParam()).replace(",", ",<br/>"));
				channelLogInfo.setResponseParam(StringEscapeUtils.escapeHtml(channelLogInfo.getResponseParam()).replace(",", ",<br/>"));

			}
			resultMap.put("rows", channelLogPage.getRows());
			resultMap.put("total", channelLogPage.getTotal());
			String countField = "returnStatus";
			CreditResponseData<List<QueryCountEntity>> countByFieldResp = creditLogService.countChannelLogByField(queryParam, countField);
			resultMap.put("successCount", successCount);
			resultMap.put("failCount", failCount);
			if(null == countByFieldResp || (null!=countByFieldResp && !countByFieldResp.isSuccess())){
				return resultMap;
			}
			for(QueryCountEntity qryCountEntity : countByFieldResp.getData()){
				if(!resultMap.containsKey("true") && "true".equalsIgnoreCase(qryCountEntity.getCountKey())){
					resultMap.put("successCount", qryCountEntity.getCountValue());
					continue;
				} else if( !resultMap.containsKey("fail") &&  "fail".equalsIgnoreCase(qryCountEntity.getCountKey())){
					resultMap.put("failCount", qryCountEntity.getCountValue());
					continue;
				}else{
					LOGGER.info("this qryCountEntity neednt show, {}" , GsonUtil.getInstance().toJson(qryCountEntity));
				}
			}
			failCount = (int) (channelLogPage.getTotal()-Long.valueOf(resultMap.get("successCount").toString()));
			resultMap.put("failCount", failCount);

		} catch (Exception e) {
			LOGGER.error("doQueryChannelLogListFromEs failed, {}", e);
			resultMap.put("rows", new ArrayList<CreditChannelLogInfo>());
			resultMap.put("total", 0);
			resultMap.put("successCount", 0);
			resultMap.put("failCount", 0);
		}
		return resultMap;
	}

	/**
	 * 查询渠道类型枚举类作为下拉数据源
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryChannelTypeInEnum.do")
	public Map<String, Object> queryChannelTypeInEnum(@RequestParam Map<String, Object> map) {
		Map<String, Object> result = new HashMap<String, Object>();
		List<TextValuePairs> list = new ArrayList<TextValuePairs>();
		for(CreditChannelTypeEnum status : CreditChannelTypeEnum.values()){
			if(null == status.toName() || "NULL".equals(status.toName())){
				continue;
			}else{
				TextValuePairs pairs = new TextValuePairs(status.toDescription(), status.toName());
				list.add(pairs);
			}
		}
		result.put("channelTypeList", list);
		return result;
	}

    /**
     * 下载业务流水商户维度调用量数据
     * @param params
     * @param queryParam
     * @return
     */
    @RequestMapping("downMerchTradeLogCallTimes.download")
    @ResponseBody
    public UploadFile downMerchTradeLogCallTimes(@RequestParam Map<String, Object> params, CallTimesGatherQueryParam queryParam) {
        queryParam.setStart(null);
        queryParam.setLimit(null);
        return creditLogService.downMerchTradeLogCallTimes(queryParam);
    }

    /**
     * 下载业务流水商户产品来源 维度调用量数据
     * @param params
     * @param queryParam
     * @return
     */
    @RequestMapping("downMerchProdTradeLogCallTimes.download")
    @ResponseBody
    public UploadFile downMerchProdTradeLogCallTimes(@RequestParam Map<String, Object> params, CallTimesGatherQueryParam queryParam) {
        queryParam.setStart(null);
        queryParam.setLimit(null);
        return creditLogService.downMerchProdTradeLogCallTimes(queryParam);
    }

    /**
     * 下载业务流水商户产品来源维度调用量数据
     * @param params
     * @param queryParam
     * @return
     */
    @RequestMapping("downMerchProdResoTradeLogCallTimes.download")
    @ResponseBody
    public UploadFile downMerchProdResoTradeLogCallTimes(@RequestParam Map<String, Object> params, CallTimesGatherQueryParam queryParam) {
        queryParam.setStart(null);
        queryParam.setLimit(null);
        String[] titles = { "商户号","商户名称","产品名称","来源", "总调用量"};
        String[] properties = { "merchantNo","merchantName", "productName", "resource", "callTotal"};
        String originalName = "业务流水商户产品来源维度调用量查询结果";
        List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
        List<CreditCallTimesGather> callTimesGatherListNew = new ArrayList<CreditCallTimesGather>();
        callTimesGatherList = creditLogService.queryMerchProdResoTradeLogCallTimesGatherList(queryParam);
        for(CreditCallTimesGather callTimes : callTimesGatherList){
            CreditCallTimesGather  callTimesNew = new CreditCallTimesGather();
            callTimesNew.setCallTotal(callTimes.getCallTotal());
            if(StringUtils.isBlank(queryParam.getMerchantNo()) && null == queryParam.getProductId()
                    && StringUtils.isBlank(queryParam.getResource())){
                BeanUtils.copyProperties(callTimes, callTimesNew);
            }
            if(StringUtils.isNotBlank(queryParam.getMerchantNo())){
                callTimesNew.setMerchantNo(callTimes.getMerchantNo());
                callTimesNew.setMerchantName(callTimes.getMerchantName());
            }
            if(null != queryParam.getProductId()){
                callTimesNew.setProductId(callTimes.getProductId());
                callTimesNew.setProductName(callTimes.getProductName());
            }
            if(StringUtils.isNotBlank(callTimesNew.getResource())){
                callTimesNew.setResource(CreditSourceEnum.enumValueOf(callTimesNew.getResource()).toDescription());
            }
            callTimesGatherListNew.add(callTimesNew);
        }
        return creditLogService.downTradeLogCallTimes(callTimesGatherListNew, titles, properties, originalName);
    }

    /**
     * 下载 业务流水调用量汇总查询
     * @param params
     * @param queryParam
     * @return
     */
    @RequestMapping("downTradeLogCallTimes.download")
    @ResponseBody
    public UploadFile downTradeLogCallTimes(@RequestParam Map<String, Object> params, CallTimesGatherQueryParam queryParam) {
        queryParam.setStart(null);
        queryParam.setLimit(null);
        String[] titles = { "汇总号","汇总时间","商户号","商户名称","产品名称","业务状态","详细状态","来源", "调用量", "调用模式"};
        String[] properties = { "gatherNo","startDate","merchantNo","merchantName","productName","accessStatus","stepStatus","resource", "callTimes", "callMode"};
        String originalName = "业务流水调用量汇总查询结果";
        List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
        callTimesGatherList = creditLogService.queryTradeLogCallTimesGatherList(queryParam);
        for(CreditCallTimesGather callTimes : callTimesGatherList){
            callTimes.setAccessStatus(StringUtil.isBlank(callTimes.getAccessStatus()) ? "-": AccessStatusEnum.enumValueOf(callTimes.getAccessStatus()).toDescription());
            callTimes.setStepStatus(StringUtil.isBlank(callTimes.getStepStatus()) ? "-": AccessStepStatusEnum.enumValueOf(callTimes.getStepStatus()).toDescription());
            callTimes.setResource(StringUtil.isBlank(callTimes.getResource()) ? "-": CreditSourceEnum.enumValueOf(callTimes.getResource()).toDescription());
            callTimes.setCallMode(StringUtil.isBlank(callTimes.getCallMode()) ? "-": AccessCallModeEnum.enumValueOf(callTimes.getCallMode()).toDescription());
        }
        return creditLogService.downTradeLogCallTimes(callTimesGatherList, titles, properties, originalName);
    }

    /**
     * 页面跳转
     * @param map
     * @return
     */
    @ResponseBody
    @RequestMapping("toQueryProdTradeLogCallTimesList.view")
    public Map<String, String> toQueryProdTradeLogCallTimesList(@RequestParam Map<String, String> map,String merchantNo) {
        map.put("merchantNo",merchantNo);
        return map;
    }

    /**
     * 根据 产品 维度查询调用量情况
     * @param map
     * @param queryParam
     * @return
     */
    @ResponseBody
    @RequestMapping("/doQueryProdTradeLogCallTimesList.do")
    public Map<String, Object> doQueryProdTradeLogCallTimesList(@RequestParam Map<String, String> map, CallTimesGatherQueryParam queryParam) {
        Map<String,Object> resultMap = new HashMap<String, Object>();
        List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
        int callTimesGatherCount = 0 ;
        try {
            callTimesGatherCount = creditLogService.queryProdTradeLogCallTimesGatherListCount(queryParam);
            if(callTimesGatherCount != 0){
                callTimesGatherList = creditLogService.queryProdTradeLogCallTimesGatherList(queryParam);
                for(CreditCallTimesGather callTimes : callTimesGatherList){
                    int failCount = callTimes.getCallTotal()-callTimes.getCallTimes();
                    callTimes.setFailCount(failCount);
                    BigDecimal fail = new BigDecimal(failCount).divide(new BigDecimal(callTimes.getCallTotal()), 4,
                            RoundingMode.FLOOR);
                    DecimalFormat df = new DecimalFormat("###.##");
                    callTimes.setFailRate(df.format(fail.multiply(new BigDecimal(100))) + "%");
                }
            }
        } catch (Exception e) {
            LOGGER.error("doQueryProdTradeLogCallTimesList failed, {}", e);
        }
        resultMap.put("rows", callTimesGatherList);
        resultMap.put("total", callTimesGatherCount);
        return resultMap;
    }

    /**
     * 下载 产品维度 业务流水调用量汇总查询
     * @param params
     * @param queryParam
     * @return
     */
    @RequestMapping("downProdTradeLogCallTimes.download")
    @ResponseBody
    public UploadFile downProdTradeLogCallTimes(@RequestParam Map<String, Object> params, CallTimesGatherQueryParam queryParam) {
        queryParam.setStart(null);
        queryParam.setLimit(null);
        String[] titles = { "产品名称","总调用量", "成功调用量","失败调用量","失败比例(%)"};
        String[] properties = { "productName", "callTotal", "callTimes","failCount", "failRate"};
        String originalName = "业务流水产品维度调用量汇总查询结果";
        List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
        callTimesGatherList = creditLogService.queryProdTradeLogCallTimesGatherList(queryParam);
        for(CreditCallTimesGather callTimes : callTimesGatherList){
            int failCount = callTimes.getCallTotal()-callTimes.getCallTimes();
            callTimes.setFailCount(failCount);
            BigDecimal fail = new BigDecimal(failCount).divide(new BigDecimal(callTimes.getCallTotal()), 4,
                    RoundingMode.FLOOR);
            DecimalFormat df = new DecimalFormat("###.##");
            callTimes.setFailRate(df.format(fail.multiply(new BigDecimal(100))) + "%");
        }
        return creditLogService.downTradeLogCallTimes(callTimesGatherList, titles, properties, originalName);
    }

    /**
     * 下载 商户产品详细状态 即失败原因分析 业务流水调用量汇总查询
     * @param params
     * @param queryParam
     * @return
     */
    @RequestMapping("downMerchProdStepTradeLogCallTimes.download")
    @ResponseBody
    public UploadFile downMerchProdStepTradeLogCallTimes(@RequestParam Map<String, Object> params, CallTimesGatherQueryParam queryParam) {
        queryParam.setStart(null);
        queryParam.setLimit(null);
        String[] titles = { "商户号","商户名称", "产品名称","总调用量","总成功量","总失败量","总失败量比例","参数错误","比例","余量不足","比例","无生效中计费","比例",
                "接口失败","比例","查无数据","比例","系统异常","比例","用户禁用","比例","服务关闭","比例","服务黑名单","比例","计费失败","比例"};
        String[] properties = { "merchantNo", "merchantName","productName","callTotal","callTimes","failCount","failRate","paramerrorTimes","paramerrorRate",
                "nobalanceTimes","nobalanceRate","nostrategyTimes","nostrategyRate","interfailTimes","interfailRate","nodataTimes","nodataRate","systemerrorTimes","systemerrorRate",
                "usercloseTimes","usercloseRate","servcloseTimes","servcloseRate","servblackTimes","servblackRate","billfailTimes","billfailRate"};
        String originalName = "商户产品详细状态失败原因分析查询结果";
        String date = (new SimpleDateFormat("yyyyMMddhhmmssSSS")).format(new Date());
        originalName = originalName+"_"+date;
        List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
        callTimesGatherList = creditLogService.queryMerchProdStepTradeLogCallTimesGatherList(queryParam);
        for(CreditCallTimesGather callTimes : callTimesGatherList){
            if(null == callTimes){ continue;}
            callTimes.setStepStatus(AccessStepStatusEnum.enumValueOf(callTimes.getStepStatus()).toDescription());
            int failCount = callTimes.getCallTotal()-callTimes.getCallTimes();
            callTimes.setFailCount(failCount);
            BigDecimal fail = new BigDecimal(failCount).divide(new BigDecimal(callTimes.getCallTotal()), 4,
                    RoundingMode.FLOOR);
            DecimalFormat df = new DecimalFormat("###.##");
            callTimes.setFailRate(df.format(fail.multiply(new BigDecimal(100))) + "%");
            if(failCount != 0){
                callTimes.setParamerrorRate(BigDecimal.valueOf(callTimes.getParamerrorTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
                callTimes.setBillfailRate(BigDecimal.valueOf(callTimes.getBillfailTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
                callTimes.setUsercloseRate(BigDecimal.valueOf(callTimes.getUsercloseTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
                callTimes.setServcloseRate(BigDecimal.valueOf(callTimes.getServcloseTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
                callTimes.setServblackRate(BigDecimal.valueOf(callTimes.getServblackTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
                callTimes.setNobalanceRate(BigDecimal.valueOf(callTimes.getNobalanceTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
                callTimes.setNostrategyRate(BigDecimal.valueOf(callTimes.getNostrategyTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
                callTimes.setInterfailRate(BigDecimal.valueOf(callTimes.getInterfailTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
                callTimes.setNodataRate(BigDecimal.valueOf(callTimes.getNodataTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
                callTimes.setSystemerrorRate(BigDecimal.valueOf(callTimes.getSystemerrorTimes()).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(failCount), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
            }else{
                callTimes.setParamerrorRate("0%");
                callTimes.setBillfailRate("0%");
                callTimes.setUsercloseRate("0%");
                callTimes.setServcloseRate("0%");
                callTimes.setServblackRate("0%");
                callTimes.setNobalanceRate("0%");
                callTimes.setNostrategyRate("0%");
                callTimes.setInterfailRate("0%");
                callTimes.setNodataRate("0%");
                callTimes.setSystemerrorRate("0%");
            }
        }
        return creditLogService.downTradeLogCallTimes(callTimesGatherList, titles, properties, originalName);
    }

    /**
     * 查询 商户产品详细状态  失败原因  详情
     * @param map
     * @return
     */
    @ResponseBody
    @RequestMapping("doQueryMerchProdStepTradeLogCallTimesListDetail.do")
    public Map<String, Object> doQueryMerchProdStepTradeLogCallTimesListDetail(@RequestParam Map<String, Object> map) {
        Map<String,Object> resultMap = new HashMap<String, Object>();
        resultMap = map;
        return resultMap;
    }

    /**
     * 下载 一般纳税人 失败原因分析 查询
     * @param params
     * @param queryParam
     * @return
     */
    @RequestMapping("downMerchProdStepTradeLogCallTimes4Ybnsr.download")
    @ResponseBody
    public UploadFile downMerchProdStepTradeLogCallTimes4Ybnsr(@RequestParam Map<String, Object> params, CallTimesGatherQueryParam queryParam) {
        queryParam.setStart(null);
        queryParam.setLimit(null);
        List<CreditCallTimesGather> callTimesGatherList = new ArrayList<CreditCallTimesGather>();
        String[] titles = { "商户号","商户名称", "产品名称","总失败量","网站无法访问","占比","无数据省份查询","占比","入参有误","占比","验证码问题","占比" };
        String[] properties = { "merchantNo", "merchantName","productName","failCount","systemerrorTimes","systemerrorRate","nodataTimes","nodataRate",
                "paramerrorTimes","paramerrorRate", "usercloseTimes","usercloseRate"};
        String originalName = "一般纳税人失败原因分析查询结果";
        String date = (new SimpleDateFormat("yyyyMMddhhmmssSSS")).format(new Date());
        originalName = originalName+"_"+date;
        CreditLogQueryParam queryParam4Count = new CreditLogQueryParam();
        queryParam4Count.setAccessStatus(AccessStatusEnum.FAIL.toName());
        queryParam4Count.setMerchantNo(queryParam.getMerchantNo());
        queryParam4Count.setProductCode(EnterpriseProductEnum4Common.ENTERPRISE_TAX_PAY_QUERY.toName());
        queryParam4Count.setStepStatus(queryParam.getStepStatus());
        queryParam4Count.setStartOccursDateStr(queryParam.getStartStartDateStr());
        queryParam4Count.setEndOccursDateStr(queryParam.getEndStartDateStr());
        String countField = "responseCode";
        CreditResponseData<List<QueryCountEntity>> countDealFlowByFieldResp = creditLogService.countCreditLogByField(queryParam4Count, countField);
        if(null != countDealFlowByFieldResp && countDealFlowByFieldResp.isSuccess() && CollectionUtils.isNotEmpty(countDealFlowByFieldResp.getData())){
            List<QueryCountEntity> countEntityList = countDealFlowByFieldResp.getData();
            CreditCallTimesGather callTiems = new CreditCallTimesGather();
            callTiems.setMerchantNo(queryParam.getMerchantNo());
            callTiems.setMerchantName(queryParam.getMerchantName());
            callTiems.setProductName(EnterpriseProductEnum4Common.ENTERPRISE_TAX_PAY_QUERY.toDescription());
            Integer totalFail = 0;
            Integer result_service_fail = 0;
            Integer result_system_exception = 0;
            Integer fetch_yzm_empty_code = 0;
            Integer fetch_param_code = 0;
            Integer fetch_enddate_code = 0;
            Integer fetch_taxpaynane_code = 0;
            Integer fetch_yzm_false_fail = 0;
            Integer fetch_taxpay_noexist = 0;
            Integer fetch_city_code = 0;
            Integer fetch_taxpay_code = 0;
            Integer fetch_reyzm = 0;
            for(QueryCountEntity countEntity : countEntityList){
                if(null == countEntity){ continue;}
                totalFail = totalFail + countEntity.getCountValue();
                if( TaxPayerErrorCodeEnum.RESULT_SERVICE_FAIL.getName().equalsIgnoreCase(countEntity.getCountKey())){
                    result_service_fail = countEntity.getCountValue();// 网站无法访问
                    continue;
                }else if(TaxPayerErrorCodeEnum.RESULT_SYSTEM_EXCEPTION.getName().equalsIgnoreCase(countEntity.getCountKey())){
                    result_system_exception = countEntity.getCountValue();// 网站无法访问
                    continue;
                }else if(TaxPayerErrorCodeEnum.FETCH_YZM_EMPTY_CODE.getName().equalsIgnoreCase(countEntity.getCountKey())){
                    fetch_yzm_empty_code = countEntity.getCountValue();//  验证码问题
                    continue;
                }else if(TaxPayerErrorCodeEnum.FETCH_PARAM_CODE.getName().equalsIgnoreCase(countEntity.getCountKey())){
                    fetch_param_code = countEntity.getCountValue();// 入参有误
                    continue;
                }else if(TaxPayerErrorCodeEnum.FETCH_ENDDATE_CODE.getName().equalsIgnoreCase(countEntity.getCountKey())){
                    fetch_enddate_code = countEntity.getCountValue();// 入参有误
                    continue;
                }else if(TaxPayerErrorCodeEnum.FETCH_TAXPAYNANE_CODE.getName().equalsIgnoreCase(countEntity.getCountKey())){
                    fetch_taxpaynane_code = countEntity.getCountValue();// 入参有误
                    continue;
                }else if(TaxPayerErrorCodeEnum.FETCH_YZM_FALSE_FAIL.getName().equalsIgnoreCase(countEntity.getCountKey())){
                    fetch_yzm_false_fail = countEntity.getCountValue();//  验证码问题
                    continue;
                }else if(TaxPayerErrorCodeEnum.FETCH_TAXPAY_NOEXIST.getName().equalsIgnoreCase(countEntity.getCountKey())){
                    fetch_taxpay_noexist = countEntity.getCountValue();// 入参有误
                    continue;
                }else if(TaxPayerErrorCodeEnum.FETCH_CITY_CODE.getName().equalsIgnoreCase(countEntity.getCountKey())){
                    fetch_city_code = countEntity.getCountValue();// 无数据省份查询
                    continue;
                }else if(TaxPayerErrorCodeEnum.FETCH_TAXPAY_CODE.getName().equalsIgnoreCase(countEntity.getCountKey())){
                    fetch_taxpay_code = countEntity.getCountValue();// 入参有误
                    continue;
                }else if(TaxPayerErrorCodeEnum.FETCH_REYZM.getName().equalsIgnoreCase(countEntity.getCountKey())){
                    fetch_reyzm = countEntity.getCountValue();// 验证码问题
                    continue;
                }
            }
            callTiems.setFailCount(totalFail);
            callTiems.setSystemerrorTimes(result_service_fail + result_system_exception);//网站无法访问
            callTiems.setSystemerrorRate(BigDecimal.valueOf(result_service_fail + result_system_exception).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(totalFail), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
            callTiems.setNodataTimes(fetch_city_code);//无数据省份查询
            callTiems.setNodataRate(BigDecimal.valueOf(fetch_city_code).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(totalFail), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
            callTiems.setParamerrorTimes(fetch_param_code+fetch_enddate_code+fetch_taxpaynane_code+fetch_taxpay_code+fetch_taxpay_noexist);//入参有误
            callTiems.setParamerrorRate(BigDecimal.valueOf(fetch_param_code+fetch_enddate_code+fetch_taxpaynane_code+fetch_taxpay_code+fetch_taxpay_noexist).multiply(
                    new BigDecimal("100")).divide(BigDecimal.valueOf(totalFail), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
            callTiems.setUsercloseTimes(fetch_yzm_empty_code+fetch_yzm_false_fail+fetch_reyzm);//验证码问题
            callTiems.setUsercloseRate(BigDecimal.valueOf(fetch_yzm_empty_code+fetch_yzm_false_fail+fetch_reyzm).multiply(new BigDecimal("100")).divide(BigDecimal.valueOf(totalFail), 0, BigDecimal.ROUND_HALF_UP ).toString()+"%");
            callTimesGatherList.add(callTiems);
        }


        return creditLogService.downTradeLogCallTimes(callTimesGatherList, titles, properties, originalName);
    }
	
}
