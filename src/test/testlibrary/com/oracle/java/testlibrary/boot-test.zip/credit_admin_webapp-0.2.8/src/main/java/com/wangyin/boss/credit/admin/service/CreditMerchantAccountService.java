package com.wangyin.boss.credit.admin.service;

public interface CreditMerchantAccountService {
	
	String selectAccountNo(int relationId, String chargeType);
}
