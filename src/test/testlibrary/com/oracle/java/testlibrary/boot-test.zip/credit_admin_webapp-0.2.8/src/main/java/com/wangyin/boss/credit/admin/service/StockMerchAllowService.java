package com.wangyin.boss.credit.admin.service;

import java.util.List;

import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractVerifyRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.paymentupdate.PaymentUpdateRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.paymentupdate.PaymentUpdateResponse;
import com.jd.jr.merchant.form.ResultObject;
import com.wangyin.boss.credit.admin.entity.StockMerchProStrategyAllow;
import com.wangyin.boss.credit.admin.entity.StockMerchProStrategyAllowModel;
import com.wangyin.operation.common.beans.Response;
import com.wangyin.operation.common.beans.ResponseData;

/** 存量商户的余量接口处理类
* @desciption : 
* @author : yangjinlin@jd.com
* @date ：2016年11月21日 下午5:15:09 
* @version 1.0 
* @return  */
public interface StockMerchAllowService {

	/**
	 * 调用商户认证接口验证
	 * @param stockMerchProStrategyAllow 该接口用到的参数为商户号
	 * @return
	 * @throws Exception 
	 */
	String queryAuthMerchantByNo(StockMerchProStrategyAllow stockMerchProStrategyAllow) throws Exception;

	/**
	 * 根据商户号查询代缴费合同下的计费策略信息 分页
	 * @param stockMerchProStrategyAllow 该接口用到的参数为商户号<p/>
	 * 合同状态为代缴费即NOPAY
	 * @return
	 */
	List<StockMerchProStrategyAllow> selectStockMerchAllowByParam(StockMerchProStrategyAllow stockMerchProStrategyAllow);

	/**
	 * 根据商户号查询代缴费合同下的计费策略信息总记录条数 分页
	 * @param stockMerchProStrategyAllow 该接口用到的参数为商户号<p/>
	 * 合同状态为代缴费即NOPAY
	 * @return
	 */
	int selectStockMerchAllowCountByParam(StockMerchProStrategyAllow stockMerchProStrategyAllow);

	/**
	 * 调用存量商户余量信息提交dubbo接口
	 * @param reqParam
	 * @return 
	 * @throws Exception 
	 */
	ResponseData<PaymentUpdateResponse> addStockMerchAllowInfo(PaymentUpdateRequest reqParam) throws Exception;

	/**
	 * 确认合同
	 * @param contractVerifyReq 合同id和确认合同传入参数PASS
	 * @return
	 * @throws Exception 
	 */
	Response updateStockMerchContractConfirm(ContractVerifyRequest contractVerifyReq) throws Exception;

	
}
