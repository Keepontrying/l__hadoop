package com.wangyin.boss.credit.admin.controller;

import com.wangyin.boss.credit.admin.entity.CreditItem;
import com.wangyin.boss.credit.admin.entity.CreditProduct;
import com.wangyin.boss.credit.admin.enums.CreditProductChargeStatusEnum;
import com.wangyin.boss.credit.admin.enums.CreditProductSortEnum;
import com.wangyin.boss.credit.admin.service.CreditProductService;
import com.wangyin.operation.common.beans.ResponseData;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 产品相关
 * @author jiangbo
 * @since 20170317
 */
@Controller
@RequestMapping("/creditProduct")
public class CreditProductController extends BaseController {

	private static Logger logger = LoggerFactory.getLogger(CreditProductController.class);

	@Autowired
	private CreditProductService creditProductService;

	@ResponseBody
	@RequestMapping("doQueryCreditProduct.do")
	public Map<String, Object> doQueryAuditContract(@RequestParam Map<String, Object> map, CreditProduct creditProduct){
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");

		try {
			List<CreditProduct> creditProductList = creditProductService.select(creditProduct);
			for(CreditProduct product : creditProductList){
				product.setChargeStatus(CreditProductChargeStatusEnum.enumValueOf(product.getChargeStatus()).toDescription());
				product.setProductSort(CreditProductSortEnum.enumValueOf(product.getProductSort()).toDescription());
			}
			int creditProductCount = creditProductService.selectCount(creditProduct);
			resultMap.put("rows", creditProductList);
			resultMap.put("total", creditProductCount);
		}catch (Exception e){
			logger.error("doQueryCreditProduct error,creditProduct:{}", ReflectionToStringBuilder.toString(creditProduct), e);
			resultMap.put("rows", new ArrayList<CreditProduct>());
			resultMap.put("total", 0);
			resultMap.put("success", false);
			resultMap.put("message", "异常，请稍后重试");
		}

		return resultMap;
	}

	@ResponseBody
    @RequestMapping("listProduct.do")
    public ResponseData listProducts(CreditProduct cp) {
        List<CreditProduct> select = creditProductService.select(cp);
        return new ResponseData(select);
    }

	/**
	 * 查询还未添加到item的产品列表
	 * @param map
	 * @param
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doAvailableCreditProductToItem.do")
	public Map<String, Object> doAvailableCreditProductToItem(@RequestParam Map<String, Object> map){
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");

		try {
			List<CreditProduct> creditProductList = creditProductService.selectAvailableCreditProductToItem();
			resultMap.put("creditProductList", creditProductList);
		}catch (Exception e){
			logger.error("doAvailableCreditProductToItem error", e);
			resultMap.put("rows", new ArrayList<CreditProduct>());
			resultMap.put("success", false);
			resultMap.put("message", "异常，请稍后重试");
			return resultMap;
		}
		return resultMap;
	}

}
