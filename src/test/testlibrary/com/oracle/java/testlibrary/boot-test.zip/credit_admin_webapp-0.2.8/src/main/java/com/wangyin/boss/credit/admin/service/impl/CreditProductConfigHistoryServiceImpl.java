package com.wangyin.boss.credit.admin.service.impl;

import com.wangyin.boss.credit.admin.dao.CreditChangeRecordMapper;
import com.wangyin.boss.credit.admin.dao.CreditProductConfigHistoryMapper;
import com.wangyin.boss.credit.admin.dao.CreditProductConfigMapper;
import com.wangyin.boss.credit.admin.entity.CreditChangeRecord;
import com.wangyin.boss.credit.admin.entity.CreditProductConfig;
import com.wangyin.boss.credit.admin.entity.CreditProductConfigHistory;
import com.wangyin.boss.credit.admin.service.CreditProductConfigHistoryService;
import com.wangyin.boss.credit.admin.service.CreditProductConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/** 
* @desciption : 产品服务配置接口方法实现类
* @author : yangjinlin@jd.com
* @date ：2016年8月29日 下午3:27:17 
* @version 1.0 
* @return  */
@Service
public class CreditProductConfigHistoryServiceImpl implements CreditProductConfigHistoryService {

	@Autowired
    private CreditProductConfigHistoryMapper creditProductConfigHistoryMapper;

	@Override
	public List<CreditProductConfigHistory> selectCreProdConfHisByPams(CreditProductConfigHistory creditProductConfigHistory) {
		return creditProductConfigHistoryMapper.selectCreProdConfHisByPams(creditProductConfigHistory);
	}

	@Override
	public int addCreProdConfHistory(CreditProductConfigHistory creditProductConfigHistory) throws Exception {
		return creditProductConfigHistoryMapper.addCreProdConfHistory(creditProductConfigHistory);
	}

	@Override
	public int selectCountConfHisByPams(CreditProductConfigHistory creditProductConfigHistory) {
		return creditProductConfigHistoryMapper.selectCountConfHisByPams(creditProductConfigHistory);
	}
}
