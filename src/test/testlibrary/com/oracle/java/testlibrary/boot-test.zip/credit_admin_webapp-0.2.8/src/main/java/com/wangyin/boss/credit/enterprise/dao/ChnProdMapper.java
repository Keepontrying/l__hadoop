package com.wangyin.boss.credit.enterprise.dao;

import com.wangyin.boss.credit.enterprise.entity.ChnProd;

public interface ChnProdMapper {
    
    int deleteByPrimaryKey(Integer productId);

    
    int insert(ChnProd record);

    
    int insertSelective(ChnProd record);

    
    ChnProd selectByPrimaryKey(Integer productId);

    
    int updateByPrimaryKeySelective(ChnProd record);

    
    int updateByPrimaryKey(ChnProd record);
}