package com.wangyin.boss.credit.enterprise.beans;

import java.io.Serializable;

/**
 * Created by zhanghui12 on 2018/6/7.
 * 标准报告查询参数
 */
public class ReportQueryParam implements Serializable{

    private static final long serialVersionUID = -5106726311581831018L;
    /**
     * 商户号
     */
    private String merchantNo;
    /**
     * 商户名称
     */
    private String merchantName;
    /**
     * 开始时间
     */
    private String startTime;
    /**
     * 结束时间
     */
    private String finishTime;
    /**
     * 批次号
     */
    private String batchNo;
    /**
     * 目标企业名称
     */
    private String companyName;

    private int start;
    private int limit;

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(String finishTime) {
        this.finishTime = finishTime;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}
