package com.wangyin.boss.credit.enterprise.controller;

import com.google.gson.Gson;
import com.jd.jr.boss.credit.facade.authen.beans.entity.JsfConfigBean;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchDataQueryParam;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.admin.frame.utils.JSONUtils;
import com.wangyin.boss.credit.enterprise.constants.HspConstant;
import com.wangyin.boss.credit.enterprise.service.CreditBatchDeriveDataService;
import com.wangyin.boss.credit.enterprise.utils.HspUtil;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.beans.UploadFile;
import com.wangyin.operation.beans.UploadObject;
import com.wangyin.operation.beans.UserModel;
import com.wangyin.operation.utils.DateUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 批量导出数据
 */
@Controller
@RequestMapping("/batchProcessing")
public class CreditBatchProcessingController {

    private static Logger logger = LoggerFactory.getLogger(CreditBatchProcessingController.class);

    @Autowired
    CreditBatchDeriveDataService creditBatchDeriveDataService;


    /**
     * TODO 查询下载列表
     * @param map
     * @return
     */
    @ResponseBody
    @RequestMapping("/pageList.do")
    protected Map<String, Object> queryFileList(BatchDataQueryParam jsfConfigBean,
                                                 @RequestParam(value = "user",required = false) UserModel userModel) {
        logger.info("download files list query params:"+JSONUtils.toJSON(jsfConfigBean));
        if (StringUtil.isEmpty(jsfConfigBean.getOperator()) && userModel !=null) {
            jsfConfigBean.setOperator(userModel.getUserName());
        }
        return creditBatchDeriveDataService.exportDataList(jsfConfigBean);
    }

    /**
     * 上传参数文件
     *
     * @param map
     * @return
     */
    @RequestMapping("/doUploadFile.do")
    @ResponseBody
    public UploadObject doUploadAuthFile(@RequestParam Map<String, Object> map) {

        String uploadObjectStr = String.valueOf(map.get("uploadObject"));
        Gson gson = new Gson();

        UploadObject uploadObject = gson.fromJson(uploadObjectStr, UploadObject.class);
        uploadObject.setVersion("2.0");
        List<UploadFile> list = uploadObject.getFileList();
        for (UploadFile uploadFile : list) {
            uploadObject.getParams().put("fileName", uploadFile.getOriginalName());
            uploadFile.setPath("/credit/export/data");//设置上传到NFS的相对路径
            uploadFile.setName(DateUtil.getInstance(DateUtil.FORMAT8).format(new Date()));//设置上传到NFS的名称（不含后缀），具体可以看UploadObject的注释
            uploadFile.setTemp(true);
        }
        return uploadObject;
    }

    /**
     * 上传授权文件回调方法
     *
     * @param map
     * @return
     */
    @RequestMapping("/doUploadFileCallback.do")
    @ResponseBody //将UploadObject对象转换成json
    public Map<String, Object> doUploadAuthFileCallback(@RequestParam Map<String, Object> map ,
                                                        @RequestParam(value = "user",required = false) UserModel userModel) {
        logger.info("上传导出数据入参："+JSONUtils.toJSON(map));
        Map<String, Object> result = new HashMap<String, Object>();
        String uploadObjectStr = String.valueOf(map.get("uploadObject"));//拿到上传对象
        Gson gson = new Gson();//json处理工具随意
        UploadObject uploadObject = gson.fromJson(uploadObjectStr, UploadObject.class);//json->object
        List<UploadFile> list = uploadObject.getFileList();//得到上传文件列表
        Map<String, String> param = uploadObject.getParams();
        String fid = "";
        String filePath = "";
        if (list != null && list.size() > 0) {
            UploadFile uploadFile = list.get(0);
            logger.info(uploadFile.getPath());
            fid = HspUtil.fileUpload(HspUtil.File2byte(new File(uploadFile.getRealPathname())),uploadFile.getName(),
                    ConfigUtil.getString(HspConstant.HSP_BATCH_DERIVE_DATA_PATH));
            filePath = uploadFile.getRealPathname();
        }
        boolean flag = false;
        if (StringUtils.isNotEmpty(fid)) {
            String operator = "tourist";
            if(userModel != null && StringUtil.isNotEmpty(userModel.getUserName())){
                operator = userModel.getUserName();
            }
            param.put("param_fid", fid);
            param.put("operator", operator);
            flag = creditBatchDeriveDataService.upload(param,filePath);
        }
        if (StringUtils.isNotEmpty(fid) && flag) {
            logger.debug("文件上传成功");
            result.put("success", true);// 前台可能会做个处理，上传成功跳转等等。demo中页面只是使用了message中的信息
            result.put("message", "文件上传成功");
        } else {
            result.put("success", false);
            result.put("message", "文件上传失败");
        }
        return result;
    }


    @ResponseBody
    @RequestMapping("/outside/data.do")
    protected Map<String,Object> outsideDate(@RequestParam Map<String,Object> param,
                                             @RequestParam(value = "user",required = false) UserModel userModel){
        logger.info("外部数据导出参数：" + JSONUtils.toJSON(param));
        String operator = "tourist";
        if (userModel != null && StringUtil.isNotEmpty(userModel.getUserName())) {
            operator = userModel.getUserName();
        }
        param.put("operator", operator);
        return creditBatchDeriveDataService.exportOutsideData(param);
    }

    /**
     * TODO 查询已配置接口
     * @param jsfConfigBean
     * @return
     */
    @ResponseBody
    @RequestMapping("/jsfConfig/interfaceList.do")
    protected Map<String,Object> getJsfConfigInterfaceId(JsfConfigBean jsfConfigBean){
        logger.info("jsf接口列表查询：" + JSONUtils.toJSON(jsfConfigBean));
        return creditBatchDeriveDataService.getJsfConfigInterfaceId(jsfConfigBean);
    }

    /**
     * TODO 查询已配置方法列表
     * @param jsfConfigBean
     * @return
     */
    @ResponseBody
    @RequestMapping("/jsfConfig/methodList.do")
    protected Map<String,Object> getMethodList(JsfConfigBean jsfConfigBean){
        logger.info("jsf接口方法列表查询：" + JSONUtils.toJSON(jsfConfigBean));
        return creditBatchDeriveDataService.getMethodList(jsfConfigBean);
    }

    /**
     * TODO 查询产品商户信息
     * @param jsfConfigBean
     * @return
     */
    @ResponseBody
    @RequestMapping("/jsfConfig/userPin.do")
    protected Map<String,Object> getUserInfo(String id, String userPin){
        logger.info("根据jsf配置id,获取默认用户信息：" + JSONUtils.toJSON(userPin));
        return creditBatchDeriveDataService.getUserInfo(id,userPin);
    }

}
