package com.wangyin.boss.credit.admin.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import com.wangyin.boss.credit.admin.entity.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.facade.authen.api.CreditVipStatisticFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.VipMerchantQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.VipTaskDtoQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.wangyin.boss.credit.admin.beans.param.CreditVipEnterpriseQueryParam;
import com.wangyin.boss.credit.admin.beans.param.CreditVipMerchantQueryParam;
import com.wangyin.boss.credit.admin.enums.CreditOpenStatusEnum;
import com.wangyin.boss.credit.admin.enums.CreditYesFlagEnum;
import com.wangyin.boss.credit.admin.enums.VipAlarmEventEnum;
import com.wangyin.boss.credit.admin.enums.VipAlarmLevelEnum;
import com.wangyin.boss.credit.admin.service.CreditVipService;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : vip监控相关serviceImpl接口实现类
* @author : yangjinlin@jd.com
* @date ：2017年6月28日 下午6:28:57 
* @version 1.0 
* @return  */
@Service
public class CreditVipServiceImpl implements CreditVipService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CreditVipServiceImpl.class);
	
	@Resource 
	private CreditVipStatisticFacade creditVipStatisticFacade;

	@Override
	public CreditPage<CreditVip> selectVipMerchantPageByParam(CreditVipMerchantQueryParam queryParam) {
		VipMerchantQueryParam qryPrm = new VipMerchantQueryParam();
		qryPrm.setMerchantNo(queryParam.getMerchantNo());
		qryPrm.setMerchantName(queryParam.getMerchantName());
		qryPrm.setStartModifiedDateStr(queryParam.getStartModifiedDateStr());
		qryPrm.setEndModifiedDateStr(queryParam.getEndModifiedDateStr());
		qryPrm.setStart(queryParam.getStart());
		qryPrm.setLimit(queryParam.getLimit());
		CreditPage<CreditVip> responseData = creditVipStatisticFacade.selectVipMerchantPageByParam(qryPrm);
        return responseData;
	}

	@Override
	public CreditPage<CreditVipTask> selectVipTaskPageByParam(CreditVipEnterpriseQueryParam queryParam) {

		VipTaskDtoQueryParam param = new VipTaskDtoQueryParam();
		param.setStart(queryParam.getStart());
		param.setLimit(queryParam.getLimit());
		param.setMerchantNo(queryParam.getMerchantNo());
		param.setMerchantName(queryParam.getMerchantName());
		param.setStartModifiedDateStr(queryParam.getStartModifiedDateStr());
		param.setEndModifiedDateStr(queryParam.getEndModifiedDateStr());
		param.setEntName(queryParam.getEntName());
		param.setCertificateNumber(queryParam.getCardNumber());
		return creditVipStatisticFacade.selectVipTaskPageByParam(param);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public int batchModifyVipMerchantMonitorStatus(CreditVip creditVip) throws Exception {
		CreditRequestParam param = new CreditRequestParam();
		param.setParam(creditVip);
		return creditVipStatisticFacade.batchModifyVipMerchantMonitorStatus(param);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public CreditVip selectByMerchantId(Integer merchantId) {
		CreditRequestParam param = new CreditRequestParam();
		CreditVip creditVip = new CreditVip();
		creditVip.setMerchantId(merchantId);
		param.setParam(creditVip);
		return creditVipStatisticFacade.selectByMerchantId(param);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public Integer insertVipMerchant(CreditVip creditVip) throws Exception {
		CreditRequestParam param = new CreditRequestParam();
		param.setParam(creditVip);
		Integer vipId = null;
		try {
			vipId = creditVipStatisticFacade.insertVipMerchant(param);
			if(null != vipId ){
				List<CreditVipWithTime> vipTimeList = this.formatCreditVipTime(creditVip, vipId);
				CreditRequestParam timeParam = new CreditRequestParam();
				timeParam.setParam(vipTimeList);
				Integer vipTimeId = creditVipStatisticFacade.insertBatchVipTime(timeParam);
				CreditVipAlarmRule vipAlarmRule = new CreditVipAlarmRule();
				this.buildAlarmRule(vipAlarmRule, vipId);
				Integer insertRuleId = creditVipStatisticFacade.insertAlarmRule(vipAlarmRule);
				if(null != insertRuleId){
					List<CreditVipAlarmRuleDetail> alarmRuleDetailList = new ArrayList<CreditVipAlarmRuleDetail>();
					vipAlarmRule.setId(insertRuleId);
					this.buildAlarmRuleDetailList(vipAlarmRule, alarmRuleDetailList);
					int insertRuleDetailCount = creditVipStatisticFacade.insertBatchVipAlarmRuleDetails(alarmRuleDetailList);
				}
			}
		} catch (Exception e) {
			LOGGER.error(" insertVipMerchant() or insertBatchVipTime() exception : ", e);
			throw new Exception();
		}
		return vipId;
	}

	
	/**
	 * 格式化征信vip监控调度时间
	 * @param cv
	 * @param vipId
	 * @return
	 */
	private List<CreditVipWithTime> formatCreditVipTime(CreditVip cv, Integer vipId) {
		List<CreditVipWithTime> infoDetailList = new ArrayList<CreditVipWithTime>();
		for(String triggerTime : cv.getTriggerTimes()){
			CreditVipWithTime creditVipTime = new CreditVipWithTime();
			creditVipTime.setVipId(vipId);
			creditVipTime.setTriggerTime(Integer.valueOf(triggerTime));
			creditVipTime.setCreator(cv.getCreator());
			creditVipTime.setModifier(cv.getModifier());
			infoDetailList.add(creditVipTime);
		}
		return infoDetailList;
	}
	
	/**
	 * 构造vip监控方案参数
	 * @param vipId
	 * @return
	 */
	private CreditVipAlarmRule buildAlarmRule(CreditVipAlarmRule vipAlarmRule, Integer vipId) {
		vipAlarmRule.setRuleName("默认方案");
		vipAlarmRule.setRelVipId(vipId);
		vipAlarmRule.setRuleStatus(CreditOpenStatusEnum.OPEN.toName());
		vipAlarmRule.setDefaultFlag(CreditYesFlagEnum.YES.toName());
		vipAlarmRule.setModifier("SYSTEM");
		vipAlarmRule.setCreator("SYSTEM");
		vipAlarmRule.setCreatedDate(new Date());
		vipAlarmRule.setModifiedDate(new Date());
		return vipAlarmRule;
	}
	
	/**
	 * 构造vip监控方案明细参数
	 * @param vipAlarmRule
	 * @param alarmRuleDetailList
	 */
	private void buildAlarmRuleDetailList(CreditVipAlarmRule vipAlarmRule,
			List<CreditVipAlarmRuleDetail> alarmRuleDetailList) {
		CreditVipAlarmRuleDetail alarmRuleDetail1 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail1.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail1.setTriggerEventType(VipAlarmEventEnum.legalPersonNameUpdate.getEventType());
		alarmRuleDetail1.setTriggerEvent(VipAlarmEventEnum.legalPersonNameUpdate.getCode());
		alarmRuleDetail1.setAlarmLevel(VipAlarmLevelEnum.RED.getCode());
		alarmRuleDetail1.setCreatedDate(new Date());
		alarmRuleDetail1.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail1);
		CreditVipAlarmRuleDetail alarmRuleDetail2 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail2.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail2.setTriggerEventType(VipAlarmEventEnum.opToUpdate.getEventType());
		alarmRuleDetail2.setTriggerEvent(VipAlarmEventEnum.opToUpdate.getCode());
		alarmRuleDetail2.setAlarmLevel(VipAlarmLevelEnum.YELLOW.getCode());
		alarmRuleDetail2.setCreatedDate(new Date());
		alarmRuleDetail2.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail2);
		CreditVipAlarmRuleDetail alarmRuleDetail3 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail3.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail3.setTriggerEventType(VipAlarmEventEnum.regLocationUpdate.getEventType());
		alarmRuleDetail3.setTriggerEvent(VipAlarmEventEnum.regLocationUpdate.getCode());
		alarmRuleDetail3.setAlarmLevel(VipAlarmLevelEnum.ORANGE.getCode());
		alarmRuleDetail3.setCreatedDate(new Date());
		alarmRuleDetail3.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail3);
		CreditVipAlarmRuleDetail alarmRuleDetail4 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail4.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail4.setTriggerEventType(VipAlarmEventEnum.entNameUpdate.getEventType());
		alarmRuleDetail4.setTriggerEvent(VipAlarmEventEnum.entNameUpdate.getCode());
		alarmRuleDetail4.setAlarmLevel(VipAlarmLevelEnum.YELLOW.getCode());
		alarmRuleDetail4.setCreatedDate(new Date());
		alarmRuleDetail4.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail4);
		CreditVipAlarmRuleDetail alarmRuleDetail5 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail5.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail5.setTriggerEventType(VipAlarmEventEnum.businessScopeUpdate.getEventType());
		alarmRuleDetail5.setTriggerEvent(VipAlarmEventEnum.businessScopeUpdate.getCode());
		alarmRuleDetail5.setAlarmLevel(VipAlarmLevelEnum.YELLOW.getCode());
		alarmRuleDetail5.setCreatedDate(new Date());
		alarmRuleDetail5.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail5);
		CreditVipAlarmRuleDetail alarmRuleDetail6 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail6.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail6.setTriggerEventType(VipAlarmEventEnum.categoryUpdate.getEventType());
		alarmRuleDetail6.setTriggerEvent(VipAlarmEventEnum.categoryUpdate.getCode());
		alarmRuleDetail6.setAlarmLevel(VipAlarmLevelEnum.YELLOW.getCode());
		alarmRuleDetail6.setCreatedDate(new Date());
		alarmRuleDetail6.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail6);
		CreditVipAlarmRuleDetail alarmRuleDetail7 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail7.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail7.setTriggerEventType(VipAlarmEventEnum.shareHolderUpdate.getEventType());
		alarmRuleDetail7.setTriggerEvent(VipAlarmEventEnum.shareHolderUpdate.getCode());
		alarmRuleDetail7.setAlarmLevel(VipAlarmLevelEnum.RED.getCode());
		alarmRuleDetail7.setCreatedDate(new Date());
		alarmRuleDetail7.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail7);
		CreditVipAlarmRuleDetail alarmRuleDetail8 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail8.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail8.setTriggerEventType(VipAlarmEventEnum.entTypeUpdate.getEventType());
		alarmRuleDetail8.setTriggerEvent(VipAlarmEventEnum.entTypeUpdate.getCode());
		alarmRuleDetail8.setAlarmLevel(VipAlarmLevelEnum.YELLOW.getCode());
		alarmRuleDetail8.setCreatedDate(new Date());
		alarmRuleDetail8.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail8);
		CreditVipAlarmRuleDetail alarmRuleDetail9 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail9.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail9.setTriggerEventType(VipAlarmEventEnum.entStatusUpdate.getEventType());
		alarmRuleDetail9.setTriggerEvent(VipAlarmEventEnum.entStatusUpdate.getCode());
		alarmRuleDetail9.setAlarmLevel(VipAlarmLevelEnum.RED.getCode());
		alarmRuleDetail9.setCreatedDate(new Date());
		alarmRuleDetail9.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail9);
		CreditVipAlarmRuleDetail alarmRuleDetail10 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail10.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail10.setTriggerEventType(VipAlarmEventEnum.regCapitalUpdate.getEventType());
		alarmRuleDetail10.setTriggerEvent(VipAlarmEventEnum.regCapitalUpdate.getCode());
		alarmRuleDetail10.setAlarmLevel(VipAlarmLevelEnum.RED.getCode());
		alarmRuleDetail10.setCreatedDate(new Date());
		alarmRuleDetail10.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail10);
		CreditVipAlarmRuleDetail alarmRuleDetail11 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail11.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail11.setTriggerEventType(VipAlarmEventEnum.paidCapitalUpdate.getEventType());
		alarmRuleDetail11.setTriggerEvent(VipAlarmEventEnum.paidCapitalUpdate.getCode());
		alarmRuleDetail11.setAlarmLevel(VipAlarmLevelEnum.ORANGE.getCode());
		alarmRuleDetail11.setCreatedDate(new Date());
		alarmRuleDetail11.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail11);
		CreditVipAlarmRuleDetail alarmRuleDetail12 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail12.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail12.setTriggerEventType(VipAlarmEventEnum.regNoUpdate.getEventType());
		alarmRuleDetail12.setTriggerEvent(VipAlarmEventEnum.regNoUpdate.getCode());
		alarmRuleDetail12.setAlarmLevel(VipAlarmLevelEnum.YELLOW.getCode());
		alarmRuleDetail12.setCreatedDate(new Date());
		alarmRuleDetail12.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail12);
		CreditVipAlarmRuleDetail alarmRuleDetail13 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail13.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail13.setTriggerEventType(VipAlarmEventEnum.creditCodeUpdate.getEventType());
		alarmRuleDetail13.setTriggerEvent(VipAlarmEventEnum.creditCodeUpdate.getCode());
		alarmRuleDetail13.setAlarmLevel(VipAlarmLevelEnum.YELLOW.getCode());
		alarmRuleDetail13.setCreatedDate(new Date());
		alarmRuleDetail13.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail13);
		CreditVipAlarmRuleDetail alarmRuleDetail14 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail14.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail14.setTriggerEventType(VipAlarmEventEnum.mainStaffUpdate.getEventType());
		alarmRuleDetail14.setTriggerEvent(VipAlarmEventEnum.mainStaffUpdate.getCode());
		alarmRuleDetail14.setAlarmLevel(VipAlarmLevelEnum.ORANGE.getCode());
		alarmRuleDetail14.setCreatedDate(new Date());
		alarmRuleDetail14.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail14);
		CreditVipAlarmRuleDetail alarmRuleDetail15 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail15.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail15.setTriggerEventType(VipAlarmEventEnum.finChiefUpdate.getEventType());
		alarmRuleDetail15.setTriggerEvent(VipAlarmEventEnum.finChiefUpdate.getCode());
		alarmRuleDetail15.setAlarmLevel(VipAlarmLevelEnum.ORANGE.getCode());
		alarmRuleDetail15.setCreatedDate(new Date());
		alarmRuleDetail15.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail15);
		CreditVipAlarmRuleDetail alarmRuleDetail16 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail16.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail16.setTriggerEventType(VipAlarmEventEnum.liquidationUpdate.getEventType());
		alarmRuleDetail16.setTriggerEvent(VipAlarmEventEnum.liquidationUpdate.getCode());
		alarmRuleDetail16.setAlarmLevel(VipAlarmLevelEnum.RED.getCode());
		alarmRuleDetail16.setCreatedDate(new Date());
		alarmRuleDetail16.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail16);
		
		CreditVipAlarmRuleDetail alarmRuleDetail17 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail17.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail17.setTriggerEventType(VipAlarmEventEnum.entInvUpdate.getEventType());
		alarmRuleDetail17.setTriggerEvent(VipAlarmEventEnum.entInvUpdate.getCode());
		alarmRuleDetail17.setAlarmLevel(VipAlarmLevelEnum.YELLOW.getCode());
		alarmRuleDetail17.setCreatedDate(new Date());
		alarmRuleDetail17.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail17);
		CreditVipAlarmRuleDetail alarmRuleDetail18 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail18.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail18.setTriggerEventType(VipAlarmEventEnum.caseUpdate.getEventType());
		alarmRuleDetail18.setTriggerEvent(VipAlarmEventEnum.caseUpdate.getCode());
		alarmRuleDetail18.setAlarmLevel(VipAlarmLevelEnum.RED.getCode());
		alarmRuleDetail18.setCreatedDate(new Date());
		alarmRuleDetail18.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail18);
		CreditVipAlarmRuleDetail alarmRuleDetail19 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail19.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail19.setTriggerEventType(VipAlarmEventEnum.punishBreakUpdate.getEventType());
		alarmRuleDetail19.setTriggerEvent(VipAlarmEventEnum.punishBreakUpdate.getCode());
		alarmRuleDetail19.setAlarmLevel(VipAlarmLevelEnum.RED.getCode());
		alarmRuleDetail19.setCreatedDate(new Date());
		alarmRuleDetail19.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail19);
		CreditVipAlarmRuleDetail alarmRuleDetail20 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail20.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail20.setTriggerEventType(VipAlarmEventEnum.punishmentUpdate.getEventType());
		alarmRuleDetail20.setTriggerEvent(VipAlarmEventEnum.punishmentUpdate.getCode());
		alarmRuleDetail20.setAlarmLevel(VipAlarmLevelEnum.RED.getCode());
		alarmRuleDetail20.setCreatedDate(new Date());
		alarmRuleDetail20.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail20);
		CreditVipAlarmRuleDetail alarmRuleDetail21 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail21.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail21.setTriggerEventType(VipAlarmEventEnum.abnormalUpdate.getEventType());
		alarmRuleDetail21.setTriggerEvent(VipAlarmEventEnum.abnormalUpdate.getCode());
		alarmRuleDetail21.setAlarmLevel(VipAlarmLevelEnum.RED.getCode());
		alarmRuleDetail21.setCreatedDate(new Date());
		alarmRuleDetail21.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail21);
		CreditVipAlarmRuleDetail alarmRuleDetail22 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail22.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail22.setTriggerEventType(VipAlarmEventEnum.equityUpdate.getEventType());
		alarmRuleDetail22.setTriggerEvent(VipAlarmEventEnum.equityUpdate.getCode());
		alarmRuleDetail22.setAlarmLevel(VipAlarmLevelEnum.ORANGE.getCode());
		alarmRuleDetail22.setCreatedDate(new Date());
		alarmRuleDetail22.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail22);
		CreditVipAlarmRuleDetail alarmRuleDetail23 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail23.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail23.setTriggerEventType(VipAlarmEventEnum.mortgageUpdate.getEventType());
		alarmRuleDetail23.setTriggerEvent(VipAlarmEventEnum.mortgageUpdate.getCode());
		alarmRuleDetail23.setAlarmLevel(VipAlarmLevelEnum.ORANGE.getCode());
		alarmRuleDetail23.setCreatedDate(new Date());
		alarmRuleDetail23.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail23);
		CreditVipAlarmRuleDetail alarmRuleDetail24 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail24.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail24.setTriggerEventType(VipAlarmEventEnum.illegalUpdate.getEventType());
		alarmRuleDetail24.setTriggerEvent(VipAlarmEventEnum.illegalUpdate.getCode());
		alarmRuleDetail24.setAlarmLevel(VipAlarmLevelEnum.RED.getCode());
		alarmRuleDetail24.setCreatedDate(new Date());
		alarmRuleDetail24.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail24);
		CreditVipAlarmRuleDetail alarmRuleDetail25 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail25.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail25.setTriggerEventType(VipAlarmEventEnum.blackUpdate.getEventType());
		alarmRuleDetail25.setTriggerEvent(VipAlarmEventEnum.blackUpdate.getCode());
		alarmRuleDetail25.setAlarmLevel(VipAlarmLevelEnum.RED.getCode());
		alarmRuleDetail25.setCreatedDate(new Date());
		alarmRuleDetail25.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail25);
		CreditVipAlarmRuleDetail alarmRuleDetail26 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail26.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail26.setTriggerEventType(VipAlarmEventEnum.entCheckUpdate.getEventType());
		alarmRuleDetail26.setTriggerEvent(VipAlarmEventEnum.entCheckUpdate.getCode());
		alarmRuleDetail26.setAlarmLevel(VipAlarmLevelEnum.YELLOW.getCode());
		alarmRuleDetail26.setCreatedDate(new Date());
		alarmRuleDetail26.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail26);
		CreditVipAlarmRuleDetail alarmRuleDetail27 = new CreditVipAlarmRuleDetail();
		alarmRuleDetail27.setRelRuleId(vipAlarmRule.getId());
		alarmRuleDetail27.setTriggerEventType(VipAlarmEventEnum.qualifyUpdate.getEventType());
		alarmRuleDetail27.setTriggerEvent(VipAlarmEventEnum.qualifyUpdate.getCode());
		alarmRuleDetail27.setAlarmLevel(VipAlarmLevelEnum.YELLOW.getCode());
		alarmRuleDetail27.setCreatedDate(new Date());
		alarmRuleDetail27.setModifiedDate(new Date());
		alarmRuleDetailList.add(alarmRuleDetail27);
	}

	@Override
	public List<CreditVip> selectCreditVipByPrm(CreditVip creditVip) {
		VipMerchantQueryParam vipMerchantQryPrm = new VipMerchantQueryParam();
		vipMerchantQryPrm.setVipId(creditVip.getVipId());
		return creditVipStatisticFacade.selectCreditVipByPrm(vipMerchantQryPrm);
	}

	@Override
	public Integer updateVipMerchant(CreditVip creditVip) {
		boolean delFlag = false;
		CreditVipWithTime creditVipWithTime = new CreditVipWithTime();
		creditVipWithTime.setVipId(creditVip.getVipId());
		Integer delCounts = creditVipStatisticFacade.deleteVipTriggerTime(creditVipWithTime);
		LOGGER.info("deleteVipTriggerTime triggerTimeStrs:" + creditVip.getTriggerTimeStrs());
		delFlag = true;
		Integer vipTimeInsertCounts = null;
		if(true == delFlag ){
			List<CreditVipWithTime> vipTimeList = this.formatCreditVipTime(creditVip, creditVip.getVipId());
			CreditRequestParam timeParam = new CreditRequestParam();
			timeParam.setParam(vipTimeList);
			LOGGER.info("insertBatchVipTime vipTimeList:" + GsonUtil.getInstance().toJson(vipTimeList));
			vipTimeInsertCounts = creditVipStatisticFacade.insertBatchVipTime(timeParam);
			Integer vipMerchantUpd = creditVipStatisticFacade.updateVipMerchant(creditVip);
		}
		return vipTimeInsertCounts;
	}

    @Override
    public List<CreditProductSecond> selectProductSecondWithoutBlack(Integer merchantId) {
        return creditVipStatisticFacade.queryVipProducts(merchantId);
    }

}
