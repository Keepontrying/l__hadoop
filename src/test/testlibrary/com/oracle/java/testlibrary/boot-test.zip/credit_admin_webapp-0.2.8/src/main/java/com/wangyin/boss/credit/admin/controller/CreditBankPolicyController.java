package com.wangyin.boss.credit.admin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wangyin.boss.credit.admin.entity.CreditBankPolicy;
import com.wangyin.boss.credit.admin.enums.BankPolicyChannelEnum;
import com.wangyin.boss.credit.admin.enums.BankPolicyStatusEnum;
import com.wangyin.boss.credit.admin.service.CreditBankPolicyService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.rediscluster.client.CacheClusterClient;

/** 
* @desciption : 银行渠道策略controller
* @author : yangjinlin@jd.com
* @date ：2016年12月13日 下午3:46:48 
* @version 1.0 
* @return  */
@Controller
@RequestMapping("/bankPolicy")
public class CreditBankPolicyController extends BaseController {

	private static Logger logger = LoggerFactory.getLogger(CreditBankPolicyController.class);
	
	@Autowired 
	CreditBankPolicyService bankPolicyService;
	
	@Autowired
    protected CacheClusterClient cacheClusterClient;
	
	/**
	 * 查询银行渠道策略信息  分页
	 * @param map
	 * @param CreditBankPolicy
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryCreditBankPolicy.do")
	public Map<String, Object> doQueryBankPolicy(@RequestParam Map<String, String> map, CreditBankPolicy bankPolicy ) {
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		List<CreditBankPolicy> bankPolicyList = new ArrayList<CreditBankPolicy>();
		int bankPolicyCount = 0;
		
		try {
			bankPolicyList = bankPolicyService.selectBankPolicyByParam(bankPolicy);
			bankPolicyCount = bankPolicyService.selectBankPolicyCountByParam(bankPolicy);
		} catch (Exception e) {
			logger.error(e);
			
		}
		resultMap.put("rows", bankPolicyList);
		resultMap.put("total", bankPolicyCount);
		
		return resultMap;
	}
	
	/**
	 * 创建银行渠道策略信息
	 * @author yangjinlin@jd.com
	 * @param map
	 * @param bankPolicy
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doCreateCreditBankPolicy.do")
	public Map<String, Object> doCreateCreditBankPolicy(@RequestParam Map<String, String> map, CreditBankPolicy bankPolicy, String user) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "操作失败");
		
		try {
			
			String userName = null;
			try {
				userName = getLoginRealName(user);
			} catch (Exception e) {
				logger.error(e);
				userName = "error";
			}
			bankPolicy.setBankChannel(BankPolicyChannelEnum.DEFAULT.toName());
			bankPolicy.setPolicyStatus(BankPolicyStatusEnum.OPEN.toName());
			bankPolicy.setCreator(userName);
			bankPolicy.setModifier(userName);
			
			resultMap = paramsCheck(bankPolicy, resultMap);
			if("false".equals(resultMap.get("checkResultFlag").toString())){
				return resultMap;
			}
			List<CreditBankPolicy> bankPolicyList = bankPolicyService.selectBankPolicyByUniqueKey(bankPolicy);
			if(CollectionUtils.isEmpty(bankPolicyList)){//根据银行编码和借贷标记查询，该银行渠道策略信息不存在，则可进行修改
				
				cacheClusterClient.set(bankPolicy.getCardType()+"_"+bankPolicy.getBankCode()+"_bank_policy", bankPolicy.getTips());
				if(StringUtils.isBlank(cacheClusterClient.get(bankPolicy.getCardType()+"_"+bankPolicy.getBankCode()+"_bank_policy"))){
					logger.error("doCreateCreditBankPolicy r2mSet failure");
					resultMap.put("success", false);
					resultMap.put("message", "操作失败");
					return resultMap;
				}else{
					int count = bankPolicyService.insert(bankPolicy);
					if(count == 1){
						resultMap.put("success", true);
						resultMap.put("message", "操作成功");
					}else{
						resultMap.put("success", false);
						resultMap.put("message", "操作失败");
					}
				}
				
			}else{
				resultMap.put("success", false);
				resultMap.put("message", " 操作失败，该银行渠道策略已存在");
			}
			
		} catch (Exception e) {
			logger.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "操作异常");
		}
		
		return resultMap;
	}

	
	/**
	 * 跳转至银行渠道策略创业页面
	 */
	@ResponseBody
	@RequestMapping("toCreateCreditBankPolicy.view")
	public Map<String, Object> toCreateCreditBankPolicy(@RequestParam Map<String, Object> map) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		
		if(map.get("policyId") != null){
			CreditBankPolicy bankPolicy = bankPolicyService.selectBypolicyId(Integer.valueOf(String.valueOf(map.get("policyId"))));
			resultMap.put("bankPolicy", bankPolicy);
			return resultMap;
		}
		return map;
	}
	
	/**
	 * 修改银行渠道策略信息 
	 * @param map
	 * @param bankPolicy
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doEditCreditBankPolicy.do")
	public Map<String, Object> doEditCreditBankPolicy(@RequestParam Map<String, Object> map, CreditBankPolicy bankPolicy, String user,
			String bankCode1, String cardType1) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "操作失败");
		
		try {
			
			String userName = null;
			try {
				userName = getLoginRealName(user);
			} catch (Exception e) {
				logger.error(e);
				userName = "error";
			}
			bankPolicy.setModifier(userName);
			List<CreditBankPolicy> bankPolicyList = bankPolicyService.selectBankPolicyByUniqueKey(bankPolicy);
			
			if(CollectionUtils.isEmpty(bankPolicyList)){//根据银行编码、借贷标记、策略状态进行查询，该银行渠道策略信息不存在，则可进行修改
				
				if(BankPolicyStatusEnum.CLOSE.toName().equals(bankPolicy.getPolicyStatus())){//若该渠道策略为无效，则仅修改本地数据不修改redis缓存
					int count = bankPolicyService.updateByPolicyId(bankPolicy);
					if(count == 1){
						resultMap.put("success", true);
						resultMap.put("message", "操作成功");
					}
				}else{//若该渠道策略为有效，则不仅修改本地数据，也修改redis缓存
					cacheClusterClient.set(bankPolicy.getCardType()+"_"+bankPolicy.getBankCode()+"_bank_policy", bankPolicy.getTips());
					if(StringUtils.isBlank(cacheClusterClient.get(bankPolicy.getCardType()+"_"+bankPolicy.getBankCode()+"_bank_policy"))){
						logger.error("doEditCreditBankPolicy r2mSet failure");
						resultMap.put("success", false);
						resultMap.put("message", "操作失败");
						return resultMap;
					}else{
						cacheClusterClient.del(cardType1+"_"+bankCode1+"_bank_policy");//删除原银行渠道策略缓存
						if(StringUtils.isNotBlank(cacheClusterClient.get(cardType1+"_"+bankCode1+"_bank_policy"))){//不为空则证明删除失败
							logger.error("doEditCreditBankPolicy r2mDel failure");
							resultMap.put("success", false);
							resultMap.put("message", "操作失败");
							return resultMap;
						}else{
							int count = bankPolicyService.updateByPolicyId(bankPolicy);
							if(count == 1){
								resultMap.put("success", true);
								resultMap.put("message", "操作成功");
							}
						}
					}
				}
				
				
			}else{//根据银行编码、借贷标记、策略状态进行查询，该银行渠道策略信息存在且为自己，则可进行修改；否则，不可进行修改
				for(CreditBankPolicy cbp : bankPolicyList){
					if(cbp.getPolicyId() == bankPolicy.getPolicyId()){//存在的信息为本策略,则可修改
						resultMap = paramsCheck(bankPolicy, resultMap);
						if("false".equals(resultMap.get("checkResultFlag").toString())){
							return resultMap;
						}
						if(BankPolicyStatusEnum.CLOSE.toName().equals(bankPolicy.getPolicyStatus())){//若该渠道策略为无效，则仅修改本地数据不修改redis缓存
							int count = bankPolicyService.updateByPolicyId(bankPolicy);
							if(count == 1){
								resultMap.put("success", true);
								resultMap.put("message", "操作成功");
								return resultMap;
							}
						}else{//若该渠道策略为有效，则不仅修改本地数据，也修改redis缓存
							cacheClusterClient.set(bankPolicy.getCardType()+"_"+bankPolicy.getBankCode()+"_bank_policy", bankPolicy.getTips());
							if(StringUtils.isBlank(cacheClusterClient.get(bankPolicy.getCardType()+"_"+bankPolicy.getBankCode()+"_bank_policy"))){
								logger.error("doEditCreditBankPolicy r2mSet failure");
								resultMap.put("success", false);
								resultMap.put("message", "操作失败");
								return resultMap;
							}else{
								int count = bankPolicyService.updateByPolicyId(bankPolicy);
								if(count == 1){
									resultMap.put("success", true);
									resultMap.put("message", "操作成功");
									return resultMap;
								}
							}
						}
						
					}else{//存在的信息不为本策略,则不可修改
						resultMap.put("success", false);
						resultMap.put("message", " 操作失败，该银行渠道策略已存在");
					}
				}
				
			}
			
		} catch (Exception e) {
			logger.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "操作异常");
		}
		
		return resultMap;
	}
	
	/**
	 * 更改银行渠道策略状态操作
	 * @author yangjinlin@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doChangeBankPolicyStatus.do")
	public Map<String, Object> doChangeBankPolicyStatus(@RequestParam Map<String, Object> map, CreditBankPolicy bankPolicy, String user) {
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "修改成功");
		
		String userName = null;
		try {
			userName = getLoginRealName(user);
		} catch (Exception e) {
			logger.error(e);
			userName = "error";
		}

		try {
			
			if(null == bankPolicy.getPolicyId() || "".equals(bankPolicy.getPolicyId()) ||
					null == bankPolicy.getPolicyStatus() || "".equals(bankPolicy.getPolicyStatus()) ){
				resultMap.put("success", false);
				resultMap.put("message", "系统异常!");
				return resultMap;
			}
			
			CreditBankPolicy bp = new CreditBankPolicy();
			bp.setPolicyId(bankPolicy.getPolicyId());
			bp.setBankCode(bankPolicy.getBankCode());
			bp.setCardType(bankPolicy.getCardType());
			bp.setModifier(userName);
			if(BankPolicyStatusEnum.OPEN.toName().equals(bankPolicy.getPolicyStatus())){//OPEN变更为CLOSE
				bp.setPolicyStatus(BankPolicyStatusEnum.CLOSE.toName());
			}else if(BankPolicyStatusEnum.CLOSE.toName().equals(bankPolicy.getPolicyStatus())){
				bp.setPolicyStatus(BankPolicyStatusEnum.OPEN.toName());
			}
			List<CreditBankPolicy> bankPolicyList = bankPolicyService.selectBankPolicyByUniqueKey(bp);
			if(CollectionUtils.isEmpty(bankPolicyList)){//根据银行编码和借贷标记查询，该银行渠道策略信息不存在，则可进行修改
				
				if(BankPolicyStatusEnum.OPEN.toName().equals(bp.getPolicyStatus())){//更改为有效，则放入缓存
					cacheClusterClient.set(bankPolicy.getCardType()+"_"+bankPolicy.getBankCode()+"_bank_policy", bankPolicy.getTips());
					if(StringUtils.isBlank(cacheClusterClient.get(bankPolicy.getCardType()+"_"+bankPolicy.getBankCode()+"_bank_policy"))){
						logger.error("doCreateCreditBankPolicy r2mSet failure");
						resultMap.put("success", false);
						resultMap.put("message", "操作失败");
					}else{
						int count = bankPolicyService.updateByPolicyId(bp);
						if(count == 1){//成功
							resultMap.put("success", true);
							resultMap.put("message", "操作成功");
						}else{
							resultMap.put("success", false);
							resultMap.put("message", "操作失败");
						}
					}
				}else if(BankPolicyStatusEnum.CLOSE.toName().equals(bp.getPolicyStatus())){//更改为无效，则移出缓存
					cacheClusterClient.del(bankPolicy.getCardType()+"_"+bankPolicy.getBankCode()+"_bank_policy");
					if(StringUtils.isNotBlank(cacheClusterClient.get(bankPolicy.getCardType()+"_"+bankPolicy.getBankCode()+"_bank_policy"))){
						logger.error("doCreateCreditBankPolicy r2mDel failure");
						resultMap.put("success", false);
						resultMap.put("message", "操作失败");
					}else{
						int count = bankPolicyService.updateByPolicyId(bp);
						if(count == 1){//成功
							resultMap.put("success", true);
							resultMap.put("message", "操作成功");
						}else{
							resultMap.put("success", false);
							resultMap.put("message", "操作失败");
						}
					}
				}else{
					resultMap.put("success", false);
					resultMap.put("message", "操作失败");
					return resultMap;
				}
				
			}else{
				resultMap.put("success", false);
				resultMap.put("message", " 操作失败，该银行渠道策略已存在");
			}
			
		} catch (Exception e) {
			logger.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "操作异常");
		}
			
		return resultMap;
		
	}
	
	/**
	 * 操作时的参数校验项
	 * @param bankPolicy
	 * @param resultMap
	 * @return
	 */
	private Map<String, Object> paramsCheck(CreditBankPolicy bankPolicy, Map<String, Object> resultMap) {
		if(StringUtils.isEmpty(bankPolicy.getBankCode())){
			resultMap.put("checkResultFlag", false);
			resultMap.put("message", " 操作失败，请选择银行名称");
			return resultMap;
		}
		if(StringUtils.isEmpty(bankPolicy.getBankName())){
			resultMap.put("checkResultFlag", false);
			resultMap.put("message", " 操作失败，请选择银行名称");
			return resultMap;
		}
		if(StringUtils.isEmpty(bankPolicy.getCardType())){
			resultMap.put("checkResultFlag", false);
			resultMap.put("message", " 操作失败，请选择借贷标识");
			return resultMap;
		}
		if(StringUtils.isEmpty(bankPolicy.getUncheckedList())){
			resultMap.put("checkResultFlag", false);
			resultMap.put("message", " 操作失败，请选择非校验项");
			return resultMap;
		}
		if(StringUtils.isEmpty(bankPolicy.getTips())){
			resultMap.put("checkResultFlag", false);
			resultMap.put("message", " 操作失败，请输入提醒文案");
			return resultMap;
		}
		resultMap.put("checkResultFlag", true);
		resultMap.put("message", " 操作成功");
		return resultMap;
	}
	
}
