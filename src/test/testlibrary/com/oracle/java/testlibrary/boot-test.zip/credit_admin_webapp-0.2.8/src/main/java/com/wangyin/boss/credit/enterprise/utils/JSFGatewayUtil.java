package com.wangyin.boss.credit.enterprise.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.wangyin.admin.frame.utils.ConfigUtil;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

public class JSFGatewayUtil {

    private static Logger logger = LoggerFactory.getLogger(JSFGatewayUtil.class);

    private static final String JSF_OPEN_API_URL="com.jd.jsf.openapi.service.JSFOpenAPI/jsf-open-api/";
    private static String JSF_APP_KEY;
    private static String JSF_OPEN_API_ADDRESS;
    private static String JSF_OPEN_API_TOKEN;
    private static String JSF_OPEN_API_ERP;

    static {
        JSF_APP_KEY = ConfigUtil.getString("jsf.app.key");
        JSF_OPEN_API_ADDRESS = ConfigUtil.getString("jsf.open.api.address");
        JSF_OPEN_API_TOKEN = ConfigUtil.getString("jsf.open.api.token");
        JSF_OPEN_API_ERP = ConfigUtil.getString("jsf.open.api.erp");
    }

    private static String buildUrl(String methodName, String appId) {
        return JSF_OPEN_API_ADDRESS + JSF_OPEN_API_URL + methodName + "/" + appId + "/jsf";
    }

    public static List<String> aliasList(String interfaceName){
        String url = buildUrl("getAliasesByIfaceName", JSF_APP_KEY);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("ifaceName", interfaceName);
        jsonObject.put("appKey", JSF_APP_KEY);
        jsonObject.put("token", JSF_OPEN_API_TOKEN);
        jsonObject.put("erp", JSF_OPEN_API_ERP);
        jsonObject.put("isDepedByOther", "false");
        jsonObject.put("appId", JSF_APP_KEY);
        try {
            logger.info("jsf别名入参："+jsonObject.toJSONString());
            StringBuilder builder = invoke$jsfOpenApi(url, jsonObject);
            logger.info("jsf-open-api返回结果："+builder.toString());
            JSONObject jsonObject1 = JSONObject.parseObject(builder.toString());
            if (jsonObject1.getBooleanValue("success") && "200".equals(jsonObject1.getString("code"))) {
                JSONArray jsonArray = jsonObject1.getJSONArray("result");
                return jsonArray.toJavaList(String.class);
            }else{
                logger.error("调用接口错误信息："+jsonObject1.get("message"));
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    public static JSONArray methodList(String ifaceName,String alias){
        String url = buildUrl("getInterfaceDetailInfo", JSF_APP_KEY);
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("ifaceName", ifaceName);
        jsonObject.put("alias", alias);
        jsonObject.put("appKey", JSF_APP_KEY);
        jsonObject.put("token", JSF_OPEN_API_TOKEN);
        jsonObject.put("erp", JSF_OPEN_API_ERP);
        try {
            logger.info("jsf方法列表入参："+jsonObject.toJSONString());
            StringBuilder builder = invoke$jsfOpenApi(url, jsonObject);
            logger.info("jsf-open-api返回结果："+builder.toString());
            JSONObject jsonObject1 = JSONObject.parseObject(builder.toString());
            if (jsonObject1.getBooleanValue("success") && "200".equals(jsonObject1.getString("code"))) {
                JSONArray jsonArray = jsonObject1.getJSONArray("result");
                return jsonArray;
            }else{
                logger.error("调用接口错误信息："+jsonObject1.get("message"));
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
        return null;
    }


    private static StringBuilder invoke$jsfOpenApi(String url, JSONObject jsonObject) {
        try {
            HttpClient httpClient = new HttpClient();
            httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(5000);
            httpClient.getHttpConnectionManager().getParams().setSoTimeout(5000);
            PostMethod postMethod = new PostMethod(url);
            RequestEntity requestEntity = new StringRequestEntity(jsonObject.toString(),
                    "application/json;charset=UTF-8", "utf-8");
            postMethod.setRequestEntity(requestEntity);
            int status = httpClient.executeMethod(postMethod);
            if (status != 200) {
                logger.error("URL:" + url + "访问出错，http状态码：" + status);
            }
            InputStream is = postMethod.getResponseBodyAsStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            StringBuilder builder = new StringBuilder();
            String line = null;
            while ((line = br.readLine()) != null) {
                builder.append(line);
            }
            return builder;
        } catch (Exception e) {
            logger.error(e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}
