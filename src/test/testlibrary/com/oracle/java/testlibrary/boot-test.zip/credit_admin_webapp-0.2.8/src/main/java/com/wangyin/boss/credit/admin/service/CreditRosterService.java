package com.wangyin.boss.credit.admin.service;

import java.util.List;

import com.wangyin.boss.credit.admin.entity.CreditRoster;

/**
 * 
 * @author wyhaozhihong
 *
 */
public interface CreditRosterService {
	
	/**
	 * 根据条件查询商户IP名单管理 分页
	 * @param creditRoster
	 * @return
	 */
	List<CreditRoster> selectByParam(CreditRoster creditRoster);
	
	/**
	 * 根据条件查询商户IP名单管理总条数
	 * @param creditRoster
	 * @return
	 */
	int selectCountByParam(CreditRoster creditRoster);
	
	/**
	 * 根据商户ID查询域名
	 * @param merchantId
	 * @return
	 */
	String selectByMerchantId(CreditRoster creditRoster);
	
	/**
	 * 根据商户ID查询商户信息和IP域名
	 * @param merchantId
	 * @return
	 */
	List<CreditRoster> selectInfoByMerchantId(CreditRoster creditRoster);
	
	/**
	 * 根据 rosterId 逻辑删除ip记录
	 * @param rosterId
	 * @param rosterStatus
	 * @return
	 */
	int deleteDomain(CreditRoster creditRoster);

	int insert(CreditRoster creditRoster);

}
