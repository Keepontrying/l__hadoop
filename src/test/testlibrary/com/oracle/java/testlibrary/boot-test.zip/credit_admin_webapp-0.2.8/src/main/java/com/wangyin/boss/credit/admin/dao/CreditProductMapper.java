package com.wangyin.boss.credit.admin.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditProduct;

@SqlMapper
@Component
public interface CreditProductMapper {
	
	/**
	 * @author wyhaozhihong
	 * 查询状态open的所有产品
	 * @return
	 */
	List<CreditProduct> select(CreditProduct cp);

	/**
	 * @author wyhaozhihong
	 * 查询状态open的所有产品count
	 * @return
	 */
	int selectCount(CreditProduct cp);

	/**
	 * 查询还未添加到item的产品列表
	 * @return
	 */
	List<CreditProduct> selectAvailableCreditProductToItem();

	/**
	 * 根据参数查询产品List
	 * @param cp
	 * @return
	 */
	List<CreditProduct> queryEnterpriseProduct(CreditProduct cp);

}