package com.wangyin.boss.credit.enterprise.dao;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJob;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResultsQueryParam;
import com.wangyin.boss.credit.enterprise.beans.CrawlerWord;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 舆情监控爬虫任务
 *
 * @author huangzhiqiang
 * @data 2018/11/20
 */
@SqlMapper
@Component
public interface CrawlerJobMapper {

    Long insert(CrawlerJob job);

    Long insertWord(CrawlerWord word);

    boolean delete(Long id);

    void delWord(Long jobId);

    void update(CrawlerJob job);

    Integer queryCount(CrawlerJobResultsQueryParam param);

    CrawlerJob queryById(Long jobId);

    List<CrawlerWord> queryWord(@Param("jobId") Long jobId);

    List<CrawlerJob> query(CrawlerJobResultsQueryParam param);

}
