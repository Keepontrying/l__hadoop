package com.wangyin.boss.credit.enterprise.service;

import java.util.List;

import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.param.CreditDealFlowQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.CreditDealFlowInfo;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.QueryCountEntity;
import com.wangyin.operation.beans.UploadFile;

/** 
* @desciption : 交易流失service接口类
* @author : yangjinlin@jd.com
* @date ：2018年4月17日 下午7:59:06 
* @version 1.0 
* @return  */
public interface CreditDealFlowService {

	/**
	 * 查询交易流水信息  分页
	 * @param dealFlowQryPrm
	 * @return
	 */
	public CreditPage<CreditDealFlowInfo> queryDealFlowPage(CreditDealFlowQueryParam dealFlowQryPrm);

	/**
	 * 根据多条件筛选并某指定字段进行数据汇总List
	 * @param dealFlowQryPrm 多条件查询入参
	 * @param countField 某字段统计
	 * @return
	 */
	public CreditResponseData<List<QueryCountEntity>> countDealFlowByField(CreditDealFlowQueryParam dealFlowQryPrm,
			String countField);

	/**
	 * 多条件查询并导出交易流水
	 * @param queryParam
	 * @return
	 */
	UploadFile downDealFlowQueryResult(CreditDealFlowQueryParam queryParam);
}
