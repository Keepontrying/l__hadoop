package com.wangyin.boss.credit.enterprise.utils;
//package com.jd.jr.boss.credit.authen.core.beans.entity;
//
//import java.util.List;
//
//import org.apache.commons.collections.CollectionUtils;
//
//public class MyList<Object> implements Comparable<T>{
//
//	private List<T> list;
//	
//	private int size;
//	
//	@Override
//	public int compareTo(MyList<T> o) {
//		if(this.list.size() > o.getSize()) {
//			return 1;
//		}else if(this.list.size() < o.getSize()){
//			return -1;
//		}
//		return 0;
//	}
//	public List<T> getList() {
//		return list;
//	}
//
//	public void setList(List<T> list) {
//		this.list = list;
//	}
//	public int getSize() {
//		return CollectionUtils.isEmpty(list) ? 0 : list.size();
//	}
//	
//}
