package com.wangyin.boss.credit.admin.utils;

/**
 * 
 * @author wyhaozhihong
 *
 */
public class StringHelper {
	
	public static String upperCaseFirstChar(String fildName){
		if(!"".equalsIgnoreCase(fildName) && fildName != null){
			fildName = fildName.replaceFirst(fildName.substring(0,1), fildName.substring(0,1).toUpperCase());
		}
		return fildName;
	}
	
}
