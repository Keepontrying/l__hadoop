package com.wangyin.boss.credit.admin.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.httpclient.ConnectTimeoutException;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.PostMethod;

import com.wangyin.commons.util.Logger;

/**
 * 
 * @author wyhaozhihong
 *
 */
public class HttpUtil {
	
	private static final Logger LOGGER = new Logger();
	/**
	 * @author wyhaozhihong
	 * 连接超时时间
	 */
	private static int CONNECT_TIMEOUT = 5000;
	/**
	 * @author wyhaozhihong
	 * 读取超时时间
	 */
	private static int READ_TIMEOUT = 5000;
	
	/**
	 * @author wyhaozhihong
	 * @param url
	 * @param params
	 * @return
	 */
	public static String doPost(String url ,Map<String,?> params) {
		String result = null;
		HttpClient httpClient = new HttpClient();
		PostMethod postMethod = new PostMethod(url);
		//设置连接超时时间(单位毫秒)
		httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(HttpUtil.CONNECT_TIMEOUT);
		//设置读数据超时时间(单位毫秒)
		httpClient.getHttpConnectionManager().getParams().setSoTimeout(HttpUtil.READ_TIMEOUT);
		httpClient.getParams().setContentCharset("utf-8");
		Set<?> keySet = params.entrySet();
		for (Iterator<Entry<String,?>> iterator = (Iterator<Entry<String, ?>>) keySet.iterator(); iterator.hasNext();) {
			Entry<String,?> entry = iterator.next();
			if(null == entry.getValue()) {
				continue;
			}
			postMethod.addParameter(entry.getKey(),entry.getValue().toString());
		}
		BufferedReader br = null;
		InputStream is = null;
		try {
			int status = httpClient.executeMethod(postMethod);
			if(200 != status) {
				LOGGER.error("URL:"+url+"访问出错，http状态码："+status);
			}
			is = postMethod.getResponseBodyAsStream();
			br = new BufferedReader(new InputStreamReader(is));
			StringBuilder sb = new StringBuilder();   
			String line = null;
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}
			result = sb.toString();
		} catch (ConnectTimeoutException e) {
			LOGGER.error("URL:"+url+"连接超时，超时时间："+HttpUtil.CONNECT_TIMEOUT+"ms",e.fillInStackTrace());
		} catch (SocketTimeoutException e) {
			LOGGER.error("URL:"+url+"长时间没有返回数据，读取超时，超时时间："+HttpUtil.READ_TIMEOUT+"ms",e.fillInStackTrace());
		} catch (HttpException e) {
			LOGGER.error("",e.fillInStackTrace());
		} catch (IOException e) {
			LOGGER.error("",e.fillInStackTrace());
		} finally {
			if(null != postMethod) {
				postMethod.releaseConnection();
			}
			try {
				if(null != br) {
					br.close();
				}
				if(null != is) {
					is.close();
				}
			} catch (IOException e) {
				LOGGER.error("",e.fillInStackTrace());
			}
		}
		return result;
	}
	
	/**
	 * @author wyhaozhihong
	 * @param READ_TIMEOUT
	 */
	public static void setREAD_TIMEOUT(int READ_TIMEOUT) {
		HttpUtil.READ_TIMEOUT = READ_TIMEOUT;
	}
	
	/**
	 * @author wyhaozhihong
	 * @param CONNECT_TIMEOUT
	 */
	public static void setCONNECT_TIMEOUT(int CONNECT_TIMEOUT) {
		HttpUtil.CONNECT_TIMEOUT = CONNECT_TIMEOUT;
	}
	
}
