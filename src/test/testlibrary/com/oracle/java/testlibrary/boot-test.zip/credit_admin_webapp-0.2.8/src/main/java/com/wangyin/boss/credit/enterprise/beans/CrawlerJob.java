package com.wangyin.boss.credit.enterprise.beans;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 爬虫任务
 *
 * @author huangzhiqiang
 * @data 2018/11/19
 */
public class CrawlerJob implements Serializable {

    private Long id;
    /**
     * 任务名称
     */
    private String name;
    /**
     * 任务类别
     * 0 - 实时
     * 1 - 定时
     */
    private Byte category;
    /**
     * 目标网站
     */
    private String targetUrl;
    /**
     * 目标网站编码
     */
    private String targetUrlCode;
    /**
     * 任务总权重
     */
    private Integer weight;
    /**
     * 创建时间
     */
    private Date createdDate;
    /**
     * 敏感词
     */
    private List<CrawlerWord> words;
    /**
     * 是否删除
     * 0 - 正常
     * 1 - 删除
     */
    private Byte isDel;
    /**
     * 任务内容
     */
    private String jobContent;
    public static byte b = 0;
    public String getCategoryDesc() {
        if (category == null) {
            return "";
        }
        return category.equals(b) ? "实时" : "定时";
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Byte getCategory() {
        return category;
    }

    public void setCategory(Byte category) {
        this.category = category;
    }

    public String getTargetUrl() {
        return targetUrl;
    }

    public void setTargetUrl(String targetUrl) {
        this.targetUrl = targetUrl;
    }

    public String getTargetUrlCode() {
        return targetUrlCode;
    }

    public void setTargetUrlCode(String targetUrlCode) {
        this.targetUrlCode = targetUrlCode;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public List<CrawlerWord> getWords() {
        return words;
    }

    public void setWords(List<CrawlerWord> words) {
        this.words = words;
    }

    public Byte getIsDel() {
        return isDel;
    }

    public void setIsDel(Byte isDel) {
        this.isDel = isDel;
    }

    public String getJobContent() {
        return jobContent;
    }

    public void setJobContent(String jobContent) {
        this.jobContent = jobContent;
    }
}
