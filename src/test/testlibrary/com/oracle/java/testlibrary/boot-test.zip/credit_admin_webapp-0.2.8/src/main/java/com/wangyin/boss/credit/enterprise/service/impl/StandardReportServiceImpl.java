package com.wangyin.boss.credit.enterprise.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.facade.authen.api.CreditStandardReportFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchCreateReportParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchReportQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.creditReport.StandardReportBatchResponse;
import com.jd.jr.boss.credit.facade.authen.beans.response.creditReport.StandardReportResponse;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.enterprise.beans.ReportQueryParam;
import com.wangyin.boss.credit.enterprise.controller.CreditStandardReportController;
import com.wangyin.boss.credit.enterprise.service.StandardReportService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by zhanghui12 on 2018/6/7.
 */
@Service
public class StandardReportServiceImpl implements StandardReportService {
    private static final Logger logger = LoggerFactory.getLogger(StandardReportServiceImpl.class);

    @Autowired
    private CreditStandardReportFacade creditStandardReportFacade;

    @Override
    public StandardReportBatchResponse queryPage(ReportQueryParam req) {

        CreditRequestParam<BatchQueryParam> requestParam = new CreditRequestParam<BatchQueryParam>();
        BatchQueryParam param = new BatchQueryParam();
        BeanUtils.copyProperties(req, param);
        requestParam.setParam(param);
        param.setQueryType("STANDARD_CREDIT_REPORT");
        CreditResponseData<StandardReportBatchResponse> response = null;
        logger.info("查询标准报告批次列表请求参数：{}", JSONObject.toJSONString(requestParam));
        try {
            response = creditStandardReportFacade.batchQuery(requestParam);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
        logger.info("查询标准报告批次列表返回结果：{}",JSONObject.toJSONString(response));
        if (response != null && response.isSuccess()) {
            return response.getData();
        }
        return null;

    }

    @Override
    public StandardReportResponse queryReportPage(ReportQueryParam req) {
        CreditRequestParam<BatchReportQueryParam> requestParam = new CreditRequestParam<BatchReportQueryParam>();
        BatchReportQueryParam param = new BatchReportQueryParam();
        BeanUtils.copyProperties(req, param);
        requestParam.setParam(param);
        CreditResponseData<StandardReportResponse> response = null;
        logger.info("查询标准报告列表请求参数：{}", JSONObject.toJSONString(requestParam));
        try {
            response = creditStandardReportFacade.reportQuery(requestParam);
        } catch (Exception e) {
            logger.error(e.getMessage(),e);
        }
        logger.info("查询标准报告列表返回结果：{}",JSONObject.toJSONString(response));
        if (response != null && response.isSuccess()) {
            return response.getData();
        }
        return null;
    }

    @Override
    public boolean reCreateReport(String orderId) {
        CreditRequestParam<String> requestParam = new CreditRequestParam<String>();
        requestParam.setParam(orderId);
        CreditResponseData response = null;
        logger.info("生成报告请求参数：{}", JSONObject.toJSONString(requestParam));
        try {
            response = creditStandardReportFacade.createReport(requestParam);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        logger.info("生成报告返回结果：{}", JSONObject.toJSONString(response));
        if (response != null && response.isSuccess()) {
            return true;
        }
        return false;
    }

    @Override
    public boolean reCreateOrder(String id) {
        CreditRequestParam<String> requestParam = new CreditRequestParam<String>();
        requestParam.setParam(id);
        CreditResponseData response = null;
        logger.info("重新下单请求参数：{}", JSONObject.toJSONString(requestParam));
        try {
            response = creditStandardReportFacade.reCreateOrder(requestParam);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        logger.info("重新下单返回结果：{}", JSONObject.toJSONString(response));
        if (response != null && response.isSuccess()) {
            return true;
        }
        return false;
    }

    @Override
    public boolean updateAuthFile(String authFileName, String fid, String batchNo) {
        CreditRequestParam<BatchCreateReportParam> requestParam=new CreditRequestParam<BatchCreateReportParam>();
        BatchCreateReportParam param =new BatchCreateReportParam();
        param.setBatchNo(batchNo);
        param.setAuthFileId(fid);
        param.setAuthFileName(authFileName);
        requestParam.setParam(param);
        CreditResponseData response = null;
        logger.info("上传授权文件：{}", JSONObject.toJSONString(requestParam));
        try {
            response = creditStandardReportFacade.updateAuthFile(requestParam);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        logger.info("上传授权文件返回结果：{}", JSONObject.toJSONString(response));
        if (response != null && response.isSuccess()) {
            return true;
        }
        return false;
    }

}
