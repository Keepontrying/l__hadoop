package com.wangyin.boss.credit.admin.service;

import com.jd.jr.boss.credit.domain.common.entity.CreditPaymentOffline;
import com.jd.jr.boss.credit.domain.common.entity.CreditPostBillMonth;
import com.jd.jr.boss.credit.facade.authen.beans.param.PaymentOfflineQueryParam;
import com.wangyin.operation.common.beans.Page;

import java.util.List;

/**
 * Created by anmeng on 2017/9/14.
 */
public interface PaymentOfflineService {
    /**
     * 查询线下付款单
     * @param queryParam
     * @return
     */
    public Page<CreditPaymentOffline> query(PaymentOfflineQueryParam queryParam);

    /**
     * 创建线下收款单
     * @param paymentOffline
     */
    public void createPaymentOffline(CreditPaymentOffline paymentOffline);
}
