package com.wangyin.boss.credit.admin.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategyAllow;
import com.wangyin.boss.credit.admin.entity.StockMerchProStrategyAllow;

@SqlMapper
@Component
public interface CreditProductStrategyMapper {
	
	/**创建计费策略
	 * @desc 新增
	 * @since Mon Jun 27 17:58:12 CST 2016
	 * @param record 服务产品计费策略实体
	 * @return
	 */
    int insert(CreditProductStrategy record);
    
    /**
     * 根据查询条件查询计费策略数据 分页
     * @param creditProductStrategy 服务产品计费策略实体
     * @return
     */
	List<CreditProductStrategy> selectByParam(CreditProductStrategy creditProductStrategy);
	
	/**
	 * 根据查询条件 查询计费策略总条数
	 * @param creditProductStrategy 服务产品计费策略实体
	 * @return
	 */
	int selectCountByParam(CreditProductStrategy creditProductStrategy);
	
	/**
	 * 根据主键修改数据
	 * @param creditProductStrategy 服务产品计费策略实体
	 * @return
	 */
	int updateByStrategyId(CreditProductStrategy creditProductStrategy);
	
	/**
	 * 批量更新
	 * @author wyhaozhihong
	 * @param creditProductStrategy 服务产品计费策略实体
	 */
	int updateBatchByPrimaryKeySelective(CreditProductStrategy creditProductStrategy);
	
	/**
	 * 
	 * @author wyhaozhihong
	 * @param strategyId 服务产品计费策略id串
	 * @return
	 */
	List<CreditProductStrategy> selectBatchByPrimaryKey(List<String> strategyIds);
	
	/**
	 * 根据条件 查询商户主体的计费信息 分页
	 * @param creditProductStrategy 服务产品计费策略实体
	 * @return
	 */
	List<CreditProductStrategyAllow> selectMerchantStrategyByParam(CreditProductStrategyAllow creditProductStrategy);
	
	/**
	 * 根据条件 查询商户主体的计费信息的总条数
	 * @param creditProductStrategy 服务产品计费策略实体
	 * @return
	 */
	int selectMerchantStrategyCountByParam(CreditProductStrategy creditProductStrategy);
	
	int updateByPrimaryKeySelective(CreditProductStrategy record);
    
	int deleteByPrimaryKey(Integer strategyId);
	
	CreditProductStrategy selectByPrimaryKey(Integer strategyId);
	
	/**
	 * 根据合同ID查询计费策略ID
	 * @param contractId 合同 id
	 * @return
	 */
	List<Integer> selectByContractId(CreditProductStrategy creditProductStrategy);
	
	/**
	 * 根据条件更新计费的状态
	 * @param creditProductStrategy 服务产品计费策略实体
	 * @return
	 */
	int updateStatusForClose(CreditProductStrategy creditProductStrategy);

	/**
	 * 关联商户账务表查询商户余量   分页
	 * @param creditProductStrategy 服务产品计费策略实体
	 * @return
	 */
	List<CreditProductStrategyAllow> selectMercAllowanceByParam(CreditProductStrategyAllow creditProductStrategy);

	/**
	 * 关联商户账务表查询商户余量   分页信息
	 * @param creditProductStrategy 服务产品计费策略实体
	 * @return
	 */
	int selectMercAllowanceCountByParam(CreditProductStrategy creditProductStrategy);

	/**
	 * 根据商户号查询代缴费合同下的计费策略信息 分页
	 * @param stockMerchProStrategyAllow 存量商户余量信息实体类
	 * @return
	 */
	List<StockMerchProStrategyAllow> selectStockMerchAllowByParam(StockMerchProStrategyAllow stockMerchProStrategyAllow);

	/**
	 * 根据商户号查询代缴费合同下的计费策略信息总记录条数 分页
	 * @param stockMerchProStrategyAllow 存量商户余量信息实体类
	 * @return
	 */
	int selectStockMerchAllowCountByParam(StockMerchProStrategyAllow stockMerchProStrategyAllow);

	/**
	 * 根据商户号查询计费策略list
	 * @param cps
	 * @return
	 */
	List<CreditProductStrategy> selectByMerchantNo(CreditProductStrategy cps);

	/**
	 * 根据参数查询计费list
	 * @param productStrategy
	 * @return
	 */
	List<CreditProductStrategy> selectStrategyListByParam(CreditProductStrategy productStrategy);
	/**
	 * 根据参数查询计费list 并根据productId\merchantId去重复
	 * @param productStrategy
	 * @return
	 */
	List<CreditProductStrategy> selectDisStrategyListByParam(CreditProductStrategy productStrategy);
	/**
	 * 根据productId\merchantId查询计费list
	 * @param productStrategy
	 * @return
	 */
	List<CreditProductStrategy> selectStrategyListByProMerId(CreditProductStrategy productStrategy);


}