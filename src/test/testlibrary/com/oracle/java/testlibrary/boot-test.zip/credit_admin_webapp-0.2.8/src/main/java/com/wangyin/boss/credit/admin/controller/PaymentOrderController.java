package com.wangyin.boss.credit.admin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.jr.boss.credit.domain.common.enums.ContractStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditPaymentChannelEnum;
import com.jd.jr.boss.credit.facade.site.api.dto.request.payment.PaymentReceiptPushRequest;
import com.wangyin.boss.credit.admin.entity.PaymentOrder;
import com.wangyin.boss.credit.admin.enums.ChargeTypeEnum;
import com.wangyin.boss.credit.admin.service.PaymentOrderService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.beans.ResponseData;

/** 
* @desciption : 缴费单功能
* @author : yangjinlin@jd.com
* @date ：2017年1月3日 下午2:42:32 
* @version 1.0 
* @return  */
@Controller
@RequestMapping("/paymentOrder")
public class PaymentOrderController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentOrderController.class);
	
	@Autowired
	PaymentOrderService paymentOrderService;
	
	/**
	 * 根据商户号查询出商户计费信息---分页
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryPaymentOrder.do")
	public Map<String, Object> doQueryStockMerchAllow(@RequestParam Map<String, String> map, 
			PaymentOrder paymentOrder){
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "查询成功");
		
		List<PaymentOrder> paymentOrderList = new ArrayList<PaymentOrder>();
		int paymentOrderCount = 0;
		
		try {
			paymentOrder.setContractStatus(ContractStatusEnum.VALID.toName());
			if(ChargeTypeEnum.PACKAGE.toName().equalsIgnoreCase(paymentOrder.getChargeType())){
				paymentOrderList = paymentOrderService.selectPackageByParam(paymentOrder);
				paymentOrderCount = paymentOrderService.selectPackageCountByParam(paymentOrder);
				
			}else if(ChargeTypeEnum.SINGLE.toName().equalsIgnoreCase(paymentOrder.getChargeType())){
				paymentOrderList = paymentOrderService.selectSingleByParam(paymentOrder);
				paymentOrderCount = paymentOrderService.selectSingleCountByParam(paymentOrder);
			}else{
				resultMap.put("success", false);
				resultMap.put("message", "计费方式不可为空");
			}
			
			
			resultMap.put("rows", paymentOrderList);
			resultMap.put("total", paymentOrderCount);
			
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "查询异常");
		}
		
		return resultMap;
	}
	
	/**
	 * 更改银行渠道策略状态操作
	 * @author yangjinlin@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doSubPaymentOrder.do")
	public Map<String, Object> doSubPaymentOrder(@RequestParam Map<String, Object> map, PaymentReceiptPushRequest paymentReceiptPushRequest, String user) {
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "推送缴费单成功");
		
		if(StringUtils.isBlank(map.get("paymentChannelStr").toString())){
			resultMap.put("success", false);
			resultMap.put("message", "计费方式不可为空！");
			return resultMap;
		}
		
		try {
			paymentReceiptPushRequest.setPaymentChannel(CreditPaymentChannelEnum.enumValueOf(map.get("paymentChannelStr").toString()));
			ResponseData  respData = paymentOrderService.pushPaymentOrder(paymentReceiptPushRequest);
			if(!respData.isSuccess()){//推送缴费单失败
				resultMap.put("success", false);
				resultMap.put("message", "推送缴费单失败!");
			}
			
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "操作异常");
		}
		return resultMap;
		
	}
	

}
