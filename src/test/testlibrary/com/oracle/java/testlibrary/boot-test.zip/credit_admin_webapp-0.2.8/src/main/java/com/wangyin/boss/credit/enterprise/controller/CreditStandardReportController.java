package com.wangyin.boss.credit.enterprise.controller;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.jd.jr.boss.credit.domain.common.entity.StandardReportBatch;
import com.jd.jr.boss.credit.facade.authen.beans.response.creditReport.StandardReportBatchResponse;
import com.jd.jr.boss.credit.facade.authen.beans.response.creditReport.StandardReportResponse;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditStandardReport;
import com.wangyin.boss.credit.admin.enums.CreditHspFidTypeEnum;
import com.wangyin.boss.credit.admin.enums.GladReportStatusEnum;
import com.wangyin.boss.credit.admin.utils.ExcelUtil;
import com.wangyin.boss.credit.enterprise.beans.CallCaseInfo;
import com.wangyin.boss.credit.enterprise.beans.CallCaseInfoQueryParam;
import com.wangyin.boss.credit.enterprise.beans.ReportQueryParam;
import com.wangyin.boss.credit.enterprise.beans.StandardReportBatchExport;
import com.wangyin.boss.credit.enterprise.constants.HspConstant;
import com.wangyin.boss.credit.enterprise.service.StandardReportService;
import com.wangyin.boss.credit.enterprise.utils.HspUtil;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.beans.UploadFile;
import com.wangyin.operation.beans.UploadObject;
import com.wangyin.operation.enums.FileTypeEnum;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by zhanghui12 on 2018/6/7.
 * 标准信用报告
 */
@Controller
@RequestMapping("/standardReport")
public class CreditStandardReportController {
    private static final Logger logger = LoggerFactory.getLogger(CreditStandardReportController.class);
    @Autowired
    private StandardReportService standardReportService;
    @RequestMapping("/toPageView.view")
    @ResponseBody
    public Map<String, String> toPageView(@RequestParam Map<String, String> params) {
        return params;
    }
    @ResponseBody
    @RequestMapping("/doReportBatchQuery.do")
    public Map<String, Object> doReportBatchQuery(ReportQueryParam param) {
        logger.info("分页查询标准报告批次,请求参数{}", JSONObject.toJSONString(param));
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            StandardReportBatchResponse page = standardReportService.queryPage(param);
            if (page != null) {
                List<StandardReportBatch> list = page.getList();
                convertResult(list);
                resultMap.put("rows", list);
                resultMap.put("total", page.getTotalCount());
                resultMap.put("success", true);
            } else {
                resultMap.put("success", false);
                resultMap.put("message", "查无数据");
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            resultMap.put("success", false);
        }
        logger.info("分页查询标准报告批次返回结果：{}", JSONObject.toJSONString(resultMap));
        return resultMap;
    }

    @ResponseBody
    @RequestMapping("/doReportQuery.do")
    public Map<String, Object> doReportQuery(ReportQueryParam param) {
        logger.info("分页查询标准报告,请求参数{}", JSONObject.toJSONString(param));
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            StandardReportResponse page = standardReportService.queryReportPage(param);
            if (page != null) {
                List<CreditStandardReport> list = page.getList();
                convertReportResult(list);
                resultMap.put("rows", list);
                resultMap.put("total", page.getTotalCount());
                resultMap.put("success", true);
            } else {
                resultMap.put("success", false);
                resultMap.put("message", "查无数据");
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            resultMap.put("success", false);
        }
        logger.info("分页查询标准报告返回结果：{}", JSONObject.toJSONString(resultMap));
        return resultMap;
    }

    /**
     * 重新生成报告
     *
     * @param orderId
     * @return
     */
    @ResponseBody
    @RequestMapping("/doReCreateReport.do")
    public Map<String, Object> doReCreateReport(String orderId) {
        logger.info("重新生成报告,orderId:", orderId);
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            boolean result = standardReportService.reCreateReport(orderId);
            if (result) {
                resultMap.put("success", true);
            } else {
                resultMap.put("success", false);
                resultMap.put("message", "重新生成报告失败");
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            resultMap.put("success", false);
        }
        logger.info("重新生成报告返回结果：{}", JSONObject.toJSONString(resultMap));
        return resultMap;
    }

    /**
     * 重新发起请求格兰德下单接口
     *
     * @param id
     * @return
     */
    @ResponseBody
    @RequestMapping("/doReCreateOrder.do")
    public Map<String, Object> doReCreateOrder(String id) {
        logger.info("重新发起请求格兰德下单,id:", id);
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            boolean result = standardReportService.reCreateOrder(id);
            if (result) {
                resultMap.put("success", true);
            } else {
                resultMap.put("success", false);
                resultMap.put("message", "重新发起请求格兰德下单接口失败");
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            resultMap.put("success", false);
        }
        logger.info("重新发起请求格兰德下单接口返回结果：{}", JSONObject.toJSONString(resultMap));
        return resultMap;
    }


    /**
     * 上传授权文件
     *
     * @param map
     * @return
     * @author zhanghui
     */
    @RequestMapping("/doUploadFile.do")
    @ResponseBody
    public UploadObject doUploadAuthFile(@RequestParam Map<String, Object> map) {

        String uploadObjectStr = String.valueOf(map.get("uploadObject"));
        Gson gson = new Gson();//json处理工具随意用什么fastjson、jsonlib、jackson。。。。等

        UploadObject uploadObject = gson.fromJson(uploadObjectStr, UploadObject.class);
        uploadObject.setVersion("2.0");
        String batchNo = uploadObject.getParams().get("batchNo");

        List<UploadFile> list = uploadObject.getFileList();

        for (UploadFile uploadFile : list) {
            uploadObject.getParams().put("authFileName", uploadFile.getOriginalName());
            uploadFile.setPath(getAuthPdfFilePath());//设置上传到NFS的相对路径
            uploadFile.setName(batchNo + uploadFile.getFieldName());//设置上传到NFS的名称（不含后缀），具体可以看UploadObject的注释
            uploadFile.setTemp(false);
        }
        return uploadObject;
    }

    public String getAuthPdfFilePath() {
        return "/pdf/authFile" + new SimpleDateFormat("yyyy/MM/dd").format(new Date())
                + "/";
    }

    /**
     * 上传授权文件回调方法
     *
     * @param map
     * @return
     * @author zhanghui
     */
    @RequestMapping("/doUploadFileCallback.do")
    @ResponseBody //将UploadObject对象转换成json
    public Map<String, Object> doUploadAuthFileCallback(@RequestParam Map<String, Object> map) {
        Map<String, Object> result = new HashMap<String, Object>();
        String uploadObjectStr = String.valueOf(map.get("uploadObject"));//拿到上传对象
        Gson gson = new Gson();//json处理工具随意
        UploadObject uploadObject = gson.fromJson(uploadObjectStr, UploadObject.class);//json->object
        List<UploadFile> list = uploadObject.getFileList();//得到上传文件列表
        Map<String, String> param = uploadObject.getParams();
        String authFileName = param.get("authFileName");
        String fid = "";
        if (list != null && list.size() > 0) {
            logger.info(list.get(0).getPath());
            fid = HspUtil.toHsp(new File(list.get(0).getRealPathname()), CreditHspFidTypeEnum.AUTH_FILE, authFileName.substring(authFileName.indexOf('.')), param.get("batchNo"), HspConstant.HSP_PORTAL_STANDARD_REPORT_PATH);
        }
        boolean flag = false;
        if (StringUtils.isNotEmpty(fid)) {
            flag = standardReportService.updateAuthFile(authFileName, fid, param.get("batchNo"));
        }
        if (StringUtils.isNotEmpty(fid) && flag) {
            logger.debug("文件上传成功");
            result.put("success", true);// 前台可能会做个处理，上传成功跳转等等。demo中页面只是使用了message中的信息
            result.put("message", "文件上传成功");
        } else {
            result.put("success", false);
            result.put("message", "文件上传失败");
        }
        return result;
    }

    @ResponseBody
    @RequestMapping("/batchExport.download")
    public UploadFile dobatchExport(ReportQueryParam param) {
        logger.info("导出批量查询:" + JSONObject.toJSONString(param));
        logger.info("start:" + System.currentTimeMillis());
        String workSheetName = "批次查询";

        String[] titles = {"商户号", "商户名称", "批次号", "总数量", "成功数量", "类型", "状态", "下单日期", "交付日期", "期望交付日期", "授权书"};
        String[] properties = {"merchantNo", "merchantName", "batchNo", "batchCount", "successCount", "timeInterval",
                "status", "createdDate", "packageTime", "expectedPackageTime", "authFileName"};

        StandardReportBatchResponse page = standardReportService.queryPage(param);
        List<StandardReportBatchExport> list = convertBatchExport(page.getList());
        UploadFile uploadfile = export(titles, properties, list, workSheetName);
        logger.info("导出批量查询 end:" + System.currentTimeMillis());
        return uploadfile;
    }


    @ResponseBody
    @RequestMapping("/reportExport.download")
    public UploadFile reportExport(ReportQueryParam param) {
        logger.info("导出查询结果:" + JSONObject.toJSONString(param));
        logger.info("start:" + System.currentTimeMillis());
        String workSheetName = "报告查询";

        String[] titles = {"商户号", "商户名称", "批次号", "目标企业", "类型", "状态", "下单日期", "交付日期", "期望交付日期"};
        String[] properties = {"merchantNo", "merchantName", "batchNo", "companyName",  "timeInterval",
                "status", "createdDate", "packageTime", "expectedPackageTime"};

        StandardReportResponse page = standardReportService.queryReportPage(param);
        List<StandardReportBatchExport> list = convertReportExport(page.getList());
        UploadFile uploadfile = export(titles, properties, list, workSheetName);
        logger.info("导出查询结果 end:" + System.currentTimeMillis());
        return uploadfile;
    }

    private List<StandardReportBatchExport> convertReportExport(List<CreditStandardReport> list) {
        List<StandardReportBatchExport> result = new ArrayList<StandardReportBatchExport>();
        if (!CollectionUtils.isEmpty(list)) {
            for (CreditStandardReport batch : list) {
                StandardReportBatchExport batchNew = new StandardReportBatchExport();
                batchNew.setMerchantNo(batch.getMerchantNo());
                batchNew.setBatchNo(batch.getBatchNo());
                batchNew.setMerchantName(batch.getMerchantName());
                batchNew.setCompanyName(batch.getCompanyName());
                if(batch.getTimeInterval()!=null){
                    batchNew.setTimeInterval(batch.getTimeInterval().intValue()==3?"加急件-T+3":"普通件-T+5");
                }
                if(batch.getReqTime()!=null){
                    batchNew.setCreatedDate(DateFormatUtils.format(batch.getReqTime(),"yyyy-MM-dd HH:mm:ss"));
                }
                if(batch.getExpectedResTime()!=null){
                    batchNew.setExpectedPackageTime(DateFormatUtils.format(batch.getExpectedResTime(),"yyyy-MM-dd HH:mm:ss"));
                }
                if(batch.getResTime()!=null){
                    batchNew.setPackageTime(DateFormatUtils.format(batch.getResTime(),"yyyy-MM-dd HH:mm:ss"));
                }
                batchNew.setStatus(batch.getStatus().getDescription());
                if (batch.getResTime() != null && batch.getExpectedResTime() != null && batch.getExpectedResTime().before(batch.getResTime())) {
                    batchNew.setStatus(GladReportStatusEnum.TIMEOUT.getDescription());
                }
                if (batch.getResTime() == null && batch.getExpectedResTime() != null && batch.getExpectedResTime().before(new Date())) {
                    batchNew.setStatus(GladReportStatusEnum.TIMEOUT.getDescription());
                }
                result.add(batchNew);
            }
        }
        return result;
    }

    private List<StandardReportBatchExport> convertBatchExport(List<StandardReportBatch> list) {
        List<StandardReportBatchExport> result = new ArrayList<StandardReportBatchExport>();
        if (!CollectionUtils.isEmpty(list)) {
            for (StandardReportBatch batch : list) {
                StandardReportBatchExport batchNew = new StandardReportBatchExport();
                batchNew.setMerchantNo(batch.getMerchantNo());
                batchNew.setAuthFileName(batch.getAuthFileName());
                batchNew.setBatchCount(batch.getBatchCount());
                batchNew.setBatchNo(batch.getBatchNo());
                batchNew.setMerchantName(batch.getMerchantName());
                batchNew.setSuccessCount(batch.getSuccessCount());
                if(batch.getTimeInterval()!=null){
                    batchNew.setTimeInterval(batch.getTimeInterval().intValue()==3?"加急件-T+3":"普通件-T+5");
                }
                if(batch.getCreatedDate()!=null){
                    batchNew.setCreatedDate(DateFormatUtils.format(batch.getCreatedDate(),"yyyy-MM-dd HH:mm:ss"));
                }
                if(batch.getExpectedPackageTime()!=null){
                    batchNew.setExpectedPackageTime(DateFormatUtils.format(batch.getExpectedPackageTime(),"yyyy-MM-dd HH:mm:ss"));
                }
                if(batch.getPackageTime()!=null){
                    batchNew.setPackageTime(DateFormatUtils.format(batch.getPackageTime(),"yyyy-MM-dd HH:mm:ss"));
                }
                if("PROCESSING".equalsIgnoreCase(batch.getStatus())){
                    batchNew.setStatus("进行中");
                }else if("FINISHED".equalsIgnoreCase(batch.getStatus())){
                    batchNew.setStatus("已完成");
                }
                if (batch.getPackageTime() != null && batch.getExpectedPackageTime() != null && batch.getExpectedPackageTime().before(batch.getPackageTime())) {
                    batchNew.setStatus("超时");
                }
                if (batch.getPackageTime() == null && batch.getExpectedPackageTime() != null && batch.getExpectedPackageTime().before(new Date())) {//还未返回报告，当前时间已超过期望打包时间
                    batchNew.setStatus("超时");
                }
                result.add(batchNew);
            }
        }
        return result;
    }




    /*
     * 导出公用方法
     */
    private UploadFile export(String[] titles, String[] properties, List<StandardReportBatchExport> list,
                              String workSheetName) {
        String basePath = ConfigUtil.getString("app.credit.downloadpath");
        String date = (new SimpleDateFormat("yyyyMMdd")).format(new Date());
        String pathName = "/standardReport/" + date + "/" + workSheetName + ".xlsx";
        String dir = basePath + pathName;
        logger.info("basePath=" + basePath + ",dir=" + dir);

        OutputStream outputStream = null;
        ExcelUtil excelUtil = new ExcelUtil();
        try {
            File file = new File(dir);
            if (!file.getParentFile().exists()) {
                if (!file.getParentFile().mkdirs()) {
                }
            }
            if (!file.exists()) {
                file.createNewFile();
            }
            outputStream = new FileOutputStream(file);
            // 创建工作薄
            SXSSFWorkbook wb = new SXSSFWorkbook(500);
            // 声明工作表
            Sheet sheet = null;
            // sheet = excelUtil.export(wb, workSheetName, titles, sheet);
            sheet = excelUtil.export(wb, outputStream, workSheetName, titles, properties, list, "",
                    StandardReportBatchExport.class, sheet, 0);
            wb.write(outputStream);
            wb.dispose();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            try {
                outputStream.flush();
                outputStream.close();
            } catch (IOException e) {
                logger.error(e.getMessage(), e);
            }
        }
        UploadFile uploadfile = new UploadFile();
        uploadfile.setPathname("/accessDetail" + pathName);
        uploadfile.setOriginalName(workSheetName + ".xlsx");
        uploadfile.setVersion("2.0");
        uploadfile.setTemp(true);
        return uploadfile;
    }

    private void convertReportResult(List<CreditStandardReport> list) {
        for (CreditStandardReport report : list) {
            if (null != report.getStatus()) {
                report.setStatusStr(report.getStatus().getDescription());
            }
            if (StringUtil.isNotEmpty(report.getResultFileId())) {
                report.setResultFileId(HspUtil.getUrl(report.getResultFileId(), 30, report.getResultFileName()));
            }
            if (report.getResTime() != null && report.getExpectedResTime() != null && report.getExpectedResTime().before(report.getResTime())) {
                report.setStatus(GladReportStatusEnum.TIMEOUT);
            }
            if (report.getResTime() == null && report.getExpectedResTime() != null && report.getExpectedResTime().before(new Date())) {
                report.setStatus(GladReportStatusEnum.TIMEOUT);
            }
        }
    }

    private void convertResult(List<StandardReportBatch> list) {
        for (StandardReportBatch batch : list) {
            if (StringUtil.isNotEmpty(batch.getSourceFile())) {
                batch.setSourceFile(HspUtil.getUrl(batch.getSourceFile(), 30, batch.getFileName()));
            }
            if (StringUtil.isNotEmpty(batch.getResultFile())) {
                batch.setResultFile(HspUtil.getUrl(batch.getResultFile(), 30, "result_" + batch.getBatchNo() + ".zip"));
            }
            if (StringUtil.isNotEmpty(batch.getAuthFileId())) {
                batch.setAuthFileId(HspUtil.getUrl(batch.getAuthFileId(), 30, batch.getAuthFileName()));
            }
            if (batch.getPackageTime() != null && batch.getExpectedPackageTime() != null && batch.getExpectedPackageTime().before(batch.getPackageTime())) {
                batch.setStatus("TIMEOUT");
            }
            if (batch.getPackageTime() == null && batch.getExpectedPackageTime() != null && batch.getExpectedPackageTime().before(new Date())) {
                batch.setStatus("TIMEOUT");
            }
        }
    }


}
