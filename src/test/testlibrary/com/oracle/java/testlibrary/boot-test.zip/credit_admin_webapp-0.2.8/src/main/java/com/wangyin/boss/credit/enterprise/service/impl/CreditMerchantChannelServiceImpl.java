package com.wangyin.boss.credit.enterprise.service.impl;

import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.domain.common.entity.CreditCallTimesGather;
import com.jd.jr.boss.credit.domain.common.entity.CreditMerchantChannelGather;
import com.jd.jr.boss.credit.facade.authen.api.CreditLogFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.MerchantChannelQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.elasticsearch.api.CreditLogSearchFacade;
import com.wangyin.boss.credit.admin.entity.CreditChnProdIns;
import com.wangyin.boss.credit.enterprise.beans.CreditChannelProdInsQueryParam;
import com.wangyin.boss.credit.enterprise.dao.CreditChnMerchantInsRelMapper;
import com.wangyin.boss.credit.enterprise.dao.CreditChnProdInsMapper;
import com.wangyin.boss.credit.enterprise.dao.CreditChnProdMapper;
import com.wangyin.boss.credit.enterprise.dao.CreditChnSysProdInsMapper;
import com.wangyin.boss.credit.enterprise.entity.CreditChannelProdIns;
import com.wangyin.boss.credit.enterprise.entity.CreditChnMerchantInsRel;
import com.wangyin.boss.credit.enterprise.entity.CreditChnProd;
import com.wangyin.boss.credit.enterprise.entity.CreditChnSysProdIns;
import com.wangyin.boss.credit.enterprise.service.CreditMerchantChannelService;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.GsonUtil;
import com.wangyin.rediscluster.client.R2mClusterClient;
import org.apache.commons.lang3.ArrayUtils;
import org.codehaus.jackson.JsonParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.lang.reflect.Array;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Description: 商户渠道 service接口实现类
 * User: yangjinlin@jd.com
 * Date: 2018/5/15 21:38
 * Version: 1.0
 */
@Service
public class CreditMerchantChannelServiceImpl implements CreditMerchantChannelService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreditMerchantChannelServiceImpl.class);

    @Resource
    CreditLogFacade creditLogFacade;

    @Resource
    CreditChnProdInsMapper chnProdInsMapper;

    @Resource
    CreditChnProdMapper creditChnProdMapper;

    @Resource
    CreditChnMerchantInsRelMapper creditChnMerchantInsRelMapper;

    @Resource
    CreditChnSysProdInsMapper creditChnSysProdInsMapper;

    @Override
    public int queryMerchantChannelGatherListCount(MerchantChannelQueryParam queryParam) {
        return creditLogFacade.queryMerchantChannelGatherListCount(queryParam);
    }

    @Override
    public List<CreditMerchantChannelGather> queryMerchantChannelGatherList(MerchantChannelQueryParam queryParam) {
        List<CreditMerchantChannelGather> merchantChannelGatherList = new ArrayList<CreditMerchantChannelGather>();
        try {
            CreditResponseData<List<CreditMerchantChannelGather>> responseData = creditLogFacade.queryMerchantChannelGatherList(queryParam);
            if(null != responseData && responseData.isSuccess()){
                merchantChannelGatherList = responseData.getData();
            }else{
                LOGGER.info("creditDealFlowFacade.queryMerchantChannelGatherList failed, {}", GsonUtil.getInstance().toJson(responseData) );
            }
        } catch (Exception e) {
            LOGGER.info("queryMerchantChannelGatherList failed, {}", e );
        }
        return merchantChannelGatherList;
    }

    @Override
    public int selectCountMerchantChannelGatherByParam(MerchantChannelQueryParam queryParam) {
        return creditLogFacade.selectCountMerchantChannelGatherByParam(queryParam);
    }

    @Override
    public int queryChannelProdInsListCount(CreditChannelProdInsQueryParam queryParam) {
        return chnProdInsMapper.queryChannelProdInsListCount(queryParam);
    }

    @Override
    public List<CreditChnProdIns> queryChannelProdInsList(CreditChannelProdInsQueryParam queryParam) {
        return chnProdInsMapper.queryChannelProdInsList(queryParam);
    }

    @Override
    public List<CreditChnProd> queryAllChannelProdList(CreditChnProd queryParam) {
        return creditChnProdMapper.queryAllChannelProdList(queryParam);
    }

    @Override
    public Set<CreditChannelProdIns> queryChannelsBy(CreditChnMerchantInsRel creditChnMerchantInsRel) {
        List<CreditChnMerchantInsRel>  creditChnMerchantInsRels = creditChnMerchantInsRelMapper.queryCreditChnMerhcnatInsRel(creditChnMerchantInsRel);
        Set<CreditChannelProdIns> creditChannelProdIns = new TreeSet<>();
        for (CreditChnMerchantInsRel merchantInsRel : creditChnMerchantInsRels) {
            String[] inscods = merchantInsRel.getInsCode().split(",");
            List<CreditChnProdIns> creditChnProdIns = chnProdInsMapper.queryChannelProdIns(Arrays.asList(inscods));
            for (CreditChnProdIns chnProdIns : creditChnProdIns) {
                CreditChannelProdIns ins = new CreditChannelProdIns();
                ins.setMerchantNo(merchantInsRel.getMerchantNo());
                ins.setUserPin(merchantInsRel.getUserId());
                ins.setInsCode(chnProdIns.getInsCode());
                ins.setInsName(chnProdIns.getInsName());
                creditChannelProdIns.add(ins);
            }
        }

        return creditChannelProdIns;
    }

    @Override
    public int saveOrUpdate(CreditChannelProdInsQueryParam queryParam, String userName) {
        String productCode = queryParam.getProductCode();
        if (StringUtils.isEmpty(productCode)) {
            throw new IllegalArgumentException("产品CODE参数异常");
        }
        CreditChnProd prod_param = new CreditChnProd();
        prod_param.setProductCode(productCode);

        List<CreditChnProd> prods = creditChnProdMapper.queryAllChannelProdList(prod_param);
        if (CollectionUtils.isEmpty(prods)) {
            throw new IllegalArgumentException(ResponseMessage.PARAM_ILLEGAL.getMessage());
        }

        int insId = 0;
        if (StringUtils.isEmpty(queryParam.getInsId())) {
            CreditChnProdIns chnProdIns = new CreditChnProdIns();
            chnProdIns.setProductCode(productCode);
            chnProdIns.setInsCode(queryParam.getInsCode());
            chnProdIns.setInsName(queryParam.getInsName());
            chnProdIns.setInsStatus(queryParam.getInsStatus());
            chnProdIns.setWeight(queryParam.getWeight());
            chnProdIns.setCreator(userName);
            chnProdIns.setModifier(userName);
            chnProdIns.setCreatedDate(new Date());
            chnProdIns.setModifiedDate(new Date());

            insId = chnProdInsMapper.insertSelective(chnProdIns);

            //插入channel sys_prod_ins;
            CreditChnSysProdIns sysProdIns = new CreditChnSysProdIns();
            sysProdIns.setCreatedDate(new Date());
            sysProdIns.setModifiedDate(new Date());
            sysProdIns.setInsId(chnProdIns.getInsId());
            sysProdIns.setCreator(userName);
            sysProdIns.setModifier(userName);
            sysProdIns.setSystemCode("ENTCAE");
            sysProdIns.setSysInsStatus(queryParam.getInsStatus());
            creditChnSysProdInsMapper.insertSelective(sysProdIns);
        }else{
            CreditChnProdIns chnProdIns = new CreditChnProdIns();
            chnProdIns.setInsId(queryParam.getInsId());
            chnProdIns.setProductCode(productCode);
            chnProdIns.setInsCode(queryParam.getInsCode());
            chnProdIns.setInsName(queryParam.getInsName());
            chnProdIns.setInsStatus(queryParam.getInsStatus());
            if (!StringUtils.isEmpty(queryParam.getWeight())) {
                chnProdIns.setWeight(queryParam.getWeight());
            }
            chnProdIns.setModifier(userName);

            insId = chnProdInsMapper.updateByPrimaryKeySelective(chnProdIns);
        }
        //清除缓存
        cacheClusterClientChannel.del("CREDIT_CHANNEL_INS_" + queryParam.getProductCode() + "_ENTCAE");
        return insId;

    }

    @Autowired
    R2mClusterClient cacheClusterClientChannel;

    @Override
    public Map<String, Object> sortMerchantChannel(Map<String, Object> start, String userName) {
        Map<String, Object> result = new HashMap<>();
        try {
            JSONObject s_weight = JSONObject.parseObject(String.valueOf(start.get("start")));
            JSONObject e_weight = JSONObject.parseObject(String.valueOf(start.get("end")));
            int w1 = s_weight.getIntValue("weight");
            int w2 = e_weight.getIntValue("weight");
            CreditChnProdIns chnProdIns = chnProdInsMapper.selectByPrimaryKey(s_weight.getIntValue("insId"));
            List<CreditChnProdIns> datas = null;
            if (w1 > w2) {//向下移动 >w2
                datas = chnProdInsMapper.queryChannelProdInsBy(chnProdIns.getProductCode(), w2);
                for (CreditChnProdIns ins : datas) {
                    if (ins.getInsId() == e_weight.getIntValue("insId")) {
                        chnProdIns.setWeight(ins.getWeight() - 1);
                    }
                }
            } else if (w1 < w2) {//向上移动 >w2
                datas = chnProdInsMapper.queryChannelProdInsBy(chnProdIns.getProductCode(), w2);
                for (CreditChnProdIns ins : datas) {
                    if (ins.getInsId() == e_weight.getIntValue("insId")) {
                        chnProdIns.setWeight(ins.getWeight());
                        ins.setWeight(ins.getWeight() - 1);

                    }
                }
            }else {
                result.put("success", true);
                result.put("message", "未更新权重");
                return result;
            }
            //批量更新权重
            datas.add(chnProdIns);
            int count = chnProdInsMapper.updateWeightBatch(datas);
            if (count > 0) {
                //清除缓存
                cacheClusterClientChannel.del("CREDIT_CHANNEL_INS_"+chnProdIns.getProductCode()+"_ENTCAE");
                result.put("success", true);
                result.put("message", ResponseMessage.SUCCESS.getDesc());
            }
        }catch (JSONException j){
            j.printStackTrace();
            result.put("success", false);
            result.put("message", ResponseMessage.PARAM_ILLEGAL.getDesc());
        }catch (Exception e) {
            e.printStackTrace();
            result.put("success", false);
            result.put("message", ResponseMessage.SYSTEM_ERROR.getDesc());
        }
        return result;
    }
}
