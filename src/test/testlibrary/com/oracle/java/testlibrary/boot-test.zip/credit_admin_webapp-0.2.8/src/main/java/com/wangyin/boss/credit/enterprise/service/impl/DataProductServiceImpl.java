package com.wangyin.boss.credit.enterprise.service.impl;

import com.wangyin.boss.credit.admin.entity.CreditChnProdIns;
import com.wangyin.boss.credit.enterprise.service.DataProductService;
import com.wangyin.operation.common.beans.PageResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class DataProductServiceImpl implements DataProductService {

    private static final Logger logger = LoggerFactory.getLogger(DataProductServiceImpl.class);


    @Override
    public PageResult<CreditChnProdIns> getChnProduct(CreditChnProdIns creditChnProdIns) {
        return null;
    }
}
