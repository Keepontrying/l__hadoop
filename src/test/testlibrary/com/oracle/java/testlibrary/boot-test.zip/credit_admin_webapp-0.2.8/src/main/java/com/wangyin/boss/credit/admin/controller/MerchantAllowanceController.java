package com.wangyin.boss.credit.admin.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;
import com.jd.jr.boss.credit.facade.authen.beans.param.SubOrderQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountQueryRequest;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccountQueryResponse;
import com.jd.jr.boss.credit.gateway.account.facade.finance.GatewayAccountFacade;
import com.wangyin.boss.credit.admin.entity.CreditOrderBalance;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategyAllow;
import com.wangyin.boss.credit.admin.enums.ChargeTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditTypeEnum;
import com.wangyin.boss.credit.admin.service.CreditMerchantAccountService;
import com.wangyin.boss.credit.admin.service.CreditOrderService;
import com.wangyin.boss.credit.admin.service.CreditProductStrategyService;
import com.wangyin.operation.common.beans.ResponseData;

/**
 * 商户余量查询controller
 * @author wyhaozhihong
 * @since 2016-07-05
 *
 */
@Controller
@RequestMapping("/merchantAllowance")
public class MerchantAllowanceController extends BaseController{
	private static final Logger LOGGER = LoggerFactory.getLogger(MerchantAllowanceController.class);
	
	@Autowired
	CreditProductStrategyService creditProductStrategyService;
	
	@Autowired
	CreditMerchantAccountService creditMerchantAccountService;

	@Resource
	private GatewayAccountFacade accountFacade;

	@Autowired
	CreditOrderService creditOrderService;
	
	/**
	 * 查询商户余量
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryMerchantAllowance.do")
	public Map<String, Object> doQueryMerchantAllowance(@RequestParam Map<String, String> map, CreditProductStrategyAllow creditProductStrategy) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		List<CreditProductStrategyAllow> creditProductStrategyList = new ArrayList<CreditProductStrategyAllow>();
		int creditProductStrategyCount = 0;
		
		try {
			
			if(ChargeTypeEnum.PACKAGE.toName().equalsIgnoreCase(creditProductStrategy.getChargeType()) || ChargeTypeEnum.CUSTOM.toName().equalsIgnoreCase(creditProductStrategy.getChargeType())){ //包量余量查询
				creditProductStrategy.setCreditType(CreditTypeEnum.PERSON.toName());
				creditProductStrategyList = creditProductStrategyService.selectMercAllowanceByParam(creditProductStrategy);
				for (CreditProductStrategyAllow productStrategy : creditProductStrategyList) {
					if(null == productStrategy.getStrategyId() || "".equals(productStrategy.getStrategyId())){
						continue;
					}
					productStrategy.setStartTimeStr(df.format(productStrategy.getStartTime()));
					productStrategy.setFinishTimeStr(df.format(productStrategy.getFinishTime()));
					productStrategy.setPaymentDateStr(null == productStrategy.getPaymentDate() ? "-" : df.format(productStrategy.getPaymentDate()));
					productStrategy.setChargeType(ChargeTypeEnum.enumValueOf(productStrategy.getChargeType()).toDescription());
					
					if(LOGGER.isInfoEnabled()){
						LOGGER.info("根据策略ID=" + productStrategy.getStrategyId() + "查询出的账户号：" + productStrategy.getAccountNo());
					}
					
					if(StringUtils.isNotBlank(productStrategy.getAccountNo())){
						Long balance = selectBalance(productStrategy.getAccountNo());//包量时调用该接口返回的结果值balance对应包量笔数，故无需除以100
						
						/*计费方式为包量时，查剩余次数*/
						productStrategy.setRemainCount(new Integer(balance.intValue()));
						
						/*计费方式为单笔时，查已使用次数*/
						productStrategy.setAlreadyUsedCount(productStrategy.getPacketCount() - productStrategy.getRemainCount());
					}

				}
				creditProductStrategyCount = creditProductStrategyService.selectMercAllowanceCountByParam(creditProductStrategy);
				
			}else{ //单笔余量查询
				creditProductStrategy.setCreditType(CreditTypeEnum.PERSON.toName());
				creditProductStrategyList = creditProductStrategyService.selectMerchantStrategyByParam(creditProductStrategy);
				for (CreditProductStrategyAllow creditProductStrategy2 : creditProductStrategyList) {
					creditProductStrategy2.setChargeType(ChargeTypeEnum.enumValueOf(creditProductStrategy2.getChargeType()).toDescription());
					if(null == creditProductStrategy2.getMerchantId()){
						continue;
					}
					if(LOGGER.isInfoEnabled()){
						LOGGER.info("根据商户ID=" + creditProductStrategy2.getMerchantId() + "查询出的账户号：" + creditProductStrategy2.getAccountNo());
					}
					if(StringUtils.isNotBlank(creditProductStrategy2.getAccountNo())){
						Long balance = selectBalance(creditProductStrategy2.getAccountNo());//单笔时返回的banlance对应的是账户余额，单位为分
						/*查询剩余金额*/
						creditProductStrategy2.setRemainAmount(balance);
					}
					String[] productNames = creditProductStrategy2.getProductName().split(",");
					ArrayList<String> productNameList = new ArrayList<String>();
					for(int i=0;i<productNames.length;i++){
						if(productNameList.contains(productNames[i])){
							continue;
						}else{
							productNameList.add(productNames[i]);
						}
					}
					creditProductStrategy2.setProductName(productNameList.toString().replace("[", "").replace("]", ""));
					
				}
				creditProductStrategyCount = creditProductStrategyService.selectMerchantStrategyCountByParam(creditProductStrategy);
			}
			resultMap.put("rows", creditProductStrategyList);
			resultMap.put("total", creditProductStrategyCount);
		} catch (Exception e) {
			LOGGER.error("doQueryMerchantAllowance error",e);
			resultMap.put("rows", creditProductStrategyList);
			resultMap.put("total", creditProductStrategyCount);
		}
		
		return resultMap;
	}


	/**
	 * 查询商户余量,企业版
	 * @author jiangbo
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryMerchantAllowanceEnterprise.do")
	public Map<String, Object> doQueryMerchantAllowanceEnterprise(@RequestParam Map<String, String> map, SubOrderQueryParam subOrderQueryParam) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "操作失败");
//		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		List<CreditOrderBalance> creditOrderBalanceList = new ArrayList<CreditOrderBalance>();
		if (org.apache.commons.lang3.StringUtils.isBlank(subOrderQueryParam.getMerchantNo())){
			LOGGER.warn("doQueryMerchantAllowanceEnterprise error,merchantNo is null");
			resultMap.put("rows", creditOrderBalanceList);
			resultMap.put("total", 0);
			resultMap.put("message", "商户id不能为空");
			return resultMap;
		}

		try {
			CreditPage<CreditOrder> creditPageOrder = creditOrderService.querySubOrder(subOrderQueryParam);
			LOGGER.info("creditOrderService.queryCreditOrderMain, result:{}, param:{}", ReflectionToStringBuilder.toString(creditPageOrder), ReflectionToStringBuilder.toString(subOrderQueryParam));
			for (CreditOrder creditOrder : creditPageOrder.getRows()) {
				Long balance = selectBalance(creditOrder.getAccountNo());
				if (balance != null) {
					CreditOrderBalance creditOrderBalance = new CreditOrderBalance();
					BeanUtils.copyProperties(creditOrder, creditOrderBalance);
					creditOrderBalance.setBalance(balance);
					creditOrderBalance.setStrategyChargeTypeDesc(creditOrder.getStrategyChargeType().toDescription());
					creditOrderBalanceList.add(creditOrderBalance);

				}
			}

			resultMap.put("rows", creditOrderBalanceList);
			resultMap.put("total", creditPageOrder.getTotal());
			resultMap.put("success", true);
			resultMap.put("message", "操作成功");
		} catch (Exception e) {
			LOGGER.error("doQueryMerchantAllowanceEnterprise error",e);
			resultMap.put("rows", creditOrderBalanceList);
			resultMap.put("total", 0);

		}

		return resultMap;
	}
	
	/**
	 * @author wyhaozhihong
	 * @param accountNo
	 * @return
	 */
	private Long selectBalance(String accountNo) {
		//依据清结算账号查询余额信息
		com.wangyin.operation.common.beans.RequestParam<GatewayAccountQueryRequest> accountRequestParam = new com.wangyin.operation.common.beans.RequestParam<GatewayAccountQueryRequest>();
		GatewayAccountQueryRequest gatewayAccountQueryRequest = new GatewayAccountQueryRequest();
		gatewayAccountQueryRequest.setAccountNo(accountNo);
		accountRequestParam.setParam(gatewayAccountQueryRequest); 
		ResponseData<GatewayAccountQueryResponse> accountResponseData = accountFacade.queryAccountInfo(accountRequestParam); 
		Long balance = accountResponseData.getData().getBalance();
		return balance;
	}


	
}
