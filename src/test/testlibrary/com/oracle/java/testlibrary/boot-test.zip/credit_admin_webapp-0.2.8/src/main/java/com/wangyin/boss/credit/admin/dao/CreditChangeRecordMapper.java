package com.wangyin.boss.credit.admin.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditChangeRecord;

@SqlMapper
@Component
public interface CreditChangeRecordMapper {
	
	/**
	 * 新增操作变更记录表 记录
	 * @param record
	 * @return
	 */
    int insert(CreditChangeRecord record);
    
    /**
     * 根据操作变更记录表的关联id查询 操作变更记录表
     * @param configId
     * @return
     */
	List<CreditChangeRecord> selectCredChanRecdsByConfigId(Integer configId);


}