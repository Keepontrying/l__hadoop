package com.wangyin.boss.credit.admin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.jd.jr.boss.credit.gateway.unc.utils.FlowNoUtils;
import com.wangyin.hsp.client.HSPClient;
import com.wangyin.hsp.client.HSPConfig;
import org.junit.Test;


public class HspTest1 {
    public static final int BUffER_SIZE = 2 * 1024;

    public static void main(String[] args) throws Exception {
        System.out.println("-----HspTest----");
        FileOutputStream fos1 = null;
        HSPClient hspClient = null;
        try {
            System.out.println("--------:"+ FlowNoUtils.createFlowMd5No("credit"));
//            fos1 = new FileOutputStream(new File("E:/leyou1.zip"));
//            HspTest1.toZip("E:/test", fos1, true);
/*            hspClient = initHSpClient();//初始化hspClient

            SaveResult saveResult = hspClient.save("E:/leyou1.zip");
            System.out.println(JSONObject.toJSONString(saveResult));

            String url = hspClient.getUrl(saveResult.getFid(), 60, "test.zip");
            System.out.println(url);*/
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fos1 != null) {
                fos1.close();
            }
            if (hspClient != null) {
                hspClient.close();
            }
        }

    }

    public static HSPClient initHSpClient() {
        Properties prop = getProperties("src//main//profiles//betagn//hsp-config.properties");
        HSPConfig hspConfig = new HSPConfig(prop.getProperty("hsp.connectString"), Integer.parseInt(prop.getProperty("hsp.applicationID")), prop.getProperty("hsp.applicationPwd"));
        hspConfig.setHttpServerUrl(prop.getProperty("hsp.httpServerUrl"));
        HSPClient hspClient = new HSPClient(hspConfig);
        return hspClient;
    }

    public static Properties getProperties(String path) {
        Properties prop = new Properties();
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(new File(path));
            prop.load(fileInputStream);
        } catch (IOException e1) {
            e1.printStackTrace();
        } finally {
            try {
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return prop;
    }

    /**
     * @param srcDir           压缩文件路径
     * @param fos1             压缩文件输出流
     * @param KeepDirStructure 是否保留原来的目录结构；false：所有文件文件跑到压缩包根目录下（注意：不保留目录结构可能会出现同名文件，会压缩失败）
     */
    public static void toZip(String srcDir, FileOutputStream fos1, boolean KeepDirStructure) {
        long start = System.currentTimeMillis();
        ZipOutputStream zos = null;
        try {
            zos = new ZipOutputStream(fos1);

            File sourceFile = new File(srcDir);
            compress(sourceFile, zos, sourceFile.getName(), KeepDirStructure);
            long end = System.currentTimeMillis();
            System.out.println("压缩完成，耗时" + (end - start) + "ms");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                zos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static void compress(File sourceFile, ZipOutputStream zos, String name, boolean KeepDirStructure) throws IOException {
        byte[] buf = new byte[BUffER_SIZE];
        if (sourceFile.isFile()) {
            //向zip输出流中添加一个zip实体，构造器中name为zip实体的文件的名字
            try {
                zos.putNextEntry(new ZipEntry(name));
            } catch (IOException e) {
                e.printStackTrace();
            }
            int len;
            FileInputStream in = new FileInputStream(sourceFile);
            while ((len = in.read(buf)) != -1) {
                zos.write(buf, 0, len);
            }
            in.close();
            zos.closeEntry();
        } else {
            File[] listFiles = sourceFile.listFiles();
            if (listFiles == null || listFiles.length == 0) {
                if (KeepDirStructure) {
                    zos.putNextEntry(new ZipEntry(name + "/"));
                    zos.closeEntry();
                }
            } else {
                for (File file : listFiles) {
                    if (KeepDirStructure) {
                        compress(file, zos, name + "/" + file.getName(), KeepDirStructure);
                    } else {
                        compress(file, zos, file.getName(), KeepDirStructure);
                    }
                }
            }
        }
    }

   @Test
    public  void createUrlByFid() {
        try {
            //线上配置信息
            String connectString ="domain=hsp-domain-mater.jdfin.local:8008,hsp-domain-slaver.jdfin.local:8008;token=hsp-token.jdfin.local:80;AKSServiceAlias=AKS-JSF;";
            int applicationId = 17;
            String applicationPwd ="zxmh20170519";
            String httpServerUrl ="http://hsp.jdpay.com";

//            String connectString ="domain=172.25.45.40:8008,172.25.45.41:8008;token=172.25.45.42:8010;AKSServiceAlias=AKS-JSF-7e474d52c9e1fb97ff35840205c2a87e;";
//            int applicationId = 17;
//            String applicationPwd ="zxmh20170519";
//            String httpServerUrl ="http://172.25.45.43";
            HSPConfig hspConfig= new HSPConfig(connectString, applicationId, applicationPwd);
            hspConfig.setHttpServerUrl(httpServerUrl);
            HSPClient hspClient = new HSPClient(hspConfig);
            String fid = "46_1809_5319_468";
            String filename = "46_1809_5319_468.xlsx";
            String url = hspClient.getUrl(fid, 0, filename);
            System.out.println("createUrlByFid fid : " + fid);
            System.out.println("createUrlByFid url : " + url);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
