package com.wangyin.boss.credit.admin.service.impl;


import com.jd.jdjr.ras.api.domain.result.RasStatusResult;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.entity.merchant.MerchantAccountVo;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.request.merchant.GatewayMerchantQueryRequest;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.response.merchant.GatewayMerchantQueryResponse;
import com.jd.jr.boss.credit.credit.gateway.merchantca.enums.MercCaRasAuditEnum;
import com.jd.jr.boss.credit.credit.gateway.merchantca.exception.MerchantException;
import com.jd.jr.boss.credit.credit.gateway.merchantca.facade.merchant.GatewayMerchantFacade;
import com.jd.jr.boss.credit.credit.gateway.merchantca.service.GatewayMerchantAccountService;
import com.jd.jr.boss.credit.domain.common.enums.OpenOrCloseStatusEnum;
import com.jd.jr.boss.credit.gateway.unc.facade.email.GatewayUncEmailFacade;
import com.wangyin.boss.credit.admin.dao.CreditMerchantMapper;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.enums.AccessCallModeEnum;
import com.wangyin.boss.credit.admin.enums.CreditMerchantResourceEnum;
import com.wangyin.boss.credit.admin.enums.CreditMerchantTypeEnum;
import com.wangyin.boss.credit.admin.service.MerchantCaService;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/** 
* @desciption : 商户认证接口实现类 
* @author : yangjinlin@jd.com
* @date ：2016年9月6日 下午5:50:33 
* @version 1.0 
* @return  */
@Service
public class MerchantCaServiceImpl implements MerchantCaService {
	
	private static Logger logger = LoggerFactory.getLogger(MerchantCaServiceImpl.class);

	@Resource
	public GatewayMerchantFacade gatewayMerchantFacade;
	
	@Resource
	GatewayMerchantAccountService gatewayMerchantAccountService;
	
	@Resource
	GatewayUncEmailFacade gatewayUncEmailFacade;
	
	@Autowired
	CreditMerchantMapper creditMerchantMapper;
	
	@SuppressWarnings("unchecked")
	@Override
	public Page<GatewayMerchantQueryResponse> queryMerchantInfo(GatewayMerchantQueryRequest merchantQueryReq) throws MerchantException {
		// TODO Auto-generated method stub
		RequestParam<GatewayMerchantQueryRequest> requestParam = new RequestParam<GatewayMerchantQueryRequest>();
		requestParam.setParam(merchantQueryReq);
		Page<GatewayMerchantQueryResponse> pageData = gatewayMerchantFacade.queryMerchantInfo(requestParam);//调用商户列表查询接口
		logger.info(" queryMerchantInfo JSF merchant list interface response data :"+ GsonUtil.getInstance().toJson(pageData));
		if(CollectionUtils.isEmpty(pageData.getRows())){
			logger.info("queryMerchantInfo merchantNo :"+ merchantQueryReq.getMerchant() + " is not exist in merchant list interface");
		}
		for(GatewayMerchantQueryResponse merchant : pageData.getRows()){//再次调用商户认证详细信息的dubbo接口获取商户认证状态
			RasStatusResult rasStatusResult = gatewayMerchantFacade.queryRasAuthMerchantByNo(merchant.getMerchant());//20180411实名认证接口升级
			logger.info("queryRasAuthMerchantByNo responseData :"+ GsonUtil.getInstance().toJson(rasStatusResult));
			if(rasStatusResult.getCode().equals("RAS00000")){
				merchant.setCompanyName(rasStatusResult.getCompanyName());//
				merchant.setMerchantCaStatus(MercCaRasAuditEnum.enumValueOf(rasStatusResult.getRealStatus()).getDescription());//返回的状态值为 英文字符串
				//商户联调模式的逻辑处理
				CreditMerchant merch = creditMerchantMapper.selectByMerchantNo(merchant.getMerchant());//根据商户号查询该商户在商户表中是否存在
				if(null != merch){
					merchant.setCallModel(merch.getCallModel());
					if(StringUtils.isNotBlank(merch.getSecretKey())){
						merchant.setSecretKey("已发送");
					}else{
						merchant.setSecretKey("未发送");
					}
					merchant.setMerchantResource(merch.getMerchantResource());
				}else{
					merchant.setSecretKey("未发送");
					merchant.setCallModel("不可操作");
				}
			}else if (rasStatusResult.getCode().equals("RAS20002")){
				merchant.setMerchantCaStatus("未认证");//接口返回成功但由于该商户号未实名等原因，视其状态为未认证
				merchant.setSecretKey("未发送");
				merchant.setCallModel("不可操作");
			}else{
				merchant.setSecretKey("暂不明确,请稍后查询");
				logger.error("queryRasStatus error, responseData :"+ GsonUtil.getInstance().toJson(rasStatusResult));
			}
//			Map<String, Object> dubboRouteMap = new HashMap<String, Object>();
//			dubboRouteMap.put("exectype", "AUTH001");
//			dubboRouteMap.put("owner", merchant.getMerchant());
//			ResultObject resultObject = gatewayMerchantFacade.queryAuthMerchantByNo(dubboRouteMap);//调用商户认证接口查询接口
//			logger.info("queryMerchantInfo queryAuthMerchantByNo response data :"+ GsonUtil.getInstance().toJson(resultObject));
//			GatewayMercCaDubRespHeader respHeadr = GsonUtil.getInstance().fromJson(
//			GsonUtil.getInstance().toJson(resultObject.getHeadMap()), GatewayMercCaDubRespHeader.class);
//			if(MerchantCaDubRespEnum.MERCHANT_DUBBO_CODE_SUCCESS.toName().equals(respHeadr.getRescode())){
//				logger.info("queryMerchantInfo queryMerchantInfo queryAuthMerchantByNo response data success :"+ GsonUtil.getInstance().toJson(resultObject));
//				if(!"".equals(resultObject.getDataMap().get("baseinfo")) && null != resultObject.getDataMap().get("baseinfo")){//rescode为 0000000  时body为null，貌似为不合规格式
//					List<AuthBaseInfoForm> bodyBase = (List<AuthBaseInfoForm>) resultObject.getDataMap().get("baseinfo");
//					if(null != bodyBase.get(0)){//bodyBase.get(0).getStatus().getCode()
//						merchant.setCompanyName(bodyBase.get(0).getName());//
//						merchant.setMerchantCaStatus(MercCaDubRespAuthStatusEnum.enumValueOf(Integer.valueOf(bodyBase.get(0).getStatus().getCode())).getDescription());//返回的状态值为 英文字符串
//						//商户联调模式的逻辑处理
//						CreditMerchant merch = creditMerchantMapper.selectByMerchantNo(merchant.getMerchant());//根据商户号查询该商户在商户表中是否存在
//						if(null != merch){
//							merchant.setCallModel(merch.getCallModel());
//							if(StringUtils.isNotBlank(merch.getSecretKey())){
//								merchant.setSecretKey("已发送");
//							}else{
//								merchant.setSecretKey("未发送");
//							}
//							merchant.setMerchantResource(merch.getMerchantResource());
//						}else{
//							merchant.setSecretKey("未发送");
//							merchant.setCallModel("不可操作");
//						}
//						
//					}else{
//						merchant.setMerchantCaStatus("未认证");//接口返回成功但由于该商户号未实名等原因，视其状态为未认证
//						merchant.setSecretKey("未发送");
//						merchant.setCallModel("不可操作");
//					}
//				}else{//接口返回0000000 成功，但是对于的dadamap没有数据,原因可能是该 商户号未实名?
//					merchant.setMerchantCaStatus("未认证");//接口返回成功但由于该商户号未实名等原因，视其状态为未认证
//					merchant.setSecretKey("未发送");
//					merchant.setCallModel("不可操作");
//				}
//			}else{
//				logger.info("queryMerchantInfo queryMerchantInfo queryMerchantInfo queryAuthMerchantByNo response data failure :"+ GsonUtil.getInstance().toJson(resultObject));
//				merchant.setSecretKey("暂不明确,请稍后查询");
//			}
		}
		return pageData;
	}

	@Override
	public boolean addMercAndSendMail(GatewayMerchantQueryResponse merchantQueryResp, String operaUserName, String receiver,
			String subject, String bizNo, Map<String, Object> templateParams, String templateCode, String appCode, String secretKey, String operatePlat) throws Exception {
		
		boolean resultFlag = false;
			
		CreditMerchant merch = creditMerchantMapper.selectByMerchantNo(merchantQueryResp.getMerchant());//根据商户号查询该商户在商户表中是否存在
		CreditMerchant merchant = new CreditMerchant();
		if(null == merch || "".equals(merch)){//根据商户号查询不到商户,创建一条商户记录
			templateParams.put("secretKey", secretKey);
			logger.info("调用merchant-unc包中发送邮件接口的请求PARAM---收件人receiver," + receiver+",subject:"+subject+",流水号bizNo:"+ 
					bizNo+",templateParams:"+GsonUtil.getInstance().toJson(templateParams)+",templateCode:"+templateCode+",appCode:"+appCode);
			boolean sendMailResult = gatewayUncEmailFacade.sendMailByUnc(receiver, subject, bizNo, templateParams, templateCode, appCode);
			if(sendMailResult){//邮件发送成功
			
				merchant.setMerchantNo(merchantQueryResp.getMerchant());
				merchant.setMerchantName(merchantQueryResp.getCompanyName());
				merchant.setSecretKey(secretKey);
				merchant.setCreator(operaUserName);
				merchant.setModifier(operaUserName);
				merchant.setMerchantStatus(OpenOrCloseStatusEnum.OPEN.toName());//创建商户时默认为开通open
				merchant.setCallModel(AccessCallModeEnum.DEBUG.toName());//创建商户时默认为联调模式
				merchant.setMerchantResource(CreditMerchantResourceEnum.NEW.toName());//创建商户时默认为新入驻商户
				merchant.setMerchantType(CreditMerchantTypeEnum.PERSON.toName());
				creditMerchantMapper.insert(merchant);
				resultFlag = true;
			}else{
				logger.info("商户认证模块商户:"+merchantQueryResp.getMerchant()+"不存在，调用UNC发送邮件接口失败");
			}
		}else{//该商户已存在商户表中,本动作仅更新
			if(StringUtil.isEmpty(merch.getSecretKey())){//商户存在但密钥为空，则发送新密钥并更新商户表
				templateParams.put("secretKey", secretKey);
				merchant.setSecretKey(secretKey);
			}else{
				templateParams.put("secretKey", merch.getSecretKey());//商户存在但密钥为空，则发送已有密钥
			}
			boolean sendMailResult = false;
			try {
				logger.info("调用merchant-unc包中发送邮件接口的请求PARAM---收件人receiver," + receiver+",subject:"+subject+",流水号bizNo:"+ 
						bizNo+",templateParams:"+GsonUtil.getInstance().toJson(templateParams)+",templateCode:"+templateCode+",appCode:"+appCode);
				sendMailResult = gatewayUncEmailFacade.sendMailByUnc(receiver, subject, bizNo, templateParams, templateCode, appCode);
			} catch (Exception e) {
				throw  new Exception();
			}
			if(true == sendMailResult){//邮件发送成功
				merchant.setMerchantId(merch.getMerchantId());
				merchant.setMerchantNo(merchantQueryResp.getMerchant());
				merchant.setMerchantName(merchantQueryResp.getCompanyName());
				merchant.setModifier(operaUserName);
				if(StringUtils.isNotBlank(operatePlat) && CreditMerchantTypeEnum.ENTERPRISE.toName().equalsIgnoreCase(operatePlat)){
					//donothing
				}else{
					if(CreditMerchantTypeEnum.ENTERPRISE.toName().equalsIgnoreCase(merch.getMerchantType()) || 
							CreditMerchantTypeEnum.ALL.toName().equalsIgnoreCase(merch.getMerchantType()) ){
						merchant.setMerchantType(CreditMerchantTypeEnum.ALL.toName());
					}else{
						merchant.setMerchantType(CreditMerchantTypeEnum.PERSON.toName());
					}
				}
				creditMerchantMapper.updateByPrimaryKeySelective(merchant);
				resultFlag = true;
			}else{
				logger.info("商户认证模块商户"+merchantQueryResp.getMerchant()+"已存在，调用UNC发送邮件接口失败");
			}
		}
		
		return resultFlag;
	}

	@Override
	public Page<GatewayMerchantQueryResponse> queryMerchantInfoByOne(String merchantNo) throws MerchantException {
		
		RequestParam<GatewayMerchantQueryRequest> requestParam = new RequestParam<GatewayMerchantQueryRequest>();
		GatewayMerchantQueryRequest merchantQueryReq = new GatewayMerchantQueryRequest();
		merchantQueryReq.setMerchant(merchantNo);
		requestParam.setParam(merchantQueryReq);
		return gatewayMerchantFacade.queryMerchantInfo(requestParam);//调用商户列表查询接口;
	}

	@Override
	public List<MerchantAccountVo> queryMerchantAccountByNo(MerchantAccountVo queryMerchantAccountVo) throws Exception {
		return gatewayMerchantAccountService.queryMerchantAccounts(queryMerchantAccountVo);
	}

	@Override
	public RasStatusResult queryAuthMerchantByNo(String merchantNo) {
		if(StringUtils.isBlank(merchantNo)){
			return null;
		}
		RasStatusResult rasStatusResult = gatewayMerchantFacade.queryRasAuthMerchantByNo(merchantNo);
		logger.info("queryRasAuthMerchantByNo responseData :"+ GsonUtil.getInstance().toJson(rasStatusResult));
		if(rasStatusResult.getCode().equals("RAS00000")){
			if(rasStatusResult.getRealStatus().equals(MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_SUCCESS.getCode())){//接口调用成功并且已实名
				return rasStatusResult;
			}else{
				return null;
			}
		}else if (rasStatusResult.getCode().equals("RAS20002")){
			return null;
		}else{
			logger.error("queryRasStatus error, responseData :"+ GsonUtil.getInstance().toJson(rasStatusResult));
			return null;
		}
		
//		dubboRouteMap.put("exectype", "AUTH001");
//		ResultObject resultObject = gatewayMerchantFacade.queryAuthMerchantByNo(dubboRouteMap);//调用商户认证接口查询接口
//		List<AuthBaseInfoForm> bodyBase = new ArrayList<AuthBaseInfoForm>();
//		logger.info("queryMerchantInfo 调用认证基础信息和证件信息查询接口 的返回结果 :"+ GsonUtil.getInstance().toJson(resultObject));
//		GatewayMercCaDubRespHeader respHeadr = GsonUtil.getInstance().fromJson(
//				GsonUtil.getInstance().toJson(resultObject.getHeadMap()), GatewayMercCaDubRespHeader.class);
//		if(MerchantCaDubRespEnum.MERCHANT_DUBBO_CODE_SUCCESS.toName().equals(respHeadr.getRescode())){
//			logger.info("queryMerchantInfo 调用认证基础信息和证件信息查询接口 成功 :"+ GsonUtil.getInstance().toJson(resultObject));
//			if(!"".equals(resultObject.getDataMap().get("baseinfo")) && null != resultObject.getDataMap().get("baseinfo")
//					&& !CollectionUtils.isEmpty((List<AuthBaseInfoForm>) resultObject.getDataMap().get("baseinfo"))){//rescode为 0000000  时body为null，貌似为不合规格式
//				bodyBase = (List<AuthBaseInfoForm>) resultObject.getDataMap().get("baseinfo");
//				if(null != bodyBase.get(0)){//bodyBase.get(0).getStatus().getCode()
//					return bodyBase;
//				}else{
//					return bodyBase;
//				}
//			}else{//接口返回0000000 成功，但是对于的dadamap没有数据,原因可能是该商户号未实名
//				return bodyBase;
//			}
//		}else{
//			logger.info("queryMerchantInfo 调用认证基础信息和证件信息查询接口 失败 :"+ GsonUtil.getInstance().toJson(resultObject));
//			return bodyBase;
//		}
	}

	@Override
	public boolean updateMerchCallByNo(CreditMerchant cm) throws Exception {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		creditMerchantMapper.updateMerchByNo(cm);
		resultFlag = true;
		return resultFlag;
	}

	@Override
	public List<CreditMerchant> selectAllLocalMerchant(CreditMerchant merchant) {
		// TODO Auto-generated method stub
		return creditMerchantMapper.selectAllLocalMerchant(merchant);
	}

	@Override
	public int selectMerchantCountByParam(CreditMerchant merchant) {
		// TODO Auto-generated method stub
		return creditMerchantMapper.selectMerchantCountByParam(merchant);
	}

	@Override
	public List<CreditMerchant> selectMerchantByParam(CreditMerchant merchant) {
		// TODO Auto-generated method stub
		return creditMerchantMapper.selectMerchantByParam(merchant);
	}

	@Override
	public int selectCountAllLocalMerchant(CreditMerchant merchant) {
		// TODO Auto-generated method stub
		return creditMerchantMapper.selectCountAllLocalMerchant(merchant);
	}

    public GatewayMerchantQueryResponse queryMerchantInfoByHttp(String merchantNo) throws MerchantException {
        CreditMerchant cm = new CreditMerchant();
        cm.setMerchantNo(merchantNo);
        return queryMerchantInfoByHttp(cm);
    }
	@Override
	public GatewayMerchantQueryResponse queryMerchantInfoByHttp(CreditMerchant cm) throws MerchantException {
		// TODO Auto-generated method stub
		GatewayMerchantQueryResponse gmqResp = new GatewayMerchantQueryResponse();
		RequestParam<GatewayMerchantQueryRequest> requestParam = new RequestParam<GatewayMerchantQueryRequest>();
		GatewayMerchantQueryRequest merchantQueryReq = new GatewayMerchantQueryRequest();
		merchantQueryReq.setMerchant(cm.getMerchantNo());
		requestParam.setParam(merchantQueryReq);
		Page<GatewayMerchantQueryResponse> pageData = gatewayMerchantFacade.queryMerchantInfo(requestParam);//调用商户列表查询接口
		logger.info("queryMerchantInfoByHttp call gatewayMerchantFacade.queryMerchantInfo result:{}", ReflectionToStringBuilder.toString(pageData));
		if(pageData.isSuccess() && CollectionUtils.isNotEmpty(pageData.getRows())){
			gmqResp.setLinkPhone(pageData.getRows().get(0).getLinkPhone());
			gmqResp.setRegisterDate(pageData.getRows().get(0).getRegisterDate());
			gmqResp.setOriginName(pageData.getRows().get(0).getOriginName());
			gmqResp.setCompanyName(pageData.getRows().get(0).getCompanyName());
			gmqResp.setUserName(pageData.getRows().get(0).getUserName());
			gmqResp.setEmail(pageData.getRows().get(0).getEmail());
			logger.info("queryRasAuthMerchantByNo request param:"+ GsonUtil.getInstance().toJson(cm.getMerchantNo()));
			RasStatusResult rasStatusResult = gatewayMerchantFacade.queryRasAuthMerchantByNo(cm.getMerchantNo());
			logger.info("queryRasAuthMerchantByNo responseData :"+ GsonUtil.getInstance().toJson(rasStatusResult));

			if(rasStatusResult.getCode().equals("RAS00000")){
				gmqResp.setMerchantCaStatus(MercCaRasAuditEnum.enumValueOf(rasStatusResult.getRealStatus()).getDescription());//返回的状态值为 数字符串
				gmqResp.setAuthCreatedDate(rasStatusResult.getCreateTime());
				gmqResp.setAuthModifiedDate(rasStatusResult.getStartTime());
				gmqResp.setCompanyName(rasStatusResult.getCompanyName());
			}else if (rasStatusResult.getCode().equals("RAS20002")){
				gmqResp.setMerchantCaStatus("未认证");
			}else{
				gmqResp.setMerchantCaStatus("暂不明确");
				logger.error("queryRasStatus error, responseData :"+ GsonUtil.getInstance().toJson(rasStatusResult));
			}
		}else{
			logger.info("queryMerchantInfo merchantNo :"+ merchantQueryReq.getMerchant() + " is not exist in merchant list interface");
			//gmqResp.setMerchantCaStatus("该商户在 企业站提供的商户列表中不存在");
		}
		return gmqResp;
	}

	@Override
	public boolean updateMerchById(CreditMerchant cm) throws Exception {
		int result = creditMerchantMapper.updateByPrimaryKeySelective(cm);
		if (result > 0){
			logger.info("updateByPrimaryKeySelective success,creditMerchant id:{}",cm.getMerchantId());
			return true;
		}else {
			logger.error("updateByPrimaryKeySelective error,CreditMerchant:{}", ReflectionToStringBuilder.toString(cm));
			return false;
		}
	}
	
	@Override
	public GatewayMerchantQueryResponse queryMerchantInfoByJsf(CreditMerchant cm) throws MerchantException {
		// TODO Auto-generated method stub
		GatewayMerchantQueryResponse gmqResp = new GatewayMerchantQueryResponse();
		RequestParam<GatewayMerchantQueryRequest> requestParam = new RequestParam<GatewayMerchantQueryRequest>();
		GatewayMerchantQueryRequest merchantQueryReq = new GatewayMerchantQueryRequest();
		merchantQueryReq.setMerchant(cm.getMerchantNo());
		requestParam.setParam(merchantQueryReq);
		Page<GatewayMerchantQueryResponse> pageData  = new Page<GatewayMerchantQueryResponse>();
		try {
			pageData = gatewayMerchantFacade.queryMerchantInfo(requestParam);//调用商户列表查询JSF接口
			logger.info("queryMerchantInfoByJsf call gatewayMerchantFacade.queryMerchantInfo result:{}", ReflectionToStringBuilder.toString(pageData));
			if(pageData.isSuccess() && CollectionUtils.isNotEmpty(pageData.getRows())){
				gmqResp.setLinkPhone(pageData.getRows().get(0).getLinkPhone());
				gmqResp.setRegisterDate(pageData.getRows().get(0).getRegisterDate());
				gmqResp.setOriginName(pageData.getRows().get(0).getOriginName());
				gmqResp.setCompanyName(pageData.getRows().get(0).getCompanyName());
				gmqResp.setUserName(pageData.getRows().get(0).getUserName());
				gmqResp.setEmail(pageData.getRows().get(0).getEmail());
			}else{
				logger.info("queryMerchantInfoByJsf merchantNo :"+ merchantQueryReq.getMerchant() + " is not exist in merchant list interface");
				//gmqResp.setMerchantCaStatus("该商户在 企业站提供的商户列表中不存在");
			}
		} catch (Exception e) {
			logger.error("queryMerchantInfoByJsf error, "+e);
			throw  new MerchantException();
		}
		
		return gmqResp;
	}


}
