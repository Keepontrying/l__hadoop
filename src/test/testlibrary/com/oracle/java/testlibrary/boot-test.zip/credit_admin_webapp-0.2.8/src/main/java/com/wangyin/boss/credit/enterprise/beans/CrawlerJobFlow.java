package com.wangyin.boss.credit.enterprise.beans;

import java.io.Serializable;

/**
 * 爬虫任务流水
 *
 * @author huangzhiqiang
 * @data 2018/11/28
 */
public class CrawlerJobFlow implements Serializable {

    private Long id;
    /**
     * 任务类别
     * 0 - 实时
     * 1 - 定时
     */
    private Byte category;
    /**
     * 任务流水号
     */
    private String jobNo;
    /**
     * 爬虫内容
     */
    private String postStr;
    /**
     * 返回结果消息
     */
    private String message;
    /**
     * 流水状态
     * 0 - 已创建
     * 1 - 爬取成功未发送
     * 2 - 爬取成功已发送
     * -1 - 爬取失败
     */
    private byte state;

    private int count;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Byte getCategory() {
        return category;
    }

    public void setCategory(Byte category) {
        this.category = category;
    }

    public String getJobNo() {
        return jobNo;
    }

    public void setJobNo(String jobNo) {
        this.jobNo = jobNo;
    }

    public String getPostStr() {
        return postStr;
    }

    public void setPostStr(String postStr) {
        this.postStr = postStr;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public byte getState() {
        return state;
    }

    public void setState(byte state) {
        this.state = state;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
