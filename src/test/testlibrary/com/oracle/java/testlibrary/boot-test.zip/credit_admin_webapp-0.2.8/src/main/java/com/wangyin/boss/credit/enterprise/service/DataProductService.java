package com.wangyin.boss.credit.enterprise.service;

import com.wangyin.boss.credit.admin.entity.CreditChnProdIns;
import com.wangyin.operation.common.beans.PageResult;

public interface DataProductService {

    public PageResult<CreditChnProdIns> getChnProduct(CreditChnProdIns creditChnProdIns);

}
