package com.wangyin.boss.credit.admin.beans;

import com.jd.jr.boss.credit.domain.common.enums.TextValueInterface;

import java.io.Serializable;

/**
 * 
 * @author wyhaozhihong
 *
 */
public class TextValuePairs implements TextValueInterface<String, String>, Serializable{
	private static final long serialVersionUID = 6239440426410094694L;
	
	private String text = "";
	private String value="";
	
	public TextValuePairs(){}
	public TextValuePairs(TextValueInterface<Object, Object> obj){
        if (obj.getValue() != null) {
            this.value = obj.getValue().toString();
        }
        if (obj.getText() != null) {
            this.text = obj.getText().toString();
        }
    }

	public TextValuePairs(String text, String value) {
		super();
		this.text = text;
		this.value = value;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	
}
