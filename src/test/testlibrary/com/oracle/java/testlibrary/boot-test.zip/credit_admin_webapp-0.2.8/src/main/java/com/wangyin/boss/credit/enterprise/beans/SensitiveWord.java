package com.wangyin.boss.credit.enterprise.beans;

import java.io.Serializable;
import java.util.Date;

/**
 * 舆情监控 - 敏感词
 *
 * @author huangzhiqiang
 * @data 2018/11/16
 */
public class SensitiveWord implements Serializable {

    /**
     * 主键
     */
    private Long id;
    /**
     * 类别
     * 0 - 主关键词
     * 1 - 副关键词
     */
    private Byte type;
    /**
     * 分组
     */
    private Long groupId;
    /**
     * 敏感词组
     */
    private String groupName;
    /**
     * 敏感词
     */
    private String word;
    /**
     * 创建时间
     */
    private Date createdDate;

    public static byte b = 0;
    public String getTypeDesc() {
        if (type == null) {
            return "";
        }
        return type.equals(b) ? "主关键词" : "副关键词";
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Byte getType() {
        return type;
    }

    public void setType(Byte type) {
        this.type = type;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
}
