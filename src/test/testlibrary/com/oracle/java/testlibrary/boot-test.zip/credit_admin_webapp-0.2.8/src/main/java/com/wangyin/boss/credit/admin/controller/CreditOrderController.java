package com.wangyin.boss.credit.admin.controller;

import com.jd.fastjson.JSON;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrderMain;
import com.jd.jr.boss.credit.domain.common.enums.ContractStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditPurchaseTypeEnum;
import com.jd.jr.boss.credit.facade.authen.beans.param.SubOrderQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.wangyin.boss.credit.admin.beans.param.OrderPageQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import com.wangyin.boss.credit.admin.enums.*;
import com.wangyin.boss.credit.admin.service.CreditContractService;
import com.wangyin.boss.credit.admin.service.CreditMerchantService;
import com.wangyin.boss.credit.admin.service.CreditOrderService;
import com.wangyin.boss.credit.admin.service.CreditProductStrategyService;
import com.wangyin.boss.credit.admin.service.MerchantCaService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by anmeng on 2017/3/23.
 */
@Controller
@RequestMapping("/creditOrder")
public class CreditOrderController extends BaseController{
    private static final Logger LOGGER = LoggerFactory.getLogger(CreditOrderController.class);

    @Autowired
    MerchantCaService merchantCaService;

    @Autowired
    CreditMerchantService creditMerchantService;

    @Autowired
    CreditContractService creditContractService;

    @Autowired
    private CreditOrderService creditOrderService;
    
    @Autowired
	CreditProductStrategyService creditProductStrategyService;

    @ResponseBody
    @RequestMapping("toCreateOrder.view")
    public Map<String,Object> toCreateOrder(@RequestParam Map<String, String> map, CreditOrderMain orderMain){
        Map<String,Object> resultMap = new HashMap<String, Object>();
        return resultMap;
    }

    /**
     * 校验商户号是否存在---调用商户列表接口获取商户信息
     * @author anmeng
     * @param map
     * @return
     */
    @ResponseBody
    @RequestMapping("doValidMerchantNo.do")
    public Map<String, Object> doValidMerchantNo(@RequestParam Map<String, Object> map, String merchantNo) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        resultMap.put("success", true);
        resultMap.put("message", "验证成功");

        try {
            CreditMerchant merchantQueryParam=new CreditMerchant();
            merchantQueryParam.setMerchantNo(merchantNo);
//            merchantQueryParam.setMerchantType(CreditMerchantTypeEnum.ENTERPRISE.toName());
            merchantQueryParam.setMerchantTypeList(Arrays.asList((CreditMerchantTypeEnum.ENTERPRISE.toName()+","+CreditMerchantTypeEnum.ALL.toName()).substring(0).split(",")));
            List<CreditMerchant> merchantList=creditMerchantService.queryMerchantListByParam(merchantQueryParam);

            if(CollectionUtils.isEmpty(merchantList)){
                resultMap.put("success", false);
                resultMap.put("message", "该商户号不存在");
                return resultMap;
            }else if(CreditMerchantStatusEnum.CLOSE.toName().equals(merchantList.get(0).getMerchantStatus())){
                //若商户状态为CLOSE则提示商户不可用并且不可进行合同创建
                resultMap.put("success", false);
                resultMap.put("message", "该商户的状态为:"+ CreditMerchantStatusEnum.CLOSE.toDescription());
                return resultMap;
            }else{
                CreditMerchant merchantInfo=merchantList.get(0);
                resultMap.put("firstName", merchantInfo.getMerchantName());
            }

            /**
             * 查询商户合同 要求未支付或者有效状态 credit_type为企业征信
             */
            CreditContract queryParam=new CreditContract();
            queryParam.setMerchantNo(merchantNo);
            List<String> contractStatusList=new ArrayList<String>();
            contractStatusList.add(ContractStatusEnum.NOPAY.toName());
            contractStatusList.add(ContractStatusEnum.VALID.toName());
            queryParam.setCreditType(CreditTypeEnum.ENTERPRISE.toName());
            queryParam.setContractStatusList(contractStatusList);
            queryParam.setContractSource(CreditContractSourceEnum.OFFLINE.toName());
            queryParam.setPurchaseType(CreditPurchaseTypeEnum.PRE);
            List<CreditContract> contractList = creditContractService.selectContrByContrParam(queryParam);
            resultMap.put("contractList", contractList);
        } catch (Exception e) {
            LOGGER.error(e);
            resultMap.put("rows", new ArrayList<CreditContract>());
            resultMap.put("total", 0);
            return resultMap;
        }

        return resultMap;
    }

    /**
     * 创建订单
     * @param map
     * @param orderMain
     * @return
     */

    @ResponseBody
    @RequestMapping("doCreateOrder.do")
    public Map<String, Object> doCreateOrder(@RequestParam Map<String, String> map, CreditOrderMain orderMain,String user) {

        Map<String,Object> resultMap = new HashMap<String, Object>();
        resultMap.put("success", false);
        resultMap.put("message", "操作失败");
        try {

            CreditMerchant merchantQueryParam=new CreditMerchant();
            merchantQueryParam.setMerchantNo(orderMain.getOrderOwnedNo());
            merchantQueryParam.setMerchantTypeList(Arrays.asList((CreditMerchantTypeEnum.ENTERPRISE.toName()+","+CreditMerchantTypeEnum.ALL.toName()).substring(0).split(",")));
            List<CreditMerchant> merchantList=creditMerchantService.queryMerchantListByParam(merchantQueryParam);

            if(CollectionUtils.isEmpty(merchantList)){
                resultMap.put("success", false);
                resultMap.put("message", "该商户号不存在");
                return resultMap;
            }else if(CreditMerchantStatusEnum.CLOSE.toName().equals(merchantList.get(0).getMerchantStatus())){
                //若商户状态为CLOSE则提示商户不可用并且不可进行合同创建
                resultMap.put("success", false);
                resultMap.put("message", "该商户的状态为:"+ CreditMerchantStatusEnum.CLOSE.toDescription());
                return resultMap;
            }

            String operator= "error";
            try {
                operator = this.getLoginRealName(user);
            } catch (Exception e) {
                LOGGER.warn(e.getMessage());
            }
            orderMain.setCreator(operator);
            orderMain.setModifier(operator);
            orderMain.setMerchantNo(merchantList.get(0).getMerchantNo());
            String subOrderListStr=map.get("subOrderListStr");
            List<CreditOrder> orderList = JSON.parseArray(subOrderListStr, CreditOrder.class);
            
//            SubOrderQueryParam orderQueryParam = new SubOrderQueryParam();
//            orderQueryParam.setMerchantNo(merchantList.get(0).getMerchantNo());
//            orderQueryParam.setContractId(orderMain.getContractId());
//            orderQueryParam.setChargeType((ChargeTypeEnum.SINGLE.toName()));
//            List<CreditOrder> orderSingleWithContratList = creditOrderService.queryContractOrder(orderQueryParam);
//			if(CollectionUtils.isEmpty(orderSingleWithContratList)){
				CreditProductStrategy creditProductStrategy = new CreditProductStrategy();
	            creditProductStrategy.setContractId(orderMain.getContractId());
	            creditProductStrategy.setMerchantNo(merchantList.get(0).getMerchantNo());
	            creditProductStrategy.setChargeType(ChargeTypeEnum.SINGLE.toName());
	            creditProductStrategy.setLimit("10000000");
				List<CreditProductStrategy> creditProductStrategySingleList = creditProductStrategyService.selectByParam(creditProductStrategy);
				if( CollectionUtils.isNotEmpty(creditProductStrategySingleList) && creditProductStrategySingleList.size()>0 ){
					for(CreditProductStrategy strategy : creditProductStrategySingleList){
						CreditOrder order = new CreditOrder();
		            	order.setStrategyId(strategy.getStrategyId());
		            	order.setVipMonitorFlag(strategy.getVipMonitorFlag());
		            	orderList.add(order);
					}
				}
//			}
			if(CollectionUtils.isEmpty(orderList)){
                resultMap.put("success", false);
                resultMap.put("message", "本次提交无可用计费策略！");
                return resultMap;
            }
            orderMain.setSubOrderList(orderList);
            creditOrderService.createOffLineOrder(orderMain);
            resultMap.put("success", true);
            resultMap.put("message", "操作成功");
        } catch (Exception e) {
            LOGGER.error(e);
            resultMap.put("success", false);
            resultMap.put("message", "操作失败");
        }

        return resultMap;
    }

    /**
     * 查询订单列表
     * @param map
     * @param queryParam
     * @return
     */
    @ResponseBody
    @RequestMapping("doQueryOrder.do")
    public Map<String, Object> doQueryContract(@RequestParam Map<String, Object> map,OrderPageQueryParam queryParam) {
        Map<String,Object> resultMap = new HashMap<String, Object>();
        try {
            CreditPage<CreditOrderMain> resultPage= creditOrderService.queryCreditOrderMain(queryParam);
            List<CreditOrderMain> resultList=resultPage.getRows();
            Long count=resultPage.getTotal();
            resultMap.put("rows", resultList);
            resultMap.put("total", count);
        } catch (Exception e) {
            LOGGER.error(e);
            resultMap.put("rows", new ArrayList<CreditContract>());
            resultMap.put("total", 0);
        }

        return resultMap;
    }

    /**
     * 确认打款
     * @param map
     * @param orderMain
     * @return
     */
    @ResponseBody
    @RequestMapping("confirmReceive.do")
    public Map<String, Object> confirmReceive(@RequestParam Map<String, String> map, CreditOrderMain orderMain) {

        Map<String,Object> resultMap = new HashMap<String, Object>();
        resultMap.put("success", true);
        resultMap.put("message", "操作成功");
        try {
            creditOrderService.confirmReceive(orderMain.getOrderMainId());
        } catch (Exception e) {
            LOGGER.error(e);
            resultMap.put("success", false);
            resultMap.put("message", "操作失败");
        }

        return resultMap;
    }

    /**
     * 查询订单详情
     * @param map
     * @param orderMain
     * @return
     */
    @ResponseBody
    @RequestMapping("doQueryOrderDetail.do")
    public Map<String, Object> doQueryOrderDetail(@RequestParam Map<String, Object> map, CreditOrderMain orderMain) {
        Map<String,Object> resultMap = new HashMap<String, Object>();
        try {
            CreditOrderMain result= creditOrderService.queryOrderMainDetail(orderMain.getOrderMainId());
            resultMap.put("orderDetail", result);
        } catch (Exception e) {
            LOGGER.error(e);
        }

        return resultMap;
    }
    
    @ResponseBody
	@RequestMapping("doQueryContractOrder.do")
	public Map<String, Object> doQueryContractOrder(@RequestParam Map<String, String> map, SubOrderQueryParam orderQueryParam,
			CreditProductStrategy creditProductStrategy) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
//			orderQueryParam.setChargeType(ChargeTypeEnum.SINGLE.toName());
//			List<CreditOrder> orderSingleWithContratList = creditOrderService.queryContractOrder(orderQueryParam);
//			if(CollectionUtils.isNotEmpty(orderSingleWithContratList)){
//				resultMap.put("success", true);
//				resultMap.put("total", 0);
//				resultMap.put("rows", new ArrayList<CreditOrder>());
//				return resultMap;
//			}
			creditProductStrategy.setChargeType(ChargeTypeEnum.SINGLE.toName());
			List<CreditProductStrategy> creditProductStrategySingleList = creditProductStrategyService.selectByParam(creditProductStrategy);
			
			for (CreditProductStrategy creditProductStrategy2 : creditProductStrategySingleList) {
				creditProductStrategy2.setChargeType(ChargeTypeEnum.enumValueOf(creditProductStrategy2.getChargeType()).toDescription());
				creditProductStrategy2.setStartTimeStr(sdf.format(creditProductStrategy2.getStartTime()));
				creditProductStrategy2.setFinishTimeStr(sdf.format(creditProductStrategy2.getFinishTime()));
			}
			resultMap.put("rows", creditProductStrategySingleList);//  creditProductStrategyList
			resultMap.put("total", CollectionUtils.isEmpty(creditProductStrategySingleList) ? 0 : creditProductStrategySingleList.size());
			resultMap.put("success", true);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("total", 0);
			resultMap.put("rows", new ArrayList<CreditProductStrategy>());
		}
		return resultMap;
	}
    
    
}
