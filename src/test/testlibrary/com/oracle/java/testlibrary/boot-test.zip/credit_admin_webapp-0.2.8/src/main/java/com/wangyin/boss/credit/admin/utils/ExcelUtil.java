package com.wangyin.boss.credit.admin.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/** 
* @desciption : excel工具类
* @author : yangjinlin@jd.com
* @date ：2018年1月2日 下午9:01:52 
* @version 1.0 
* @return  */
public class ExcelUtil {
	/**
     * 总行数
     */
    private int totalRows = 0;
    /**
     * 总列数
     */
    private int totalCells = 0;
    /**
     * 错误信息
     */
    private String errorInfo;

    public int getTotalRows() {
        return totalRows;
    }

    public int getTotalCells() {
        return totalCells;
    }

    public String getErrorInfo() {
        return errorInfo;
    }
    
    public List<List<String>> read(InputStream inputStream, boolean isExcel2003, int skipRow) {
        List<List<String>> dataLst = null;
        Workbook wb = null;
        try {
            /** 根据版本选择创建Workbook的方式 */
            if (isExcel2003) {
                wb = new HSSFWorkbook(inputStream);
            } else {
                wb = new XSSFWorkbook(inputStream);
            }
            dataLst = read(wb, skipRow);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (wb != null) {
                    wb.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return dataLst;
    }


    private List<List<String>> read(Workbook wb, int skipRow) {
        List<List<String>> dataLst = new ArrayList<List<String>>();
        /** 得到第一个shell */
        Sheet sheet = wb.getSheetAt(0);
        /** 得到Excel的行数 */
        this.totalRows = sheet.getPhysicalNumberOfRows();
        /** 得到Excel的列数 */
        if (this.totalRows >= 1 && sheet.getRow(0) != null) {
            this.totalCells = sheet.getRow(0).getPhysicalNumberOfCells();
        }

        if (skipRow < 0) {
            skipRow = 0;
        }
        /** 循环Excel的行 */
        for (int r = skipRow; r < this.totalRows; r++) {
            Row row = sheet.getRow(r);
            if (row == null) {
                continue;
            }
            List<String> rowLst = new ArrayList<String>();
            /** 循环Excel的列 */
            for (int c = 0; c < this.getTotalCells(); c++) {
                Cell cell = row.getCell(c);
                String cellValue = "";
                if (null != cell) {
                    // 以下是判断数据的类型
                    switch (cell.getCellTypeEnum()) {
                        case NUMERIC: // 数字
                        	DecimalFormat df = new DecimalFormat("0");  
                            cellValue = df.format(cell.getNumericCellValue());  
                            break;
                        case STRING: // 字符串
                            cellValue = cell.getStringCellValue();
                            break;
                        case BOOLEAN: // Boolean
                            cellValue = cell.getBooleanCellValue() + "";
                            break;
                        case FORMULA: // 公式
                            cellValue = cell.getCellFormula() + "";
                            break;
                        case BLANK: // 空值
                        case _NONE: // 空值
                            cellValue = "";
                            break;
                        case ERROR: // 故障
                            cellValue = "非法字符";
                            break;
                        default:
                            cellValue = "未知类型";
                            break;
                    }
                }
                rowLst.add(cellValue);
            }
            /** 保存第r行的第c列 */
            dataLst.add(rowLst);
        }
        return dataLst;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    /**
     * 导出excel
     *
     * @param data
     * @param isExcel2003
     * @return
     */
    public ByteArrayOutputStream export(List<List<String>> data, boolean isExcel2003) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        //创建工作薄
        Workbook wb = null;
        try {
            if (isExcel2003) {
                wb = new HSSFWorkbook();
            } else {
                wb = new XSSFWorkbook();
            }

            Sheet sheet = wb.createSheet();// 声明工作表
            for (int j = 0; j < data.size(); j++) {
                List<String> row = data.get(j);
                // 创建行
                Row rowData = sheet.createRow(j);
                // 在表头每列 放值
                for (int i = 0; i < row.size(); i++) {
                    Cell cell = rowData.createCell(i);
                    cell.setCellValue(row.get(i));
                }
            }
            wb.write(baos);
            baos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (baos != null) {
                    baos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (wb != null) {
                    wb.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return baos;
    }
    
    
	/**
	 * @descrption				使用poi的SXSSFWorkbook组件导出xlsx文件，支持大数据量导出
	 * @param wb				工作薄
	 * @param output			导出的数据流，有可能是文件流，可能是网络数据流
	 * @param workSheetName		工作表名称
	 * @param titles			表头信息
	 * @param property			对象属性，对对象的哪些属性进行导出
	 * @param data				数据集合
	 * @param defaultValue		设置默认值
	 * @param clazz				进行类型转换的类，需要注意的是方法必须使用get+属性名（首字母大写）。参数为属性类型。如username为String类型，
	 *							则方法为public String getUsername(String
	 * 							username)
	 * @param sheet				sheet表
	 * @param rowNum			行数
	 * @return					Sheet
	 */
	public Sheet export(SXSSFWorkbook wb,OutputStream output, String workSheetName,
			String[] titles, String[] property, List<?> data,
			String defaultValue, Class<?> clazz,Sheet sheet,int rowNum) {

		// 每个sheet中的总显示数（最大行数）
		int sheetMaxRowCount = 1048575;

		// 每个sheet的列数
		int columNumber = titles.length;

		try {

			for (Object bean : data) {

				// 此处加1.00，用于强制转换类型留下一行用于表头信息，然后肯定是要向上进位了
				Double sheetIndex = Math.ceil((rowNum + 1.00)
						/ sheetMaxRowCount);

				// 返回的Double，当然要取int类型了
				int sheetNum = sheetIndex.intValue();

				Row rowData = null;// 表内容

				// 如果行数刚好是最大行数的整数倍，就应该加一个工作表了
				if (rowNum == sheetMaxRowCount * (sheetNum - 1)) {

					// sheet表名依次为表0、表1、表2...
					sheet = wb.createSheet(workSheetName + sheetNum);

					// 创建行
					rowData = sheet.createRow(0);

					// 在表头每列 放值
					for (int columnIndex = 0; columnIndex < columNumber; columnIndex++) {

						// 按照表头信息生成每一个表头单元格信息
						Cell headerCell = rowData.createCell(columnIndex);

						// 设置每一列的宽度
						sheet.setColumnWidth(columnIndex, 6000);

						// 居中
//						setBorder.setAlignment(HSSFCellStyle.ALIGN_CENTER);

						// 设置单元格值
						headerCell.setCellValue(titles[columnIndex]);

					}

				}

				// 创建行
				rowData = sheet.createRow(rowNum - sheetMaxRowCount
						* (sheetNum - 1) + 1);

				for (int columnIndex = 0; columnIndex < columNumber; columnIndex++) {

					// 按照表头信息生成每一个表头单元格信息
					Cell cellData = rowData.createCell(columnIndex);

					// 设置每一列的宽度
					sheet.setColumnWidth(columnIndex, 6000);

					Method method = clazz.getMethod("get"+ StringHelper.upperCaseFirstChar(property[columnIndex]));
                    Object invoke = method.invoke(bean);

                    //给Cell赋值  若getter方法返回的值为null,则赋默认defaultValue值
					if(invoke == null){
						cellData.setCellValue(defaultValue);
					}else{
						cellData.setCellValue(String.valueOf(invoke));
					}

				}

				// 行数要加1了。
				rowNum++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sheet;

	}
	
	/**
	 * @author wyhaozhihong
	 * @desc					用于生成表头信息
	 * @param wb				工作薄
	 * @param workSheetName		工作表名称
	 * @param titles			表头信息
	 * @param sheet
	 * @return
	 */
	public Sheet export(SXSSFWorkbook wb,String workSheetName,String[] titles, Sheet sheet) {
		
		// sheet表名依次为表0、表1、表2...
		sheet = wb.createSheet(workSheetName + 1);
		
		Row rowData = null;// 表内容

		// 创建行
		rowData = sheet.createRow(0);
		
		// 在表头每列 放值
		for (int columnIndex = 0; columnIndex < titles.length; columnIndex++) {

			// 按照表头信息生成每一个表头单元格信息
			Cell headerCell = rowData.createCell(columnIndex);

			// 设置每一列的宽度
			sheet.setColumnWidth(columnIndex, 6000);

			// 设置单元格值
			headerCell.setCellValue(titles[columnIndex]);

		}
		
		return sheet;
	}
	
	
}
