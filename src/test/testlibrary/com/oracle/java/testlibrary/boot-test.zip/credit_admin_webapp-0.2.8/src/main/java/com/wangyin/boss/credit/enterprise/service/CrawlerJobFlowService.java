package com.wangyin.boss.credit.enterprise.service;

import com.wangyin.boss.credit.enterprise.beans.CrawlerJob;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobFlow;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResultsQueryParam;

import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2018/11/28
 */
public interface CrawlerJobFlowService {

    String addJobFlow(CrawlerJob job);

    Long addOrUpdate(CrawlerJobFlow flow);

    List<CrawlerJobFlow> queryList(CrawlerJobResultsQueryParam param);
}
