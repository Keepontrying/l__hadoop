package com.wangyin.boss.credit.admin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wangyin.boss.credit.admin.dao.CreditRosterMapper;
import com.wangyin.boss.credit.admin.entity.CreditRoster;
import com.wangyin.boss.credit.admin.service.CreditRosterService;

@Service
public class CreditRosterServiceImpl implements CreditRosterService {
	
	@Autowired
	private CreditRosterMapper creditRosterMapper;
	
	@Override
	public List<CreditRoster> selectByParam(CreditRoster creditRoster) {
		return creditRosterMapper.selectByParam(creditRoster);
	}

	@Override
	public int selectCountByParam(CreditRoster creditRoster) {
		return creditRosterMapper.selectCountByParam(creditRoster);
	}

	@Override
	public String selectByMerchantId(CreditRoster creditRoster) {
		return creditRosterMapper.selectByMerchantId(creditRoster);
	}

	@Override
	public List<CreditRoster> selectInfoByMerchantId(CreditRoster creditRoster) {
		return creditRosterMapper.selectInfoByMerchantId(creditRoster);
	}

	@Override
	public int deleteDomain(CreditRoster creditRoster) {
		return creditRosterMapper.deleteByRosterId(creditRoster);
	}

	@Override
	public int insert(CreditRoster creditRoster) {
		return creditRosterMapper.insert(creditRoster);
	}

}
