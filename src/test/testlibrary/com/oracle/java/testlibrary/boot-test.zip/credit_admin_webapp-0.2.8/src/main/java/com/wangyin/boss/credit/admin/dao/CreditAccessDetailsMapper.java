package com.wangyin.boss.credit.admin.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditAccessDetails;

@SqlMapper
@Component
public interface CreditAccessDetailsMapper {
	
	List<CreditAccessDetails> selectByParam(CreditAccessDetails creditAccessDetails);

	int selectCountByParam(CreditAccessDetails creditAccessDetails);
	
	int insert(CreditAccessDetails record);

	CreditAccessDetails selectAccessDetailById(CreditAccessDetails accessDetail);
	
}