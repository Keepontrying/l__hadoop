package com.wangyin.boss.credit.admin.controller;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.response.merchant.GatewayMerchantQueryResponse;
import com.jd.jr.boss.credit.credit.gateway.merchantca.exception.MerchantException;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrderMain;
import com.jd.jr.boss.credit.domain.common.enums.ContractStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditYesOrNoEnum;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.wangyin.boss.credit.admin.beans.param.OrderPageQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.service.CreditMerchantService;
import com.wangyin.boss.credit.admin.service.CreditOrderService;
import com.wangyin.boss.credit.admin.service.MerchantCaService;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.ResponseData;

/**
 * 商户信息controller
 *
 * @author: dongzhihua
 * @time: 2018/10/29 16:17:22
 */
@Controller
@RequestMapping("creditMerchant")
public class CreditMerchantController {

    @Resource
    CreditMerchantService creditMerchantService;
    @Autowired
    private MerchantCaService merchantCaService;

    @Autowired
    private CreditOrderService creditOrderService;

    @RequestMapping("queryCreditMerchantPage.do")
    @ResponseBody
    Page<CreditMerchant> queryCreditMerchantPage(CreditMerchant creditMerchant) throws MerchantException {
//    	if(creditMerchant != null) {
//    		creditMerchant.setContractStatus(ContractStatusEnum.VALID.name());//只查有效合同的 孙学帅新需求20181213
//    	}
        return creditMerchantService.queryCreditMerchantPage(creditMerchant);
    }

    @RequestMapping("getMerchantCaStatus.do")
    @ResponseBody
    public ResponseData<String> getMerchantCaStatus(String merchantNo) throws MerchantException {
        GatewayMerchantQueryResponse gmqResp = merchantCaService.queryMerchantInfoByHttp(merchantNo);
        return new ResponseData<String>(gmqResp.getMerchantCaStatus());
    }

    @RequestMapping("getSignStatus.do")
    @ResponseBody
    public ResponseData<String> getSignStatus(String merchantNo) {
        String signStatus = "未签约";
        if (StringUtils.isNotEmpty(merchantNo)) {
            OrderPageQueryParam orderPageQueryParam = new OrderPageQueryParam();
            orderPageQueryParam.setMerchantNo(merchantNo);
            orderPageQueryParam.setSignStatus(CreditYesOrNoEnum.YES.toName());
            CreditPage<CreditOrderMain> creditOrderMainCreditPage = creditOrderService.queryCreditOrderMain(orderPageQueryParam);
            if (creditOrderMainCreditPage.getTotal() > 0) {
                signStatus = "已签约";
            }
        }
        return new ResponseData<String>(signStatus);
    }
}
