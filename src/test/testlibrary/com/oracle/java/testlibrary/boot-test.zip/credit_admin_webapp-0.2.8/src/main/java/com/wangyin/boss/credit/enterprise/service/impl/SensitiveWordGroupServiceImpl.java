package com.wangyin.boss.credit.enterprise.service.impl;

import com.wangyin.boss.credit.enterprise.beans.SensitiveWordGroup;
import com.wangyin.boss.credit.enterprise.beans.SensitiveWordQueryParam;
import com.wangyin.boss.credit.enterprise.dao.SensitiveWordGroupMapper;
import com.wangyin.boss.credit.enterprise.service.SensitiveWordGroupService;
import com.wangyin.operation.common.beans.Page;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author huangzhiqiang
 * @data 2018/11/19
 */
@Service
public class SensitiveWordGroupServiceImpl implements SensitiveWordGroupService {

    @Resource
    private SensitiveWordGroupMapper mapper;

    @Override
    public Long insert(SensitiveWordGroup word) {
        return mapper.insert(word);
    }

    @Override
    public void update(SensitiveWordGroup word) {
        mapper.update(word);
    }

    @Override
    public Page<SensitiveWordGroup> query(SensitiveWordQueryParam param) {
        Page<SensitiveWordGroup> page = new Page<>();
        int total = mapper.queryCount(param);
        page.setTotal(total);
        if (total > 0) {
            page.setRows(mapper.query(param));
        }
        return page;
    }

}
