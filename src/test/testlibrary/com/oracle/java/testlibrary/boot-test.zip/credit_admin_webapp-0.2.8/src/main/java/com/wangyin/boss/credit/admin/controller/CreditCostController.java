package com.wangyin.boss.credit.admin.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wangyin.boss.credit.admin.entity.CreditCost;
import com.wangyin.boss.credit.admin.enums.CostStatusEnum;
import com.wangyin.boss.credit.admin.service.CreditCostService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/**
 * 接口成本管理 controller
 * @author wyhaozhihong
 * @since 2016-07-22
 *
 */
@Controller
@RequestMapping("/creditCost")
public class CreditCostController extends BaseController{
	private static final Logger LOGGER = LoggerFactory.getLogger(CreditCostController.class);
	
	@Autowired
	CreditCostService creditCostService;
	
	/**
	 * 查询接口成本配置
	 * @author wyhaozhihong
	 * @param map
	 * @param creditCost
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryCreditCost.do")
	public Map<String, Object> doQueryCreditCost(@RequestParam Map<String, String> map, CreditCost creditCost) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		List<CreditCost> creditCostList = new ArrayList<CreditCost>();
		int creditCostCount = 0;
		
		try {
			creditCostList = creditCostService.selectByParam(creditCost);
			for (CreditCost creditCost2 : creditCostList) {
				creditCost2.setCostStatus(CostStatusEnum.getValueByCode(creditCost2.getCostStatus()));
			}
			creditCostCount = creditCostService.selectCountByParam(creditCost);
		} catch (Exception e) {
			LOGGER.error(e);
		}
		resultMap.put("rows", creditCostList);
		resultMap.put("total", creditCostCount);
		
		return resultMap;
	}
	
	/**
	 * 创建接口成本
	 * @author wyhaozhihong
	 * @param map
	 * @param creditCost
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doCreateCreditCost.do")
	public Map<String, Object> doCreateCreditCost(@RequestParam Map<String, String> map, CreditCost creditCost, String user) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "操作失败");
		
		try {
			Date startDate = DateUtils.parseDate(creditCost.getStartDateStr(), new String[]{"yyyy-MM-dd"});
			creditCost.setStartDate(startDate);
			creditCost.setPrice(new BigDecimal(creditCost.getPriceStr()).multiply(new BigDecimal(100)).longValue());
			creditCost.setCostStatus(CostStatusEnum.OPEN.getCode());
			
			String userName = null;
			try {
				userName = getLoginRealName(user);
			} catch (Exception e) {
				LOGGER.error(e);
				userName = "error";
			}
			creditCost.setCreator(userName);
			//creditCost.setFinishDate(new Date());
			
			int count = creditCostService.insert(creditCost);
			if(count == 1){
				resultMap.put("success", true);
				resultMap.put("message", "操作成功");
			}
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "操作异常");
		}
		
		return resultMap;
	}
	
}
