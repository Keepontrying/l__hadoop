package com.wangyin.boss.credit.admin.service;

import com.jd.jr.boss.credit.gateway.account.beans.entity.finance.FundFlowQueryEntity;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountQueryRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountRechargeRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayFundFlowQueryRequest;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccounTradeResponse;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccountQueryResponse;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.ResponseData;

/** 
* @desciption : 商户余额余量service接口类
* @author : yangjinlin@jd.com
* @date ：2017年11月25日 下午8:19:16 
* @version 1.0 
* @return  */
public interface CreditMerchantBalanceAllowanceService {

	/**
	 * 根据账户号查询账户余额余量
	 * @param accountQueryRequest
	 * @return
	 */
	public ResponseData<GatewayAccountQueryResponse> queryAccountInfo(GatewayAccountQueryRequest accountQueryRequest);

	/**
	 * 账户充值
	 * @param req
	 * @return
	 */
	public ResponseData<GatewayAccounTradeResponse> accountRecharge(GatewayAccountRechargeRequest req);

	/**
	 * 根据账户号查询充值流水信息
	 * @param fundFlowQueryRequest
	 * @return
	 */
	public Page<FundFlowQueryEntity> queryFlowsByDate(GatewayFundFlowQueryRequest fundFlowQueryRequest);

}
