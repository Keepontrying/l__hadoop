package com.wangyin.boss.credit.enterprise.beans;

import com.wangyin.operation.common.beans.PageQuery;

import java.io.Serializable;
import java.util.Date;

/**
 * 舆情监控 - 敏感词筛选入参
 *
 * @author huangzhiqiang
 * @data 2018/11/20
 */
public class SensitiveWordQueryParam extends PageQuery implements Serializable {
    /**
     * 查询字符
     */
    private String word;

    private String wordRaw;
    /**
     * 敏感词类别
     */
    private Byte type;
    /**
     * 敏感词组别
     */
    private Long groupId;
    /**
     * 起始时间
     */
    private Date time1;
    /**
     * 终止时间
     */
    private Date time2;

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getWordRaw() {
        return wordRaw;
    }

    public void setWordRaw(String wordRaw) {
        this.wordRaw = wordRaw;
    }

    public Byte getType() {
        return type;
    }

    public void setType(Byte type) {
        this.type = type;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public Date getTime1() {
        return time1;
    }

    public void setTime1(Date time1) {
        this.time1 = time1;
    }

    public Date getTime2() {
        return time2;
    }

    public void setTime2(Date time2) {
        this.time2 = time2;
    }
}
