package com.wangyin.boss.credit.admin.dao;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditBill;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import org.springframework.stereotype.Component;

import java.util.List;

@SqlMapper
@Component
public interface CreditUserMapper {

	List<CreditUser> selectCreditUserByParam(CreditUser creditUser);
//
	int selectCreditUserCountByParam(CreditUser credituser);

	/**
	 * 根据主键更新用户信息
	 *  yangjinlin@jd.com
	 * @param creditUser
	 * @return
	 */
	int modifyUserByPrimaryKey(CreditUser creditUser);
//
//	List<CreditBill> selectMonthBillByParam(CreditBill creditBill);
//
//	int selectMonthBillCountByParam(CreditBill creditBill);
//
//	int insert(CreditBill record);
}