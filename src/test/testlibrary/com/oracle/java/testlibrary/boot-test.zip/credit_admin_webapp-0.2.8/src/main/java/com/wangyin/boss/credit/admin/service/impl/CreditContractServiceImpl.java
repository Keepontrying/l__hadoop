package com.wangyin.boss.credit.admin.service.impl;

import com.jd.jr.boss.credit.domain.common.constants.PaymentOrderConstants;
import com.jd.jr.boss.credit.domain.common.enums.ContractStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditPaymentTypeEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditStrategyStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.OpenOrCloseStatusEnum;
import com.jd.jr.boss.credit.gateway.account.beans.request.payment.GatewayPaymentCancelRequest;
import com.jd.jr.boss.credit.gateway.account.facade.payment.GatewayPaymentOrderFacade;
import com.wangyin.boss.credit.admin.dao.*;
import com.wangyin.boss.credit.admin.entity.*;
import com.wangyin.boss.credit.admin.enums.*;
import com.wangyin.boss.credit.admin.service.CreditContractService;
import com.wangyin.boss.payment.api.dto.PaymentOrderResponseDTO;
import com.wangyin.commons.util.Logger;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CreditContractServiceImpl implements CreditContractService {
	private static final Logger LOGGER = new Logger(CreditContractServiceImpl.class);
	
	@Autowired
	CreditContractMapper creditContractMapper;
	
	@Autowired
	CreditContractDetailsMapper creditContractDetailsMapper;
	
	@Autowired
	CreditMerchantMapper creditMerchantMapper;
	
	@Autowired
	CreditProductStrategyMapper creditProductStrategyMapper;
	
	@Autowired
	CreditChangeRecordMapper creditChangeRecordMapper;
	
	@Autowired
	CreditProductConfigMapper creditProductConfigMapper;
	
	@Autowired
	private GatewayPaymentOrderFacade gatewayPaymentOrderFacade;

	@Override
	public List<CreditContract> selectByParam(CreditContract creditContract) {
		return creditContractMapper.selectByParam(creditContract);
	}

	@Override
	public int selectCountByParam(CreditContract creditContract) {
		return creditContractMapper.selectCountByParam(creditContract);
	}

	@Override
	public CreditContract selectByPrimaryKey(Integer contractId) {
		return creditContractMapper.selectByPrimaryKey(contractId);
	}
	
	@Override
	public boolean updateContractForUpload(String contractId, String filePath) {

		CreditContract contractInfo = new CreditContract();
		contractInfo.setContractId(Integer.valueOf(contractId));
		contractInfo.setContractPath(filePath);

		return creditContractMapper.updateContractForUpload(contractInfo) == 1;
	}
	
	@Override
	public List<CreditContract> selectAuditByParam(CreditContract creditContract) {
		return creditContractMapper.selectAuditByParam(creditContract);
	}

	@Override
	public int selectCountAuditByParam(CreditContract creditContract) {
		return creditContractMapper.selectCountAuditByParam(creditContract);
	}

	@Override
	public int createContract(CreditContract creditContract, CreditMerchant creditMerchant, String[] strategyIds) throws Exception {
		
		/*查看商户关系表是否存在改商户的数据，不存在则新增加一条*/
		CreditMerchant cmerchant = creditMerchantMapper.selectByMerchantNo(creditContract.getMerchantNo());
		boolean existCreditMerchant = false;
		Integer merchantId = null;
		int contractId = 0;
		CreditContractDetails creditContractDetails = new CreditContractDetails();
		
		if(null != cmerchant ){//根据商户号查询该商户号已存在，则更新商户信息
			existCreditMerchant = true;
			CreditMerchant merchant = new CreditMerchant();
			merchant.setMerchantName(creditMerchant.getMerchantName());
			merchant.setMerchantSub(creditMerchant.getMerchantSub());
			merchant.setMerchantCode(creditMerchant.getMerchantCode());
			merchantId = cmerchant.getMerchantId();
			merchant.setModifier(creditMerchant.getModifier());
			merchant.setMerchantResource(creditMerchant.getMerchantResource());
			merchant.setMerchantId(merchantId);
			if(CreditMerchantTypeEnum.ENTERPRISE.toName().equalsIgnoreCase(cmerchant.getMerchantType()) ||
					CreditMerchantTypeEnum.ALL.toName().equalsIgnoreCase(cmerchant.getMerchantType())	
					){
				merchant.setMerchantType(CreditMerchantTypeEnum.ALL.toName());
			}else{
				merchant.setMerchantType(CreditMerchantTypeEnum.PERSON.toName());
			}
			creditMerchantMapper.updateByPrimaryKeySelective(merchant);
		}else{//根据商户号查询该商户不存在，则新增商户记录
			/*创建商户关系表数据*/
			creditMerchant.setMerchantStatus(OpenOrCloseStatusEnum.OPEN.toName());//创建商户时默认为开通open
			creditMerchant.setCallModel(AccessCallModeEnum.DEBUG.toName());//创建商户时默认为联调模式
			creditMerchant.setMerchantResource(creditMerchant.getMerchantResource());//创建商户时默认为新入驻商户,现改为可选择
			creditMerchant.setCreator(creditContract.getCreator());
			creditMerchant.setModifier(creditMerchant.getModifier());
			creditMerchant.setMerchantType(CreditMerchantTypeEnum.PERSON.toName());
			creditMerchantMapper.insert(creditMerchant);
			merchantId = creditMerchant.getMerchantId();
		}
		/*创建征信认证产品合同*/
		creditContract.setMerchantId(merchantId);
		creditContract.setContractType(CreditContractTypeEnum.CONTRACT_TYPE_NOSTANDARD.toName());//nostandard
		creditContract.setContractStatus(ContractStatusEnum.NOAUDIT.toName());//"noaudit"
		creditContract.setCreditType(CreditTypeEnum.PERSON.toName());
		creditContract.setContractSource(CreditContractSourceEnum.OFFLINE.toName());
		creditContract.setContractPath(creditContract.getContractPath() == null ? "null" : creditContract.getContractPath());
		if(creditContract.getContractId() != null){
			creditContractMapper.updateByPrimaryKeySelective(creditContract);
			creditContractDetails.setHandleType(CreditContractHandleTypeEnum.MODIFIED.getCode());
		}else{
			creditContractMapper.insert(creditContract);
			creditContractDetails.setHandleType(CreditContractHandleTypeEnum.CREATE.getCode());
		}
		contractId = creditContract.getContractId();
		/*在 合同操作记录表 中增加一条数据*/
		creditContractDetails.setContractId(contractId);
		creditContractDetails.setHandleResult(CreditContractHandleResultEnum.SUCCESS.getCode());
		creditContractDetails.setRemarks("");
		creditContractDetails.setCreator(creditContract.getCreator());
		creditContractDetailsMapper.insert(creditContractDetails);
		if(strategyIds != null){
			/*根据strategy_id更新计费策略的contract_id,merchant_id,strategy_status*/
			CreditProductStrategy creditProductStrategy = new CreditProductStrategy();
			creditProductStrategy.setStrategyIds(Arrays.asList(strategyIds));
			//creditProductStrategy.setStrategyStatus("open");
			creditProductStrategy.setContractId(contractId);
			creditProductStrategy.setMerchantId(merchantId);
			creditProductStrategy.setMerchantNo(creditContract.getMerchantNo());
			creditProductStrategy.setMerchantName(creditContract.getMerchantName());
			creditProductStrategyMapper.updateBatchByPrimaryKeySelective(creditProductStrategy);
			/* 以下为新增合同时往credit_product_config表中新增记录 */
			//从策略表中获取产品Id
			List<CreditProductStrategy> credProdStrategyList = creditProductStrategyMapper.selectBatchByPrimaryKey(Arrays.asList(strategyIds));
			for(CreditProductStrategy credProdStrategy: credProdStrategyList){//
				/* 根据既有的产品ids和商户id 为产品服务配置信息表 新增或修改数据   */
				CreditProductConfig credProdConf = new CreditProductConfig();
				credProdConf.setProductId(credProdStrategy.getProductId());
				credProdConf.setProductName(credProdStrategy.getProductName());
				credProdConf.setMerchantId(credProdStrategy.getMerchantId());
				credProdConf.setMerchantNo(credProdStrategy.getMerchantNo());
				credProdConf.setMerchantName(credProdStrategy.getMerchantName());
				credProdConf.setCreator(credProdStrategy.getCreator());
				credProdConf.setModifier(credProdStrategy.getModifier());
				Map<String, Object> params = new HashMap<String, Object>();
                params.put("productId", credProdStrategy.getProductId());
                params.put("merchantId", merchantId);
				List<CreditProductConfig> credProdConfFindList = creditProductConfigMapper.selectCredProdConfByProdMercId(params);
				if(credProdConfFindList.size() != 0){// update
					creditProductConfigMapper.updateCreProdConfByProdMerchId(credProdConf);
				}else{// insert
					credProdConf.setConfigStatus(OpenOrCloseStatusEnum.OPEN.toName());//新增时默认open
					creditProductConfigMapper.addCreProdConfByProdMerchId(credProdConf);
				}
			}
			
		}
		return contractId;
		
	}

	@Override
	public int updateContractByPrimaryKey(CreditContract creditContract) {
		int count = creditContractMapper.updateByPrimaryKeySelective(creditContract);
		if(count == 1){
			/*在 合同操作记录表 中增加一条数据*/
			CreditContractDetails creditContractDetails = new CreditContractDetails();
			if(ContractStatusEnum.TERMINATE_AUDIT.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.TERMINATE.getCode());
			}else if(ContractStatusEnum.CANCEL_AUDIT.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.CANCEL.getCode());
			}else if(ContractStatusEnum.NOCONFIRM.toName().equalsIgnoreCase(creditContract.getContractStatus()) || ContractStatusEnum.RISK_NOPASS.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.AUDIT.getCode());
			}else if(ContractStatusEnum.CANCEL.toName().equalsIgnoreCase(creditContract.getContractStatus()) || ContractStatusEnum.NOPAY.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.CANCEL_AUDIT.getCode());
			}else if(ContractStatusEnum.MERCHANT_NOPASS.toName().equalsIgnoreCase(creditContract.getContractStatus())){//新增逻辑---驳回合同
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.REJECT.getCode());
			}else {
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.TERMINATE_AUDIT.getCode());
			}
			creditContractDetails.setContractId(creditContract.getContractId());
			if(ContractStatusEnum.TERMINATE_AUDIT.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleResult(CreditContractHandleResultEnum.SUCCESS.getCode());
			}else if(ContractStatusEnum.CANCEL_AUDIT.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleResult(CreditContractHandleResultEnum.SUCCESS.getCode());
			}else if(ContractStatusEnum.NOCONFIRM.toName().equalsIgnoreCase(creditContract.getContractStatus()) || ContractStatusEnum.CANCEL.toName().equalsIgnoreCase(creditContract.getContractStatus()) || ContractStatusEnum.TERMINATE.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleResult(CreditContractHandleResultEnum.PASS.getCode());
			}else{
				creditContractDetails.setHandleResult(CreditContractHandleResultEnum.REJECT.getCode());
			}
			creditContractDetails.setRemarks(creditContract.getCancelRemark());
			creditContractDetails.setCreator(creditContract.getModifier() != null ? creditContract.getModifier() : creditContract.getAuditor());
			creditContractDetailsMapper.insert(creditContractDetails);//在操作记录表中新增操作记录
			
		}
		return count;
	}

	@Override
	public boolean doValidMerchantNoAuth(String merchantNo) {
		
		/*try{
			Map<String,Object> arg0 = new HashMap<String,Object>();
			arg0.put("owner", merchantNo);
			
			AuthBaseInfoForm query = authCenterQueryFacade.query(arg0, QueryType.AUTHCERD001);
			if(query != null){
				if(BaseInfoStatusEnum.CER_SUCCESS == query.getStatus()){
					LOGGER.info("商户的认证信息是有效的");
					return true;
				}else{
					LOGGER.info("可以查询到认证信息但是认证信息状态无效，认证中心返回认证信息状态是："+query.getStatus());
					return false;
				}
			}else{
				LOGGER.error("返回信息为null:"+merchantNo);
			}
		}catch(Exception e){
			LOGGER.error("调用认证接口有异常：",e);
		}*/
		
		return false;
	}

	@Override
	public int modifyContractByPrimaryKey(CreditContract creditContract) {
		int count = creditContractMapper.updateByPrimaryKeySelective(creditContract);
		if(count == 1){
			
			if(ContractStatusEnum.CANCEL.toName().equalsIgnoreCase(creditContract.getContractStatus())){//当作废确认时，CAUDIT对应CANCLE，此时应取消缴费单
				RequestParam<GatewayPaymentCancelRequest> reqaram = new RequestParam<GatewayPaymentCancelRequest>();
				GatewayPaymentCancelRequest payCanlReq = new GatewayPaymentCancelRequest();
				payCanlReq.setOperator(creditContract.getAuditor());
				payCanlReq.setSystemId(PaymentOrderConstants.PARAM_OUTPUT_SYSTEMID);
				payCanlReq.setRequestCode(creditContract.getContractId().toString());
				payCanlReq.setMerchantNo(creditContract.getMerchantNo());
				payCanlReq.setPaymentType(CreditPaymentTypeEnum.CREDIT_PACKAGE.toName());
				reqaram.setParam(payCanlReq);
				ResponseData<PaymentOrderResponseDTO> responseData = gatewayPaymentOrderFacade.cancelPaymentOrder(reqaram);//调用account的取消缴费单接口
				if(responseData.isSuccess()){//撤销缴费单成功
					LOGGER.info("[CreditContractServiceImpl-modifyContractByPrimaryKey]作废合同通过时调用缴费单接口成功："+ GsonUtil.getInstance().toJson(responseData.getData()));
				}else{//撤销缴费单失败，不影响本次作废审核的成功，有其他入口可手动作废缴费单
					LOGGER.info("[CreditContractServiceImpl-modifyContractByPrimaryKey]作废合同通过时调用缴费单接口失败："+ GsonUtil.getInstance().toJson(responseData.getData()));
				}
				
			}
			
			/*在 合同操作记录表 中增加一条数据*/
			CreditContractDetails creditContractDetails = new CreditContractDetails();
			if(ContractStatusEnum.TERMINATE_AUDIT.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.TERMINATE.getCode());
			}else if(ContractStatusEnum.CANCEL_AUDIT.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.CANCEL_AUDIT.getCode());
			}else if(ContractStatusEnum.NOCONFIRM.toName().equalsIgnoreCase(creditContract.getContractStatus()) || 
					ContractStatusEnum.RISK_NOPASS.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.AUDIT.getCode());
			}else if(ContractStatusEnum.CANCEL.toName().equalsIgnoreCase(creditContract.getContractStatus()) || 
					ContractStatusEnum.NOPAY.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.CANCEL_AUDIT.getCode());
			}else {
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.TERMINATE_AUDIT.getCode());
			}
			creditContractDetails.setContractId(creditContract.getContractId());
			if(ContractStatusEnum.TERMINATE_AUDIT.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleResult(CreditContractHandleResultEnum.SUCCESS.getCode());
			}else if(ContractStatusEnum.CANCEL_AUDIT.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleResult(CreditContractHandleResultEnum.SUCCESS.getCode());
			}else if(ContractStatusEnum.NOCONFIRM.toName().equalsIgnoreCase(creditContract.getContractStatus()) || 
					ContractStatusEnum.CANCEL.toName().equalsIgnoreCase(creditContract.getContractStatus()) || 
					ContractStatusEnum.TERMINATE.toName().equalsIgnoreCase(creditContract.getContractStatus()) ){
				creditContractDetails.setHandleResult(CreditContractHandleResultEnum.PASS.getCode());
			}else{
				creditContractDetails.setHandleResult(CreditContractHandleResultEnum.REJECT.getCode());
			}
			creditContractDetails.setRemarks(creditContract.getAuditAdvice());
			creditContractDetails.setCreator(creditContract.getAuditor());
			creditContractDetailsMapper.insert(creditContractDetails);
		}
		
		if( ContractStatusEnum.CANCEL.toName().equalsIgnoreCase(creditContract.getContractStatus()) || 
				ContractStatusEnum.TERMINATE.toName().equalsIgnoreCase(creditContract.getContractStatus()) ){//当合同已作废、
			CreditProductStrategy creditProductStrategy1 = new CreditProductStrategy();
			creditProductStrategy1.setContractId(creditContract.getContractId());
			creditProductStrategy1.setStrategyStatus(CreditStrategyStatusEnum.OPEN.toName());
			List<Integer> strategyIds = creditProductStrategyMapper.selectByContractId(creditProductStrategy1);
			if(strategyIds != null && strategyIds.size() > 0){
				CreditProductStrategy creditProductStrategy = new CreditProductStrategy();
				creditProductStrategy.setContractId(creditContract.getContractId());
				creditProductStrategy.setModifier(creditContract.getAuditor());
				creditProductStrategy.setModifiedDate(creditContract.getAuditTime());
				creditProductStrategy.setStrategyStatus(OpenOrCloseStatusEnum.CLOSE.toName());
				creditProductStrategyMapper.updateStatusForClose(creditProductStrategy);//close
			}
		}
		return count;
	}

	@Override
	public List<CreditContract> selectContractByMerchantNo(String merchantNo) {
		// TODO Auto-generated method stub
		return creditContractMapper.selectContractByMerchantNo(merchantNo);
	}

	@Override
	public List<CreditContract> selectContrByContrParam(CreditContract contract) {
		// TODO Auto-generated method stub
		return creditContractMapper.selectContrByContrParam(contract);
	}

	
}
