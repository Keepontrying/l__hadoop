package com.wangyin.boss.credit.enterprise.utils;

import com.jd.jr.boss.credit.domain.common.enums.HspDirRightsEnum;
import com.jd.jr.boss.credit.domain.common.enums.HspRetCodeEnum;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.enums.CreditHspFidTypeEnum;
import com.wangyin.boss.credit.enterprise.constants.HspConstant;
import com.wangyin.hsp.client.HSPClient;
import com.wangyin.hsp.client.HSPConfig;
import com.wangyin.hsp.client.NetFile;
import com.wangyin.hsp.client.model.result.DirCountResult;
import com.wangyin.operation.utils.GsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

/**
 * Created by zhanghui12 on 2018/5/15.
 * HSP工具类
 */
public class HspUtil {
    private static final Logger logger = LoggerFactory.getLogger(HspUtil.class);

    private static final String connectString = ConfigUtil.getString(HspConstant.HSP_CONNECT_STRING);
    private static final int appid = Integer.valueOf(ConfigUtil.getString(HspConstant.HSP_PORTAL_APPID));
    private static final String apppwd = ConfigUtil.getString(HspConstant.HSP_PORTAL_APPPWD);
    private static final String httpServerUrl = ConfigUtil.getString(HspConstant.HSP_HTTPSERVER_URL);

    private static final HSPClient hspClient;
    private static final HSPConfig hspConfig;

    static {
        hspConfig = new HSPConfig(connectString, appid, apppwd);
        hspConfig.setHttpServerUrl(httpServerUrl);
        hspClient = new HSPClient(hspConfig);
    }


    /**
     * 上传到hsp
     *
     * @param file
     * @param source
     * @param fileType
     * @param merchantNo
     * @return
     */
    public static String toHsp(File file, CreditHspFidTypeEnum source, String fileType, String merchantNo, String path) {
        String fileName = file.getName();
        String dateStr = (new SimpleDateFormat("yyyyMMdd")).format(new Date());
        String hspPath = ConfigUtil.getString(path) + "/" + dateStr;
        String randomStr = String.valueOf((int) (10000 + Math.random() * 99000));
        String hspFileName = source.toName() + "_" + merchantNo + "_" + randomStr + fileType;
        // 上传到hsp
        String fid = "";
        try {
            fid = HspUtil.fileUpload(File2byte(file), hspFileName, hspPath);
        } catch (Exception e) {
            logger.info(e.getMessage(), e);
        }
        return fid;
    }

    /**
     * 文件转byte
     *
     * @param file
     * @return
     */
    public static byte[] File2byte(File file) {
        byte[] buffer = null;
        try {
            FileInputStream fis = new FileInputStream(file);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] b = new byte[1024];
            int n;
            while ((n = fis.read(b)) != -1) {
                bos.write(b, 0, n);
            }
            fis.close();
            bos.close();
            buffer = bos.toByteArray();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return buffer;
    }

    /**
     * created by zhanghui12
     * hsp上传文件
     *
     * @param buffer
     * @param hspFileName
     * @param hspPath
     * @return
     */
    public static String fileUpload(byte[] buffer, String hspFileName, String hspPath) {
        logger.info("HspUtil fileUpload begin,target file:{}/{}", hspPath, hspFileName);
        String fid = "";
        try {
            boolean dirCreateResult = hspDirCreate(hspPath);
            if (dirCreateResult) {
                HSPClient hspClient = new HSPClient(hspConfig);
                NetFile netfile = new NetFile(hspClient);
                if (!netfile.CreateByName(hspPath + "/" + hspFileName, buffer.length)) {
                    logger.error("[HspUtil fileUpload()-netfile.CreateByName()] fail");
                } else {
                    logger.info("HspUtil fileUpload create file success");
                    String origFid = netfile.GetFid();
                    boolean result = netfile.Write(buffer);
                    logger.info("[HspUtil fileUpload-netfile.Write()] result:{} ", result);
                    if (true == result) {
                        fid = origFid;
                    }
                }
            }
        } catch (Exception e) {
            logger.error("HspUtil fileUpload exception: " + e.getMessage(), e);
        }
        logger.info("HspUtil fileUpload finished");
        return fid;
    }

    /**
     * Created by zhanghui12
     * 创建目录
     *
     * @param finalPath
     * @return
     */
    public static boolean hspDirCreate(String finalPath) {
        logger.info("HSP create dir begin,dir={}", finalPath);
        String[] paths = null;
        boolean flag = false;
        try {
            DirCountResult dirResult = hspClient.dirCount(finalPath);
            if (HspRetCodeEnum.ERROR_DIR_EXISTS.toCode() == dirResult.retcode) {
                logger.info("hspClient.dirCreate,path:{} already exist ", finalPath);
            } else {
                paths = finalPath.substring(1).split("/");//配置文件配置的路径前面都有个/,所以substring(1)
                String pathInHsp = "";
                for (String strPath : Arrays.asList(paths)) {
                    pathInHsp = pathInHsp + "/" + strPath;
                    DirCountResult dirCountResult = hspClient.dirCount(pathInHsp);
                    logger.info("hspClient.dirCount,request:{}, response:{} ", pathInHsp, GsonUtil.getInstance().toJson(dirCountResult));
                    if (HspRetCodeEnum.ERROR_DIR_NOTEXISTS.toCode() == dirCountResult.retcode) {//-30表示 目录不存在
                        int retcode = hspClient.dirCreate(pathInHsp, HspDirRightsEnum.EXTENDS_PARENT.toCode());
                        logger.info("hspClient.dirCreate,request:{}, response:{} ", pathInHsp, retcode);
                        if (HspRetCodeEnum.SUCCESS.toCode() != retcode) {
                            return flag = false;
                        }
                    }
                }
            }
            return flag = true;
        } catch (Exception e) {
            flag = false;
            logger.error(e.getMessage(), e);
        } finally {
            logger.info("HSP create dir={}, success={}", finalPath, flag);
            return flag;
        }
    }

    /**
     * created by zhanghui12
     * 根据fid获取url
     *
     * @param fid
     * @param validMinute
     * @param filename    不能为空
     * @return
     */
    public static String getUrl(String fid, int validMinute, String filename) {
        logger.info("HSP getUrl by fid,fid={}", fid);
        String url = "";
        try {
            url = hspClient.getUrl(fid, validMinute, filename);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        } finally {
            logger.info("HSP getUrl by fid finished,fid={}, url={}", fid, url);
            return url;
        }
    }

    /**
     * 根据fid读取文件
     *
     * @param fileId
     * @return
     */
    public static byte[] readFile(String fileId) {
        logger.info("read file by fid,fid:{}", fileId);
        byte buffer[] = null;
        try {
            NetFile netfile = new NetFile(hspClient);
            if (netfile.Open(fileId, false)) {
                int readlen = 0;
                do { //大文件需要分多次读，一次最多读1M
                    byte buf[] = new byte[1024 * 1024]; //最大1M，填充 Buf
                    int offset = 0;        // Buf的偏移量
                    int len = buf.length;  //要读出的长度
                    readlen = netfile.Read(buf, offset, len);
                    int bufLen = buffer == null ? 0 : buffer.length;
                    byte[] bufferTem = new byte[readlen + bufLen];
                    if (buffer != null && buffer.length > 0) {
                        System.arraycopy(buffer, 0, bufferTem, 0, bufLen);
                    }
                    System.arraycopy(buf, 0, bufferTem, bufLen, readlen);
                    buffer = bufferTem;
                } while (readlen > 0 && !netfile.IsEof());
            }
        } catch (Exception e) {
            logger.error("read file by fid error" + e.getMessage(), e);
        }
        logger.info("read file by fid finished,fid:{}", fileId);
        return buffer;
    }

    public static NetFile getNetFile() {
        logger.info("getNetFile");
        NetFile netfile = new NetFile(hspClient);
        return netfile;
    }

    /**
     * 删除文件
     *
     * @param fid
     */
    public static void deleteFile(String fid) {
        logger.info("delete file fid:{}", fid);
        try {
            hspClient.delete(fid);
        } catch (Exception e) {
            logger.error("delete file error," + e.getMessage(), e);
        }
        logger.info("delete file finish:{}", fid);
    }

}
