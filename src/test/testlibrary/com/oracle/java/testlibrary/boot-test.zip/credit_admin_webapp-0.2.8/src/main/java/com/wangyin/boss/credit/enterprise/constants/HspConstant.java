package com.wangyin.boss.credit.enterprise.constants;
/** 
* @desciption : hsp常量类
* @author : yangjinlin@jd.com
* @date ：2017年7月25日 下午9:34:18 
* @version 1.0 
* @return  */
public class HspConstant {
	
	/*---------------------  HSP文件系统       start    -------------------*/
	/**
	 * 文件系统的连接串
	 */
	public static final String HSP_CONNECT_STRING = "hsp.connect.string";
	/**
	 * 用户ID：征信门户
	 */
	public static final String HSP_PORTAL_APPID = "hsp.portal.appid";
	/**
	 * 用户密码：征信门户
	 */
	public static final String HSP_PORTAL_APPPWD = "hsp.portal.apppwd";
	/**
	 * http server域名
	 */
	public static final String HSP_HTTPSERVER_URL = "hsp.httpserver.url";

	/**
	 * mini文件在hsp上的路径
	 */
	public static final String HSP_PORTAL_MINI_PATH = "hsp.portal.mini.path";
	/**
	 * 标准信用报告在hsp上的路径
	 */
	public static final String HSP_PORTAL_STANDARD_REPORT_PATH = "hsp.portal.standard.report.path";
	/**
	 * 导出数据参数在hsp上的路径
	 */
	public static final String HSP_BATCH_DERIVE_DATA_PATH = "hsp.portal.batch.derive.data.path";
	/*---------------------  HSP文件系统       end    -------------------*/
	
}
