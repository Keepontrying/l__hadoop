package com.wangyin.boss.credit.admin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wangyin.boss.credit.admin.dao.CreditChangeRecordMapper;
import com.wangyin.boss.credit.admin.entity.CreditChangeRecord;
import com.wangyin.boss.credit.admin.service.CreditChangeRecordService;

@Service
public class CreditChangeRecordServiceImpl implements CreditChangeRecordService {
	@Autowired
	CreditChangeRecordMapper creditChangeRecordMapper;

	@Override
	public int insertRecord(CreditChangeRecord creditChangeRecord) {
		return creditChangeRecordMapper.insert(creditChangeRecord);
	}

	@Override
	public List<CreditChangeRecord> selectCredChanRecdsByConfigId(Integer configId) {
		return creditChangeRecordMapper.selectCredChanRecdsByConfigId(configId);
	}

}
