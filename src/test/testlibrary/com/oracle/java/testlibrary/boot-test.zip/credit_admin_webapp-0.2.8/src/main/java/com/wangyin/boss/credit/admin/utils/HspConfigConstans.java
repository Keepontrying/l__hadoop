package com.wangyin.boss.credit.admin.utils;
/** 
* @desciption : 文件系统HSP配置参数常量
* @author : yangjinlin@jd.com
* @date ：2017年3月21日 下午9:15:26 
* @version 1.0 
* @return  */
public class HspConfigConstans {

	public static final String HSP_CONNECTSTRING = "connectstring";
	
	/**
	 * 使用前需申请appid
	 */
	public static final String HSP_APPID= "appid";
	
	/**
	 * 使用前需申请apppwd
	 */
	public static final String HSP_APPPWD = "apppwd";
	
	public static final String HSP_HTTPSERVERURL = "httpServerUrl";
	
	
}
