package com.wangyin.boss.credit.admin.dao;

import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditMerchantAccount;

@SqlMapper
@Component
public interface CreditMerchantAccountMapper {

	String selectAccountNo(CreditMerchantAccount creditMerchantAccount);
	
}