package com.wangyin.boss.credit.admin.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditRoster;

@SqlMapper
@Component
public interface CreditRosterMapper {

	List<CreditRoster> selectByParam(CreditRoster creditRoster);

	int selectCountByParam(CreditRoster selectCountByParam);

	String selectByMerchantId(CreditRoster creditRoster);

	List<CreditRoster> selectInfoByMerchantId(CreditRoster creditRoster);

	int deleteByRosterId(CreditRoster creditRoster);

	int insert(CreditRoster creditRoster);

}
