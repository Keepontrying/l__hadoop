package com.wangyin.boss.credit.admin.controller;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jd.jr.boss.credit.domain.common.entity.CreditCallTimesGather;
import com.jd.jr.boss.credit.facade.authen.api.CreditVipStatisticFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.CallTimesGatherQueryParam;
import com.wangyin.boss.credit.admin.entity.*;
import com.wangyin.operation.beans.UploadFile;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.wangyin.boss.credit.admin.beans.param.CreditVipEnterpriseQueryParam;
import com.wangyin.boss.credit.admin.beans.param.CreditVipMerchantQueryParam;
import com.wangyin.boss.credit.admin.enums.CreditMerchantStatusEnum;
import com.wangyin.boss.credit.admin.enums.CreditMerchantTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditVipMonitorStatusEnum;
import com.wangyin.boss.credit.admin.enums.CreditVipStatusEnum;
import com.wangyin.boss.credit.admin.enums.MerchantAuditEnum;
import com.wangyin.boss.credit.admin.service.CreditMerchantService;
import com.wangyin.boss.credit.admin.service.CreditVipService;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : vip控制类
* @author : yangjinlin@jd.com
* @date ：2017年6月28日 下午3:44:00 
* @version 1.0 
* @return  */

@Controller
@RequestMapping("/creditVip")
public class CreditVipController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CreditVipController.class);
	
	@Autowired
	CreditVipService creditVipService;
	@Autowired 
	private CreditMerchantService creditMerchantService;//征信商户接口类

	/**
	 * 查询vip商户信息  分页
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryVipMerchant.do")
	public Map<String, Object> doQueryVipMerchant(@RequestParam Map<String, String> map, CreditVipMerchantQueryParam queryParam) {
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			if (StringUtils.isNotBlank(queryParam.getStartModifiedDateStr())) {
				queryParam.setStartModifiedDateStr(queryParam.getStartModifiedDateStr() + " 00:00:00");
			}
			if (StringUtils.isNotBlank(queryParam.getEndModifiedDateStr())) {
				queryParam.setEndModifiedDateStr(queryParam.getEndModifiedDateStr() + " 23:59:59");
			}

			CreditPage<CreditVip> resultPage= creditVipService.selectVipMerchantPageByParam(queryParam);
            List<CreditVip> resultList=resultPage.getRows();

            for(CreditVip cv : resultList){
            	if( null == cv){
            		continue;
            	}
                List<CreditProductSecond> vipProductSecondList = creditVipService.selectProductSecondWithoutBlack(cv.getMerchantId());
            	if(CollectionUtils.isEmpty(vipProductSecondList)){
                    cv.setProductName("暂无");
                    continue;
                }
                ArrayList<String> productNameList = new ArrayList<String>();
                for(CreditProductSecond cps : vipProductSecondList){
                    if(productNameList.contains(cps.getProductName())){
                        continue;
                    }else{
                        productNameList.add(cps.getProductName());
                    }
                }
				cv.setProductName(productNameList.toString().replace("[", "").replace("]", ""));
            }
            Long count=resultPage.getTotal();
            resultMap.put("rows", resultList);
            resultMap.put("total", count);
		} catch (Exception e) {
			LOGGER.error("doQueryVipMerchant exception ", e);
			resultMap.put("rows", new ArrayList<CreditContract>());
			resultMap.put("total", 0);
		}
		return resultMap;
	}


	/**
	 * 进入VIP企业列表
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toEnterpriseListPage.view")
	public Map<String, String> toPage(@RequestParam Map<String, String> map,String merchantNo,String merchantName) {
		map.put("merchantNo",merchantNo);
		map.put("merchantName",merchantName);
		return map;
	}
	/**
	 * 查询VIP企业 分页
	 */
	@RequestMapping("doQueryVipEnterprise.do")
	@ResponseBody
	public Map<String, Object> doQueryVipEnterprise(@RequestParam Map<String, String> map, CreditVipEnterpriseQueryParam queryParam) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("rows", new ArrayList<CreditContract>());
		resultMap.put("total", 0);
		try {
			if (StringUtils.isNotBlank(queryParam.getStartModifiedDateStr())) {
				queryParam.setStartModifiedDateStr(queryParam.getStartModifiedDateStr() + " 00:00:00");
			}
			if (StringUtils.isNotBlank(queryParam.getEndModifiedDateStr())) {
				queryParam.setEndModifiedDateStr(queryParam.getEndModifiedDateStr() + " 23:59:59");
			}
			CreditPage<CreditVipTask> resultPage = creditVipService.selectVipTaskPageByParam(queryParam);
			List<CreditVipTask> resultList=resultPage.getRows();
			Long count=resultPage.getTotal();
			resultMap.put("rows", resultList);
			resultMap.put("total", count);
		}catch (Exception e){
			LOGGER.error("doQueryVipEnterprise exception",e);
		}
		return resultMap;
	}

    /**
     * 开通、关停 vip商户监控状态
     * @param map
     * @param creditVip
     * @param user
     * @return
     */
	@ResponseBody
	@RequestMapping("doModifyVipMerchantMonitorStatus.do")
	public Map<String, Object> doModifyVipMerchantMonitorStatus(@RequestParam Map<String, Object> map,
			CreditVip creditVip, String user) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");
		
		String operaUserName = null;
		try {
			LOGGER.error("user : " + GsonUtil.getInstance().toJson(user));
			operaUserName = getLoginRealName(user);
		} catch (Exception e) {
			LOGGER.error("getLoginRealName() exception , ", e);
			operaUserName = "error";
		}
		String remark = map.containsKey("remarks") ? String.valueOf(map.get("remarks")) : "未获取到相应备注信息!";
		try {
			String[] vipIds = String.valueOf(map.get("vipIds")).split(",");
			if(vipIds.length == 0){
				resultMap.put("success", false);
				resultMap.put("message", "操作有误，请重新操作!");
			}else{
				creditVip.setModifier(operaUserName);
				creditVip.setRemarks(remark);
				creditVip.setMonitorStatus(String.valueOf(map.get("monitorStatus")));
				creditVip.setVipIds(Arrays.asList(vipIds));
				int monitorStatusUpdate = creditVipService.batchModifyVipMerchantMonitorStatus(creditVip);
				LOGGER.error("batchModifyVipMerchantMonitorStatus SUCCESS , updateCounts:{}", monitorStatusUpdate);
			}
		} catch (Exception e) {
			LOGGER.error("batchModifyVipMerchantMonitorStatus exception : ", e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
		}
		
		return resultMap;
	}
	
	/**
	 * 校验商户号并根据商户号自动获取商户名称
	 * @param map 传特殊参数用
	 * @param merchantNo 商户号
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doValidMerchanInStatusType.do")
	public Map<String, Object> doValidMerchanInStatusType(@RequestParam Map<String, Object> map, String merchantNo){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "查询成功");
		try {
			if(StringUtils.isBlank(map.get("merchantNo").toString())){
				resultMap.put("success", false);
				resultMap.put("message", "系统异常！");
				return resultMap;
			}
			CreditMerchant creditMerchant = new CreditMerchant();
			creditMerchant.setMerchantNo(merchantNo);
			creditMerchant.setMerchantTypeList(Arrays.asList((CreditMerchantTypeEnum.ENTERPRISE.toName()+","+CreditMerchantTypeEnum.ALL.toName()).substring(0).split(",")));
			
			creditMerchant.setMerchantStatus(CreditMerchantStatusEnum.OPEN.toName());
			List<CreditMerchant> mhList = creditMerchantService.queryMerchantListByParam(creditMerchant);
			if(CollectionUtils.isEmpty(mhList) || mhList.get(0).getMerchantType().equals(CreditTypeEnum.PERSON.toName())){
				resultMap.put("success", false);
				resultMap.put("message", "该商户不是可用的企业征信商户");
			}else if(StringUtils.isBlank(mhList.get(0).getAuditStatus())){
				resultMap.put("success", false);
				resultMap.put("message", "该商户尚未被业务审核通过");
			}else if(!mhList.get(0).getAuditStatus().equals(MerchantAuditEnum.PASS_BUSINESS.getCode())){
				resultMap.put("success", false);
				resultMap.put("message", "该商户尚未被业务审核通过");
			}else{
				resultMap.put("merchantName", mhList.get(0).getMerchantName());
				resultMap.put("merchantId", mhList.get(0).getMerchantId());
			}
			
		} catch (Exception e) {
			LOGGER.error(" doValidMerchanInStatusType exception :", e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
			return resultMap;
		}
		
		return resultMap;
	} 
	
	/**
	 * 创建vip商户信息
	 * @param map
	 * @param creditVip
	 * @param user
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doCreateVipMerchant.do")
	public Map<String, Object> doCreateVipMerchant(@RequestParam Map<String, String> map, CreditVip creditVip, String user) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "操作失败");
		
		try {
			String userName = null;
			try {
				userName = getLoginRealName(user);
			} catch (Exception e) {
				LOGGER.error("getLoginRealName() exception , ", e);
				userName = "error";
			}
			creditVip.setMonitorStatus(CreditVipMonitorStatusEnum.VIP_MONITOR_OPEN.getCode());
			creditVip.setVipStatus(CreditVipStatusEnum.VIP_OPEN.getCode());
			creditVip.setCreator(userName);
			creditVip.setCreatedDate(new Date());
			creditVip.setModifier(userName);
			creditVip.setModifiedDate(new Date());
			creditVip.setMonitorStart(new Date());
			if(StringUtil.isBlank(String.valueOf(map.get("triggerTimeList")))){
				resultMap.put("success", false);
				resultMap.put("message", " 操作失败，请选择监控日期");
				return resultMap;
			}
			String[] triggerTimes = String.valueOf(map.get("triggerTimeList")).split(",");
			creditVip.setTriggerTimes(Arrays.asList(triggerTimes));
			resultMap = paramsCheck(creditVip, resultMap);
			
			if("false".equals(resultMap.get("checkResultFlag").toString())){
				return resultMap;
			}
			CreditVip cv = creditVipService.selectByMerchantId(creditVip.getMerchantId());
			if( null == cv ){//根据merchantId查询vip商户
				Integer count = creditVipService.insertVipMerchant(creditVip);
				if( null != count){
					resultMap.put("success", true);
					resultMap.put("message", "操作成功");
				}else{
					resultMap.put("success", false);
					resultMap.put("message", "操作失败");
				}
			}else{
				resultMap.put("success", false);
				resultMap.put("message", " 操作失败，该商户已是VIP商户");
			}
			
		} catch (Exception e) {
			LOGGER.error(" doCreateVipMerchant exception :", e);
			resultMap.put("success", false);
			resultMap.put("message", "操作异常");
		}
		
		return resultMap;
	}
	
	/**
	 * 参数校验
	 * @param creditVip
	 * @param resultMap
	 * @return
	 */
	private Map<String, Object> paramsCheck(CreditVip creditVip, Map<String, Object> resultMap) {
		if(StringUtils.isEmpty(creditVip.getMerchantId().toString())){
			resultMap.put("checkResultFlag", false);
			resultMap.put("message", " 操作失败，");
			return resultMap;
		}
		if(CollectionUtils.isEmpty(creditVip.getTriggerTimes())){
			resultMap.put("checkResultFlag", false);
			resultMap.put("message", " 操作失败，请选择监控日期");
			return resultMap;
		}
		resultMap.put("checkResultFlag", true);
		resultMap.put("message", " 操作成功");
		return resultMap;
	}
	
	/**
	 * 跳转至编辑vip商户页
	 * @param map
	 * @param vipId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toEditVipMerchant.do")
	public Map<String, Object> toEditVipMerchant(@RequestParam Map<String, Object> map,Integer vipId) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		if(null == vipId){
			resultMap.put("success", false);
			resultMap.put("message", "系统异常！");
			return resultMap;
		}
		CreditVip creditVip = new CreditVip();
		creditVip.setVipId(vipId);
		List<CreditVip> creditVipList = creditVipService.selectCreditVipByPrm(creditVip);
		if(CollectionUtils.isEmpty(creditVipList)){
			resultMap.put("success", false);
			resultMap.put("message", "系统异常！");
			return resultMap;
		}
		resultMap.put("creditVipMerchant", creditVipList.get(0));
		return resultMap;
	}
	
	/**
	 * vip商户修改提交
	 * @param map
	 * @param creditVip
	 * @param user
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doEditVipMerchant.do")
	public Map<String, Object> doEditVipMerchant(@RequestParam Map<String, String> map, CreditVip creditVip, String user) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "操作失败");
		
		try {
			String userName = null;
			try {
				userName = getLoginRealName(user);
			} catch (Exception e) {
				LOGGER.error("getLoginRealName() exception , ", e);
				userName = "error";
			}
			creditVip.setCreator(userName);
			creditVip.setCreatedDate(new Date());
			creditVip.setModifier(userName);
			creditVip.setModifiedDate(new Date());
			creditVip.setRemarks("修改vip监控周期:" + creditVip.getRemarks());
			if(StringUtil.isBlank(String.valueOf(map.get("triggerTimeList")))){
				resultMap.put("checkResultFlag", false);
				resultMap.put("message", " 操作失败，请选择监控日期");
				return resultMap;
			}
			String[] triggerTimes = String.valueOf(map.get("triggerTimeList")).split(",");
			creditVip.setTriggerTimes(Arrays.asList(triggerTimes));
			if(CollectionUtils.isEmpty(creditVip.getTriggerTimes())){
				resultMap.put("checkResultFlag", false);
				resultMap.put("message", " 操作失败，请选择监控日期");
				return resultMap;
			}
			if( null != creditVip.getVipId()){//根据merchantId查询vip商户
				Integer count = creditVipService.updateVipMerchant(creditVip);
				if( null != count){
					resultMap.put("success", true);
					resultMap.put("message", "操作成功");
				}else{
					resultMap.put("success", false);
					resultMap.put("message", "操作失败");
				}
			}else{
				resultMap.put("success", false);
				resultMap.put("message", " 操作失败，该商户已是VIP商户");
			}
			
		} catch (Exception e) {
			LOGGER.error(" doCreateVipMerchant exception :", e);
			resultMap.put("success", false);
			resultMap.put("message", "操作异常");
		}
		
		return resultMap;
	}


}
