package com.wangyin.boss.credit.admin.publicSentiment;

import com.wangyin.boss.credit.enterprise.beans.CrawlerJob;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResultsQueryParam;
import com.wangyin.boss.credit.enterprise.beans.CrawlerWord;
import com.wangyin.boss.credit.enterprise.dao.CrawlerJobMapper;
import com.wangyin.operation.utils.GsonUtil;
import org.joda.time.DateTime;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2018/11/27
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class CrawlerJobMapperTest {

    @Resource
    private CrawlerJobMapper jobMapper;

    @Test
    public void insertJob() {
        String jobName = "测试任务";
        byte category = 0;
        String url = "www.baidu.com";
        String urlCode = "baidu";

        CrawlerJob job = new CrawlerJob();
        job.setName(jobName);
        job.setCategory(category);
        job.setTargetUrl(url);
        job.setTargetUrlCode(urlCode);
        jobMapper.insert(job);
        CrawlerWord word1 = new CrawlerWord();
        word1.setWord("缴获");
        word1.setWeight(8);
        word1.setGroupId(1L);
        word1.setJobId(job.getId());
        CrawlerWord word2 = new CrawlerWord();
        word2.setWord("跑路");
        word2.setWeight(2);
        word2.setGroupId(1L);
        word2.setJobId(job.getId());
        jobMapper.insertWord(word1);
        jobMapper.insertWord(word2);
    }

    @Test
    public void updateJob() {
        String jobName = "啷里格啷";
        byte category = 0;
        String url = "www.baidu.com";
        String urlCode = "baidu";

        CrawlerJob job = new CrawlerJob();
        job.setId(18L);
        job.setName(jobName);
        job.setCategory(category);
        job.setTargetUrl(url);
        job.setTargetUrlCode(urlCode);
        jobMapper.update(job);
    }

    @Test
    public void delJob() {
        jobMapper.delete(18L);
    }

    @Test
    public void queryJob() {
        String jobName = "";
        String word = "";
        String urlCode = "";
        byte category = 0;
        Integer weight1 = null;
        Integer weight2 = null;
        CrawlerJobResultsQueryParam param = new CrawlerJobResultsQueryParam();
        param.setName(jobName);
        param.setWord(word);
        param.setTargetUrlCode(urlCode);
        param.setCategory(category);
        param.setJobWeight1(weight1);
        param.setJobWeight2(weight2);
        param.setStart(1);
        param.setLimit(10);
        param.setCurrent(1);
        System.out.println(GsonUtil.getInstance().toJson(jobMapper.query(param)));
    }

    @Test
    public void count() {
//        byte category = 1;
//        String jobName = "基因fei 编辑";
        CrawlerJobResultsQueryParam param = new CrawlerJobResultsQueryParam();
//        param.setName(jobName);
//        param.setCategory(category);
        param.setWord("阿里");
        System.out.println(jobMapper.query(param));
    }

    @Test
    public void queryList() {
        CrawlerJobResultsQueryParam param = new CrawlerJobResultsQueryParam();
        param.setTime1(DateTime.now().minusDays(1).toDate());
        param.setTime2(DateTime.now().toDate());
        param.setCategory((byte)0);
        System.out.println(GsonUtil.getInstance().toJson( jobMapper.query(param)));
    }
}
