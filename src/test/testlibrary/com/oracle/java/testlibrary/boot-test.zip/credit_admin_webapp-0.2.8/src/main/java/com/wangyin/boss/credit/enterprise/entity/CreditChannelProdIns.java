package com.wangyin.boss.credit.enterprise.entity;

import java.io.Serializable;

public class CreditChannelProdIns implements Serializable {
    private static final long serialVersionUID = 4660326619312563078L;
    private String insCode;
    private String insName;
    private String userPin;
    private String merchantNo;

    public CreditChannelProdIns() {
    }

    public String getInsCode() {
        return insCode;
    }

    public void setInsCode(String insCode) {
        this.insCode = insCode;
    }

    public String getInsName() {
        return insName;
    }

    public void setInsName(String insName) {
        this.insName = insName;
    }

    public String getUserPin() {
        return userPin;
    }

    public void setUserPin(String userPin) {
        this.userPin = userPin;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof CreditChnMerchantInsRel) {
            CreditChnMerchantInsRel rel = (CreditChnMerchantInsRel) obj;
            return insCode.equalsIgnoreCase(rel.getInsCode());
        }
        return false;
    }
}

