package com.wangyin.boss.credit.enterprise.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wangyin.admin.frame.utils.JSONUtils;
import com.wangyin.boss.credit.enterprise.beans.CreditChnProdInsInfo;
import com.wangyin.boss.credit.enterprise.entity.CreditChnProd;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.jr.boss.credit.domain.common.entity.CreditMerchantChannelGather;
import com.jd.jr.boss.credit.domain.common.enums.CreditChannelInterfaceCodeInsCodeEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditChannelReturnStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditChannelTypeEnum;
import com.jd.jr.boss.credit.facade.authen.beans.param.MerchantChannelQueryParam;
import com.wangyin.boss.credit.admin.controller.BaseController;
import com.wangyin.boss.credit.admin.entity.CreditChnProdIns;
import com.wangyin.boss.credit.admin.enums.CreditOpenStatusEnum;
import com.wangyin.boss.credit.enterprise.beans.CreditChannelProdInsQueryParam;
import com.wangyin.boss.credit.enterprise.beans.MerchantChannel;
import com.wangyin.boss.credit.enterprise.dao.CreditChnProdInsMapper;
import com.wangyin.boss.credit.enterprise.service.CreditMerchantChannelService;
import com.wangyin.operation.beans.UserModel;
import com.wangyin.operation.common.enums.ResponseMessage;

/**
 * Description: 商户渠道
 * User: yangjinlin@jd.com
 * Date: 2018/5/15 21:31
 * Version: 1.0
 */
@Controller
@RequestMapping("/merchantChannel")
public class CreditMerchantChannelController  extends BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreditMerchantChannelController.class);

    @Autowired
    CreditMerchantChannelService creditMerchantChannelService;
    
    @Autowired
    CreditChnProdInsMapper creditChnProdInsMapper;

    /**
     * 查询汇总过的商户渠道信息 分页
     * @param map
     * @param queryParam
     * @return
     */
    @ResponseBody
    @RequestMapping("doQueryMerchantChannelGatherList.biz")
    public Map<String, Object> doQueryMerchantChannelGatherList(MerchantChannelQueryParam queryParam) {
        Map<String,Object> resultMap = new HashMap<String, Object>();
        List<CreditMerchantChannelGather> merchantChannelGatherList = new ArrayList<CreditMerchantChannelGather>();
        int  count = 0 ;
        resultMap.put("rows", merchantChannelGatherList);
        resultMap.put("total", count);
        resultMap.put("successCount", 0);
        resultMap.put("failCount", 0);

        try {

            count = creditMerchantChannelService.queryMerchantChannelGatherListCount(queryParam);
            if(count != 0){
                merchantChannelGatherList = creditMerchantChannelService.queryMerchantChannelGatherList(queryParam);
                for(CreditMerchantChannelGather merchantChannel : merchantChannelGatherList){
                    merchantChannel.setChannel(CreditChannelTypeEnum.enumValueOf(merchantChannel.getChannel()).toDescription());
                    merchantChannel.setReturnStatus(CreditChannelReturnStatusEnum.enumValueOf(merchantChannel.getReturnStatus()).toDescription());
                    merchantChannel.setInterfaceCode(CreditChannelInterfaceCodeInsCodeEnum.enumValueOfInterfaceCode(merchantChannel.getInterfaceCode()).getDescription());
                }
            }
            int merchantChannelCount = creditMerchantChannelService.selectCountMerchantChannelGatherByParam(queryParam);
            resultMap.put("rows", merchantChannelGatherList);
            resultMap.put("total", merchantChannelCount);

            if(CreditChannelReturnStatusEnum.SUCCESS.toName().equals(queryParam.getReturnStatus())){
                int successCount = creditMerchantChannelService.selectCountMerchantChannelGatherByParam(queryParam);
                resultMap.put("successCount", successCount);
                resultMap.put("failCount", 0);
            }else if(CreditChannelReturnStatusEnum.FAIL.toName().equals(queryParam.getReturnStatus())){
                resultMap.put("successCount", 0);
                int failCount = creditMerchantChannelService.selectCountMerchantChannelGatherByParam(queryParam);
                resultMap.put("failCount", failCount);
            }else{
                queryParam.setReturnStatus(CreditChannelReturnStatusEnum.SUCCESS.toName());
                int successCount = creditMerchantChannelService.selectCountMerchantChannelGatherByParam(queryParam);
                resultMap.put("successCount", successCount);
                queryParam.setReturnStatus(CreditChannelReturnStatusEnum.FAIL.toName());
                int failCount = creditMerchantChannelService.selectCountMerchantChannelGatherByParam(queryParam);
                resultMap.put("failCount", failCount);
            }
        } catch (Exception e) {
            LOGGER.error("doQueryMerchantChannelList failed, {}", e);
            resultMap.put("rows", new ArrayList<CreditMerchantChannelGather>());
            resultMap.put("total", 0);
            resultMap.put("successCount", 0);
            resultMap.put("failCount", 0);
        }
        resultMap.put("rows", merchantChannelGatherList);
        resultMap.put("total", count);

        return resultMap;
    }

    @ResponseBody
    @RequestMapping("doQueryChannelProdInsList.biz")
    public Map<String, Object> doQueryChannelProdInsList(@RequestParam Map<String, String> map, CreditChannelProdInsQueryParam queryParam) {
        Map<String,Object> resultMap = new HashMap<String, Object>();

        List<CreditChnProdInsInfo> chnProdInsInfos = new ArrayList<CreditChnProdInsInfo>();
        int  count = 0 ;
        resultMap.put("rows", chnProdInsInfos);
        resultMap.put("total", count);
        try {

            count = creditMerchantChannelService.queryChannelProdInsListCount(queryParam);
            if(count != 0){
                List<CreditChnProdIns> chnProdInsList = creditMerchantChannelService.queryChannelProdInsList(queryParam);
                for(CreditChnProdIns chnProdIns : chnProdInsList){
                    chnProdIns.setInsStatus(CreditOpenStatusEnum.enumValueOf(chnProdIns.getInsStatus()).toDescription());

                    CreditChnProdInsInfo insInfo = new CreditChnProdInsInfo();
                    BeanUtils.copyProperties(chnProdIns, insInfo);
                    CreditChnProd param  = new CreditChnProd();
                    param.setProductCode(chnProdIns.getProductCode());
                    List<CreditChnProd> prods = creditMerchantChannelService.queryAllChannelProdList(param);
                    if (!CollectionUtils.isEmpty(prods)) {
                        insInfo.setProductName(prods.get(0).getProductName());
                    }
                    chnProdInsInfos.add(insInfo);
                }
            }
        } catch (Exception e) {
            LOGGER.error("doQueryChannelProdInsList failed, {}", e);
            resultMap.put("rows", new ArrayList<CreditChnProdInsInfo>());
            resultMap.put("total", 0);
        }
        resultMap.put("rows", chnProdInsInfos);
        resultMap.put("total", count);

        return resultMap;
    }


    @ResponseBody
    @RequestMapping("saveOrUpdate.biz")
    public Map<String, Object> saveOrUpdateChannelProd(CreditChannelProdInsQueryParam queryParam,
                                                       @RequestParam(value = "user", required = false) UserModel userModel){

        Map<String, Object> result = new HashMap<>();

        String userName = "tourist";
        if (!org.springframework.util.StringUtils.isEmpty(userModel)) {
            userName = userModel.getUserName();
        }
        try {
            int i = creditMerchantChannelService.saveOrUpdate(queryParam, userName);
            if (i > 0) {
                result.put("success", true);
                result.put("message", ResponseMessage.SUCCESS.getDesc());
            }else{
                result.put("success", false);
                result.put("message", ResponseMessage.DATABASE_ERROR.getDesc());
            }
        } catch (Exception e) {
            LOGGER.error("saveOrUpdateChannelProd failed, {}", e);
            result.put("success", false);
            result.put("message", ResponseMessage.SYSTEM_ERROR.getDesc());
        }
        return result;
    }

    @ResponseBody
    @RequestMapping("doQueryMerchantChannelList.biz")
    public Map<String, Object> doQueryMerchantChannelList(@RequestParam Map<String, String> map, CreditChannelProdInsQueryParam queryParam) {
    	LOGGER.info("数据路由机制查询开始>>");
        Map<String,Object> resultMap = new HashMap<String, Object>();
        List<MerchantChannel> queryMerchantChannel  = new ArrayList<MerchantChannel>();
        int  count = 0 ;
        resultMap.put("rows", queryMerchantChannel);
        resultMap.put("total", count);
        try {

            count = creditChnProdInsMapper.queryMerchantChannelCount(queryParam);
            if(count != 0){
            	queryMerchantChannel = creditChnProdInsMapper.queryMerchantChannel(queryParam);
                for(MerchantChannel mc : queryMerchantChannel){
                	String insCode = mc.getInsCode();
                	if(StringUtils.isNoneBlank(insCode)) {
                		String[] split = insCode.split(",");
                		List<String> pa = new ArrayList<String>();
                		Collections.addAll(pa, split);
                		List<String> queryInsName = creditChnProdInsMapper.queryInsName(pa);
                		if(CollectionUtils.isNotEmpty(queryInsName)) {
                			StringBuilder sb = new StringBuilder();
                			for(int i=0;i<queryInsName.size();i++) {
                				sb.append(queryInsName.get(i));
                				if(i != queryInsName.size()-1) {
                					sb.append("，");
                				}
                			}
                			mc.setInsName(sb.toString());
                		}
                	}
                }
            }
        } catch (Exception e) {
            LOGGER.error("doQueryMerchantChannelList@查询出错", e);
            resultMap.put("rows", new ArrayList<CreditChnProdIns>());
            resultMap.put("total", 0);
        }
        resultMap.put("rows", queryMerchantChannel);
        resultMap.put("total", count);

        return resultMap;
    }


    @ResponseBody
    @RequestMapping("sortMerchantChannelWeight.biz")
    public Map<String, Object> sortMerchantChannel(@RequestParam Map<String, Object> start,
                                                   @RequestParam(value = "user", required = false) UserModel userModel) {
        LOGGER.info("数据路由机制更新操作>>"+JSONUtils.toJSON(start));
        String userName = "tourist";
        if (!org.springframework.util.StringUtils.isEmpty(userModel)) {
            userName = userModel.getUserName();
        }
        return creditMerchantChannelService.sortMerchantChannel(start, userName);
    }


}
