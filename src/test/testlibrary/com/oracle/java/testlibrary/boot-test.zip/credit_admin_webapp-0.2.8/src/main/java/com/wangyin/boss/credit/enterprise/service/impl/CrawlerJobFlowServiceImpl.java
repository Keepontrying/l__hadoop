package com.wangyin.boss.credit.enterprise.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.jdjr.fmq.client.producer.MessageProducer;
import com.jdjr.fmq.common.exception.JMQException;
import com.jdjr.fmq.common.message.Message;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJob;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobFlow;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResultsQueryParam;
import com.wangyin.boss.credit.enterprise.dao.CrawlerJobFlowMapper;
import com.wangyin.boss.credit.enterprise.service.CrawlerJobFlowService;
import com.wangyin.operation.utils.GsonUtil;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author huangzhiqiang
 * @data 2018/11/28
 */
@Service
public class CrawlerJobFlowServiceImpl implements CrawlerJobFlowService {
    private Logger logger = LoggerFactory.getLogger(CrawlerJobFlowServiceImpl.class);

    private static final String SYSTEM_CODE = "ENTCAE";
    private static final String SYSTEM_KEY = "3c184d6006882904b2e0f1ba9478745f1de73963";

    @Resource
    private CrawlerJobFlowMapper mapper;
    @Resource
    @Qualifier("producer")
    private MessageProducer producer;

    @Async
    @Override
    public String addJobFlow(CrawlerJob job) {
        logger.info("异步发起任务开始。。。");
        String postStr = GsonUtil.getInstance().toJson(job);
        CrawlerJobFlow flow = new CrawlerJobFlow();
        String jobNo = "LS" + System.currentTimeMillis() + job.getId();
        flow.setJobNo(jobNo);
        flow.setPostStr(postStr);
        flow.setCategory(job.getCategory());
        mapper.insertOrUpadte(flow);
        sendMsg(flow);
        return jobNo;
    }

    @Override
    public Long addOrUpdate(CrawlerJobFlow flow) {
        mapper.insertOrUpadte(flow);
        return flow.getId();
    }

    @Override
    public List<CrawlerJobFlow> queryList(CrawlerJobResultsQueryParam param) {
        return mapper.queryList(param);
    }

    private void sendMsg(CrawlerJobFlow flow) {
        Map<String, Object> map = new HashMap<>();
        map.put("systemCode", SYSTEM_CODE);
        map.put("systemKey", SYSTEM_KEY);
        map.put("sendTime", DateTime.now().toString("yyyy-MM-dd HH:mm:ss"));
        map.put("param", flow);
        Message message = new Message("bc_public_sentiment_request", JSONObject.toJSONString(map), UUID.randomUUID().toString());
        try {
            producer.send(message);
        } catch (JMQException e) {
            logger.error("爬虫任务流水发送异常" + e.getMessage(), e);
        }
        logger.info("爬虫任务流水发送成功:" + JSONObject.toJSONString(map));
    }
}
