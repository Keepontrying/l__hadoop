package com.wangyin.boss.credit.admin.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wangyin.boss.credit.admin.dao.CreditCostMapper;
import com.wangyin.boss.credit.admin.entity.CreditCost;
import com.wangyin.boss.credit.admin.enums.CostStatusEnum;
import com.wangyin.boss.credit.admin.service.CreditCostService;
import com.wangyin.boss.credit.admin.utils.DateUtil;

/**
 * 
 * @author wyhaozhihong
 *
 */
@Service
public class CreditCostServiceImpl implements CreditCostService {
	
	@Autowired
	CreditCostMapper creditCostMapper;

	@Override
	public List<CreditCost> selectByParam(CreditCost creditCost) {
		return creditCostMapper.selectByParam(creditCost);
	}

	@Override
	public int selectCountByParam(CreditCost creditCost) {
		return creditCostMapper.selectCountByParam(creditCost);
	}

	@Override
	public int insert(CreditCost creditCost) throws ParseException {
		/*更新该服务项的上一条的成本配置失效日期为本条生效日期-1*/
		CreditCost creditCost1 = new CreditCost();
		creditCost1.setCostStatus(CostStatusEnum.HISTORY.getCode());
		creditCost1.setFinishDate(DateUtil.getBeforeDay(new SimpleDateFormat("yyyy-MM-dd").parse(creditCost.getStartDateStr())));
		creditCost1.setProductId(creditCost.getProductId());
		creditCostMapper.update(creditCost1);
		return creditCostMapper.insert(creditCost);
	}

	@Override
	public int update(CreditCost creditCost) {
		return creditCostMapper.update(creditCost);
	}

}
