package com.wangyin.boss.credit.enterprise.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.facade.authen.api.CreditBatchDataFacade;
import com.jd.jr.boss.credit.facade.authen.beans.entity.JsfConfigBean;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchDataQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.BatchDataEntity;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.admin.frame.utils.JSONUtils;
import com.wangyin.boss.credit.admin.dao.CreditUserMapper;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.boss.credit.admin.utils.ExcelUtil;
import com.wangyin.boss.credit.enterprise.service.CreditBatchDeriveDataService;
import com.wangyin.boss.credit.enterprise.utils.HspUtil;
import com.wangyin.boss.credit.enterprise.utils.JSFGatewayUtil;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.operation.utils.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class CreditBatchDeriveDataServiceImpl implements CreditBatchDeriveDataService {

    private static Logger logger = LoggerFactory.getLogger(CreditBatchDeriveDataServiceImpl.class);

    @Autowired
    CreditBatchDataFacade creditBatchDataFacade;

    @Autowired
    CreditUserMapper creditUserMapper;

    @Override
    public boolean upload(Map<String, String> params, String filePath) {
        //解析excel
//        List<List<String>> paramList = excel(filePath);
        List<Map<String, Object>> paramList = analysisExcel(filePath,params.get("userPin"));
        if (CollectionUtils.isEmpty(paramList)) {
            logger.error("excel参数为空");
            return false;
        }
        //业务接口必传
        if (params.get("jsfId") == null) {
            logger.error("业务参数为空: jsfId");
            return false;
        }
        //调用上传
        CreditRequestParam<List<Map<String, Object>>> param = new CreditRequestParam<List<Map<String, Object>>>();
        param.setParam(paramList);
        param.setArg(params);
        param.setSystemId("credit_admin");
        try {
            CreditResponseData responseData = creditBatchDataFacade.uploadBatchDataParam(param);
            logger.info("上传跑批参数结果："+JSONUtils.toJSON(responseData));
            return responseData.isSuccess();
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return false;
    }

    @Override
    public Map<String, Object> exportDataList(BatchDataQueryParam map) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            CreditRequestParam<BatchDataQueryParam> param = new CreditRequestParam<BatchDataQueryParam>();
            param.setParam(map);
            CreditPage<BatchDataEntity> page =  creditBatchDataFacade.queryBatchExportData(param);
            if (page.isSuccess()) {
                for (BatchDataEntity entity : page.getRows()) {
                    if (StringUtil.isNotEmpty(entity.getParamUrl())) {
                        entity.setParamUrl(HspUtil.getUrl(entity.getParamUrl(),24*60,
                                DateUtil.getInstance(DateUtil.FORMAT8).format(new Date()))+".xlsx");
                    }
                    if (StringUtil.isNotEmpty(entity.getHspUrl())) {
                        entity.setHspUrl(HspUtil.getUrl(entity.getHspUrl(),24*60,entity.getMerchantNo()+".csv"));
                    }
                }
                resultMap.put("rows", page.getRows());
                resultMap.put("total", page.getTotal());
                resultMap.put("success", true);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            resultMap.put("rows", null);
            resultMap.put("total", 0);
            resultMap.put("success", false);
        }
        return resultMap;
    }

    @Override
    public Map<String, Object> queryJsfConfigList(JsfConfigBean jsfConfigBean) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            CreditRequestParam<JsfConfigBean> param = new CreditRequestParam<JsfConfigBean>();
            param.setParam(jsfConfigBean);

            CreditPage<JsfConfigBean> page = creditBatchDataFacade.queryJsfConfig(param);
            if (page.isSuccess()) {
                resultMap.put("rows", page.getRows());
                resultMap.put("total", page.getTotal());
                resultMap.put("success", true);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            resultMap.put("rows", null);
            resultMap.put("total", 0);
            resultMap.put("success", false);
        }
        return resultMap;
    }

    @Override
    public Map<String, Object> saveOrUpdateJsfConfig(JsfConfigBean jsfConfigBean) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            //校验非空参数
            if (StringUtil.isEmpty(jsfConfigBean.getInterfaceId())
                    || StringUtil.isEmpty(jsfConfigBean.getMethodName())
                    || StringUtil.isEmpty(jsfConfigBean.getArgType())
                    || StringUtil.isEmpty(jsfConfigBean.getAlias())
                    || StringUtil.isEmpty(jsfConfigBean.getArgTemplate())
                    || StringUtil.isEmpty(jsfConfigBean.getErp())
                    || StringUtil.isEmpty(jsfConfigBean.getRemark())
                    ) {
                resultMap.put("msg", ResponseMessage.PARAM_IS_REQUIRED.getDesc());
                resultMap.put("success", false);
                return resultMap;
            }
            CreditRequestParam<JsfConfigBean> param = new CreditRequestParam<JsfConfigBean>();
            param.setParam(jsfConfigBean);

            CreditResponseData responseData = creditBatchDataFacade.uploadJsfConfig(param);
            resultMap.put("msg", responseData.getMessage());
            resultMap.put("success", responseData.isSuccess());
        } catch (Exception e) {
            logger.error(e.getMessage());
            resultMap.put("msg", ResponseMessage.SYSTEM_ERROR.getDesc());
            resultMap.put("success", false);
        }
        return resultMap;
    }

    @Override
    public Map<String, Object> queryResult(Map<String,Object> jsfConfigBean) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            CreditRequestParam<Map<String, Object>> param = new CreditRequestParam<Map<String, Object>>();
            param.setParam(jsfConfigBean);

            CreditResponseData responseData = creditBatchDataFacade.jsfResult(param);
            resultMap.put("msg", responseData.getMessage());
            resultMap.put("success", responseData.isSuccess());
            resultMap.put("data", responseData.getData());
        } catch (Exception e) {
            logger.error(e.getMessage());
            resultMap.put("msg", ResponseMessage.SYSTEM_ERROR.getDesc());
            resultMap.put("success", false);
        }
        return resultMap;
    }

    @Override
    public Map<String, Object> queryJsfConfig(JsfConfigBean jsfConfigBean) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            CreditRequestParam<JsfConfigBean> param = new CreditRequestParam<JsfConfigBean>();
            param.setParam(jsfConfigBean);

            CreditPage<JsfConfigBean> page = creditBatchDataFacade.queryJsfConfig(param);
            if (page.isSuccess() && !CollectionUtils.isEmpty(page.getRows())) {
                JsfConfigBean configBean = page.getRows().get(0);

                resultMap = org.apache.commons.beanutils.BeanUtils.describe(configBean);
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return resultMap;
    }

    @Override
    public Map<String, Object> exportOutsideData(Map<String, Object> map) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            CreditRequestParam<Map<String, Object>> param = new CreditRequestParam<Map<String, Object>>();
            param.setParam(map);

            CreditResponseData page = creditBatchDataFacade.exportOutsideData(param);
            resultMap.put("message", page.getMessage());
            resultMap.put("success", page.isSuccess());
        } catch (Exception e) {
            logger.error(e.getMessage());
            resultMap.put("success", false);
            resultMap.put("message", ResponseMessage.SYSTEM_ERROR.getDesc());
        }
        return resultMap;
    }

    @Override
    public Map<String, Object> getJsfConfigInterfaceId(JsfConfigBean jsfConfigBean) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            CreditRequestParam<JsfConfigBean> param = new CreditRequestParam<JsfConfigBean>();
            param.setParam(jsfConfigBean);

            CreditResponseData<List<String>> page = creditBatchDataFacade.getJsfConfigInterfaceId(param);
            resultMap.put("message", page.getMessage());
            resultMap.put("success", page.isSuccess());
            resultMap.put("data", page.getData());
        } catch (Exception e) {
            logger.error(e.getMessage());
            resultMap.put("success", false);
            resultMap.put("message", ResponseMessage.SYSTEM_ERROR.getDesc());
        }
        return resultMap;
    }

    @Override
    public Map<String, Object> getMethodList(JsfConfigBean jsfConfigBean) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            CreditRequestParam<JsfConfigBean> param = new CreditRequestParam<JsfConfigBean>();
            param.setParam(jsfConfigBean);

            CreditResponseData<List<JsfConfigBean>> page = creditBatchDataFacade.getMethodList(param);
            if (page.isSuccess()) {
                for (JsfConfigBean entity : page.getData()) {
                    if(!StringUtil.isEmpty(entity.getTemplateFid())){
                        entity.setTemplateFid(HspUtil.getUrl(entity.getTemplateFid(),0,
                                entity.getId()+".xlsx"));
                    }

                }
                resultMap.put("message", page.getMessage());
                resultMap.put("success", page.isSuccess());
                resultMap.put("data", page.getData());
            }

        } catch (Exception e) {
            logger.error(e.getMessage());
            resultMap.put("success", false);
            resultMap.put("message", ResponseMessage.SYSTEM_ERROR.getDesc());
        }
        return resultMap;
    }

    @Override
    public Map<String, Object> getInterfaceDetailInf(Map<String, Object> param) {
        Map<String, Object> result = new HashMap<>();
        Object ifaceName = param.get("interfaceName");
        Object alias = param.get("alias");
        if (StringUtils.isEmpty(ifaceName) || StringUtils.isEmpty(alias)) {
            result.put("success", false);
            result.put("message", "接口名称或者别名为空");
            return result;
        }
        JSONArray methodList = JSFGatewayUtil.methodList(String.valueOf(ifaceName), String.valueOf(alias));
        if (methodList == null) {
            result.put("success", false);
            result.put("message", "JSF接口调用异常");
            return result;
        }

        result.put("success", true);
        result.put("message", ResponseMessage.SUCCESS.getDesc());
        result.put("data", methodList);
        return result;
    }

    @Override
    public Map<String, Object> getAliasByInterfaceId(Map<String, Object> param) {
        Map<String, Object> result = new HashMap<>();
        Object ifaceName = param.get("interfaceName");
        if (StringUtils.isEmpty(ifaceName)) {
            result.put("success", false);
            result.put("message", "接口名称为空");
            return result;
        }
        List<String> jsonArray = JSFGatewayUtil.aliasList(String.valueOf(ifaceName));
        if (jsonArray == null) {
            result.put("success", false);
            result.put("message", "JSF接口调用异常");
            return result;
        }

        result.put("success", true);
        result.put("message", ResponseMessage.SUCCESS.getDesc());
        result.put("data", jsonArray);
        return result;
    }

    @Override
    public Map<String, Object> getUserInfo(String id,String userPin) {
        Map<String, Object> result = new HashMap<>();
        try {
            if (!StringUtils.isEmpty(userPin)) {
                CreditUser creditUser = new CreditUser();
                creditUser.setUserPin(userPin);
                List<CreditUser> users = creditUserMapper.selectCreditUserByParam(creditUser);
                if (!CollectionUtils.isEmpty(users)) {
                    creditUser = users.get(0);
                    result.put("loginName", creditUser.getLoginName());
                    result.put("merchantNo", creditUser.getMerchantNo());
                    result.put("merchantName", creditUser.getMerchantName());
                    result.put("userPin", creditUser.getUserPin());

                    result.put("success", true);
                    result.put("message", ResponseMessage.SUCCESS.getDesc());
                    return result;
                }
            } else if (!StringUtils.isEmpty(id)) {
                CreditRequestParam<JsfConfigBean> param = new CreditRequestParam<JsfConfigBean>();
                JsfConfigBean jsfConfigBean = new JsfConfigBean();
                jsfConfigBean.setId(Long.valueOf(id));
                param.setParam(jsfConfigBean);
                CreditPage<JsfConfigBean> creditPage = creditBatchDataFacade.queryJsfConfig(param);
                if (creditPage.isSuccess()) {
                    List<JsfConfigBean> rows = creditPage.getRows();
                    if (!CollectionUtils.isEmpty(rows)) {
                        JsfConfigBean configBean = rows.get(0);
                        String argTemplate = configBean.getArgTemplate();
                        JSONObject jsonObject = JSONObject.parseObject(argTemplate);
                        if (jsonObject.containsKey("systemId")) {
                            String target = jsonObject.getString("systemId");
                            CreditUser creditUser = new CreditUser();
                            creditUser.setUserPin(target);
                            List<CreditUser> users = creditUserMapper.selectCreditUserByParam(creditUser);
                            if (!CollectionUtils.isEmpty(users)) {
                                creditUser = users.get(0);
                                result.put("loginName", creditUser.getLoginName());
                                result.put("merchantNo", creditUser.getMerchantNo());
                                result.put("merchantName", creditUser.getMerchantName());
                                result.put("userPin", creditUser.getUserPin());

                                result.put("success", true);
                                result.put("message", ResponseMessage.SUCCESS.getDesc());
                                return result;
                            }
                        }
                    }
                    result.put("success", false);
                    result.put("message", "接口参数配置错误");
                } else {
                    logger.error(creditPage.getMessage());
                    result.put("success", false);
                    result.put("message", "JSF接口调用异常");
                    return result;
                }
            }else{
                result.put("success", false);
                result.put("message", ResponseMessage.PARAM_IS_REQUIRED.getDesc());
            }

        } catch (Exception e) {
            logger.error(e.getMessage());
            result.put("success", false);
            result.put("message", ResponseMessage.SYSTEM_ERROR.getDesc());
        }

        return result;
    }

    @Deprecated
    private List<List<String>> excel(String filePath) {
        try {
            InputStream inputStream = new FileInputStream(filePath);
            List<List<String>> rowdata = new ExcelUtil().read(inputStream, false, 0);
            if (CollectionUtils.isEmpty(rowdata)) {
                throw new IllegalArgumentException("excel参数为空");
            }

            return rowdata;
        } catch (FileNotFoundException e) {
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return null;
    }

    @Deprecated
    private List<Map<String,Object>> analysisExcel(String filePath, String userPin) {
        List<Map<String, Object>> params = new ArrayList<Map<String, Object>>();
        try {
            InputStream inputStream = new FileInputStream(filePath);
            List<List<String>> rowdata = new ExcelUtil().read(inputStream, false, 0);
            if (CollectionUtils.isEmpty(rowdata)) {
                throw new IllegalArgumentException("excel参数为空");
            }
            List<String> keys = rowdata.get(0);
            //过滤中文注解
            keys=filterReqDesc(keys);
            for (int j = 1; j < rowdata.size(); j++) {
                List<String> rows = rowdata.get(j);
                ConcurrentHashMap<String, Object> key_value = new ConcurrentHashMap<String, Object>();
                for (int i = 0; i < keys.size(); i++) {
                    key_value.put(keys.get(i), rows.get(i));
                }
                key_value.put("systemId", userPin);
                params.add(convert(key_value));
            }

        } catch (FileNotFoundException e) {
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return params;
    }

    private static List<String> filterReqDesc(List<String> keys) {
        List<String> k = new ArrayList<>();
        for (int i = 0; i < keys.size(); i++) {
            String key = keys.get(i);
            if (key.indexOf("(")>0) {
                key = key.substring(0, key.indexOf("("));
                k.add(key);
            }else{
                k.add(key);
            }
        }
        return k;
    }


    public static Map<String,Object> convert(ConcurrentHashMap<String,Object> data){
        Set<String> keys = data.keySet();
        for (String key : keys) {
            String[] k = key.split("\\.");
            if (k.length > 1) {//嵌套数据结构
                String newK = k[0];
                ConcurrentHashMap<String, Object> newV = new ConcurrentHashMap<String, Object>();
                if (data.get(newK) != null) {
                    newV = (ConcurrentHashMap<String, Object>) data.get(newK);
                }
                newV.put(key.substring(key.indexOf(".")+1), data.get(key));
                convert(newV);
                data.put(newK, newV);
                data.remove(key);
            }
        }
        return data;
    }

    public static void main(String[] args) {
        ConcurrentHashMap<String, Object> data = new ConcurrentHashMap<String, Object>();

        /*data.put("f1", 1);
        data.put("f6.f2", "test1.2");
        data.put("f7.f2.f3(中国人民)", "test123");
        data.put("f8.f4(测试)", "ts4");
        data.put("f6.f4", "ts4");

        System.err.println(JSONUtils.toJSON(data));

        convert(data);

        System.err.println(JSONUtils.toJSON(data));*/

        List<String> keys = new ArrayList<>();
        keys.add("f7.f2.f3(中国人民)");
        keys.add("f7.f3(中国人民)");
        keys.add("f7");

        filterReqDesc(keys);
        System.err.println(keys);
    }
}
