package com.wangyin.boss.credit.enterprise.entity;

import java.io.Serializable;

/** 
* @desciption : 标准报告时间对应价格实体类
* @author : yangjinlin@jd.com
* @date ：2018年6月4日 下午9:29:27
* @version 1.0 
* @return  */
public class StandardReportComplPriceModel implements Serializable {

	private static final long serialVersionUID = -1601389859274357979L;
	/**
	 * 时效对应价格
	 */
	private Integer complePrice;
	private Integer freeTimes;
	private String complePriceStr;//时效价格value
	private Integer completionType;//响应时间类型
	private String priceTypeType;//计价方式
	private Integer strategyId;//计费策略id
	private Integer upperLimit;//上线次数
	

	public Integer getComplePrice() {
		return complePrice;
	}

	public void setComplePrice(Integer complePrice) {
		this.complePrice = complePrice;
	}

	public String getComplePriceStr() {
		return complePriceStr;
	}

	public void setComplePriceStr(String complePriceStr) {
		this.complePriceStr = complePriceStr;
	}

	public Integer getCompletionType() {
		return completionType;
	}

	public void setCompletionType(Integer completionType) {
		this.completionType = completionType;
	}

	public String getPriceTypeType() {
		return priceTypeType;
	}

	public void setPriceTypeType(String priceTypeType) {
		this.priceTypeType = priceTypeType;
	}

	public Integer getStrategyId() {
		return strategyId;
	}

	public void setStrategyId(Integer strategyId) {
		this.strategyId = strategyId;
	}

	public Integer getFreeTimes() {
		return freeTimes;
	}

	public void setFreeTimes(Integer freeTimes) {
		this.freeTimes = freeTimes;
	}

	public Integer getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(Integer upperLimit) {
		this.upperLimit = upperLimit;
	}
}
