package com.wangyin.boss.credit.admin.service;

import java.util.List;

import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrderMain;
import com.jd.jr.boss.credit.facade.authen.beans.param.SubOrderQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.wangyin.boss.credit.admin.beans.param.OrderPageQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditContract;

/**
 * Created by anmeng on 2017/3/24.
 */
public interface CreditOrderService {
    /**
     * 生成订单
     * @param orderMain
     */
    public void createOffLineOrder(CreditOrderMain orderMain);

    /**
     * 分页查询订单列表
     * @param queryParam
     * @return
     */
    public CreditPage<CreditOrderMain> queryCreditOrderMain(OrderPageQueryParam queryParam);

    /**
     * 查询订单详情
     * @param orderMainId
     * @return
     */
    public CreditOrderMain queryOrderMainDetail(Integer orderMainId);

    /**
     * 确认打款
     * @param orderMainId
     */
    public void confirmReceive(Integer orderMainId);


    /**
     * 查询商户订单信息
     * @param requestParam
     * @return
     */
    public CreditPage<CreditOrder> querySubOrder(SubOrderQueryParam requestParam);

    /**
     * 查询合同下的订单明细信息
     * @param orderQueryParam
     * @return
     */
	public List<CreditOrder> queryContractOrder(SubOrderQueryParam orderQueryParam);

	/**
	 * 根据订单信息查询合同信息
	 * @param requestParam
	 * @return
	 */
	public List<CreditContract> queryContractByOrderInfo(SubOrderQueryParam requestParam);

}
