package com.wangyin.boss.credit.admin.service;

import java.util.List;
import java.util.Set;

import com.jd.jr.boss.credit.facade.site.api.dto.request.payment.PaymentReceiptPushRequest;
import com.wangyin.boss.credit.admin.entity.PaymentOrder;
import com.wangyin.operation.common.beans.ResponseData;

/** 
* @desciption : 缴费单接口类
* @author : yangjinlin@jd.com
* @date ：2017年1月3日 下午4:29:27 
* @version 1.0 
* @return  */
public interface PaymentOrderService {

	/**
	 * 多条件查询包量缴费单---分页
	 * @param paymentOrder
	 * @return
	 */
	List<PaymentOrder> selectPackageByParam(PaymentOrder paymentOrder);

	/**
	 * 多条件查询包量缴费单总数目---分页
	 * @param paymentOrder
	 * @return
	 */
	int selectPackageCountByParam(PaymentOrder paymentOrder);

	/**
	 * 多条件查询单笔缴费单--- 分页
	 * @param paymentOrder
	 * @return
	 */
	List<PaymentOrder> selectSingleByParam(PaymentOrder paymentOrder);

	/**
	 * 多条件查询单笔缴费单总数目---分页
	 * @param paymentOrder
	 * @return
	 */
	int selectSingleCountByParam(PaymentOrder paymentOrder);

	/**
	 * 推送缴费单
	 * @param paymentReceiptPushRequest
	 * @return
	 * @throws Exception 
	 */
	ResponseData pushPaymentOrder(PaymentReceiptPushRequest paymentReceiptPushRequest) throws Exception;

}
