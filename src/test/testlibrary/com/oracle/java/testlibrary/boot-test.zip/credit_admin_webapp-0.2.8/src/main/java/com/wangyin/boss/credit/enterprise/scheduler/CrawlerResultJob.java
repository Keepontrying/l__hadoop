package com.wangyin.boss.credit.enterprise.scheduler;

import com.jd.jr.boss.credit.gateway.unc.constance.GatewayUncConstance;
import com.jd.jr.boss.credit.gateway.unc.facade.email.GatewayUncEmailFacade;
import com.jd.jr.boss.credit.gateway.unc.utils.FlowNoUtils;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobFlow;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResultsQueryParam;
import com.wangyin.boss.credit.enterprise.service.CrawlerJobFlowService;
import com.wangyin.operation.utils.GsonUtil;
import com.wangyin.schedule.client.job.ScheduleContext;
import com.wangyin.schedule.client.job.ScheduleFlowTask;
import com.wangyin.schedule.client.job.TaskResult;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author huangzhiqiang
 * @data 2018/12/3
 */
@Component
public class CrawlerResultJob implements ScheduleFlowTask {
    private Logger logger = LoggerFactory.getLogger(CrawlerResultJob.class);

    @Resource
    private CrawlerJobFlowService flowService;
    @Resource
    private GatewayUncEmailFacade gatewayUncEmailFacade;

    private static final String SUBJECT = "京东企业信用舆情监控预警";
    private static final String TEMPLATE_CODE = "credit_public_sentiment";

    @Override
    public TaskResult doTask(ScheduleContext scheduleContext) throws Exception {
        logger.info("定向舆情通知开始");
        Map<String, String> parameters = scheduleContext.getParameters();
        CrawlerJobResultsQueryParam param = new CrawlerJobResultsQueryParam();
        Byte jobCategory = Byte.valueOf(parameters.get("jobCategory"));
        Date time1;
        Date time2;
        String timeStr1;
        String timeStr2;
        String category = "定时";
        String downloadUrl = ConfigUtil.getString("credit.publish.sentiment.url");

        if (jobCategory == 0) {
            DateTimeFormatter format = DateTimeFormat.forPattern("yyyy-MM-dd HH");
            timeStr1 = DateTime.now().minusHours(1).toString(format);
            time1 = DateTime.parse(timeStr1, format).toDate();
            timeStr2 = DateTime.now().toString(format);
            time2 = DateTime.now().toDate();DateTime.parse(timeStr2, format).toDate();
            param.setCategory((byte) 0);
            category = "实时";
            downloadUrl = downloadUrl + "/http/credit/publicSentiment/exportXlsx.download?category=0&timeStr1=" + timeStr1 + "&timeStr2=" + timeStr2;
        } else {
            DateTimeFormatter format = DateTimeFormat.forPattern("yyyy-MM-dd");
            timeStr1 = DateTime.now().minusDays(1).toString(format);
            time1 = DateTime.parse(timeStr1, format).toDate();
            timeStr2 = DateTime.now().toString(format);
            time2 = DateTime.parse(timeStr2, format).toDate();
            param.setCategory((byte) 1);
            downloadUrl = downloadUrl + "/http/credit/publicSentiment/exportXlsx.download?category=1&timeStr1=" + timeStr1 + "&timeStr2=" + timeStr2;
        }
        param.setState((byte) 1);
        param.setTime1(time1);
        param.setTime2(time2);
        logger.info("定向舆情监控通知入参：" + GsonUtil.getInstance().toJson(param));
        List<CrawlerJobFlow> flows = flowService.queryList(param);
        if (flows != null && flows.size() > 0) {
            boolean flag = sendMailByUnc(flows.size(), downloadUrl, category);
            if (flag) {
                for (CrawlerJobFlow flow : flows) {
                    flow.setState((byte) 2);
                    flowService.addOrUpdate(flow);
                }
            }
        }
        return TaskResult.SUCCESS_BLANK;
    }

    private boolean sendMailByUnc(Integer var1, String downloadUrl, String category) {
        boolean sendMailResult;
        Map<String, Object> uncParamsMap = new HashMap<>();
        uncParamsMap.put("category", category);
        uncParamsMap.put("var1", var1);
        uncParamsMap.put("downloadUrl", downloadUrl);
        String bizNo = FlowNoUtils.createFlowNo("admin");
        logger.info("【bizNo】: " + bizNo);
        String appCode = ConfigUtil.getString(GatewayUncConstance.UNC_CLIENT_APPCODE);
        String receiver = ConfigUtil.getString("unc.client.public.sentiment.receiver");
        logger.info("【定向舆情预警监控】: " + GsonUtil.getInstance().toJson(uncParamsMap));
        try {
            sendMailResult = gatewayUncEmailFacade.sendMailByUnc(receiver, SUBJECT, bizNo,
                    uncParamsMap, TEMPLATE_CODE, appCode);
            if (!sendMailResult) {
                logger.info("定向舆情预警监控邮件发送失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("【定向舆情预警监控邮件发送失败失败!】");
        }
        return sendMailResult;
    }

}
