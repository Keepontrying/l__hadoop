package com.wangyin.boss.credit.admin.entity;
/** 
* @desciption : 缴费单实体类
* @author : yangjinlin@jd.com
* @date ：2017年1月3日 下午3:44:19 
* @version 1.0 
* @return  */
public class PaymentOrder extends CreditProductStrategy {

	/**
	 * 合同编号
	 */
	private String contractNo;
	
	/**
     * 预付款
     */
    private Long advancePayment;
    
    /**
     * 合同状态
     */
    private String contractStatus;
    
    /*------展示字段--------*/
    /**
     * 预付款字符串格式
     */
    private String advancePaymentStr;
    /**
     * 是否推送缴费单标识  CAN_PUSH:可推送；CANNOT_PUSH：不可推送
     */
    private String pushPaymentOrderFlag;
    /**
     * 计费预览
     */
    private String chargeOverView;
    /**
     * 产品id合并统称
     */
    private String productIdUnion;
    /**
     * 产品名称合并统称
     */
    private String productNameUnion;
    /**
     * 各计费策略的备注统称
     */
    private String remarkses;

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public Long getAdvancePayment() {
		return advancePayment;
	}

	public void setAdvancePayment(Long advancePayment) {
		this.advancePayment = advancePayment;
	}

	public String getAdvancePaymentStr() {
		return advancePaymentStr;
	}

	public void setAdvancePaymentStr(String advancePaymentStr) {
		this.advancePaymentStr = advancePaymentStr;
	}

	public String getPushPaymentOrderFlag() {
		return pushPaymentOrderFlag;
	}

	public void setPushPaymentOrderFlag(String pushPaymentOrderFlag) {
		this.pushPaymentOrderFlag = pushPaymentOrderFlag;
	}

	public String getChargeOverView() {
		return chargeOverView;
	}

	public void setChargeOverView(String chargeOverView) {
		this.chargeOverView = chargeOverView;
	}
	
	public String getProductIdUnion() {
		return productIdUnion;
	}

	public void setProductIdUnion(String productIdUnion) {
		this.productIdUnion = productIdUnion;
	}

	public String getProductNameUnion() {
		return productNameUnion;
	}

	public void setProductNameUnion(String productNameUnion) {
		this.productNameUnion = productNameUnion;
	}

	public String getRemarkses() {
		return remarkses;
	}

	public void setRemarkses(String remarkses) {
		this.remarkses = remarkses;
	}

	public String getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

}
