package com.wangyin.boss.credit.enterprise.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class T {
	public static void main(String[] args) {
		School sl = new School();
		sl.setName("京东大学");
		sl.setAddress("北京大兴区");
		sl.setStartYear(1921);
		sl.setIs211(true);
		
		Student s1 = new Student();
		s1.setAge("11");
		s1.setGrade("89");
		s1.setName("小明");
		s1.setNo("01");
		s1.setSex("男");
		Student s2 = new Student();
		s2.setAge("12");
		s2.setGrade("76");
		s2.setName("小红");
		s2.setNo("02");
		s2.setSex("女");
		
		Student s3 = new Student();
		s3.setAge("13");
		s3.setGrade("99");
		s3.setName("小强");
		s3.setNo("03");
		s3.setSex("男");
		
		Student s4 = new Student();
		s4.setAge("14");
		s4.setGrade("100");
		s4.setName("小丽");
		s4.setNo("04");
		s4.setSex("女");
		
		List<Student> l1= new ArrayList<Student>();
		l1.add(s1);
		l1.add(s2);
		List<Student> l2= new ArrayList<Student>();
		l2.add(s3);
		l2.add(s4);
		
		Class cls1 = new Class();
		cls1.setLevl("A");
		cls1.setManager("房志刚");
		cls1.setName("实验1班");
		cls1.setStudents(l1);
		
		Class cls2 = new Class();
		cls2.setLevl("B");
		cls2.setManager("张志鹏");
		cls2.setName("实验2班");
		cls2.setStudents(l2);
		
		Teacher t1 = new Teacher();
		t1.setName("刘老师");
		t1.setSex("男");
		t1.setSubject("语文");
		Teacher t2 = new Teacher();
		t2.setName("李老师");
		t2.setSex("女");
		t2.setSubject("数学");
		List<Teacher> lt = new ArrayList<Teacher>();
		lt.add(t1);
		lt.add(t2);
		
		Hospital hospital = new Hospital();
		hospital.setAddress("学校东门外往北50米");
		hospital.setLevel(3);
		hospital.setTel("010-88595230");
		
		
		List<Class> cl = new ArrayList<Class>();
		cl.add(cls1);
		cl.add(cls2);
		sl.setClasses(cl);
		sl.setTeachers(lt);
		sl.setHospital(hospital);
		
//		String str = "{\"charset\":\"UTF-8\",\"checkSign\":\"4E3BCD86288F85163A26E2524BE0C88D\",\"orderNo\":\"cd0c02f8-b83b-469d-b224-24acfaa5418e\",\"request\":\"西宁九通商贸有限公司\",\"result\":{\"links\":[{\"from\":\"51160923\",\"id\":\"162318749\",\"properties\":{\"condate\":\"\",\"conprop\":\"\",\"currency\":\"\",\"currencyDesc\":\"\",\"holderamt\":\"\",\"holderrto\":\"\",\"legal\":\"true\",\"position\":\"\",\"positionDesc\":\"\",\"sharestype\":\"\",\"subconam\":\"\"},\"to\":\"113984262\",\"type\":\"任职\"},{\"from\":\"51160923\",\"id\":\"50211499\",\"properties\":{\"condate\":\"2040-05-18\",\"conprop\":\"0.96666667\",\"currency\":\"156\",\"currencyDesc\":\"人民币元\",\"holderamt\":\"\",\"holderrto\":\"\",\"legal\":\"\",\"position\":\"\",\"positionDesc\":\"\",\"sharestype\":\"\",\"subconam\":\"29\"},\"to\":\"113984262\",\"type\":\"投资\"},{\"from\":\"51160923\",\"id\":\"131080715\",\"properties\":{\"condate\":\"\",\"conprop\":\"\",\"currency\":\"\",\"currencyDesc\":\"\",\"holderamt\":\"\",\"holderrto\":\"\",\"legal\":\"\",\"position\":\"432K\",\"positionDesc\":\"执行董事\",\"sharestype\":\"\",\"subconam\":\"\"},\"to\":\"113984262\",\"type\":\"任职\"}],\"nodes\":[{\"id\":\"51160923\",\"innode\":\"false\",\"name\":\"张小强\",\"properties\":{\"cgzb\":\"96.6667\",\"creditcode\":\"\",\"entstatus\":\"\",\"enttype\":\"\",\"esdate\":\"\",\"industryphy\":\"\",\"industryphyDesc\":\"null\",\"invtype\":\"\",\"invtypeDesc\":\"null\",\"isSyr\":\"true\",\"islist\":\"\",\"name\":\"张小强\",\"palgorithmid\":\"V1!N0d9ahgLvZwXF8rt8RDXBO5cFckLE+tU8G5xq+H+goaOm+8RSMH+NMXt89XqShkhGzoXATVVDFzX<n>nkzf4qwpRg==\",\"positionDesces\":\"执行董事\",\"regcap\":\"\",\"regcapcur\":\"\",\"regcapcurDesc\":\"\",\"regno\":\"\",\"syrType\":\"直接或间接控股,关键管理人员\"},\"type\":\"人员\"},{\"id\":\"113984262\",\"innode\":\"true\",\"name\":\"西宁九通商贸有限公司\",\"properties\":{\"cgzb\":\"\",\"creditcode\":\"91630104661922467M\",\"entstatus\":\"1\",\"enttype\":\"\",\"esdate\":\"2008-01-10\",\"industryphy\":\"F\",\"industryphyDesc\":\"批发和零售业\",\"invtype\":\"\",\"invtypeDesc\":\"null\",\"isSyr\":\"false\",\"islist\":\"0\",\"name\":\"西宁九通商贸有限公司\",\"palgorithmid\":\"\",\"positionDesces\":\"\",\"regcap\":\"30\",\"regcapcur\":\"156\",\"regcapcurDesc\":\"\",\"regno\":\"630104100000909\",\"syrType\":\"\"},\"type\":\"企业\"}]},\"resultCode\":\"SUCCESS\",\"resultMsg\":\"成功\",\"success\":true,\"time\":\"1541754586863\",\"tradeNo\":\"TRADE201811090509467735616093147\",\"version\":\"1.0\"}";
		String str ="{\"extend\":null,\"code\":\"SUCCESS\",\"data\":{\"baseData\":{\"industryName\":\"\",\"nonDealDays\":0,\"address\":\"河东区津塘路15号院内（天津市中铁会园饭店216室）\",\"province\":\"天津\",\"city\":\"\",\"taxRegNo\":\"91120102592906171Y\",\"firstInvoiceDate\":\"2014-12-02\",\"enterpriseName\":\"天津市力合创远科技发展有限公司\",\"industryCode\":\"\"},\"invoiceInfo\":[{\"month\":\"2018-10\",\"redNum\":\"1\",\"redAmount\":\"115655.70\",\"invalidNum\":\"2\",\"invalidAmount\":\"29700.00\",\"maxInvoiceAmount\":\"114804.00\",\"invoiceDays\":\"7\",\"actInvoiceDays\":\"6\",\"invoiceNum\":\"70\",\"invoiceAmount\":\"5736954.86\"},{\"month\":\"2018-09\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"6\",\"invalidAmount\":\"553723.78\",\"maxInvoiceAmount\":\"115655.70\",\"invoiceDays\":\"9\",\"actInvoiceDays\":\"9\",\"invoiceNum\":\"88\",\"invoiceAmount\":\"8369877.45\"},{\"month\":\"2018-08\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"2\",\"invalidAmount\":\"220951.40\",\"maxInvoiceAmount\":\"115881.62\",\"invoiceDays\":\"10\",\"actInvoiceDays\":\"10\",\"invoiceNum\":\"82\",\"invoiceAmount\":\"7868726.97\"},{\"month\":\"2018-07\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"2\",\"invalidAmount\":\"45633.78\",\"maxInvoiceAmount\":\"115218.00\",\"invoiceDays\":\"12\",\"actInvoiceDays\":\"12\",\"invoiceNum\":\"95\",\"invoiceAmount\":\"8831977.99\"},{\"month\":\"2018-06\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"2\",\"invalidAmount\":\"167311.65\",\"maxInvoiceAmount\":\"115791.00\",\"invoiceDays\":\"8\",\"actInvoiceDays\":\"8\",\"invoiceNum\":\"91\",\"invoiceAmount\":\"8696622.63\"},{\"month\":\"2018-05\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"2\",\"invalidAmount\":\"203642.00\",\"maxInvoiceAmount\":\"115749.70\",\"invoiceDays\":\"12\",\"actInvoiceDays\":\"12\",\"invoiceNum\":\"119\",\"invoiceAmount\":\"11528568.11\"},{\"month\":\"2018-04\",\"redNum\":\"5\",\"redAmount\":\"477840.65\",\"invalidNum\":\"0\",\"invalidAmount\":\"0.00\",\"maxInvoiceAmount\":\"116880.60\",\"invoiceDays\":\"13\",\"actInvoiceDays\":\"12\",\"invoiceNum\":\"125\",\"invoiceAmount\":\"10891339.45\"},{\"month\":\"2018-03\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"12\",\"invalidAmount\":\"1243380.50\",\"maxInvoiceAmount\":\"116747.40\",\"invoiceDays\":\"9\",\"actInvoiceDays\":\"9\",\"invoiceNum\":\"97\",\"invoiceAmount\":\"9084090.50\"},{\"month\":\"2018-02\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"0\",\"invalidAmount\":\"0.00\",\"maxInvoiceAmount\":\"115735.00\",\"invoiceDays\":\"7\",\"actInvoiceDays\":\"7\",\"invoiceNum\":\"63\",\"invoiceAmount\":\"5774482.24\"},{\"month\":\"2018-01\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"1\",\"invalidAmount\":\"106388.34\",\"maxInvoiceAmount\":\"116982.60\",\"invoiceDays\":\"13\",\"actInvoiceDays\":\"13\",\"invoiceNum\":\"89\",\"invoiceAmount\":\"8159002.54\"},{\"month\":\"2017-12\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"1\",\"invalidAmount\":\"108665.20\",\"maxInvoiceAmount\":\"116356.00\",\"invoiceDays\":\"11\",\"actInvoiceDays\":\"11\",\"invoiceNum\":\"86\",\"invoiceAmount\":\"7638064.87\"},{\"month\":\"2017-11\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"1\",\"invalidAmount\":\"50811.60\",\"maxInvoiceAmount\":\"116885.60\",\"invoiceDays\":\"11\",\"actInvoiceDays\":\"11\",\"invoiceNum\":\"80\",\"invoiceAmount\":\"7187771.45\"},{\"month\":\"2017-10\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"0\",\"invalidAmount\":\"0.00\",\"maxInvoiceAmount\":\"116808.00\",\"invoiceDays\":\"10\",\"actInvoiceDays\":\"10\",\"invoiceNum\":\"85\",\"invoiceAmount\":\"7829665.08\"},{\"month\":\"2017-09\",\"redNum\":\"1\",\"redAmount\":\"36406.00\",\"invalidNum\":\"5\",\"invalidAmount\":\"516387.38\",\"maxInvoiceAmount\":\"116547.00\",\"invoiceDays\":\"9\",\"actInvoiceDays\":\"9\",\"invoiceNum\":\"61\",\"invoiceAmount\":\"5606755.19\"},{\"month\":\"2017-08\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"0\",\"invalidAmount\":\"0.00\",\"maxInvoiceAmount\":\"116840.00\",\"invoiceDays\":\"8\",\"actInvoiceDays\":\"8\",\"invoiceNum\":\"79\",\"invoiceAmount\":\"6875034.10\"},{\"month\":\"2017-07\",\"redNum\":\"9\",\"redAmount\":\"716710.73\",\"invalidNum\":\"1\",\"invalidAmount\":\"73260.00\",\"maxInvoiceAmount\":\"116970.00\",\"invoiceDays\":\"8\",\"actInvoiceDays\":\"8\",\"invoiceNum\":\"80\",\"invoiceAmount\":\"5993156.12\"},{\"month\":\"2017-06\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"1\",\"invalidAmount\":\"111520.00\",\"maxInvoiceAmount\":\"116966.80\",\"invoiceDays\":\"5\",\"actInvoiceDays\":\"5\",\"invoiceNum\":\"45\",\"invoiceAmount\":\"4410552.18\"},{\"month\":\"2017-05\",\"redNum\":\"2\",\"redAmount\":\"233025.60\",\"invalidNum\":\"1\",\"invalidAmount\":\"94339.67\",\"maxInvoiceAmount\":\"116880.75\",\"invoiceDays\":\"10\",\"actInvoiceDays\":\"10\",\"invoiceNum\":\"55\",\"invoiceAmount\":\"3889718.34\"},{\"month\":\"2017-04\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"0\",\"invalidAmount\":\"0.00\",\"maxInvoiceAmount\":\"116910.00\",\"invoiceDays\":\"9\",\"actInvoiceDays\":\"9\",\"invoiceNum\":\"45\",\"invoiceAmount\":\"4117273.54\"},{\"month\":\"2017-03\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"0\",\"invalidAmount\":\"0.00\",\"maxInvoiceAmount\":\"111455.10\",\"invoiceDays\":\"15\",\"actInvoiceDays\":\"15\",\"invoiceNum\":\"54\",\"invoiceAmount\":\"4197299.75\"},{\"month\":\"2017-02\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"3\",\"invalidAmount\":\"179753.64\",\"maxInvoiceAmount\":\"116480.00\",\"invoiceDays\":\"8\",\"actInvoiceDays\":\"8\",\"invoiceNum\":\"28\",\"invoiceAmount\":\"2276262.11\"},{\"month\":\"2017-01\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"2\",\"invalidAmount\":\"12145.00\",\"maxInvoiceAmount\":\"116843.00\",\"invoiceDays\":\"7\",\"actInvoiceDays\":\"7\",\"invoiceNum\":\"28\",\"invoiceAmount\":\"2081292.45\"},{\"month\":\"2016-12\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"3\",\"invalidAmount\":\"206887.07\",\"maxInvoiceAmount\":\"109692.50\",\"invoiceDays\":\"6\",\"actInvoiceDays\":\"6\",\"invoiceNum\":\"28\",\"invoiceAmount\":\"1871627.74\"},{\"month\":\"2016-11\",\"redNum\":\"0\",\"redAmount\":\"0.00\",\"invalidNum\":\"3\",\"invalidAmount\":\"169124.30\",\"maxInvoiceAmount\":\"115850.00\",\"invoiceDays\":\"7\",\"actInvoiceDays\":\"7\",\"invoiceNum\":\"27\",\"invoiceAmount\":\"1742480.32\"}],\"customerSaleRegionList\":[{\"year\":\"2018\",\"rank\":1,\"invoiceAmount\":\"32302395.51\",\"invoiceAmountRatio\":39.43,\"invoiceNum\":348,\"invoiceNumRatio\":39.32,\"taxAuthCode\":\"120100\",\"taxAuthName\":\"天津市\"},{\"year\":\"2018\",\"rank\":2,\"invoiceAmount\":\"20035198.00\",\"invoiceAmountRatio\":24.46,\"invoiceNum\":203,\"invoiceNumRatio\":22.94,\"taxAuthCode\":\"130900\",\"taxAuthName\":\"河北-沧州市\"},{\"year\":\"2018\",\"rank\":3,\"invoiceAmount\":\"5858272.93\",\"invoiceAmountRatio\":7.15,\"invoiceNum\":59,\"invoiceNumRatio\":6.67,\"taxAuthCode\":\"130600\",\"taxAuthName\":\"河北-保定市\"},{\"year\":\"2018\",\"rank\":4,\"invoiceAmount\":\"3074530.13\",\"invoiceAmountRatio\":3.75,\"invoiceNum\":40,\"invoiceNumRatio\":4.52,\"taxAuthCode\":\"150200\",\"taxAuthName\":\"内蒙古-包头市\"},{\"year\":\"2018\",\"rank\":5,\"invoiceAmount\":\"2726747.90\",\"invoiceAmountRatio\":3.33,\"invoiceNum\":26,\"invoiceNumRatio\":2.94,\"taxAuthCode\":\"130200\",\"taxAuthName\":\"河北-唐山市\"},{\"year\":\"2018\",\"rank\":6,\"invoiceAmount\":\"2432224.92\",\"invoiceAmountRatio\":2.97,\"invoiceNum\":28,\"invoiceNumRatio\":3.16,\"taxAuthCode\":\"110100\",\"taxAuthName\":\"北京市\"},{\"year\":\"2018\",\"rank\":7,\"invoiceAmount\":\"1995697.50\",\"invoiceAmountRatio\":2.44,\"invoiceNum\":23,\"invoiceNumRatio\":2.6,\"taxAuthCode\":\"131000\",\"taxAuthName\":\"河北-廊坊市\"},{\"year\":\"2018\",\"rank\":8,\"invoiceAmount\":\"1654179.03\",\"invoiceAmountRatio\":2.02,\"invoiceNum\":18,\"invoiceNumRatio\":2.03,\"taxAuthCode\":\"210100\",\"taxAuthName\":\"辽宁-沈阳市\"},{\"year\":\"2018\",\"rank\":9,\"invoiceAmount\":\"1425232.40\",\"invoiceAmountRatio\":1.74,\"invoiceNum\":18,\"invoiceNumRatio\":2.03,\"taxAuthCode\":\"120200\",\"taxAuthName\":\"天津市\"},{\"year\":\"2018\",\"rank\":10,\"invoiceAmount\":\"1205138.82\",\"invoiceAmountRatio\":1.47,\"invoiceNum\":14,\"invoiceNumRatio\":1.58,\"taxAuthCode\":\"131100\",\"taxAuthName\":\"河北-衡水市\"},{\"year\":\"2018\",\"rank\":11,\"invoiceAmount\":\"779043.33\",\"invoiceAmountRatio\":0.95,\"invoiceNum\":8,\"invoiceNumRatio\":0.9,\"taxAuthCode\":\"110200\",\"taxAuthName\":\"北京市\"},{\"year\":\"2018\",\"rank\":12,\"invoiceAmount\":\"599590.20\",\"invoiceAmountRatio\":0.73,\"invoiceNum\":6,\"invoiceNumRatio\":0.68,\"taxAuthCode\":\"310000\",\"taxAuthName\":\"上海市\"},{\"year\":\"2018\",\"rank\":13,\"invoiceAmount\":\"418387.25\",\"invoiceAmountRatio\":0.51,\"invoiceNum\":4,\"invoiceNumRatio\":0.45,\"taxAuthCode\":\"130400\",\"taxAuthName\":\"河北-邯郸市\"},{\"year\":\"2018\",\"rank\":14,\"invoiceAmount\":\"398122.90\",\"invoiceAmountRatio\":0.49,\"invoiceNum\":4,\"invoiceNumRatio\":0.45,\"taxAuthCode\":\"331000\",\"taxAuthName\":\"浙江-台州市\"},{\"year\":\"2018\",\"rank\":15,\"invoiceAmount\":\"371274.38\",\"invoiceAmountRatio\":0.45,\"invoiceNum\":5,\"invoiceNumRatio\":0.56,\"taxAuthCode\":\"410100\",\"taxAuthName\":\"河南-郑州市\"},{\"year\":\"2018\",\"rank\":16,\"invoiceAmount\":\"366656.50\",\"invoiceAmountRatio\":0.45,\"invoiceNum\":4,\"invoiceNumRatio\":0.45,\"taxAuthCode\":\"210800\",\"taxAuthName\":\"辽宁-营口市\"},{\"year\":\"2018\",\"rank\":17,\"invoiceAmount\":\"366522.70\",\"invoiceAmountRatio\":0.45,\"invoiceNum\":6,\"invoiceNumRatio\":0.68,\"taxAuthCode\":\"310100\",\"taxAuthName\":\"上海市\"},{\"year\":\"2018\",\"rank\":18,\"invoiceAmount\":\"325420.98\",\"invoiceAmountRatio\":0.4,\"invoiceNum\":3,\"invoiceNumRatio\":0.34,\"taxAuthCode\":\"610000\",\"taxAuthName\":\"陕西\"},{\"year\":\"2018\",\"rank\":19,\"invoiceAmount\":\"162968.00\",\"invoiceAmountRatio\":0.2,\"invoiceNum\":2,\"invoiceNumRatio\":0.23,\"taxAuthCode\":\"410500\",\"taxAuthName\":\"河南-安阳市\"},{\"year\":\"2018\",\"rank\":20,\"invoiceAmount\":\"136060.55\",\"invoiceAmountRatio\":0.17,\"invoiceNum\":2,\"invoiceNumRatio\":0.23,\"taxAuthCode\":\"370600\",\"taxAuthName\":\"山东-烟台市\"},{\"year\":\"2018\",\"rank\":21,\"invoiceAmount\":\"29992.50\",\"invoiceAmountRatio\":0.04,\"invoiceNum\":1,\"invoiceNumRatio\":0.11,\"taxAuthCode\":\"230100\",\"taxAuthName\":\"黑龙江-哈尔滨市\"},{\"year\":\"2017\",\"rank\":1,\"invoiceAmount\":\"25335120.95\",\"invoiceAmountRatio\":41.56,\"invoiceNum\":275,\"invoiceNumRatio\":38.68,\"taxAuthCode\":\"120100\",\"taxAuthName\":\"天津市\"},{\"year\":\"2017\",\"rank\":2,\"invoiceAmount\":\"10096767.05\",\"invoiceAmountRatio\":16.56,\"invoiceNum\":125,\"invoiceNumRatio\":17.58,\"taxAuthCode\":\"130900\",\"taxAuthName\":\"河北-沧州市\"},{\"year\":\"2017\",\"rank\":3,\"invoiceAmount\":\"4738964.98\",\"invoiceAmountRatio\":7.77,\"invoiceNum\":72,\"invoiceNumRatio\":10.13,\"taxAuthCode\":\"130600\",\"taxAuthName\":\"河北-保定市\"},{\"year\":\"2017\",\"rank\":4,\"invoiceAmount\":\"4266255.41\",\"invoiceAmountRatio\":7,\"invoiceNum\":49,\"invoiceNumRatio\":6.89,\"taxAuthCode\":\"131000\",\"taxAuthName\":\"河北-廊坊市\"},{\"year\":\"2017\",\"rank\":5,\"invoiceAmount\":\"3693481.60\",\"invoiceAmountRatio\":6.06,\"invoiceNum\":36,\"invoiceNumRatio\":5.06,\"taxAuthCode\":\"410200\",\"taxAuthName\":\"河南-开封市\"},{\"year\":\"2017\",\"rank\":6,\"invoiceAmount\":\"3419808.20\",\"invoiceAmountRatio\":5.61,\"invoiceNum\":45,\"invoiceNumRatio\":6.33,\"taxAuthCode\":\"110100\",\"taxAuthName\":\"北京市\"},{\"year\":\"2017\",\"rank\":7,\"invoiceAmount\":\"2875557.30\",\"invoiceAmountRatio\":4.72,\"invoiceNum\":35,\"invoiceNumRatio\":4.92,\"taxAuthCode\":\"120200\",\"taxAuthName\":\"天津市\"},{\"year\":\"2017\",\"rank\":8,\"invoiceAmount\":\"1920827.91\",\"invoiceAmountRatio\":3.15,\"invoiceNum\":22,\"invoiceNumRatio\":3.09,\"taxAuthCode\":\"130400\",\"taxAuthName\":\"河北-邯郸市\"},{\"year\":\"2017\",\"rank\":9,\"invoiceAmount\":\"1388245.28\",\"invoiceAmountRatio\":2.28,\"invoiceNum\":14,\"invoiceNumRatio\":1.97,\"taxAuthCode\":\"310100\",\"taxAuthName\":\"上海市\"},{\"year\":\"2017\",\"rank\":10,\"invoiceAmount\":\"1186462.20\",\"invoiceAmountRatio\":1.95,\"invoiceNum\":15,\"invoiceNumRatio\":2.11,\"taxAuthCode\":\"110200\",\"taxAuthName\":\"北京市\"},{\"year\":\"2017\",\"rank\":11,\"invoiceAmount\":\"699406.50\",\"invoiceAmountRatio\":1.15,\"invoiceNum\":7,\"invoiceNumRatio\":0.98,\"taxAuthCode\":\"372300\",\"taxAuthName\":\"山东\"},{\"year\":\"2017\",\"rank\":12,\"invoiceAmount\":\"378096.60\",\"invoiceAmountRatio\":0.62,\"invoiceNum\":4,\"invoiceNumRatio\":0.56,\"taxAuthCode\":\"370700\",\"taxAuthName\":\"山东-潍坊市\"},{\"year\":\"2017\",\"rank\":13,\"invoiceAmount\":\"270588.80\",\"invoiceAmountRatio\":0.44,\"invoiceNum\":3,\"invoiceNumRatio\":0.42,\"taxAuthCode\":\"330200\",\"taxAuthName\":\"浙江-宁波市\"},{\"year\":\"2017\",\"rank\":14,\"invoiceAmount\":\"159686.50\",\"invoiceAmountRatio\":0.26,\"invoiceNum\":2,\"invoiceNumRatio\":0.28,\"taxAuthCode\":\"210800\",\"taxAuthName\":\"辽宁-营口市\"},{\"year\":\"2017\",\"rank\":15,\"invoiceAmount\":\"156379.50\",\"invoiceAmountRatio\":0.26,\"invoiceNum\":2,\"invoiceNumRatio\":0.28,\"taxAuthCode\":\"410100\",\"taxAuthName\":\"河南-郑州市\"},{\"year\":\"2017\",\"rank\":16,\"invoiceAmount\":\"136866.00\",\"invoiceAmountRatio\":0.22,\"invoiceNum\":2,\"invoiceNumRatio\":0.28,\"taxAuthCode\":\"410500\",\"taxAuthName\":\"河南-安阳市\"},{\"year\":\"2017\",\"rank\":17,\"invoiceAmount\":\"127400.00\",\"invoiceAmountRatio\":0.21,\"invoiceNum\":2,\"invoiceNumRatio\":0.28,\"taxAuthCode\":\"450200\",\"taxAuthName\":\"广西-柳州市\"},{\"year\":\"2017\",\"rank\":18,\"invoiceAmount\":\"106047.91\",\"invoiceAmountRatio\":0.17,\"invoiceNum\":1,\"invoiceNumRatio\":0.14,\"taxAuthCode\":\"360100\",\"taxAuthName\":\"江西-南昌市\"},{\"year\":\"2016\",\"rank\":1,\"invoiceAmount\":\"5187413.92\",\"invoiceAmountRatio\":21.41,\"invoiceNum\":73,\"invoiceNumRatio\":22.67,\"taxAuthCode\":\"120100\",\"taxAuthName\":\"天津市\"},{\"year\":\"2016\",\"rank\":2,\"invoiceAmount\":\"3735652.96\",\"invoiceAmountRatio\":15.42,\"invoiceNum\":36,\"invoiceNumRatio\":11.18,\"taxAuthCode\":\"372300\",\"taxAuthName\":\"山东\"},{\"year\":\"2016\",\"rank\":3,\"invoiceAmount\":\"3474211.05\",\"invoiceAmountRatio\":14.34,\"invoiceNum\":46,\"invoiceNumRatio\":14.29,\"taxAuthCode\":\"130900\",\"taxAuthName\":\"河北-沧州市\"},{\"year\":\"2016\",\"rank\":4,\"invoiceAmount\":\"2756102.99\",\"invoiceAmountRatio\":11.38,\"invoiceNum\":33,\"invoiceNumRatio\":10.25,\"taxAuthCode\":\"120200\",\"taxAuthName\":\"天津市\"},{\"year\":\"2016\",\"rank\":5,\"invoiceAmount\":\"2712962.25\",\"invoiceAmountRatio\":11.2,\"invoiceNum\":36,\"invoiceNumRatio\":11.18,\"taxAuthCode\":\"110200\",\"taxAuthName\":\"北京市\"},{\"year\":\"2016\",\"rank\":6,\"invoiceAmount\":\"1846027.00\",\"invoiceAmountRatio\":7.62,\"invoiceNum\":25,\"invoiceNumRatio\":7.76,\"taxAuthCode\":\"131000\",\"taxAuthName\":\"河北-廊坊市\"},{\"year\":\"2016\",\"rank\":7,\"invoiceAmount\":\"1397109.65\",\"invoiceAmountRatio\":5.77,\"invoiceNum\":27,\"invoiceNumRatio\":8.39,\"taxAuthCode\":\"110100\",\"taxAuthName\":\"北京市\"},{\"year\":\"2016\",\"rank\":8,\"invoiceAmount\":\"639790.08\",\"invoiceAmountRatio\":2.64,\"invoiceNum\":9,\"invoiceNumRatio\":2.8,\"taxAuthCode\":\"370300\",\"taxAuthName\":\"山东-淄博市\"},{\"year\":\"2016\",\"rank\":9,\"invoiceAmount\":\"600835.39\",\"invoiceAmountRatio\":2.48,\"invoiceNum\":10,\"invoiceNumRatio\":3.11,\"taxAuthCode\":\"131100\",\"taxAuthName\":\"河北-衡水市\"},{\"year\":\"2016\",\"rank\":10,\"invoiceAmount\":\"516872.00\",\"invoiceAmountRatio\":2.13,\"invoiceNum\":6,\"invoiceNumRatio\":1.86,\"taxAuthCode\":\"420100\",\"taxAuthName\":\"湖北-武汉市\"},{\"year\":\"2016\",\"rank\":11,\"invoiceAmount\":\"452216.98\",\"invoiceAmountRatio\":1.87,\"invoiceNum\":6,\"invoiceNumRatio\":1.86,\"taxAuthCode\":\"420000\",\"taxAuthName\":\"湖北\"},{\"year\":\"2016\",\"rank\":12,\"invoiceAmount\":\"264186.90\",\"invoiceAmountRatio\":1.09,\"invoiceNum\":3,\"invoiceNumRatio\":0.93,\"taxAuthCode\":\"370700\",\"taxAuthName\":\"山东-潍坊市\"},{\"year\":\"2016\",\"rank\":13,\"invoiceAmount\":\"186144.80\",\"invoiceAmountRatio\":0.77,\"invoiceNum\":3,\"invoiceNumRatio\":0.93,\"taxAuthCode\":\"410100\",\"taxAuthName\":\"河南-郑州市\"},{\"year\":\"2016\",\"rank\":14,\"invoiceAmount\":\"178087.82\",\"invoiceAmountRatio\":0.74,\"invoiceNum\":2,\"invoiceNumRatio\":0.62,\"taxAuthCode\":\"130100\",\"taxAuthName\":\"河北-石家庄市\"},{\"year\":\"2016\",\"rank\":15,\"invoiceAmount\":\"138792.50\",\"invoiceAmountRatio\":0.57,\"invoiceNum\":2,\"invoiceNumRatio\":0.62,\"taxAuthCode\":\"210300\",\"taxAuthName\":\"辽宁-鞍山市\"},{\"year\":\"2016\",\"rank\":16,\"invoiceAmount\":\"124287.90\",\"invoiceAmountRatio\":0.51,\"invoiceNum\":4,\"invoiceNumRatio\":1.24,\"taxAuthCode\":\"130400\",\"taxAuthName\":\"河北-邯郸市\"},{\"year\":\"2016\",\"rank\":17,\"invoiceAmount\":\"14276.30\",\"invoiceAmountRatio\":0.06,\"invoiceNum\":1,\"invoiceNumRatio\":0.31,\"taxAuthCode\":\"211100\",\"taxAuthName\":\"辽宁-盘锦市\"}],\"tradeCustomerSumInfo\":[{\"season\":\"2018年3季度\",\"customerNum\":45,\"top10\":[{\"invoiceNumRatio\":28.24,\"rank\":1,\"invoiceAmount\":\"7213570.400000\",\"invoiceNum\":72,\"customerName\":\"北京汽车制造厂有限公司黄骅公司\",\"invoiceAmountRatio\":29.75},{\"invoiceNumRatio\":16.47,\"rank\":2,\"invoiceAmount\":\"4115131.370000\",\"invoiceNum\":42,\"customerName\":\"天津万顺昌金属制品有限公司\",\"invoiceAmountRatio\":16.97},{\"invoiceNumRatio\":4.71,\"rank\":3,\"invoiceAmount\":\"1248444.600000\",\"invoiceNum\":12,\"customerName\":\"唐山乐凡商贸有限公司\",\"invoiceAmountRatio\":5.15},{\"invoiceNumRatio\":3.92,\"rank\":4,\"invoiceAmount\":\"1056553.510000\",\"invoiceNum\":10,\"customerName\":\"天津市乔策商贸有限公司\",\"invoiceAmountRatio\":4.36},{\"invoiceNumRatio\":3.92,\"rank\":5,\"invoiceAmount\":\"985357.050000\",\"invoiceNum\":10,\"customerName\":\"河北荣阳汽车零配件有限公司\",\"invoiceAmountRatio\":4.06},{\"invoiceNumRatio\":2.75,\"rank\":6,\"invoiceAmount\":\"701706.150000\",\"invoiceNum\":7,\"customerName\":\"天津市宏煜金泽商贸有限公司\",\"invoiceAmountRatio\":2.89},{\"invoiceNumRatio\":2.75,\"rank\":7,\"invoiceAmount\":\"694963.150000\",\"invoiceNum\":7,\"customerName\":\"天津简易商贸有限公司\",\"invoiceAmountRatio\":2.87},{\"invoiceNumRatio\":2.35,\"rank\":8,\"invoiceAmount\":\"599590.200000\",\"invoiceNum\":6,\"customerName\":\"神钢商贸（上海）有限公司\",\"invoiceAmountRatio\":2.47},{\"invoiceNumRatio\":2.75,\"rank\":9,\"invoiceAmount\":\"568119.000000\",\"invoiceNum\":7,\"customerName\":\"天津市润飞贸易有限公司\",\"invoiceAmountRatio\":2.34},{\"invoiceNumRatio\":1.96,\"rank\":10,\"invoiceAmount\":\"535790.300000\",\"invoiceNum\":5,\"customerName\":\"定州市宏远机械有限公司\",\"invoiceAmountRatio\":2.21}]},{\"season\":\"2018年2季度\",\"customerNum\":55,\"top10\":[{\"invoiceNumRatio\":26.89,\"rank\":1,\"invoiceAmount\":\"8833049.700000\",\"invoiceNum\":89,\"customerName\":\"北京汽车制造厂有限公司黄骅公司\",\"invoiceAmountRatio\":28.73},{\"invoiceNumRatio\":6.95,\"rank\":2,\"invoiceAmount\":\"2384984.800000\",\"invoiceNum\":23,\"customerName\":\"天津市宏煜金泽商贸有限公司\",\"invoiceAmountRatio\":7.76},{\"invoiceNumRatio\":6.95,\"rank\":3,\"invoiceAmount\":\"2168851.440000\",\"invoiceNum\":23,\"customerName\":\"天津万顺昌金属制品有限公司\",\"invoiceAmountRatio\":7.05},{\"invoiceNumRatio\":9.06,\"rank\":4,\"invoiceAmount\":\"2090551.880000\",\"invoiceNum\":30,\"customerName\":\"包头市广晔钢铁贸易有限公司\",\"invoiceAmountRatio\":6.8},{\"invoiceNumRatio\":5.14,\"rank\":5,\"invoiceAmount\":\"1788152.220000\",\"invoiceNum\":17,\"customerName\":\"天津市乔策商贸有限公司\",\"invoiceAmountRatio\":5.82},{\"invoiceNumRatio\":4.53,\"rank\":6,\"invoiceAmount\":\"1616534.360000\",\"invoiceNum\":15,\"customerName\":\"定州市永舟汽车零部件有限公司\",\"invoiceAmountRatio\":5.26},{\"invoiceNumRatio\":4.53,\"rank\":7,\"invoiceAmount\":\"1484989.820000\",\"invoiceNum\":15,\"customerName\":\"定州市宏远机械有限公司\",\"invoiceAmountRatio\":4.83},{\"invoiceNumRatio\":2.72,\"rank\":8,\"invoiceAmount\":\"968648.800000\",\"invoiceNum\":9,\"customerName\":\"唐山乐凡商贸有限公司\",\"invoiceAmountRatio\":3.15},{\"invoiceNumRatio\":1.81,\"rank\":9,\"invoiceAmount\":\"616126.750000\",\"invoiceNum\":6,\"customerName\":\"沈阳华溪伟业商贸有限公司\",\"invoiceAmountRatio\":2},{\"invoiceNumRatio\":1.81,\"rank\":10,\"invoiceAmount\":\"580534.900000\",\"invoiceNum\":6,\"customerName\":\"任丘市通盛通讯器材有限公司\",\"invoiceAmountRatio\":1.89}]},{\"season\":\"2018年1季度\",\"customerNum\":57,\"top10\":[{\"invoiceNumRatio\":25,\"rank\":1,\"invoiceAmount\":\"6119158.160000\",\"invoiceNum\":59,\"customerName\":\"天津市乔策商贸有限公司\",\"invoiceAmountRatio\":28.24},{\"invoiceNumRatio\":12.29,\"rank\":2,\"invoiceAmount\":\"2863297.200000\",\"invoiceNum\":29,\"customerName\":\"北京汽车制造厂有限公司黄骅公司\",\"invoiceAmountRatio\":13.21},{\"invoiceNumRatio\":9.75,\"rank\":3,\"invoiceAmount\":\"2300207.070000\",\"invoiceNum\":23,\"customerName\":\"天津万顺昌金属制品有限公司\",\"invoiceAmountRatio\":10.62},{\"invoiceNumRatio\":4.24,\"rank\":4,\"invoiceAmount\":\"921435.980000\",\"invoiceNum\":10,\"customerName\":\"天津市信忠运金属材料销售有限公司\",\"invoiceAmountRatio\":4.25},{\"invoiceNumRatio\":3.39,\"rank\":5,\"invoiceAmount\":\"690590.450000\",\"invoiceNum\":8,\"customerName\":\"北京顺恒达汽车电子股份有限公司\",\"invoiceAmountRatio\":3.19},{\"invoiceNumRatio\":2.97,\"rank\":6,\"invoiceAmount\":\"681305.100000\",\"invoiceNum\":7,\"customerName\":\"天津市鸿捷达模具开发有限公司\",\"invoiceAmountRatio\":3.14},{\"invoiceNumRatio\":2.54,\"rank\":7,\"invoiceAmount\":\"604012.550000\",\"invoiceNum\":6,\"customerName\":\"霸州市华硕汽车零部件有限公司\",\"invoiceAmountRatio\":2.79},{\"invoiceNumRatio\":2.54,\"rank\":8,\"invoiceAmount\":\"601104.620000\",\"invoiceNum\":6,\"customerName\":\"乾元中科能源科技（北京）有限公司\",\"invoiceAmountRatio\":2.77},{\"invoiceNumRatio\":2.54,\"rank\":9,\"invoiceAmount\":\"583258.250000\",\"invoiceNum\":6,\"customerName\":\"盛隆电气（北京）有限公司\",\"invoiceAmountRatio\":2.69},{\"invoiceNumRatio\":2.12,\"rank\":10,\"invoiceAmount\":\"477840.650000\",\"invoiceNum\":5,\"customerName\":\"包头市广晔钢铁贸易有限公司\",\"invoiceAmountRatio\":2.21}]},{\"season\":\"2017年4季度\",\"customerNum\":60,\"top10\":[{\"invoiceNumRatio\":14.06,\"rank\":1,\"invoiceAmount\":\"3387473.450000\",\"invoiceNum\":35,\"customerName\":\"北京汽车制造厂有限公司黄骅公司\",\"invoiceAmountRatio\":15.06},{\"invoiceNumRatio\":9.64,\"rank\":2,\"invoiceAmount\":\"2320916.600000\",\"invoiceNum\":24,\"customerName\":\"天津市宏煜金泽商贸有限公司\",\"invoiceAmountRatio\":10.32},{\"invoiceNumRatio\":7.63,\"rank\":3,\"invoiceAmount\":\"2057789.820000\",\"invoiceNum\":19,\"customerName\":\"天津市沐林包装容器有限公司\",\"invoiceAmountRatio\":9.15},{\"invoiceNumRatio\":6.83,\"rank\":4,\"invoiceAmount\":\"1787820.610000\",\"invoiceNum\":17,\"customerName\":\"天津市乔策商贸有限公司\",\"invoiceAmountRatio\":7.95},{\"invoiceNumRatio\":4.42,\"rank\":5,\"invoiceAmount\":\"1228785.500000\",\"invoiceNum\":11,\"customerName\":\"邯郸市新颐通管业科技有限公司\",\"invoiceAmountRatio\":5.46},{\"invoiceNumRatio\":4.02,\"rank\":6,\"invoiceAmount\":\"1093867.850000\",\"invoiceNum\":10,\"customerName\":\"定州市至信机械制造有限公司\",\"invoiceAmountRatio\":4.86},{\"invoiceNumRatio\":4.02,\"rank\":7,\"invoiceAmount\":\"1020182.880000\",\"invoiceNum\":10,\"customerName\":\"上海众科机电有限公司\",\"invoiceAmountRatio\":4.53},{\"invoiceNumRatio\":3.61,\"rank\":8,\"invoiceAmount\":\"864988.650000\",\"invoiceNum\":9,\"customerName\":\"河南奥力星汽车部件有限公司\",\"invoiceAmountRatio\":3.85},{\"invoiceNumRatio\":3.21,\"rank\":9,\"invoiceAmount\":\"822692.100000\",\"invoiceNum\":8,\"customerName\":\"天津市明丰工贸有限公司\",\"invoiceAmountRatio\":3.66},{\"invoiceNumRatio\":2.81,\"rank\":10,\"invoiceAmount\":\"631765.510000\",\"invoiceNum\":7,\"customerName\":\"北京敏实汽车零部件有限公司\",\"invoiceAmountRatio\":2.81}]},{\"season\":\"2017年3季度\",\"customerNum\":42,\"top10\":[{\"invoiceNumRatio\":15.42,\"rank\":1,\"invoiceAmount\":\"2405234.500000\",\"invoiceNum\":33,\"customerName\":\"北京汽车制造厂有限公司黄骅公司\",\"invoiceAmountRatio\":13.45},{\"invoiceNumRatio\":10.28,\"rank\":2,\"invoiceAmount\":\"2133464.690000\",\"invoiceNum\":22,\"customerName\":\"天津纵联金属材料有限公司\",\"invoiceAmountRatio\":11.93},{\"invoiceNumRatio\":8.88,\"rank\":3,\"invoiceAmount\":\"1975540.100000\",\"invoiceNum\":19,\"customerName\":\"河南奥力星汽车部件有限公司\",\"invoiceAmountRatio\":11.05},{\"invoiceNumRatio\":7.48,\"rank\":4,\"invoiceAmount\":\"1611044.000000\",\"invoiceNum\":16,\"customerName\":\"霸州市华硕汽车零部件有限公司\",\"invoiceAmountRatio\":9.01},{\"invoiceNumRatio\":6.54,\"rank\":5,\"invoiceAmount\":\"1592210.110000\",\"invoiceNum\":14,\"customerName\":\"上海欧冶材料技术有限责任公司天津自贸试验区分公司\",\"invoiceAmountRatio\":8.9},{\"invoiceNumRatio\":3.27,\"rank\":6,\"invoiceAmount\":\"797674.970000\",\"invoiceNum\":7,\"customerName\":\"天津市乔策商贸有限公司\",\"invoiceAmountRatio\":4.46},{\"invoiceNumRatio\":3.27,\"rank\":7,\"invoiceAmount\":\"701302.020000\",\"invoiceNum\":7,\"customerName\":\"天津市鸿捷达模具开发有限公司\",\"invoiceAmountRatio\":3.92},{\"invoiceNumRatio\":9.81,\"rank\":8,\"invoiceAmount\":\"587652.450000\",\"invoiceNum\":21,\"customerName\":\"定州市长奥汽车配件有限公司\",\"invoiceAmountRatio\":3.29},{\"invoiceNumRatio\":2.34,\"rank\":9,\"invoiceAmount\":\"511390.750000\",\"invoiceNum\":5,\"customerName\":\"天津市明丰工贸有限公司\",\"invoiceAmountRatio\":2.86},{\"invoiceNumRatio\":2.34,\"rank\":10,\"invoiceAmount\":\"477925.300000\",\"invoiceNum\":5,\"customerName\":\"北京博萨汽车配件有限公司\",\"invoiceAmountRatio\":2.67}]},{\"season\":\"2017年2季度\",\"customerNum\":30,\"top10\":[{\"invoiceNumRatio\":11.19,\"rank\":1,\"invoiceAmount\":\"1853746.940000\",\"invoiceNum\":16,\"customerName\":\"上海欧冶材料技术有限责任公司天津自贸试验区分公司\",\"invoiceAmountRatio\":15.18},{\"invoiceNumRatio\":16.08,\"rank\":2,\"invoiceAmount\":\"1560230.400000\",\"invoiceNum\":23,\"customerName\":\"北京汽车制造厂有限公司黄骅公司\",\"invoiceAmountRatio\":12.78},{\"invoiceNumRatio\":11.19,\"rank\":3,\"invoiceAmount\":\"1360022.210000\",\"invoiceNum\":16,\"customerName\":\"定州市长奥汽车配件有限公司\",\"invoiceAmountRatio\":11.14},{\"invoiceNumRatio\":5.59,\"rank\":4,\"invoiceAmount\":\"857410.280000\",\"invoiceNum\":8,\"customerName\":\"天津冠亚科技发展有限公司\",\"invoiceAmountRatio\":7.02},{\"invoiceNumRatio\":5.59,\"rank\":5,\"invoiceAmount\":\"852952.850000\",\"invoiceNum\":8,\"customerName\":\"河南奥力星汽车部件有限公司\",\"invoiceAmountRatio\":6.98},{\"invoiceNumRatio\":5.59,\"rank\":6,\"invoiceAmount\":\"777776.810000\",\"invoiceNum\":8,\"customerName\":\"天津市乔策商贸有限公司\",\"invoiceAmountRatio\":6.37},{\"invoiceNumRatio\":5.59,\"rank\":7,\"invoiceAmount\":\"747358.500000\",\"invoiceNum\":8,\"customerName\":\"河北江津五金制品股份有限公司\",\"invoiceAmountRatio\":6.12},{\"invoiceNumRatio\":4.2,\"rank\":8,\"invoiceAmount\":\"525676.200000\",\"invoiceNum\":6,\"customerName\":\"天津纵联金属材料有限公司\",\"invoiceAmountRatio\":4.3},{\"invoiceNumRatio\":3.5,\"rank\":9,\"invoiceAmount\":\"453248.210000\",\"invoiceNum\":5,\"customerName\":\"邯郸市新颐通管业科技有限公司\",\"invoiceAmountRatio\":3.71},{\"invoiceNumRatio\":4.2,\"rank\":10,\"invoiceAmount\":\"416544.800000\",\"invoiceNum\":6,\"customerName\":\"盛隆电气（北京）有限公司\",\"invoiceAmountRatio\":3.41}]},{\"season\":\"2017年1季度\",\"customerNum\":33,\"top10\":[{\"invoiceNumRatio\":13.33,\"rank\":1,\"invoiceAmount\":\"1370583.220000\",\"invoiceNum\":14,\"customerName\":\"天津市乔策商贸有限公司\",\"invoiceAmountRatio\":16.39},{\"invoiceNumRatio\":6.67,\"rank\":2,\"invoiceAmount\":\"699406.500000\",\"invoiceNum\":7,\"customerName\":\"山东滨州渤海活塞股份有限公司\",\"invoiceAmountRatio\":8.36},{\"invoiceNumRatio\":8.57,\"rank\":3,\"invoiceAmount\":\"676679.850000\",\"invoiceNum\":9,\"customerName\":\"北京汽车制造厂有限公司黄骅公司\",\"invoiceAmountRatio\":8.09},{\"invoiceNumRatio\":6.67,\"rank\":4,\"invoiceAmount\":\"548648.100000\",\"invoiceNum\":7,\"customerName\":\"天津中粮制桶有限公司\",\"invoiceAmountRatio\":6.56},{\"invoiceNumRatio\":5.71,\"rank\":5,\"invoiceAmount\":\"516602.400000\",\"invoiceNum\":6,\"customerName\":\"天津瑞林迪金属制品有限公司\",\"invoiceAmountRatio\":6.18},{\"invoiceNumRatio\":4.76,\"rank\":6,\"invoiceAmount\":\"455862.800000\",\"invoiceNum\":5,\"customerName\":\"盛隆电气（北京）有限公司\",\"invoiceAmountRatio\":5.45},{\"invoiceNumRatio\":3.81,\"rank\":7,\"invoiceAmount\":\"378096.600000\",\"invoiceNum\":4,\"customerName\":\"张家港中粮包装有限公司山东分公司\",\"invoiceAmountRatio\":4.52},{\"invoiceNumRatio\":3.81,\"rank\":8,\"invoiceAmount\":\"364400.500000\",\"invoiceNum\":4,\"customerName\":\"天津市鸿捷达模具开发有限公司\",\"invoiceAmountRatio\":4.36},{\"invoiceNumRatio\":4.76,\"rank\":9,\"invoiceAmount\":\"351676.460000\",\"invoiceNum\":5,\"customerName\":\"天津市中宝三星科技有限公司\",\"invoiceAmountRatio\":4.21},{\"invoiceNumRatio\":3.81,\"rank\":10,\"invoiceAmount\":\"351548.700000\",\"invoiceNum\":4,\"customerName\":\"河北江津五金制品股份有限公司\",\"invoiceAmountRatio\":4.2}]}]},\"tradeNo\":\"1234\",\"success\":true,\"message\":\"请求成功\"}"; 
//		JSONObject json = JSONObject.fromObject(sl);
		JSONObject json = JSONObject.fromObject(str);
		Set<String> keySet = json.keySet();
		Map<String,List<Object>> r = new HashMap<String,List<Object>>();
		T t = new T();
		System.out.println("结果："+json);
		t.appendObj("",json,r);
		System.out.println("转换后的结构："+r);
		
		Collection<List<Object>> values = r.values();
		Iterator<List<Object>> iterator = values.iterator();
		int maxSize = 0; 
		while(iterator.hasNext()) {
			int size = iterator.next().size();
			if(size > maxSize) {
				maxSize = size;
			}
			System.out.println(maxSize);
		}
		
		StringBuilder sb = new StringBuilder();
		Set<String> keySet2 = r.keySet();
		ArrayList<String> al = new ArrayList<String>();
		al.addAll(keySet2);
		Collections.sort(al, new Comparator<String>() {

			@Override
			public int compare(String s1, String s2) {
				if(s1.lastIndexOf("__") > s2.lastIndexOf("__")) {
					return 1;
				}else if(s1.lastIndexOf("__") < s2.lastIndexOf("__")) {
					return -1;
				}else {
					if(s1.compareTo(s2) > 0 ) {
						return 1;
					}else if(s1.compareTo(s2) < 0 ) {
						return -1;
					}
				}
				return 0;
			}
			
		});
		System.out.println(al);
		for(int k=0;k<al.size();k++) {
			sb.append("\"").append(al.get(k)).append("\"");
			if(k < al.size()-1) {
				sb.append(",");
			}else {
				sb.append("\t\n");
			}
		}
		for(int i=0;i<maxSize;i++) {
			for(int k=0;k<al.size();k++) {
				List<Object> list = r.get(al.get(k));
				if(list != null && list.size() > i) {
					Object object = list.get(i);
					sb.append("\"");
					if(object == null) {
						sb.append("");
					}else {
						sb.append(object.toString());
					}
					sb.append("\"");
				}else {
					sb.append("\"\"");
				}
				if(k < al.size()-1) {
					sb.append(",");
				}else {
					sb.append("\t\n");
				}
			}
		}
		System.out.println(sb.toString());
		
		
		
	}
	
	private void appendObj(String prefixKey, JSONObject json, Map<String,List<Object>> r) {
		Set<String> keySet = json.keySet();
		int maxArraySize = 0;
		for(String key : keySet) {
			Object object = json.get(key);
			if(object instanceof JSONObject){
			}else if(object instanceof JSONArray) {
				JSONArray js = (JSONArray)object;
				int size = js.size();
				if(size > maxArraySize) {
					maxArraySize = size;
				}
				System.out.println("数组："+object);
			}
		}
		
		for(String key : keySet) {
			Object object = json.get(key);
			if(object instanceof JSONObject){
				System.out.println("对象："+object);
				appendObj(prefixKey+key+"__",(JSONObject)object,r);
			}else if(object instanceof JSONArray) {
				System.out.println("数组："+object);
				appendArray(prefixKey+key+"__",(JSONArray)object,r);
			}else {
				System.out.println("都不是：" + object.toString());
				ArrayList<Object> levelOne = new ArrayList<Object>();
				levelOne.add(object.toString());
				for(int k=0;k<maxArraySize-1;k++) {
					levelOne.add(null);
				}
				List<Object> list = r.get(prefixKey + key);
				if(list == null || list.size() == 0) {
					r.put(prefixKey + key, levelOne);
				}else {
					list.addAll(levelOne);
				}
			}
		}
	}
	
	private void appendArray(String prefixKey, JSONArray array, Map<String,List<Object>> r) {
		for(int i=0; i<array.size(); i++) {
			Object object = array.get(i);
			if(object == null) {
				continue;
			}
			if(object instanceof JSONObject){
				System.out.println("对象："+object);
				appendObj(prefixKey,(JSONObject)object,r);
			}else if(object instanceof JSONArray) {
				System.out.println("数组："+object);
			}else {
				System.out.println("都不是：" + object.toString());
				Object [] list = array.toArray();
				List<Object> asList = Arrays.asList(list);
				List<Object> oldList = r.get(prefixKey);
				
				if(oldList == null || oldList.size() == 0) {
					r.put(prefixKey, asList);
				}else {
					oldList.addAll(asList);
				}
				break;
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
