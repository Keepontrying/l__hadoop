package com.wangyin.boss.credit.admin.beans.param;

import com.chinabank.core.utils.StringUtil;
import com.wangyin.boss.credit.admin.utils.DateUtil;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by anmeng on 2017/3/24.
 */
public class OrderPageQueryParam extends PageQueryParam implements Serializable {
    private static final long serialVersionUID = 5266054480641346074L;

    private static DateFormat dateDF=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private String startCreateDateStr;//交易创建时间 起
    private String endCreateDateStr;//交易创建时间 止
    private Date startCreateDate;
    private Date endCreateDate;

    private String merchantNo;//商户号
    private String merchantName;//商户名称

    private String orderStatus;//交易状态

    private String orderSource;//订单类型

    private String orderNo;//商户订单号
    private String signStatus;// 签约状态  yes-已签约；no-未签约
    private String merchantClassify;//商户分类

    public String getStartCreateDateStr() {
        return startCreateDateStr;
    }

    public void setStartCreateDateStr(String startCreateDateStr) {
        this.startCreateDateStr = startCreateDateStr;
        try {
            if(!StringUtil.isBlank(startCreateDateStr)){
                startCreateDate=dateDF.parse(startCreateDateStr+" 00:00:00");
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public String getEndCreateDateStr() {
        return endCreateDateStr;
    }

    public void setEndCreateDateStr(String endCreateDateStr) {
        this.endCreateDateStr = endCreateDateStr;
        try {
            if(!StringUtil.isBlank(endCreateDateStr)){
                endCreateDate=dateDF.parse(DateUtil.getAfterDay(endCreateDateStr)+" 00:00:00");
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderSource() {
        return orderSource;
    }

    public void setOrderSource(String orderSource) {
        this.orderSource = orderSource;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public Date getStartCreateDate() {
        return startCreateDate;
    }

    public void setStartCreateDate(Date startCreateDate) {
        this.startCreateDate = startCreateDate;
    }

    public Date getEndCreateDate() {
        return endCreateDate;
    }

    public void setEndCreateDate(Date endCreateDate) {
        this.endCreateDate = endCreateDate;
    }

    public String getSignStatus() {
        return signStatus;
    }

    public void setSignStatus(String signStatus) {
        this.signStatus = signStatus;
    }

    public String getMerchantClassify() {
        return merchantClassify;
    }

    public void setMerchantClassify(String merchantClassify) {
        this.merchantClassify = merchantClassify;
    }
}
