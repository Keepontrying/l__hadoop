package com.wangyin.boss.credit.enterprise.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wangyin.boss.credit.admin.enums.*;
import com.wangyin.operation.beans.UploadFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.param.CreditDealFlowQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.CreditDealFlowInfo;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.QueryCountEntity;
import com.wangyin.boss.credit.admin.controller.BaseController;
import com.wangyin.boss.credit.admin.entity.CreditAccessDetails;
import com.wangyin.boss.credit.enterprise.service.CreditDealFlowService;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : 交易流水controller
* @author : yangjinlin@jd.com
* @date ：2018年4月22日 下午10:18:57 
* @version 1.0 
* @return  */
@Controller
@RequestMapping("/dealFlow")
public class CreditDealFlowController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CreditDealFlowController.class);
	
	@Autowired
	CreditDealFlowService creditDealFlowService;
	
	/**
	 * 查询商户业务详单数据 分页  --- 变更为 查询商户交易流水信息   分页
	 * @author yangjinlin@jd.com
	 * @param map
	 * @param dealFlowQryPrm
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryDealFlowList.biz")
	public Map<String, Object> doQueryDealFlowListFromEs(@RequestParam Map<String, String> map, CreditDealFlowQueryParam dealFlowQryPrm) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		try {
			List<CreditDealFlowInfo> dealFlowList = new ArrayList<CreditDealFlowInfo>();
			int dealFlowQryTotalCount = 0;
			int successCount = 0;
			int failCount = 0;
			CreditPage<CreditDealFlowInfo> dealFlowPage = creditDealFlowService.queryDealFlowPage(dealFlowQryPrm);
			if(null == dealFlowPage || ( null != dealFlowPage && !dealFlowPage.isSuccess() ) ){
				resultMap.put("rows", dealFlowList);
				resultMap.put("total", dealFlowQryTotalCount);
				resultMap.put("successCount", successCount);
				resultMap.put("failCount", failCount);
				return resultMap;
			}
			
			for(CreditDealFlowInfo dealFlowInfo : dealFlowPage.getRows()){
				dealFlowInfo.setChargeType(ChargeTypeEnum.enumValueOf(dealFlowInfo.getChargeType()).toDescription());
				dealFlowInfo.setStepStatus(AccessStepStatusEnum.enumValueOf(dealFlowInfo.getStepStatus()).toDescription());
				dealFlowInfo.setCallMode(AccessCallModeEnum.enumValueOf(dealFlowInfo.getCallMode()).toDescription());
				dealFlowInfo.setResource(CreditSourceEnum.enumValueOf(dealFlowInfo.getResource()).toDescription());
			}
			resultMap.put("rows", dealFlowPage.getRows());
			resultMap.put("total", dealFlowPage.getTotal());
			String countFiled = "stepStatus";
			CreditResponseData<List<QueryCountEntity>> countDealFlowByFieldResp = creditDealFlowService.countDealFlowByField(dealFlowQryPrm, countFiled);
			resultMap.put("successCount", successCount);
			resultMap.put("failCount", failCount);
			if(null == countDealFlowByFieldResp || (null!=countDealFlowByFieldResp && !countDealFlowByFieldResp.isSuccess())){
				return resultMap;
			}
			for(QueryCountEntity qryCountEntity : countDealFlowByFieldResp.getData()){
				if(!resultMap.containsKey("success") && AccessStatusEnum.SUCCESS.toName().equalsIgnoreCase(qryCountEntity.getCountKey())){
					resultMap.put("successCount", qryCountEntity.getCountValue());
					continue;
				} else if( !resultMap.containsKey("fail") &&  AccessStatusEnum.FAIL.toName().equalsIgnoreCase(qryCountEntity.getCountKey())){
					resultMap.put("failCount", qryCountEntity.getCountValue());
					continue;
				}else{
					LOGGER.info("this qryCountEntity neednt show, {}" , GsonUtil.getInstance().toJson(qryCountEntity));
				}
			}
			failCount = (int) (dealFlowPage.getTotal()-Long.valueOf(resultMap.get("successCount").toString()));
			resultMap.put("failCount", failCount);
			
		} catch (Exception e) {
			LOGGER.error("doQueryDealFlowList failed, {}", e);
			resultMap.put("rows", new ArrayList<CreditAccessDetails>());
			resultMap.put("total", 0);
			resultMap.put("successCount", 0);
			resultMap.put("failCount", 0);
		}
		
		return resultMap;
	}

	/**
	 * 下载交易流水数据
	 * @param params
	 * @param queryParam
	 * @return
	 */
	@RequestMapping("downDealFlowQueryResult.download")
	@ResponseBody
	public UploadFile downDealFlowQueryResult(@RequestParam Map<String, Object> params, CreditDealFlowQueryParam queryParam) {
		return creditDealFlowService.downDealFlowQueryResult(queryParam);
	}

}
