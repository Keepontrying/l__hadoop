package com.wangyin.boss.credit.admin.controller;

import com.wangyin.boss.credit.admin.beans.TextValuePairs;
import com.wangyin.boss.credit.admin.utils.TextValueUtil;
import com.wangyin.operation.common.beans.ResponseData;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * 表单选项获取控制器
 *
 * @author: dongzhihua
 * @time: 2018/10/31 10:39:30
 */
@Controller
@RequestMapping("formOptions")
public class FormOptionsController {

    private static Logger logger = LoggerFactory.getLogger(FormOptionsController.class);

    /**
     * 获取商户分类选项，根据枚举类名获取选项集合，枚举需在此包下com.wangyin.boss.credit.admin.enums
     * @author: dongzhihua
     * @time: 2018/10/31 10:41:21
     */
    @RequestMapping("getEnumOptions.do")
    @ResponseBody
    public ResponseData<List<TextValuePairs>> getEnumOptions(String enumName) {
        logger.info("getEnumOptions : {}", enumName);
        String path = "com.wangyin.boss.credit.admin.enums.";
        ResponseData<List<TextValuePairs>> listResponseData = new ResponseData<List<TextValuePairs>>();
        if (StringUtils.isBlank(enumName)) {
            listResponseData.setSuccess(false);
            listResponseData.setMessage("参数enumName名称不能为空");
            return listResponseData;
        }
        try {
            List<TextValuePairs> enumOption = TextValueUtil.getEnumOption(path + enumName);
            listResponseData.setData(enumOption);
        } catch (Exception e) {
            listResponseData.setSuccess(false);
            listResponseData.setMessage(e.getMessage());
        }
        return listResponseData;
    }
}
