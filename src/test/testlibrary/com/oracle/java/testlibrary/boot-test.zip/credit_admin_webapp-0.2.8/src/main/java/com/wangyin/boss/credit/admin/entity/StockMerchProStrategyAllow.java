package com.wangyin.boss.credit.admin.entity;
/** 
* @desciption : 存量商户余量信息实体类
* @author : yangjinlin@jd.com
* @date ：2016年10月19日 下午8:06:26 
* @version 1.0 
* @return  */
public class StockMerchProStrategyAllow extends CreditProductStrategy{

	//账号
	private String accountNo;
	//余量
	private Integer allowance;
	//合同编号
	private String contractNo;
	//合同电子件路径
	private String contractPath;
	//合同电子件路径
	private String contractStatus;
	//剩余次数
    private String remainCountStr;
    
    private String packetCountStr;
	

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public Integer getAllowance() {
		return allowance;
	}

	public void setAllowance(Integer allowance) {
		this.allowance = allowance;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public String getContractPath() {
		return contractPath;
	}

	public void setContractPath(String contractPath) {
		this.contractPath = contractPath;
	}

	public String getContractStatus() {
		return contractStatus;
	}

	public void setContractStatus(String contractStatus) {
		this.contractStatus = contractStatus;
	}

	public String getRemainCountStr() {
		return remainCountStr;
	}

	public void setRemainCountStr(String remainCountStr) {
		this.remainCountStr = remainCountStr;
	}

	public String getPacketCountStr() {
		return packetCountStr;
	}

	public void setPacketCountStr(String packetCountStr) {
		this.packetCountStr = packetCountStr;
	}

	
}
