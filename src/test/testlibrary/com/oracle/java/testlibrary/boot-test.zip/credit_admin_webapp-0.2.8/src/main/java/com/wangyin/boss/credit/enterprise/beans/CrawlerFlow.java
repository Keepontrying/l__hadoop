package com.wangyin.boss.credit.enterprise.beans;

/**
 * @author huangzhiqiang
 * @data 2018/11/27
 */
public class CrawlerFlow {
}
