package com.wangyin.boss.credit.admin.entity;

import java.util.List;

/** 
* @desciption : 存量商户余量信息实体类
* @author : yangjinlin@jd.com
* @date ：2016年10月19日 下午8:06:26 
* @version 1.0 
* @return  */
public class StockMerchProStrategyAllowModel{

	//商户单笔余量
	private String priceStr;
	
	private List<StockMerchProStrategyAllow> stockMerchAllowList;

	public String getPriceStr() {
		return priceStr;
	}

	public void setPriceStr(String priceStr) {
		this.priceStr = priceStr;
	}

	public List<StockMerchProStrategyAllow> getStockMerchAllowList() {
		return stockMerchAllowList;
	}

    public void setStockMerchAllowList(List<StockMerchProStrategyAllow> stockMerchAllowList) {
		this.stockMerchAllowList = stockMerchAllowList;
	}

}
