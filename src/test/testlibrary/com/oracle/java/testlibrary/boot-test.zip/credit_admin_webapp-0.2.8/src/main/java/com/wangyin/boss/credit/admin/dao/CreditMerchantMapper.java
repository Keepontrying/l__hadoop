package com.wangyin.boss.credit.admin.dao;

import java.util.List;
import java.util.Map;

import com.wangyin.wallet.member.common.dto.MailParamDTO;
import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditRoster;

@SqlMapper
@Component
public interface CreditMerchantMapper {
	
	CreditMerchant selectByMerchantNo(String merchantNo);

	CreditMerchant selectByMerNoType(Map<String,String> map);
	
	int insert(CreditMerchant record);
	
	int updateByPrimaryKeySelective(CreditMerchant record);
	
	CreditMerchant selectByPrimaryKey(Integer merchantId);

	/**
	 * 根据商户号查询商户列表(原则上至多有1条数据)
	 * @param merchantNo
	 * @return
	 */
	List<CreditMerchant> selectMerchListByNo(String merchantNo);

	/**
	 * 根据商户号更新商户信息
	 * @param cm
	 * @return
	 */
	int updateMerchByNo(CreditMerchant cm);

	/**
	 * 无条件查询所有有效商户  分页
	 * 
	 * @return
	 */
	List<CreditMerchant> selectAllLocalMerchant(CreditMerchant merchant);

	/**
	 * 无条件查询所有有效商户总条数  分页
	 * @return
	 */
	int selectCountAllLocalMerchant(CreditMerchant merchant);

	/**
	 * 条件查询所有有效商户  分页
	 *
	 * @return
	 */
	List<CreditMerchant> selectMerchantByParam(CreditMerchant merchant);

	/**
	 * 条件查询所有有效商户总条数  分页
	 * @return
	 */
	int selectMerchantCountByParam(CreditMerchant merchant);

	/**
	 * 根据查询参数获取商户信息list
	 * @param creditMerchant
	 * @return
	 */
	List<CreditMerchant> queryMerchantListByParam(CreditMerchant creditMerchant);

	/**
	 * 按条件分页查询
	 * @author: dongzhihua
	 * @time: 2018/10/29 18:32:03
	 */
	List<CreditMerchant> pageMerchantByParam(CreditMerchant creditMerchant);
	/**
	 * 按条件查询数目
	 * @author: dongzhihua
	 * @time: 2018/10/31 17:23:35
	 */
	int countMerchantByParam(CreditMerchant creditMerchant);
}