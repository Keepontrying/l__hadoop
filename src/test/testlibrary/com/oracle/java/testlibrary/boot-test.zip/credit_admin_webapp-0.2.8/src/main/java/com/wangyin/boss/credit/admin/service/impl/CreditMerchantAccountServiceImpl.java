package com.wangyin.boss.credit.admin.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wangyin.boss.credit.admin.dao.CreditMerchantAccountMapper;
import com.wangyin.boss.credit.admin.entity.CreditMerchantAccount;
import com.wangyin.boss.credit.admin.service.CreditMerchantAccountService;

@Service
public class CreditMerchantAccountServiceImpl implements CreditMerchantAccountService {
	
	@Autowired
	CreditMerchantAccountMapper creditMerchantAccountMapper;

	@Override
	public String selectAccountNo(int relationId, String chargeType) {
		CreditMerchantAccount creditMerchantAccount = new CreditMerchantAccount();
		creditMerchantAccount.setRelationId(String.valueOf(relationId));
		creditMerchantAccount.setChargeType(chargeType);
		return creditMerchantAccountMapper.selectAccountNo(creditMerchantAccount);
	}

}
