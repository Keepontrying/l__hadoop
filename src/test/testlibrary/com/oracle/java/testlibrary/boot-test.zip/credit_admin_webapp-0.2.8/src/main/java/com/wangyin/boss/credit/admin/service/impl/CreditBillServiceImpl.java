package com.wangyin.boss.credit.admin.service.impl;

import java.util.List;

import com.wangyin.boss.credit.enterprise.beans.CallCaseInfoQueryParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wangyin.boss.credit.admin.dao.CreditBillMapper;
import com.wangyin.boss.credit.admin.entity.CreditBill;
import com.wangyin.boss.credit.admin.service.CreditBillService;
import com.wangyin.boss.credit.enterprise.beans.CallCaseInfo;

@Service
public class CreditBillServiceImpl implements CreditBillService {
	
	@Autowired
	CreditBillMapper creditBillMapper;

	@Override
	public List<CreditBill> selectByParam(CreditBill creditBill) {
		return creditBillMapper.selectByParam(creditBill);
	}

	@Override
	public int selectCountByParam(CreditBill creditBill) {
		return creditBillMapper.selectCountByParam(creditBill);
	}

	@Override
	public List<CreditBill> selectMonthBillByParam(CreditBill creditBill) {
		return creditBillMapper.selectMonthBillByParam(creditBill);
	}

	@Override
	public int selectMonthBillCountByParam(CreditBill creditBill) {
		return creditBillMapper.selectMonthBillCountByParam(creditBill);
	}

	@Override
	public int queryProductBillPageCount(String productName, String beginDate, String endDate) {
		return creditBillMapper.queryProductBillPageCount(productName, beginDate, endDate);
	}

	@Override
	public List<CallCaseInfo> queryProductBillPage(String productName, String beginDate,
			String endDate, Integer start, Integer limit) {
		return creditBillMapper.queryProductBillPage(productName, beginDate, endDate, start, limit);
	}

	@Override
	public int queryMerchantBillPageCount(String merchantName, String merchantNo, String beginDate, String endDate) {
		return creditBillMapper.queryMerchantBillPageCount(merchantName, merchantNo, beginDate, endDate, null);
	}

	@Override
	public List<CallCaseInfo> queryMerchantBillPage(String merchantName, String merchantNo, String beginDate,
			String endDate, Integer start, Integer limit) {
		return creditBillMapper.queryMerchantBillPage(merchantName, merchantNo,beginDate, endDate, null, start, limit);
	}

	@Override
	public int queryMerProBillPageCount(String merchantName, String merchantNo, String productName, String beginDate,
			String endDate) {
		return creditBillMapper.queryMerProBillPageCount(merchantName, merchantNo, productName, beginDate, endDate);
	}

	@Override
	public List<CallCaseInfo> queryMerProBillPage(String merchantName, String merchantNo, String productName,
			String beginDate,
			String endDate, Integer start, Integer limit) {
		return creditBillMapper.queryMerProBillPage(merchantName, merchantNo, productName, beginDate, endDate, start,
				limit);
	}

	@Override
	public CallCaseInfo queryBillFiledsTotalCount(CallCaseInfoQueryParam caseInfoQueryParam) {
		return creditBillMapper.queryBillFiledsTotalCount(caseInfoQueryParam);
	}

}
