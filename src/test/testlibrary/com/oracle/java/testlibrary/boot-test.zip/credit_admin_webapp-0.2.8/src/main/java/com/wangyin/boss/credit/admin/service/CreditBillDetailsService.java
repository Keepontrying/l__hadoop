package com.wangyin.boss.credit.admin.service;

import java.util.List;

import com.wangyin.boss.credit.admin.entity.CreditBillDetails;

/**
 * 
 * @author wyhaozhihong
 *
 */
public interface CreditBillDetailsService {
	
	/**
	 * 查询每日账单详情
	 * @param creditBill
	 * @return
	 */
	List<CreditBillDetails> selectPerDayBillDetails(CreditBillDetails creditBillDetails);
	
	/**
	 * 查询每月账单详情
	 * @param creditBillDetails
	 * @return
	 */
	List<CreditBillDetails> selectPerMonthBillDetails(CreditBillDetails creditBillDetails);

}
