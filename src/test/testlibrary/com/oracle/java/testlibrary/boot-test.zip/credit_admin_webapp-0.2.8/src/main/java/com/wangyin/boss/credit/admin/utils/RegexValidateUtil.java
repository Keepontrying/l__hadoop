package com.wangyin.boss.credit.admin.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @desciption : 正则表达式验证工具类
 * @author : yangjinlin@jd.com
 * @date ：2017年7月14日 下午5:42:18
 * @version 1.0
 * @return
 */
public class RegexValidateUtil {

	/**
	 * 验证邮箱
	 * @param email
	 * @return
	 */
	public static boolean checkEmail(String email) {
		boolean flag = false;
		try {
			String check = "^([a-z0-9A-Z]+[-|_|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
			Pattern regex = Pattern.compile(check);
			Matcher matcher = regex.matcher(email);
			flag = matcher.matches();
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}

	/**
	 * 验证手机号码
	 * 
	 * @param mobiles
	 * @return
	 */
	public static boolean checkMobileNumber(String mobileNumber) {
		boolean flag = false;
		try {
			Pattern regex = Pattern
					.compile("^(((13[0-9])|(14[0-9])|(15([^4,\\D]))|(17[0-9])|(18[0-9]))\\d{8})$");
			Matcher matcher = regex.matcher(mobileNumber);
			flag = matcher.matches();
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}
	/**
	 * 校验18位数字
	 * @param digit
	 * @return
	 */
	public static boolean check18Digit(String digit) {
		boolean flag = false;
		try {
			String check = "^\\d{18}$";
			Pattern regex = Pattern.compile(check);
			Matcher matcher = regex.matcher(digit);
			flag = matcher.matches();
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}
	
	/**
	 * 验证是否为数字
	 * @param str
	 * @return
	 */
	public static boolean checkDigit(String str) {
		boolean flag = false;
		try {
			Pattern regex = Pattern.compile("^[0-9]*$");
			Matcher matcher = regex.matcher(str);
			flag = matcher.matches();
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}
	
	public static boolean checkAmountWith2(String amount) {
		Pattern pattern = Pattern.compile("^(([1-9]{1}\\d*)|([0]{1}))(\\.(\\d){0,2})?$"); // 判断小数点后2位的数字的正则表达式
		Matcher match = pattern.matcher(amount);
		if (match.matches() == false) {
			return false;
		} else {
			return true;
		}
	}
	
	
}
