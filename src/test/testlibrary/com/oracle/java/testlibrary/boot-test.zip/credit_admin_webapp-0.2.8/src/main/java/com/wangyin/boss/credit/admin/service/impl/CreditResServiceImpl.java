package com.wangyin.boss.credit.admin.service.impl;

import java.io.InputStream;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.domain.common.entity.CreditCustoms;
import com.jd.jr.boss.credit.domain.common.enums.CreditMiniAreaCompletionEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditMiniAreaCoverTypeEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditMiniAreaDataSourceEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditMiniAreaPriceTypeEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditMiniAreaProcodeEnum;
import com.jd.jr.boss.credit.facade.authen.api.CreditQueryBatchFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.MiniCommAreaComplDetailQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.MiniCommAreaComplQueryParam;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountConsumeRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountCreateRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountQueryRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountRechargeRequest;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccounTradeResponse;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccountCreateResponse;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccountQueryResponse;
import com.jd.jr.boss.credit.gateway.account.facade.finance.GatewayAccountFacade;
import com.jd.jsf.gd.util.StringUtils;
import com.wangyin.boss.credit.admin.dao.CreditResMapper;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniCommonArea;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniCommonAreaCompletion;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniCommonAreaDetail;
import com.wangyin.boss.credit.admin.enums.CreditOpenStatusEnum;
import com.wangyin.boss.credit.admin.service.CreditResService;
import com.wangyin.boss.credit.admin.utils.ExcelUtil;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;
import com.wangyin.r2m.client.jedis.Jedis;
import com.wangyin.r2m.client.jedis.JedisClusterConnectionHandler;
import com.wangyin.r2m.client.jedis.JedisPool;
import com.wangyin.r2m.client.jedis.ScanParams;
import com.wangyin.r2m.client.jedis.ScanResult;
import com.wangyin.rediscluster.client.CacheClusterClient;
import com.wangyin.rediscluster.experimental.NodesHelper;

/** 
* @desciption : 执行备用sql操作 service接口类
* @author : yangjinlin@jd.com
* @date ：2016年12月8日 下午5:02:51 
* @version 1.0 
* @return  */
@Service
public class CreditResServiceImpl implements CreditResService {
	
	private static Logger logger = LoggerFactory.getLogger(CreditResServiceImpl.class);

	@Autowired
	CreditResMapper creditResMapper;
	
	@Autowired
	GatewayAccountFacade gatewayAccountFacade;

	@Autowired
	protected CacheClusterClient cacheClusterClient;
	
	@Autowired
	public CreditQueryBatchFacade queryBatchFacade;


	@Override
	public boolean updateResOperaBySql(String paramSql) {
		boolean excFlag = false;
		creditResMapper.updateResOperaBySql(paramSql);
		excFlag = true;
		return excFlag;
	}

	@Override
	public ResponseData<GatewayAccountCreateResponse> createAccount4Res(GatewayAccountCreateRequest userIdReqParam) {
		RequestParam<GatewayAccountCreateRequest> accountCreateRequest = new RequestParam<GatewayAccountCreateRequest>();
		accountCreateRequest.setParam(userIdReqParam);
		logger.info("/creditRes/doCreateAccount, call gatewayAccountFacade create requestParam:"+GsonUtil.getInstance().toJson(accountCreateRequest));
		return gatewayAccountFacade.create(accountCreateRequest);
	}

	@Override
	public ResponseData<GatewayAccountQueryResponse> queryAccountInfo4Res(GatewayAccountQueryRequest accountQryReq) {
		RequestParam<GatewayAccountQueryRequest> repParam = new RequestParam<GatewayAccountQueryRequest>();
		repParam.setParam(accountQryReq);
		logger.info("/creditRes/doqryAccount4Res, call gatewayAccountFacade queryAccountInfo requestParam:"+GsonUtil.getInstance().toJson(repParam));
		return gatewayAccountFacade.queryAccountInfo(repParam);
	}

	@Override
	public ResponseData<GatewayAccounTradeResponse> accountRecharge(GatewayAccountRechargeRequest req) {
		RequestParam<GatewayAccountRechargeRequest> repParam = new RequestParam<GatewayAccountRechargeRequest>();
		repParam.setParam(req);
		logger.info("/creditRes/accountRecharge, call gatewayAccountFacade queryAccountInfo requestParam:"+GsonUtil.getInstance().toJson(repParam));
		return gatewayAccountFacade.accountRecharge(repParam);
	}

	@Override
	public ResponseData<GatewayAccounTradeResponse> accountConsume(GatewayAccountConsumeRequest req) {
		RequestParam<GatewayAccountConsumeRequest> repParam = new RequestParam<GatewayAccountConsumeRequest>();
		repParam.setParam(req);
		logger.info("/creditRes/accountConsume, call gatewayAccountFacade queryAccountInfo requestParam:"+GsonUtil.getInstance().toJson(repParam));
		return gatewayAccountFacade.accountConsume(repParam);
	}

	/**
	 * 按照前缀批量设置r2m缓存失效时间
	 *
	 * @param prefixStr
	 */
	@Override
	public void expireKeysR2m(String prefixStr,int ttl) {
		if(StringUtil.isBlank(prefixStr)){
			throw new RuntimeException("key前缀不能为空");
		}

		try {
			ExpireKeysNodesHelper helper=new ExpireKeysNodesHelper(cacheClusterClient.getConnectionHandler(),prefixStr,ttl);
			helper.run();
		} catch (InterruptedException e) {
			e.printStackTrace();
			throw new RuntimeException("批量设置过期时间失败！");
		}
	}

	class ExpireKeysNodesHelper extends NodesHelper{

		private String pattern;
		private int ttl;

		public ExpireKeysNodesHelper(JedisClusterConnectionHandler connectionHandler,String prefixStr,int ttl) {
			super(connectionHandler);
			this.pattern=prefixStr+"*";
			this.ttl=ttl;
		}

		@Override
		public Map<String, JedisPool> setNodes(JedisClusterConnectionHandler jedisClusterConnectionHandler) {
			return jedisClusterConnectionHandler.getNodes();
		}

		@Override
		public Object handle(Jedis jedis) {
			String scanCursor="0";
			do {
				ScanResult<String> result = jedis.scan(scanCursor, new ScanParams().match(pattern));
				List<String> keyList= result.getResult();
				for(String key:keyList){
					jedis.expire(key,ttl);
				}
				scanCursor=result.getCursor();
			}while(!scanCursor.equals("0"));
			return null;
		}

		@Override
		public void handleException(String s, Exception e) {

		}
	}

	@Override
	public Map<String, Object> insertMiniAreasExcel(InputStream is, Boolean isExcel2003) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		ExcelUtil excelUtil = new ExcelUtil();
        List<List<String>> dataList = null;
        try {
			Integer skipRow = 1;
            dataList = excelUtil.read(is, isExcel2003, skipRow);
            for (List<String> data : dataList) {
                if (data.size() == 0 || StringUtil.isBlank(data.get(0).trim())) {
                    continue;
                }
                while(data.size()<14){
                    data.add(null);
                }
                Long areaNo4Pr = Long.valueOf(data.get(0).trim());
                String prName = data.get(1).trim();
                Long areaNo4Ci = Long.valueOf(data.get(2).trim());
                String ciName = data.get(3).trim();
                Long areaNo4Di = Long.valueOf(data.get(4).trim());
                String diName = data.get(5).trim();
                String coverTypeCell = data.get(7).trim();
                String govSeatCell = data.get(8).trim();
                String completionCell = data.get(9).trim();
                String priceTypeCell = data.get(11).trim();
                String districtCenterCell = data.get(13).trim();
                
                MiniCommAreaComplQueryParam detailQueryPrm4Pr = new MiniCommAreaComplQueryParam();
                detailQueryPrm4Pr.setValidStatus(CreditOpenStatusEnum.OPEN.toName());
                detailQueryPrm4Pr.setDataSource(CreditMiniAreaDataSourceEnum.SHUZHE.toName());
                detailQueryPrm4Pr.setProcode(CreditMiniAreaProcodeEnum.PR.toName());
                detailQueryPrm4Pr.setAreaNo(areaNo4Pr);
                detailQueryPrm4Pr.setAreaName(prName);
                List<CreditMiniCommonArea> prList = queryBatchFacade.queryValidMiniAreaList(detailQueryPrm4Pr);
                if(CollectionUtils.isEmpty(prList)){
                	CreditMiniCommonArea pr = new CreditMiniCommonArea();
                	pr.setAreaNo(areaNo4Pr);
                	pr.setAreaName(prName);
                	pr.setPid(0L);
                	pr.setDisorder(0);
                	pr.setProcode(CreditMiniAreaProcodeEnum.PR.toName());
                	pr.setValidStatus(CreditOpenStatusEnum.OPEN.toName());
                	pr.setGovSeat(govSeatCell);
                	pr.setDistrictCenter(districtCenterCell);
                	pr.setDataSource(CreditMiniAreaDataSourceEnum.SHUZHE.toName());
                	Integer areaId = queryBatchFacade.addMiniAreas(pr);
                }
                
                MiniCommAreaComplQueryParam detailQueryPrm4Ci = new MiniCommAreaComplQueryParam();
                detailQueryPrm4Ci.setValidStatus(CreditOpenStatusEnum.OPEN.toName());
                detailQueryPrm4Ci.setDataSource(CreditMiniAreaDataSourceEnum.SHUZHE.toName());
                detailQueryPrm4Ci.setProcode(CreditMiniAreaProcodeEnum.CI.toName());
                detailQueryPrm4Ci.setAreaNo(areaNo4Ci);
                detailQueryPrm4Ci.setAreaName(ciName);
                detailQueryPrm4Ci.setPid(areaNo4Pr);
                List<CreditMiniCommonArea> ciList = queryBatchFacade.queryValidMiniAreaList(detailQueryPrm4Ci);
                if(CollectionUtils.isEmpty(ciList)){
                	CreditMiniCommonArea ci = new CreditMiniCommonArea();
                	ci.setAreaNo(areaNo4Ci);
                	ci.setAreaName(ciName);
                	ci.setPid(areaNo4Pr);
                	ci.setDisorder(0);
                	ci.setProcode(CreditMiniAreaProcodeEnum.CI.toName());
                	ci.setValidStatus(CreditOpenStatusEnum.OPEN.toName());
                	ci.setGovSeat(govSeatCell);
                	ci.setDistrictCenter(districtCenterCell);
                	ci.setDataSource(CreditMiniAreaDataSourceEnum.SHUZHE.toName());
                	Integer areaId = queryBatchFacade.addMiniAreas(ci);
                }
                MiniCommAreaComplQueryParam detailQueryPrm4Di = new MiniCommAreaComplQueryParam();
                detailQueryPrm4Di.setValidStatus(CreditOpenStatusEnum.OPEN.toName());
                detailQueryPrm4Di.setDataSource(CreditMiniAreaDataSourceEnum.SHUZHE.toName());
                detailQueryPrm4Di.setProcode(CreditMiniAreaProcodeEnum.DI.toName());
                detailQueryPrm4Di.setAreaNo(areaNo4Di);
                detailQueryPrm4Di.setAreaName(diName);
                detailQueryPrm4Di.setPid(areaNo4Ci);
                detailQueryPrm4Di.setPriceType(CreditMiniAreaPriceTypeEnum.enumValueOf(Integer.valueOf(priceTypeCell)).toName());
                List<CreditMiniCommonArea> diList = queryBatchFacade.queryValidAreaListByPrm(detailQueryPrm4Di);
                if(CollectionUtils.isEmpty(diList)){
                	CreditMiniCommonArea di = new CreditMiniCommonArea();
                	di.setAreaNo(areaNo4Di);
                	di.setAreaName(diName);
                	di.setPid(areaNo4Ci);
                	di.setDisorder(0);
                	di.setProcode(CreditMiniAreaProcodeEnum.DI.toName());
                	di.setValidStatus(CreditOpenStatusEnum.OPEN.toName());
                	di.setCoverType(CreditMiniAreaCoverTypeEnum.enumValueOfByDesc(coverTypeCell).toName());
                	di.setGovSeat(govSeatCell);
                	di.setPriceType(CreditMiniAreaPriceTypeEnum.enumValueOf(Integer.valueOf(priceTypeCell)).toName());
                	di.setDistrictCenter(districtCenterCell);
                	di.setDataSource(CreditMiniAreaDataSourceEnum.SHUZHE.toName());
                	Integer areaId = queryBatchFacade.addMiniAreas(di);
                	if(null != areaId && areaId != 0 && StringUtils.isNotBlank(di.getProcode())
        			&& di.getProcode().equalsIgnoreCase(CreditMiniAreaProcodeEnum.DI.toName())){
		        		CreditMiniCommonAreaCompletion areaCompletionEntity = new CreditMiniCommonAreaCompletion();
		        		areaCompletionEntity.setAreaId(areaId);
		        		areaCompletionEntity.setCompletionId(CreditMiniAreaCompletionEnum.enumValueOf(completionCell).toCode());//completionCell
		        		areaCompletionEntity.setValidStatus(CreditOpenStatusEnum.OPEN.toName());
		        		Integer areaCompletionId = queryBatchFacade.addMiniAreasCompletion(areaCompletionEntity);
					}
                }
            }
            resultMap.put("success", true);
        } catch (Exception e) {
            logger.error("insertMiniAreasExcel handle fail, " , e);
            e.printStackTrace();
        }
        return resultMap;
	}
	

}
