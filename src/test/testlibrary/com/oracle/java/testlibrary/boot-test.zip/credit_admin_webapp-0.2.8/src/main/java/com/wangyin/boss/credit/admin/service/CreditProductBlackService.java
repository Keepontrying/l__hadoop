package com.wangyin.boss.credit.admin.service;

import com.wangyin.boss.credit.admin.entity.CreditChangeRecord;
import com.wangyin.boss.credit.admin.entity.CreditProductBlack;
import com.wangyin.boss.credit.admin.entity.CreditProductConfig;

import java.util.List;
import java.util.Map;

/** 
* @desciption : 产品黑名单接口方法
* @author : liuwei55@jd.com
* @date ：2017年4月10日 下午20:37:55
* @version 1.0 
* @return  */
public interface CreditProductBlackService {


	/**
	 *@desc 根据查询条件查询  产品黑名单配置  分页
	 *@param creditProductBlack
	 *@Author liuwei55@jd.com
	 *@Date 2017/4/10 20:39
	 */
	List<CreditProductBlack> selectCreProdBlackByPams(CreditProductBlack creditProductBlack);

	/**
	 * 根据查询条件查询  产品黑名单配置  总条数
	 * @param creditProductBlack
	 * @return
	 */
	int selectCountByParam(CreditProductBlack creditProductBlack);
	/**
	 * 根据产品黑名单表主键 black_id更新
	 * @param creditProductBlack
	 * @return
	 * @throws Exception
	 */
	int updateCredProdBlackById(CreditProductBlack creditProductBlack) throws Exception;

	/**
	 * 根据查询条件查询  产品黑名单配置 分页
	 * @param blackId
	 * @return
	 */
	CreditProductBlack selectCredProdBlackById(int blackId);
	/**
	 * 插入产品黑名单
	 * @param creditProductBlack
	 * @return
	 * @throws Exception
	 */
	int insertCredProdBlack(CreditProductBlack creditProductBlack);
	/**
	 * 根据查询条件查询  产品黑名单配置
	 * @param productId
	 * @return
	 */
	CreditProductBlack selectCredProdBlackByProMerId(Map<String,Integer> map);

}
