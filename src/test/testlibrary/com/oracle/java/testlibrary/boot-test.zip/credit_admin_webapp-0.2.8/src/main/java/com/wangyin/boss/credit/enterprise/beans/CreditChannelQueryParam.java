package com.wangyin.boss.credit.enterprise.beans;

import com.wangyin.operation.common.beans.PageQuery;

import java.io.Serializable;

public class CreditChannelQueryParam extends PageQuery implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer channelId;
    private String channelName;
    private String channelSubject;
    private String channelProd;
    private String creator;
    private String channelStatus;
    private String starttime;
    private String endtime;
    private String remark;

    public Integer getChannelId() {
        return channelId;
    }

    public void setChannelId(Integer channelId) {
        this.channelId = channelId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getChannelSubject() {
        return channelSubject;
    }

    public void setChannelSubject(String channelSubject) {
        this.channelSubject = channelSubject;
    }

    public String getChannelProd() {
        return channelProd;
    }

    public void setChannelProd(String channelProd) {
        this.channelProd = channelProd;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getChannelStatus() {
        return channelStatus;
    }

    public void setChannelStatus(String channelStatus) {
        this.channelStatus = channelStatus;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }
}
