package com.wangyin.boss.credit.admin.entity;

/**
 * 
 * @author wyhaozhihong
 *
 */
public class CmAccount {
	
	/**
	 * 账户代码
	 */
	private String id;
	
	/**
	 * 商户名称
	 */
	private String name;
	
	/**
	 * 商户号
	 */
	private String owner;
	
	/**
	 * 二级商户号 
	 */
	private String orgcode;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getOrgcode() {
		return orgcode;
	}

	public void setOrgcode(String orgcode) {
		this.orgcode = orgcode;
	}
	
}
