package com.wangyin.boss.credit.enterprise.beans;

import java.io.Serializable;

/**
 * 爬虫任务返回结果
 *
 * @author huangzhiqiang
 * @data 2018/11/19
 */
public class CrawlerJobResults extends CrawlerJob implements Serializable {

    /**
     * 任务标识
     */
    private Long jobId;
    /**
     * 任务流水
     */
    private String jobNo;
    /**
     * 文章标题
     */
    private String articleTitle;
    /**
     * 文章URL
     */
    private String articleUrl;
    /**
     * 总词频
     */
    private Integer totalHit;
    /**
     * 任务总评分
     */
    private Integer score;

    public Long getJobId() {
        return jobId;
    }

    public void setJobId(Long jobId) {
        this.jobId = jobId;
    }

    public String getJobNo() {
        return jobNo;
    }

    public void setJobNo(String jobNo) {
        this.jobNo = jobNo;
    }

    public String getArticleTitle() {
        return articleTitle;
    }

    public void setArticleTitle(String articleTitle) {
        this.articleTitle = articleTitle;
    }

    public String getArticleUrl() {
        return articleUrl;
    }

    public void setArticleUrl(String articleUrl) {
        this.articleUrl = articleUrl;
    }

    public Integer getTotalHit() {
        return totalHit;
    }

    public void setTotalHit(Integer totalHit) {
        this.totalHit = totalHit;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

}
