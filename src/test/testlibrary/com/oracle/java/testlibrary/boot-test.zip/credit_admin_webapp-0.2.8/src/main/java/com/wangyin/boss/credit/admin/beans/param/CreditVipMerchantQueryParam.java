package com.wangyin.boss.credit.admin.beans.param;

import java.io.Serializable;

/** 
* @desciption : 
* @author : yangjinlin@jd.com
* @date ：2017年6月28日 下午7:01:50 
* @version 1.0 
* @return  */
public class CreditVipMerchantQueryParam extends PageQueryParam implements Serializable {

	private static final long serialVersionUID = -4739313902256922885L;
	
	/**
	 * 商户号
	 */
	private String merchantNo;
	/**
	 * 商户名称
	 */
    private String merchantName;

	 /*--------- 下方参数为前后台映射使用-----------*/
    
    /**
     * 创建开始时间,查询条件中时间控件输入框使用
     */
    private String startModifiedDateStr;
    
    /**
     * 创建结束时间,查询条件中时间控件输入框使用
     */
    private String endModifiedDateStr;

	public String getMerchantNo() {
		return merchantNo;
	}

	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getStartModifiedDateStr() {
		return startModifiedDateStr;
	}

	public void setStartModifiedDateStr(String startModifiedDateStr) {
		this.startModifiedDateStr = startModifiedDateStr;
	}

	public String getEndModifiedDateStr() {
		return endModifiedDateStr;
	}

	public void setEndModifiedDateStr(String endModifiedDateStr) {
		this.endModifiedDateStr = endModifiedDateStr;
	}
    
    
	
	
}
