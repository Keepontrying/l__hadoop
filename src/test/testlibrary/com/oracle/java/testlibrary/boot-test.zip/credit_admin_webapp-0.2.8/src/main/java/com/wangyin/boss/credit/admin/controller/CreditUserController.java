package com.wangyin.boss.credit.admin.controller;

import java.util.*;

import com.chinabank.core.utils.StringUtil;
import com.jd.jr.boss.credit.domain.common.enums.CreditYesOrNoEnum;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.boss.credit.admin.enums.CreditUserEnum;
import com.wangyin.boss.credit.admin.service.CreditUserService;

/**
 * 用户相关
 * @author jiangbo
 * @since 20170317
 */
@Controller
@RequestMapping("/creditUser")
public class CreditUserController extends BaseController {

	private static Logger logger = LoggerFactory.getLogger(CreditUserController.class);

	@Autowired
	private CreditUserService creditUserService;

	@ResponseBody
	@RequestMapping("doQueryCreditUser.do")
	public Map<String, Object> doQueryAuditContract(@RequestParam Map<String, Object> map, CreditUser creditUser){
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");
		creditUser.setUserStatus(CreditUserEnum.OPEN.getCode());

		try {
			List<CreditUser> creditUserList = creditUserService.selectCreditUserByParam(creditUser);
			int creditUserCount = creditUserService.selectCreditUserCountByParam(creditUser);
			resultMap.put("rows", creditUserList);
			resultMap.put("total", creditUserCount);
		}catch (Exception e){
			logger.error("doQueryCreditUser error,creditUser:{}", creditUser, e);
			resultMap.put("rows", new ArrayList<CreditUser>());
			resultMap.put("total", 0);
			resultMap.put("success", false);
			resultMap.put("message", "异常，请稍后重试");
		}

		return resultMap;
	}

	/**
	 * 编辑用户对接信息
	 * @param map
	 * @param user session信息
	 * @param creditUser 用户信息
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doEditUserInfo.do")
	public Map<String, Object> doEditUserInfo(@RequestParam Map<String, Object> map, String user, CreditUser creditUser) {
		Map<String, Object> resultMap = new HashMap<String, Object>();

		String userName = null;
		try {
			//userName是登录名,RealName是中文别名,getLoginRealName()返回的是userName
			userName = getLoginRealName(user);
		} catch (Exception e) {
			logger.error(e.getMessage());
			userName = "error";
		}
		try {
			int count = creditUserService.modifyUserByPrimaryKey(creditUser);
			if(count == 1){
				resultMap.put("success", true);
				resultMap.put("message", "操作成功");
				return resultMap;
			}else{
				resultMap.put("success", false);
				resultMap.put("message", "操作失败");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			resultMap.put("success", false);
			resultMap.put("message", "操作异常");
		}
		return resultMap;
	}

	

}
