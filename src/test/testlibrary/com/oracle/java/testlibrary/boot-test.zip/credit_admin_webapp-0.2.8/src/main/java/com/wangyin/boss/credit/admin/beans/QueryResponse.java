package com.wangyin.boss.credit.admin.beans;

import java.io.Serializable;

public class QueryResponse implements Serializable{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：QueryResponse.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -5713540231308630930L;
	
	private String responseCode;
	
	private String message;
	
	private String data;
	
	private String successful;

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getSuccessful() {
		return successful;
	}

	public void setSuccessful(String successful) {
		this.successful = successful;
	}
	
	
}
