package com.wangyin.boss.credit.admin;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wangyin.boss.credit.admin.dao.CreditContractMapper;
import com.wangyin.boss.credit.admin.entity.CreditContract;

/**
 * 合同表dao接口测试类
 * 
 * @author wyhaozhihong
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:applicationContext.xml" })
public class CreditContractMapperTest {

	@Autowired
	CreditContractMapper creditContractMapper;
	
	@Test
	public void selectByParamTest(){
		CreditContract creditContract = new CreditContract();
		creditContract.setStart("0");
		creditContract.setLimit("10");
		List<CreditContract> list = creditContractMapper.selectByParam(creditContract);
		System.out.println(list.size());
	}
	
	@Test
	public void selectCountByParamTest(){
		CreditContract creditContract = new CreditContract();
		int count = creditContractMapper.selectCountByParam(creditContract);
		System.out.println(count);
	}
	
	@Test
	public void updateByPrimaryKeyTest(){
		CreditContract record = new CreditContract();
		record.setContractId(1);
		record.setContractStatus("cancel");
		int count = creditContractMapper.updateByPrimaryKeySelective(record);
		System.out.println(count);
	}

}
