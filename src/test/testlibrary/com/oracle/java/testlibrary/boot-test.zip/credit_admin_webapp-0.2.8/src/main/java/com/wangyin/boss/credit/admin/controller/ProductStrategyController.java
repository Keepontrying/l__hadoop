package com.wangyin.boss.credit.admin.controller;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wangyin.boss.credit.admin.entity.CreditItem;
import com.wangyin.boss.credit.admin.entity.CreditItemSku;
import com.wangyin.boss.credit.admin.service.CreditItemService;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.jr.boss.credit.domain.common.enums.CreditStrategyStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.OpenOrCloseStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.ProductTableEnum;
import com.wangyin.boss.credit.admin.beans.TextValuePairs;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import com.wangyin.boss.credit.admin.enums.ChargeTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditProductStrategySegmentTypeEnum;
import com.wangyin.boss.credit.admin.service.CreditChangeRecordService;
import com.wangyin.boss.credit.admin.service.CreditProductStrategyService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

import javax.annotation.Resource;

/**
 * 产品策略配置controller
 * @author wyhaozhihong
 * @since 2016-07-05
 *
 */
@Controller
@RequestMapping("/productStrategy")
public class ProductStrategyController extends BaseController{

	private static Logger LOGGER = LoggerFactory.getLogger(ProductStrategyController.class);
	
	@Autowired
	CreditProductStrategyService creditProductStrategyService;
	
	@Autowired
	CreditChangeRecordService creditChangeRecordService;

	@Resource
	private CreditItemService itemService;
	
	/**
	 * 查询产品服务配置  分页
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryProductConfig.do")
	public Map<String, Object> doQueryProductConfig(@RequestParam Map<String, String> map, CreditProductStrategy creditProductStrategy) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		String strategyIdStr = map.get("strategyIdStr");
		if(StringUtils.isNotBlank(strategyIdStr)){
			creditProductStrategy.setStrategyIds(Arrays.asList(strategyIdStr.substring(1).split("&")));
		}
		try {
			List<CreditProductStrategy> creditProductStrategyList = creditProductStrategyService.selectByParam(creditProductStrategy);
			for (CreditProductStrategy creditProductStrategy2 : creditProductStrategyList) {
				creditProductStrategy2.setChargeType(ChargeTypeEnum.enumValueOf(creditProductStrategy2.getChargeType()).toDescription());
				creditProductStrategy2.setStartTimeStr(sdf.format(creditProductStrategy2.getStartTime()));
				creditProductStrategy2.setFinishTimeStr(sdf.format(creditProductStrategy2.getFinishTime()));

			}
			int creditProductStrategyCount = creditProductStrategyService.selectCountByParam(creditProductStrategy);
			resultMap.put("rows", creditProductStrategyList);
			resultMap.put("total", creditProductStrategyCount);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditProductStrategy>());
			resultMap.put("total", 0);
		}
		
		return resultMap;
	}

	/**
	 * 查询产品服务配置  分页 带标准价格
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryProductConfigWithStdPrice.do")
	public Map<String, Object> doQueryProductConfigWithStdPrice(@RequestParam Map<String, String> map, CreditProductStrategy creditProductStrategy) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		String strategyIdStr = map.get("strategyIdStr");
		if(StringUtils.isNotBlank(strategyIdStr)){
			creditProductStrategy.setStrategyIds(Arrays.asList(strategyIdStr.substring(1).split("&")));
		}
		try {
            creditProductStrategy.setMerchantName(null);//无需根据商户名称进行筛选,防止商户变更名称后已购买内容无法查出
			List<CreditProductStrategy> creditProductStrategyList = creditProductStrategyService.selectByParam(creditProductStrategy);

			//生成标准价格的一个map product:custom_price
			Map<Integer,Long> priceMap=new HashMap<Integer, Long>();
			CreditItem creditItem=new CreditItem();
			creditItem.setLimit("9999999");
			creditItem.setItemStatus("SHELVE");
			List<CreditItem> itemList=itemService.selectItemAndSkuByParam(creditItem);
			for(CreditItem item:itemList){
				//取其中chargeType为custom的sku的价格
				List<CreditItemSku> skuList=item.getCreditItemSkuList();
				for(CreditItemSku sku:skuList){
					if(ChargeTypeEnum.CUSTOM.toName().equals(sku.getChargeType())){
						priceMap.put(item.getProductId(),sku.getCustomPrice());
					}
				}
			}
			List<CreditProductStrategy> creditProductStrategyListNotSingle = new ArrayList<CreditProductStrategy>();
			for (CreditProductStrategy creditProductStrategy2 : creditProductStrategyList) {
				creditProductStrategy2.setChargeType(ChargeTypeEnum.enumValueOf(creditProductStrategy2.getChargeType()).toDescription());
				creditProductStrategy2.setStartTimeStr(sdf.format(creditProductStrategy2.getStartTime()));
				creditProductStrategy2.setFinishTimeStr(sdf.format(creditProductStrategy2.getFinishTime()));
				if(priceMap.containsKey(creditProductStrategy2.getProductId())){
					creditProductStrategy2.setStandardPrice(priceMap.get(creditProductStrategy2.getProductId()));
				}
				if(!creditProductStrategy2.getChargeType().equalsIgnoreCase(ChargeTypeEnum.SINGLE.toDescription())){
					creditProductStrategyListNotSingle.add(creditProductStrategy2);
				}
			}
			
			int creditProductStrategyCount = creditProductStrategyService.selectCountByParam(creditProductStrategy);
			resultMap.put("rows", creditProductStrategyListNotSingle);//  creditProductStrategyList
			resultMap.put("total", creditProductStrategyCount-creditProductStrategyListNotSingle.size());
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditProductStrategy>());
			resultMap.put("total", 0);
		}

		return resultMap;
	}
	
	/**
	 * 合同编辑页面 查询产品服务配置  分页
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryProductConfig1.do")
	public Map<String, Object> doQueryProductConfig1(@RequestParam Map<String, String> map, CreditProductStrategy creditProductStrategy) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		String strategyIdStr = map.get("strategyIdStr");
		if(StringUtils.isNotBlank(strategyIdStr)){
			creditProductStrategy.setStrategyIds(Arrays.asList(strategyIdStr.substring(1).split("&")));
		}
		try {
			creditProductStrategy.setMerchantNo(null);
			creditProductStrategy.setMerchantName(null);
			List<CreditProductStrategy> creditProductStrategyList = creditProductStrategyService.selectByParam(creditProductStrategy);
			for (CreditProductStrategy creditProductStrategy2 : creditProductStrategyList) {
				creditProductStrategy2.setChargeType(ChargeTypeEnum.enumValueOf(creditProductStrategy2.getChargeType()).toDescription());
				creditProductStrategy2.setStartTimeStr(sdf.format(creditProductStrategy2.getStartTime()));
				creditProductStrategy2.setFinishTimeStr(sdf.format(creditProductStrategy2.getFinishTime()));
				
			}
			int creditProductStrategyCount = creditProductStrategyService.selectCountByParam(creditProductStrategy);
			resultMap.put("rows", creditProductStrategyList);
			resultMap.put("total", creditProductStrategyCount);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditProductStrategy>());
			resultMap.put("total", 0);
		}
		
		return resultMap;
	}
	
	/**
	 * 创建新计费策略
	 * @author wyhaozhihong
	 * @param map
	 * @param creditProductStrategy
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doSubmitAddFeeCfg.do")
	public Map<String, Object> doSubmitAddFeeCfg(@RequestParam Map<String, Object> map, String user,
			CreditProductStrategy creditProductStrategy, CreditContract creditContract) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "创建新计费策略成功");
		
		String userName = null;
		try {
			userName = getLoginRealName(user);
		} catch (Exception e) {
			LOGGER.error(e);
			userName = "error";
		}

		/* 非空校验 */
		boolean verifyResult = notNullVerification(creditProductStrategy);
		if (!verifyResult) {
			resultMap.put("success", false);
			resultMap.put("message", "带*的输入框全为必填项！");
			return resultMap;
		}
		
		initCreditProductStrategy(creditProductStrategy, userName);
		
		/* 给CreditProductStrategy实体赋值 */
		try {
			convertCreditProductStrategy(creditProductStrategy, creditContract);
		} catch (Exception e) {
			resultMap.put("success", false);
			resultMap.put("message", e.getMessage());
			return resultMap;
		}

		/* 提交 */
		int count = creditProductStrategyService.insert(creditProductStrategy);
		LOGGER.info("新增加计费的id：" + creditProductStrategy.getStrategyId());
		if (count == 0) {
			resultMap.put("success", false);
			resultMap.put("message", "创建新计费策略失败");
			return resultMap;
		}
		resultMap.put("strategyId", creditProductStrategy.getStrategyId());
		return resultMap;
	}
	
	/**
	 * 删除计费策略
	 * @author wyhaozhihong
	 * @param map
	 * @param strategyId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doDelProductStrategy.do")
	public Map<String, Object> doDelProductStrategy(@RequestParam Map<String, Object> map, String strategyId) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "删除成功");
		int count = creditProductStrategyService.deleteByStrategyId(Integer.valueOf(strategyId));
		if(count != 1){
			resultMap.put("success", false);
			resultMap.put("message", "删除失败");
		}
		return resultMap;
	}
	
	/**
	 * 修改计费策略
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doEditProductStrategy.do")
	public Map<String, Object> doEditProductStrategy(@RequestParam Map<String, Object> map, String user,
			CreditProductStrategy creditProductStrategy, CreditContract creditContract) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "修改成功");
		
		String operator = null;
		try {
			operator = getLoginRealName(user);
		} catch (Exception e) {
			LOGGER.error(e);
			operator = "error";
		}
		
		/* 给CreditProductStrategy实体赋值 */
		try {
			/* 非空校验 */
			boolean verifyResult = notNullVerification(creditProductStrategy);
			if (!verifyResult) {
				resultMap.put("success", false);
				resultMap.put("message", "带*的输入框全为必填项！");
				return resultMap;
			}
			convertCreditProductStrategy(creditProductStrategy, creditContract);
		} catch (Exception e) {
			resultMap.put("success", false);
			resultMap.put("message", e.getMessage());
			return resultMap;
		}
		creditProductStrategy.setModifier(operator);
		creditProductStrategy.setMerchantNo(String.valueOf(map.get("merchantNo")));
		creditProductStrategy.setMerchantName(String.valueOf(map.get("merchantName")));
		
		int count = creditProductStrategyService.updateByStrategyId(creditProductStrategy);
		if(count != 1){
			resultMap.put("success", false);
			resultMap.put("message", "修改失败");
		}
		return resultMap;
	}
	
	/**
	 * 创建新计费策略页面
	 */
	@ResponseBody
	@RequestMapping("toAddFeeCfg.view")
	public Map<String, Object> toAddFeeCfg(@RequestParam Map<String, Object> map) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		
		if(map.get("strategyId") != null){
			CreditProductStrategy creditProductStrategy = creditProductStrategyService.selectByStrategyId(Integer.valueOf(String.valueOf(map.get("strategyId"))));
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			
			creditProductStrategy.setAmountStr(new BigDecimal(creditProductStrategy.getAmount()).divide(new BigDecimal("100")).toString());
			creditProductStrategy.setPriceStr(new BigDecimal(creditProductStrategy.getPrice()).divide(new BigDecimal("100")).toString());
			creditProductStrategy.setStartTimeStr(df.format(creditProductStrategy.getStartTime()));
			creditProductStrategy.setFinishTimeStr(df.format(creditProductStrategy.getFinishTime()));
			resultMap.put("creditProductStrategy", creditProductStrategy);
			resultMap.put("startDateTimeStr", map.containsKey("startDateTimeStr") ? map.get("startDateTimeStr").toString() : "");//startDateTimeStr
			resultMap.put("finishDateTimeStr", map.containsKey("finishDateTimeStr") ? map.get("finishDateTimeStr").toString() : "");//finishDateTimeStr
			resultMap.put("merchantNo", map.containsKey("merchantNo") ? map.get("merchantNo").toString() : "");//修改时从页面获取 最新商户 信息
			resultMap.put("merchantName", map.containsKey("merchantName") ? map.get("merchantName").toString() : "");//merchantName
			return resultMap;
		}
		return map;
	}
	
	/**
	 * 根据id查看计费策略详情
	 * @author yangjinlin5
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toQueryProductStrategyDetail.view")
	public Map<String, Object> toQueryProductStrategyDetail(@RequestParam Map<String, Object> map) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Integer strategyId = Integer.valueOf(String.valueOf(map.get("strategyId")));
		CreditProductStrategy cps = creditProductStrategyService.selectByStrategyId(strategyId);
		cps.setStrategyStatus(CreditStrategyStatusEnum.enumValueOf(cps.getStrategyStatus()).toDescription());
		resultMap.put("creditProductStrategy", cps);
		return resultMap;
	}
	
	/**
	 * 参数类型转换
	 * @param creditProductStrategy
	 * @param creditContract 
	 */
	private void convertCreditProductStrategy(CreditProductStrategy creditProductStrategy, CreditContract creditContract) throws Exception {
		try {
			if(null == creditProductStrategy.getStartTimeStr() || "".equals(creditProductStrategy.getStartTimeStr())){
				creditProductStrategy.setStartTimeStr(creditContract.getStartDateTimeStr()); 
			}
			if(null == creditProductStrategy.getFinishTimeStr() || "".equals(creditProductStrategy.getFinishTimeStr())){
				creditProductStrategy.setFinishTimeStr(creditContract.getFinishDateTimeStr());
			}
			if(creditContract.getStartDateTimeStr().compareTo(creditProductStrategy.getStartTimeStr()) > 0 || 
					creditProductStrategy.getFinishTimeStr().compareTo(creditContract.getFinishDateTimeStr()) > 0){
				throw new Exception("计费有效期必须在合同有效期内");
			}
			Date startTime = DateUtils.parseDate(creditProductStrategy.getStartTimeStr(), new String[]{"yyyy-MM-dd"});
			Date finishTime = DateUtils.parseDate(creditProductStrategy.getFinishTimeStr(), new String[]{"yyyy-MM-dd"});
			creditProductStrategy.setStartTime(startTime);
			creditProductStrategy.setFinishTime(finishTime);
			if("package".equalsIgnoreCase(creditProductStrategy.getChargeType())){
				creditProductStrategy.setPriceStr("0");
			}else{
				creditProductStrategy.setPacketCount(0);
				creditProductStrategy.setAmountStr("0");
			}
			BigDecimal bg = new BigDecimal("100");
			creditProductStrategy.setAmount(new BigDecimal(creditProductStrategy.getAmountStr()).multiply(bg).longValue());
			creditProductStrategy.setPrice(new BigDecimal(creditProductStrategy.getPriceStr()).multiply(bg).longValue());
		} catch (Exception e) {
			LOGGER.error(e);
			throw new Exception(e.getMessage());
		}
	}

	private void initCreditProductStrategy(CreditProductStrategy creditProductStrategy, String operator) {
		/* 默认值 */
		creditProductStrategy.setCreator(operator);
		creditProductStrategy.setCreatedDate(new Date());
		creditProductStrategy.setModifier(operator);
		creditProductStrategy.setModifiedDate(new Date());

		/* 设置默认值，创建完合同后需要更新成具体值 */
		creditProductStrategy.setContractId(0);
		creditProductStrategy.setMerchantId(0);
		creditProductStrategy.setStrategyStatus(OpenOrCloseStatusEnum.CLOSE.toName());//close
		creditProductStrategy.setMerchantNo(creditProductStrategy.getMerchantNo() == null ? "null" : creditProductStrategy.getMerchantNo());
		creditProductStrategy.setMerchantName(creditProductStrategy.getMerchantName() == null ? "null" : creditProductStrategy.getMerchantName());
	}

	/**
	 * 校验CreditProductStrategy实体的必填项
	 * @param creditProductStrategy
	 */
	private boolean notNullVerification(CreditProductStrategy creditProductStrategy) {
		
		if ("package".equalsIgnoreCase(creditProductStrategy.getChargeType())) {
			if (StringUtils.isBlank(creditProductStrategy.getAmountStr()) || creditProductStrategy.getPacketCount() == null) {
				return false;
			}
		}else{
			if (StringUtils.isBlank(creditProductStrategy.getPriceStr())){
				return false;
			}
		}
		if(ProductTableEnum.IDENTITY_VERIFY.toCode().equals(creditProductStrategy.getProductId())){
			if(StringUtils.isBlank(creditProductStrategy.getSegmentType())){
				return false;
			}
		}
		
		return true;
	}
	
	/**
	 * 征信产品计费策略细分类型枚举类中获取细分列表
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryCreditProductStrategySegmentTypeEnum.do")
	public Map<String, Object> queryCreditProductStrategySegmentTypeEnum(@RequestParam Map<String, Object> map, CreditProductStrategy creditProductStrategy) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<TextValuePairs> productStrategySegmentTypeList = new ArrayList<TextValuePairs>();
		try {
			for(CreditProductStrategySegmentTypeEnum status : CreditProductStrategySegmentTypeEnum.values()){
				if(null == status.toName() || "NULL".equals(status.toName())){
					continue;
				}else{
					TextValuePairs pairs = new TextValuePairs(status.toDescription(), status.toName());
					productStrategySegmentTypeList.add(pairs);
				}
			}
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "操作异常");
		}
		resultMap.put("productStrategySegmentTypeList", productStrategySegmentTypeList);
		return resultMap;
	}
	
}
