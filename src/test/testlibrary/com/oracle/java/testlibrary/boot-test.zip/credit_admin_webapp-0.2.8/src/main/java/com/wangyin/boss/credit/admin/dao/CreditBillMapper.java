package com.wangyin.boss.credit.admin.dao;

import java.util.List;

import com.wangyin.boss.credit.enterprise.beans.CallCaseInfoQueryParam;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditBill;
import com.wangyin.boss.credit.enterprise.beans.CallCaseInfo;

@SqlMapper
@Component
public interface CreditBillMapper {

	List<CreditBill> selectByParam(CreditBill creditBill);

	int selectCountByParam(CreditBill creditBill);
	
	List<CreditBill> selectMonthBillByParam(CreditBill creditBill);

	int selectMonthBillCountByParam(CreditBill creditBill);
	
	int insert(CreditBill record);

	int queryProductBillPageCount(@Param("productName") String productName,
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate);

	List<CallCaseInfo> queryProductBillPage(@Param("productName") String productName,
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate, @Param("start") Integer start, @Param("limit") Integer limit);

	int queryMerchantBillPageCount(@Param("merchantName") String merchantName, @Param("merchantNo") String merchantNo,
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate, @Param("merchantClassify") String merchantClassify);

	List<CallCaseInfo> queryMerchantBillPage(@Param("merchantName") String merchantName,
			@Param("merchantNo") String merchantNo,
			@Param("beginDate") String beginDate,
			@Param("endDate") String endDate, @Param("merchantClassify") String merchantClassify, @Param("start") Integer start, @Param("limit") Integer limit);

	int queryMerProBillPageCount(@Param("merchantName") String merchantName, @Param("merchantNo") String merchantNo,
			@Param("productName") String productName,
			@Param("beginDate") String beginDate, @Param("endDate") String endDate);

	List<CallCaseInfo> queryMerProBillPage(@Param("merchantName") String merchantName,
			@Param("merchantNo") String merchantNo,
			@Param("productName") String productName, @Param("beginDate") String beginDate,
			@Param("endDate") String endDate, @Param("start") Integer start, @Param("limit") Integer limit);

	/**
	 * 多维度统计次数
	 * @param caseInfoQueryParam
	 * @return
	 */
    CallCaseInfo queryBillFiledsTotalCount(CallCaseInfoQueryParam caseInfoQueryParam);
}