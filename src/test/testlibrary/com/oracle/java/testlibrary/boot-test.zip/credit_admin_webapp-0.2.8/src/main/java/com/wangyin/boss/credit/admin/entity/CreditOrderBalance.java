package com.wangyin.boss.credit.admin.entity;

import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;

import java.io.Serializable;

/**
 * order的扩展类
 * @author jiangbo
 * @since 2017/03/28
 */
public class CreditOrderBalance extends CreditOrder implements Serializable {
    private Long balance;
    private String strategyChargeTypeDesc;

    public Long getBalance() {
        return balance;
    }

    public void setBalance(Long balance) {
        this.balance = balance;
    }

    public String getStrategyChargeTypeDesc() {
        return strategyChargeTypeDesc;
    }

    public void setStrategyChargeTypeDesc(String strategyChargeTypeDesc) {
        this.strategyChargeTypeDesc = strategyChargeTypeDesc;
    }
}
