package com.wangyin.boss.credit.admin.service;

import java.util.List;
import java.util.Map;

import com.jd.jdjr.ras.api.domain.result.RasStatusResult;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.entity.merchant.MerchantAccountVo;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.request.merchant.GatewayMerchantQueryRequest;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.response.merchant.GatewayMerchantQueryResponse;
import com.jd.jr.boss.credit.credit.gateway.merchantca.exception.MerchantException;
import com.jd.jr.merchant.form.AuthBaseInfoForm;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditRoster;
import com.wangyin.operation.common.beans.Page;

/** 
* @desciption : 
* @author : yangjinlin@jd.com
* @date ：2016年9月6日 下午5:49:54 
* @version 1.0 
* @return  */
public interface MerchantCaService {

	/**
	 * 商户认证信息查询  分页
	 * @param merchantQueryReq 调用接口查询商户信息的请求体
	 * @return
	 * @throws MerchantException 
	 */
	Page<GatewayMerchantQueryResponse> queryMerchantInfo(GatewayMerchantQueryRequest merchantQueryReq) throws MerchantException;

	/**
	 * 发送邮件并对商户信息做增改
	 * @param merchantQueryResp
	 * @param user 当前操作人
	 * @param receiver 收件人
	 * @param subject 主题
	 * @param bizNo 流水号-自主生成且唯一，最长可为120
	 * @param templateParams
	 * @param templateCode 模板编号-UNC提供
	 * @param appCode 应用编号-UNC提供
	 * @param secretKey 商户密钥
	 * @return
	 * @throws Exception
	 */
	boolean addMercAndSendMail(GatewayMerchantQueryResponse merchantQueryResp, String operaUserName, String receiver, String subject,
			String bizNo, Map<String, Object> templateParams, String templateCode, String appCode, String secretKey, String operatePlat) throws Exception;

	/**
	 * 调用第三方商户列表接口：根据商户号查询商户信息
	 * @param merchantNo 商户号
	 * @return
	 * @throws MerchantException
	 */
	Page<GatewayMerchantQueryResponse> queryMerchantInfoByOne(String merchantNo) throws MerchantException;

	/**
	 * 调用第三方账户信息接口：根据商户号查询该商户的账户信息
	 * @param queryMerchantAccountVo 商户账户代码实体bean
	 * @return
	 * @throws Exception 
	 */
	List<MerchantAccountVo> queryMerchantAccountByNo(MerchantAccountVo queryMerchantAccountVo) throws Exception;

	/**
	 * 根据商户号调用认证商户信息接口  从企业站dubbo接口升级至基础服务组jsf接口
	 * @param merchantNo 商户号
	 * @return
	 */
	RasStatusResult queryAuthMerchantByNo(String merchantNo);

	/**
	 * 根据商户号更改商户联调模式
	 * @param merchant 商户号
	 * @param callModel 联调模式
	 * @return
	 * @throws Exception 
	 */
	boolean updateMerchCallByNo(CreditMerchant cm) throws Exception;

	/**
	 * 查询本地所有有效的商户 分页 
	 * @param merchant 商户信息实体类
	 * @return
	 */
	List<CreditMerchant> selectAllLocalMerchant(CreditMerchant merchant);

	/**
	 * 查询本地所有有效的商户总条数 分页
	 * @param merchant 商户信息实体类
	 * @return
	 */
	int selectCountAllLocalMerchant(CreditMerchant merchant);

	/**
	 * 根据条件查询本地所有有效的商户 分页
	 * @param merchant 商户信息实体类
	 * @return
	 */
	List<CreditMerchant> selectMerchantByParam(CreditMerchant merchant);

	/**
	 * 根据条件查询本地所有有效的商户总条数 分页
	 * @param merchant 商户信息实体类
	 * @return
	 */
	int selectMerchantCountByParam(CreditMerchant merchant);

	/**
	 * 根据商户号调用商户列表接口获取用户名
	 * @param cm
	 * @return
	 * @throws MerchantException 
	 */
	GatewayMerchantQueryResponse queryMerchantInfoByHttp(CreditMerchant cm) throws MerchantException;
	GatewayMerchantQueryResponse queryMerchantInfoByHttp(String merchantNo) throws MerchantException;

	/**
	 * 更新商户信息
	 * @param CreditMerchant 实体
	 * @param
	 * @return
	 * @throws Exception
	 */
	boolean updateMerchById(CreditMerchant cm) throws Exception;

	/**
	 * 根据商户号查询商户信息
	 * @param cm
	 * @return
	 * @throws MerchantException 
	 */
	GatewayMerchantQueryResponse queryMerchantInfoByJsf(CreditMerchant cm) throws MerchantException;

}
