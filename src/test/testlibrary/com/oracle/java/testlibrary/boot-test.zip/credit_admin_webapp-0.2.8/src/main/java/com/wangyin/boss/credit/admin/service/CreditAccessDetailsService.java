package com.wangyin.boss.credit.admin.service;

import java.util.List;

import com.wangyin.boss.credit.admin.entity.CreditAccessDetails;
import com.wangyin.operation.beans.UploadFile;

/**
 * 商户业务详单service
 * @author wyhaozhihong
 *
 */
public interface CreditAccessDetailsService {
	
	/**
	 * 根据参数查询业务详单数据 分页
	 * @author wyhaozhihong
	 * @param creditAccessDetails
	 * @return
	 */
	List<CreditAccessDetails> selectByParam(CreditAccessDetails creditAccessDetails);
	
	/**
	 * 根据参数查询业务详单数据总条数
	 * @author wyhaozhihong
	 * @param creditAccessDetails
	 * @return
	 */
	int selectCountByParam(CreditAccessDetails creditAccessDetails);
	
	/**
	 * 下载业务详单数据
	 * @author wyhaozhihong
	 * @param creditAccessDetails
	 * @return
	 */
	UploadFile downAccessDetailQueryResult(CreditAccessDetails creditAccessDetails);

	/**
	 * 根据accessId查询业务详单详细信息
	 * @param accessDetail
	 * @return
	 */
	CreditAccessDetails selectAccessDetailById(CreditAccessDetails accessDetail);

}
