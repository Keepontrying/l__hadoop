package com.wangyin.boss.credit.admin.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.domain.common.enums.CreditPaymentChannelEnum;
import com.jd.jr.boss.credit.facade.site.api.CreditPaymentFacade;
import com.jd.jr.boss.credit.facade.site.api.dto.request.payment.PaymentReceiptPushRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.payment.PaymentReceiptQueryRequest;
import com.wangyin.boss.credit.admin.dao.PaymentOrderMapper;
import com.wangyin.boss.credit.admin.entity.PaymentOrder;
import com.wangyin.boss.credit.admin.enums.CreditProductStatusEnum;
import com.wangyin.boss.credit.admin.service.PaymentOrderService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : 缴费单service实现类
* @author : yangjinlin@jd.com
* @date ：2017年1月3日 下午4:51:56 
* @version 1.0 
* @return  */
@Service
public class PaymentOrderServiceImpl implements PaymentOrderService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PaymentOrderServiceImpl.class);

	@Autowired
	PaymentOrderMapper paymentOrderMapper;
	
	@Resource
	CreditPaymentFacade creditPaymentFacade;
	
	@Override
	public List<PaymentOrder> selectPackageByParam(PaymentOrder paymentOrder) {
		// TODO Auto-generated method stub
		List<PaymentOrder> selectPackageByParamList = paymentOrderMapper.selectPackageByParam(paymentOrder);
		if(CollectionUtils.isNotEmpty(selectPackageByParamList)){
			for(PaymentOrder po : selectPackageByParamList){
				po.setPushPaymentOrderFlag("CANNOT_PUSH");//默认为不可推送缴费单
				if(CreditProductStatusEnum.CREDIT_ROSTER_CLOSE.toName().equalsIgnoreCase(po.getStrategyStatus()) ||
						(new Date()).compareTo(po.getStartTime()) < 0 ||
						(new Date()).compareTo(po.getFinishTime()) > 0){//若策略无效或不在有效期，则不可推送缴费单
					po.setPushPaymentOrderFlag("CANNOT_PUSH");
					continue;
				}
				RequestParam<PaymentReceiptQueryRequest> requestParam = new RequestParam<PaymentReceiptQueryRequest>();
				PaymentReceiptQueryRequest request = new PaymentReceiptQueryRequest();
				request.setMerchantNo(po.getMerchantNo());
				request.setPaymentChannel(CreditPaymentChannelEnum.PACKAGE_MANUAL);
				requestParam.setParam(request);
				ResponseData<Set<String>> respData = creditPaymentFacade.queryPaymentReceiptUnpaid(requestParam);
				if(respData.getData().contains(po.getStrategyId().toString())){
					po.setPushPaymentOrderFlag("CANNOT_PUSH");
				}else{
					po.setPushPaymentOrderFlag("CAN_PUSH");
				}
			}
		}
		return selectPackageByParamList;
	}

	@Override
	public int selectPackageCountByParam(PaymentOrder paymentOrder) {
		// TODO Auto-generated method stub
		return paymentOrderMapper.selectPackageCountByParam(paymentOrder);
	}

	@Override
	public List<PaymentOrder> selectSingleByParam(PaymentOrder paymentOrder) {
		// TODO Auto-generated method stub
		List<PaymentOrder> selectSingleByParamList = paymentOrderMapper.selectSingleByParam(paymentOrder);
		if(CollectionUtils.isNotEmpty(selectSingleByParamList)){
			for(PaymentOrder po : selectSingleByParamList){
				po.setPushPaymentOrderFlag("CANNOT_PUSH");//默认为不可推送缴费单
				if(CreditProductStatusEnum.CREDIT_ROSTER_CLOSE.toName().equalsIgnoreCase(po.getStrategyStatus()) ||
						(new Date()).compareTo(po.getStartTime()) < 0 ||
						(new Date()).compareTo(po.getFinishTime()) > 0){//若策略无效或不在有效期，则不可推送缴费单
					po.setPushPaymentOrderFlag("CANNOT_PUSH");
					continue;
				}
				RequestParam<PaymentReceiptQueryRequest> requestParam = new RequestParam<PaymentReceiptQueryRequest>();
				PaymentReceiptQueryRequest request = new PaymentReceiptQueryRequest();
				request.setMerchantNo(po.getMerchantNo());
				request.setPaymentChannel(CreditPaymentChannelEnum.SINGLE_MANUAL);
				requestParam.setParam(request);
				ResponseData<Set<String>> respData = creditPaymentFacade.queryPaymentReceiptUnpaid(requestParam);
				if(respData.getData().contains(po.getContractId().toString())){
					po.setPushPaymentOrderFlag("CANNOT_PUSH");
				}else{
					po.setPushPaymentOrderFlag("CAN_PUSH");
				}
			}
		}
		return selectSingleByParamList;
	}

	@Override
	public int selectSingleCountByParam(PaymentOrder paymentOrder) {
		// TODO Auto-generated method stub
		return paymentOrderMapper.selectSingleCountByParam(paymentOrder);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public ResponseData pushPaymentOrder(PaymentReceiptPushRequest paymentReceiptPushRequest) throws Exception {
		// TODO Auto-generated method stub
		RequestParam<PaymentReceiptPushRequest> requestParam = new RequestParam<PaymentReceiptPushRequest>();
		requestParam.setParam(paymentReceiptPushRequest);
		LOGGER.info("pushPaymentOrder---pushPaymentReceipt() before requestParam:" + GsonUtil.getInstance().toJson(requestParam));
		ResponseData respData = creditPaymentFacade.pushPaymentReceipt(requestParam);
		LOGGER.info("pushPaymentOrder---pushPaymentReceipt() after respData:" + GsonUtil.getInstance().toJson(respData));
		return respData;
	}
	
	public static void main(String[] args) throws Exception {
		String DateStr1 = "2016-09-12 00:00:00";
		String DateStr2 = "2017-09-11 00:00:00";
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println("---今天---"+ new Date());
		Date dateTime1 = dateFormat.parse(DateStr1);
		System.out.println("---dateTime1-----------"+dateTime1);
		Date dateTime2 = dateFormat.parse(DateStr2);
		System.out.println("---dateTime2-----------"+dateTime2);
		int i = dateTime1.compareTo(dateTime2); 
		System.out.println(i < 0);
		System.out.println((new Date()).compareTo(dateTime1));
		System.out.println((new Date()).compareTo(dateTime2));
	}

}
