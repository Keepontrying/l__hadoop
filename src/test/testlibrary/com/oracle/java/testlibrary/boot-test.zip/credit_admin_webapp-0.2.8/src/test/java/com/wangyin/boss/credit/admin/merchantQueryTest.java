package com.wangyin.boss.credit.admin;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.jd.fastjson.JSONObject;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.response.merchant.GatewayMerchantQueryResponse;
import com.jd.jr.boss.credit.credit.gateway.merchantca.exception.MerchantException;
import com.jd.jr.boss.credit.credit.gateway.merchantca.utils.HttpUtil;
import com.jd.jr.merchant.customer.ServiceControllerFacade;
import com.jd.jr.merchant.customer.common.RequestMessage;
import com.jd.jr.merchant.customer.common.ResponseMessage;
import com.wangyin.admin.frame.utils.BASE64;
import com.wangyin.admin.frame.utils.DES;
import com.wangyin.admin.frame.utils.MD5;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;



/** 
* @desciption : 商户列表接口
* @author : yangjinlin@jd.com
* @date ：2016年9月12日 上午10:29:06 
* @version 1.0 
* @return  */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:applicationContext.xml" })
public class merchantQueryTest {
	
	@Autowired
    private ServiceControllerFacade serviceControllerFacade;
	
	private static Logger logger = LoggerFactory.getLogger(merchantQueryTest.class);

	/**
	 * 测试商户认证信息查询jsf接口
	 * @throws MerchantException
	 */
//	@Test
	public void queryMerchantHttp() throws MerchantException{
		String url = "http://172.24.5.182:8081/api/service.htm";
		String id = new SimpleDateFormat("yyyymmddhhMMss").format(new Date());
		String registerDateStart = "1970-01-01 00:00:00";
		String registerDateEnd = "9999-12-31 23:59:59";
		Map<String, String> data = new HashMap<String, String>();
		data.put("merchant", "22318136");
		data.put("registerDateStart", registerDateStart);//注册时间为接口必须项
		data.put("registerDateEnd", registerDateEnd);//注册时间为接口必须项
		data.put("start", "0");
		data.put("limit", "10");
		logger.info("请求商户列表查询未加密前的参数data:"+GsonUtil.getInstance().toJson(data));
		Map<String, Object> dataWraper = new HashMap<String, Object>();
		dataWraper.put("serviceParam", data);
		
		String keyStr = id + "MARRY123QAZ" + "0001";
		GsonBuilder gsonBuilder = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss");
		String dataJson;
		try {
			dataJson = DES.encrypt(gsonBuilder.create().toJson(dataWraper), BASE64.encode(keyStr.getBytes()), "UTF-8");
		} catch (Exception e) {
			throw new MerchantException("调用加密方法失败！",e);
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("order", id);
		map.put("owner", "0001");
		try {
			map.put("sign", MD5.md5(dataJson, keyStr));
		} catch (Exception e) {
			throw new MerchantException("调用MD5方法失败！",e);
		}
		map.put("code", "I0030020");
		map.put("data", dataJson);
		String merchantListResp = HttpUtil.doPost(url, map);
		logger.info("==============merchantListResp1:========string========="+merchantListResp);
		ResponseData<Page<GatewayMerchantQueryResponse>> resData = GsonUtil.getInstance().fromJson(merchantListResp, new TypeToken<ResponseData<Page<GatewayMerchantQueryResponse>>>() {}.getType());
		
		logger.info("==============merchantListResp2:========json========="+GsonUtil.getInstance().toJson(merchantListResp));
	}
	
	/**
	 * 测试商户认证信息查询http接口
	 * @throws MerchantException 
	 * @throws Exception 
	 */
	@Test
	public void queryMerchantJsf() throws MerchantException{
		String id = new SimpleDateFormat("yyyymmddhhMMss").format(new Date());
		String registerDateStart = "1970-01-01 00:00:00";
		String registerDateEnd = "9999-12-31 23:59:59";
		Map<String, String> data = new HashMap<String, String>();
		data.put("merchant", "22318136");
//		data.put("registerDateStart", registerDateStart);//注册时间为接口必须项
//		data.put("registerDateEnd", registerDateEnd);//注册时间为接口必须项
		data.put("start", "0");
		data.put("limit", "10");
		logger.info("请求商户列表查询未加密前的参数data:"+GsonUtil.getInstance().toJson(data));
		Map<String, Object> dataWraper = new HashMap<String, Object>();
		dataWraper.put("serviceParam", data);
		
		String keyStr = id + "MARRY123QAZ" + "0001";
		GsonBuilder gsonBuilder = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss");
		String dataJson;
		try {
			dataJson = DES.encrypt(gsonBuilder.create().toJson(dataWraper), BASE64.encode(keyStr.getBytes()), "UTF-8");
		} catch (Exception e) {
			throw new MerchantException("调用加密方法失败！",e);
		}
		
		RequestMessage requestMessage = new RequestMessage();
		requestMessage.setReqid(id);
		requestMessage.setData(dataJson);
		requestMessage.setSystem("0001");
		requestMessage.setType("I0030020");
		try {
			requestMessage.setSign(MD5.md5(dataJson,keyStr));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ResponseMessage responseMessage = serviceControllerFacade.doRequest(requestMessage);
		logger.info("===========responseMessage.getData()=============="+responseMessage.getData());
		//{"total":1,"rows":[{"linkPhone":null,"originId":null,"merchant":"22318136","registerDate":"2017-03-28 15:57:38","originCode":null,"modifyDate":"2018-04-17 16:56:45","companyName":"一升三充值测试","companyCode":"1E1EA030B52F31CDE053110018AC7DEC","userType":"管理员","linkMan":null,"loginLockStatus":"正常","merchantType":"E","linkEmail":null,"userStatus":"可用","userName":"m6wgkjtest","originAlias":null,"authStatus":"0","originName":null}]}
		JSONObject jsStr = JSONObject.parseObject(responseMessage.getData()); 
		Page<GatewayMerchantQueryResponse> resData1 = GsonUtil.getInstance().fromJson(jsStr.toString(), new TypeToken<Page<GatewayMerchantQueryResponse>>() {}.getType());
		logger.info("===========gsonBuilder2=============="+gsonBuilder.create().toJson(resData1));
		
		
	}
	
	
}
