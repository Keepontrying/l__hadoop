package com.wangyin.boss.credit.enterprise.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.jd.jr.boss.credit.domain.common.entity.CreditCallTimesGather;
import com.jd.jr.boss.credit.domain.common.enums.*;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.enums.*;
import com.wangyin.boss.credit.admin.utils.ExcelUtil;
import com.wangyin.boss.credit.enterprise.entity.StandardReportComplPriceModel;
import com.wangyin.operation.beans.UploadFile;
import org.apache.commons.collections.CollectionUtils;
import org.apache.poi.ss.formula.functions.T;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.facade.authen.api.CreditOrderFacade;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jsf.gd.util.StringUtils;
import com.wangyin.boss.credit.admin.dao.CreditContractDetailsMapper;
import com.wangyin.boss.credit.admin.dao.CreditContractMapper;
import com.wangyin.boss.credit.admin.dao.CreditProductConfigMapper;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditContractDetails;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditProductConfig;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import com.wangyin.boss.credit.admin.entity.EnterpriseProductItemSku;
import com.wangyin.boss.credit.admin.service.CreditProductStrategyService;
import com.wangyin.boss.credit.enterprise.constants.SpecialProductConstant;
import com.wangyin.boss.credit.enterprise.dao.EnterpriseContractMapper;
import com.wangyin.boss.credit.enterprise.entity.EnterpriseProductItemSkuModel;
import com.wangyin.boss.credit.enterprise.entity.MiniCompletionPriceModel;
import com.wangyin.boss.credit.enterprise.service.EnterpriseContractService;
import com.wangyin.commons.util.StringUtil;

/** 
* @desciption : 企业征信合同serviceImpl实现类
* @author : yangjinlin@jd.com
* @date ：2017年3月17日 下午4:33:15 
* @version 1.0 
* @return  */
@Service
public class EnterpriseContractServiceImpl implements EnterpriseContractService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EnterpriseContractServiceImpl.class);

	@Autowired
	private EnterpriseContractMapper enterpContMapper;
	
	@Autowired
	CreditContractMapper creditContractMapper;
	
	@Autowired
	CreditContractDetailsMapper creditContractDetailsMapper;//合同操作记录
	
	@Autowired
	CreditProductStrategyService creditProductStrategyService;//计费策略服务
	
	@Autowired
	CreditProductConfigMapper creditProductConfigMapper;//产品服务配置

	@Autowired
	CreditOrderFacade orderFacade;//订单后台服务
	

	@Override
	public List<CreditContract> selectEnterpContByParam(CreditContract creditContract) {
		return enterpContMapper.selectEnterpContByParam(creditContract);
	}

	@Override
	public int selectEnterpContCountByParam(CreditContract creditContract) {
		return enterpContMapper.selectEnterpContCountByParam(creditContract);
	}

	@Override
	public int createEnterpContract(CreditContract creditContract, CreditMerchant creditMerchant,
			EnterpriseProductItemSkuModel enterpriseProductItemSkuModel) throws Exception{
		int contractId = 0;
		//
		CreditContractDetails creditContractDetails = new CreditContractDetails();
		/*在 合同操作记录表 中增加一条数据*/
		creditContract.setMerchantId(creditMerchant.getMerchantId());
		creditContract.setContractType(CreditContractTypeEnum.CONTRACT_TYPE_NOSTANDARD.toName());//nostandard
		creditContract.setContractStatus(ContractStatusEnum.NOAUDIT.toName());//"noaudit"
		creditContract.setContractPath(creditContract.getContractPath() == null ? "null" : creditContract.getContractPath());
		creditContract.setCreditType(CreditTypeEnum.ENTERPRISE.toName());
		creditContract.setContractSource(CreditContractSourceEnum.OFFLINE.toName());
		BigDecimal bg = new BigDecimal("100");
		if(CreditPurchaseTypeEnum.PRE.equals(creditContract.getPurchaseType())){
			creditContract.setAdvancePayment((StringUtils.isBlank(creditContract.getAdvancePaymentStr())) ? 0 : new BigDecimal(creditContract.getAdvancePaymentStr()).multiply(bg).longValue());
		}
		if(creditContract.getContractId() != null){//存在合同id，则进行更新动作
			creditContractMapper.updateByPrimaryKeySelective(creditContract);
			creditContractDetails.setHandleType(CreditContractHandleTypeEnum.MODIFIED.getCode());
		}else{
			creditContractMapper.insert(creditContract);//不存在合同id，则进行新增动作
			creditContractDetails.setHandleType(CreditContractHandleTypeEnum.CREATE.getCode());
		}
		contractId = creditContract.getContractId();
		
		/*在 合同操作记录表 中增加一条数据*/
		creditContractDetails.setContractId(contractId);
		creditContractDetails.setHandleResult(CreditContractHandleResultEnum.SUCCESS.getCode());
		creditContractDetails.setRemarks("");
		creditContractDetails.setCreator(creditContract.getCreator());
		creditContractDetailsMapper.insert(creditContractDetails);
		List<EnterpriseProductItemSku> enterprProdItemSkuList4Mini = new ArrayList<EnterpriseProductItemSku>();
		List<EnterpriseProductItemSku> enterprProdItemSkuList4StandardRepor = new ArrayList<EnterpriseProductItemSku>();
		for(EnterpriseProductItemSku strategyEvolve : enterpriseProductItemSkuModel.getEnterprProdItemSkuList()){
			if(  StringUtils.isNotBlank(strategyEvolve.getProductName()) && strategyEvolve.getProductName().equalsIgnoreCase(EnterpriseProductEnum4Common.ENTERPRISE_MINI_DUE.toDescription())
					&&  CollectionUtils.isNotEmpty(enterpriseProductItemSkuModel.getMiniCompleList())
					){
				for(MiniCompletionPriceModel miniCompl: enterpriseProductItemSkuModel.getMiniCompleList()){
					if(null == strategyEvolve.getStrategyId() && miniCompl.getCompletionType().equalsIgnoreCase(CreditMiniAreaCompletionEnum.T1.toName())){
						strategyEvolve.setSinglePriceStr(miniCompl.getComplePriceStr());
						strategyEvolve.setAmount(0L);
						strategyEvolve.setPacketCount(0);
						strategyEvolve.setCompletionPriceType(miniCompl.getPriceTypeType()+":"+miniCompl.getCompletionType());
					}else if(null != strategyEvolve.getStrategyId()){
						EnterpriseProductItemSku miniComplClone = new EnterpriseProductItemSku();
						BeanUtils.copyProperties(strategyEvolve, miniComplClone);
						miniComplClone.setStrategyId(miniCompl.getStrategyId());
						miniComplClone.setAmount(0L);
						miniComplClone.setPacketCount(0);
						miniComplClone.setSinglePriceStr(miniCompl.getComplePriceStr());
						miniComplClone.setCompletionPriceType(miniCompl.getPriceTypeType()+":"+miniCompl.getCompletionType());
						enterprProdItemSkuList4Mini.add(miniComplClone);
					}else{
						EnterpriseProductItemSku miniComplClone = new EnterpriseProductItemSku();
						BeanUtils.copyProperties(strategyEvolve, miniComplClone);
						miniComplClone.setAmount(0L);
						miniComplClone.setPacketCount(0);
						miniComplClone.setSinglePriceStr(miniCompl.getComplePriceStr());
						miniComplClone.setCompletionPriceType(miniCompl.getPriceTypeType()+":"+miniCompl.getCompletionType());
						enterprProdItemSkuList4Mini.add(miniComplClone);
					}
				}
			}
			if( StringUtils.isNotBlank(strategyEvolve.getProductName()) && strategyEvolve.getProductName().equalsIgnoreCase(EnterpriseProductEnum4Common.ENTERPRISE_ENT_STANDARD_REPORT.toDescription())
					&&  CollectionUtils.isNotEmpty(enterpriseProductItemSkuModel.getStandardRepoCompleList())
					){//标准信用报告特殊处理
				for(StandardReportComplPriceModel standardReportCompl : enterpriseProductItemSkuModel.getStandardRepoCompleList()){
					if( null == standardReportCompl.getCompletionType()){
						continue;
					}
					if(null == strategyEvolve.getStrategyId() && standardReportCompl.getCompletionType() == CreditGladReportCompletionEnum.T3.toCode()){
						strategyEvolve.setAmount(0L);
						strategyEvolve.setPacketCount(0);
						strategyEvolve.setUpperLimit(standardReportCompl.getUpperLimit());
						strategyEvolve.setCustomPriceStr(StringUtil.isBlank(standardReportCompl.getComplePriceStr()) ? "0" : standardReportCompl.getComplePriceStr());
						strategyEvolve.setFreeTimes(null == standardReportCompl.getFreeTimes()  ? 0 : standardReportCompl.getFreeTimes());
						strategyEvolve.setCompletionPriceType(standardReportCompl.getCompletionType().toString());
					}else if(null != strategyEvolve.getStrategyId()){
						EnterpriseProductItemSku standardRepoComplClone = new EnterpriseProductItemSku();
						BeanUtils.copyProperties(strategyEvolve, standardRepoComplClone);
						standardRepoComplClone.setStrategyId(standardReportCompl.getStrategyId());
						standardRepoComplClone.setAmount(0L);
						standardRepoComplClone.setPacketCount(0);
						standardRepoComplClone.setCustomPriceStr(StringUtil.isBlank(standardReportCompl.getComplePriceStr()) ? "0" : standardReportCompl.getComplePriceStr());
						standardRepoComplClone.setCompletionPriceType(standardReportCompl.getCompletionType().toString());
						standardRepoComplClone.setFreeTimes(null == standardReportCompl.getFreeTimes()  ? 0 : standardReportCompl.getFreeTimes());
						standardRepoComplClone.setUpperLimit(standardReportCompl.getUpperLimit());
						enterprProdItemSkuList4StandardRepor.add(standardRepoComplClone);
					}else{
						EnterpriseProductItemSku standardRepoComplClone = new EnterpriseProductItemSku();
						BeanUtils.copyProperties(strategyEvolve, standardRepoComplClone);
						standardRepoComplClone.setAmount(0L);
						standardRepoComplClone.setPacketCount(0);
						standardRepoComplClone.setCustomPriceStr(StringUtil.isBlank(standardReportCompl.getComplePriceStr()) ? "0" : standardReportCompl.getComplePriceStr());
						standardRepoComplClone.setUpperLimit(standardReportCompl.getUpperLimit());
						standardRepoComplClone.setFreeTimes(null == standardReportCompl.getFreeTimes()  ? 0 : standardReportCompl.getFreeTimes());
						standardRepoComplClone.setCompletionPriceType(standardReportCompl.getCompletionType().toString());
						enterprProdItemSkuList4StandardRepor.add(standardRepoComplClone);
					}
				}

			}
		}
		enterpriseProductItemSkuModel.getEnterprProdItemSkuList().addAll(enterprProdItemSkuList4Mini);
		enterpriseProductItemSkuModel.getEnterprProdItemSkuList().addAll(enterprProdItemSkuList4StandardRepor);
		/*遍历产品计费原型,生成产品服务配置和计费信息*/
		for(EnterpriseProductItemSku strategyEvolve : enterpriseProductItemSkuModel.getEnterprProdItemSkuList()){
			if(null == strategyEvolve){
				continue;
			}
			if(null == strategyEvolve.getProductId()){
				if(null == strategyEvolve.getStrategyId()){
					continue;
				}else{
					CreditProductStrategy creditProductStrategy = initStrategyInfos(creditContract, creditMerchant, contractId,
							strategyEvolve);
					if(null != creditProductStrategy){
						creditProductStrategyService.updateByStrategyId(creditProductStrategy);
						continue;
					}else{
						continue;
					}
				}
			}
			CreditProductStrategy creditProductStrategy = initStrategyInfos(creditContract, creditMerchant, contractId,
					strategyEvolve);
			if(null == creditProductStrategy){
				continue;
			}else{
				if(null != strategyEvolve.getStrategyId() && !"".contentEquals(strategyEvolve.getStrategyId().toString())
						&& !"null".equalsIgnoreCase(strategyEvolve.getStrategyId().toString())){
					creditProductStrategyService.updateByStrategyId(creditProductStrategy);
				}else{
					creditProductStrategyService.insert(creditProductStrategy);
				}
			}
			
		}
		
		
		return contractId;
	}

	/**
	 * 初始化服务产品
	 * @param creditContract
	 * @param creditMerchant
	 * @param strategyEvolve
	 * @return
	 */
	private CreditProductConfig initProductConfig(CreditContract creditContract, CreditMerchant creditMerchant,
			EnterpriseProductItemSku strategyEvolve) {
		CreditProductConfig credProdConf = new CreditProductConfig();
		credProdConf.setProductId(strategyEvolve.getProductId());
		credProdConf.setProductName(strategyEvolve.getProductName());
		credProdConf.setMerchantId(creditMerchant.getMerchantId());
		credProdConf.setMerchantNo(creditMerchant.getMerchantNo());
		credProdConf.setMerchantName(creditMerchant.getMerchantName());
		credProdConf.setCreator(creditContract.getCreator());
		credProdConf.setModifier(creditContract.getModifier());
		return credProdConf;
	}

	/**
	 * 初始化计费信息
	 * @param creditContract
	 * @param creditMerchant
	 * @param contractId
	 * @param strategyEvolve
	 * @return
	 */
	private CreditProductStrategy initStrategyInfos(CreditContract creditContract, CreditMerchant creditMerchant,
			int contractId, EnterpriseProductItemSku strategyEvolve) {
		CreditProductStrategy creditProductStrategy = new CreditProductStrategy();
		creditProductStrategy.setStrategyId(strategyEvolve.getStrategyId());
		creditProductStrategy.setProductId(strategyEvolve.getProductId());
		creditProductStrategy.setProductName(strategyEvolve.getProductName());
		
		creditProductStrategy.setMerchantId(creditMerchant.getMerchantId());
		creditProductStrategy.setMerchantNo(creditMerchant.getMerchantNo());
		creditProductStrategy.setMerchantName(creditMerchant.getMerchantName());
		creditProductStrategy.setChargeType(strategyEvolve.getChargeType());
		BigDecimal bg = new BigDecimal("100");
		if(StringUtils.isBlank(strategyEvolve.getChargeType())){
			creditProductStrategy.setContractId(0);
		}else{
			if(strategyEvolve.getChargeType().equals(ChargeTypeEnum.SINGLE.toName())){//单笔
				creditProductStrategy.setAmount(0L);
				creditProductStrategy.setPacketCount(0);
				creditProductStrategy.setPrice(null == strategyEvolve.getSinglePriceStr()? 0 : new BigDecimal(strategyEvolve.getSinglePriceStr()).multiply(bg).longValue());
			}else if(strategyEvolve.getChargeType().equals(ChargeTypeEnum.CUSTOM.toName())){//按次
				creditProductStrategy.setAmount(0L);
				creditProductStrategy.setPacketCount(0);
				creditProductStrategy.setPrice(null == strategyEvolve.getCustomPriceStr() ? 0 : new BigDecimal(strategyEvolve.getCustomPriceStr()).multiply(bg).longValue());//按次计费先将按次价格存到amount中，同时对应的charge_type=CUSTOM自定制
			}else if(strategyEvolve.getChargeType().equals(ChargeTypeEnum.PACKAGE.toName())){//包量
				creditProductStrategy.setAmount(null == strategyEvolve.getAmountStr()? null : new BigDecimal(strategyEvolve.getAmountStr()).multiply(bg).longValue());//
				creditProductStrategy.setPacketCount(strategyEvolve.getPacketCount());
				creditProductStrategy.setPrice(0L);
			}
		}
		creditProductStrategy.setStartTime(creditContract.getStartTime());
		creditProductStrategy.setFinishTime(creditContract.getFinishTime());
		creditProductStrategy.setStrategyStatus(OpenOrCloseStatusEnum.CLOSE.toName());
		creditProductStrategy.setModifier(creditContract.getModifier());
		creditProductStrategy.setModifiedDate(creditContract.getModifiedDate());
		creditProductStrategy.setCreator(creditContract.getCreator());
		creditProductStrategy.setCreatedDate(creditContract.getCreatedDate());
		creditProductStrategy.setFreeTimes(null == strategyEvolve.getFreeTimes() ? 0 : strategyEvolve.getFreeTimes());
		if("NOORDERED".equals(strategyEvolve.getOrderStatus())){//不订购
			creditProductStrategy.setContractId(0);
		}else{//订购
			creditProductStrategy.setContractId(contractId);
		}
		creditProductStrategy.setVipMonitorFlag(StringUtil.isBlank(strategyEvolve.getVipMonitorFlag())?"NO":strategyEvolve.getVipMonitorFlag());
		creditProductStrategy.setUpperLimit(strategyEvolve.getUpperLimit());
		creditProductStrategy.setPurchaseType(creditContract.getPurchaseType().getCode());
		if(StringUtils.isNotBlank(strategyEvolve.getCompletionPriceType())){
			creditProductStrategy.setRemarks(strategyEvolve.getCompletionPriceType());
		}
		return creditProductStrategy;
	}

	@Override
	public int modifyContractByPrimaryKey(CreditContract creditContract) {
		int count = creditContractMapper.updateByPrimaryKeySelective(creditContract);
		if(count == 1){
			
//			if(ContractStatusEnum.NOPAY.toName().equalsIgnoreCase(creditContract.getContractStatus())){//企业征信合同无需用户确认，在审核通过时合同状态变为待支付，同时往credit_order表写入该合同定值的计费
//				CreditProductStrategy productStrategy = new CreditProductStrategy();
//				productStrategy.setContractId(creditContract.getContractId());
//				List<CreditProductStrategy> creditProductStrategyList = creditProductStrategyService.selectStrategyListByParam(productStrategy);
//				for(CreditProductStrategy ps : creditProductStrategyList){
//					CreditOrder order = new CreditOrder();
//					order.setMerchantNo(ps.getMerchantNo());
//			        order.setSource(CreditOrderSourceEnum.CONTRACT);
//			        order.setStatus(CreditOrderStatusEnum.UNPAID);
//			        order.setStrategyId(ps.getStrategyId());
//			        order.setStrategyChargeType(ProductChargeTypeEnum.enumValueOf(ps.getChargeType()));
//			        order.setCreator(creditContract.getModifier());
//			        order.setCreatedDate(new Date());
//			        order.setModifier(creditContract.getModifier());
//			        order.setModifiedDate(new Date());
//			        creditOrderService.insertCreditOrder(order);
//				}
//				
//			}
			
			/*在 合同操作记录表 中增加一条数据*/
			CreditContractDetails creditContractDetails = new CreditContractDetails();
			if(ContractStatusEnum.TERMINATE_AUDIT.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.TERMINATE.getCode());
			}else if(ContractStatusEnum.CANCEL_AUDIT.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.CANCEL_AUDIT.getCode());
			}else if(ContractStatusEnum.NOCONFIRM.toName().equalsIgnoreCase(creditContract.getContractStatus()) || 
					ContractStatusEnum.RISK_NOPASS.toName().equalsIgnoreCase(creditContract.getContractStatus()) || 
					ContractStatusEnum.NOPAY.toName().equalsIgnoreCase(creditContract.getContractStatus())||
					ContractStatusEnum.VALID.toName().equalsIgnoreCase(creditContract.getContractStatus())
					){
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.AUDIT.getCode());
			}else if(ContractStatusEnum.CANCEL.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.CANCEL_AUDIT.getCode());
			}else {
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.TERMINATE_AUDIT.getCode());
			}
			creditContractDetails.setContractId(creditContract.getContractId());
			if(ContractStatusEnum.TERMINATE_AUDIT.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleResult(CreditContractHandleResultEnum.SUCCESS.getCode());
			}else if(ContractStatusEnum.CANCEL_AUDIT.toName().equalsIgnoreCase(creditContract.getContractStatus())){
				creditContractDetails.setHandleResult(CreditContractHandleResultEnum.SUCCESS.getCode());
			}else if(ContractStatusEnum.NOCONFIRM.toName().equalsIgnoreCase(creditContract.getContractStatus()) || 
					ContractStatusEnum.CANCEL.toName().equalsIgnoreCase(creditContract.getContractStatus()) || 
					ContractStatusEnum.TERMINATE.toName().equalsIgnoreCase(creditContract.getContractStatus()) ||
					ContractStatusEnum.NOPAY.toName().equalsIgnoreCase(creditContract.getContractStatus())||
							ContractStatusEnum.VALID.toName().equalsIgnoreCase(creditContract.getContractStatus())
					){
				creditContractDetails.setHandleResult(CreditContractHandleResultEnum.PASS.getCode());
			}else{
				creditContractDetails.setHandleResult(CreditContractHandleResultEnum.REJECT.getCode());
			}
			creditContractDetails.setRemarks(creditContract.getAuditAdvice());
			creditContractDetails.setCreator(creditContract.getAuditor());
			creditContractDetailsMapper.insert(creditContractDetails);
		}
		
		if( ContractStatusEnum.CANCEL.toName().equalsIgnoreCase(creditContract.getContractStatus()) || 
				ContractStatusEnum.TERMINATE.toName().equalsIgnoreCase(creditContract.getContractStatus()) ){//当合同已作废/履行结束时，将计费关停
			CreditProductStrategy creditProductStrategy = new CreditProductStrategy();
			creditProductStrategy.setContractId(creditContract.getContractId());
			creditProductStrategy.setModifier(creditContract.getAuditor());
			creditProductStrategy.setModifiedDate(creditContract.getAuditTime());
			creditProductStrategy.setStrategyStatus(OpenOrCloseStatusEnum.CLOSE.toName());
			creditProductStrategyService.updateStatusForClose(creditProductStrategy);//close
		}
        if(ContractStatusEnum.VALID.toName().equalsIgnoreCase(creditContract.getContractStatus())){//当合同将变为有效时才创建后付费订单
			//后付费合同审核通过，生成订单信息
			if(CreditPurchaseTypeEnum.POST.equals(creditContract.getPurchaseType())){
				//更新计费策略状态
				CreditProductStrategy creditProductStrategy = new CreditProductStrategy();
				creditProductStrategy.setContractId(creditContract.getContractId());
				creditProductStrategy.setModifier(creditContract.getAuditor());
				creditProductStrategy.setModifiedDate(creditContract.getAuditTime());
				creditProductStrategy.setStrategyStatus(OpenOrCloseStatusEnum.OPEN.toName());
				creditProductStrategyService.updateStatusForClose(creditProductStrategy);//open

				//创建订单
				CreditRequestParam<CreditContract> requestParam=new CreditRequestParam<CreditContract>();
				requestParam.setParam(creditContract);
				CreditResponseData responseData= orderFacade.createPostOrder(requestParam);
				if(!responseData.isSuccess()){
					//后付费订单生成失败
                    LOGGER.warn("后付费订单生成失败！");
				}
			}
		}


		return count;
	}


    @Override
    public UploadFile downCreditEnterContract(List<CreditContract> list, String[] titles, String[] properties, String fileName) {
        LOGGER.info("start downTradeLogCallTimes start.");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        ExcelUtil excelUtil = new ExcelUtil();
        String startDate = sdf.format(new Date());
        LOGGER.info("startDate=" + startDate);
        String path = ConfigUtil.getString("app.credit.downloadpath");
        String date = (new SimpleDateFormat("yyyyMMddHHmmSS")).format(new Date());
        String month = date.substring(0, 6);
        String day = date.substring(6, 14);
        String randomStr = String.valueOf((int)(1000000+Math.random()*9900000));
        String name = "/AccessDetailQueryResult/" + month + "/"+ fileName + "_"+ day +randomStr + ".xlsx";
        String dir = path + name;
        String pathName = "/accessDetail" + name;
        String originalName = fileName + ".xlsx";
        OutputStream outputStream = null;
        String workSheetName = fileName;
        int start = 0;
        int limit = 5000000;
        try {
            File file = new File(dir);
            if (!file.getParentFile().exists()) {
                if (!file.getParentFile().mkdirs()) {
                }
            }
            if (!file.exists()) {
                file.createNewFile();
            }
            outputStream = new FileOutputStream(file);
            SXSSFWorkbook wb = new SXSSFWorkbook(500);//// 创建工作薄
            Sheet sheet = null;//// 声明工作表
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            for (int i = 1;; i++) {
                if(i == 1 && list.size() == 0){
                    sheet = excelUtil.export(wb, workSheetName, titles, sheet);
                    break;
                }
                start = i * limit;
                LOGGER.info("downCreditEnterContract resultList.size()=" + list.size());
                int rowNum = 0;
                if (i != 1) {
                    rowNum = (i - 1) * limit;
                }
                sheet = excelUtil.export(wb, outputStream, workSheetName, titles,
                        properties, list, "", CreditContract.class, sheet,  rowNum);
                if (list.size() < limit) {// 最后一批则跳出循环
                    break;
                }
            }
            wb.write(outputStream);
            wb.dispose();
        } catch (Exception e) {
            LOGGER.error("downCreditEnterContract create result excel error,{}", e);
        } finally {
            try {
                outputStream.flush();
                outputStream.close();
            } catch (IOException e) {
                LOGGER.error("downCreditEnterContract error,{}", e);
            }
        }
        UploadFile uploadfile = new UploadFile();
        uploadfile.setPathname(pathName);
        uploadfile.setOriginalName(originalName);
        uploadfile.setVersion("2.0");
        uploadfile.setTemp(true);
        LOGGER.info("ending downCreditEnterContract download end.");
        String endDate = sdf.format(new Date());
        return uploadfile;
    }


}
