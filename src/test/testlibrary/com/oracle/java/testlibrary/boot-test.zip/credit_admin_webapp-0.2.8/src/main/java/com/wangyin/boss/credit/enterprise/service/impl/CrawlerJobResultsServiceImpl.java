package com.wangyin.boss.credit.enterprise.service.impl;

import com.google.gson.Gson;
import com.wangyin.boss.credit.enterprise.beans.*;
import com.wangyin.boss.credit.enterprise.dao.CrawlerJobMapper;
import com.wangyin.boss.credit.enterprise.dao.CrawlerJobResultsMapper;
import com.wangyin.boss.credit.enterprise.service.CrawlerJobFlowService;
import com.wangyin.boss.credit.enterprise.service.CrawlerJobResultsService;
import com.wangyin.commons.util.Logger;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.utils.GsonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2018/11/20
 */
@Service
public class CrawlerJobResultsServiceImpl implements CrawlerJobResultsService {
    private Logger logger = new Logger(CrawlerJobResultsServiceImpl.class);

    @Resource
    private CrawlerJobMapper jobMapper;
    @Resource
    private CrawlerJobResultsMapper mapper;

    @Resource
    private CrawlerJobFlowService flowService;

    @Override
    public void insert(CrawlerJobResults results) {
        List<CrawlerWord> words = results.getWords();
        if (words != null && !words.isEmpty()) {
            Integer jobWeight = 0;
            Integer jobHit = 0;
            for (CrawlerWord word : words) {
                jobWeight += word.getWeight();
                jobHit += word.getHit();
                if (word.getHit() != null && word.getHit() > 0) {
                    word.setScore(word.getWeight() * word.getHit());
                }
            }
            results.setTotalHit(jobHit);
            results.setWeight(jobWeight);
            results.setScore(jobHit * jobWeight);
        }
        CrawlerJob job = jobMapper.queryById(results.getJobId());
        results.setName(job.getName());
        results.setCategory(job.getCategory());
        results.setTargetUrl(job.getTargetUrl());
        mapper.insert(results);
        Long jobResId = results.getId();
        for (CrawlerWord word : words) {
            word.setJobResId(jobResId);
            mapper.insertWord(word);
        }
    }

    @Override
    public Page<CrawlerJobResults> query(CrawlerJobResultsQueryParam param) {
        Page<CrawlerJobResults> page = new Page<>();
        int total = mapper.queryCount(param);
        page.setTotal(total);
        if (total > 0) {
            List<CrawlerJobResults> results = mapper.query(param);
            for (CrawlerJobResults result : results) {
                result.setWords(mapper.queryWord(result.getId()));
            }
            page.setRows(results);
        }
        return page;
    }

    @Override
    public Page<CrawlerJobResults> queryList(CrawlerJobResultsQueryParam param) {
        Page<CrawlerJobResults> page = new Page<>();
        param.setState((byte)2);
        List<CrawlerJobFlow> flows = flowService.queryList(param);
        List<CrawlerJobResults> resultsAll = new ArrayList<>();
        for (CrawlerJobFlow flow : flows) {
            param.setJobNo(flow.getJobNo());
            param.setTime1(null);
            param.setTime2(null);
            List<CrawlerJobResults> results = mapper.query(param);
            for (CrawlerJobResults result : results) {
                result.setWords(mapper.queryWord(result.getId()));
            }
            resultsAll.addAll(results);
        }
        page.setRows(resultsAll);
        return page;
    }
}
