package com.wangyin.boss.credit.admin.service.impl;

import com.wangyin.boss.credit.admin.dao.CreditProductBlackHistoryMapper;
import com.wangyin.boss.credit.admin.dao.CreditProductBlackMapper;
import com.wangyin.boss.credit.admin.entity.CreditProductBlack;
import com.wangyin.boss.credit.admin.entity.CreditProductBlackHistory;
import com.wangyin.boss.credit.admin.enums.CreditProcutBlackHistoryStatusEnum;
import com.wangyin.boss.credit.admin.service.CreditProductBlackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;


/**
 * @desciption : 产品黑名单接口方法实现类
 * @author : liuwei55@jd.com
 * @date ：2017年4月10日 下午20:37:55
 * @version 1.0
 * @return  */
@Service
public class CreditProductBlackServiceImpl implements CreditProductBlackService {

	@Autowired
    private CreditProductBlackMapper creditProductBlackMapper;
	@Autowired
	private CreditProductBlackHistoryMapper creditProductBlackHistoryMapper;
	

	@Override
	public List<CreditProductBlack> selectCreProdBlackByPams(CreditProductBlack creditProductBlack) {
		
		return creditProductBlackMapper.selectCreProdBlackByPams(creditProductBlack);
	}

	@Override
	public int selectCountByParam(CreditProductBlack creditProductBlack) {
		
		return creditProductBlackMapper.selectCountByParam(creditProductBlack);
	}

	@Override
	public int updateCredProdBlackById(CreditProductBlack creditProductBlack) throws Exception {
		int res= creditProductBlackMapper.updateCredProdBlackById(creditProductBlack);
		CreditProductBlack creditProductBlackNew=creditProductBlackMapper.selectCredProdBlackById(creditProductBlack.getBlackId());
		CreditProductBlackHistory history=new CreditProductBlackHistory();
		history.setBlackId(creditProductBlackNew.getBlackId());
		history.setBlackStatus(creditProductBlackNew.getBlackStatus());
		history.setCreatedDate(creditProductBlackNew.getCreatedDate());
		history.setCreator(creditProductBlackNew.getCreator());
		history.setModifiedDate(creditProductBlackNew.getModifiedDate());
		history.setMerchantId(creditProductBlackNew.getMerchantId());
		history.setModifier(creditProductBlackNew.getModifier());
		history.setRemarks(creditProductBlackNew.getRemarks());
		history.setProductId(creditProductBlackNew.getProductId());
		creditProductBlackHistoryMapper.addCreProdBlackHistory(history);
		return res;
	}

	@Override
	public CreditProductBlack selectCredProdBlackById(int blackId) {
		return creditProductBlackMapper.selectCredProdBlackById(blackId);
	}

	@Override
	public int insertCredProdBlack(CreditProductBlack creditProductBlack) {
		int res=creditProductBlackMapper.insertCredProdBlack(creditProductBlack);
		CreditProductBlackHistory history=new CreditProductBlackHistory();
		history.setBlackId(creditProductBlack.getBlackId());
		history.setBlackStatus(CreditProcutBlackHistoryStatusEnum.CREATE.getCode());
		history.setCreatedDate(creditProductBlack.getCreatedDate());
		history.setCreator(creditProductBlack.getCreator());
		history.setModifiedDate(creditProductBlack.getModifiedDate());
		history.setMerchantId(creditProductBlack.getMerchantId());
		history.setModifier(creditProductBlack.getModifier());
		history.setRemarks(creditProductBlack.getRemarks());
		history.setProductId(creditProductBlack.getProductId());
		creditProductBlackHistoryMapper.addCreProdBlackHistory(history);
		return res;
	}

	@Override
	public CreditProductBlack selectCredProdBlackByProMerId(Map<String,Integer> map) {
		return creditProductBlackMapper.selectCredProdBlackByProMerId(map);
	}

}
