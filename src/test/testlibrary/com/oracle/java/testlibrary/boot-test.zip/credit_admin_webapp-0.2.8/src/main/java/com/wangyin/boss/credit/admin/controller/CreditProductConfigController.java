package com.wangyin.boss.credit.admin.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jd.jsf.gd.util.StringUtils;
import com.wangyin.boss.credit.admin.entity.*;
import com.wangyin.boss.credit.admin.enums.CreditProductTypeEnum;
import com.wangyin.boss.credit.admin.service.CreditProductConfigHistoryService;
import com.wangyin.boss.credit.admin.service.CreditProductStrategyService;
import freemarker.ext.beans.HashAdapter;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wangyin.boss.credit.admin.enums.CreditProcutConfigStatusEnum;
import com.wangyin.boss.credit.admin.service.CreditProductConfigService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/** 
* @desciption : 产品服务配置controller
* @author : yangjinlin@jd.com
* @date ：2016年8月29日 下午3:44:00 
* @version 1.0 
* @return  */

@Controller
@RequestMapping("/creditProductConfig")
public class CreditProductConfigController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CreditProductConfigController.class);
	
	@Autowired
	CreditProductConfigService creditProductConfigService;
	@Autowired
	CreditProductConfigHistoryService creditProductConfigHistoryService;
	@Autowired
	CreditProductStrategyService creditProductStrategyService;

	
	
	
	/**
	 * 查询产品服务配置  分页
	 * @author yangjinlin@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryProductConfig.do")
	public Map<String, Object> doQueryProductConfig(@RequestParam Map<String, String> map, CreditProductConfig creditProductConfig) {
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		List<CreditProductConfig> result=new ArrayList<CreditProductConfig>();
		try {
			String merchantNo=creditProductConfig.getMerchantNo();
			String merchantName=creditProductConfig.getMerchantName();
			Integer productId=creditProductConfig.getProductId();
			String configStatus=creditProductConfig.getConfigStatus();
			String limit=creditProductConfig.getLimit();
			String start=creditProductConfig.getStart();
//			creditProductConfig.setProductType(CreditProductTypeEnum.ENTERPRISE.toName());
   			if(StringUtils.isNotEmpty(merchantNo)){//商户号必填
				if(CreditProcutConfigStatusEnum.CLOSE.getCode().equals(configStatus)){//直接查询config表。
					result=creditProductConfigService.selectCreProdConfByPams(creditProductConfig);
					int confCount=creditProductConfigService.selectCountByParam(creditProductConfig);
					resultMap.put("rows", result);
					resultMap.put("total", confCount);
					return resultMap;
				}else{
					CreditProductStrategy creditProductStrategy=new CreditProductStrategy();
					creditProductStrategy.setMerchantNo(merchantNo);
					creditProductStrategy.setMerchantName(merchantName);
					creditProductStrategy.setProductId(productId);
					creditProductStrategy.setProductType(creditProductConfig.getProductType());

					List<CreditProductStrategy> list=creditProductStrategyService.selectDisStrategyListByParam(creditProductStrategy);
					Map<String, Object> mapParams=new HashMap<String,Object>();
					if(CollectionUtils.isNotEmpty(list)){
						for(CreditProductStrategy stragey:list){

							CreditProductConfig config=new CreditProductConfig();
							mapParams.put("productId",stragey.getProductId());
							mapParams.put("merchantId",stragey.getMerchantId());
							List<CreditProductConfig> configs=creditProductConfigService.selectCredProdConfByProdMercId(mapParams);
							if(CollectionUtils.isNotEmpty(configs)){//不为空则说明这个产品为关闭服务。
								if(CreditProcutConfigStatusEnum.OPEN.getCode().equals(configStatus)){
									break;
								}
								config.setConfigStatus(CreditProcutConfigStatusEnum.CLOSE.getCode());
								config.setModifiedDate(configs.get(0).getModifiedDate());
								config.setModifier(configs.get(0).getModifier());
								config.setRemarks(configs.get(0).getRemarks());
							}else{
								config.setConfigStatus(CreditProcutConfigStatusEnum.OPEN.getCode());
								config.setModifiedDate(stragey.getModifiedDate());
								config.setModifier(stragey.getModifier());
							}
							config.setProductId(stragey.getProductId());
							config.setMerchantId(stragey.getMerchantId());
							config.setMerchantNo(stragey.getMerchantNo());
							config.setProductName(stragey.getProductName());
							config.setMerchantName(stragey.getMerchantName());
							result.add(config);
						}
					}
					//分页
					int end=Integer.parseInt(start)+Integer.parseInt(limit)-1;
					int begin=Integer.parseInt(start);
					List<CreditProductConfig> configRes=new ArrayList<CreditProductConfig>();
					if(result.size()>end){
						configRes=result.subList(begin,end+1);
					}else{
						configRes=result.subList(begin,result.size());
					}
					resultMap.put("rows", configRes);
					resultMap.put("total", result.size());
				}
			}else{
				resultMap.put("rows", result);
				resultMap.put("total", 0);
			}
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", result);
			resultMap.put("total", 0);
		}
		
		return resultMap;
	}

	
	/**
	 * 开通、关停 产品服务配置
	 * @author yangjinlin@jd.com
	 * @param map
	 * @param creditProductConfig
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doOperateProductConfig.do")
	public Map<String, Object> doOperateProductStrategy(@RequestParam Map<String, Object> map,
			CreditProductConfig creditProductConfig, String user) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");
		
		String operaUserName = null;
		try {
			operaUserName = getLoginRealName(user);
		} catch (Exception e) {
			LOGGER.error(e);
			operaUserName = "error";
		}
		creditProductConfig.setModifier(operaUserName);
		String remark = map.containsKey("remarks") ? String.valueOf(map.get("remarks")) : "未获取到相应备注信息!";
		
		String[] configIds = String.valueOf(map.get("configIds")).split("\\|");
		if(configIds.length == 0){
			resultMap.put("success", false);
			resultMap.put("message", "操作有误，请重新操作!");
		}else{
			for (String configId : configIds) {
				String[] proMerIds=configId.split("\\,");
				creditProductConfig.setProductId(Integer.valueOf(proMerIds[0]));
				creditProductConfig.setMerchantId(Integer.valueOf(proMerIds[1]));
				CreditProductStrategy strategyParam=new CreditProductStrategy();
				strategyParam.setProductId(creditProductConfig.getProductId());
				strategyParam.setMerchantId(creditProductConfig.getMerchantId());
				List<CreditProductStrategy> list=creditProductStrategyService.selectStrategyListByProMerId(strategyParam);
				CreditProductStrategy strategy=new CreditProductStrategy();
				if(CollectionUtils.isNotEmpty(list)){
					strategy=list.get(0);
				}
				try {
					String configStatus=String.valueOf(map.get("configStatus"));
					creditProductConfig.setMerchantNo(strategy.getMerchantNo());
					creditProductConfig.setMerchantName(strategy.getMerchantName());
					creditProductConfig.setProductName(strategy.getProductName());
					creditProductConfig.setCreator(operaUserName);
					if(CreditProcutConfigStatusEnum.OPEN.getCode().equals(configStatus)){//开通需要将config表数据删除
						creditProductConfigService.deleteCredProdConfByProMerId(creditProductConfig);
					}else{//关闭插入数据
						creditProductConfig.setConfigStatus(CreditProcutConfigStatusEnum.CLOSE.getCode());
						creditProductConfigService.addCreProdConfByProdMerchId(creditProductConfig);
					}
					CreditProductConfigHistory history=new CreditProductConfigHistory();
					history.setProductId(creditProductConfig.getProductId());
					history.setConfigId(-1);//暂时不用这个属性，通过productId merchantId查询
					history.setProductName(creditProductConfig.getProductName());
					history.setMerchantId(creditProductConfig.getMerchantId());
					history.setMerchantNo(creditProductConfig.getMerchantNo());
					history.setMerchantName(creditProductConfig.getMerchantName());
					history.setConfigStatus(creditProductConfig.getConfigStatus());
					history.setCreator(operaUserName);
					history.setModifier(operaUserName);
					history.setRemarks(creditProductConfig.getRemarks());
					creditProductConfigHistoryService.addCreProdConfHistory(history);
					
				} catch (Exception e) {
					LOGGER.error(e);
					resultMap.put("success", false);
					resultMap.put("message", "操作异常");
				}
			}
		}
		return resultMap;
	}
	
	/**
	 * 根据id查看产品服务配置详情&查看产品服务配置的历史操作记录
	 * @author yangjinlin@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toQueryCreditProductConfigDetail.view")
	public Map<String, Object> toQueryProductStrategyDetail(@RequestParam Map<String, Object> map) {
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		Integer productId = Integer.valueOf(String.valueOf(map.get("productId")));
		Integer merchantId= Integer.valueOf(String.valueOf(map.get("merchantId")));
		String configStatus=String.valueOf(map.get("configStatus"));
		CreditProductStrategy strategy=new CreditProductStrategy();
		strategy.setProductId(productId);
		strategy.setMerchantId(merchantId);
		List<CreditProductStrategy> list=creditProductStrategyService.selectStrategyListByProMerId(strategy);
		CreditProductConfig cpc = new CreditProductConfig();
		if(CollectionUtils.isNotEmpty(list)){
			 strategy=list.get(0);
			cpc.setProductId(productId);
			cpc.setMerchantId(merchantId);
			cpc.setMerchantNo(strategy.getMerchantNo());
			cpc.setMerchantName(strategy.getMerchantName());
			cpc.setProductName(strategy.getProductName());
			cpc.setConfigStatus(configStatus);
		}
		resultMap.put("creditProductConfig", cpc);
		
		return resultMap;
	}
	/**
	 * 查看产品黑名单配置的历史操作记录
	 * @author liuwei55@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toQueryProductConfigHistList")
	public Map<String, Object> toQueryProductBlackHistList(@RequestParam Map<String, Object> map) {

		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			Integer productId = Integer.valueOf(String.valueOf(map.get("productId")));
			Integer merchantId = Integer.valueOf(String.valueOf(map.get("merchantId")));
			CreditProductConfigHistory history=new CreditProductConfigHistory();
			history.setProductId(productId);
			history.setMerchantId(merchantId);
			history.setStart(String.valueOf(map.get("start")));
			history.setLimit(String.valueOf(map.get("limit")));
			List<CreditProductConfigHistory> list=creditProductConfigHistoryService.selectCreProdConfHisByPams(history);
			int credProdConfigCount = creditProductConfigHistoryService.selectCountConfHisByPams(history);
			resultMap.put("rows", list);
			resultMap.put("total", credProdConfigCount);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditProductConfigHistory>());
			resultMap.put("total", 0);
		}
		return resultMap;
	}
	
	
	/**
	 * 根据id查看计费策略表的变更记录
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryOperateRecord.do")
	public Map<String, Object> doQueryOperateRecord(@RequestParam Map<String, Object> map,
			CreditProductConfig creditProductConfig) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		//查询操作记录表list
		Integer configId = Integer.valueOf(String.valueOf(map.get("configId")));
		List<CreditChangeRecord> credChanRecList = creditProductConfigService.selectCredChanRecdsByConfigId(configId);
		for (CreditChangeRecord creditChangeRecord : credChanRecList) {
			creditChangeRecord.setCreatedDateStr(df.format(creditChangeRecord.getCreatedDate()));
			creditChangeRecord.setChangeStatus(CreditProcutConfigStatusEnum.getValueByCode(creditChangeRecord.getChangeStatus()));
		}
		resultMap.put("creditChangeRecords", credChanRecList);
		return resultMap;
	}
}
