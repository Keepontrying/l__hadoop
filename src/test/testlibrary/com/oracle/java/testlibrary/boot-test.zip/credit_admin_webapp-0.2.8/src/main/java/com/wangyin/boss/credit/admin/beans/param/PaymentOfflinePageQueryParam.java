package com.wangyin.boss.credit.admin.beans.param;

import com.jd.jr.boss.credit.domain.common.enums.PaymentOfflineStatusEnum;

import java.io.Serializable;

/**
 * Created by anmeng on 2017/9/14.
 */
public class PaymentOfflinePageQueryParam extends PageQueryParam implements Serializable {
    private static final long serialVersionUID = 114767434543836664L;

    private String merchantNo;//商户号
    private String merchantName;//商户名称
    private PaymentOfflineStatusEnum status;

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public PaymentOfflineStatusEnum getStatus() {
        return status;
    }

    public void setStatus(PaymentOfflineStatusEnum status) {
        this.status = status;
    }
}
