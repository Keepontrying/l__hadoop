package com.wangyin.boss.credit.admin.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import com.jd.jr.boss.credit.domain.common.enums.CreditYesOrNoEnum;
import com.wangyin.boss.credit.admin.enums.MerchantClassifyEnum;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.entity.merchant.MerchantUsers;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.request.merchant.GatewayPortalUserRequest;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.response.merchant.GatewayMerchantQueryResponse;
import com.jd.jr.boss.credit.credit.gateway.merchantca.facade.merchant.GatewayMerchantFacade;
import com.wangyin.boss.credit.admin.dao.CreditUserMapper;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.boss.credit.admin.service.CreditUserService;
import com.wangyin.boss.credit.admin.service.MerchantCaService;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.RequestParam;

/**
 * @author jiangbo
 * @since 2017/3/17
 */
@Service
public class CreditUserServiceImpl implements CreditUserService {

    private static Logger logger = LoggerFactory.getLogger(CreditUserServiceImpl.class);

    @Autowired
    private MerchantCaService merchantCaService;

    @Autowired
    CreditUserMapper creditUserMapper;
    
    @Resource
	GatewayMerchantFacade gatewayMerchantFacade;

    @Override
    public List<CreditUser> selectCreditUserByParam(CreditUser creditUser) {

        try {

            List<CreditUser> creditUserList = creditUserMapper.selectCreditUserByParam(creditUser);

            for (CreditUser cu : creditUserList) {
                cu.setSeparateBillType(CreditYesOrNoEnum.enumValueOf(cu.getSeparateBillType()).toDescription());
                cu.setMerchantClassify(StringUtils.isBlank(cu.getMerchantClassify()) ? "": MerchantClassifyEnum.valueOf(cu.getMerchantClassify()).getDescription());
                if (StringUtils.isEmpty(cu.getMerchantNo())) {
                    logger.warn("selectCreditUserByParam MerchantNo miss,creditUser:{}", cu);
                    continue;
                }
                RequestParam<GatewayPortalUserRequest> userInfoReqPrm = new RequestParam<GatewayPortalUserRequest>();
                GatewayPortalUserRequest portalUserRequest = new GatewayPortalUserRequest();
                portalUserRequest.setUserName(cu.getLoginName());
                userInfoReqPrm.setParam(portalUserRequest);
                Page<MerchantUsers> page = gatewayMerchantFacade.queryUsersInfoByPrm(userInfoReqPrm);
                if(page.isSuccess() && CollectionUtils.isNotEmpty(page.getRows()) && page.getRows().size()>0
                		&& null != page.getRows().get(0) ){
                	cu.setEmailReal(page.getRows().get(0).getEmail());
                }
                CreditMerchant cm = new CreditMerchant();
                cm.setMerchantNo(cu.getMerchantNo());
                GatewayMerchantQueryResponse gmqResp = merchantCaService.queryMerchantInfoByHttp(cm);
                cu.setMerchantCaStatus(gmqResp.getMerchantCaStatus());
                cu.setOriginName(gmqResp.getOriginName());
                cu.setRegisterDate(gmqResp.getRegisterDate());
                cu.setLinkPhone(gmqResp.getLinkPhone());
            }

            return creditUserList;
        }catch (Exception e){
            logger.error("selectCreditUserByParam error,creditUser:{}", creditUser, e);
            return new ArrayList<CreditUser>();
        }
    }

    @Override
    public int selectCreditUserCountByParam(CreditUser creditUser) {
        return creditUserMapper.selectCreditUserCountByParam(creditUser);
    }

    @Override
    public int modifyUserByPrimaryKey(CreditUser creditUser) {
        return creditUserMapper.modifyUserByPrimaryKey(creditUser);
    }
}
