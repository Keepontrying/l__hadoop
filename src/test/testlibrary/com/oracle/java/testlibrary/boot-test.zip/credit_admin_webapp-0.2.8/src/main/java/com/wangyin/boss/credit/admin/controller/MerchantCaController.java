package com.wangyin.boss.credit.admin.controller;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.request.merchant.GatewayMerchantQueryRequest;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.response.merchant.GatewayMerchantQueryResponse;
import com.jd.jr.boss.credit.domain.common.enums.CreditPurchaseTypeEnum;
import com.jd.jr.boss.credit.facade.authen.api.CreditWxOrderFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.WxOrderParam;
import com.jd.jr.boss.credit.facade.authen.beans.response.WxOrderResp;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.gateway.unc.constance.GatewayUncConstance;
import com.jd.jr.boss.credit.gateway.unc.utils.FlowNoUtils;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.beans.TextValuePairs;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.boss.credit.admin.enums.CreditMerchantCallModelEnum;
import com.wangyin.boss.credit.admin.enums.CreditMerchantTypeEnum;
import com.wangyin.boss.credit.admin.enums.MerchantAuditEnum;
import com.wangyin.boss.credit.admin.service.CreditUserService;
import com.wangyin.boss.credit.admin.service.MerchantCaService;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.beans.ErrorMessage;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;

/** 
* @desciption : 商户认证控制层
* @author : yangjinlin@jd.com
* @date ：2016年9月6日 下午2:57:09 
* @version 1.0 
* @return  */
@Controller
@RequestMapping("/merchantca")
public class MerchantCaController extends BaseController {

	private static Logger logger = LoggerFactory.getLogger(MerchantCaController.class);
	
	@Autowired
	private MerchantCaService merchantCaService;

	@Autowired
	private CreditUserService creditUserService;

	@Autowired
	private CreditWxOrderFacade creditWxOrderFacade;
	
	private static String appCode;
	private static String templateCode;
	private static String webServerTest;//本系统是否为测试环境  true:是测试环境；false：非测试环境
	private static String useTestReceiver;
	
	
	static {
		appCode = ConfigUtil.getString(GatewayUncConstance.UNC_CLIENT_APPCODE);
		templateCode = ConfigUtil.getString(GatewayUncConstance.UNC_CLIENT_TEMPLATECODE);
		webServerTest = ConfigUtil.getString(GatewayUncConstance.UNC_CLIENT_TEST);
		useTestReceiver = ConfigUtil.getString(GatewayUncConstance.UNC_CLIENT_TEST_RECEIVER);
		
    }
	
	
	/**
	 * 查询商户认证信息  分页
	 * @author yangjinlin@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doQueryMerchantCa.do")
	public Map<String, Object> doQueryMerchantCa(@RequestParam Map<String, String> map, 
			GatewayMerchantQueryRequest merchantQueryReq) {
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		try {
			merchantQueryReq.setPageNo(Integer.valueOf(map.get("start")));
			merchantQueryReq.setPageSize(Integer.valueOf(map.get("limit")));
			Page<GatewayMerchantQueryResponse> page = merchantCaService.queryMerchantInfo(merchantQueryReq);
			resultMap.put("rows", page.getRows());
			resultMap.put("total", page.getTotal());
			return resultMap;
		} catch (Exception e) {
			logger.error("queryMerchantInfo error",e);
			return ErrorMessage.getGridErrorMessage("系统异常");
		}
		
	}
	
	/**
	 * 发送密钥操作
	 * @author yangjinlin@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doSendEmail4MercCa.do")
	public Map<String, Object> doSendEmail4MercCa(@RequestParam Map<String, String> map, String user,
			GatewayMerchantQueryResponse merchantQueryResp) {
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		String operaUserName = null;
		try {
			operaUserName = getLoginRealName(user);
		} catch (Exception e1) {
			logger.error("getLoginRealName error", e1);
			operaUserName = "error";
		}
		
		try {
			String receiver = null;
			if("true".equals(webServerTest)){//本系统为测试环境
				receiver = useTestReceiver;
			}else{
				receiver = merchantQueryResp.getUserName();
			}
			String subject = "【征信数据服务】安全密钥";
			String bizNo = FlowNoUtils.createFlowNo("credit");
			Map<String, Object> templateParams = new HashMap<String, Object>();
			templateParams.put("companyName", merchantQueryResp.getCompanyName());
			templateParams.put("merchantNo", merchantQueryResp.getMerchant());
			String operatePlat = "";
			if(map.containsKey("operatePlat") && StringUtils.isNotBlank(map.get("operatePlat").toString())){
				operatePlat = map.get("operatePlat").toString();
			}
			
			boolean sendResult = merchantCaService.addMercAndSendMail(merchantQueryResp, operaUserName, receiver, subject, bizNo,
					templateParams, templateCode, appCode, FlowNoUtils.createFlowMd5No("credit"), operatePlat);
			if(true == sendResult){
				resultMap.put("success", true);
				resultMap.put("message", "操作成功");
			}else{
				resultMap.put("success", false);
				resultMap.put("message", "邮件发送失败，请重新操作!");
			}
		} catch (Exception e) {
			logger.error("addMercAndSendMail error,{}",e);
			resultMap.put("success", false);
			resultMap.put("message", "异常，请稍后重试");
		}
		
		return resultMap;
		
	}
	
	/**
	 * 为企业征信商户发送密钥操作
	 * @author yangjinlin@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doSendEmail4MercCaEnterp.do")
	public Map<String, Object> doSendEmail4MercCaEnterp(@RequestParam Map<String, String> map, String user,
			GatewayMerchantQueryResponse merchantQueryResp) {
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		String operaUserName = null;
		try {
			operaUserName = getLoginRealName(user);
		} catch (Exception e1) {
			logger.error("getLoginRealName error", e1);
			operaUserName = "error";
		}
		
		try {
			String receiver = null;
			if("true".equals(webServerTest)){//本系统为测试环境
				receiver = useTestReceiver;
			}else{
				receiver = merchantQueryResp.getUserName();
			}
			String subject = "【企业征信服务】安全密钥";
			String bizNo = FlowNoUtils.createFlowNo("credit");
			Map<String, Object> templateParams = new HashMap<String, Object>();
			templateParams.put("companyName", merchantQueryResp.getCompanyName());
			templateParams.put("merchantNo", merchantQueryResp.getMerchant());
			String operatePlat = "";
			if(map.containsKey("operatePlat") && StringUtils.isNotBlank(map.get("operatePlat").toString())){
				operatePlat = map.get("operatePlat").toString();
			}
			String templateCodeEnterp = ConfigUtil.getString(GatewayUncConstance.UNC_CLIENT_TEMPLATECODE_ENTERP);
			
			boolean sendResult = merchantCaService.addMercAndSendMail(merchantQueryResp, operaUserName, receiver, subject, bizNo,
					templateParams, templateCodeEnterp, appCode, FlowNoUtils.createFlowMd5No("credit"), operatePlat);
			if(true == sendResult){
				resultMap.put("success", true);
				resultMap.put("message", "操作成功");
			}else{
				resultMap.put("success", false);
				resultMap.put("message", "邮件发送失败，请重新操作!");
			}
		} catch (Exception e) {
			logger.error("addMercAndSendMail error,{}",e);
			resultMap.put("success", false);
			resultMap.put("message", "异常，请稍后重试");
		}
		
		return resultMap;
		
	}
	
	/**
	 * 更改商户联调模式操作
	 * @author yangjinlin@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doUpdateMerchCall.do")
	public Map<String, Object> doUpdateMerchCall(@RequestParam Map<String, String> map, String user,
			GatewayMerchantQueryResponse merchantQueryResp) {
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		String operaUserName = null;
		try {
			operaUserName = getLoginRealName(user);
		} catch (Exception e1) {
			logger.error("getLoginRealName error",e1);
			operaUserName = "error";
		}
		if(null == merchantQueryResp.getCallModel() || "".equals(merchantQueryResp.getCallModel())){//校验接口开通模式传参是否有问题
			resultMap.put("success", false);
			resultMap.put("message", "系统异常!");
			return resultMap;
		}
		if(null == merchantQueryResp.getMerchant() || "".equals(merchantQueryResp.getMerchant())){//校验商户号是否为空
			resultMap.put("success", false);
			resultMap.put("message", "系统异常!");
			return resultMap;
		}
		try {
			
			CreditMerchant cm = new CreditMerchant();
			cm.setMerchantNo(merchantQueryResp.getMerchant());
			if(merchantQueryResp.getCallModel().equals(CreditMerchantCallModelEnum.DEBUG.toName())){
				cm.setCallModel(CreditMerchantCallModelEnum.NORMAL.toName());
			}else if(merchantQueryResp.getCallModel().equals(CreditMerchantCallModelEnum.NORMAL.toName())){
				cm.setCallModel(CreditMerchantCallModelEnum.DEBUG.toName());
			}
			cm.setModifier(operaUserName);
			
			boolean updateResult = merchantCaService.updateMerchCallByNo(cm);
			if(true == updateResult){
				resultMap.put("success", true);
				resultMap.put("message", "操作成功");
			}else{
				resultMap.put("success", false);
				resultMap.put("message", "操作失败!");
			}
		} catch (Exception e) {
			logger.error("updateMerchCallByNo error,{}", e);
			resultMap.put("success", false);
			resultMap.put("message", "异常，请稍后重试");
		}
		
		return resultMap;
		
	}
	
	/**
	 * 默认加载本地商户信息  分页
	 * @author yangjinlin@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doQueryMerchantLocal.do")
	public Map<String, Object> doQueryMerchantLocal(@RequestParam Map<String, String> map, 
			CreditMerchant merchant) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");
		//为了兼容老的个人征信逻辑，默认为PERSON,ALL
		if (StringUtils.isBlank(merchant.getMerchantType())){
			merchant.setMerchantTypeList(Arrays.asList((CreditMerchantTypeEnum.PERSON.toName()+","+CreditMerchantTypeEnum.ALL.toName()).substring(0).split(",")));
		}
		List<GatewayMerchantQueryResponse> merchantLocalList = new ArrayList<GatewayMerchantQueryResponse>();
		List<CreditMerchant> merchantList = new ArrayList<CreditMerchant>();
		int merchantLocalCount = 0;
		try {
			merchantList = merchantCaService.selectAllLocalMerchant(merchant);
			for(CreditMerchant cm : merchantList){
				if(StringUtils.isEmpty(cm.getMerchantNo())){
					continue;
				}
				GatewayMerchantQueryResponse gmqResp = merchantCaService.queryMerchantInfoByHttp(cm);
				GatewayMerchantQueryResponse gmq = new GatewayMerchantQueryResponse();
				gmq.setMerchant(cm.getMerchantNo());
				gmq.setCompanyName(cm.getMerchantName());
				gmq.setSecretKey(cm.getSecretKey());
				gmq.setCallModel(cm.getCallModel());
				gmq.setUserName(gmqResp.getUserName());
				gmq.setMerchantCaStatus(gmqResp.getMerchantCaStatus());
				gmq.setMerchantResource(cm.getMerchantResource());
				merchantLocalList.add(gmq);
			}
			merchantLocalCount = merchantCaService.selectCountAllLocalMerchant(merchant);
			resultMap.put("rows", merchantLocalList);
			resultMap.put("total", merchantLocalCount);
			
		} catch (Exception e) {
			logger.error("doQueryMerchantLocal error,{}",e);
			resultMap.put("rows", new ArrayList<GatewayMerchantQueryResponse>());
			resultMap.put("total", 0);
			resultMap.put("success", false);
			resultMap.put("message", "异常，请稍后重试");
		}
		
		return resultMap;
	}

	/**
	 * 商户审核查询  分页
	 * @author jiangbo@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doQueryMerchantAudit.do")
	public Map<String, Object> doQueryMerchantAudit(@RequestParam Map<String, String> map,
													CreditMerchant merchant) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");

		//添加一个默认的type,
		if (org.apache.commons.lang3.StringUtils.isBlank(merchant.getMerchantType())){
			resultMap.put("rows", new ArrayList<CreditMerchant>());
			resultMap.put("total", 0);
			resultMap.put("success", false);
			resultMap.put("message", "商户类型，不能为空");
			return resultMap;
		}

		List<CreditMerchant> merchantList;
		int merchantLocalCount = 0;
		try {

			merchantList = merchantCaService.selectMerchantByParam(merchant);
			for(CreditMerchant cm : merchantList){
				if(StringUtils.isEmpty(cm.getMerchantNo())){
					continue;
				}

				GatewayMerchantQueryResponse gmqResp = merchantCaService.queryMerchantInfoByHttp(cm);
				cm.setUserName(gmqResp.getUserName());
				cm.setLinkPhone(gmqResp.getLinkPhone());
				cm.setAuthCreatedDate(gmqResp.getAuthCreatedDate());
				cm.setAuthModifiedDate(gmqResp.getAuthModifiedDate());

//				if (org.apache.commons.lang3.StringUtils.isBlank(cm.getAuditStatus()) || cm.getAuditStatus().equals(MerchantAuditEnum.WAIT_RISK.getCode()) || cm.getAuditStatus().equals(MerchantAuditEnum.NOT_CERTIFIED.getCode())){
//					CreditMerchant cmNew = new CreditMerchant();
//					cmNew.setMerchantId(cm.getMerchantId());
//					cmNew.setModifier("SYSTEM");
////					cmNew.setMerchantName(gmqResp.getCompanyName());
//					if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_SUCCESS.getDescription())){
//						cmNew.setAuditStatus(MerchantAuditEnum.WAIT_BUSINESS.getCode());
//					}else if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_REJECTED.getDescription())){
//						cmNew.setAuditStatus(MerchantAuditEnum.FAIL_RISK.getCode());
//					}else if (gmqResp.getMerchantCaStatus().equals(MercCaDubRespAuthStatusEnum.MERCHANT_DUBBO_CODE_BASE_CER_ING.getDescription())){
//						cmNew.setAuditStatus(MerchantAuditEnum.WAIT_RISK.getCode());
//					}
//					try{
//						merchantCaService.updateMerchById(cmNew);
//					} catch (Exception e){
//						logger.error("updateMerchById error,merchantId:{}, auditStatus",cmNew.getMerchantId(),cmNew.getAuditStatus(),e);
//					}
//				}

				cm.setMerchantCaStatus(gmqResp.getMerchantCaStatus());
			}
			merchantLocalCount = merchantCaService.selectMerchantCountByParam(merchant);
			resultMap.put("rows", merchantList);
			resultMap.put("total", merchantLocalCount);

		} catch (Exception e) {
			logger.error("doQueryMerchantAudit error,{}",e);
			resultMap.put("rows", new ArrayList<CreditMerchant>());
			resultMap.put("total", 0);
			resultMap.put("success", false);
			resultMap.put("message", "异常，请稍后重试");
		}

		return resultMap;
	}

	/**
	 * Audit
	 * @author jiangbo@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doMerchantAudit.do")
	public Map<String, Object> doMerchantAudit(@RequestParam Map<String, String> map, String user,  CreditMerchant merchant) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "操作异常");

		String operaUserName = "test";
//		try {
//			operaUserName = getLoginRealName(user);
//		} catch (Exception e1) {
//			logger.error("getLoginRealName error",e1);
//			operaUserName = "error";
//			resultMap.put("message", "操作用户异常");
//			return resultMap;
//		}

		if (merchant.getMerchantId() == null){
			resultMap.put("success", false);
			resultMap.put("message", "商户id，不能为空");
			return resultMap;
		}

		CreditMerchant cmNew = new CreditMerchant();
		cmNew.setMerchantId(merchant.getMerchantId());
		cmNew.setModifier(operaUserName);
		cmNew.setAuditOpinion(merchant.getAuditOpinion());
		cmNew.setAuditOperator(operaUserName);
		cmNew.setAuditDate(new Date());

		if (merchant.getAuditStatus().equals("PASS_BUSINESS")) {
			cmNew.setAuditStatus(MerchantAuditEnum.PASS_BUSINESS.getCode());
		}else if (merchant.getAuditStatus().equals("FAIL_BUSINESS")){
			cmNew.setAuditStatus(MerchantAuditEnum.FAIL_BUSINESS.getCode());
		}else {
			resultMap.put("success", false);
			resultMap.put("message", "审核动作异常");
			return resultMap;
		}

		try{

			boolean result = merchantCaService.updateMerchById(cmNew);
			if (!result){
				logger.warn("updateMerchById failed,CreditMerchant:{}", ReflectionToStringBuilder.toString(cmNew));
				resultMap.put("success", false);
				resultMap.put("message", "审核操作失败");
				return resultMap;
			}else{
				logger.info("doMerchantAudit success,merchantId:{},auditStatus:{},operaUserName:{}",cmNew.getMerchantId(),cmNew.getAuditStatus(),operaUserName);
				resultMap.put("success", true);
				resultMap.put("message", "审核操作成功");

				//如果审核成功，查看是否有需要处理的万象订单
				if (cmNew.getAuditStatus().equals(MerchantAuditEnum.PASS_BUSINESS.getCode())){
					logger.info("doMerchantAudit start checkAndCreateWxOrder");
					CreditRequestParam<WxOrderParam> requestParam = new CreditRequestParam<WxOrderParam>();
					WxOrderParam wxOrderParam = new WxOrderParam();

					CreditMerchant creditMerchant = new CreditMerchant();
					creditMerchant.setMerchantId(merchant.getMerchantId());
					creditMerchant.setStart("0");
					creditMerchant.setLimit("1");

					List<CreditMerchant> creditMerchantList = merchantCaService.selectMerchantByParam(creditMerchant);

					wxOrderParam.setMerchantNo(creditMerchantList.get(0).getMerchantNo());

					requestParam.setParam(wxOrderParam);

					logger.info("creditWxOrderFacade.checkAndCreateWxOrder,requestParam:{}", GsonUtil.getInstance().toJson(requestParam));
					CreditResponseData<WxOrderResp> resp = creditWxOrderFacade.checkAndCreateWxOrder(requestParam);
					logger.info("creditWxOrderFacade.checkAndCreateWxOrder,resp:{}", GsonUtil.getInstance().toJson(resp));
				}

				return resultMap;
			}

		} catch (Exception e){
			logger.error("updateMerchById error,merchantId:{}, auditStatus:{},error:{}",cmNew.getMerchantId(),cmNew.getAuditStatus(),e);
		}

		return resultMap;
	}

	/**
	 * AuditType
	 * @author jiangbo@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doMerchantAuditType.do")
	public Map<String, Object> doMerchantAuditType(@RequestParam Map<String, String> map) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");

		List<TextValuePairs> list = new ArrayList<TextValuePairs>();
		for(MerchantAuditEnum merchantAudit : MerchantAuditEnum.values()){
			TextValuePairs pairs = new TextValuePairs(merchantAudit.getDescription(), merchantAudit.getCode());
			list.add(pairs);
		}

		resultMap.put("merchantAuditList", list);
		return resultMap;
	}

	/**
	 * 根据id查看商户认证信息
	 * @author jiangbo@jd.com
	 * @param map
	 * @param
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toMerchantAudit.view")
	public Map<String, Object> toMerchantAudit(@RequestParam Map<String, Object> map, CreditMerchant merchant) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		if (merchant.getMerchantId() == null) {
			logger.warn("toMerchantAudit, merchantId is null");
			return resultMap;
		}

		try{
			CreditMerchant newMerchant = new CreditMerchant();
			newMerchant.setMerchantId(merchant.getMerchantId());
			newMerchant.setLimit("2");
			newMerchant.setStart("0");

			List<CreditMerchant> merchantList = merchantCaService.selectMerchantByParam(newMerchant);
			CreditMerchant creditMerchant;
			if (merchantList != null && merchantList.size() > 0){
				creditMerchant = merchantList.get(0);
			}else {
				return resultMap;
			}

			if(StringUtils.isEmpty(creditMerchant.getMerchantNo())){
				return resultMap;
			}

			GatewayMerchantQueryResponse gmqResp = merchantCaService.queryMerchantInfoByHttp(creditMerchant);
			creditMerchant.setUserName(gmqResp.getUserName());
//			creditMerchant.setLinkPhone(gmqResp.getLinkPhone());

			CreditUser creditUserParam = new CreditUser();
			creditUserParam.setMerchantNo(creditMerchant.getMerchantNo());

			List<CreditUser> creditUserList = creditUserService.selectCreditUserByParam(creditUserParam);
			if (creditUserList != null && creditUserList.size() > 0) {
				for (int i = creditUserList.size() - 1 ; i >= 0; i--) {
					CreditUser creditUser = creditUserList.get(i);
					if (StringUtils.isBlank(creditUser.getPhone())){
						continue;
					}else {
						creditMerchant.setLinkPhone(creditUser.getPhone());
						creditMerchant.setUserName(creditUser.getLoginName());
						break;
					}
				}
			}
			resultMap.put("creditMerchant", creditMerchant);
		}catch (Exception e){
			logger.error("toMerchantAudit param:{}, error:{}:", ReflectionToStringBuilder.toString(merchant), e);
		}

		return resultMap;
	}

	/**
	 * 根据id查看商户认证信息
	 * @author jiangbo@jd.com
	 * @param map
	 * @param
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toQueryMerchant.view")
	public Map<String, Object> toQueryMerchant(@RequestParam Map<String, Object> map) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");
		return resultMap;
	}

	@ResponseBody
	@RequestMapping("doQueryMerchant.biz")
	public Map<String,Object> doQueryMerchant(@RequestParam Map<String, Object> map,CreditMerchant merchantParam){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");

		merchantParam.setAuditStatus(MerchantAuditEnum.PASS_BUSINESS.getCode());
		List<CreditMerchant> merchantList = merchantCaService.selectMerchantByParam(merchantParam);
		Integer total = merchantCaService.selectMerchantCountByParam(merchantParam);
		resultMap.put("rows", merchantList);
		resultMap.put("total", total);

		return resultMap;
	}

	@ResponseBody
	@RequestMapping("toChangePurchase.view")
	public Map<String, Object> toChangePurchase(@RequestParam Map<String, Object> map,String merchantNo) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");
		resultMap.put("merchantNo",merchantNo);
		return resultMap;
	}

	@ResponseBody
	@RequestMapping("doChangePurchase.biz")
	public Map<String,Object> doChangePurchase(@RequestParam Map<String, Object> map,CreditMerchant merchant){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");

		try {
			if(merchant.getPurchaseType()==null){
				merchant.setPurchaseType(CreditPurchaseTypeEnum.POST);
			}
			merchantCaService.updateMerchCallByNo(merchant);
		} catch (Exception e) {
			logger.error("doChangePurchase error,{}",e);
			resultMap.put("success", false);
		}
		return resultMap;
	}

	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2018年1月11日</li>
	 * <li>2、开发时间：下午4:20:54</li>
	 * <li>3、作 者：zhanghui12</li>
	 * <li>4、返回类型：Map<String,Object></li>
	 * <li>5、方法含义：给商户打标分类</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * 
	 * @param map
	 * @param merchantId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toMerchantClassify.view")
	public Map<String, Object> toMerchantClassify(@RequestParam Map<String, Object> map, String merchantId) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		if (StringUtils.isEmpty(merchantId)) {
			logger.warn("toMerchantClassify, merchantId is null");
			return resultMap;
		}
		try {
			CreditMerchant newMerchant = new CreditMerchant();
			newMerchant.setMerchantId(Integer.parseInt(merchantId));
			newMerchant.setLimit("2");
			newMerchant.setStart("0");

			List<CreditMerchant> merchantList = merchantCaService.selectMerchantByParam(newMerchant);
			CreditMerchant creditMerchant;
			if (merchantList != null && merchantList.size() > 0) {
				creditMerchant = merchantList.get(0);
			} else {
				return resultMap;
			}
			if (StringUtils.isEmpty(creditMerchant.getMerchantNo())) {
				return resultMap;
			}
			resultMap.put("creditMerchant", creditMerchant);
		} catch (Exception e) {
			logger.error("toMerchantClassify param:{}, error:{}", merchantId, e);
		}
		return resultMap;
	}

	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2018年1月11日</li>
	 * <li>2、开发时间：下午4:19:32</li>
	 * <li>3、作 者：zhanghui12</li>
	 * <li>4、返回类型：Map<String,Object></li>
	 * <li>5、方法含义：商户分类</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * 
	 * @param map
	 * @param merchantParam
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doMerchantClassify.biz")
	public Map<String, Object> doMerchantClassify(@RequestParam Map<String, Object> map, CreditMerchant merchantParam) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		if (merchantParam == null) {
			logger.warn("doMerchantClassify, merchant is null");
			resultMap.put("success", false);
			resultMap.put("message", "请求参数为空");
			return resultMap;
		}
		try {
			boolean updateResult = merchantCaService.updateMerchById(merchantParam);
			if (updateResult) {
				resultMap.put("success", true);
			} else {
				resultMap.put("success", false);
				resultMap.put("message", "修改数据库失败");
			}
		} catch (Exception e) {
			logger.error("doMerchantClassify param:{},error:{}", JSONObject.toJSONString(merchantParam), e);
			resultMap.put("success", false);
			resultMap.put("message", "未知异常");
		}
		return resultMap;
	}

    /**
     * 手动创建密钥
     * @param map
     * @param user
     * @param merchantQueryResp
     * @return
     */
    @ResponseBody
    @RequestMapping("/doCreateSecretKey.do")
    public Map<String, Object> doCreateSecretKey(@RequestParam Map<String, String> map, String user,
                                                        GatewayMerchantQueryResponse merchantQueryResp) {

        Map<String,Object> resultMap = new HashMap<String, Object>();
        String operaUserName = null;
        try {
            operaUserName = getLoginRealName(user);
        } catch (Exception e1) {
            logger.error("getLoginRealName error", e1);
            operaUserName = "error";
        }
        try {
            CreditMerchant merchant = new CreditMerchant();
            merchant.setMerchantNo(merchantQueryResp.getMerchant());
            merchant.setLimit("10");
            merchant.setStart("0");
            List<CreditMerchant> merchantList = merchantCaService.selectMerchantByParam(merchant);
            if(CollectionUtils.isEmpty(merchantList)){
                resultMap.put("success", false);
                resultMap.put("message", "该商户不存在，请稍后重试!");
                return resultMap;
            }
            CreditMerchant merchantExsit = merchantList.get(0);
            if(! MerchantAuditEnum.PASS_BUSINESS.getCode().equalsIgnoreCase(merchantExsit.getAuditStatus())){
                resultMap.put("success", false);
                resultMap.put("message", "该商户未实名认证通过，请稍后重试!");
                return resultMap;
            }
            if(MerchantAuditEnum.PASS_BUSINESS.getCode().equalsIgnoreCase(merchantExsit.getAuditStatus()) && StringUtil.isNotBlank(merchantExsit.getSecretKey())){
                resultMap.put("success", false);
                resultMap.put("message", "该商户密钥已存在,请勿重复生成!");
                return resultMap;
            }
            String secretKey = FlowNoUtils.createFlowMd5No("credit");
            CreditMerchant cm4SecretKey = new CreditMerchant();
            cm4SecretKey.setSecretKey(secretKey);
            cm4SecretKey.setMerchantId(merchantExsit.getMerchantId());
            boolean result = merchantCaService.updateMerchById(cm4SecretKey);
            if(true == result){
                resultMap.put("success", true);
                resultMap.put("message", "操作成功");
            }else{
                resultMap.put("success", false);
                resultMap.put("message", "操作失败，请重新操作!");
            }
        } catch (Exception e) {
            logger.error("doCreateSecretKey error,{}",e);
            resultMap.put("success", false);
            resultMap.put("message", "系统异常，请稍后重试");
        }

        return resultMap;

    }

}
