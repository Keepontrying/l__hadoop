package com.wangyin.boss.credit.enterprise.service.impl;

import com.wangyin.boss.credit.enterprise.beans.CrawlerJob;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResultsQueryParam;
import com.wangyin.boss.credit.enterprise.beans.CrawlerWord;
import com.wangyin.boss.credit.enterprise.dao.CrawlerJobMapper;
import com.wangyin.boss.credit.enterprise.service.CrawlerJobFlowService;
import com.wangyin.boss.credit.enterprise.service.CrawlerJobService;
import com.wangyin.boss.credit.enterprise.service.SensitiveWordService;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.utils.GsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * 舆情管理-爬虫任务管理
 *
 * @author huangzhiqiang
 * @data 2018/11/20
 */
@Service
public class CrawlerJobServiceImpl implements CrawlerJobService {
    private Logger logger = LoggerFactory.getLogger(CrawlerJobServiceImpl.class);

    @Resource
    private CrawlerJobMapper mapper;
    @Resource
    private SensitiveWordService wordService;
    @Resource
    private CrawlerJobFlowService flowService;

    @Override
    public Long insert(CrawlerJob job) {
        logger.info("添加爬虫任务" + GsonUtil.getInstance().toJson(job));
        List<CrawlerWord> words = job.getWords();
        Long jobId = null;
        if (words != null && !words.isEmpty()) {
            Integer jobWeight = 0;
            for (CrawlerWord word : words) {
                jobWeight += word.getWeight();
            }
            job.setWeight(jobWeight);
            mapper.insert(job);
            jobId = job.getId();
            for (CrawlerWord word : words) {
                word.setJobId(jobId);
                mapper.insertWord(word);
                wordService.insert(word);
            }
        }
        logger.info("舆情监控任务创建，异步发送");
        flowService.addJobFlow(job);
        logger.info("添加爬虫任务成功：" + jobId);
        return jobId;
    }

    @Override
    public void delete(Long id) {
        logger.info("删除爬虫任务：" + id);
        mapper.delete(id);
    }

    @Override
    public void update(CrawlerJob job) {
        List<CrawlerWord> words = job.getWords();
        if (words != null && !words.isEmpty()) {
            mapper.delWord(job.getId());
            Integer jobWeight = 0;
            for (CrawlerWord word : words) {
                jobWeight += word.getWeight();
            }
            job.setWeight(jobWeight);
            for (CrawlerWord word : words) {
                word.setJobId(job.getId());
                mapper.insertWord(word);
                wordService.insert(word);
            }
        }
        if (job.getCategory() != null && job.getCategory() == 0) {
            logger.info("实时任务，异步发送");
            flowService.addJobFlow(job);
        }
        mapper.update(job);
    }


    @Override
    public Page<CrawlerJob> query(CrawlerJobResultsQueryParam param) {
        Page<CrawlerJob> page = new Page<>();
        int total = mapper.queryCount(param);
        page.setTotal(total);
        if (total > 0) {
            List<CrawlerJob> jobs = mapper.query(param);
            for (CrawlerJob job : jobs) {
                job.setWords(mapper.queryWord(job.getId()));
            }
            page.setRows(jobs);
        }
        return page;
    }

    @Override
    public List<CrawlerJob> queryList(CrawlerJobResultsQueryParam param) {
        List<CrawlerJob> jobs = mapper.query(param);
        for (CrawlerJob job : jobs) {
            job.setWords(mapper.queryWord(job.getId()));
        }
        return jobs;
    }

}
