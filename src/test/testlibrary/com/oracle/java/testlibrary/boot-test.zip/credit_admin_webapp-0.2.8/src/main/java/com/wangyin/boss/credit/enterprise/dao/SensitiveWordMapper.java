package com.wangyin.boss.credit.enterprise.dao;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.enterprise.beans.SensitiveWord;
import com.wangyin.boss.credit.enterprise.beans.SensitiveWordQueryParam;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 敏感词
 *
 * @author huangzhiqiang
 * @data 2018/11/16
 */

@SqlMapper
@Component
public interface SensitiveWordMapper {

    Long insert(SensitiveWord word);

    void delete(Long id);

    void update(SensitiveWord word);

    Integer queryCount(SensitiveWordQueryParam param);

    List<SensitiveWord> query(SensitiveWordQueryParam param);
}
