package com.wangyin.boss.credit.admin;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wangyin.boss.credit.admin.dao.CreditAccessDetailsMapper;
import com.wangyin.boss.credit.admin.entity.CreditAccessDetails;

/**
 * 业务详单 测试类
 * 
 * @author wyhaozhihong
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:applicationContext.xml" })
public class CreditAccessDetailTest {

	@Autowired
	CreditAccessDetailsMapper creditAccessDetailsMapper;
	
	@Test
	public void insert(){
		CreditAccessDetails record = new CreditAccessDetails();
		record.setTradeNo("20160321131313002");
		record.setStrategyId(47);
		record.setRequestParam("{商户号：110103531，身份证：...}");
		record.setResponseParam("{商户号：110103531，响应代码：成功...}");
		record.setRequestTime(new Date());
		record.setResponseTime(new Date());
		record.setAccessStatus("success");
		record.setStepStatus("success");
		record.setRequestNo("20160324455666");
		record.setReturnStatus("success");
		record.setReturnCode("SUCCESS");
		creditAccessDetailsMapper.insert(record);
	}
	
}
