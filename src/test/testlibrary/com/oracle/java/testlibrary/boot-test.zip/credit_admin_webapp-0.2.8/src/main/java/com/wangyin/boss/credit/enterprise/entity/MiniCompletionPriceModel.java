package com.wangyin.boss.credit.enterprise.entity;

import java.io.Serializable;

/** 
* @desciption : mini尽调响应时间对应价格实体类
* @author : yangjinlin@jd.com
* @date ：2018年1月9日 下午9:29:27 
* @version 1.0 
* @return  */
public class MiniCompletionPriceModel implements Serializable {

	
	private static final long serialVersionUID = 2510365113485926473L;
	
	/**
	 * 时效对应价格
	 */
	private Integer complePrice;
	private String complePriceStr;//时效价格value
	private String completionType;//响应时间类型
	private String priceTypeType;//计价方式
	private Integer strategyId;//计费策略id
	

	public Integer getComplePrice() {
		return complePrice;
	}

	public void setComplePrice(Integer complePrice) {
		this.complePrice = complePrice;
	}

	public String getComplePriceStr() {
		return complePriceStr;
	}

	public void setComplePriceStr(String complePriceStr) {
		this.complePriceStr = complePriceStr;
	}

	public String getCompletionType() {
		return completionType;
	}

	public void setCompletionType(String completionType) {
		this.completionType = completionType;
	}

	public String getPriceTypeType() {
		return priceTypeType;
	}

	public void setPriceTypeType(String priceTypeType) {
		this.priceTypeType = priceTypeType;
	}

	public Integer getStrategyId() {
		return strategyId;
	}

	public void setStrategyId(Integer strategyId) {
		this.strategyId = strategyId;
	}
	
	
	
}
