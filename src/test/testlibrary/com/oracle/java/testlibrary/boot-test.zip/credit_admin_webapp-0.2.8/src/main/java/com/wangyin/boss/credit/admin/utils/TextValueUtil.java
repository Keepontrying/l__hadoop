package com.wangyin.boss.credit.admin.utils;

import com.jd.jr.boss.credit.domain.common.enums.TextValueInterface;
import com.wangyin.boss.credit.admin.beans.TextValuePairs;
import com.wangyin.operation.common.beans.ResponseData;
import org.apache.commons.lang3.reflect.MethodUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * 键值对工具类
 *
 * @author: dongzhihua
 * @time: 2018/10/31 10:54:54
 */
public class TextValueUtil {

    private static Logger logger = LoggerFactory.getLogger(TextValueUtil.class);

    /**
     * 将TextValue抽象的转成具体的
     * @author: dongzhihua
     * @time: 2018/10/31 11:04:20
     */
    public static List<TextValuePairs> toPairs(TextValueInterface[] collection) {
        List<TextValuePairs> list = new ArrayList<TextValuePairs>();
        for (TextValueInterface textValueInterface : collection) {
            list.add(new TextValuePairs(textValueInterface));
        }
        return list;
    }

    /**
     * 获取枚举选项
     * @author: dongzhihua
     * @time: 2018/11/2 12:18:33
     */
    public static List<TextValuePairs> getEnumOption(String type) {
        logger.info("getEnumOption type: {}", type);
        try {
            Class clazz = Class.forName(type);
            TextValueInterface[] values = (TextValueInterface[]) MethodUtils.invokeExactStaticMethod(clazz, "values");
            return TextValueUtil.toPairs(values);
        } catch (ClassNotFoundException e) {
            logger.info("getEnumOption 类型不存在: {}", e.getMessage());
            throw new RuntimeException("类型不存在");
        } catch (NoSuchMethodException e) {
            logger.info("getEnumOption : 不是枚举类型{}", e.getMessage());
            throw new RuntimeException("不是枚举类型");
        } catch (ClassCastException e) {
            logger.error("getEnumOption 枚举需要继承接口", e);
            throw new RuntimeException("枚举需要继承接口：TextValueInterface");
        } catch (Exception e) {
            logger.error("getEnumOption 异常", e);
            throw new RuntimeException(e.getMessage());
        }
    }
}
