package com.wangyin.boss.credit.admin.service;

import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.wangyin.boss.credit.admin.beans.param.CreditVipEnterpriseQueryParam;
import com.wangyin.boss.credit.admin.beans.param.CreditVipMerchantQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditProductSecond;
import com.wangyin.boss.credit.admin.entity.CreditVip;
import com.wangyin.boss.credit.admin.entity.CreditVipTask;

import java.util.List;

/** 
* @desciption : vip监控相关service接口类
* @author : yangjinlin@jd.com
* @date ：2017年6月28日 下午6:28:19 
* @version 1.0 
* @return  */
public interface CreditVipService {


	/**
	 * 多条件查询vip商户List  分页
	 * @param queryParam
	 * @return
	 */
	public CreditPage<CreditVip> selectVipMerchantPageByParam(CreditVipMerchantQueryParam queryParam);
	/**
	 * 多条件查询VIP企业list  分页
	 * @param queryParam
	 * @return
	 */
	public CreditPage<CreditVipTask> selectVipTaskPageByParam(CreditVipEnterpriseQueryParam queryParam);
	/**
	 * 批量更新vip商户监控状态
	 * @param creditVip
	 * @return 
	 * @throws Exception 
	 */
	public int batchModifyVipMerchantMonitorStatus(CreditVip creditVip) throws Exception;
	/**
	 * 根据商户号查询vip商户
	 * @param merchantId
	 * @return
	 */
	public CreditVip selectByMerchantId(Integer merchantId);
	/**
	 * 新增VIP商户
	 * @param creditVip
	 * @return
	 * @throws Exception 
	 */
	public Integer insertVipMerchant(CreditVip creditVip) throws Exception;

    /**
     * 根据主键id查找vip商户
     * @param creditVip
     * @return
     */
	public List<CreditVip> selectCreditVipByPrm(CreditVip creditVip);
	/**
	 * 修改vip商户监控信息
	 * @param creditVip
	 * @return
	 */
	public Integer updateVipMerchant(CreditVip creditVip);

    /**
     * 查询该商户的征信二级非黑名单产品
     * @param merchantId
     * @return
     */
    List<CreditProductSecond> selectProductSecondWithoutBlack(Integer merchantId);
}
