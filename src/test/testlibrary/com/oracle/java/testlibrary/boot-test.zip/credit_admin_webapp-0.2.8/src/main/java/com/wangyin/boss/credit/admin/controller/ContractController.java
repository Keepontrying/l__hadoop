package com.wangyin.boss.credit.admin.controller;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.chinabank.core.utils.StringUtil;
import com.google.gson.Gson;
import com.jd.jdjr.ras.api.domain.result.RasStatusResult;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.entity.merchant.MerchantAccountVo;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.response.merchant.GatewayMerchantQueryResponse;
import com.jd.jr.boss.credit.domain.common.enums.ContractStatusEnum;
import com.jd.jr.merchant.form.AuthBaseInfoForm;
import com.wangyin.boss.credit.admin.beans.TextValuePairs;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditContractDetails;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditProduct;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import com.wangyin.boss.credit.admin.enums.CreditContractHandleResultEnum;
import com.wangyin.boss.credit.admin.enums.CreditContractHandleTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditContractTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditMerchantResourceEnum;
import com.wangyin.boss.credit.admin.enums.CreditMerchantStatusEnum;
import com.wangyin.boss.credit.admin.enums.CreditProductStatusEnum;
import com.wangyin.boss.credit.admin.enums.CreditProductTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditTypeEnum;
import com.wangyin.boss.credit.admin.service.CreditContractDetailsService;
import com.wangyin.boss.credit.admin.service.CreditContractService;
import com.wangyin.boss.credit.admin.service.CreditMerchantService;
import com.wangyin.boss.credit.admin.service.CreditProductService;
import com.wangyin.boss.credit.admin.service.CreditProductStrategyService;
import com.wangyin.boss.credit.admin.service.MerchantCaService;
import com.wangyin.boss.credit.admin.utils.DateUtil;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.beans.UploadFile;
import com.wangyin.operation.beans.UploadObject;
import com.wangyin.operation.common.beans.Page;

/**
 * 征信产品合同及合同审核controller
 * Created by wyhaozhihong on 2016/6/29.
 */
@Controller
@RequestMapping("/contract")
public class ContractController extends BaseController{
	private static final Logger LOGGER = LoggerFactory.getLogger(ContractController.class);

	@Autowired
	CreditProductStrategyService creditProductStrategyService;

	@Autowired
	CreditProductService creditProductService;

	@Autowired
	CreditContractService creditContractService;

	@Autowired
	CreditContractDetailsService creditContractDetailsService;


	@Autowired
	CreditMerchantService creditMerchantService;

	@Autowired
	MerchantCaService merchantCaService;



	/**
	 * 查询征信产品合同数据、 查询合同内容审核数据  分页
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryContract.do")
	public Map<String, Object> doQueryContract(@RequestParam Map<String, Object> map,CreditContract creditContract) {
		Map<String,Object> resultMap = new HashMap<String, Object>();

		List<CreditContract> list = null;
		int count = 0;
		try {
			creditContract.setCreditType(CreditTypeEnum.PERSON.toName());
			if(StringUtils.isNotBlank(creditContract.getEndCreateDateStr())){
				creditContract.setEndCreateDateStr(DateUtil.getAfterDay(creditContract.getEndCreateDateStr()));
			}
			list = creditContractService.selectByParam(creditContract);
			for (CreditContract creditContract2 : list) {
				creditContract2.setContractStatus(ContractStatusEnum.enumValueOf(creditContract2.getContractStatus()).toDescription());
				creditContract2.setContractType(CreditContractTypeEnum.enumValueOf(creditContract2.getContractType()).toDescription());
			}
			count = creditContractService.selectCountByParam(creditContract);

			resultMap.put("rows", list);
			resultMap.put("total", count);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditContract>());
			resultMap.put("total", 0);
		}

		return resultMap;
	}

	/**
	 * 查询征信产品合同数据、 查询合同内容审核数据  分页
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryAuditContract.do")
	public Map<String, Object> doQueryAuditContract(@RequestParam Map<String, Object> map,CreditContract creditContract) {
		Map<String,Object> resultMap = new HashMap<String, Object>();

		List<CreditContract> list = null;
		int count = 0;
		try {
			if(StringUtils.isNotBlank(creditContract.getEndCreateDateStr())){
				creditContract.setEndCreateDateStr(DateUtil.getAfterDay(creditContract.getEndCreateDateStr()));
			}
			creditContract.setCreditType(CreditTypeEnum.PERSON.toName());
			list = creditContractService.selectAuditByParam(creditContract);
			for (CreditContract creditContract2 : list) {
				creditContract2.setContractStatus(ContractStatusEnum.enumValueOf(creditContract2.getContractStatus()).toDescription());
				creditContract2.setContractType(CreditContractTypeEnum.enumValueOf(creditContract2.getContractType()).toDescription());
			}
			count = creditContractService.selectCountAuditByParam(creditContract);

			resultMap.put("rows", list);
			resultMap.put("total", count);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditContract>());
			resultMap.put("total", 0);
		}

		return resultMap;
	}

	/**
	 * 根据合同ID查询合同详情
	 * @author wyhaozhihong
	 * @param map
	 * @param creditContract
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryContractDetail.do")
	public Map<String, Object> doQueryContractDetail(@RequestParam Map<String, Object> map,String contractId) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		/*查询合同信息*/
		CreditContract creditContract = creditContractService.selectByPrimaryKey(Integer.valueOf(contractId));
		creditContract.setContractType(CreditContractTypeEnum.enumValueOf(creditContract.getContractType()).toDescription());
		creditContract.setContractStatus(ContractStatusEnum.enumValueOf(creditContract.getContractStatus()).toDescription());
		creditContract.setCreatedDateStr(df1.format(creditContract.getCreatedDate()));
		creditContract.setAuditTimeStr(creditContract.getAuditTime() == null ? null : df1.format(creditContract.getAuditTime()));
		creditContract.setEnsureTimeStr(creditContract.getEnsureTime() == null ? null : df1.format(creditContract.getEnsureTime()));
		creditContract.setStartDateTimeStr(df.format(creditContract.getStartTime()));
		creditContract.setFinishDateTimeStr(df.format(creditContract.getFinishTime()));
		creditContract.setAdvancePaymentStr(new BigDecimal(creditContract.getAdvancePayment()).divide(new BigDecimal("100")).toString());
		resultMap.put("creditContract", creditContract);

		/*查询商户信息*/
		CreditMerchant creditMerchant = creditMerchantService.selectByMerchantId(creditContract.getMerchantId());
		creditMerchant.setMerchantResource(CreditMerchantResourceEnum.enumValueOf(creditMerchant.getMerchantResource()).toDescription());
		resultMap.put("creditMerchant", creditMerchant);

		return resultMap;
	}

	/**
	 * 根据合同ID编辑合同
	 * @author wyhaozhihong
	 * @param map
	 * @param creditContract
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toEditContract.do")
	public Map<String, Object> toEditContract(@RequestParam Map<String, Object> map,String contractId) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

		/*查询合同信息*/
		CreditContract creditContract = creditContractService.selectByPrimaryKey(Integer.valueOf(contractId));
		creditContract.setStartDateTimeStr(df.format(creditContract.getStartTime()));
		creditContract.setFinishDateTimeStr(df.format(creditContract.getFinishTime()));
		creditContract.setAdvancePaymentStr(new BigDecimal(creditContract.getAdvancePayment()).divide(new BigDecimal("100")).toString());
		resultMap.put("creditContract", creditContract);

		/*查询商户信息*/
		CreditMerchant creditMerchant = creditMerchantService.selectByMerchantId(creditContract.getMerchantId());
		resultMap.put("creditMerchant", creditMerchant);

		return resultMap;
	}

	/**
	 * 合同作废申请、中止合同、驳回合同申请公用方法
	 * @author wyhaozhihong
	 * @param map
	 * @param contractId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doCancelContract.do")
	public Map<String, Object> doCancelContract(@RequestParam Map<String, Object> map,String contractId,String user,String cancelRemark,String contractStatus) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");

		CreditContract creditContract = new CreditContract();
		creditContract.setContractId(Integer.valueOf(contractId));
		creditContract.setContractStatus(contractStatus);
		creditContract.setCancelRemark(cancelRemark);

		try {
			String realName = getLoginRealName(user);
			creditContract.setModifier(realName);
		} catch (Exception e) {
			LOGGER.error(e);
			creditContract.setModifier("error");
		}
		int count = creditContractService.updateContractByPrimaryKey(creditContract);
		if(count != 1){
			resultMap.put("success", false);
			resultMap.put("message", "操作失败");
		}
		return resultMap;
	}

	/**
	 * 下载合同文件
	 * @author wyhaozhihong
	 * @param creditContract
	 * @return
	 */
	@RequestMapping("/downloadContract.do")
	@ResponseBody
	public UploadFile downloadContract(String contractId) {

		UploadFile uploadfile = new UploadFile();

		try {
			CreditContract creditContract = creditContractService.selectByPrimaryKey(Integer.valueOf(contractId));
			if (creditContract != null) {
				// 等同于setPath + setName
				uploadfile.setPathname( "credit/pdf/" + creditContract.getContractPath());
			}
		} catch (Exception e) {
			LOGGER.error("下载合同文件失败" + e.getMessage(), e);
		}
		uploadfile.setVersion("2.0");// 上传时用2.0版本。所以下载时也用2.0版本
		uploadfile.setTemp(false);// 上传时，传到临时路径，所以这里也从临时路径下载

		return uploadfile;
	}

	/**
	 * 上传合同文件
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@RequestMapping("/doUploadContract.biz")
	@ResponseBody //将UploadObject对象转换成json
	public UploadObject doUploadContract(@RequestParam Map<String,Object> map){
		String uploadObjectStr = String.valueOf(map.get("uploadObject"));
		Gson gson = new Gson();//json处理工具随意用什么fastjson、jsonlib、jackson。。。。等

		UploadObject uploadObject = gson.fromJson(uploadObjectStr, UploadObject.class);
		uploadObject.setVersion("2.0");
		String contractId = uploadObject.getParams().get("contractId");
		CreditContract creditContract = creditContractService.selectByPrimaryKey(Integer.valueOf(contractId));

		if(creditContract == null) {
			LOGGER.error("合同文件上传失败-合同不存在，合同Id" + contractId);
			return null;
		}

		List<UploadFile> list = uploadObject.getFileList();

		for (UploadFile uploadFile : list) {
			uploadFile.setPath(getContractPdfFilePath(creditContract));//设置上传到NFS的相对路径
			uploadFile.setName(creditContract.getContractId() + StringUtils.trimToEmpty(creditContract.getContractNo()));//设置上传到NFS的名称（不含后缀），具体可以看UploadObject的注释
			uploadFile.setTemp(false);
		}
		return uploadObject;
	}

	/**
	 * 上传合同文件回调方法
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@RequestMapping("/doUploadContractCallback.biz")
	@ResponseBody //将UploadObject对象转换成json
	public Map<String,Object> doUploadContractCallback(@RequestParam Map<String,Object> map){
		Map<String,Object> result = new HashMap<String,Object>();
		String uploadObjectStr = String.valueOf(map.get("uploadObject"));//拿到上传对象
		Gson gson = new Gson();//json处理工具随意

		UploadObject uploadObject = gson.fromJson(uploadObjectStr, UploadObject.class);//json->object
		List<UploadFile> list = uploadObject.getFileList();//得到上传文件列表

		Map<String, String> param = uploadObject.getParams();

		String contractId = uploadObject.getParams().get("contractId");
		CreditContract creditContract = creditContractService.selectByPrimaryKey(Integer.valueOf(contractId));

		UploadFile file = null;
		if (creditContract != null
				&& uploadObject.isSuccess()
				&& list.size() == 1
				&& (file = list.get(0)) != null
				&& creditContractService.updateContractForUpload(param.get("contractId"),
						subtractPdfPath(file.getPathname()))
				) {
			String subtractPdfPath = subtractPdfPath(file.getPathname());
			LOGGER.debug("文件上传成功，文件路径是"+subtractPdfPath);
			result.put("success", true);// 前台可能会做个处理，上传成功跳转等等。demo中页面只是使用了message中的信息
			result.put("filePath", file.getPathname());
			result.put("message", "文件上传成功");
		} else {
			result.put("success", false);
			result.put("message", "文件上传失败");

			if (list.size() == 0 || (file = list.get(0)) == null) {
				result.put("message", "文件为空");
			}
		}
		return result;//返回json串，前台进行处理
	}

	/**
	 * 查询产品名称和产品表的主键ID
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryProduct.do")
	public Map<String, Object> queryProduct(@RequestParam Map<String, Object> map, CreditProduct creditProductParam) {
		Map<String, Object> result = new HashMap<String, Object>();
		List<TextValuePairs> list = new ArrayList<TextValuePairs>();
		CreditProduct cp = new CreditProduct();
		cp.setProductStatus(CreditProductStatusEnum.CREDIT_ROSTER_OPEN.toName());
		cp.setProductType(CreditProductTypeEnum.PERSON.toName());//个人征信产品
		List<CreditProduct> productList = creditProductService.select(cp);
		for (CreditProduct creditProduct : productList) {
			TextValuePairs TextValuePairs = new TextValuePairs(creditProduct.getProductName(),creditProduct.getProductId().toString());
			list.add(TextValuePairs);
		}

		result.put("list", list);
		return result;
	}

	/**
	 * 从合同状态枚举类中获取状态列表
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryContractStatusInEnum.do")
	public Map<String, Object> queryContractStatusInEnum(@RequestParam Map<String, Object> map) {
		Map<String, Object> result = new HashMap<String, Object>();
		List<TextValuePairs> list = new ArrayList<TextValuePairs>();
		for(ContractStatusEnum status : ContractStatusEnum.values()){
			if(null == status.toName() || "NULL".equals(status.toName())){
				continue;
			}else{
				TextValuePairs pairs = new TextValuePairs(status.toDescription(), status.toName());
				list.add(pairs);
			}
		}
		result.put("contractStatusList", list);
		return result;
	}



	/**
	 * 校验商户号是否存在---调用商户列表接口获取商户信息
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doValidMerchantNo.do")

	public Map<String, Object> doValidMerchantNo(@RequestParam Map<String, Object> map, String merchantNo) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "验证成功");

		/*检验商户号是否存在*/
		Page<GatewayMerchantQueryResponse> pageData = new Page<GatewayMerchantQueryResponse>();
		List<MerchantAccountVo> merchantAccountList = new ArrayList<MerchantAccountVo>();
		List<CreditMerchant> merchList = new ArrayList<CreditMerchant>();
		List<CreditMerchant> merchantList = new ArrayList<CreditMerchant>();
		List<TextValuePairs> merchantResourceList = new ArrayList<TextValuePairs>();

		try {
			pageData = merchantCaService.queryMerchantInfoByOne(merchantNo);//调用商户列表接口查询该商户的基本信息
			if(CollectionUtils.isEmpty(pageData.getRows())){
				resultMap.put("success", false);
				resultMap.put("message", "该商户号不存在");
				return resultMap;
			}
			MerchantAccountVo queryMerchantAccountVo = new MerchantAccountVo();
			queryMerchantAccountVo.setMerchantNo(merchantNo);
			merchantAccountList = merchantCaService.queryMerchantAccountByNo(queryMerchantAccountVo);//调用商户账户接口查询该商户的账户信息
			if(CollectionUtils.isEmpty(merchantAccountList)){
				resultMap.put("success", false);
				resultMap.put("message", "该商户无账户代码");
				return resultMap;
			}

			//商户存在且状态为CLOSE时，直接返回前台提示
			merchList =  creditMerchantService.selectMerchListByNo(merchantNo);//查询商户表,产品设计规则的查询结果是一个商户号在商户表中至多有1条记录
			if(!CollectionUtils.isEmpty(merchList) && CreditMerchantStatusEnum.CLOSE.toName().equals(merchList.get(0).getMerchantStatus())){
				//若商户状态为CLOSE则提示商户不可用并且不可进行合同创建
				resultMap.put("success", false);
				resultMap.put("message", "该商户的状态为:"+ CreditMerchantStatusEnum.CLOSE.toDescription());
				return resultMap;
			}

			/*查询商户关系表，查看是否申请过合同，若申请过，则用已申请过的商户名称和账户代码；若没申请过合同则需要调用企业站接口查询账户代码信息*/
			List<CreditContract> contrMercList = creditContractService.selectContractByMerchantNo(merchantNo);

			if(!CollectionUtils.isEmpty(contrMercList)){//该商户已申请过合同

				CreditMerchant creditMerchant1 = new CreditMerchant();
				creditMerchant1.setMerchantName(merchList.get(0).getMerchantName());
				creditMerchant1.setMerchantCode(merchList.get(0).getMerchantCode());
				creditMerchant1.setMerchantSub(merchList.get(0).getMerchantSub());
				creditMerchant1.setMerchantResource(merchList.get(0).getMerchantResource());
				merchantList.add(creditMerchant1);
				merchantResourceList.add(new TextValuePairs(CreditMerchantResourceEnum.enumValueOf(merchList.get(0).getMerchantResource()).toDescription(),
						CreditMerchantResourceEnum.enumValueOf(merchList.get(0).getMerchantResource()).toName()));
				resultMap.put("firstName", creditMerchant1.getMerchantName());
				resultMap.put("exsitFlag", "has");

			}else{

				RasStatusResult rasStatusResult = merchantCaService.queryAuthMerchantByNo(merchantNo);//调用商户认证接口查询接口
				if(null == rasStatusResult){
					resultMap.put("success", false);
					resultMap.put("message", "该商户号未实名认证");
					return resultMap;
				}else{
					resultMap.put("firstName",rasStatusResult.getCompanyName());//
				}

				for(MerchantAccountVo merhaccu : merchantAccountList){
					CreditMerchant creditMerchant1 = new CreditMerchant();
					for (GatewayMerchantQueryResponse merchantQryResp : pageData.getRows()) {
						if(merchantQryResp.getMerchant().equals(merhaccu.getMerchantNo())){
							creditMerchant1.setMerchantCode(merhaccu.getId());//账户代码之前取orgCode，现在取Id,code是老清结算中一代三代商户号的标识
							creditMerchant1.setMerchantSub(merhaccu.getOrgCode());//二级商户号
						}
						creditMerchant1.setMerchantName(merchantQryResp.getCompanyName());
						merchantList.add(creditMerchant1);
					}
				}
				//遍历商户来源常量类
				for(CreditMerchantResourceEnum status : CreditMerchantResourceEnum.values()){
					if(null == status.toName() || "NULL".equals(status.toName())){
						continue;
					}else{
						TextValuePairs pairs = new TextValuePairs(status.toDescription(), status.toName());
						merchantResourceList.add(pairs);
					}
				}
			}

			resultMap.put("merchantResourceList", merchantResourceList);

			resultMap.put("merchantList", merchantList);

		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditContract>());
			resultMap.put("total", 0);
			return resultMap;
		}

		return resultMap;
	}


	/**
	 * 创建征信产品合同
	 * @author wyhaozhihong
	 * @param map
	 * @param creditContract
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doCreateContract.do")
	public Map<String, Object> doCreateContract(@RequestParam Map<String, Object> map,
			CreditContract creditContract, CreditMerchant creditMerchant, String user, String strategyIdStr) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "创建征信产品合同成功");

		/*获取登录人名称*/
		String userName = null;
		try {
			userName = getLoginRealName(user);
		} catch (Exception e1) {
			LOGGER.error(e1);
			userName = "error";
		}

		/*设置合同表的登录人、修改人和商户关系表的创建人 为登录人名称*/
		creditContract.setCreator(userName);
		creditContract.setModifier(userName);
		creditMerchant.setCreator(userName);
		creditMerchant.setModifier(userName);

		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		try {
			creditContract.setStartTime(df.parse(creditContract.getStartDateTimeStr()));
			creditContract.setFinishTime(df.parse(creditContract.getFinishDateTimeStr()));
		} catch (ParseException e1) {
			LOGGER.error(e1);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
		}

		/*将以逗号分隔的一个或者多个计费ID转换为string数组*/
		String[] strategyIds = null;
		if(StringUtils.isNotBlank(strategyIdStr)){
			strategyIds = strategyIdStr.substring(1).split("&");
			/*校验计费策略的有效期是否在合同有效期之内*/
			List<CreditProductStrategy> list = creditProductStrategyService.selectBatchByPrimaryKey(Arrays.asList(strategyIds));
			for (CreditProductStrategy creditProductStrategy : list) {
				if(creditContract.getStartTime().compareTo(creditProductStrategy.getStartTime()) > 0 ||
						creditProductStrategy.getFinishTime().compareTo(creditContract.getFinishTime()) > 0){
					resultMap.put("success", false);
					resultMap.put("message", "计费策略的有效期应在合同有效期内");
					return resultMap;
				}
			}
		}

		int contractId = 0;
		try {

			boolean verifyResult = notNullVerification(creditContract, creditMerchant);
			if (!verifyResult) {
				resultMap.put("success", false);
				resultMap.put("message", "带*的输入框全为必填项！");
				return resultMap;
			}

			BigDecimal bg = new BigDecimal("100");
			creditContract.setAdvancePayment(new BigDecimal(creditContract.getAdvancePaymentStr()).multiply(bg).longValue());

			contractId = creditContractService.createContract(creditContract, creditMerchant, strategyIds);
			resultMap.put("contractId", contractId);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
			return resultMap;
		}
		if (contractId == 0) {
			resultMap.put("success", false);
			resultMap.put("message", "创建征信产品合同失败");
		}
		return resultMap;
	}

    /**
     * 合同内容 审核
     * @param map
     * @param user
     * @param creditContract
     * @return
     */
	@ResponseBody
	@RequestMapping("doAuditContract.do")
	public Map<String, Object> doAuditContract(@RequestParam Map<String, Object> map, String user,
			CreditContract creditContract) {
		Map<String, Object> resultMap = new HashMap<String, Object>();

		String userName = null;
		try {
			//userName是登录名,RealName是中文别名,getLoginRealName()返回的是userName
			userName = getLoginRealName(user);
		} catch (Exception e) {
			LOGGER.error(e);
			userName = "error";
		}
		creditContract.setAuditor(userName);
		creditContract.setAuditTime(new Date());
		try {
			int count = creditContractService.modifyContractByPrimaryKey(creditContract);
			if(count == 1){
				resultMap.put("success", true);
				resultMap.put("message", "审核成功");
				return resultMap;
			}else{
				resultMap.put("success", false);
				resultMap.put("message", "审核失败");
			}
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "审核异常");
		}
		return resultMap;
	}

    /**
     * 获取合同PDF存放路径
     * @param creditContract
     * @return
     */
	public String getContractPdfFilePath(CreditContract creditContract) {

		return "/pdf/" + new SimpleDateFormat("yyyy/MM/dd").format(
				creditContract.getStartTime())
				+ "/";
	}

	/**
	 * 去除PDF文件路径的pdf/以及之前的部分
	 * @param pdfFilePathName
	 * @return
	 */
	public static String subtractPdfPath(String pdfFilePathName) {
		if (StringUtils.isEmpty(pdfFilePathName)) {
			return "";
		}

		String pdf = "pdf/";
		int beginIndex = pdf.length();

		int pdfIndex = pdfFilePathName.indexOf(pdf);
		if(pdfIndex > 0) {
			beginIndex += pdfIndex;
		}

		return pdfFilePathName.substring(beginIndex);
	}


    /**
     * 根据合同ID 查询 合同操作记录表
     * @param map
     * @param contractId
     * @return
     */
	@ResponseBody
	@RequestMapping("doQueryCreditContractDetail.do")
	public Map<String, Object> doQueryCreditContractDetail(@RequestParam Map<String, Object> map, String contractId) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		List<CreditContractDetails> list = null;
		try {
			list = creditContractDetailsService.selectByContractId(Integer.valueOf(contractId));
			for (CreditContractDetails creditContractDetails : list) {
				creditContractDetails.setCreatedDateStr(df.format(creditContractDetails.getCreatedDate()));
				creditContractDetails.setHandleType(CreditContractHandleTypeEnum.getValueByCode(creditContractDetails.getHandleType()));
				creditContractDetails.setHandleResult(CreditContractHandleResultEnum.getValueByCode(creditContractDetails.getHandleResult()));
			}
			resultMap.put("rows", list);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditContract>());
		}
		return resultMap;
	}

	/**
	 * 查询商户来源枚举类作为下拉数据源
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryCreditMerchantResourceEnum.do")
	public Map<String, Object> queryCreditMerchantResourceEnum(@RequestParam Map<String, Object> map) {
		Map<String, Object> result = new HashMap<String, Object>();
		List<TextValuePairs> creditMerchantResourceList = new ArrayList<TextValuePairs>();
		List<CreditMerchant> merchList = new ArrayList<CreditMerchant>();
		try {
			merchList =  creditMerchantService.selectMerchListByNo(map.get("merchantNo").toString());//查询商户表,产品设计规则的查询结果是一个商户号在商户表中至多有1条记录

			if(!CollectionUtils.isEmpty(merchList) && StringUtil.isNotBlank(merchList.get(0).getMerchantResource())){//该商户已存在且商户来源不为空

				creditMerchantResourceList.add(new TextValuePairs(CreditMerchantResourceEnum.enumValueOf(merchList.get(0).getMerchantResource()).toDescription(),
						CreditMerchantResourceEnum.enumValueOf(merchList.get(0).getMerchantResource()).toName()));

			}else{
				for(CreditMerchantResourceEnum status : CreditMerchantResourceEnum.values()){
					if(null == status.toName() || "NULL".equals(status.toName())){
						continue;
					}else{
						TextValuePairs pairs = new TextValuePairs(status.toDescription(), status.toName());
						creditMerchantResourceList.add(pairs);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(e);
		}

		result.put("creditMerchantResourceList", creditMerchantResourceList);
		return result;
	}

	/**
	 * 校验creditContract实体的必填项
	 * @param creditContract 合同实体类
	 */
	private boolean notNullVerification(CreditContract creditContract, CreditMerchant creditMerchant) {

		if(StringUtils.isBlank(creditContract.getMerchantNo())){
			return false;
		}
		if(StringUtils.isBlank(creditContract.getContractNo())){
			return false;
		}
		if(StringUtils.isBlank(creditContract.getContractVersion())){
			return false;
		}
		if(StringUtils.isBlank(creditContract.getAdvancePaymentStr())){
			return false;
		}
		if(StringUtils.isBlank(creditContract.getSalesManager())){
			return false;
		}
		if(StringUtils.isBlank(creditContract.getStartTime().toString())){
			return false;
		}
		if(StringUtils.isBlank(creditContract.getFinishTime().toString())){
			return false;
		}

		return true;
	}
}
