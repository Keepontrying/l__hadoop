package com.wangyin.boss.credit.enterprise.service;

import com.jd.jr.boss.credit.facade.authen.beans.entity.JsfConfigBean;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchDataQueryParam;

import java.util.Map;

public interface CreditBatchDeriveDataService {

    boolean upload(Map<String, String> params, String filePath);

    Map<String,Object> exportDataList(BatchDataQueryParam map);

    Map<String,Object> queryJsfConfigList(JsfConfigBean jsfConfigBean);

    Map<String, Object> saveOrUpdateJsfConfig(JsfConfigBean jsfConfigBean);

    Map<String,Object> queryResult(Map<String,Object> jsfConfigBean);

    Map<String,Object> queryJsfConfig(JsfConfigBean jsfConfigBean);

    Map<String,Object> exportOutsideData(Map<String,Object> param);

    Map<String,Object> getJsfConfigInterfaceId(JsfConfigBean jsfConfigBean);

    Map<String,Object> getMethodList(JsfConfigBean jsfConfigBean);

    Map<String,Object> getInterfaceDetailInf(Map<String,Object> param);

    Map<String,Object> getAliasByInterfaceId(Map<String,Object> param);

    Map<String,Object> getUserInfo(String id, String userPin);
}
