package com.wangyin.boss.credit.enterprise.controller;

import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.controller.CreditRosterController;
import com.wangyin.boss.credit.enterprise.beans.*;
import com.wangyin.boss.credit.enterprise.service.*;
import com.wangyin.boss.credit.enterprise.utils.PublicSentimentExcelUtil;
import com.wangyin.operation.beans.UploadFile;
import com.wangyin.operation.beans.UserModel;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.DateUtil;
import com.wangyin.operation.utils.GsonUtil;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.io.File;
import java.util.Date;

/**
 * 舆情监控
 *
 * @author huangzhiqiang
 * @data 2018/11/19
 */
@Controller
@RequestMapping("/publicSentiment")
public class PublicSentimentController {
    private Logger logger = LoggerFactory.getLogger(CreditRosterController.class);

    @Resource
    private SensitiveWordService sensitiveWordService;
    @Resource
    private SensitiveWordGroupService sensitiveWordGroupService;
    @Resource
    private CrawlerJobService crawlerJobService;
    @Resource
    private CrawlerJobFlowService flowService;
    @Resource
    private CrawlerJobResultsService crawlerJobResultsService;

    /**
     * 添加敏感词
     *
     * @param word
     */
    @RequestMapping(value = "addWord", method = RequestMethod.POST)
    @ResponseBody
    public ResponseData addWord(SensitiveWord word) {
        logger.info("增加敏感词入参：" + GsonUtil.getInstance().toJson(word));
        return new ResponseData<>(sensitiveWordService.insert(word));
    }

    /**
     * 添加敏感词组
     *
     * @param word
     */
    @RequestMapping(value = "addGroup", method = RequestMethod.POST)
    @ResponseBody
    public ResponseData addGroup(SensitiveWordGroup word) {
        logger.info("增加敏感词组入参：" + GsonUtil.getInstance().toJson(word));
        return new ResponseData<>(sensitiveWordGroupService.insert(word));
    }

    /**
     * 删除敏感词
     *
     * @param id
     */
    @RequestMapping("delWord")
    @ResponseBody
    public ResponseData delWord(Long id) {
        logger.info("删除敏感词入参：" + id);
        sensitiveWordService.delete(id);
        return new ResponseData();
    }

    /**
     * 更新敏感词
     *
     * @param word
     */
    @RequestMapping(value = "updateWord", method = RequestMethod.POST)
    @ResponseBody
    public ResponseData updateWord(SensitiveWord word) {
        logger.info("修改敏感词入参：" + GsonUtil.getInstance().toJson(word));
        sensitiveWordService.update(word);
        return new ResponseData();
    }

    /**
     * 更新敏感词组
     *
     * @param word
     */
    @RequestMapping(value = "updateGroup", method = RequestMethod.POST)
    @ResponseBody
    public ResponseData updateGroup(SensitiveWordGroup word) {
        logger.info("修改敏感词入参：" + GsonUtil.getInstance().toJson(word));
        sensitiveWordGroupService.update(word);
        return new ResponseData();
    }

    /**
     * 条件查询敏感词
     *
     * @param param
     * @return
     */
    @RequestMapping("queryWords")
    @ResponseBody
    public Page<SensitiveWord> queryWords(SensitiveWordQueryParam param) {
        logger.info("查询敏感词入参：" + GsonUtil.getInstance().toJson(param));
        return sensitiveWordService.query(param);
    }

    /**
     * 条件查询敏感词
     *
     * @param param
     * @return
     */
    @RequestMapping("queryGroups")
    @ResponseBody
    public Page<SensitiveWordGroup> queryGroups(SensitiveWordQueryParam param) {
        logger.info("查询敏感词入参：" + GsonUtil.getInstance().toJson(param));
        return sensitiveWordGroupService.query(param);
    }

    /**
     * 添加爬虫任务
     *
     * @param job
     * @return
     */
    @RequestMapping("addJob")
    @ResponseBody
    public ResponseData addCrawlerJob(CrawlerJob job) {
        logger.info("添加爬虫任务入参：" + GsonUtil.getInstance().toJson(job));
        return new ResponseData<>(crawlerJobService.insert(job));
    }

    /**
     * 删除爬虫任务
     *
     * @param id
     */
    @RequestMapping("delJob")
    @ResponseBody
    public ResponseData delCrawlerJob(Long id) {
        logger.info("删除爬虫任务入参：" + id);
        crawlerJobService.delete(id);
        return new ResponseData();
    }

    /**
     * 删除爬虫任务
     *
     * @param job
     */
    @RequestMapping("updateJob")
    @ResponseBody
    public ResponseData updateCrawlerJob(CrawlerJob job) {
        logger.info("更新爬虫任务入参：" + GsonUtil.getInstance().toJson(job));
        crawlerJobService.update(job);
        return new ResponseData();
    }

    /**
     * 条件查询爬虫任务
     *
     * @param param
     * @return
     */
    @RequestMapping("queryJob")
    @ResponseBody
    public Page<CrawlerJob> queryCrawlerJob(CrawlerJobResultsQueryParam param) {
        logger.info("查询爬虫任务入参：" + GsonUtil.getInstance().toJson(param));
        return crawlerJobService.query(param);
    }

    /**
     * 条件查询爬虫任务
     *
     * @param param
     * @return
     */
    @RequestMapping("queryResults")
    @ResponseBody
    public Page<CrawlerJobResults> queryJobResults(CrawlerJobResultsQueryParam param,
                                                   @RequestParam(value = "user") UserModel userModel) {
        logger.info("查询爬虫任务返回结果入参：" + GsonUtil.getInstance().toJson(param));
        return crawlerJobResultsService.query(param);
    }

    @RequestMapping("exportXlsx")
    @ResponseBody
    public Object exportXlsx(CrawlerJobResultsQueryParam param) throws Exception {
        param.setLimit(10000);
        String abPath = ConfigUtil.getString("app.credit.temp.path");
        String relativePath = "credit/export/";
        String fileName = DateUtil.getInstance(DateUtil.FORMAT6).format(new Date()) + ".xlsx";

        File template = ResourceUtils.getFile("classpath:templates/publicSentimentExport.xlsx");

        File target = new File(abPath, relativePath + fileName);
        DateTimeFormatter format;
        if (param.getCategory() == 0) {
            format = DateTimeFormat.forPattern("yyyy-MM-dd HH");
        } else {
            format = DateTimeFormat.forPattern("yyyy-MM-dd");
        }
        param.setTime1(DateTime.parse(param.getTimeStr1(), format).toDate());
        param.setTime2(DateTime.parse(param.getTimeStr2(), format).toDate());
        Page<CrawlerJobResults> query = crawlerJobResultsService.queryList(param);
        PublicSentimentExcelUtil.export(query, template, target);
        UploadFile u = new UploadFile(relativePath, fileName, fileName);
        u.setVersion("2.0");
        u.setTemp(true);
        return u;
    }
}
