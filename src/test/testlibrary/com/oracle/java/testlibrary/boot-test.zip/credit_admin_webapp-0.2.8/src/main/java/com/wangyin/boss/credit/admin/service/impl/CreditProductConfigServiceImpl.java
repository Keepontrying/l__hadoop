package com.wangyin.boss.credit.admin.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wangyin.boss.credit.admin.dao.CreditChangeRecordMapper;
import com.wangyin.boss.credit.admin.dao.CreditProductConfigMapper;
import com.wangyin.boss.credit.admin.entity.CreditChangeRecord;
import com.wangyin.boss.credit.admin.entity.CreditProductConfig;
import com.wangyin.boss.credit.admin.service.CreditProductConfigService;

/** 
* @desciption : 产品服务配置接口方法实现类
* @author : yangjinlin@jd.com
* @date ：2016年8月29日 下午3:27:17 
* @version 1.0 
* @return  */
@Service
public class CreditProductConfigServiceImpl implements CreditProductConfigService {

	@Autowired
    private CreditProductConfigMapper creditProductConfigMapper;
	
	@Autowired
	CreditChangeRecordMapper creditChangeRecordMapper;
	
	@Override
	public List<CreditProductConfig> selectCreProdConfByPams(CreditProductConfig creditProductConfig) {
		
		return creditProductConfigMapper.selectCreProdConfByPams(creditProductConfig);
	}

	@Override
	public int selectCountByParam(CreditProductConfig creditProductConfig) {
		
		return creditProductConfigMapper.selectCountByParam(creditProductConfig);
	}

	@Override
	public CreditProductConfig selectCredProdConfByConfId(Integer configId) {
		
		return creditProductConfigMapper.selectCredProdConfByConfId(configId);
	}

	@Override
	public int updateCredProdConfByConfId(CreditProductConfig creditProductConfig, 
			String operaUserName, String remark) throws Exception{
		
		int updateCount = creditProductConfigMapper.updateCredProdConfByConfId(creditProductConfig);
//		if(updateCount == 1){//更新产品服务配置信息表的状态成功后，往credit_change_record表中新增记录
//			CreditChangeRecord creditChangeRecord = new CreditChangeRecord();
//			creditChangeRecord.setConfigId(creditProductConfig.getConfigId());
//			creditChangeRecord.setChangeStatus(creditProductConfig.getConfigStatus());
//			creditChangeRecord.setRemarks(remark);
//			creditChangeRecord.setCreator(operaUserName);
//			creditChangeRecordMapper.insert(creditChangeRecord);
//		}
		return updateCount;
	}

	@Override
	public List<CreditChangeRecord> selectCredChanRecdsByConfigId(Integer configId) {
		// TODO Auto-generated method stub
		return creditChangeRecordMapper.selectCredChanRecdsByConfigId(configId);
	}

	@Override
	public List<CreditProductConfig> selectCredProdConfByProdMercId(Map<String, Object> params) {
		return creditProductConfigMapper.selectCredProdConfByProdMercId(params);
	}

	@Override
	public List<CreditProductConfig> selectCreProdConfListByPams(CreditProductConfig creditProductConfig) {
		return creditProductConfigMapper.selectCreProdConfListByPams(creditProductConfig);
	}

	@Override
	public int deleteCredProdConfByProMerId(CreditProductConfig creditProductConfig) throws Exception {
		return creditProductConfigMapper.deleteCredProdConfByProMerId(creditProductConfig);
	}

	@Override
	public int addCreProdConfByProdMerchId(CreditProductConfig credProdConf) throws Exception{
		return creditProductConfigMapper.addCreProdConfByProdMerchId(credProdConf);
	}
}
