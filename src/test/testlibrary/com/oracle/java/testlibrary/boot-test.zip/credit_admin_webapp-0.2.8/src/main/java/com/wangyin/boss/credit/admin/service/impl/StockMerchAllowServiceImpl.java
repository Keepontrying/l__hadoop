package com.wangyin.boss.credit.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jdjr.ras.api.domain.result.RasStatusResult;
import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.response.merchant.GatewayMercCaDubRespHeader;
import com.jd.jr.boss.credit.credit.gateway.merchantca.enums.MercCaRasAuditEnum;
import com.jd.jr.boss.credit.credit.gateway.merchantca.enums.MerchantCaDubRespEnum;
import com.jd.jr.boss.credit.credit.gateway.merchantca.facade.merchant.GatewayMerchantFacade;
import com.jd.jr.boss.credit.facade.site.api.CreditContractFacade;
import com.jd.jr.boss.credit.facade.site.api.CreditPaymentUpdateFacade;
import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractVerifyRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.paymentupdate.PaymentUpdateRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.paymentupdate.PaymentUpdateResponse;
import com.jd.jr.merchant.form.AuthBaseInfoForm;
import com.jd.jr.merchant.form.ResultObject;
import com.wangyin.boss.credit.admin.dao.CreditProductStrategyMapper;
import com.wangyin.boss.credit.admin.entity.StockMerchProStrategyAllow;
import com.wangyin.boss.credit.admin.service.StockMerchAllowService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.Response;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : 存量商户的余量信息补充service实现类
* @author : yangjinlin@jd.com
* @date ：2016年11月21日 下午5:19:36 
* @version 1.0 
* @return  */
@Service
public class StockMerchAllowServiceImpl implements StockMerchAllowService {

	private static Logger LOGGER = LoggerFactory.getLogger(MerchantCaServiceImpl.class);
	
	@Resource
	GatewayMerchantFacade gatewayMerchantFacade;
	
	@Autowired
	private CreditProductStrategyMapper creditProductStrategyMapper;
	
	@Resource
	CreditPaymentUpdateFacade creditPaymentUpdateFacade;

	@Resource
	CreditContractFacade creditContractFacade;
	
	@Override
	public String queryAuthMerchantByNo(StockMerchProStrategyAllow stockMerchProStrategyAllow) throws Exception {
		String resultStr = null;
		RasStatusResult rasStatusResult = gatewayMerchantFacade.queryRasAuthMerchantByNo(stockMerchProStrategyAllow.getMerchantNo());
		LOGGER.info("queryRasAuthMerchantByNo responseData :"+ GsonUtil.getInstance().toJson(rasStatusResult));
		if(rasStatusResult.getCode().equals("RAS00000")){
			if(rasStatusResult.getRealStatus().equals(MercCaRasAuditEnum.MERCHANT_RAS_CODE_BASE_CER_SUCCESS.getCode())){//接口调用成功且已认证
				resultStr = "TRUE";
			}else{//实名中和已过期均视为未实名
				resultStr = "FAIL";
			}
		}else if (rasStatusResult.getCode().equals("RAS20002")){
			resultStr = "FAIL";
		}else{
			LOGGER.error("queryRasStatus error, responseData :"+ GsonUtil.getInstance().toJson(rasStatusResult));
			resultStr = "FAIL";
		}
//		String resultStr = null;
//		Map<String, Object> dubboRouteMap = new HashMap<String, Object>();
//		dubboRouteMap.put("exectype", "AUTH001");
//		dubboRouteMap.put("owner", stockMerchProStrategyAllow.getMerchantNo());
//		ResultObject resultObject = gatewayMerchantFacade.queryAuthMerchantByNo(dubboRouteMap);//调用商户认证接口查询接口
//		LOGGER.info("queryMerchantInfo 调用认证基础信息和证件信息查询接口 的返回结果 :"+ GsonUtil.getInstance().toJson(resultObject));
//		GatewayMercCaDubRespHeader respHeadr = GsonUtil.getInstance().fromJson(
//				GsonUtil.getInstance().toJson(resultObject.getHeadMap()), GatewayMercCaDubRespHeader.class);
//		if(MerchantCaDubRespEnum.MERCHANT_DUBBO_CODE_SUCCESS.toName().equals(respHeadr.getRescode())){
//			LOGGER.info("queryMerchantInfo 调用认证基础信息和证件信息查询接口 成功 :"+ GsonUtil.getInstance().toJson(resultObject));
//			if(!"".equals(resultObject.getDataMap().get("baseinfo")) && null != resultObject.getDataMap().get("baseinfo")){//rescode为 0000000  时body为null，貌似为不合规格式
//				List<AuthBaseInfoForm> bodyBase = (List<AuthBaseInfoForm>) resultObject.getDataMap().get("baseinfo");
//				if(null != bodyBase.get(0)){//bodyBase.get(0).getStatus().getCode()
//					resultStr = "TRUE";
//				}else{
//					resultStr = "FAIL";
//				}
//			}else{//接口返回0000000 成功，但是对于的datamap没有数据,原因可能是该 商户号未实名?
//				resultStr = "FAIL";
//			}
//		}else{
//			resultStr = "FAIL";
//			LOGGER.info("queryMerchantInfo 调用认证基础信息和证件信息查询接口 失败 :"+ GsonUtil.getInstance().toJson(resultObject));
//		}
		return resultStr;
	}


	@Override
	public List<StockMerchProStrategyAllow> selectStockMerchAllowByParam(StockMerchProStrategyAllow stockMerchProStrategyAllow) {
		// TODO Auto-generated method stub
		return creditProductStrategyMapper.selectStockMerchAllowByParam(stockMerchProStrategyAllow);
	}


	@Override
	public int selectStockMerchAllowCountByParam(StockMerchProStrategyAllow stockMerchProStrategyAllow) {
		// TODO Auto-generated method stub
		return creditProductStrategyMapper.selectStockMerchAllowCountByParam(stockMerchProStrategyAllow);
	}


	@Override
	public ResponseData<PaymentUpdateResponse> addStockMerchAllowInfo(PaymentUpdateRequest paymentUpdateRequest) throws Exception {
		// TODO Auto-generated method stub
		RequestParam<PaymentUpdateRequest> requestParam = new RequestParam<PaymentUpdateRequest>();
		requestParam.setParam(paymentUpdateRequest);
		LOGGER.info("addStockMerchAllowInfo()调用运营后台存量商户余量提交接口前的请求参数---before, requestParam:"+GsonUtil.getInstance().toJson(requestParam));
		ResponseData<PaymentUpdateResponse> respData = creditPaymentUpdateFacade.updatePaymentStatus(requestParam);
		LOGGER.info("addStockMerchAllowInfo()调用运营后台存量商户余量提交接口前的请求参数---after, respData:"+GsonUtil.getInstance().toJson(respData));
		return respData;
	}


	@Override
	public Response updateStockMerchContractConfirm(ContractVerifyRequest contractVerifyReq) throws Exception {
		// TODO Auto-generated method stub
		RequestParam<ContractVerifyRequest> requestParam = new RequestParam<ContractVerifyRequest>();
		requestParam.setParam(contractVerifyReq);
		return creditContractFacade.verify(requestParam);
	}

}
