package com.wangyin.boss.credit.admin.controller;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wangyin.boss.credit.admin.entity.CreditBill;
import com.wangyin.boss.credit.admin.entity.CreditBillDetails;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import com.wangyin.boss.credit.admin.enums.ChargeTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditTypeEnum;
import com.wangyin.boss.credit.admin.service.CreditBillDetailsService;
import com.wangyin.boss.credit.admin.service.CreditBillService;
import com.wangyin.boss.credit.admin.service.CreditProductStrategyService;
import com.wangyin.boss.credit.admin.utils.DateUtil;
import com.wangyin.boss.credit.admin.vo.BillStrategyDetail;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/**
 * 商户账单查询controller
 * @since 2016-07-06
 *
 */
@Controller
@RequestMapping("/creditBill")
public class CreditBillController extends BaseController{
	private static final Logger LOGGER = LoggerFactory.getLogger(CreditBillController.class);
	
	@Autowired
	CreditBillService creditBillService;
	
	@Autowired
	CreditBillDetailsService creditBillDetailsService;
	
	@Autowired
	CreditProductStrategyService creditProductStrategyService;
	
	/**
	 * 商户账单查询 分页
	 * @param map
	 * @param creditBill
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryCreditBill.do")
	public Map<String, Object> doQueryCreditBill(@RequestParam Map<String, String> map, CreditBill creditBill) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		List<CreditBill> creditBillList = new ArrayList<CreditBill>();
		int creditBillCount = 0 ;
		
		try {
			creditBill.setCreditType(CreditTypeEnum.PERSON.toName());
			if(("perDay").equalsIgnoreCase(creditBill.getBillCycle())){
				creditBillList = creditBillService.selectByParam(creditBill);
				creditBillCount = creditBillService.selectCountByParam(creditBill);
				for (CreditBill creditBill2 : creditBillList) {
					creditBill2.setBillCycle("每日账单");
					creditBill2.setStartDateStr(new SimpleDateFormat("yyyy-MM-dd").format(creditBill2.getStartDate()));
				}
			}else{
				DateFormat df = new SimpleDateFormat("yyyy-MM");
				DateFormat df1 = new SimpleDateFormat("yyyyMMdd");
//				if(creditBill != null && StringUtils.isNotBlank(creditBill.getStartDateStr())){
//					creditBill.setStartDateStr(creditBill.getStartDateStr().substring(0, 7));
//				}
				creditBillCount = creditBillService.selectMonthBillCountByParam(creditBill);
				if(creditBillCount != 0){
					creditBillList = creditBillService.selectMonthBillByParam(creditBill);
					for (CreditBill creditBill2 : creditBillList) {
						if(creditBill2.getStartDateStr().equalsIgnoreCase(df.format(new Date()))){
							creditBill2.setBillNo(creditBill2.getMerchantNo() + "-02-" + creditBill2.getStartDateStr().replace("-", "") + 
									"01-" + df1.format(DateUtil.getBeforeDay(new Date())) + "-" + creditBill2.getProductId());
						}else{
							int year = Integer.valueOf(creditBill2.getStartDateStr().substring(0, 4));
							int month = Integer.valueOf(creditBill2.getStartDateStr().substring(5, 7));
							int maxDay = DateUtil.getDaysByYearMonth(year, month);
							creditBill2.setBillNo(creditBill2.getMerchantNo() + "-02-" + creditBill2.getStartDateStr().replace("-", "") + 
									"01-" + creditBill2.getStartDateStr().replace("-", "") + maxDay + "-" + creditBill2.getProductId());
						}
						creditBill2.setStartDateStr(creditBill2.getMonthDate()+"-01");
						creditBill2.setBillCycle("每月账单");
					}
				}
			}
			
		} catch (Exception e) {
			LOGGER.error(e);
		}
		resultMap.put("rows", creditBillList);
		resultMap.put("total", creditBillCount);
		
		return resultMap;
	}
	
	/**
	 * 查询商户账单详情
	 * @author yangjinlin5
	 * @param map
	 * @param creditBill
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryCreditBillDetail.do")
	public Map<String, Object> doQueryCreditBillDetail(@RequestParam Map<String, String> map, CreditBill creditBill) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("creditBill", creditBill);
		
		CreditBillDetails creditBillDetails = new CreditBillDetails();
		
		List<CreditBillDetails> creditBillDetailsList = new ArrayList<CreditBillDetails>(); //结果容器
		CreditBillDetails packageDetail = new CreditBillDetails();
		CreditBillDetails singleDetail = new CreditBillDetails();
		List<BillStrategyDetail> packageBillStrategyDetailList = new ArrayList<BillStrategyDetail>(); //包量容器
		List<BillStrategyDetail> singleBillStrategyDetailList = new ArrayList<BillStrategyDetail>(); //单笔容器
		
		List<CreditBillDetails> list = null;
		
		if("每日账单".equalsIgnoreCase(creditBill.getBillCycle())){
			
			creditBillDetails.setBillId(creditBill.getBillId());
			list = creditBillDetailsService.selectPerDayBillDetails(creditBillDetails);
		}else if("每月账单".equalsIgnoreCase(creditBill.getBillCycle())){
			creditBillDetails.setMonthDate(creditBill.getMonthDate());
			creditBillDetails.setMerchantId(creditBill.getMerchantId());
			creditBillDetails.setProductId(creditBill.getProductId());
			list = creditBillDetailsService.selectPerMonthBillDetails(creditBillDetails);
		}
		
		/*消耗包量的总次数*/
		Long expendPackageCount = 0L;
		/*消耗单笔的总金额*/
		Long expendSingleCount = 0L;
		for (CreditBillDetails creditBillDetails2 : list) {
			StringBuffer strategyDetail = new StringBuffer();
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			CreditProductStrategy creditProductStrategy = creditProductStrategyService.selectByStrategyId(creditBillDetails2.getStrategyId());
			
			BillStrategyDetail packageBillStrategyDetail = new BillStrategyDetail();
			
			if(ChargeTypeEnum.PACKAGE.toName().equalsIgnoreCase(creditBillDetails2.getChargeType())){//包量
				packageBillStrategyDetail.setExpendCount(creditBillDetails2.getExpendCount());
				packageBillStrategyDetail.setExpendCountStr(creditBillDetails2.getExpendCount().toString());
				
				if(creditProductStrategy != null){
					strategyDetail.append("包量次数：").append(creditProductStrategy.getPacketCount()).append("次 预收费用：")
					.append(new BigDecimal(creditProductStrategy.getAmount()).divide(new BigDecimal("100")).toString()).append("元 有效期限：");
					strategyDetail.append(df.format(creditProductStrategy.getStartTime())).append("到").append(df.format(creditProductStrategy.getFinishTime()));
				}
				
				expendPackageCount += creditBillDetails2.getExpendCount();
				packageBillStrategyDetail.setStrategyDetail(strategyDetail.toString());
				packageBillStrategyDetailList.add(packageBillStrategyDetail);
			}else{
				packageBillStrategyDetail.setExpendCount(new BigDecimal(creditBillDetails2.getExpendCount()).divide(new BigDecimal("100")).longValue());
				packageBillStrategyDetail.setExpendCountStr(new BigDecimal(creditBillDetails2.getExpendCount()).divide(new BigDecimal("100")).toString());
				if(creditProductStrategy != null){
					strategyDetail.append("单笔费用：").append(new BigDecimal(creditProductStrategy.getPrice()).divide(new BigDecimal("100")).toString()).append("元/次  有效期限：");
					strategyDetail.append(df.format(creditProductStrategy.getStartTime())).append("到").append(df.format(creditProductStrategy.getFinishTime()));
				}
				
				expendSingleCount += creditBillDetails2.getExpendCount();
				packageBillStrategyDetail.setStrategyDetail(strategyDetail.toString());
				singleBillStrategyDetailList.add(packageBillStrategyDetail);
			}
			
		}
		packageDetail.setExpendCount(expendPackageCount);
		packageDetail.setExpendCountStr(expendPackageCount.toString());
		packageDetail.setChargeType("包量");
		packageDetail.setStrategyDetails(packageBillStrategyDetailList);
		creditBillDetailsList.add(packageDetail);
		
		singleDetail.setExpendCount(expendSingleCount/100);
		singleDetail.setExpendCountStr(new BigDecimal(expendSingleCount).divide(new BigDecimal("100")).toString());
		singleDetail.setChargeType("单笔");
		singleDetail.setStrategyDetails(singleBillStrategyDetailList);
		creditBillDetailsList.add(singleDetail);
		
		resultMap.put("creditBillDetailsList", creditBillDetailsList);
		
		return resultMap;
	}
	
}
