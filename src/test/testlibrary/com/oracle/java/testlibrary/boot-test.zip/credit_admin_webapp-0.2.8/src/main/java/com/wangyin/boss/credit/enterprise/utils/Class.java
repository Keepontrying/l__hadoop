package com.wangyin.boss.credit.enterprise.utils;

import java.util.List;

public class Class {
	private String name;
	private String manager;
	private String levl;
	private List<Student> students;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getManager() {
		return manager;
	}
	public void setManager(String manager) {
		this.manager = manager;
	}
	public String getLevl() {
		return levl;
	}
	public void setLevl(String levl) {
		this.levl = levl;
	}
	public List<Student> getStudents() {
		return students;
	}
	public void setStudents(List<Student> students) {
		this.students = students;
	}
	
}
