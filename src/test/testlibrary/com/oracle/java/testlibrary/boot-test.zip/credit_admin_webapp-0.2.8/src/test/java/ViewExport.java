import com.wangyin.operation.util.viewUtil.ViewExportUtil;
import com.wangyin.operation.util.viewUtil.enums.EnvironmentEnum;

/**
 * 视图控制
 *
 * @author: dongzhihua
 * @time: 2018/10/25 14:42:13
 */
public class ViewExport {
    public static void main(String[] args) {
        String basePath = "E://SVNPage/credit/base";
        ViewExportUtil.export(basePath, "credit", EnvironmentEnum.local);
    }
}
