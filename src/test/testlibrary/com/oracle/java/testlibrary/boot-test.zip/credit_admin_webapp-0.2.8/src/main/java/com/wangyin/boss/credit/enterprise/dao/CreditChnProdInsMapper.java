package com.wangyin.boss.credit.enterprise.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditChnProdIns;
import com.wangyin.boss.credit.enterprise.beans.CreditChannelProdInsQueryParam;
import com.wangyin.boss.credit.enterprise.beans.MerchantChannel;
@SqlMapper
@Component
public interface CreditChnProdInsMapper {
    int deleteByPrimaryKey(Integer insId);
    int insert(CreditChnProdIns record);
    int insertSelective(CreditChnProdIns record);
    CreditChnProdIns selectByPrimaryKey(Integer insId);

    int updateByPrimaryKeySelective(CreditChnProdIns record);

    int updateByPrimaryKey(CreditChnProdIns record);

    /**
     *  查询 渠道产品实例  总数
     * @param queryParam
     * @return
     */
    int queryChannelProdInsListCount(CreditChannelProdInsQueryParam queryParam);

    /**
     * 查询 渠道产品实例  List
     * @param queryParam
     * @return
     */
    List<CreditChnProdIns> queryChannelProdInsList(CreditChannelProdInsQueryParam queryParam);
    
    /**
     * 商户渠道分页查询
     * @param queryParam
     * @return
     */
    List<MerchantChannel> queryMerchantChannel(CreditChannelProdInsQueryParam queryParam);
    
    /**
     * 商户渠道查询 总条数
     * @param queryParam
     * @return
     */
    int queryMerchantChannelCount(CreditChannelProdInsQueryParam queryParam);
    
    List<String> queryInsName(List<String> insCodeList);

    /**
     * 根据insCodeList查询实例
     * @param list
     * @return
     */
    List<CreditChnProdIns> queryChannelProdIns(List<String> list);

    /**
     * 查询需要更新的权重记录
     * @param productCode
     * @param w2
     * @return
     */
    List<CreditChnProdIns> queryChannelProdInsBy(@Param(value = "productCode") String productCode, @Param(value = "weight") int weight);

    /**
     * 批量更新权重
     * @param datas
     * @return
     */
    int updateWeightBatch(List<CreditChnProdIns> list);
}