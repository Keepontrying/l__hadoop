package com.wangyin.boss.credit.admin.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.gateway.account.beans.entity.finance.FundFlowQueryEntity;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountQueryRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountRechargeRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayFundFlowQueryRequest;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccounTradeResponse;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccountQueryResponse;
import com.jd.jr.boss.credit.gateway.account.facade.finance.GatewayAccountFacade;
import com.jd.jr.boss.credit.gateway.account.facade.payment.GatewayPaymentOrderFacade;
import com.wangyin.boss.credit.admin.service.CreditMerchantBalanceAllowanceService;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.RequestParam;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : 商户余额余量service接口实现类
* @author : yangjinlin@jd.com
* @date ：2017年11月25日 下午8:20:24 
* @version 1.0 
* @return  */
@Service
public class CreditMerchantBalanceAllowanceServiceImpl implements CreditMerchantBalanceAllowanceService {

	@Autowired
	private GatewayAccountFacade accountFacade;
	
	@Override
	public ResponseData<GatewayAccountQueryResponse> queryAccountInfo(GatewayAccountQueryRequest accountQueryRequest) {
		RequestParam<GatewayAccountQueryRequest> requestParam = new RequestParam<GatewayAccountQueryRequest>();
		requestParam.setParam(accountQueryRequest);
		ResponseData<GatewayAccountQueryResponse> accountQueryresponse = accountFacade.queryAccountInfo(requestParam);
		return accountQueryresponse;
	}

	@Override
	public ResponseData<GatewayAccounTradeResponse> accountRecharge(GatewayAccountRechargeRequest req) {
		RequestParam<GatewayAccountRechargeRequest> repParam = new RequestParam<GatewayAccountRechargeRequest>();
		repParam.setParam(req);
		return accountFacade.accountRecharge(repParam);
	}

	@Override
	public Page<FundFlowQueryEntity> queryFlowsByDate(GatewayFundFlowQueryRequest fundFlowQueryRequest) {
		RequestParam<GatewayFundFlowQueryRequest> flowQueryRequest = new RequestParam<GatewayFundFlowQueryRequest>();
		flowQueryRequest.setParam(fundFlowQueryRequest);
		return accountFacade.queryFlowsByDate(flowQueryRequest);
	}

}
