package com.wangyin.boss.credit.admin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wangyin.boss.credit.admin.dao.CreditContractDetailsMapper;
import com.wangyin.boss.credit.admin.entity.CreditContractDetails;
import com.wangyin.boss.credit.admin.service.CreditContractDetailsService;

@Service
public class CreditContractDetailsServiceImpl implements CreditContractDetailsService {
	
	@Autowired
	CreditContractDetailsMapper creditContractDetailsMapper;

	@Override
	public List<CreditContractDetails> selectByParam(CreditContractDetails creditContractDetails) {
		return creditContractDetailsMapper.selectByParam(creditContractDetails);
	}

	@Override
	public int selectCountByParam(CreditContractDetails creditContractDetails) {
		return creditContractDetailsMapper.selectCountByParam(creditContractDetails);
	}

	@Override
	public List<CreditContractDetails> selectByContractId(Integer contractId) {
		return creditContractDetailsMapper.selectByContractId(contractId);
	}

}
