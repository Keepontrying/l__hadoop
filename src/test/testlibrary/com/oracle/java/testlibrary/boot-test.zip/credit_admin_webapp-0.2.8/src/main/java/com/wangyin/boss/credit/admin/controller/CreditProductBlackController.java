package com.wangyin.boss.credit.admin.controller;

import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditProductBlack;
import com.wangyin.boss.credit.admin.entity.CreditProductBlackHistory;
import com.wangyin.boss.credit.admin.enums.CreditMerchantTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditProcutBlackStatusEnum;
import com.wangyin.boss.credit.admin.service.CreditMerchantService;
import com.wangyin.boss.credit.admin.service.CreditProductBlackHistoryService;
import com.wangyin.boss.credit.admin.service.CreditProductBlackService;

import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
* @desciption : 产品黑名单配置管理controller
* @author : liuwei55@jd.com
* @date ：2017年4月10日 下午17:00:00
* @version 1.0
* @return  */

@Controller
@RequestMapping("/creditProductBlack")
public class CreditProductBlackController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CreditProductBlackController.class);
	
	@Autowired
	CreditProductBlackService creditProductBlackService;
	@Autowired
	CreditProductBlackHistoryService creditProductBlackHistoryService;
	@Autowired
	CreditMerchantService creditMerchantService;

	/**
	 *@desc 产品黑名单管理列表查询
	 *@param
	 *@Author liuwei55@jd.com
	 *@Date 2017/4/10 17:23
	 */
	@ResponseBody
	@RequestMapping("doQueryProductBlack.do")
	public Map<String, Object> doQueryProductBlack(@RequestParam Map<String, String> map, CreditProductBlack creditProductBlack) {
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		
		try {

			List<CreditProductBlack> creProdConfList = creditProductBlackService.selectCreProdBlackByPams(creditProductBlack);
			int credProdBlackCount = creditProductBlackService.selectCountByParam(creditProductBlack);
			resultMap.put("rows", creProdConfList);
			resultMap.put("total", credProdBlackCount);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditProductBlack>());
			resultMap.put("total", 0);
		}
		
		return resultMap;
	}

	/**
	 * 开通、关停 产品黑名单配置
	 * @author liuwe55@jd.com
	 * @param
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doOperateProductBlack.do")
	public Map<String, Object> doOperateProductStrategy(@RequestParam Map<String, Object> map,
														CreditProductBlack creditProductBlack, String user) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");

		String operaUserName = null;
		try {
			operaUserName = getLoginRealName(user);
		} catch (Exception e) {
			LOGGER.error(e);
			operaUserName = "error";
		}
		creditProductBlack.setModifier(operaUserName);
		String remark = map.containsKey("remarks") ? String.valueOf(map.get("remarks")) : "未获取到相应备注信息!";

		String[] blackIds = String.valueOf(map.get("blackIds")).split("\\|");
		if(blackIds.length == 0){
			resultMap.put("success", false);
			resultMap.put("message", "操作有误，请重新操作!");
		}else{

			for (String blackgId : blackIds) {
				creditProductBlack.setBlackId(Integer.valueOf(blackgId));
				creditProductBlack.setRemarks(remark);
				try {

					creditProductBlackService.updateCredProdBlackById(creditProductBlack);

				} catch (Exception e) {
					LOGGER.error(e);
					resultMap.put("success", false);
					resultMap.put("message", "操作异常");
				}
			}
		}
		return resultMap;
	}

	/**
	 * 根据id查看产品黑名单配置详情
	 * @author liuwei55@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toQueryProductBlackDetail.view")
	public Map<String, Object> toQueryProductBlackDetail(@RequestParam Map<String, Object> map) {

		Map<String, Object> resultMap = new HashMap<String, Object>();
		Integer blackId = Integer.valueOf(String.valueOf(map.get("blackId")));
		CreditProductBlack cpb = creditProductBlackService.selectCredProdBlackById(blackId);
		resultMap.put("creditProductBlack", cpb);

		return resultMap;
	}
	/**
	 * 查看产品黑名单配置的历史操作记录
	 * @author liuwei55@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toQueryProductBlackHistList")
	public Map<String, Object> toQueryProductBlackHistList(@RequestParam Map<String, Object> map) {

		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			Integer blackId = Integer.valueOf(String.valueOf(map.get("blackId")));
			List<CreditProductBlackHistory> list=creditProductBlackHistoryService.selectCreProdBlHisByBlackId(map);
			int credProdBlackCount = creditProductBlackHistoryService.selectCountHisByBlackId(map);
			resultMap.put("rows", list);
			resultMap.put("total", credProdBlackCount);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditProductBlack>());
			resultMap.put("total", 0);
		}
		return resultMap;
	}
	/**
	 * 添加产品黑名单配置
	 * @author liuwe55@jd.com
	 * @param
	 * @return
	 */
	@ResponseBody
	@RequestMapping("insertProductBlack.do")
	public Map<String, Object> insertProductBlack(@RequestParam Map<String, Object> map,
														CreditProductBlack creditProductBlack, String user) {
		String operaUserName = null;
		try {
			operaUserName = getLoginRealName(user);
		} catch (Exception e) {
			LOGGER.error(e);
			operaUserName = "error";
		}
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");
		Map<String, Integer> param = new HashMap<String, Integer>();
		param.put("productId",creditProductBlack.getProductId());
		param.put("merchantId",creditProductBlack.getMerchantId());
		CreditProductBlack black=creditProductBlackService.selectCredProdBlackByProMerId(param);
		if(black!=null){//说明产品id对应的merchantNo已经有黑名单
			resultMap.put("success", false);
			resultMap.put("message", "此商户对应的产品已经在黑名单中，不能重复添加");
			return resultMap;
		}
		try {
			creditProductBlack.setBlackStatus(CreditProcutBlackStatusEnum.OPEN.getCode());
			creditProductBlack.setCreator(operaUserName);
			creditProductBlack.setModifier(operaUserName);
			creditProductBlackService.insertCredProdBlack(creditProductBlack);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "操作异常");
		}
		return resultMap;
	}
	/**
	 * 校验商户号是否存在--黑名单用，只限本地数据库校验
	 * @author liuwei55
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doValidMerchantNo.do")

	public Map<String, Object> doValidMerchantNo(@RequestParam Map<String, Object> map, String merchantNo) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "验证成功");
		Map<String, String> mapParams = new HashMap<String, String>();
		mapParams.put("merchantNo",merchantNo);
		mapParams.put("merchantType", CreditMerchantTypeEnum.ENTERPRISE.toName());
		CreditMerchant merchant=creditMerchantService.selectByMerNoType(mapParams);
		if(merchant!=null){
			resultMap.put("merchantName",merchant.getMerchantName());
			resultMap.put("merchantId",merchant.getMerchantId());
		}else{
			resultMap.put("success", false);
			resultMap.put("message", "此商户不存在");
		}
		return resultMap;
	}

}
