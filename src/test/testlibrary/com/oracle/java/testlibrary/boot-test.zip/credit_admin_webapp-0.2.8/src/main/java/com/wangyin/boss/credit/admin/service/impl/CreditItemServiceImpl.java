package com.wangyin.boss.credit.admin.service.impl;

import com.wangyin.boss.credit.admin.dao.CreditItemHistoryMapper;
import com.wangyin.boss.credit.admin.dao.CreditItemMapper;
import com.wangyin.boss.credit.admin.dao.CreditItemSkuHistoryMapper;
import com.wangyin.boss.credit.admin.dao.CreditItemSkuMapper;
import com.wangyin.boss.credit.admin.entity.CreditItem;
import com.wangyin.boss.credit.admin.entity.CreditItemHistory;
import com.wangyin.boss.credit.admin.entity.CreditItemSku;
import com.wangyin.boss.credit.admin.entity.CreditItemSkuHistory;
import com.wangyin.boss.credit.admin.enums.CreditItemSkuEnum;
import com.wangyin.boss.credit.admin.service.CreditItemService;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 *
 * 门户标准产品管理
 * @author jiangbo
 * @since 2017/3/17
 */
@Service
public class CreditItemServiceImpl implements CreditItemService {

    private static Logger logger = LoggerFactory.getLogger(CreditItemServiceImpl.class);


    @Autowired
    CreditItemMapper creditItemMapper;
    @Autowired
    CreditItemHistoryMapper creditItemHistoryMapper;
    @Autowired
    CreditItemSkuHistoryMapper creditItemSkuHistoryMapper;

    @Autowired
    CreditItemSkuMapper creditItemSkuMapper;

    @Override
    public List<CreditItem> selectItemAndSkuByParam(CreditItem creditItem) {
        return creditItemMapper.selectItemAndSkuByParam(creditItem);
    }

    @Override
    public int selectItemAndSkuCountByParam(CreditItem creditItem) {
        return creditItemMapper.selectItemAndSkuCountByParam(creditItem);
    }

    public int updateByPrimaryKeySelective(CreditItem creditItem){
        creditItem.setModifiedDate(new Date());
        return creditItemMapper.updateByPrimaryKeySelective(creditItem);
    }

    @Override
    public int insertSelective(CreditItem creditItem) {
        creditItem.setModifiedDate(new Date());
        return creditItemMapper.insertSelective(creditItem);
    }

    /**
     * 保存item和sku的历史，并插入修改新的item和sku,整个在一个事务里执行
     * @param creditItem
     * @return
     */
    @Transactional
    @Override
    public boolean transactionSaveItemAndSkuAndHistory(CreditItem creditItem) throws Exception{
        int itemId = creditItem.getItemId();
        CreditItem oldCreditItem = new CreditItem();
        oldCreditItem.setItemId(itemId);

        //查出原始的item和sku
        List<CreditItem> creditItemList = creditItemMapper.selectItemAndSkuByParam(oldCreditItem);
        if (creditItemList == null || creditItemList.size() == 0) {
            logger.error("transactionSaveItemAndSkuAndHistory error,selectItemAndSkuByParam creditItemList is null,itemId:{}", itemId);
            return false;
        }
        CreditItem creditItemResult = creditItemList.get(0);
        CreditItemHistory creditItemHistory = new CreditItemHistory();

        //开始插入item的历史
        BeanUtils.copyProperties(creditItemHistory, creditItemResult);
        int resultItemInsertHis = creditItemHistoryMapper.insertSelective(creditItemHistory);
        if (resultItemInsertHis > 0) {
            logger.info("transactionSaveItemAndSkuAndHistory, save creditItemHistory success,creditItemHistory:{}", ReflectionToStringBuilder.toString(creditItemHistory));
        } else {
            logger.error("transactionSaveItemAndSkuAndHistory, save creditItemHistory error,creditItemHistory:{}", ReflectionToStringBuilder.toString(creditItemHistory));
            //抛异常回滚
            throw new Exception();
        }

        //开始插入sku的历史，并删除原始的sku
        if (creditItemResult.getCreditItemSkuList() != null && creditItemResult.getCreditItemSkuList().size() > 0) {
            for (CreditItemSku creditItemSku : creditItemResult.getCreditItemSkuList()) {

                CreditItemSkuHistory creditItemSkuHistory = new CreditItemSkuHistory();
                BeanUtils.copyProperties(creditItemSkuHistory,creditItemSku);
                creditItemSkuHistory.setItemHistoryId(creditItemHistory.getHistoryId());
                int resultSkuHis = creditItemSkuHistoryMapper.insertSelective(creditItemSkuHistory);
                if (resultSkuHis > 0) {
                    logger.info("transactionSaveItemAndSkuAndHistory, save creditItemSkuHistory success,creditItemSkuHistory:{}", ReflectionToStringBuilder.toString(creditItemSkuHistory));
                } else {
                    logger.error("transactionSaveItemAndSkuAndHistory, save creditItemSkuHistory error,creditItemSkuHistory:{}", ReflectionToStringBuilder.toString(creditItemSkuHistory));
                    //抛异常回滚
                    throw new Exception();
                }

                int resultSkuDel = creditItemSkuMapper.deleteByPrimaryKey(creditItemSku.getSkuId());

                if (resultSkuDel > 0) {
                    logger.info("transactionSaveItemAndSkuAndHistory, delete creditItemSku success,skuId:{}", creditItemSku.getSkuId());
                } else {
                    logger.error("transactionSaveItemAndSkuAndHistory, delete creditItemSku error,skuId:{}", creditItemSku.getSkuId());
                    //抛异常回滚
                    throw new Exception();
                }
            }
        } else {
            logger.info("transactionSaveItemAndSkuAndHistory, save creditItemSkuHistory, creditItemSku is null");
        }


        //更新item
        int itemIdNew = this.updateByPrimaryKeySelective(creditItem);
        if (itemIdNew <= 0) {
            logger.warn("updateByPrimaryKeySelective item error,result:{},creditItem:{}", itemIdNew, ReflectionToStringBuilder.toString(creditItem));
            //抛异常回滚
            throw new Exception();
        }

        //插入sku数据
        for (CreditItemSku creditItemSku : creditItem.getCreditItemSkuList()){
                //校验数据creditItemSku
                if (StringUtils.isBlank(creditItemSku.getChargeType())){
                    continue;
                }
                creditItemSku.setSkuId(null);
                creditItemSku.setItemId(creditItem.getItemId());
                creditItemSku.setCreator(creditItem.getModifier());
                creditItemSku.setCreatedDate(new Date());
                creditItemSku.setModifier(creditItem.getModifier());
                creditItemSku.setSkuStatus(CreditItemSkuEnum.SHELVE.getCode());
                creditItemSku.setModifiedDate(new Date());

                int resultSkuInsert = creditItemSkuMapper.insertSelective(creditItemSku);
                if (resultSkuInsert <= 0) {
                    logger.info("insertSelective or updateByPrimaryKeySelective sku error,resultSkuInsert:{},creditItemSku:{}", resultSkuInsert, ReflectionToStringBuilder.toString(creditItemSku));
                    //抛异常回滚
                    throw new Exception();
                }
            }

        return true;
    }

    @Override
    public List<CreditItemHistory> selectItemHisAndSkuByParam(CreditItemHistory creditItemHistory) {
        return creditItemHistoryMapper.selectItemHisAndSkuByParam(creditItemHistory);
    }

    @Override
    public int selectItemHisAndSkuCountByParam(CreditItemHistory creditItemHistory) {
        return creditItemHistoryMapper.selectItemHisAndSkuCountByParam(creditItemHistory);
    }
}
