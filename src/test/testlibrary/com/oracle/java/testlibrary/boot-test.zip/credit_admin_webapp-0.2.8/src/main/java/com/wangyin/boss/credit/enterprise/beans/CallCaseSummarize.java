package com.wangyin.boss.credit.enterprise.beans;

/**
 * 
 * <ul>
 * <li>1、开发日期：2018年1月12日</li>
 * <li>2、开发时间：下午12:21:36</li>
 * <li>3、作 者：zhanghui12</li>
 * <li>4、类型名称：CallCaseSummarize</li>
 * <li>5、类型意图：产品调用情况汇总对象</li>
 * </ul>
 *
 */
public class CallCaseSummarize {
	/*
	 * 金融机构本月新增
	 */
	private int financeMonth;
	/*
	 * 非金融机构本月新增
	 */
	private int nonFinanceMonth;
	/*
	 * 司法行政部门本月新增
	 */
	private int departmentMonth;
	/*
	 * 其他本月新增
	 */
	private int otherMonth;
	/*
	 * 合计本月新增
	 */
	private int totalMonth;

	/*
	 * 金融机构本年新增
	 */
	private int financeYear;
	/*
	 * 非金融机构本年新增
	 */
	private int nonFinanceYear;
	/*
	 * 司法行政机构本年新增
	 */
	private int departmentYear;
	/*
	 * 其他本年新增
	 */
	private int otherYear;
	/*
	 * 合计本年新增
	 */
	private int totalYear;

	/*
	 * 金融机构总累计
	 */
	private int financeHis;
	/*
	 * 非金融机构总累计
	 */
	private int nonFinanceHis;
	/*
	 * 司法行政部门总累计
	 */
	private int departmentHis;
	/*
	 * 其他总累计
	 */
	private int otherHis;
	/*
	 * 合计总累计
	 */
	private int totalHis;

	public int getFinanceMonth() {
		return financeMonth;
	}

	public void setFinanceMonth(int financeMonth) {
		this.financeMonth = financeMonth;
	}

	public int getNonFinanceMonth() {
		return nonFinanceMonth;
	}

	public void setNonFinanceMonth(int nonFinanceMonth) {
		this.nonFinanceMonth = nonFinanceMonth;
	}

	public int getDepartmentMonth() {
		return departmentMonth;
	}

	public void setDepartmentMonth(int departmentMonth) {
		this.departmentMonth = departmentMonth;
	}

	public int getOtherMonth() {
		return otherMonth;
	}

	public void setOtherMonth(int otherMonth) {
		this.otherMonth = otherMonth;
	}

	public int getTotalMonth() {
		return totalMonth;
	}

	public void setTotalMonth(int totalMonth) {
		this.totalMonth = totalMonth;
	}

	public int getFinanceYear() {
		return financeYear;
	}

	public void setFinanceYear(int financeYear) {
		this.financeYear = financeYear;
	}

	public int getNonFinanceYear() {
		return nonFinanceYear;
	}

	public void setNonFinanceYear(int nonFinanceYear) {
		this.nonFinanceYear = nonFinanceYear;
	}

	public int getDepartmentYear() {
		return departmentYear;
	}

	public void setDepartmentYear(int departmentYear) {
		this.departmentYear = departmentYear;
	}

	public int getOtherYear() {
		return otherYear;
	}

	public void setOtherYear(int otherYear) {
		this.otherYear = otherYear;
	}

	public int getTotalYear() {
		return totalYear;
	}

	public void setTotalYear(int totalYear) {
		this.totalYear = totalYear;
	}

	public int getFinanceHis() {
		return financeHis;
	}

	public void setFinanceHis(int financeHis) {
		this.financeHis = financeHis;
	}

	public int getNonFinanceHis() {
		return nonFinanceHis;
	}

	public void setNonFinanceHis(int nonFinanceHis) {
		this.nonFinanceHis = nonFinanceHis;
	}

	public int getDepartmentHis() {
		return departmentHis;
	}

	public void setDepartmentHis(int departmentHis) {
		this.departmentHis = departmentHis;
	}

	public int getOtherHis() {
		return otherHis;
	}

	public void setOtherHis(int otherHis) {
		this.otherHis = otherHis;
	}

	public int getTotalHis() {
		return totalHis;
	}

	public void setTotalHis(int totalHis) {
		this.totalHis = totalHis;
	}

	@Override
	public String toString() {
		return "CallCaseSummarize [financeMonth=" + financeMonth + ", nonFinanceMonth=" + nonFinanceMonth
				+ ", departmentMonth=" + departmentMonth + ", otherMonth=" + otherMonth + ", totalMonth=" + totalMonth
				+ ", financeYear=" + financeYear + ", nonFinanceYear=" + nonFinanceYear + ", departmentYear="
				+ departmentYear + ", otherYear=" + otherYear + ", totalYear=" + totalYear + ", financeHis="
				+ financeHis + ", nonFinanceHis=" + nonFinanceHis + ", departmentHis=" + departmentHis + ", otherHis="
				+ otherHis + ", totalHis=" + totalHis + "]";
	}


}
