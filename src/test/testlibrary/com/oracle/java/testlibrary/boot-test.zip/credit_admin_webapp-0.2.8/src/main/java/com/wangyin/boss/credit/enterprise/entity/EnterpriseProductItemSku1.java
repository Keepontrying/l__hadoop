package com.wangyin.boss.credit.enterprise.entity;
/** 
* @desciption : 企业征信产品及其包量信息model类
* @author : yangjinlin@jd.com
* @date ：2017年3月20日 下午9:04:41 
* @version 1.0 
* @return  */
public class EnterpriseProductItemSku1 {

	/**
	 * 产品id
	 */
	private Integer productId;
	/**
	 * 产品名称
	 */
	private String productName;
	/**
	 * 计费类型:PACKAGE-包量; SINGLE-单笔; CUSTOM-定制包; LADDER-阶梯价
	 */
	private String chargeType;
	/**
	 * 免费次数
	 */
	private Integer freeTimes;
	/**
	 * 定制包, 按次付费价格
	 */
	private Integer customPrice;
	/**
	 * chargeType=PACKAGE时，该字段为包量价格<p/>
	 * chargeType=SINGLE时，该字段为单笔价格<p/>
	 */
	private Long amount;
	/**
	 * 包量次数, 其他计费类型下默认为0
	 */
	private Integer packetCount;
	private Integer singlePrice;
	/**
	 * 计费策略id
	 */
	private Integer strategyId;

	private Integer upperLimit;//固定周期使用上限值
	private String purchaseType;//付费方式
	
	/*  前端展示和传特殊参用  */
	private String customPriceStr;
	private String amountStr;
	private String orderStatus;
	private String vipMonitorFlag;
	private String singlePriceStr;
	private String completionPriceType;//mini尽调时效
	private String productCode;//产品编码
	private String unitDesc;//产品计费单位描述
	
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getChargeType() {
		return chargeType;
	}
	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}
	public Integer getFreeTimes() {
		return freeTimes;
	}
	public void setFreeTimes(Integer freeTimes) {
		this.freeTimes = freeTimes;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public Integer getPacketCount() {
		return packetCount;
	}
	public void setPacketCount(Integer packetCount) {
		this.packetCount = packetCount;
	}
	public Integer getCustomPrice() {
		return customPrice;
	}
	public void setCustomPrice(Integer customPrice) {
		this.customPrice = customPrice;
	}
	public Integer getStrategyId() {
		return strategyId;
	}
	public void setStrategyId(Integer strategyId) {
		this.strategyId = strategyId;
	}
	public String getCustomPriceStr() {
		return customPriceStr;
	}
	public void setCustomPriceStr(String customPriceStr) {
		this.customPriceStr = customPriceStr;
	}
	public String getAmountStr() {
		return amountStr;
	}
	public void setAmountStr(String amountStr) {
		this.amountStr = amountStr;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getVipMonitorFlag() {
		return vipMonitorFlag;
	}

	public void setVipMonitorFlag(String vipMonitorFlag) {
		this.vipMonitorFlag = vipMonitorFlag;
	}

	public Integer getUpperLimit() {
		return upperLimit;
	}
	public void setUpperLimit(Integer upperLimit) {
		this.upperLimit = upperLimit;
	}
	public Integer getSinglePrice() {
		return singlePrice;
	}
	public void setSinglePrice(Integer singlePrice) {
		this.singlePrice = singlePrice;
	}
	public String getSinglePriceStr() {
		return singlePriceStr;
	}
	public void setSinglePriceStr(String singlePriceStr) {
		this.singlePriceStr = singlePriceStr;
	}
	public String getPurchaseType() {
		return purchaseType;
	}
	public void setPurchaseType(String purchaseType) {
		this.purchaseType = purchaseType;
	}
	public String getCompletionPriceType() {
		return completionPriceType;
	}
	public void setCompletionPriceType(String completionPriceType) {
		this.completionPriceType = completionPriceType;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getUnitDesc() {
		return unitDesc;
	}
	public void setUnitDesc(String unitDesc) {
		this.unitDesc = unitDesc;
	}
	
	
}
