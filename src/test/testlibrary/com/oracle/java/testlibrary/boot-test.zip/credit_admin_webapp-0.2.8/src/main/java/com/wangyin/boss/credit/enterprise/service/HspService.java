package com.wangyin.boss.credit.enterprise.service;
/** 
* @desciption : 
* @author : yangjinlin@jd.com
* @date ：2017年10月24日 下午4:18:30 
* @version 1.0 
* @return  */
public interface HspService {

	/**
	 * 根据fid生成在HSP上的URL
	 * @param hspFid fid
	 * @param filename 文件名  如 test.esxl
	 * @return
	 */
	public String createHspUrlByFid(String hspFid, String filename);

}
