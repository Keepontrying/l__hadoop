package com.wangyin.boss.credit.enterprise.service;

import com.jd.jr.boss.credit.facade.authen.beans.response.creditReport.StandardReportBatchResponse;
import com.jd.jr.boss.credit.facade.authen.beans.response.creditReport.StandardReportResponse;
import com.wangyin.boss.credit.enterprise.beans.ReportQueryParam;

/**
 * Created by zhanghui12 on 2018/6/7.
 * 标准报告服务
 */
public interface StandardReportService {
    /**
     * 分页查询
     * @param param
     * @return
     */
    StandardReportBatchResponse queryPage(ReportQueryParam param);

    StandardReportResponse queryReportPage(ReportQueryParam param);

    boolean reCreateReport(String orderId);

    boolean reCreateOrder(String id);

    boolean updateAuthFile(String authFileName, String fid, String batchNo);
}
