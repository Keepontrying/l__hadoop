package com.wangyin.boss.credit.enterprise.controller;

import com.wangyin.boss.credit.enterprise.beans.CreditChannelQueryParam;
import com.wangyin.boss.credit.enterprise.entity.CreditChnChannel;
import com.wangyin.boss.credit.enterprise.service.CreditChannelService;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.beans.UserModel;
import com.wangyin.operation.common.beans.PageResult;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/credit/creditChannel")
public class CreditChannelController {

    private static final Logger logger = LoggerFactory.getLogger(CreditChannelController.class);

    @Autowired
    CreditChannelService creditChannelService;


    /**
     * 查询所有数据产品
     * @param creditChannelQueryParam
     * @return
     */
    @RequestMapping("/pageList.do")
    @ResponseBody
    public PageResult<CreditChnChannel> pageList(CreditChannelQueryParam creditChannelQueryParam) {
        PageResult<CreditChnChannel> pageResult = new PageResult<>();
        try {
            pageResult = creditChannelService.queryChannelList(creditChannelQueryParam);
            return pageResult;
        } catch (Exception e) {
            logger.error(e.getMessage());
            pageResult.setSuccess(false);
            pageResult.setMessage(ResponseMessage.SYSTEM_ERROR.getDesc());
        }

        return pageResult;
    }

    /**
     * 查询所有数据产品
     * @param creditChannelQueryParam
     * @return
     */
    @RequestMapping("/saveOrUpdate.do")
    @ResponseBody
    public Map<String,Object> saveOrUpdate(CreditChannelQueryParam creditChannelQueryParam,
                @RequestParam(value = "user",required = false) UserModel userModel) {
        Map<String, Object> result = new HashMap<>();
        try {
            if (StringUtil.isEmpty(creditChannelQueryParam.getCreator()) && userModel !=null) {
                creditChannelQueryParam.setCreator(userModel.getUserName());
            }
            result = creditChannelService.saveOrUpdate(creditChannelQueryParam);
            return result;
        } catch (Exception e) {
            logger.error(e.getMessage());
            result.put("success",false);
            result.put("message",ResponseMessage.SYSTEM_ERROR.getDesc());
        }

        return result;
    }

    /**
     * 根据channelId
     * @param creditChannelQueryParam
     * @return
     */
    @RequestMapping("/queryByChannelId.do")
    @ResponseBody
    public Map<String,Object> queryByChannelId(CreditChannelQueryParam creditChannelQueryParam) {
        Map<String, Object> result = new HashMap<>();
        try {
            if (StringUtils.isEmpty(creditChannelQueryParam.getChannelId())) {
                return null;
            }
            result = creditChannelService.queryChannelInfoById(creditChannelQueryParam);
            return result;
        } catch (Exception e) {
            logger.error(e.getMessage());
            result.put("success",false);
            result.put("message",ResponseMessage.SYSTEM_ERROR.getDesc());
        }

        return result;
    }
}
