package com.wangyin.boss.credit.admin.publicSentiment;

import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResults;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResultsQueryParam;
import com.wangyin.boss.credit.enterprise.beans.CrawlerWord;
import com.wangyin.boss.credit.enterprise.dao.CrawlerJobResultsMapper;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author huangzhiqiang
 * @data 2018/11/28
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class CrawlerJobResultsMapperTest {

    @Autowired
    CrawlerJobResultsMapper mapper;

    @Test
    public void addResult() {
        Long jobId = 1L;
        String jobNo = "LS001";
        String jobName = "啷里格啷的结果";
        byte jobCategory = 0;
        int jobWeight = 100;
        String url = "www.baidu.com";
        String urlCode = "baidu";
        String articleTitle = "啷里格啷的结果";
        String articleUrl = "www.baidu.com";
        int totalHit = 100;

        CrawlerJobResults res = new CrawlerJobResults();
        res.setJobId(jobId);
        res.setJobNo(jobNo);
        res.setName(jobName);
        res.setCategory(jobCategory);
        res.setWeight(jobWeight);
        res.setTargetUrl(url);
        res.setTargetUrlCode(urlCode);
        res.setArticleTitle(articleTitle);
        res.setArticleUrl(articleUrl);
        res.setTotalHit(totalHit);
        mapper.insert(res);

        Long jobResId = res.getId();

        CrawlerWord word1 = new CrawlerWord();
        word1.setJobResId(jobResId);
        word1.setWord("普剖普");
        word1.setHit(40);
        word1.setScore(100);
        word1.setType((byte)0);
        word1.setGroupId(1L);


        CrawlerWord word2 = new CrawlerWord();
        word2.setJobResId(jobResId);
        word2.setWord("哈哈哈");
        word2.setHit(20);
        word2.setScore(80);
        word2.setType((byte)0);
        word2.setGroupId(1L);

        mapper.insertWord(word1);
        mapper.insertWord(word2);
    }

    @Test
    public void queryJob(){
        CrawlerJobResultsQueryParam param = new CrawlerJobResultsQueryParam();
        param.setWord("哈");
        System.out.println(GsonUtil.getInstance().toJson(mapper.query(param)));
    }
}
