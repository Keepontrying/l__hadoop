package com.wangyin.boss.credit.admin.service;

import java.io.InputStream;
import java.util.Map;

import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountConsumeRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountCreateRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountQueryRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountRechargeRequest;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccounTradeResponse;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccountCreateResponse;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccountQueryResponse;
import com.wangyin.operation.common.beans.ResponseData;

/**
 * 执行备用sql操作 service接口类
 * @author yangjinlin
 *
 */
public interface CreditResService {
	
	/**
	 * 执行备用sql操作
	 * @param paramSql
	 * @return 
	 */
	boolean updateResOperaBySql(String paramSql);

	/**
	 * 根据用户ID创建账户
	 * @param userId
	 * @return
	 */
	ResponseData<GatewayAccountCreateResponse> createAccount4Res(GatewayAccountCreateRequest userIdReqParam);

	/**
	 * 根据账户号查询账户信息
	 * @param accountQryReq
	 * @return
	 */
	ResponseData<GatewayAccountQueryResponse> queryAccountInfo4Res(GatewayAccountQueryRequest accountQryReq);

	/**
	 * 根据账户号进行充值操作
	 * @param req
	 * @return
	 */
	ResponseData<GatewayAccounTradeResponse> accountRecharge(GatewayAccountRechargeRequest req);

	/**
	 * 根据账户进行消费
	 * @param req
	 * @return
	 */
	ResponseData<GatewayAccounTradeResponse> accountConsume(GatewayAccountConsumeRequest req);

	/**
	 * 按照前缀清除r2m缓存
	 * @param prefixStr
	 */
	public void expireKeysR2m(String prefixStr,int ttl);

	/**
	 * 解析Mini尽调excel
	 * @param is
	 * @param isExcel2003
	 * @return
	 */
	Map<String, Object> insertMiniAreasExcel(InputStream is, Boolean isExcel2003);
}
