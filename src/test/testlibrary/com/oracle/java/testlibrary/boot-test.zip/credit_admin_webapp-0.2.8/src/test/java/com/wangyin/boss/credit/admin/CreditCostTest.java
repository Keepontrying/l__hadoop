package com.wangyin.boss.credit.admin;

import java.text.ParseException;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wangyin.boss.credit.admin.dao.CreditCostMapper;
import com.wangyin.boss.credit.admin.entity.CreditCost;
import com.wangyin.boss.credit.admin.service.CreditCostService;

/**
 * 接口成本 测试类
 * 
 * @author wyhaozhihong
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:applicationContext.xml" })
public class CreditCostTest {

	@Autowired
	CreditCostMapper creditCostMapper;
	
	@Autowired
	CreditCostService creditCostService;
	
	@Test
	public void insert(){
		CreditCost record = new CreditCost();
		record.setProductId(4);
		record.setProductName("学籍认证");
		record.setCreator("haozhihong");
		record.setStartDate(new Date());
		record.setFinishDate(new Date());
		record.setPrice(1000L);
		record.setRemarks("hzhtest");
		record.setCostStatus("open");
		creditCostMapper.insert(record);
	}
	
	@Test
	public void insertService() throws ParseException{
		CreditCost record = new CreditCost();
		record.setProductId(4);
		record.setProductName("学籍认证");
		record.setCreator("haozhihong");
		record.setStartDate(new Date());
		record.setFinishDate(new Date());
		record.setStartDateStr("2016-07-24");
		record.setPrice(1000L);
		record.setRemarks("hzhtest");
		record.setCostStatus("open");
		creditCostService.insert(record);
	}
}
