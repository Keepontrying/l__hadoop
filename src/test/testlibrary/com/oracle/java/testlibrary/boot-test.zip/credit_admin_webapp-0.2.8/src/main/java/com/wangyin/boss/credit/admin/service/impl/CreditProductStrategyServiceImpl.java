package com.wangyin.boss.credit.admin.service.impl;

import com.wangyin.boss.credit.admin.dao.CreditProductStrategyMapper;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategyAllow;
import com.wangyin.boss.credit.admin.service.CreditProductStrategyService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by wyhaozhihong on 2016/6/29.
 */

@Service
public class CreditProductStrategyServiceImpl implements CreditProductStrategyService{

    @Autowired
    private CreditProductStrategyMapper creditProductStrategyMapper;

    @Override
    public int insert(CreditProductStrategy record) {
        return creditProductStrategyMapper.insert(record);
    }

	@Override
	public List<CreditProductStrategy> selectByParam(CreditProductStrategy creditProductStrategy) {
		return creditProductStrategyMapper.selectByParam(creditProductStrategy);
	}

	@Override
	public int selectCountByParam(CreditProductStrategy creditProductStrategy) {
		return creditProductStrategyMapper.selectCountByParam(creditProductStrategy);
	}

	@Override
	public int updateByPrimaryKey(CreditProductStrategy creditProductStrategy) {
		return creditProductStrategyMapper.updateByPrimaryKeySelective(creditProductStrategy);
	}

	@Override
	public int deleteByStrategyId(Integer strategyId) {
		return creditProductStrategyMapper.deleteByPrimaryKey(strategyId);
	}

	@Override
	public CreditProductStrategy selectByStrategyId(Integer strategyId) {
		return creditProductStrategyMapper.selectByPrimaryKey(strategyId);
	}

	@Override
	public int updateByStrategyId(CreditProductStrategy creditProductStrategy) {
		return creditProductStrategyMapper.updateByStrategyId(creditProductStrategy);
	}

	@Override
	public List<CreditProductStrategy> selectBatchByPrimaryKey(List<String> strategyIds) {
		return creditProductStrategyMapper.selectBatchByPrimaryKey(strategyIds);
	}

	@Override
	public List<CreditProductStrategyAllow> selectMerchantStrategyByParam(CreditProductStrategyAllow creditProductStrategy) {
		return creditProductStrategyMapper.selectMerchantStrategyByParam(creditProductStrategy);
	}

	@Override
	public int selectMerchantStrategyCountByParam(CreditProductStrategy creditProductStrategy) {
		return creditProductStrategyMapper.selectMerchantStrategyCountByParam(creditProductStrategy);
	}

	@Override
	public List<CreditProductStrategyAllow> selectMercAllowanceByParam(CreditProductStrategyAllow creditProductStrategy) {
		// TODO Auto-generated method stub
		return creditProductStrategyMapper.selectMercAllowanceByParam(creditProductStrategy);
	}

	@Override
	public int selectMercAllowanceCountByParam(CreditProductStrategy creditProductStrategy) {
		// TODO Auto-generated method stub
		return creditProductStrategyMapper.selectMercAllowanceCountByParam(creditProductStrategy);
	}

	@Override
	public List<CreditProductStrategy> selectByMerchantNo(CreditProductStrategy cps) {
		// TODO Auto-generated method stub
		return creditProductStrategyMapper.selectByMerchantNo(cps);
	}

	@Override
	public int updateStatusForClose(CreditProductStrategy creditProductStrategy) {
		// TODO Auto-generated method stub
		return creditProductStrategyMapper.updateStatusForClose(creditProductStrategy);
	}

	@Override
	public List<CreditProductStrategy> selectStrategyListByParam(CreditProductStrategy productStrategy) {
		// TODO Auto-generated method stub
		return creditProductStrategyMapper.selectStrategyListByParam(productStrategy);
	}

	@Override
	public List<CreditProductStrategy> selectStrategyListByProMerId(CreditProductStrategy productStrategy) {
		return creditProductStrategyMapper.selectStrategyListByProMerId(productStrategy);
	}

	@Override
	public List<CreditProductStrategy> selectDisStrategyListByParam(CreditProductStrategy productStrategy) {
		return creditProductStrategyMapper.selectDisStrategyListByParam(productStrategy);
	}
}
