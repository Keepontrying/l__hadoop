package com.wangyin.boss.credit.enterprise.scheduler;

import com.wangyin.boss.credit.enterprise.beans.CrawlerJob;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResultsQueryParam;
import com.wangyin.boss.credit.enterprise.service.CrawlerJobFlowService;
import com.wangyin.boss.credit.enterprise.service.CrawlerJobService;
import com.wangyin.schedule.client.job.ScheduleContext;
import com.wangyin.schedule.client.job.ScheduleFlowTask;
import com.wangyin.schedule.client.job.TaskResult;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * 定向舆情监控定时任务
 *
 * @author huangzhiqiang
 * @data 2018/11/27
 */
@Service
public class PublicSentimentJob implements ScheduleFlowTask {
    private Logger logger = LoggerFactory.getLogger(PublicSentimentJob.class);

    @Resource
    private CrawlerJobService jobService;
    @Resource
    private CrawlerJobFlowService flowService;

    @Override
    public TaskResult doTask(ScheduleContext scheduleContext) throws Exception {
        logger.info("定向舆情任务开始");
        Map<String, String> parameters = scheduleContext.getParameters();
        CrawlerJobResultsQueryParam param = new CrawlerJobResultsQueryParam();

        Byte jobCategory = Byte.valueOf(parameters.get("jobCategory"));
        if (jobCategory == 0) {
            param.setTime1(DateTime.now().minusHours(1).toDate());
            param.setTime2(DateTime.now().toDate());
        }
        param.setCategory(jobCategory);
        List<CrawlerJob> jobList = jobService.queryList(param);
        if (jobList != null && jobList.size() > 0) {
            for (CrawlerJob job : jobList) {
                flowService.addJobFlow(job);
            }
        }
        return TaskResult.SUCCESS_BLANK;
    }

}
