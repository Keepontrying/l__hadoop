package com.wangyin.boss.credit.admin.service.impl;

import com.jd.jr.boss.credit.facade.authen.api.CreditMerchantFacade;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.dao.CreditMerchantMapper;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditVip;
import com.wangyin.boss.credit.admin.enums.CreditVipStatusEnum;
import com.wangyin.boss.credit.admin.service.CreditMerchantService;
import com.wangyin.boss.credit.admin.service.MerchantCaService;
import com.wangyin.operation.common.beans.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CreditMerchantServiceImpl implements CreditMerchantService {
	
	@Autowired
	CreditMerchantMapper creditMerchantMapper;

	@Autowired
	CreditMerchantFacade creditMerchantFacade;
    @Autowired
    private MerchantCaService merchantCaService;

	@Override
	public CreditMerchant selectByMerchantNo(String merchantNo) {
		return creditMerchantMapper.selectByMerchantNo(merchantNo);
	}

	@Override
	public CreditMerchant selectByMerNoType(Map<String, String> map) {
		return creditMerchantMapper.selectByMerNoType(map);
	}

	@Override
	public CreditMerchant selectByMerchantId(Integer merchantId) {
		return creditMerchantMapper.selectByPrimaryKey(merchantId);
	}

	@Override
	public List<CreditMerchant> selectMerchListByNo(String merchantNo) {
		return creditMerchantMapper.selectMerchListByNo(merchantNo);
	}

	@Override
	public List<CreditMerchant> queryMerchantListByParam(CreditMerchant creditMerchant) {
		// TODO Auto-generated method stub
		return creditMerchantMapper.queryMerchantListByParam(creditMerchant);
	}

	/**
	 * 校验是否是vip商户
	 *
	 * @param merchantId
	 * @return
	 */
	@Override
	public Boolean isVipMonitorMerchant(Integer merchantId) {
		CreditRequestParam<Integer> requestParam=new CreditRequestParam<Integer>();
		requestParam.setParam(merchantId);
		CreditResponseData<CreditVip> responseData= creditMerchantFacade.queryMerchantVip(requestParam);
		if(responseData.isSuccess()){
			CreditVip vipDO=responseData.getData();
			if(vipDO!=null&&CreditVipStatusEnum.VIP_OPEN.getCode().equals(vipDO.getVipStatus())){
				return true;
			}else{
				return false;
			}
		}
		throw new RuntimeException("查询商户vip监控状态失败:"+responseData.getMessage());
	}

    @Override
    public Page<CreditMerchant> queryCreditMerchantPage(CreditMerchant creditMerchant) {
        int count = creditMerchantMapper.countMerchantByParam(creditMerchant);
        Page<CreditMerchant> creditMerchantPage = new Page<CreditMerchant>();
        creditMerchantPage.setTotal(count);
        if (count > 0) {
            List<CreditMerchant> creditMerchantList = creditMerchantMapper.pageMerchantByParam(creditMerchant);
            creditMerchantPage.setRows(creditMerchantList);
//            for (CreditMerchant merchant : creditMerchantList) {

//                GatewayMerchantQueryResponse gmqResp = merchantCaService.queryMerchantInfoByHttp(merchant.getMerchantNo());
//                merchant.setMerchantCaStatus(gmqResp.getMerchantCaStatus());
//            }
        }
        return creditMerchantPage;
    }
}