package com.wangyin.boss.credit.admin.controller;

import static java.math.BigDecimal.ROUND_HALF_UP;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.response.merchant.GatewayMerchantQueryResponse;
import com.jd.jr.boss.credit.domain.common.entity.CreditOrder;
import com.jd.jr.boss.credit.facade.authen.beans.param.SubOrderQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.gateway.account.beans.entity.finance.FundFlowQueryEntity;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountQueryRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountRechargeRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayFundFlowQueryRequest;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccounTradeResponse;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccountQueryResponse;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.enums.ChargeTypeEnum;
import com.wangyin.boss.credit.admin.service.CreditMerchantBalanceAllowanceService;
import com.wangyin.boss.credit.admin.service.CreditMerchantService;
import com.wangyin.boss.credit.admin.service.CreditOrderService;
import com.wangyin.boss.credit.admin.service.MerchantCaService;
import com.wangyin.boss.credit.admin.utils.DateUtil;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;

/**
 * 商户余额查询controller,主要用于查询企业钱包余额
 * @author jiangbo
 * @since 2016-07-05
 *
 */
@Controller
@RequestMapping("/merchantBalance")
public class MerchantBalanceController extends BaseController{
	private static final Logger LOGGER = LoggerFactory.getLogger(MerchantBalanceController.class);

	@Autowired
	private MerchantCaService merchantCaService;
	
	@Autowired
	private CreditOrderService orderService;
	
	@Autowired
	private CreditMerchantBalanceAllowanceService balanAllowService;

	@Autowired
    private CreditMerchantService creditMerchantService;

	/**
	 * 查询商户余额，企业钱包余额
	 * @author jiangbo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryMerchantBalance.do")
	public Page<CreditMerchant> doQueryMerchantBalance(CreditMerchant merchant) {
        Page<CreditMerchant> creditMerchantPage;
		try {
            creditMerchantPage = creditMerchantService.queryCreditMerchantPage(merchant);
            if (creditMerchantPage.getTotal() == 0) {
                return creditMerchantPage;
            }
			for(CreditMerchant cm : creditMerchantPage.getRows()){
				if(StringUtils.isEmpty(cm.getMerchantNo())){
					continue;
				}
				GatewayMerchantQueryResponse gmqResp = merchantCaService.queryMerchantInfoByHttp(cm);
				cm.setUserName(gmqResp.getUserName());
				
				SubOrderQueryParam subOrderQueryParam = new SubOrderQueryParam();
				subOrderQueryParam.setMerchantNo(cm.getMerchantNo());
				subOrderQueryParam.setChargeType(merchant.getChargeType());
				subOrderQueryParam.setStart(0);
				subOrderQueryParam.setLimit(1000);
				CreditPage<CreditOrder> creditPageOrder = orderService.querySubOrder(subOrderQueryParam);
				if(null != creditPageOrder && creditPageOrder.isSuccess() && null != creditPageOrder.getRows()
						&& creditPageOrder.getRows().size()>0 && creditPageOrder.getRows().get(0).getValidTime() != null ){
					//依据服务查询余额
					GatewayAccountQueryRequest accountQueryRequest = new GatewayAccountQueryRequest();
					accountQueryRequest.setAccountNo(creditPageOrder.getRows().get(0).getAccountNo());
					ResponseData<GatewayAccountQueryResponse> accountQueryresponse = balanAllowService.queryAccountInfo(accountQueryRequest);
					if(null != accountQueryresponse && accountQueryresponse.isSuccess() && null != accountQueryresponse.getData() ){
						cm.setMerchantAccountBalance( BigDecimal.valueOf(accountQueryresponse.getData().getBalance()).divide(BigDecimal.valueOf(100), 2, ROUND_HALF_UP));
						cm.setMerchantAccountNo(creditPageOrder.getRows().get(0).getAccountNo());
					}else{
						cm.setMerchantAccountBalance(null);
					}
				}else{
					cm.setMerchantAccountBalance(null);
				}
				
			}
		} catch (Exception e) {
			LOGGER.error("doQueryMerchantBalance error",e);
            creditMerchantPage = new Page<CreditMerchant>();
            creditMerchantPage.setSuccess(false);
            creditMerchantPage.setMessage(e.getMessage());
		}
        return creditMerchantPage;
    }
	
	/**
	 * 跳转至账户充值页面
	 */
	@ResponseBody
	@RequestMapping("toCharge4Merchant.view")
	public Map<String, String> toCharge4Merchant(@RequestParam Map<String, String> map) {
		if(!map.containsKey("merchantNo") || !map.containsKey("merchantAccountNo")){
			return map;
		}
		String merchantNo = map.get("merchantNo").toString();
		String merchantAccountNo = map.get("merchantAccountNo").toString();
		
		
		//依据服务查询余额
		GatewayFundFlowQueryRequest fundFlowQueryRequest = new GatewayFundFlowQueryRequest();
		fundFlowQueryRequest.setAccountNo(merchantAccountNo);
		Date startDate = null;
		try {
			startDate = DateUtil.parseUtilDate("2016-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss");
		} catch (Exception e) {
			LOGGER.info("toCharge4Merchant DateUtil.parseUtilDate parse fail");
		}
		fundFlowQueryRequest.setStartDate(startDate);
		fundFlowQueryRequest.setEndDate(new Date());
		fundFlowQueryRequest.setPageNo(1);
		fundFlowQueryRequest.setPageSize(100);
		Page<FundFlowQueryEntity> fundFlowQueryresponse = balanAllowService.queryFlowsByDate(fundFlowQueryRequest);
		if(null != fundFlowQueryresponse && fundFlowQueryresponse.isSuccess() ){
			if(CollectionUtils.isEmpty(fundFlowQueryresponse.getRows())){
				SubOrderQueryParam requestParam = new SubOrderQueryParam();
				requestParam.setMerchantNo(merchantNo);
				requestParam.setChargeType(ChargeTypeEnum.SINGLE.toName());
				requestParam.setAccountNo(merchantAccountNo);
				List<CreditContract> contractList = orderService.queryContractByOrderInfo(requestParam);
				if(CollectionUtils.isNotEmpty(contractList)){
					map.put("balance4Recharge", BigDecimal.valueOf(contractList.get(0).getAdvancePayment()).divide(BigDecimal.valueOf(100), 2, ROUND_HALF_UP).toString());
				}
			}
		}
//		SubOrderQueryParam subOrderQueryParam = new SubOrderQueryParam();
//		subOrderQueryParam.setMerchantNo(merchantNo);
//		subOrderQueryParam.setChargeType(ChargeTypeEnum.SINGLE.toName());
//		subOrderQueryParam.setStart(0);
//		subOrderQueryParam.setLimit(1000);
//		CreditPage<CreditOrder> creditPageOrder = orderService.querySubOrder(subOrderQueryParam);
//		if(null != creditPageOrder && creditPageOrder.isSuccess() && null != creditPageOrder.getRows()
//				&& creditPageOrder.getRows().size()>0 && StringUtils.isNotBlank(creditPageOrder.getRows().get(0).getAccountNo()) ){
//			if(ChargeTypeEnum.SINGLE.toName().equalsIgnoreCase(creditPageOrder.getRows().get(0).getStrategyChargeType().toName()) 
//					&& creditPageOrder.getRows().get(0).getValidTime() != null ){
//				SubOrderQueryParam requestParam = new SubOrderQueryParam();
//				requestParam.setOrderId(creditPageOrder.getRows().get(0).getOrderId());
//				requestParam.setChargeType(ChargeTypeEnum.SINGLE.toName());
//				List<CreditContract> contractList = orderService.queryContractByOrderInfo(requestParam);
//				if(CollectionUtils.isNotEmpty(contractList)){
//					map.put("balance4Recharge", BigDecimal.valueOf(contractList.get(0).getAdvancePayment()).divide(BigDecimal.valueOf(100), 2, ROUND_HALF_UP).toString());
//				}
//			}
//		}
		
		return map;
	}
	
	/**
	 * 账户充值
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/docharge4MerchantAccount.do")
	public Map<String,Object> docharge4MerchantAccount(@RequestParam Map<String, String> map, String merchantAccountNo, 
			String merchantNo, String balance4Recharge, String user){
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "操作异常，请稍后重试");
		if(StringUtils.isEmpty(merchantAccountNo)){//判定账户号
			LOGGER.info("docharge4MerchantAccount fail, reason : merchantAccountNo is null");
			return resultMap;
		}
		if(StringUtils.isEmpty(merchantNo)){//判定操作密钥
			LOGGER.info("docharge4MerchantAccount fail, reason : merchantNo is null");
			resultMap.put("success", false);
			resultMap.put("message", "执行失败，账户号不可为空!");
			return resultMap;
		}
		if(StringUtils.isEmpty(balance4Recharge)){
			LOGGER.info("docharge4MerchantAccount fail, reason : balance4Recharge is null");
			resultMap.put("success", false);
			resultMap.put("message", "执行失败，充值金额不可为空!");
			return resultMap;
		}
//		if(!RegexValidateUtil.checkDigit(balance4Recharge)){
//			resultMap.put("success", false);
//			resultMap.put("message", "执行失败，充值金额格式有误!");
//			return resultMap;
//		}
		String operator = "error";
		try {
			operator = getLoginRealName(user);
		} catch (Exception e) {
			LOGGER.error("getLoginRealName failed," + e);
		}
		
		try {
			GatewayAccountRechargeRequest req = new GatewayAccountRechargeRequest();
			req.setAccountNo(merchantAccountNo);
			req.setTradeAmt(new BigDecimal(balance4Recharge).multiply(new BigDecimal("100")).longValue());
			req.setTradeDesc("manual operation");
			ResponseData<GatewayAccounTradeResponse> respData = balanAllowService.accountRecharge(req);
			LOGGER.info("docharge4MerchantAccount, balanAllowService.accountRecharge response:"+GsonUtil.getInstance().toJson(respData));
			resultMap.put("respData", GsonUtil.getInstance().toJson(respData));
			if(respData.isSuccess()){
				resultMap.put("success", true);
				resultMap.put("message", "操作成功!");
			}else{//创建账户失败
				resultMap.put("success", false);
				resultMap.put("message", respData.getMessage());
			}
		} catch (Exception e) {
			LOGGER.error("docharge4MerchantAccount failed, reason: "+ e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常，请稍后重试");
		}
		
		return resultMap;
	}
}
