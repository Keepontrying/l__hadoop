package com.wangyin.boss.credit.admin.controller;

import com.wangyin.boss.credit.admin.entity.CreditItem;
import com.wangyin.boss.credit.admin.entity.CreditItemHistory;
import com.wangyin.boss.credit.admin.entity.CreditItemSku;
import com.wangyin.boss.credit.admin.enums.ChargeTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditItemEnum;
import com.wangyin.boss.credit.admin.enums.CreditItemSkuEnum;
import com.wangyin.boss.credit.admin.enums.CreditProductChargeStatusEnum;
import com.wangyin.boss.credit.admin.enums.CreditProductSortEnum;
import com.wangyin.boss.credit.admin.service.CreditItemService;
import com.wangyin.boss.credit.admin.service.CreditItemSkuService;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;

/**
 * item商品相关
 * @author jiangbo
 * @since 20170317
 */
@Controller
@RequestMapping("/creditItem")
public class CreditItemController extends BaseController {

	private static Logger logger = LoggerFactory.getLogger(CreditItemController.class);

	@Autowired
	private CreditItemService creditItemService;

	@Autowired
	private CreditItemSkuService creditItemSkuService;

	@ResponseBody
	@RequestMapping(value={"doQueryCreditItem.do","toEditCreditItem.view"})
	public Map<String, Object> doQueryCreditItem(@RequestParam Map<String, Object> map, CreditItem creditItem){
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");

		CreditItem CItem = new CreditItem();
		if (creditItem.getItemId() != null){
			CItem.setItemId(creditItem.getItemId());
		}

		if (StringUtils.isNotBlank(creditItem.getLimit())){
			CItem.setLimit(creditItem.getLimit());
		}

		if (StringUtils.isNotBlank(creditItem.getStart())){
			CItem.setStart(creditItem.getStart());
		}

//		CItem.setItemStatus(CreditItemEnum.SHELVE.getCode());
		try {
			List<CreditItem> creditItemList = creditItemService.selectItemAndSkuByParam(CItem);
			for(CreditItem item : creditItemList){
				item.setChargeStatus(CreditProductChargeStatusEnum.enumValueOf(item.getChargeStatus()).toDescription());
				item.setProductSort(CreditProductSortEnum.enumValueOf(item.getProductSort()).toDescription());
			}
			int creditItemCount = creditItemService.selectItemAndSkuCountByParam(CItem);
			resultMap.put("rows", creditItemList);
			resultMap.put("total", creditItemCount);
		}catch (Exception e){
			logger.error("doQueryCreditItem error,creditItem:{}", ReflectionToStringBuilder.toString(creditItem), e);
			resultMap.put("rows", new ArrayList<CreditItem>());
			resultMap.put("total", 0);
			resultMap.put("success", false);
			resultMap.put("message", "异常，请稍后重试");
		}

		return resultMap;
	}

	/**
	 * 更新item的状态
	 * @param map
	 * @param creditItem
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doUpdateCreditItemStatus.do")
	public Map<String, Object> doUpdateCreditItemStatus(@RequestParam Map<String, Object> map, CreditItem creditItem){
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");

		CreditItem CItem = new CreditItem();

		if (StringUtils.isBlank(creditItem.getItemStatus())){
			resultMap.put("success", false);
			resultMap.put("message", "操作异常");
			return resultMap;
		}

		if (creditItem.getItemId() == null){
			resultMap.put("success", false);
			resultMap.put("message", "id不能为空");
			return resultMap;
		}

		CItem.setItemId(creditItem.getItemId());
		CItem.setItemStatus(creditItem.getItemStatus());

		try {
			int result = creditItemService.updateByPrimaryKeySelective(CItem);
			if (result > 0) {
				logger.info("updateByPrimaryKeySelective success,CItem:{}", ReflectionToStringBuilder.toString(creditItem));
				return resultMap;
			}else {
				resultMap.put("success", false);
				resultMap.put("message", "操作失败");
				return resultMap;
			}
		}catch (Exception e){
			logger.error("doUpdateCreditItemStatus error,creditItem:{}", ReflectionToStringBuilder.toString(creditItem), e);
			resultMap.put("success", false);
			resultMap.put("message", "异常，请稍后重试");
			return resultMap;
		}
	}

	/**
	 * 创建item和sku
	 * @param map
	 * @param user
	 * @param creditItem
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doCreateCreditItemWithSku.do")
	public Map<String, Object> doCreateCreditItemWithSku(@RequestParam Map<String, Object> map, String user, CreditItem creditItem){
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "操作失败");

		if (creditItem == null){
			resultMap.put("message", "提交数据为空");
			return resultMap;
		}

		if (creditItem.getCreditItemSkuList() == null || creditItem.getCreditItemSkuList().size() == 0){
			resultMap.put("message", "提交sku数据为空");
			return resultMap;
		}

		if (creditItem.getProductId() == null){
			resultMap.put("message", "产品id不能为空");
			return resultMap;
		}

		if (creditItem.getFreeTimes() == null || creditItem.getFreeTimes() < 0){
			resultMap.put("message", "免费次数不正确");
			return resultMap;
		}

		//校验数据
		if (creditItem.getCreditItemSkuList() != null && creditItem.getCreditItemSkuList().size() > 0) {
			for (CreditItemSku creditItemSku : creditItem.getCreditItemSkuList()) {
				//校验数据creditItemSku
				if (StringUtils.isBlank(creditItemSku.getChargeType())){
					continue;
				}else{
					if (creditItemSku.getChargeType().equals(ChargeTypeEnum.CUSTOM.toName())){
						if (creditItemSku.getCustomPrice() == null){
							resultMap.put("message", "定制包的单次价格不能为空");
							return resultMap;
						}

						if (creditItemSku.getPeriodValidity() == null){
							resultMap.put("message", "定制包的有效期不能为空");
							return resultMap;
						}
					}

					if (creditItemSku.getChargeType().equals(ChargeTypeEnum.PACKAGE.toName())){
						if (creditItemSku.getAmount() == null){
							resultMap.put("message", "包量的价格不能为空");
							return resultMap;
						}

						if (creditItemSku.getPacketCount() == null){
							resultMap.put("message", "包量的次数不能为空");
							return resultMap;
						}

						if (creditItemSku.getPeriodValidity() == null){
							resultMap.put("message", "定制包的有效期不能为空");
							return resultMap;
						}
					}

				}
			}
		}else {
			resultMap.put("message", "sku不能为空");
			return resultMap;
		}

		String operaUserName = "";
		try {
			operaUserName = getLoginRealName(user);
		} catch (Exception e1) {
			logger.error("getLoginRealName error",e1);
			resultMap.put("message", "操作用户异常");
			return resultMap;
		}

		creditItem.setItemStatus(CreditItemEnum.SHELVE.getCode());
		creditItem.setCreator(operaUserName);
		creditItem.setCreatedDate(new Date());
		creditItem.setModifier(operaUserName);


		try {

			//先插入item
			int itemId = creditItemService.insertSelective(creditItem);
			if (itemId <= 0) {
				logger.warn("insertSelective item error,result:{},creditItem:{}", itemId, ReflectionToStringBuilder.toString(creditItem));
				resultMap.put("success", false);
				resultMap.put("message", "批量插入，请检查后重试！");
				return resultMap;
			}else {
				logger.info("insertSelective item success,result:{},creditItem:{}", itemId, ReflectionToStringBuilder.toString(creditItem));
			}

			if (creditItem.getCreditItemSkuList() != null && creditItem.getCreditItemSkuList().size() > 0) {
				for (CreditItemSku creditItemSku : creditItem.getCreditItemSkuList()) {
					//校验数据creditItemSku
					if (StringUtils.isBlank(creditItemSku.getChargeType())){
						continue;
					}
					creditItemSku.setItemId(creditItem.getItemId());
					creditItemSku.setCreator(operaUserName);
					creditItemSku.setCreatedDate(new Date());
					creditItemSku.setModifier(operaUserName);
					creditItemSku.setSkuStatus(CreditItemSkuEnum.SHELVE.getCode());

					int result = creditItemSkuService.insertSelective(creditItemSku);
					if (result <= 0) {
						logger.warn("insertSelective sku error,result:{},creditItemSku:{}", result, ReflectionToStringBuilder.toString(creditItemSku));
						resultMap.put("success", false);
						resultMap.put("message", "批量插入包信息，部分失败，请检查后重试！");
						return resultMap;
					}else {
						logger.info("insertSelective sku success,result:{},creditItemSku:{}", result, ReflectionToStringBuilder.toString(creditItemSku));
					}
				}
			}

			resultMap.put("success", true);
			resultMap.put("message", "操作成功");
		} catch (Exception e) {
			logger.error("doCreateCreditItemWithSku error,creditItem:{}", ReflectionToStringBuilder.toString(creditItem), e);
			resultMap.put("success", false);
			resultMap.put("message", "异常，请稍后重试");
			return resultMap;
		}
		return resultMap;
	}


	/**
	 * 更新item和sku
	 * @param map
	 * @param user
	 * @param creditItem
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doUpdateCreditItemWithSku.do")
	public Map<String, Object> doUpdateCreditItemWithSku(@RequestParam Map<String, Object> map, String user, CreditItem creditItem){
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "操作失败");

		if (creditItem == null || creditItem.getItemId() == null){
			resultMap.put("message", "提交数据为空");
			return resultMap;
		}

		if (creditItem.getCreditItemSkuList() == null || creditItem.getCreditItemSkuList().size() == 0){
			resultMap.put("message", "提交sku数据为空");
			return resultMap;
		}

		if (creditItem.getProductId() == null){
			resultMap.put("message", "产品id不能为空");
			return resultMap;
		}

		if (creditItem.getFreeTimes() == null || creditItem.getFreeTimes() < 0){
			resultMap.put("message", "免费次数不正确");
			return resultMap;
		}

		//校验数据
		if (creditItem.getCreditItemSkuList() != null && creditItem.getCreditItemSkuList().size() > 0) {
			for (CreditItemSku creditItemSku : creditItem.getCreditItemSkuList()) {
				//校验数据creditItemSku
				if (StringUtils.isBlank(creditItemSku.getChargeType())){
					continue;
				}else{
					if (creditItemSku.getChargeType().equals(ChargeTypeEnum.CUSTOM.toName())){
						if (creditItemSku.getCustomPrice() == null){
							resultMap.put("message", "定制包的单次价格不能为空");
							return resultMap;
						}

						if (creditItemSku.getPeriodValidity() == null){
							resultMap.put("message", "定制包的有效期不能为空");
							return resultMap;
						}
					}

					if (creditItemSku.getChargeType().equals(ChargeTypeEnum.PACKAGE.toName())){
						if (creditItemSku.getAmount() == null){
							resultMap.put("message", "包量的价格不能为空");
							return resultMap;
						}

						if (creditItemSku.getPacketCount() == null){
							resultMap.put("message", "包量的次数不能为空");
							return resultMap;
						}

						if (creditItemSku.getPeriodValidity() == null){
							resultMap.put("message", "定制包的有效期不能为空");
							return resultMap;
						}
					}

				}
			}
		}else {
			resultMap.put("message", "sku不能为空");
			return resultMap;
		}

		String operaUserName = "";
		try {
			operaUserName = getLoginRealName(user);
		} catch (Exception e1) {
			logger.error("getLoginRealName error",e1);
			resultMap.put("message", "操作用户异常");
			return resultMap;
		}

		creditItem.setModifier(operaUserName);


		try {

			if (!creditItemService.transactionSaveItemAndSkuAndHistory(creditItem)){
				logger.error("transactionSaveItemAndSkuAndHistory failed, itemId:{}", ReflectionToStringBuilder.toString(creditItem));
				resultMap.put("success", false);
				resultMap.put("message", "保存历史错误，请稍后重试！");
				return resultMap;
			}

			resultMap.put("success", true);
			resultMap.put("message", "操作成功");
		} catch (Exception e) {
			logger.error("doCreateCreditItemWithSku error,creditItem:{}", ReflectionToStringBuilder.toString(creditItem), e);
			resultMap.put("success", false);
			resultMap.put("message", "异常，请稍后重试");
			return resultMap;
		}
		return resultMap;
	}

	/**
	 * 查看历史版本
	 * @param map
	 * @param creditItemHistory
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value={"doQueryCreditItemHistory.do"})
	public Map<String, Object> doQueryCreditItemHistory(@RequestParam Map<String, Object> map, CreditItemHistory creditItemHistory){
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");

		try {
			List<CreditItemHistory> creditItemList = creditItemService.selectItemHisAndSkuByParam(creditItemHistory);
			int creditItemCount = creditItemService.selectItemHisAndSkuCountByParam(creditItemHistory);
			resultMap.put("rows", creditItemList);
			resultMap.put("total", creditItemCount);
		}catch (Exception e){
			logger.error("doQueryCreditItem error,creditItem:{}", ReflectionToStringBuilder.toString(creditItemHistory), e);
			resultMap.put("rows", new ArrayList<CreditItemHistory>());
			resultMap.put("total", 0);
			resultMap.put("success", false);
			resultMap.put("message", "异常，请稍后重试");
		}

		return resultMap;
	}

}
