package com.wangyin.boss.credit.enterprise.beans;

import java.io.Serializable;

/**
 * @author huangzhiqiang
 * @data 2018/11/20
 */
public class CrawlerWord extends SensitiveWord implements Serializable {

    /**
     * 权重
     */
    private Integer weight;
    /**
     * 命中频率
     */
    private Integer hit;
    /**
     * 任务编号
     */
    private Long jobId;
    /**
     * 任务流水号
     */
    private Long jobNo;
    /**
     * 评分
     */
    private Integer score;
    /**
     * 返回结果ID
     */
    private Long jobResId;

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public Integer getHit() {
        return hit;
    }

    public void setHit(Integer hit) {
        this.hit = hit;
    }

    public Long getJobId() {
        return jobId;
    }

    public void setJobId(Long jobId) {
        this.jobId = jobId;
    }

    public Long getJobNo() {
        return jobNo;
    }

    public void setJobNo(Long jobNo) {
        this.jobNo = jobNo;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Long getJobResId() {
        return jobResId;
    }

    public void setJobResId(Long jobResId) {
        this.jobResId = jobResId;
    }
}
