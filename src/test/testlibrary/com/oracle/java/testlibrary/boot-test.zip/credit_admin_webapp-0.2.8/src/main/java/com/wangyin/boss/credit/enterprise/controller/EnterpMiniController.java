package com.wangyin.boss.credit.enterprise.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.jr.boss.credit.domain.common.enums.CreditMiniAreaProcodeEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditMiniProjectParamConfigEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditMiniSampleProgressEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditMiniStatusEnum;
import com.jd.jr.boss.credit.facade.authen.beans.param.MiniProjectQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.MiniSampleQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.DueStatusParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.MiniCommAreaComplQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.controller.BaseController;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniCommonArea;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniProject;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniSampleBase;
import com.wangyin.boss.credit.admin.enums.CreditProjectProgressEnum;
import com.wangyin.boss.credit.enterprise.service.CreditMiniService;
import com.wangyin.boss.credit.enterprise.service.HspService;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : 征信Mini尽调控制类
* @author : yangjinlin@jd.com
* @date ：2017年10月22日 下午4:05:02 
* @version 1.0 
* @return  */
@Controller
@RequestMapping("/creditMini")
public class EnterpMiniController extends BaseController  {

	private static final Logger LOGGER = LoggerFactory.getLogger(EnterpMiniController.class);
	
	@Autowired
	private CreditMiniService miniService;
	@Autowired
	private HspService hspService;
	
	/**
	 * 查询征信Mini尽调项目信息 分页 
	 * @param map
	 * @param queryParam
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryMiniProject.do")
	public Map<String, Object> doQueryMiniProject(@RequestParam Map<String, String> map, MiniProjectQueryParam queryParam) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			if (StringUtils.isNotBlank(queryParam.getStartCreateDateStr())) {
				queryParam.setStartCreateDateStr(queryParam.getStartCreateDateStr() + " 00:00:00");
			}
			if (StringUtils.isNotBlank(queryParam.getEndCreateDateStr())) {
				queryParam.setEndCreateDateStr(queryParam.getEndCreateDateStr() + " 23:59:59");
			}
			CreditPage<CreditMiniProject> resultPage = miniService.selectMiniProjectPageByParam(queryParam);
            List<CreditMiniProject> resultList = resultPage.getRows();
            for(CreditMiniProject project : resultList){
            	project.setProjectProgress(CreditProjectProgressEnum.enumValueOf(project.getProjectProgress()).toDescription());
            	project.setSampleUnFinishCount(project.getSampleCount()-project.getSampleFinishCount()-project.getSampleOngoingCount());
            }
            Long count=resultPage.getTotal();
            resultMap.put("rows", resultList);
            resultMap.put("total", count);
		} catch (Exception e) {
			LOGGER.error("doQueryMiniProject exception ,{}", e);
			resultMap.put("rows", new ArrayList<CreditContract>());
			resultMap.put("total", 0);
		}
		return resultMap;
	}
	
	/**
	 * 查询征信Mini尽调样本信息   分页 
	 * @param map
	 * @param queryParam
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryMiniSample.do")
	public Map<String, Object> doQueryMiniSample(@RequestParam Map<String, String> map, MiniSampleQueryParam queryParam) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
			if (StringUtils.isNotBlank(queryParam.getStartCreateDateStr())) {
				queryParam.setStartCreateDateStr(queryParam.getStartCreateDateStr() + " 00:00:00");
			}
			if (StringUtils.isNotBlank(queryParam.getEndCreateDateStr())) {
				queryParam.setEndCreateDateStr(queryParam.getEndCreateDateStr() + " 23:59:59");
			}
			if (StringUtils.isNotBlank(queryParam.getSampleStatus())) {
				queryParam.setSampleStatus(CreditMiniStatusEnum.enumValueOf(queryParam.getSampleStatus()).toCode().toString());
			}
			if (StringUtils.isNotBlank(queryParam.getSampleProgress())) {
				queryParam.setSampleProgress(CreditMiniSampleProgressEnum.enumValueOf(queryParam.getSampleProgress()).toCode().toString());
			}
			if(StringUtils.isNotBlank(queryParam.getSampleProvince()) && queryParam.getSampleProvince().contains(":")){
				queryParam.setSampleProvince(queryParam.getSampleProvince().split(":")[0]);
			}
			if(StringUtils.isNotBlank(queryParam.getSampleCity()) && queryParam.getSampleCity().contains(":")){
				queryParam.setSampleCity(queryParam.getSampleCity().split(":")[0]);
			}
			if(StringUtils.isNotBlank(queryParam.getSampleDistrict()) && queryParam.getSampleDistrict().contains(":")){
				queryParam.setSampleDistrict(queryParam.getSampleDistrict().split(":")[0]);
			}
			CreditPage<CreditMiniSampleBase> resultPage = miniService.selectMiniSamplePageByParam(queryParam);
            List<CreditMiniSampleBase> resultList = resultPage.getRows();
            for(CreditMiniSampleBase sampleBase : resultList){
            	sampleBase.setSampleStatusStr(StringUtils.isBlank(sampleBase.getSampleStatus()) ? "未知" : CreditMiniStatusEnum.enumValueOf(Integer.valueOf(sampleBase.getSampleStatus())).toDescription());
            	sampleBase.setSampleProgressStr(StringUtils.isBlank(sampleBase.getSampleProgress()) ? "未知" : CreditMiniSampleProgressEnum.enumValueOf(Integer.valueOf(sampleBase.getSampleProgress())).toDescription());
            }
            Long count=resultPage.getTotal();
            resultMap.put("rows", resultList);
            resultMap.put("total", count);
		} catch (Exception e) {
			LOGGER.error("doQueryMiniProject exception ,{}", e);
			resultMap.put("rows", new ArrayList<CreditContract>());
			resultMap.put("total", 0);
		}
		return resultMap;
	}
	
	/**
	 * 查询Mini尽调有效省份List
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("validMiniProvinceList.do")
	public Map<String, Object> validMiniProvinceList(@RequestParam Map<String, Object> map) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<CreditMiniCommonArea> provinceList = new ArrayList<CreditMiniCommonArea>();
		resultMap.put("success", false);
		resultMap.put("message", "系统异常");
		try {
			MiniCommAreaComplQueryParam queryParam = new MiniCommAreaComplQueryParam();
			queryParam.setProcode(CreditMiniAreaProcodeEnum.PR.toName());
			provinceList = miniService.queryValidMiniAreaList(queryParam);
			resultMap.put("success", true);
		} catch (Exception e) {
			LOGGER.error("validMiniProvinceList failed,{} " , e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
		}
		resultMap.put("provinceList", provinceList);
		return resultMap;
	}
	/**
	 * 查询Mini尽调有效市份List
	 * @param map
	 * @param areaName
	 * @return
	 */
	@ResponseBody
	@RequestMapping("validMiniCityList.do")
	public Map<String, Object> validMiniCityList(@RequestParam Map<String, Object> map, String areaName) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "系统异常");
		List<CreditMiniCommonArea> cityList = new ArrayList<CreditMiniCommonArea>();
		if(StringUtils.isBlank(areaName)){
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
		}
		try {
			String areaNo = areaName.split(":")[1];
			MiniCommAreaComplQueryParam queryParam = new MiniCommAreaComplQueryParam();
			queryParam.setPid(Long.valueOf(areaNo));
			queryParam.setProcode(CreditMiniAreaProcodeEnum.CI.toName());
			cityList = miniService.queryValidMiniAreaList(queryParam);
			resultMap.put("success", true);
		} catch (Exception e) {
			LOGGER.error("validMiniCityList failed, {}" , e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
		}
		resultMap.put("cityList", cityList);
		return resultMap;
	}
	/**
	 * 查询Mini尽调有效区县List
	 * @param map
	 * @param areaName
	 * @return
	 */
	@ResponseBody
	@RequestMapping("validMiniDistrictList.do")
	public Map<String, Object> validMiniDistrictList(@RequestParam Map<String, Object> map, String areaName) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<CreditMiniCommonArea> districtList = new ArrayList<CreditMiniCommonArea>();
		if(StringUtils.isBlank(areaName)){
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
		}
		try {
			if(!areaName.contains(":")){
				resultMap.put("success", false);
				resultMap.put("message", "系统异常");
			}
			String areaNo = areaName.split(":")[1];
			MiniCommAreaComplQueryParam queryParam = new MiniCommAreaComplQueryParam();
			queryParam.setPid(Long.valueOf(areaNo));
			queryParam.setProcode(CreditMiniAreaProcodeEnum.DI.toName());
			districtList = miniService.queryValidMiniAreaList(queryParam);
		} catch (Exception e) {
			LOGGER.error("validMiniDistrictList failed, {}" , e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
		}
		resultMap.put("districtList", districtList);
		return resultMap;
	}

    /**
     * 根据Mini尽调项目ID查询项目详情
     * @param map
     * @param projectId
     * @return
     */
	@ResponseBody
	@RequestMapping("doQueryMiniProjectDetail.do")
	public Map<String, Object> doQueryMiniProjectDetail(@RequestParam Map<String, Object> map,String projectId) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "系统异常");
		if(StringUtils.isBlank(projectId)){
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
		}
		CreditMiniProject project = new CreditMiniProject();
		try {
			MiniProjectQueryParam queryParam = new MiniProjectQueryParam();
			queryParam.setStart(null);
			queryParam.setLimit(null);
			queryParam.setId(Integer.valueOf(projectId));
			CreditPage<CreditMiniProject> resultPage = miniService.selectMiniProjectPageByParam(queryParam);
			List<CreditMiniProject> resultList = resultPage.getRows();
			if(CollectionUtils.isNotEmpty(resultList)){
				DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				project = resultList.get(0);
				project.setHasVideoStr(CreditMiniProjectParamConfigEnum.enumValueOf(project.getHasVideo()).toDescription());
				project.setHasPhotoStr(CreditMiniProjectParamConfigEnum.enumValueOf(project.getHasPhoto()).toDescription());
				project.setHasPhoneStr(CreditMiniProjectParamConfigEnum.enumValueOf(project.getHasPhone()).toDescription());
				project.setHasQuestionnaireStr(CreditMiniProjectParamConfigEnum.enumValueOf(project.getHasQuestionnaire()).toDescription());
				project.setProjectProgress(CreditProjectProgressEnum.enumValueOf(project.getProjectProgress()).toDescription());
				project.setModifiedDateStr(df1.format(project.getModifiedDate()));
				project.setCreatedDateStr(df1.format(project.getCreatedDate()));
				project.setSampleUnFinishCount(project.getSampleCount()-project.getSampleFinishCount()-project.getSampleOngoingCount());
				resultMap.put("success", true);
			}
		} catch (Exception e) {
			LOGGER.error("doQueryMiniProjectDetail failed, {}" + e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
		}
		try {
			if(StringUtils.isNotBlank(project.getQuestionnaireFileId())){
				String[] questionnaireFileIds = project.getQuestionnaireFileId().split(",");
				Map<String, String> questionnaireFileMap = new HashMap<String,String>();
				for(int i=0;i<questionnaireFileIds.length;i++){
					if(questionnaireFileMap.containsKey(questionnaireFileIds[i])){
						continue;
					}else{
						if(StringUtils.isNotBlank(project.getQuestionnaireFileName())){
							String[] questionnaireFileNames = project.getQuestionnaireFileName().split(",");
							for(int j=0;j<questionnaireFileIds.length;j++){
								if(i == j){
									String questionnaireFileUrl = hspService.createHspUrlByFid(questionnaireFileIds[i], StringUtils.isBlank(questionnaireFileNames[j]) ? questionnaireFileIds[i] : questionnaireFileNames[j]);
									questionnaireFileMap.put(questionnaireFileUrl, questionnaireFileNames[j]);
								}
							}
			        	}
					}
				}
				project.setQuestionnaireFileMap(questionnaireFileMap);
        	}
			if(StringUtils.isNotBlank(project.getWarrantFileId())){
				String warrantFileUrl = hspService.createHspUrlByFid(project.getWarrantFileId(), StringUtils.isBlank(project.getWarrantFileName()) ? project.getWarrantFileId() : project.getWarrantFileName() );
				project.setWarrantFileUrl(warrantFileUrl);
			}
		} catch (Exception e) {
			LOGGER.error("doQueryMiniProjectDetail failed, {}" , e);
		}
		resultMap.put("miniProject", project);
		return resultMap;
	}
	
	/**
	 * 再次发起样本详情查询并落地
	 * @param map
	 * @param user
	 * @param queryParam 
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doCompleSampleDetails.do")
	public Map<String, Object> doCompleSampleDetails(@RequestParam Map<String, String> map, String user,
			MiniSampleQueryParam queryParam) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "操作失败，请稍后操作!");
		String operaUserName = "";
		try {
			operaUserName = getLoginRealName(user);
		} catch (Exception e1) {
			LOGGER.error("getLoginRealName error"+ e1);
			operaUserName = "error";
		}
		if(StringUtils.isBlank(queryParam.getSampleNo())){
			resultMap.put("success", false);
			resultMap.put("message", "操作失败，请稍后操作!");
		}
		try {
			CreditRequestParam<List<DueStatusParam>> requestParam = new CreditRequestParam<List<DueStatusParam>>();
	    	List<DueStatusParam> dueStatusParamList = new ArrayList<DueStatusParam>();
	    	DueStatusParam DueStatus = new DueStatusParam();
	    	DueStatus.setSampleId(queryParam.getSampleNo());
	    	DueStatus.setStatus("FINISH");
	    	DueStatus.setOperator(operaUserName);
	    	dueStatusParamList.add(DueStatus);
	    	requestParam.setParam(dueStatusParamList);
	    	LOGGER.error("doCompleSampleDetails requestParam, "+ GsonUtil.getInstance().toJson(requestParam));
			CreditResponseData<String> responseData = miniService.doCompleSampleDetails(requestParam);
			LOGGER.error("doCompleSampleDetails responseData, "+ GsonUtil.getInstance().toJson(responseData));
			if(responseData.isSuccess()){
				resultMap.put("success", true);
				resultMap.put("message", "操作成功");
			}else{
				resultMap.put("success", false);
				resultMap.put("message", "操作失败，请稍后操作!");
			}
		} catch (Exception e) {
			LOGGER.error("doCompleSampleDetails error,{}", e);
			resultMap.put("success", false);
			resultMap.put("message", "操作异常，请稍后重试");
		}
		return resultMap;
		
	}
	
	
}
