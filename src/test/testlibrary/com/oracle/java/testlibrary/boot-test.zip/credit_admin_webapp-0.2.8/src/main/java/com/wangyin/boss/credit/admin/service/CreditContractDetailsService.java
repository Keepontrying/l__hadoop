package com.wangyin.boss.credit.admin.service;

import java.util.List;

import com.wangyin.boss.credit.admin.entity.CreditContractDetails;

/**
 * 合同操作记录接口
 * @author wyhaozhihong
 *
 */
public interface CreditContractDetailsService {
	
	/**
	 * 根据条件查询数据 分页
	 * @param creditContractDetails
	 * @return
	 */
	List<CreditContractDetails> selectByParam(CreditContractDetails creditContractDetails);
	
	/**
	 * 根据条件查询总条数
	 * @param creditContractDetails
	 * @return
	 */
	int selectCountByParam(CreditContractDetails creditContractDetails);
	
	/**
	 * 根据合同ID查询合同操作记录表
	 * @author wyhaozhihong
	 * @param contractId
	 * @return
	 */
	List<CreditContractDetails> selectByContractId(Integer contractId);

}
