package com.wangyin.boss.credit.admin.publicSentiment;

import com.wangyin.boss.credit.admin.BaseTest;
import com.wangyin.boss.credit.enterprise.beans.SensitiveWord;
import com.wangyin.boss.credit.enterprise.beans.SensitiveWordGroup;
import com.wangyin.boss.credit.enterprise.beans.SensitiveWordQueryParam;
import com.wangyin.boss.credit.enterprise.dao.SensitiveWordGroupMapper;
import com.wangyin.boss.credit.enterprise.dao.SensitiveWordMapper;
import com.wangyin.operation.utils.GsonUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.Date;

/**
 * @author huangzhiqiang
 * @data 2018/11/19
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:applicationContext.xml" })
public class SensitiveWordMapperTest extends BaseTest {

    @Resource
    private SensitiveWordMapper mapper;
    @Resource
    private SensitiveWordGroupMapper groupMapper;

    @Test
    public void insert() {
        Date createdDate = new Date();
        SensitiveWord word = new SensitiveWord();
        word.setType((byte) 0);
        word.setGroupId(1L);
        word.setGroupName("涉黄");
        word.setWord("京东金融");
        word.setCreatedDate(createdDate);
        mapper.insert(word);
    }

    @Test
    public void query(){
        SensitiveWordQueryParam param = new SensitiveWordQueryParam();
        param.setWord("词");
        System.out.println(GsonUtil.getInstance().toJson(mapper.query(param)));
    }

    @Test
    public void queryGroup(){
        SensitiveWordQueryParam param = new SensitiveWordQueryParam();
        param.setWord("项目名称");
        System.out.println(GsonUtil.getInstance().toJson(groupMapper.query(param)));
    }

    @Test
    public void update(){
        SensitiveWord word = new SensitiveWord();
        word.setType((byte) 0);
        word.setGroupId(1L);
        word.setGroupName("涉黄");
        word.setWord("京东金融");
        mapper.update(word);
    }

    @Test
    public void updateGoup(){
        SensitiveWordGroup group = new SensitiveWordGroup();
        group.setId(1116L);
        group.setName("涉黑");
        group.setContent("不可描述");
        groupMapper.update(group);
    }
}
