package com.wangyin.boss.credit.enterprise.fmq;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jd.jr.bc.bcapi.entity.BcRequestParam;
import com.jd.jr.bc.bcapi.entity.BcResponseData;
import com.jd.jr.bc.bcapi.entity.opinionTrack.OpinionTrackQueryRequest;
import com.jd.jr.bc.bcapi.entity.opinionTrack.OpinionTrackQueryResponse;
import com.jd.jr.bc.bcapi.facade.OpinionTrackFacade;
import com.jdjr.fmq.client.consumer.MessageListener;
import com.jdjr.fmq.common.message.Message;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobFlow;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResults;
import com.wangyin.boss.credit.enterprise.beans.CrawlerWord;
import com.wangyin.boss.credit.enterprise.service.CrawlerJobFlowService;
import com.wangyin.boss.credit.enterprise.service.CrawlerJobResultsService;
import com.wangyin.commons.util.Logger;
import com.wangyin.operation.utils.GsonUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 爬去任务返回结果
 *
 * @author huangzhiqiang
 * @data 2018/11/28
 */
@Component("crawlerJobListener")
public class CrawlerJobListener implements MessageListener {
    private Logger logger = new Logger(CrawlerJobListener.class);

    @Resource
    private CrawlerJobFlowService flowService;
    @Resource
    private CrawlerJobResultsService resultsService;
    @Resource
    private OpinionTrackFacade trackQueryFacade;

    private static final String BC_SYSTEM_ID = "ENTCAE";

    @Override
    public void onMessage(List<Message> list) throws Exception {
        if (list == null || list.isEmpty()) {
            logger.warn("CrawlerJobListener message is null");
            return;
        }

        CrawlerJobFlow flow;
        for (Message message : list) {
            String objectJson = message.getText();
            logger.info("CrawlerJobListener message, body part:{}", objectJson);

            ObjectMapper mapper = new ObjectMapper();

            JsonNode node = mapper.readTree(objectJson);
            JsonNode resultNode = node.get("param");
            String code = node.get("code").asText();
            String msg = node.get("msg").asText("");
            String taskNo = resultNode.get("taskNo").asText();
            String taskId = resultNode.get("taskId").asText();
            if (StringUtils.isNotBlank(code)) {
                if ("1001".equals(code)) {
                    flow = new CrawlerJobFlow();
                    flow.setJobNo(taskNo);
                    flow.setMessage(msg);
                    flow.setState((byte) -1);
                    flowService.addOrUpdate(flow);
                } else if ("0000".equals(code)) {
                    BcRequestParam<OpinionTrackQueryRequest> bcParam = new BcRequestParam<>();
                    OpinionTrackQueryRequest request = new OpinionTrackQueryRequest();
                    request.setTaskNo(taskNo);
                    request.setTaskId(taskId);
                    bcParam.setSystemId(BC_SYSTEM_ID);
                    bcParam.setParam(request);

                    logger.info("opinionTrackFacade接口请求：", GsonUtil.getInstance().toJson(bcParam));
                    BcResponseData<OpinionTrackQueryResponse> responseData = trackQueryFacade.queryTrackResult(bcParam);
                    logger.info("opinionTrackFacade接口返回参数：", GsonUtil.getInstance().toJson(responseData));
                    if (responseData != null && "SUCCESS".equalsIgnoreCase(responseData.getCode())) {
                        List<String> results = responseData.getData().getRows();
                        if (results != null && results.size() > 0) {
                            addCrawlerJobResult(results);
                            flow = new CrawlerJobFlow();
                            flow.setState((byte) 1);
                            flow.setJobNo(taskNo);
                            flowService.addOrUpdate(flow);
                        }
                    }
                }
            } else {
                throw new Exception("CrawlerJobListener code is null");
            }
        }
    }

    private void addCrawlerJobResult(List<String> results) throws IOException {
        ObjectMapper mapper;
        CrawlerJobResults jobResults;
        List<CrawlerWord> words;
        if (results != null && results.size() > 0) {
            for (String result : results) {
                mapper = new ObjectMapper();
                jobResults = new CrawlerJobResults();

                JsonNode node = mapper.readTree(result);
                if (node.get("taskId") != null) {
                    jobResults.setJobId(node.get("taskId").asLong());
                }
                if (node.get("taskNo") != null) {
                    jobResults.setJobNo(node.get("taskNo").asText(""));
                }
                if (node.get("siteNo") != null) {
                    jobResults.setTargetUrlCode(node.get("siteNo").asText(""));
                }
                if (node.get("detailUrl") != null) {
                    jobResults.setArticleUrl(node.get("detailUrl").asText(""));
                }
                if (node.get("title") != null) {
                    jobResults.setArticleTitle(node.get("title").asText(""));
                }
                if (node.get("words") != null) {
                    node = mapper.readTree(node.get("words").toString());
                    CrawlerWord word;
                    words = new ArrayList<>();
                    for (JsonNode childrenNode : node) {
                        word = new CrawlerWord();
                        word.setWord(childrenNode.get("word").asText());
                        word.setType((byte) childrenNode.get("type").asInt());
                        word.setWeight(childrenNode.get("weight").asInt());
                        word.setHit(childrenNode.get("hit").asInt());
                        word.setGroupId(childrenNode.get("groupId").asLong());
                        word.setJobId(childrenNode.get("jobId").asLong());
                        words.add(word);
                    }
                    jobResults.setWords(words);
                }
                resultsService.insert(jobResults);
            }
        }
    }
}
