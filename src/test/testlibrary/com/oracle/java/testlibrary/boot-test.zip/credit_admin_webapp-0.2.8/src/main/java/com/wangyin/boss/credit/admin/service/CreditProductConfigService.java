package com.wangyin.boss.credit.admin.service;

import java.util.List;
import java.util.Map;

import com.wangyin.boss.credit.admin.entity.CreditChangeRecord;
import com.wangyin.boss.credit.admin.entity.CreditProductConfig;

/** 
* @desciption : 产品服务配置接口方法
* @author : yangjinlin@jd.com
* @date ：2016年8月29日 下午3:24:55 
* @version 1.0 
* @return  */
public interface CreditProductConfigService {

	/**
	 * 根据查询条件查询  产品服务配置  分页
	 * @param creditProductStrategy
	 * @return
	 */
	List<CreditProductConfig> selectCreProdConfByPams(CreditProductConfig creditProductConfig);
	/**
	 * 根据查询条件查询  产品服务配置
	 * @param creditProductConfig
	 * @return
	 */
	List<CreditProductConfig> selectCreProdConfListByPams(CreditProductConfig creditProductConfig);

	/**
	 * 根据查询条件查询  产品服务配置  总条数
	 * @param creditProductConfig
	 * @return
	 */
	int selectCountByParam(CreditProductConfig creditProductConfig);

	/**
	 * 根据产品服务配置主键configId 查询 产品服务配置 详细信息
	 * @param configId
	 * @return
	 */
	CreditProductConfig selectCredProdConfByConfId(Integer configId);

	/**
	 * 根据产品服务配置表主键 config_id更新
	 * @param creditProductConfig
	 * @param operaUserName 操作者名称
	 * @param remark 备注
	 * @return
	 * @throws Exception 
	 */
	int updateCredProdConfByConfId(CreditProductConfig creditProductConfig, String operaUserName, String remark) throws Exception;

	/**
	 * 根据关系id查询 操作关系记录表
	 * @param configId
	 * @return
	 */
	List<CreditChangeRecord> selectCredChanRecdsByConfigId(Integer configId);

	/**
	 * 根据产品id、商户Id 查询 产品服务配置 信息
	 * @param params
	 * @return
	 */
	List<CreditProductConfig> selectCredProdConfByProdMercId(Map<String, Object> params);

	/**
	 * 根据产品服务配置表主键 productId，merchantId删除config表数据。
	 * @param creditProductConfig
	 * @return
	 * @throws Exception
	 */
	int deleteCredProdConfByProMerId(CreditProductConfig creditProductConfig) throws Exception;
	/**
	 * 根据产品id、商户Id 新增 产品服务配置 信息
	 * @param credProdConf
	 * @return
	 */
	int addCreProdConfByProdMerchId(CreditProductConfig credProdConf) throws Exception;;
}
