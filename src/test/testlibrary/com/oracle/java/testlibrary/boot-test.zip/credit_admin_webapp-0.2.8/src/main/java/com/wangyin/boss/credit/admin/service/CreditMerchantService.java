package com.wangyin.boss.credit.admin.service;

import java.util.List;
import java.util.Map;

import com.jd.jr.boss.credit.credit.gateway.merchantca.exception.MerchantException;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.operation.common.beans.Page;

public interface CreditMerchantService {
	
	/**
	 * 根据商户号查询商户关系信息
	 * @author wyhaozhihong
	 * @param merchantNo
	 * @return
	 */
	CreditMerchant selectByMerchantNo(String merchantNo);
	/**
	 * 根据商户号、商户类型查询商户关系信息
	 * @author liuwei55
	 * @param map
	 * @return
	 */
	CreditMerchant selectByMerNoType(Map<String,String> map);
	
	/**
	 * 根据主键查询商户关系信息
	 * @author wyhaozhihong
	 * @param merchantId
	 * @return
	 */
	CreditMerchant selectByMerchantId(Integer merchantId);

	/**
	 * 根据商户号查询商户List
	 * @param merchantNo
	 * @return
	 */
	List<CreditMerchant> selectMerchListByNo(String merchantNo);

	/**
	 * 根据查询参数获取商户信息List
	 * @param creditMerchant
	 * @return
	 */
	List<CreditMerchant> queryMerchantListByParam(CreditMerchant creditMerchant);

	/**
	 * 校验是否是vip商户
	 * @param merchantId
	 * @return
	 */
	Boolean isVipMonitorMerchant(Integer merchantId);

	/**
	 * 分页查询商户信息
	 * @author: dongzhihua
	 * @time: 2018/10/29 16:24:26
	 */
    Page<CreditMerchant> queryCreditMerchantPage(CreditMerchant creditMerchant) throws MerchantException;
}
