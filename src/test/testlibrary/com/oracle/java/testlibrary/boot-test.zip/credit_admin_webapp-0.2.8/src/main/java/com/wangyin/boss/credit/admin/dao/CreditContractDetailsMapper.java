package com.wangyin.boss.credit.admin.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditContractDetails;

@SqlMapper
@Component
public interface CreditContractDetailsMapper {

	List<CreditContractDetails> selectByParam(CreditContractDetails creditContractDetails);

	int selectCountByParam(CreditContractDetails creditContractDetails);
	
	List<CreditContractDetails> selectByContractId(Integer contractId);
	
	int insert(CreditContractDetails record);

}