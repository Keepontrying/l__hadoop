package com.wangyin.boss.credit.enterprise.controller;

import com.alibaba.fastjson.JSONObject;
import com.jd.jr.boss.credit.facade.authen.api.SummarizeFacade;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.controller.BaseController;
import com.wangyin.boss.credit.admin.entity.CreditSummarize;
import com.wangyin.boss.credit.admin.enums.SummarizeTypeEnum;
import com.wangyin.boss.credit.admin.service.CreditBillService;
import com.wangyin.boss.credit.admin.utils.ExcelUtil;
import com.wangyin.boss.credit.enterprise.beans.CallCaseInfo;
import com.wangyin.boss.credit.enterprise.beans.CallCaseInfoQueryParam;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.beans.UploadFile;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 
 * <ul>
 * <li>1、开发日期：2017年12月25日</li>
 * <li>2、开发时间：下午9:36:06</li>
 * <li>3、作 者：zhanghui12</li>
 * <li>4、类型名称：EnterBillController</li>
 * <li>5、类型意图：账单查询</li>
 * </ul>
 *
 */
@Controller
@RequestMapping("/callCase")
public class EnterpCallCaseController extends BaseController {
	private static final Logger logger = LoggerFactory.getLogger(EnterpCallCaseController.class);
	@Autowired
	private CreditBillService creditBillService;
	@Autowired
	private SummarizeFacade summarizeFacade;

//	 @ResponseBody
//	 @RequestMapping("toProductCallCaseQuery.view")
//	 public Map<String, String> toPage(@RequestParam Map<String, String> map)	 {
//	 return map;
//	 }
	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2017年12月26日</li>
	 * <li>2、开发时间：上午10:36:35</li>
	 * <li>3、作 者：zhanghui12</li>
	 * <li>4、返回类型：Map<String,Object></li>
	 * <li>5、方法含义：企业征信——产品调用量查询</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 *
	 * @param productName
	 * @param beginDate
	 * @param endDate
	 * @param start
	 * @param limit
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doProductCallCaseQuery.biz")
	public Map<String, Object> doQueryPorductBill(String productName, String beginDate, String endDate, int start,
			int limit) {
		logger.info("查询产品调用量:" + productName);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<CallCaseInfo> creditBillList = new ArrayList<CallCaseInfo>();
		CallCaseInfo callCaseInfo = null;
		try {
			if (StringUtils.isNotBlank(beginDate)) {
				beginDate = beginDate + " 00:00:00";
			}
			if (StringUtils.isNotBlank(endDate)) {
				endDate = endDate + " 23:59:59";
			}
			int failTotalCount = 0;
			int creditBillCount = creditBillService.queryProductBillPageCount(productName, beginDate, endDate);
			if (creditBillCount != 0) {
				creditBillList = creditBillService.queryProductBillPage(productName, beginDate, endDate, start, limit);
				failTotalCount = billHandel(creditBillList);
			}
			CallCaseInfoQueryParam caseInfoQueryParam = new CallCaseInfoQueryParam();
			caseInfoQueryParam.setProductName(productName);
			caseInfoQueryParam.setBeginDate(beginDate);
			caseInfoQueryParam.setEndDate(endDate);
			callCaseInfo = creditBillService.queryBillFiledsTotalCount(caseInfoQueryParam);
//			callCaseInfo.setFailTotalCount(failTotalCount+"");
			resultMap.put("callCaseInfo", callCaseInfo);
			resultMap.put("rows", creditBillList);
			resultMap.put("total", creditBillCount);

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		logger.info("查询产品调用量结果：" + JSONObject.toJSONString(resultMap));
		return resultMap;
	}

	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2018年1月3日</li>
	 * <li>2、开发时间：下午6:11:59</li>
	 * <li>3、作 者：zhanghui12</li>
	 * <li>4、返回类型：Map<String,Object></li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * 
	 * @param merchantName
	 * @param beginDate
	 * @param endDate
	 * @param start
	 * @param limit
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doMerchantCallCaseQuery.biz")
	public Map<String, Object> doQueryMerchantBill(String merchantName, String merchantNo, String beginDate,
			String endDate, int start,
			int limit) {
		logger.info("查询商户调用量:" + merchantName);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<CallCaseInfo> creditBillList = new ArrayList<CallCaseInfo>();
		CallCaseInfo callCaseInfo = null;
		try {
			int creditBillCount = creditBillService.queryMerchantBillPageCount(merchantName, merchantNo, beginDate,
					endDate);
			int failTotalCount = 0;
			if (creditBillCount != 0) {
				creditBillList = creditBillService.queryMerchantBillPage(merchantName, merchantNo, beginDate, endDate,
						start,
						limit);
				failTotalCount = billHandel(creditBillList);
			}
			CallCaseInfoQueryParam caseInfoQueryParam = new CallCaseInfoQueryParam();
			caseInfoQueryParam.setMerchantNo(merchantNo);
			caseInfoQueryParam.setMerchantName(merchantName);
			caseInfoQueryParam.setBeginDate(beginDate);
			caseInfoQueryParam.setEndDate(endDate);
			callCaseInfo = creditBillService.queryBillFiledsTotalCount(caseInfoQueryParam);
//			callCaseInfo.setFailTotalCount(failTotalCount+"");
			resultMap.put("callCaseInfo", callCaseInfo);
			resultMap.put("rows", creditBillList);
			resultMap.put("total", creditBillCount);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			resultMap.put("message", e.getMessage());
		}
		logger.info("查询产品调用量结果：" + JSONObject.toJSONString(resultMap));
		return resultMap;
	}

	@ResponseBody
	@RequestMapping("/doMerProCallCaseQuery.biz")
	public Map<String, Object> doQueryMerProchantBill(String productName, String merchantNo, String merchantName,
			String beginDate,
			String endDate, int start,
			int limit) {
		logger.info("查询商户+产品调用量，商户:" + merchantName + ",产品：" + productName);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<CallCaseInfo> creditBillList = new ArrayList<CallCaseInfo>();
		CallCaseInfo callCaseInfo = null;
		try {
			int creditBillCount = creditBillService.queryMerProBillPageCount(merchantName, merchantNo, productName,
					beginDate,
					endDate);
			int failTotalCount = 0;
			if (creditBillCount != 0) {
				creditBillList = creditBillService.queryMerProBillPage(merchantName, merchantNo, productName, beginDate,
						endDate,
						start,
						limit);
				failTotalCount = billHandel(creditBillList);
			}
			CallCaseInfoQueryParam caseInfoQueryParam = new CallCaseInfoQueryParam();
			caseInfoQueryParam.setMerchantNo(merchantNo);
			caseInfoQueryParam.setMerchantName(merchantName);
			caseInfoQueryParam.setProductName(productName);
			caseInfoQueryParam.setBeginDate(beginDate);
			caseInfoQueryParam.setEndDate(endDate);
			callCaseInfo = creditBillService.queryBillFiledsTotalCount(caseInfoQueryParam);
//			callCaseInfo.setFailTotalCount(failTotalCount+"");
			resultMap.put("callCaseInfo", callCaseInfo);
			resultMap.put("rows", creditBillList);
			resultMap.put("total", creditBillCount);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		logger.info("查询产品调用量结果：" + JSONObject.toJSONString(resultMap));
		return resultMap;
	}

	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2018年1月5日</li>
	 * <li>2、开发时间：下午12:08:39</li>
	 * <li>3、作 者：zhanghui12</li>
	 * <li>4、返回类型：Map<String,Object></li>
	 * <li>5、方法含义：查询结果导出excel文件</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * 
	 * @param productName
	 * @param beginDate
	 * @param endDate
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/toProductCallCaseExport.download")
	public UploadFile doProductCallCaseExport(String productName, String beginDate, String endDate) {
		logger.info("导出产品调用量:" + productName);
		logger.info("start:" + System.currentTimeMillis());
		String workSheetName = beginDate + "到" + endDate + "产品调用量查询结果";

		String[] titles = { "产品名称", "单笔调用次数", "单笔总金额", "包量调用次数", "包量总金额", "成功总次数", "总金额", "失败总次数", "失败比例" };
		String[] properties = { "productName", "singleCount", "singleAmount", "packCount", "packAmount", "totalCount",
				"totalAmount", "errorCount", "errorRate" };

		List<CallCaseInfo> creditBillList = creditBillService.queryProductBillPage(productName, beginDate, endDate,
					null, null);
		int failTotalCount = 0;
		failTotalCount = billHandel(creditBillList);

        UploadFile uploadfile = export(titles, properties, creditBillList, workSheetName);
		logger.info("ProductCallCaseExport end:" + System.currentTimeMillis());

		return uploadfile;
	}

	private int  billHandel(List<CallCaseInfo> creditBillList) {
		int failTotalCount = 0;
		if (creditBillList != null) {
			for (CallCaseInfo callCase : creditBillList) {
				callCase.setPackAmount(StringUtil.centToDollar(callCase.getPackAmount()));
				callCase.setSingleAmount(StringUtil.centToDollar(callCase.getSingleAmount()));
				callCase.setTotalAmount(StringUtil.centToDollar(callCase.getTotalAmount()));

				int errorCount = Integer.parseInt(callCase.getAllCount()) - Integer.parseInt(callCase.getTotalCount());
				failTotalCount = failTotalCount + errorCount;
				callCase.setErrorCount(errorCount + "");
				BigDecimal big = new BigDecimal(errorCount).divide(new BigDecimal(callCase.getAllCount()), 4,
						RoundingMode.FLOOR);
				DecimalFormat df = new DecimalFormat("###.##");
				callCase.setErrorRate(df.format(big.multiply(new BigDecimal(100))) + "%");
			}
		}
		return failTotalCount;
	}

	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2018年1月8日</li>
	 * <li>2、开发时间：下午12:00:41</li>
	 * <li>3、作 者：zhanghui12</li>
	 * <li>4、返回类型：UploadFile</li>
	 * <li>5、方法含义：导出商户调用量统计</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * 
	 * @param merchantName
	 * @param merchantNo
	 * @param beginDate
	 * @param endDate
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/toMerchantCallCaseExport.download")
	public UploadFile doMerchantCallCaseExport(String merchantName, String merchantNo, String beginDate,
			String endDate) {
		logger.info("导出商户调用量:" + merchantName);
		logger.info("start:" + System.currentTimeMillis());
		String workSheetName = beginDate + "到" + endDate + "商户调用量查询结果";
		String[] titles = { "商户名称", "商户号", "账单机构", "单笔调用次数", "单笔总金额", "包量调用次数", "包量总金额", "成功总次数", "总金额", "失败总次数", "失败比例" };
		String[] properties = { "merchantName", "merchantNo","departmentDesc",  "singleCount", "singleAmount", "packCount", "packAmount",
				"totalCount", "totalAmount", "errorCount", "errorRate" };
		List<CallCaseInfo> creditBillList = creditBillService.queryMerchantBillPage(merchantName, merchantNo, beginDate,
				endDate, null, null);
		int failTotalCount = 0;
		failTotalCount = billHandel(creditBillList);
		UploadFile uploadfile = export(titles, properties, creditBillList, workSheetName);

		logger.info("MerchantCallCaseExport end:" + System.currentTimeMillis());

		return uploadfile;
	}

	@ResponseBody
	@RequestMapping("/toMerProCallCaseExport.download")
	public UploadFile doMerProCallCaseExport(String productName, String merchantNo, String merchantName,
			String beginDate,
			String endDate) {
		logger.info("导出商户+产品调用量");
		logger.info("start:" + System.currentTimeMillis());
		String workSheetName = beginDate + "到" + endDate + " 商户+产品调用量查询结果";
		String[] titles = { "商户名称", "商户号", "账单机构", "产品名称", "单笔调用次数", "单笔总金额", "包量调用次数", "包量总金额", "成功总次数", "总金额", "失败总次数",
				"失败比例" };
		String[] properties = { "merchantName", "merchantNo","departmentDesc","productName", "singleCount", "singleAmount", "packCount", "packAmount",
				"totalCount", "totalAmount", "errorCount", "errorRate" };
		List<CallCaseInfo> creditBillList = creditBillService.queryMerProBillPage(merchantName, merchantNo, productName,
				beginDate,
				endDate, null, null);
		int failTotalCount = 0;
		failTotalCount = billHandel(creditBillList);
		UploadFile uploadfile = export(titles, properties, creditBillList, workSheetName);

		logger.info("MerProCallCaseExport end:" + System.currentTimeMillis());

		return uploadfile;
	}

	/*
	 * 导出公用方法
	 */
	private UploadFile export(String[] titles, String[] properties, List<CallCaseInfo> creditBillList,
			String workSheetName) {
		String basePath = ConfigUtil.getString("app.credit.downloadpath");
		String date = (new SimpleDateFormat("yyyyMMdd")).format(new Date());
		String pathName = "/proCallCaseResult/" + date + "/" + workSheetName + ".xlsx";
		String dir = basePath + pathName;
		logger.info("basePath=" + basePath + ",dir=" + dir);

		OutputStream outputStream = null;
		ExcelUtil excelUtil = new ExcelUtil();
		try {
			File file = new File(dir);
			if (!file.getParentFile().exists()) {
				if (!file.getParentFile().mkdirs()) {
				}
			}
			if (!file.exists()) {
				file.createNewFile();
			}
			outputStream = new FileOutputStream(file);
			// 创建工作薄
			SXSSFWorkbook wb = new SXSSFWorkbook(500);
			// 声明工作表
			Sheet sheet = null;
			// sheet = excelUtil.export(wb, workSheetName, titles, sheet);
			sheet = excelUtil.export(wb, outputStream, workSheetName, titles, properties, creditBillList, "",
					CallCaseInfo.class, sheet, 0);
			wb.write(outputStream);
			wb.dispose();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		} finally {
			try {
				outputStream.flush();
				outputStream.close();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
		}
		UploadFile uploadfile = new UploadFile();
		uploadfile.setPathname("/accessDetail" + pathName);
		uploadfile.setOriginalName(workSheetName + ".xlsx");
		uploadfile.setVersion("2.0");
		uploadfile.setTemp(true);
		return uploadfile;
	}

	@ResponseBody
	@RequestMapping("/doSummarizeQuery.biz")
	public Map<String, Object> doSummarizeQuery(String month) {
		logger.info("汇总商户产品调用情况,month:" + month + ",start:" + System.currentTimeMillis());
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			if (StringUtil.isEmpty(month)) {
				month = DateFormatUtils.format(new Date(), "yyyy-MM");
			}
			map.put("monthDate", month);
			CreditRequestParam<String> reqParam = new CreditRequestParam<String>();
			reqParam.setParam(month);
			CreditResponseData<List<CreditSummarize>> response = summarizeFacade.querySummarize(reqParam);
			if (response != null && response.isSuccess()) {
				if (response.getData() != null && response.getData().size() > 0) {
					for (CreditSummarize summ : response.getData()) {
						if (summ.getSummarizeType() == SummarizeTypeEnum.ENT_SCORE_QUERY) {
							map.put("entScorePro", summ);
						}
						if (summ.getSummarizeType() == SummarizeTypeEnum.ENTERPRISE_REPORT_QUERY_BASIC) {
							map.put("entReportPro", summ);
						}
						if (summ.getSummarizeType() == SummarizeTypeEnum.ORGANIZATION) {
							map.put("newMerchant", summ);
						}
						if (summ.getSummarizeType() == SummarizeTypeEnum.OTHER_PRO) {
							map.put("otherPro", summ);
						}
					}
					map.put("success", true);
					map.put("message", "成功");
				} else {
					map.put("success", false);
					map.put("message", "该月份未统计");
				}

			} else {
				map.put("success", false);
				map.put("message", response.getMessage());
			}
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			map.put("success", false);
			map.put("message", "未知异常");
		}
		logger.info("doSummarizeQuery end:" + System.currentTimeMillis() + ",result:" + JSONObject.toJSONString(map));
		return map;
	}
}
