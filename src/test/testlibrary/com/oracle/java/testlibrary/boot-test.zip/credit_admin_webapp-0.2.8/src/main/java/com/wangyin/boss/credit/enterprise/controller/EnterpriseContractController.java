package com.wangyin.boss.credit.enterprise.controller;

 import java.math.BigDecimal;
 import java.math.RoundingMode;
 import java.text.DateFormat;
 import java.text.DecimalFormat;
 import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

 import com.jd.jr.boss.credit.domain.common.entity.CreditCallTimesGather;
 import com.jd.jr.boss.credit.domain.common.enums.CreditPurchaseTypeEnum;
 import com.jd.jr.boss.credit.facade.authen.beans.param.CallTimesGatherQueryParam;
 import com.wangyin.boss.credit.admin.enums.*;
 import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.jd.jr.boss.credit.domain.common.enums.ContractStatusEnum;
import com.jd.jr.boss.credit.domain.common.enums.CreditYesOrNoEnum;
import com.jd.jr.boss.credit.facade.authen.beans.param.ProductQueryParam;
import com.wangyin.boss.credit.admin.beans.TextValuePairs;
import com.wangyin.boss.credit.admin.controller.BaseController;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditProduct;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategy;
import com.wangyin.boss.credit.admin.entity.EnterpriseProductItemSku;
import com.wangyin.boss.credit.admin.entity.StrategyHasBuyedShow4Common;
import com.wangyin.boss.credit.admin.entity.StrategyShow4Common;
import com.wangyin.boss.credit.admin.entity.ProductShow4Common;
import com.wangyin.boss.credit.admin.entity.ProductToBuyShow4Common;
 import com.wangyin.boss.credit.admin.service.CreditContractService;
import com.wangyin.boss.credit.admin.service.CreditMerchantService;
import com.wangyin.boss.credit.admin.service.CreditProductService;
import com.wangyin.boss.credit.admin.service.CreditProductStrategyService;
import com.wangyin.boss.credit.admin.utils.DateUtil;
import com.wangyin.boss.credit.enterprise.entity.EnterpriseProductItemSkuModel;
import com.wangyin.boss.credit.enterprise.service.EnterpriseContractService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.operation.beans.UploadFile;
import com.wangyin.operation.beans.UploadObject;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : 企业征信合同controller
* @author : yangjinlin@jd.com
* @date ：2017年3月17日 上午11:00:12 
* @version 1.0 
* @return  */
@Controller
@RequestMapping("/enterpriseContract")
public class EnterpriseContractController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EnterpriseContractController.class);
	
	@Autowired
	private EnterpriseContractService enterpriseContractService;//企业征信合同接口类
	
	@Autowired 
	private CreditProductService creditProductService;//征信产品
	
	@Autowired 
	private CreditMerchantService creditMerchantService;//征信商户接口类
	
	@Autowired
	CreditContractService creditContractService;//
	
	@Autowired
	CreditProductStrategyService creditProductStrategyService;
	
	/**
	 * 查询企业征信合同
	 * @param map
	 * @param creditContract
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryEnterpriseContract.do")
	public Map<String, Object> doQueryEnterpriseContract(@RequestParam Map<String, Object> map,CreditContract creditContract){
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		
		List<CreditContract> list = null;
		int count = 0;
		try {
			creditContract.setCreditType(CreditTypeEnum.ENTERPRISE.toName());//仅查询企业征信合同相关数据
			if(StringUtils.isNotBlank(creditContract.getStartCreateDateStr())){
				creditContract.setCreatedDateStr(creditContract.getStartCreateDateStr() + " 00:00:00");
			}
			if(StringUtils.isNotBlank(creditContract.getEndCreateDateStr())){
				creditContract.setEndCreateDateStr(creditContract.getEndCreateDateStr() + " 23:59:59");
			}
            if(StringUtils.isNotBlank(creditContract.getStartFinishimeStr())){
                creditContract.setStartFinishimeStr(creditContract.getStartFinishimeStr()+ " 00:00:00");
            }
            if(StringUtils.isNotBlank(creditContract.getEndFinishTimeStr())){
                creditContract.setEndFinishTimeStr(creditContract.getEndFinishTimeStr() + " 23:59:59");
            }
            if(CreditYesOrNoEnum.YES.toName().equalsIgnoreCase(creditContract.getSignStatus())){//已签约：非测试商户且有合同,学帅说 未归类属于未签约
                List<String> merchantClassifyList = new ArrayList<String>();
                merchantClassifyList.add(MerchantClassifyEnum.FINANCE.getCode());
                merchantClassifyList.add(MerchantClassifyEnum.NON_FINANCE.getCode());
                merchantClassifyList.add(MerchantClassifyEnum.JUSTICE_DEPARTMENT.getCode());
                merchantClassifyList.add(MerchantClassifyEnum.OTHER.getCode());
                creditContract.setMerchantClassifyList(merchantClassifyList);
            }else if(CreditYesOrNoEnum.NO.toName().equalsIgnoreCase(creditContract.getSignStatus())){
                List<String> merchantClassifyList = new ArrayList<String>();
                merchantClassifyList.add(MerchantClassifyEnum.TEST.getCode());
                merchantClassifyList.add(MerchantClassifyEnum.WAIT.getCode());
                creditContract.setMerchantClassifyList(merchantClassifyList);
            }
			list = enterpriseContractService.selectEnterpContByParam(creditContract);
			for (CreditContract enterpriseContract : list) {
				enterpriseContract.setContractStatus(ContractStatusEnum.enumValueOf(enterpriseContract.getContractStatus()).toDescription());
				enterpriseContract.setContractSource(null == enterpriseContract.getContractSource()? "" : CreditContractSourceEnum.valueOf(enterpriseContract.getContractSource()).toDescription());
				enterpriseContract.setContractType(CreditContractTypeEnum.enumValueOf(enterpriseContract.getContractType()).toDescription());
			}
			count = enterpriseContractService.selectEnterpContCountByParam(creditContract);
			
			resultMap.put("rows", list);
			resultMap.put("total", count);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditContract>());
			resultMap.put("total", 0);
		}
		
		return resultMap;
		
	}
	
	/**
	 * 查询产品名称和产品表的主键ID
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryEnterpriseProduct4Contract.do")
	public Map<String, Object> queryEnterpriseProduct4Contract(@RequestParam Map<String, Object> map) {
		Map<String, Object> result = new HashMap<String, Object>();
		List<TextValuePairs> list = new ArrayList<TextValuePairs>();
		ProductQueryParam productQryPrm = new ProductQueryParam();
		String vipMonitorFlag=(String)map.get("vipMonitorFlag");
		if(StringUtil.isNotBlank(vipMonitorFlag)) {
			productQryPrm.setVipMonitorFlag(vipMonitorFlag);
		}
		List<String> typeList = new ArrayList<String>();
		typeList.add(CreditProductSortEnum.CREDIT_SERVICE.toName());
		typeList.add(CreditProductSortEnum.DATA_SERVICE.toName());
		typeList.add(CreditProductSortEnum.REPORT_SERVICE.toName());
		typeList.add(CreditProductSortEnum.SPECIAL_SERVICE.toName());
		for(String type : typeList) {
			productQryPrm.setProductStatus(CreditOpenStatusEnum.OPEN.toName());
			productQryPrm.setChargeStatus(CreditProductChargeStatusEnum.NOTFREE.toName());
			productQryPrm.setProductSort(type);
			List<CreditProduct> productList = creditProductService.queryProductListByPrm(productQryPrm);
			if(CreditProductSortEnum.CREDIT_SERVICE.toName().equals(type)){
				ProductToBuyShow4Common show = new ProductToBuyShow4Common();
				Map<String,ProductShow4Common> productShowMap = show.getProductMap();
				for (CreditProduct product : productList) {
					String productCode = product.getProductCode();
					ProductShow4Common productShow = productShowMap.get(productCode);
					if (productShow != null) {
						productShow.setShow(true);
//						productShow.setShowName(product.getProductName());
						if(StringUtils.isNotBlank(product.getInnerFlag()) && CreditYesOrNoEnum.YES.toName().equalsIgnoreCase(product.getInnerFlag())){
							productShow.setProductName(product.getProductName()+product.getSuffixName());
						}else{
							productShow.setProductName(product.getProductName());
						}
						productShow.setProductId(product.getProductId());
					}
				}
				result.put(type, show.getMenuMap());
			}else{
				for (CreditProduct product : productList) {
					if(StringUtils.isNotBlank(product.getInnerFlag()) && CreditYesOrNoEnum.YES.toName().equalsIgnoreCase(product.getInnerFlag())){
						product.setProductName(product.getProductName()+product.getSuffixName());
					}else{
						product.setProductName(product.getProductName());
					}
				}
				result.put(type,productList);
			}
		}
		result.put("queryEnterpriseProdList", list);
		return result;
	}
	
	/**
	 * 查询产品名称和产品表的主键ID
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryEnterpriseProduct.do")
	public Map<String, Object> queryProduct(@RequestParam Map<String, Object> map) {
		Map<String, Object> result = new HashMap<String, Object>();
		List<TextValuePairs> list = new ArrayList<TextValuePairs>();
		CreditProduct cp = new CreditProduct();
		String vipMonitorFlag=(String)map.get("vipMonitorFlag");
		if(StringUtil.isNotBlank(vipMonitorFlag)) {
			cp.setVipMonitorFlag(vipMonitorFlag);
		}
		cp.setProductStatus(CreditProductStatusEnum.CREDIT_ROSTER_OPEN.toName());
		cp.setProductType(CreditProductTypeEnum.ENTERPRISE.toName());//企业征信产品
		List<CreditProduct> productList = creditProductService.queryEnterpriseProduct(cp);
		for (CreditProduct creditProduct : productList) {
			TextValuePairs TextValuePairs = new TextValuePairs(creditProduct.getProductName(),creditProduct.getProductId().toString());
			list.add(TextValuePairs);
		}
		
		result.put("queryEnterpriseProdList", list);
		return result;
	}
	
	/**
	 * 从合同状态枚举类中获取状态列表
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("qryEnterpContrStatusInEnum.do")
	public Map<String, Object> queryContractStatusInEnum(@RequestParam Map<String, Object> map) {
		Map<String, Object> result = new HashMap<String, Object>();
		List<TextValuePairs> list = new ArrayList<TextValuePairs>();
		for(ContractStatusEnum status : ContractStatusEnum.values()){
			if(null == status.toName() || "NULL".equals(status.toName()) ||
					ContractStatusEnum.NOCONFIRM.toName().equals(status.toName()) || ContractStatusEnum.CANCEL_AUDIT.toName().equals(status.toName()) ||
					ContractStatusEnum.CANCEL.toName().equals(status.toName()) || ContractStatusEnum.CLOSE.toName().equals(status.toName()) ||
					ContractStatusEnum.MERCHANT_NOPASS.toName().equals(status.toName()) || ContractStatusEnum.SUSPEND.toName().equalsIgnoreCase(status.toName()) ||
					ContractStatusEnum.TERMINATE_AUDIT.toName().equalsIgnoreCase(status.toName())
					){
				continue;
			}else{
				TextValuePairs pairs = new TextValuePairs(status.toDescription(), status.toName());
				list.add(pairs);
			}
		}
		result.put("enterpContrStatusList", list);
		return result;
	}
	
	/**
	 * 创建企业征信的合同
	 * @param map 特殊传参
	 * @param creditContract 合同实体类
	 * @param creditMerchant 征信商户实体类
	 * @param user 当前用户
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doCreateEnterpContract.do")
	public Map<String, Object> doCreateEnterpContract(@RequestParam Map<String, Object> map, CreditContract creditContract, 
			CreditMerchant creditMerchant, String user, EnterpriseProductItemSkuModel enterpriseProductItemSkuModel) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "创建征信产品合同成功");
		
		/*获取登录人名称*/
		String userName = null;
		try {
			LOGGER.error("user : " + GsonUtil.getInstance().toJson(user));
			userName = getLoginRealName(user);
		} catch (Exception e1) {
			LOGGER.error(e1);
			userName = "error";
		}
		
		/*设置合同表的登录人、修改人和商户关系表的创建人 为登录人名称*/
		creditContract.setCreator(userName);
		creditContract.setModifier(userName);
		creditContract.setModifiedDate(new Date());
		creditMerchant.setCreator(userName);
		creditContract.setCreatedDate(new Date());
		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		LOGGER.error("map before parse: " + GsonUtil.getInstance().toJson(map));
		LOGGER.error("creditContract before parse: " + GsonUtil.getInstance().toJson(creditContract));
		LOGGER.error("enterpriseProductItemSkuModel before parse: " + GsonUtil.getInstance().toJson(enterpriseProductItemSkuModel));
		try {
			boolean verifyResult = notNullVerification(creditContract, creditMerchant);
			if (!verifyResult) {
				resultMap.put("success", false);
				resultMap.put("message", "带*的输入框全为必填项！");
				return resultMap;
			}
			creditContract.setStartTime(df.parse(creditContract.getStartDateTimeStr()));
			creditContract.setFinishTime(df.parse(creditContract.getFinishDateTimeStr()));
			LOGGER.error("creditContract after parse: " + GsonUtil.getInstance().toJson(creditContract));
		} catch (ParseException e1) {
			LOGGER.error("参数格式化异常, " + e1);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
		}
		
		int contractId = 0;
		try {
			
			//将vip的计费策略合到一个list中
			if(enterpriseProductItemSkuModel.getEnterprProdItemSkuList()!=null){
				if(enterpriseProductItemSkuModel.getEnterprVIPProdItemSkuList()!=null){
					enterpriseProductItemSkuModel.getEnterprProdItemSkuList().addAll(enterpriseProductItemSkuModel.getEnterprVIPProdItemSkuList());
				}
			}else{
				enterpriseProductItemSkuModel.setEnterprProdItemSkuList(enterpriseProductItemSkuModel.getEnterprVIPProdItemSkuList());
			}

			contractId = enterpriseContractService.createEnterpContract(creditContract, creditMerchant, enterpriseProductItemSkuModel);
			resultMap.put("contractId", contractId);
		} catch (Exception e) {
			LOGGER.error("创建合同异常, ", e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
			return resultMap;
		}
		if (contractId == 0) {
			resultMap.put("success", false);
			resultMap.put("message", "创建征信产品合同失败");
		}
		return resultMap;
	}
	
	/**
	 * 创建、修改合同时的校验方法
	 * @param creditContract
	 * @param creditMerchant
	 * @return
	 */
	public boolean notNullVerification(CreditContract creditContract, CreditMerchant creditMerchant) {
		
		if(StringUtils.isBlank(creditContract.getMerchantNo())){
			return false;
		}
		if(StringUtils.isBlank(creditContract.getMerchantName())){
			return false;
		}
		if(StringUtils.isBlank(creditContract.getContractNo())){
			return false;
		}
		if(StringUtils.isBlank(creditContract.getContractVersion())){
			return false;
		}
		if(StringUtils.isBlank(creditContract.getSalesManager())){
			return false;
		}
		if(StringUtils.isBlank(creditContract.getStartDateTimeStr())){
			return false;
		}
		if(StringUtils.isBlank(creditContract.getFinishDateTimeStr())){
			return false;
		}
		if(null == creditContract.getPurchaseType()){
			return false;
		}
		
		return true;
	}
	
	/**
	 * 校验商户号并根据商户号自动获取商户名称
	 * @param map 传特殊参数用
	 * @param merchantNo 商户号
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doValidMerchanInStatusType.do")
	public Map<String, Object> doValidMerchanInStatusType(@RequestParam Map<String, Object> map, String merchantNo){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "查询成功");
		try {
			if(StringUtils.isBlank(map.get("merchantNo").toString())){
				resultMap.put("success", false);
				resultMap.put("message", "系统异常！");
				return resultMap;
			}
			CreditMerchant creditMerchant = new CreditMerchant();
			creditMerchant.setMerchantNo(merchantNo);
			creditMerchant.setMerchantTypeList(Arrays.asList((CreditMerchantTypeEnum.ENTERPRISE.toName()+","+CreditMerchantTypeEnum.ALL.toName()).substring(0).split(",")));
			
			creditMerchant.setMerchantStatus(CreditMerchantStatusEnum.OPEN.toName());
			List<CreditMerchant> mhList = creditMerchantService.queryMerchantListByParam(creditMerchant);
			if(CollectionUtils.isEmpty(mhList) || mhList.get(0).getMerchantType().equals(CreditTypeEnum.PERSON.toName())){
				resultMap.put("success", false);
				resultMap.put("message", "该商户不是可用的企业征信商户");
			}else if(StringUtils.isBlank(mhList.get(0).getAuditStatus())){
				resultMap.put("success", false);
				resultMap.put("message", "该商户尚未被业务审核通过");
			}else if(!mhList.get(0).getAuditStatus().equals(MerchantAuditEnum.PASS_BUSINESS.getCode())){
				resultMap.put("success", false);
				resultMap.put("message", "该商户尚未被业务审核通过");
			}else{
				Integer merchantId=mhList.get(0).getMerchantId();
				resultMap.put("merchantName", mhList.get(0).getMerchantName());
				resultMap.put("merchantId", mhList.get(0).getMerchantId());
				resultMap.put("purchaseType",mhList.get(0).getPurchaseType());
				Boolean isVipMonitor=creditMerchantService.isVipMonitorMerchant(merchantId);
				resultMap.put("isVipMonitor",isVipMonitor);
			}
			
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
			return resultMap;
		}
		
		return resultMap;
	} 
	
	
	/**
	 * 下载合同文件
	 * @author wyhaozhihong
	 * @param contractId
	 * @return
	 */
	@RequestMapping("/downloadEnterpContract.do")
	@ResponseBody
	public UploadFile downloadEnterpContract(String contractId) {

		UploadFile uploadfile = new UploadFile();
		
		try {
			CreditContract creditContract = creditContractService.selectByPrimaryKey(Integer.valueOf(contractId));
			if (creditContract != null) {
				// 等同于setPath + setName
				uploadfile.setPathname( "credit/pdf/" + creditContract.getContractPath());
			}
		} catch (Exception e) {
			LOGGER.error("下载合同文件失败" + e.getMessage(), e);
		}
		uploadfile.setVersion("2.0");// 上传时用2.0版本。所以下载时也用2.0版本
		uploadfile.setTemp(false);// 上传时，传到临时路径，所以这里也从临时路径下载

		return uploadfile;
	}
	
	/**
	 * 上传合同文件
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@RequestMapping("/doUploadEnterpContract.biz")
	@ResponseBody 
	public UploadObject doUploadEnterpContract(@RequestParam Map<String,Object> map){

		String uploadObjectStr = String.valueOf(map.get("uploadObject"));
		Gson gson = new Gson();//json处理工具随意用什么fastjson、jsonlib、jackson。。。。等

		UploadObject uploadObject = gson.fromJson(uploadObjectStr, UploadObject.class);
		uploadObject.setVersion("2.0");
		String contractId = uploadObject.getParams().get("contractId");
		CreditContract creditContract = creditContractService.selectByPrimaryKey(Integer.valueOf(contractId));
		
		if(creditContract == null) {
			LOGGER.error("合同文件上传失败-合同不存在，合同Id" + contractId);
			return null;
		}

		List<UploadFile> list = uploadObject.getFileList();

		for (UploadFile uploadFile : list) {
			uploadFile.setPath(getContractPdfFilePath(creditContract));//设置上传到NFS的相对路径
			uploadFile.setName(creditContract.getContractId() + StringUtils.trimToEmpty(creditContract.getContractNo()));//设置上传到NFS的名称（不含后缀），具体可以看UploadObject的注释
			uploadFile.setTemp(false);
		}
		return uploadObject;
	}
	
	/**
	 * 上传合同文件回调方法
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@RequestMapping("/doUploadEnterpContractCallback.biz")
	@ResponseBody //将UploadObject对象转换成json
	public Map<String,Object> doUploadEnterpContractCallback(@RequestParam Map<String,Object> map){
		Map<String,Object> result = new HashMap<String,Object>();
		String uploadObjectStr = String.valueOf(map.get("uploadObject"));//拿到上传对象
		Gson gson = new Gson();//json处理工具随意
		UploadObject uploadObject = gson.fromJson(uploadObjectStr, UploadObject.class);//json->object
		List<UploadFile> list = uploadObject.getFileList();//得到上传文件列表
		Map<String, String> param = uploadObject.getParams();
		String contractId = uploadObject.getParams().get("contractId");
		CreditContract creditContract = creditContractService.selectByPrimaryKey(Integer.valueOf(contractId));
		
		UploadFile file = null;
		if (creditContract != null
				&& uploadObject.isSuccess()
				&& list.size() == 1
				&& (file = list.get(0)) != null
				&& creditContractService.updateContractForUpload(param.get("contractId"),
						subtractPdfPath(file.getPathname()))
				) {
			String subtractPdfPath = subtractPdfPath(file.getPathname());
			LOGGER.debug("文件上传成功，文件路径是"+subtractPdfPath);
			result.put("success", true);// 前台可能会做个处理，上传成功跳转等等。demo中页面只是使用了message中的信息
			result.put("filePath", file.getPathname());
			result.put("message", "文件上传成功");
		} else {
			result.put("success", false);
			result.put("message", "文件上传失败");
			if (list.size() == 0 || (file = list.get(0)) == null) {
				result.put("message", "文件为空");
			}
		}
		return result;//返回json串，前台进行处理
	}
	
	/**
	 * 获取合同PDF存放路径
	 * @param contract
	 * @return
	 */
	public String getContractPdfFilePath(CreditContract contract) {
		return "/pdf/" + new SimpleDateFormat("yyyy/MM/dd").format(
				contract.getStartTime())
				+ "/";
	}
	
	/**
	 * 去除PDF文件路径的pdf/以及之前的部分
	 * @param pdfFilePathName
	 * @return
	 */
	public static String subtractPdfPath(String pdfFilePathName) {
		if (StringUtils.isEmpty(pdfFilePathName)) {
			return "";
		}
		String pdf = "pdf/";
		int beginIndex = pdf.length();
		int pdfIndex = pdfFilePathName.indexOf(pdf);
		if(pdfIndex > 0) {
			beginIndex += pdfIndex;
		}
		return pdfFilePathName.substring(beginIndex);
	}
	
	/**
	 * 查询征信产品合同数据、 查询合同内容审核数据  分页
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryEnterpAuditContract.do")
	public Map<String, Object> doQueryEnterpAuditContract(@RequestParam Map<String, Object> map,CreditContract creditContract) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		
		List<CreditContract> list = null;
		int count = 0;
		try {
			if(StringUtils.isNotBlank(creditContract.getEndCreateDateStr())){
				creditContract.setEndCreateDateStr(DateUtil.getAfterDay(creditContract.getEndCreateDateStr()));
			}
			if(StringUtils.isNotBlank(creditContract.getCreatedDateStr())){
				creditContract.setCreatedDateStr(creditContract.getCreatedDateStr() + " 00:00:00");
			}
			if(StringUtils.isNotBlank(creditContract.getEndCreateDateStr())){
				creditContract.setEndCreateDateStr(creditContract.getEndCreateDateStr() + " 23:59:59");
			}
			creditContract.setCreditType(CreditTypeEnum.ENTERPRISE.toName());//仅查询企业征信的合同
            if(CreditYesOrNoEnum.YES.toName().equalsIgnoreCase(creditContract.getSignStatus())){//已签约：非测试商户且有合同,学帅说 未归类属于未签约
                List<String> merchantClassifyList = new ArrayList<String>();
                merchantClassifyList.add(MerchantClassifyEnum.FINANCE.getCode());
                merchantClassifyList.add(MerchantClassifyEnum.NON_FINANCE.getCode());
                merchantClassifyList.add(MerchantClassifyEnum.JUSTICE_DEPARTMENT.getCode());
                merchantClassifyList.add(MerchantClassifyEnum.OTHER.getCode());
                creditContract.setMerchantClassifyList(merchantClassifyList);
            }else if(CreditYesOrNoEnum.NO.toName().equalsIgnoreCase(creditContract.getSignStatus())){
                List<String> merchantClassifyList = new ArrayList<String>();
                merchantClassifyList.add(MerchantClassifyEnum.TEST.getCode());
                merchantClassifyList.add(MerchantClassifyEnum.WAIT.getCode());
                creditContract.setMerchantClassifyList(merchantClassifyList);
            }
			list = creditContractService.selectAuditByParam(creditContract);
			for (CreditContract creditContract2 : list) {
				creditContract2.setContractStatus(ContractStatusEnum.enumValueOf(creditContract2.getContractStatus()).toDescription());
				creditContract2.setContractType(CreditContractTypeEnum.enumValueOf(creditContract2.getContractType()).toDescription());
				creditContract2.setContractSource(CreditContractSourceEnum.valueOf(creditContract2.getContractSource()).toDescription());
			}
			count = creditContractService.selectCountAuditByParam(creditContract);
			
			resultMap.put("rows", list);
			resultMap.put("total", count);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditContract>());
			resultMap.put("total", 0);
		}
		
		return resultMap;
	}
	
	/**
	 * 跳转至合同审核页
	 * @param map
	 * @param contractId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doAuditEnterpContOprate.do")
	public Map<String, Object> doAuditEnterpContOprate(@RequestParam Map<String, Object> map,String contractId) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		/*查询合同信息*/
		CreditContract creditContract = creditContractService.selectByPrimaryKey(Integer.valueOf(contractId));
		creditContract.setContractType(CreditContractTypeEnum.enumValueOf(creditContract.getContractType()).toDescription());
		creditContract.setContractStatus(ContractStatusEnum.enumValueOf(creditContract.getContractStatus()).toDescription());
		creditContract.setCreatedDateStr(df1.format(creditContract.getCreatedDate()));
		creditContract.setAuditTimeStr(creditContract.getAuditTime() == null ? null : df1.format(creditContract.getAuditTime()));
		creditContract.setEnsureTimeStr(creditContract.getEnsureTime() == null ? null : df1.format(creditContract.getEnsureTime()));
		creditContract.setStartDateTimeStr(df.format(creditContract.getStartTime()));
		creditContract.setFinishDateTimeStr(df.format(creditContract.getFinishTime()));
		creditContract.setAdvancePaymentStr(creditContract.getAdvancePayment() == null ? null :new BigDecimal(creditContract.getAdvancePayment()).divide(new BigDecimal("100")).toString());
		resultMap.put("creditContract", creditContract);
		
		/*查询商户信息*/
		CreditMerchant creditMerchant = creditMerchantService.selectByMerchantId(creditContract.getMerchantId());
		creditMerchant.setMerchantResource(CreditMerchantResourceEnum.enumValueOf(creditMerchant.getMerchantResource()).toDescription());
		resultMap.put("creditMerchant", creditMerchant);
		
		return resultMap;
	}
	
	/**
	 * 查询某合同下的征信产品和计费策略信息
	 * @param map
	 * @param creditProductStrategy
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryEnterpProdStrat.do")
	public Map<String, Object> doQueryEnterpProdStrat(@RequestParam Map<String, String> map, CreditProductStrategy creditProductStrategy) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		String strategyIdStr = map.get("strategyIdStr");
		if(StringUtils.isNotBlank(strategyIdStr)){
			creditProductStrategy.setStrategyIds(Arrays.asList(strategyIdStr.substring(1).split("&")));
		}
		try {
			List<CreditProductStrategy> creditProductStrategyList = creditProductStrategyService.selectByParam(creditProductStrategy);
			for (CreditProductStrategy creditProductStrategy2 : creditProductStrategyList) {
				creditProductStrategy2.setChargeType(ChargeTypeEnum.enumValueOf(creditProductStrategy2.getChargeType()).toDescription());
				creditProductStrategy2.setStartTimeStr(sdf.format(creditProductStrategy2.getStartTime()));
				creditProductStrategy2.setFinishTimeStr(sdf.format(creditProductStrategy2.getFinishTime()));

			}
			int creditProductStrategyCount = creditProductStrategyService.selectCountByParam(creditProductStrategy);
			resultMap.put("rows", creditProductStrategyList);
			resultMap.put("total", creditProductStrategyCount);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditProductStrategy>());
			resultMap.put("total", 0);
		}
		
		return resultMap;
	}
	/**
	 * 
	 * @param map
	 * @param user
	 * @param creditContract
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doAuditEnterpContract.do")
	public Map<String, Object> doAuditEnterpContract(@RequestParam Map<String, Object> map, String user,
			CreditContract creditContract) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		String userName = null;
		try {
			//userName是登录名,RealName是中文别名,getLoginRealName()返回的是userName
			userName = getLoginRealName(user);
		} catch (Exception e) {
			LOGGER.error(e);
			userName = "error";
		}
		creditContract.setAuditor(userName);
		creditContract.setAuditTime(new Date());
		creditContract.setModifier(userName);
		creditContract.setModifiedDate(new Date());
		try {
			int count = enterpriseContractService.modifyContractByPrimaryKey(creditContract);
			if(count == 1){
				resultMap.put("success", true);
				resultMap.put("message", "审核成功");
				return resultMap;
			}else{
				resultMap.put("success", false);
				resultMap.put("message", "审核失败");
			}
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "审核异常");
		}
		return resultMap;
	}
	/**
	 * 修改企业征信合同
	 * @param map
	 * @param contractId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doEditEnterpContract.do")
	public Map<String, Object> doEditEnterpContract(@RequestParam Map<String, Object> map,String contractId) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		
		/*查询合同信息*/
		CreditContract creditContract = creditContractService.selectByPrimaryKey(Integer.valueOf(contractId));
		creditContract.setStartDateTimeStr(df.format(creditContract.getStartTime()));
		creditContract.setFinishDateTimeStr(df.format(creditContract.getFinishTime()));
		creditContract.setAdvancePaymentStr(creditContract.getAdvancePayment() == null ? null : new BigDecimal(creditContract.getAdvancePayment()).divide(new BigDecimal("100")).toString());
		resultMap.put("creditContract", creditContract);
		
		/*查询商户信息*/
		CreditMerchant creditMerchant = creditMerchantService.selectByMerchantId(creditContract.getMerchantId());
		resultMap.put("creditMerchant", creditMerchant);
		
		return resultMap;
	}
	
	/**
	 * 查询某合同下定制的计费产品信息
	 * @author wyhaozhihong
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryEnterpHasProdStrat.do")
	public Map<String, Object> doQueryEnterpHasProdStrat(@RequestParam Map<String, Object> map, Integer contractId) {
		Map<String, Object> result = new HashMap<String, Object>();

		List<String> typeList = new ArrayList<String>();
		typeList.add(CreditProductSortEnum.CREDIT_SERVICE.toName());
		typeList.add(CreditProductSortEnum.DATA_SERVICE.toName());
		typeList.add(CreditProductSortEnum.REPORT_SERVICE.toName());
		typeList.add(CreditProductSortEnum.SPECIAL_SERVICE.toName());
		ProductQueryParam productQryPrm = new ProductQueryParam();
		for(String type : typeList) {
			List<EnterpriseProductItemSku> enterprProdItemSkuList = new ArrayList<EnterpriseProductItemSku>();
			List<Integer> productIdList = new ArrayList<Integer>();
			CreditProductStrategy cps = new CreditProductStrategy();
			cps.setContractId(contractId);
			cps.setProductSort(type);
			List<CreditProductStrategy> cpstList = creditProductStrategyService.selectStrategyListByParam(cps);
			for(CreditProductStrategy strategy : cpstList){
				EnterpriseProductItemSku skuInfo = new EnterpriseProductItemSku();
				if(ChargeTypeEnum.SINGLE.toName().equals(strategy.getChargeType())){//单笔
					skuInfo.setSinglePrice(new BigDecimal(strategy.getPrice()).intValue());
					skuInfo.setFreeTimes(null);
				}else if(ChargeTypeEnum.CUSTOM.toName().equals(strategy.getChargeType())){//按次
					skuInfo.setAmount(0L);
					skuInfo.setPacketCount(0);
					skuInfo.setCustomPrice(new BigDecimal(strategy.getPrice()).intValue());//按次计费先将按次价格存到amount中，同时对应的charge_type=CUSTOM自定制
					skuInfo.setUpperLimit(strategy.getUpperLimit());
				}else if(ChargeTypeEnum.PACKAGE.toName().equals(strategy.getChargeType())){//包量
					skuInfo.setAmount(new BigDecimal(strategy.getAmount()).longValue());//
					skuInfo.setPacketCount(strategy.getPacketCount());//new BigDecimal(creditContract.getAdvancePayment()).divide(new BigDecimal("100")).toString()
					skuInfo.setCustomPrice(0);
				}
				skuInfo.setCompletionPriceType(strategy.getRemarks());
				skuInfo.setChargeType(strategy.getChargeType());
				skuInfo.setFreeTimes(strategy.getFreeTimes());
				skuInfo.setProductId(strategy.getProductId());
				if(StringUtils.isNotBlank(strategy.getInnerFlag()) && CreditYesOrNoEnum.YES.toName().equalsIgnoreCase(strategy.getInnerFlag())){
					skuInfo.setProductName(strategy.getProductName()+strategy.getSuffixName()+ ":" + strategy.getUnitDesc());
				}else{
					skuInfo.setProductName(strategy.getProductName()+ ":" + strategy.getUnitDesc());
				}
				skuInfo.setStrategyId(strategy.getStrategyId());
				skuInfo.setProductCode(strategy.getProductCode());
				enterprProdItemSkuList.add(skuInfo);
				productIdList.add(skuInfo.getProductId());
			}
			productQryPrm.setProductStatus(CreditOpenStatusEnum.OPEN.toName());
			productQryPrm.setChargeStatus(CreditProductChargeStatusEnum.NOTFREE.toName());
			productQryPrm.setProductSort(type);
			List<CreditProduct> productList = creditProductService.queryProductListByPrm(productQryPrm);
			for(CreditProduct credProd : productList){
				if( !productIdList.contains(credProd.getProductId())){
					EnterpriseProductItemSku sku = new EnterpriseProductItemSku();
					sku.setProductId(credProd.getProductId());
					sku.setProductCode(credProd.getProductCode());
					if(StringUtils.isNotBlank(credProd.getInnerFlag()) && CreditYesOrNoEnum.YES.toName().equalsIgnoreCase(credProd.getInnerFlag())){
						sku.setProductName(credProd.getProductName()+credProd.getSuffixName());
					}else{
						sku.setProductName(credProd.getProductName());
					}
					enterprProdItemSkuList.add(sku);
				}
			}
			if(CreditProductSortEnum.CREDIT_SERVICE.toName().equals(type)){
				StrategyHasBuyedShow4Common show = new StrategyHasBuyedShow4Common();
				Map<String,StrategyShow4Common> productShowMap = show.getProductMap();
				for(EnterpriseProductItemSku productItem : enterprProdItemSkuList){
					String productCode = productItem.getProductCode();
					StrategyShow4Common itemShow = productShowMap.get(productCode);
					if (itemShow != null) {
						itemShow.setShow(true);
//						itemShow.setShowName(itemShow.getProductName());
						itemShow.setStrategyId(productItem.getStrategyId());
						if(ChargeTypeEnum.SINGLE.toName().equals(productItem.getChargeType())){//单笔
							itemShow.setSinglePrice(productItem.getSinglePrice());
							itemShow.setFreeTimes(null);
						}else if(ChargeTypeEnum.CUSTOM.toName().equals(productItem.getChargeType())){//按次
							itemShow.setAmount(0L);
							itemShow.setPacketCount(0);
							itemShow.setCustomPrice(productItem.getCustomPrice());//按次计费先将按次价格存到amount中，同时对应的charge_type=CUSTOM自定制
							itemShow.setUpperLimit(productItem.getUpperLimit());
						}else if(ChargeTypeEnum.PACKAGE.toName().equals(productItem.getChargeType())){//包量
							itemShow.setAmount(productItem.getAmount());//
							itemShow.setPacketCount(productItem.getPacketCount());//new BigDecimal(creditContract.getAdvancePayment()).divide(new BigDecimal("100")).toString()
							itemShow.setCustomPrice(0);
						}
						itemShow.setCompletionPriceType(productItem.getCompletionPriceType());
						itemShow.setChargeType(productItem.getChargeType());
						itemShow.setFreeTimes(productItem.getFreeTimes());
						itemShow.setProductId(productItem.getProductId());
						itemShow.setProductName(productItem.getProductName());
						itemShow.setStrategyId(productItem.getStrategyId());
						itemShow.setProductCode(productItem.getProductCode());
					}
				}
				result.put(type, show.getMenuMap());
			}else{
				result.put(type,enterprProdItemSkuList);
			}
		}
		return result;
	}
	/**
	 * 查询企业征信合同详情
	 * @param map
	 * @param contractId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryEnterpContractDetail.do")
	public Map<String, Object> doQueryEnterpContractDetail(@RequestParam Map<String, Object> map,String contractId) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
		/*查询合同信息*/
		CreditContract creditContract = creditContractService.selectByPrimaryKey(Integer.valueOf(contractId));
		creditContract.setContractType(CreditContractTypeEnum.enumValueOf(creditContract.getContractType()).toDescription());
		creditContract.setContractStatus(ContractStatusEnum.enumValueOf(creditContract.getContractStatus()).toDescription());
		creditContract.setCreatedDateStr(df1.format(creditContract.getCreatedDate()));
		creditContract.setAuditTimeStr(creditContract.getAuditTime() == null ? null : df1.format(creditContract.getAuditTime()));
		creditContract.setEnsureTimeStr(creditContract.getEnsureTime() == null ? null : df1.format(creditContract.getEnsureTime()));
		creditContract.setStartDateTimeStr(df.format(creditContract.getStartTime()));
		creditContract.setFinishDateTimeStr(df.format(creditContract.getFinishTime()));
		creditContract.setAdvancePaymentStr(creditContract.getAdvancePayment() == null ? null :new BigDecimal(creditContract.getAdvancePayment()).divide(new BigDecimal("100")).toString());
		resultMap.put("creditContract", creditContract);
		
		/*查询商户信息*/
		CreditMerchant creditMerchant = creditMerchantService.selectByMerchantId(creditContract.getMerchantId());
		creditMerchant.setMerchantResource(CreditMerchantResourceEnum.enumValueOf(creditMerchant.getMerchantResource()).toDescription());
		resultMap.put("creditMerchant", creditMerchant);
		
		return resultMap;
	}

    /**
     * 下载 合同
     * @param params
     * @param creditContract
     * @return
     */
    @RequestMapping("downCreditEnterContract.download")
    @ResponseBody
    public UploadFile downCreditEnterContract(@RequestParam Map<String, Object> params, CreditContract creditContract) {
        String[] titles = { "合同编号","商户号", "商户名称","产品名称","生效时间","失效时间","合同状态","合同类型","付费模式","创建人","创建时间"};
        String[] properties = { "contractNo", "merchantNo", "merchantName","productName","startDateTimeStr","finishDateTimeStr","contractStatus","contractSource","purchaseTypeStr","creator","createdDateStr"};
        String originalName = "合同查询导出结果";
        String date = (new SimpleDateFormat("yyyyMMddhhmmssSSS")).format(new Date());
        originalName = originalName+"_"+date;
        List<CreditContract> list = new ArrayList<CreditContract>();
        creditContract.setCreditType(CreditTypeEnum.ENTERPRISE.toName());//仅查询企业征信合同相关数据
        if(StringUtils.isNotBlank(creditContract.getStartCreateDateStr())){
            creditContract.setCreatedDateStr(creditContract.getStartCreateDateStr() + " 00:00:00");
        }
        if(StringUtils.isNotBlank(creditContract.getEndCreateDateStr())){
            creditContract.setEndCreateDateStr(creditContract.getEndCreateDateStr() + " 23:59:59");
        }
        if(CreditYesOrNoEnum.YES.toName().equalsIgnoreCase(creditContract.getSignStatus())){//已签约：非测试商户且有合同,学帅说 未归类属于未签约
            List<String> merchantClassifyList = new ArrayList<String>();
            merchantClassifyList.add(MerchantClassifyEnum.FINANCE.getCode());
            merchantClassifyList.add(MerchantClassifyEnum.NON_FINANCE.getCode());
            merchantClassifyList.add(MerchantClassifyEnum.JUSTICE_DEPARTMENT.getCode());
            merchantClassifyList.add(MerchantClassifyEnum.OTHER.getCode());
            creditContract.setMerchantClassifyList(merchantClassifyList);
        }else if(CreditYesOrNoEnum.NO.toName().equalsIgnoreCase(creditContract.getSignStatus())){
            List<String> merchantClassifyList = new ArrayList<String>();
            merchantClassifyList.add(MerchantClassifyEnum.TEST.getCode());
            merchantClassifyList.add(MerchantClassifyEnum.WAIT.getCode());
            creditContract.setMerchantClassifyList(merchantClassifyList);
        }
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        list = enterpriseContractService.selectEnterpContByParam(creditContract);
        for (CreditContract enterpriseContract : list) {
            enterpriseContract.setContractStatus(ContractStatusEnum.enumValueOf(enterpriseContract.getContractStatus()).toDescription());
            enterpriseContract.setContractSource(null == enterpriseContract.getContractSource()? "" : CreditContractSourceEnum.valueOf(enterpriseContract.getContractSource()).toDescription());
            enterpriseContract.setContractType(CreditContractTypeEnum.enumValueOf(enterpriseContract.getContractType()).toDescription());
            enterpriseContract.setPurchaseTypeStr(enterpriseContract.getPurchaseType().getName());
            enterpriseContract.setStartDateTimeStr(df.format(enterpriseContract.getStartTime()));
            enterpriseContract.setFinishDateTimeStr(df.format(enterpriseContract.getFinishTime()));
            enterpriseContract.setCreatedDateStr(df1.format(enterpriseContract.getCreatedDate()));
        }
        return enterpriseContractService.downCreditEnterContract(list, titles, properties, originalName);
    }
	
}
