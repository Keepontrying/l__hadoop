package com.wangyin.boss.credit.enterprise.controller;

import com.wangyin.boss.credit.admin.entity.CreditChnProdIns;
import com.wangyin.boss.credit.enterprise.beans.CreditChannelProdInsQueryParam;
import com.wangyin.boss.credit.enterprise.entity.CreditChannelProdIns;
import com.wangyin.boss.credit.enterprise.entity.CreditChnMerchantInsRel;
import com.wangyin.boss.credit.enterprise.entity.CreditChnProd;
import com.wangyin.boss.credit.enterprise.service.CreditMerchantChannelService;
import com.wangyin.boss.credit.enterprise.service.DataProductService;
import com.wangyin.operation.common.beans.PageResult;
import com.wangyin.operation.common.enums.ResponseMessage;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Controller
@RequestMapping("/credit/dataProduct")
public class DataProductController {

    private static final Logger logger = LoggerFactory.getLogger(DataProductController.class);

    @Autowired
    DataProductService dataProductService;

    @Autowired
    CreditMerchantChannelService creditMerchantChannelService;


    /**
     * 查询所有数据产品
     * @param prodInsQueryParam
     * @return
     */
    @RequestMapping("/getChannelProdList.do")
    @ResponseBody
    public PageResult<CreditChnProd> getChannelProdList(CreditChnProd prodInsQueryParam) {
        PageResult<CreditChnProd> pageResult = new PageResult<>();
        try {
            List<CreditChnProd> creditChnProdList = creditMerchantChannelService.queryAllChannelProdList(prodInsQueryParam);
            pageResult.setSuccess(true);
            pageResult.setRows(creditChnProdList);
            pageResult.setMessage(ResponseMessage.SUCCESS.getDesc());
        } catch (Exception e) {
            logger.error(e.getMessage());
            pageResult.setSuccess(false);
            pageResult.setMessage(e.getMessage());
        }

        return pageResult;
    }

    /**
     * 查询数据产品对应渠道
     * @param prodInsQueryParam
     * @return
     */
    @RequestMapping("/getChannelList.do")
    @ResponseBody
    public PageResult<CreditChannelProdIns> getChannelList(CreditChnMerchantInsRel creditChnMerchantInsRel) {
        PageResult<CreditChannelProdIns> pageResult = new PageResult<>();
        try {
            if (StringUtils.isEmpty(creditChnMerchantInsRel.getProductCode())) {
                pageResult.setSuccess(false);
                pageResult.setMessage(ResponseMessage.PARAM_IS_REQUIRED.getDesc());
                return pageResult;
            }
            Set<CreditChannelProdIns> creditChnProdList = creditMerchantChannelService.queryChannelsBy(creditChnMerchantInsRel);
            pageResult.setSuccess(true);
            pageResult.setRows(new ArrayList<>(creditChnProdList));
            pageResult.setMessage(ResponseMessage.SUCCESS.getDesc());
        } catch (Exception e) {
            logger.error(e.getMessage());
            pageResult.setSuccess(false);
            pageResult.setMessage(e.getMessage());
        }

        return pageResult;
    }
}
