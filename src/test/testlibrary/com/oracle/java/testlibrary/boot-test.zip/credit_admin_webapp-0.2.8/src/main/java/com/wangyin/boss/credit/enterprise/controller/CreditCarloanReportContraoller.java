package com.wangyin.boss.credit.enterprise.controller;

import com.jd.jr.boss.credit.facade.authen.beans.param.CarLoanReportQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.MiniProjectQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.MiniSampleQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.DueStatusParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.controller.BaseController;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditReportQueryCarloan;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniProject;
import com.wangyin.boss.credit.admin.enums.CreditProjectProgressEnum;
import com.wangyin.boss.credit.admin.utils.DateUtil;
import com.wangyin.boss.credit.enterprise.service.CreditCarloanReportService;
import com.wangyin.boss.credit.enterprise.service.CreditMiniService;
import com.wangyin.operation.utils.GsonUtil;
import oracle.sql.DATE;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Description: 车贷定制报告控制类
 * User: yangjinlin@jd.com
 * Date: 2018/6/26 14:35
 * Version: 1.0
 */
@Controller
@RequestMapping("/carloan")
public class CreditCarloanReportContraoller extends BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(EnterpMiniController.class);

    @Autowired
    private CreditCarloanReportService creditCarloanReportService;
    /**
     * 查询车贷报告 分页
     * @param map
     * @param queryParam
     * @return
     */
    @ResponseBody
    @RequestMapping("doQueryCarloanReport.do")
    public Map<String, Object> doQueryCarloanReport(@RequestParam Map<String, String> map, CarLoanReportQueryParam queryParam) {
        Map<String, Object> resultMap = new HashMap<String, Object>();
        try {
            if (StringUtils.isNotBlank(queryParam.getStartCreateDateStr())) {
                queryParam.setStartCreateDateStr(queryParam.getStartCreateDateStr() + " 00:00:00");
            }
            if (StringUtils.isNotBlank(queryParam.getEndCreateDateStr())) {
                queryParam.setEndCreateDateStr(queryParam.getEndCreateDateStr() + " 23:59:59");
            }
            List<CreditReportQueryCarloan> resultList = new ArrayList<CreditReportQueryCarloan>();
            Long count = 0L;
            CreditPage<CreditReportQueryCarloan> resultPage = creditCarloanReportService.selectCarloanReportPageByParam(queryParam);
            if(null !=resultPage && resultPage.isSuccess() && CollectionUtils.isNotEmpty(resultPage.getRows())){
                resultList = resultPage.getRows();
                count = resultPage.getTotal();
            }
            resultMap.put("rows", resultList);
            resultMap.put("total", count);
        } catch (Exception e) {
            LOGGER.error("doQueryCarloanReport exception, {}", e);
            resultMap.put("rows", new ArrayList<CreditReportQueryCarloan>());
            resultMap.put("total", 0);
        }
        return resultMap;
    }

    /**
     * 再次发起样本详情查询并落地
     * @param map
     * @param user
     * @param queryParam
     * @return
     */
    @ResponseBody
    @RequestMapping("/doCarloanReportPdfSupplyHandle.do")
    public Map<String, Object> doCarloanReportPdfSupplyHandle(@RequestParam Map<String, String> map, String user,
                                                              CarLoanReportQueryParam queryParam) {
        Map<String,Object> resultMap = new HashMap<String, Object>();
        resultMap.put("success", false);
        resultMap.put("message", "操作失败，请稍后操作!");
        String operaUserName = "";
        try {
            operaUserName = getLoginRealName(user);
        } catch (Exception e1) {
            LOGGER.error("getLoginRealName error"+ e1);
            operaUserName = "error";
        }
        if(null == queryParam.getId()){
            resultMap.put("success", false);
            resultMap.put("message", "入参有误，请稍后操作!");
            return resultMap;
        }
        try {

            CreditPage<CreditReportQueryCarloan> resultPage = creditCarloanReportService.selectCarloanReportPageByParam(queryParam);
            if(null !=resultPage && resultPage.isSuccess() && CollectionUtils.isNotEmpty(resultPage.getRows())){
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String nowDateStr = format.format(DateUtil.getDaysBeforeDay(new Date(), -2));//真实缓存数据为10天，故此处将比对的系统当前日期往前提2天，方便时间差的数据补充
                if(null != resultPage.getRows().get(0) && null!= resultPage.getRows().get(0).getValidDate() &&
                        DateUtil.datesReduceReturnSeconds(format.format(resultPage.getRows().get(0).getValidDate()), nowDateStr) <0 ) {//到期日小于当前系统日期，则r2m数据已失效，不可再次做处理
                    LOGGER.info("doCarloanReportPdfSupplyHandle failed，reason: 缓存已超过9天，不可进行此操作。");
                    resultMap.put("success", false);
                    resultMap.put("message", "缓存已超过9天，不可进行此操作!");
                    return resultMap;
                }
                LOGGER.error("doCarloanReportPdfSupplyHandle requestParam, "+ GsonUtil.getInstance().toJson(queryParam));
                CreditResponseData<String> responseData = creditCarloanReportService.carloanReportPdfSupplyHandle(queryParam);
                LOGGER.error("doCarloanReportPdfSupplyHandle responseData, "+ GsonUtil.getInstance().toJson(responseData));
                if(responseData.isSuccess()){
                    resultMap.put("success", true);
                    resultMap.put("message", "操作成功");
                }else{
                    resultMap.put("success", false);
                    resultMap.put("message", "操作失败，请稍后操作!");
                }
            }else{
                LOGGER.info("doCarloanReportPdfSupplyHandle failed，reason: this record is not exsit.");
                resultMap.put("success", false);
                resultMap.put("message", "该记录不存在，不可进行此操作!");
                return resultMap;
            }


        } catch (Exception e) {
            LOGGER.error("doCarloanReportPdfSupplyHandle error,{}", e);
            resultMap.put("success", false);
            resultMap.put("message", "操作异常，请稍后重试");
        }
        return resultMap;

    }


}
