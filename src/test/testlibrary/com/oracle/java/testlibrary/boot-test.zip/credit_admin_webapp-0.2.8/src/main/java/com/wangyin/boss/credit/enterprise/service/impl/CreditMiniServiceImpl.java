package com.wangyin.boss.credit.enterprise.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.facade.authen.api.CreditDiligenceFacade;
import com.jd.jr.boss.credit.facade.authen.api.CreditQueryBatchFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.MiniProjectQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.MiniSampleQueryParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.DueStatusParam;
import com.jd.jr.boss.credit.facade.authen.beans.param.mini.MiniCommAreaComplQueryParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditRequestParam;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniCommonArea;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniProject;
import com.wangyin.boss.credit.admin.entity.mini.CreditMiniSampleBase;
import com.wangyin.boss.credit.enterprise.service.CreditMiniService;

/** 
* @desciption : 征信Mini尽调 service业务逻辑实现类
* @author : yangjinlin@jd.com
* @date ：2017年10月22日 下午4:35:22 
* @version 1.0 
* @return  */
@Service
public class CreditMiniServiceImpl implements CreditMiniService {

	@Resource
	private CreditQueryBatchFacade creditQueryBatchFacade;
	@Resource
	private CreditDiligenceFacade creditDiligenceFacade;
	
	@Override
	public CreditPage<CreditMiniProject> selectMiniProjectPageByParam(MiniProjectQueryParam queryParam) {
		return creditQueryBatchFacade.queryMiniProject(queryParam);
	}

	@Override
	public CreditPage<CreditMiniSampleBase> selectMiniSamplePageByParam(MiniSampleQueryParam queryParam) {
		return creditQueryBatchFacade.queryMiniSample(queryParam);
	}

	@Override
	public List<CreditMiniCommonArea> queryValidMiniAreaList(MiniCommAreaComplQueryParam queryParam) {
		return creditQueryBatchFacade.queryValidMiniAreaList(queryParam);
	}

	@Override
	public CreditResponseData<String> doCompleSampleDetails(CreditRequestParam<List<DueStatusParam>> requestParam) {
		return creditDiligenceFacade.doSimple(requestParam);
	}

}
