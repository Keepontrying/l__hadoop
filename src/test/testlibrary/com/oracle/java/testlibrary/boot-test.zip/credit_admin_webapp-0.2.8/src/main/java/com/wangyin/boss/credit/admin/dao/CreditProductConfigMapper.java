package com.wangyin.boss.credit.admin.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditProductConfig;

/** 
* @desciption : 产品服务配置 mapper映射类
* @author : yangjinlin@jd.com
* @date ：2016年8月29日 下午5:32:58 
* @version 1.0 
* @return  */

@SqlMapper
@Component
public interface CreditProductConfigMapper {

	/**
     * 根据查询条件查询  产品服务配置 分页
     * @param creditProductConfig
     * @return
     */
	List<CreditProductConfig> selectCreProdConfByPams(CreditProductConfig creditProductConfig);
	/**
	 * 根据查询条件查询  产品服务配置
	 * @param creditProductConfig
	 * @return
	 */
	List<CreditProductConfig> selectCreProdConfListByPams(CreditProductConfig creditProductConfig);
	
	/**
	 * 根据查询条件查询  产品服务配置  总条数
	 * @param creditProductConfig
	 * @return
	 */
	int selectCountByParam(CreditProductConfig creditProductConfig);

	/**
	 * 根据产品id集合 更新或新增 产品服务配置 信息
	 * @param productIds
	 */
	int updateCreProdConfByProdIds(List<Integer> productIds);

	/**
	 * 根据产品id、商户Id 更新或新增产品服务配置 信息
	 * @param creditProductConfig
	 * @return
	 */
	int updateOrAddCreProdConfByProdMerchId(CreditProductConfig creditProductConfig);

	/**
	 * 根据产品id、商户Id 查询 产品服务配置 信息
	 * @param params
	 * @return
	 */
	List<CreditProductConfig> selectCredProdConfByProdMercId(Map<String, Object> params);

	/**
	 * 根据产品id、商户Id 更新 产品服务配置 信息
	 * @param credProdConf
	 * @return
	 */
	int updateCreProdConfByProdMerchId(CreditProductConfig credProdConf);

	/**
	 * 根据产品id、商户Id 新增 产品服务配置 信息
	 * @param credProdConf
	 * @return
	 */
	int addCreProdConfByProdMerchId(CreditProductConfig credProdConf);

	/**
	 * 根据产品服务配置主键configId 查询 产品服务配置 信息
	 * @param configId
	 * @return
	 */
	CreditProductConfig selectCredProdConfByConfId(Integer configId);

	/**
	 * 根据产品服务配置表的主键configId 更新 产品服务配置表的状态
	 * @param creditProductConfig
	 * @return
	 */
	int updateCredProdConfByConfId(CreditProductConfig creditProductConfig);
	/**
	 * 根据产品服务配置表主键 productId，merchantId删除config表数据。
	 * @param creditProductConfig
	 * @return
	 * @throws Exception
	 */
	int deleteCredProdConfByProMerId(CreditProductConfig creditProductConfig);
	
}
