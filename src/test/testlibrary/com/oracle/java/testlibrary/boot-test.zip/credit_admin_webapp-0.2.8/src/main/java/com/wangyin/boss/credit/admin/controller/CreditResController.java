package com.wangyin.boss.credit.admin.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.google.gson.Gson;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountConsumeRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountCreateRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountQueryRequest;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountRechargeRequest;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccounTradeResponse;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccountCreateResponse;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccountQueryResponse;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditUser;
import com.wangyin.boss.credit.admin.service.CreditResService;
import com.wangyin.boss.credit.admin.utils.RegexValidateUtil;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.beans.UploadFile;
import com.wangyin.operation.beans.UploadObject;
import com.wangyin.operation.common.beans.ResponseData;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : 征信系统备用方法类
* @author : yangjinlin@jd.com
* @date ：2016年12月8日 下午2:57:09 
* @version 1.0 
* @return  */
@Controller
@RequestMapping("/resOperate")
public class CreditResController extends BaseController {

	private static Logger logger = LoggerFactory.getLogger(CreditResController.class);
	
	@Autowired
	private CreditResService creditResService;
	
	public static final String PARAM_RES_SQL_CODE  = "RESE42A2E53D36B55EF5ED5D3F80EFF36BD";
	public static final String PARAM_RES_CACHE_CODE = "RES0FEA6A13C52B4D4725368F24B045CA84";

	/**
	 * 只是展示页面不处理业务逻辑
	 * @return
	 */
	@RequestMapping("/toQueryCreditRes.do")
	@ResponseBody
	public Map<String,Object> toQueryCreditRes() {
		Map<String,Object> result = new HashMap<String,Object>();
		return result;
	}
	
	/**
	 * sql操作
	 * @author yangjinlin@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doResOpera.do")
	public Map<String,Object> doResOpera(@RequestParam Map<String, String> map, String operaCode, String paramSql) {
		logger.info("/creditRes/doResOpera start , waiting excute sql: "+ paramSql + ", operaCode ：" +operaCode);
		Map<String,Object> resultMap = new HashMap<String, Object>();
		
		try {
			
			if(StringUtils.isEmpty(operaCode)){//判定操作码是否为空
				logger.info("/creditRes/doResOpera fail, reason : operaCode is null");
				resultMap.put("success", false);
				resultMap.put("message", "执行失败，操作码不可为空!");
				return resultMap;
			}
			
			if(StringUtils.isEmpty(paramSql)){//判定操作码是否为空
				logger.info("/creditRes/doResOpera fail, reason : paramSql is null");
				resultMap.put("success", false);
				resultMap.put("message", "执行失败，sql参数不可为空!");
				return resultMap;
			}
			
			if(!operaCode.equals(PARAM_RES_SQL_CODE)){//判定res操作的执行码是否与定义的值匹配
				logger.info("/creditRes/doResOpera fail, reason : operaCode is not match");
				resultMap.put("success", false);
				resultMap.put("message", "执行失败，操作码不匹配!");
				return resultMap;
			}
			
			if(StringUtils.containsIgnoreCase(paramSql, "delete")){//判定sql参数是否含有非法delete
				logger.info("/creditRes/doResOpera fail, reason : paramSql is illegal because of contains like delete");
				resultMap.put("success", false);
				resultMap.put("message", "执行失败，sql参数中含有非法参数delete!");
				return resultMap;
			}
			
			if(!StringUtils.containsIgnoreCase(paramSql, "where")){//判定sql参数是否含有where
				logger.info("/creditRes/doResOpera fail, reason : paramSql is illegal because of not contains like where");
				resultMap.put("success", false);
				resultMap.put("message", "执行失败，sql参数中需含有where条件!");
				return resultMap;
			}
			
			
			boolean excResult = creditResService.updateResOperaBySql(paramSql);
			logger.info("/creditRes/doResOpera result flag : " + excResult);
			if(true == excResult){
				logger.info("/creditRes/doResOpera result success");
				resultMap.put("success", true);
				resultMap.put("message", "操作成功");
			}else{
				resultMap.put("success", false);
				resultMap.put("message", "执行失败，请重新操作!");
			}
			
		} catch (Exception e) {
			logger.error("/creditRes/doResOpera error, reason: "+ e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常，请稍后重试");
			
		}
		
		return resultMap;
	}
	
	/**
	 * 账户操作之创建账户
	 * @param map
	 * @param userId 操作员ID
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/docreateAccount4Res.do")
	public Map<String,Object> doCreateAccount4Res(@RequestParam Map<String, String> map, String userId){
		
		logger.info("/creditRes/doCreateAccount4Res start , frontParam: "+ userId );
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "异常，请稍后重试");

		if(StringUtils.isEmpty(userId)){//判定用户ID是否为空
			logger.info("/creditRes/doCreateAccount4Res fail, reason : userId is null");
			resultMap.put("success", false);
			resultMap.put("message", "执行失败，用户ID不可为空!");
			return resultMap;
		}
		
		try {
			GatewayAccountCreateRequest req = new GatewayAccountCreateRequest();
			req.setUserId(userId);
			resultMap.put("respParam", GsonUtil.getInstance().toJson(req));
			
			ResponseData<GatewayAccountCreateResponse> respData = creditResService.createAccount4Res(req);
			logger.info("/creditRes/doCreateAccount4Res, call gatewayAccountFacade create responseResult:"+GsonUtil.getInstance().toJson(respData));
			resultMap.put("respData", GsonUtil.getInstance().toJson(respData));
			if(respData.isSuccess()){//创建账户成功
				resultMap.put("success", true);
				resultMap.put("message", "执行成功，用户ID:"+userId+"开户成功!");
			}else{//创建账户失败
				resultMap.put("success", false);
				resultMap.put("message", respData.getMessage());
			}
		} catch (Exception e) {
			logger.error("/creditRes/docreateAccount4Res error, reason: "+ e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常，请稍后重试");
		}
		
		
		return resultMap;
	}
	
	
	/**
	 * 账户操作之查询账户
	 * @param map
	 * @param userId 操作员ID
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doqryAccount4Res.do")
	public Map<String,Object> doqryAccount4Res(@RequestParam Map<String, String> map, String accountNo4ResQry){
		
		logger.info("/creditRes/doqryAccount4Res start , waiting excute sql: "+ accountNo4ResQry );
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "异常，请稍后重试");

		if(StringUtils.isEmpty(accountNo4ResQry)){//判定用户ID是否为空
			logger.info("/creditRes/doqryAccount4Res fail, reason : accountNo4ResQry is null");
			resultMap.put("success", false);
			resultMap.put("message", "查询失败，账户号不可为空!");
			return resultMap;
		}
		
		try {
			GatewayAccountQueryRequest accountQryReq = new GatewayAccountQueryRequest();
			accountQryReq.setAccountNo(accountNo4ResQry);
			resultMap.put("respParam", GsonUtil.getInstance().toJson(accountQryReq));
			
			ResponseData<GatewayAccountQueryResponse> respData = creditResService.queryAccountInfo4Res(accountQryReq);
			logger.info("/creditRes/doqryAccount4Res, call gatewayAccountFacade queryAccountInfo responseResult:"+GsonUtil.getInstance().toJson(respData));
			resultMap.put("respData", GsonUtil.getInstance().toJson(respData));
			if(respData.isSuccess()){//创建账户成功
				resultMap.put("success", true);
				resultMap.put("message", "查询成功!");
			}else{//创建账户失败
				resultMap.put("success", false);
				resultMap.put("message", respData.getMessage());
			}
		} catch (Exception e) {
			logger.error("/creditRes/doqryAccount4Res error, reason: "+ e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常，请稍后重试");
		}
		
		
		return resultMap;
	}
	/**
	 * 账户充值
	 * @param map
	 * @param userId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doRechargeAccount4Res.do")
	public Map<String,Object> doRechargeAccount4Res(@RequestParam Map<String, String> map, String accountNo4ResRecharge, 
			String operaCode4Recharge, String balance4Recharge){
		
		logger.info("/creditRes/doRechargeAccount4Res start , frontParam: "+ accountNo4ResRecharge );
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "异常，请稍后重试");
		if(StringUtils.isEmpty(operaCode4Recharge)){//判定操作密钥
			logger.info("/creditRes/doRechargeAccount4Res fail, reason : operaCode4Recharge is null");
			resultMap.put("success", false);
			resultMap.put("message", "执行失败，操作码不可为空!");
			return resultMap;
		}
		if(!operaCode4Recharge.equals(PARAM_RES_SQL_CODE)){//判定res操作的执行码是否与定义的值匹配
			logger.info("/creditRes/doResOpera fail, reason : operaCode4Recharge is not match");
			resultMap.put("success", false);
			resultMap.put("message", "执行失败，操作码不匹配!");
			return resultMap;
		}
		if(StringUtils.isEmpty(accountNo4ResRecharge)){//判定操作密钥
			logger.info("/creditRes/doRechargeAccount4Res fail, reason : accountNo4ResRecharge is null");
			resultMap.put("success", false);
			resultMap.put("message", "执行失败，账户号不可为空!");
			return resultMap;
		}
		if(StringUtils.isEmpty(balance4Recharge)){
			logger.info("/creditRes/doRechargeAccount4Res fail, reason : balance4Recharge is null");
			resultMap.put("success", false);
			resultMap.put("message", "执行失败，余额余量不可为空!");
			return resultMap;
		}
		if(!RegexValidateUtil.checkDigit(balance4Recharge)){
			logger.info("/creditRes/doRechargeAccount4Res fail, reason : balance4Recharge is illegal");
			resultMap.put("success", false);
			resultMap.put("message", "执行失败，余额余量格式有误!");
			return resultMap;
		}
		
		try {
			GatewayAccountRechargeRequest req = new GatewayAccountRechargeRequest();
			req.setAccountNo(accountNo4ResRecharge);
			req.setTradeAmt(Long.valueOf(balance4Recharge));
			req.setOperator("SYSTEM");
			req.setTradeDesc("RES operation");
			resultMap.put("respParam", GsonUtil.getInstance().toJson(req));
			ResponseData<GatewayAccounTradeResponse> respData = creditResService.accountRecharge(req);
			logger.info("/creditRes/doRechargeAccount4Res, call gatewayAccountFacade accountRecharge responseResult:"+GsonUtil.getInstance().toJson(respData));
			resultMap.put("respData", GsonUtil.getInstance().toJson(respData));
			if(respData.isSuccess()){
				resultMap.put("success", true);
				resultMap.put("message", "充值成功!");
			}else{//创建账户失败
				resultMap.put("success", false);
				resultMap.put("message", respData.getMessage());
			}
		} catch (Exception e) {
			logger.error("/creditRes/doRechargeAccount4Res error, reason: "+ e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常，请稍后重试");
		}
		
		return resultMap;
	}
	
	/**
	 * 账户消费
	 * @param map
	 * @param accountNo4ResRecharge
	 * @param operaCode4Recharge
	 * @param balance4Recharge
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/doConsumeAccount4Res.do")
	public Map<String,Object> doConsumeAccount4Res(@RequestParam Map<String, String> map, String accountNo4ResConsume, 
			String operaCode4Consume, String balance4Consume){
		
		logger.info("/creditRes/doConsumeAccount4Res start , frontParam: "+ accountNo4ResConsume );
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "异常，请稍后重试");
		if(StringUtils.isEmpty(operaCode4Consume)){//判定操作密钥
			logger.info("/creditRes/doConsumeAccount4Res fail, reason : operaCode4Consume is null");
			resultMap.put("success", false);
			resultMap.put("message", "执行失败，操作码不可为空!");
			return resultMap;
		}
		if(!operaCode4Consume.equals(PARAM_RES_SQL_CODE)){//判定res操作的执行码是否与定义的值匹配
			logger.info("/creditRes/doConsumeAccount4Res fail, reason : operaCode4Recharge is not match");
			resultMap.put("success", false);
			resultMap.put("message", "执行失败，操作码不匹配!");
			return resultMap;
		}
		if(StringUtils.isEmpty(accountNo4ResConsume)){//判定操作密钥
			logger.info("/creditRes/doConsumeAccount4Res fail, reason : accountNo4ResConsume is null");
			resultMap.put("success", false);
			resultMap.put("message", "执行失败，账户号不可为空!");
			return resultMap;
		}
		if(StringUtils.isEmpty(balance4Consume)){
			logger.info("/creditRes/doConsumeAccount4Res fail, reason : balance4Recharge is null");
			resultMap.put("success", false);
			resultMap.put("message", "执行失败，消费额/量不可为空!");
			return resultMap;
		}
		if(!RegexValidateUtil.checkDigit(balance4Consume)){
			logger.info("/creditRes/doConsumeAccount4Res fail, reason : balance4Recharge is illegal");
			resultMap.put("success", false);
			resultMap.put("message", "执行失败，消费额/量格式有误!");
			return resultMap;
		}
		
		try {
			GatewayAccountConsumeRequest req = new GatewayAccountConsumeRequest();
			req.setAccountNo(accountNo4ResConsume);
			req.setTradeAmt(Long.valueOf(balance4Consume));
			req.setOperator("SYSTEM");
			req.setTradeDesc("RES operation");
			resultMap.put("respParam", GsonUtil.getInstance().toJson(req));
			ResponseData<GatewayAccounTradeResponse> respData = creditResService.accountConsume(req);
			logger.info("/creditRes/doConsumeAccount4Res, call gatewayAccountFacade accountRecharge responseResult:"+GsonUtil.getInstance().toJson(respData));
			resultMap.put("respData", GsonUtil.getInstance().toJson(respData));
			if(respData.isSuccess()){
				resultMap.put("success", true);
				resultMap.put("message", "消费成功!");
			}else{//创建账户失败
				resultMap.put("success", false);
				resultMap.put("message", respData.getMessage());
			}
		} catch (Exception e) {
			logger.error("/creditRes/doConsumeAccount4Res error, reason: "+ e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常，请稍后重试");
		}
		
		return resultMap;
	}


	/**
	 * r2m后门，用于设置key值的失效时间
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/expiredR2mKeys.do")
	public Map<String,Object> expiredR2mKeys(@RequestParam Map<String, String> map) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "操作成功");
		String operaCode=map.get("opCode");
		String prefix=map.get("prefix");
		String ttl=map.get("ttl");
		logger.info("expiredR2mKeys : prefix "+prefix+",ttl "+ttl);

		try {
			if(PARAM_RES_CACHE_CODE.equals(operaCode)) {
                creditResService.expireKeysR2m(prefix,Integer.parseInt(ttl));
            }else{
                resultMap.put("success", false);
                resultMap.put("message", "op code error!");
            }
		} catch (NumberFormatException e) {
			e.printStackTrace();
			resultMap.put("success", false);
			resultMap.put("message", "操作失败");
		}
		return resultMap;
	}
	
	/**
	 * 上传文件
	 * @author yangjinlin
	 * @param map
	 * @return
	 */
	@RequestMapping("/doUploadMiniArea.biz")
	@ResponseBody 
	public UploadObject doUploadMiniArea(@RequestParam Map<String,Object> map){

		String uploadObjectStr = String.valueOf(map.get("uploadObject"));
		Gson gson = new Gson();//json处理工具随意用什么fastjson、jsonlib、jackson。。。。等

		UploadObject uploadObject = gson.fromJson(uploadObjectStr, UploadObject.class);
		uploadObject.setVersion("2.0");
		List<UploadFile> list = uploadObject.getFileList();

		for (UploadFile uploadFile : list) {
			uploadFile.setPath("/miniArea/" + new SimpleDateFormat("yyyy/MM/dd").format(new Date()) + "/");//设置上传到NFS的相对路径
			uploadFile.setName(System.currentTimeMillis()+"");//设置上传到NFS的名称（不含后缀），具体可以看UploadObject的注释
			uploadFile.setTemp(false);
		}
		return uploadObject;
	}
	
	/**
	 * 上传合同文件回调方法
	 * @author yangjinlin
	 * @param map
	 * @return
	 */
	@RequestMapping("/doUploadMiniAreaCallback.biz")
	@ResponseBody //将UploadObject对象转换成json
	public Map<String,Object> doUploadMiniAreaCallback(@RequestParam Map<String,Object> map){
		Map<String,Object> result = new HashMap<String,Object>();
		String uploadObjectStr = String.valueOf(map.get("uploadObject"));//拿到上传对象
		Gson gson = new Gson();//json处理工具随意
		UploadObject uploadObject = gson.fromJson(uploadObjectStr, UploadObject.class);//json->object
		List<UploadFile> list = uploadObject.getFileList();//得到上传文件列表
		UploadFile loadFile = null;
		try {
			if (    uploadObject.isSuccess()
					&& list.size() == 1
					&& (loadFile = list.get(0)) != null  ) {
				String subtractPdfPath = subtractPdfPath(loadFile.getPathname());
				File file = new File(loadFile.getRealPathname());  
			    InputStream is = new FileInputStream(file);  
			    parseExcelMiniArea(is);
				logger.debug("文件上传成功，文件路径是"+subtractPdfPath);
				result.put("success", true);// 前台可能会做个处理，上传成功跳转等等。demo中页面只是使用了message中的信息
				result.put("filePath", loadFile.getPathname());
				result.put("message", "文件上传成功");
			} else {
				result.put("success", false);
				result.put("message", "文件上传失败");
				if (list.size() == 0 || (loadFile = list.get(0)) == null) {
					result.put("message", "文件为空");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		    logger.error("uploadFileByHspDirFileAdd error, " + e);
		}
		
		return result;//返回json串，前台进行处理
	}
	
	public Map<String, Object> parseExcelMiniArea(InputStream is){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", false);
		resultMap.put("message", "操作失败");
		try {
			resultMap = creditResService.insertMiniAreasExcel(is, false);
			if(resultMap.get("success").equals(true)){
				resultMap.put("success", false);
			}
		} catch (Exception e) {
			logger.error("uploadFileByHspDirFileAdd error, " ,e);
			resultMap.put("success", false);
			resultMap.put("message", "操作失败");
		}
		return resultMap;
	}
	
	/**
	 * 去除文件路径的pdf/以及之前的部分
	 * @param pdfFilePathName
	 * @return
	 */
	public static String subtractPdfPath(String pdfFilePathName) {
		if (StringUtils.isEmpty(pdfFilePathName)) {
			return "";
		}
		String pdf = "mini/";
		int beginIndex = pdf.length();
		int pdfIndex = pdfFilePathName.indexOf(pdf);
		if(pdfIndex > 0) {
			beginIndex += pdfIndex;
		}
		return pdfFilePathName.substring(beginIndex);
	}
	
}
