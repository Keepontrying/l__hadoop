package com.wangyin.boss.credit.admin.service;

import java.util.List;

import com.wangyin.boss.credit.admin.entity.CreditBankPolicy;

/** 
* @desciption : 银行渠道策略接口类
* @author : yangjinlin@jd.com
* @date ：2016年12月13日 下午3:50:59 
* @version 1.0 
* @return  */
public interface CreditBankPolicyService {

	/**
	 * 多条件查询银行渠道策略接口信息 分页 
	 * @param bankPolicy 银行渠道策略实体类
	 * @return
	 */
	List<CreditBankPolicy> selectBankPolicyByParam(CreditBankPolicy bankPolicy);

	/**
	 * 多条件查询银行渠道策略接口信息总条数  分页 
	 * @param bankPolicy 银行渠道策略实体类
	 * @return
	 */
	int selectBankPolicyCountByParam(CreditBankPolicy bankPolicy);

	/**
	 * 新增银行渠道策略信息
	 * @param bankPolicy 银行渠道策略实体类
	 * @return
	 */
	int insert(CreditBankPolicy bankPolicy);

	/**
	 * 根据policyId查询银行渠道策略信息
	 * @param policyId 银行渠道策略主键Id
	 * @return
	 */
	CreditBankPolicy selectBypolicyId(Integer policyId);

	/**
	 * 根据policyId更新银行渠道策略信息
	 * @param bankPolicy 银行渠道策略主键Id
	 * @return
	 */
	int updateByPolicyId(CreditBankPolicy bankPolicy);

	/**
	 * 根据银行渠道策略的主键 银行编码、借贷标记 来查询 银行渠道策略
	 * @param bankPolicy 银行编码bankCode、借贷标记cardType、策略状态
	 * @return
	 */
	List<CreditBankPolicy> selectBankPolicyByUniqueKey(CreditBankPolicy bankPolicy);

	
	
}
