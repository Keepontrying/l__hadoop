package com.wangyin.boss.credit.admin.service.impl;

import com.jd.jr.boss.credit.domain.common.entity.CreditPostBillMonth;
import com.jd.jr.boss.credit.facade.authen.api.CreditBillFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.PostBillQueryParam;
import com.wangyin.boss.credit.admin.service.PostBillService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.beans.Page;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * Created by anmeng on 2017/9/14.
 */
@Service
public class PostBillServiceImpl implements PostBillService {

    private Logger logger= LoggerFactory.getLogger(PostBillServiceImpl.class);

    @Resource
    private CreditBillFacade billFacade;

    /**
     * 查询后付费账单
     *
     * @param queryParam
     * @return
     */
    @Override
    public Page<CreditPostBillMonth> query(PostBillQueryParam queryParam) {
        return billFacade.queryPostBill(queryParam);
    }

    /**
     * 查询后付费账单详情
     *
     * @param queryParam
     * @return
     */
    @Override
    public CreditPostBillMonth detail(PostBillQueryParam queryParam) {
        return billFacade.detailPostBill(queryParam);
    }
}
