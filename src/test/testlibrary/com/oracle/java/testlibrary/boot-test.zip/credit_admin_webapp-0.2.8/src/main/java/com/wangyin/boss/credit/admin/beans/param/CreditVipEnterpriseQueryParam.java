package com.wangyin.boss.credit.admin.beans.param;

import java.io.Serializable;
import java.util.Date;

/** 
* @desciption : 
* @author : liuwei55@jd.com
* @date ：2017年6月28日 下午7:01:50 
* @version 1.0 
* @return  */
public class CreditVipEnterpriseQueryParam extends CreditVipMerchantQueryParam implements Serializable {

	private static final long serialVersionUID = -4739313902256922885L;
	/**
	 * 监控企业名称
	 */
    private String entName;
	/**
	 * 证件号码
	 */
    private String cardNumber;
	/**
	 * 开始监控日期时间段 起始日期
	 */
	private String startModifiedDateStr;
	/**
	 * 开始监控日期时间段 结束日期
	 */
	private String endModifiedDateStr;

	public String getEntName() {
		return entName;
	}

	public void setEntName(String entName) {
		this.entName = entName;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	@Override
	public String getStartModifiedDateStr() {
		return startModifiedDateStr;
	}

	@Override
	public void setStartModifiedDateStr(String startModifiedDateStr) {
		this.startModifiedDateStr = startModifiedDateStr;
	}

	@Override
	public String getEndModifiedDateStr() {
		return endModifiedDateStr;
	}

	@Override
	public void setEndModifiedDateStr(String endModifiedDateStr) {
		this.endModifiedDateStr = endModifiedDateStr;
	}
}
