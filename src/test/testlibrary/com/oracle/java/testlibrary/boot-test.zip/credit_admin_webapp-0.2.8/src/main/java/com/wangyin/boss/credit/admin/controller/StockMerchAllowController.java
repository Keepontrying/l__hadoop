package com.wangyin.boss.credit.admin.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.jr.boss.credit.credit.gateway.merchantca.beans.entity.merchant.MerchantAccountVo;
import com.jd.jr.boss.credit.domain.common.enums.ContractStatusEnum;
import com.jd.jr.boss.credit.facade.site.api.dto.entity.PaymentPackageEntity;
import com.jd.jr.boss.credit.facade.site.api.dto.request.contract.ContractVerifyRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.request.paymentupdate.PaymentUpdateRequest;
import com.jd.jr.boss.credit.facade.site.api.dto.response.paymentupdate.PaymentUpdateResponse;
import com.jd.jr.boss.credit.facade.site.api.enums.request.ContractVerifyRequestEnum;
import com.jd.jr.boss.credit.gateway.account.beans.request.finance.GatewayAccountQueryRequest;
import com.jd.jr.boss.credit.gateway.account.beans.response.finance.GatewayAccountQueryResponse;
import com.jd.jr.boss.credit.gateway.account.facade.finance.GatewayAccountFacade;
import com.wangyin.boss.credit.admin.entity.CreditContract;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;
import com.wangyin.boss.credit.admin.entity.CreditProductStrategyAllow;
import com.wangyin.boss.credit.admin.entity.StockMerchProStrategyAllow;
import com.wangyin.boss.credit.admin.entity.StockMerchProStrategyAllowModel;
import com.wangyin.boss.credit.admin.enums.ChargeTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditMerchantStatusEnum;
import com.wangyin.boss.credit.admin.enums.CreditTypeEnum;
import com.wangyin.boss.credit.admin.service.CreditContractService;
import com.wangyin.boss.credit.admin.service.CreditMerchantService;
import com.wangyin.boss.credit.admin.service.CreditProductStrategyService;
import com.wangyin.boss.credit.admin.service.MerchantCaService;
import com.wangyin.boss.credit.admin.service.StockMerchAllowService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.beans.Response;
import com.wangyin.operation.common.beans.ResponseData;

/** 
* @desciption : 存量商户余额迁移功能
* @author : yangjinlin@jd.com
* @date ：2016年11月21日 下午2:42:32 
* @version 1.0 
* @return  */
@Controller
@RequestMapping("/stockMerchAllow")
public class StockMerchAllowController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(StockMerchAllowController.class);
	
	@Autowired
	StockMerchAllowService stockMerchAllowService;
	
	@Autowired
	CreditMerchantService creditMerchantService;
	
	@Autowired
	MerchantCaService merchantCaService;
	
	@Autowired
	CreditContractService creditContractService;
	
	@Resource
	GatewayAccountFacade accountFacade;
	
	@Autowired
	CreditProductStrategyService creditProductStrategyService;
	
	/**
	 * 根据商户号查询出商户计费信息
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryStockMerchAllow.do")
	public Map<String, Object> doQueryStockMerchAllow(@RequestParam Map<String, String> map, 
			StockMerchProStrategyAllow stockMerchProStrategyAllow){
		
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "查询成功");
		
		List<StockMerchProStrategyAllow> stockMerchProStrategyAllowList = new ArrayList<StockMerchProStrategyAllow>();
		List<CreditMerchant> merchList = new ArrayList<CreditMerchant>();
		List<MerchantAccountVo> merchantAccountList = new ArrayList<MerchantAccountVo>();
		int stockMerchProStrategyAllowCount = 0;
		
		if(StringUtils.isBlank(stockMerchProStrategyAllow.getMerchantNo())){
			resultMap.put("rows", null);
			resultMap.put("total", 0);
			resultMap.put("success", false);
			resultMap.put("message", "商户号不可为空！");
			return resultMap;
		}
		
		try {
			//调用企业站的商户认证接口查询接口,查看该商户是否为已认证商户
			String resultStr = stockMerchAllowService.queryAuthMerchantByNo(stockMerchProStrategyAllow);
			if("FAIL".equalsIgnoreCase(resultStr)){
				resultMap.put("success", true);
				resultMap.put("message", "该商户未认证!");
				return resultMap;
			}
			
			MerchantAccountVo queryMerchantAccountVo = new MerchantAccountVo();
			queryMerchantAccountVo.setMerchantNo(stockMerchProStrategyAllow.getMerchantNo());
			merchantAccountList = merchantCaService.queryMerchantAccountByNo(queryMerchantAccountVo);//调用商户账户接口查询该商户的账户信息
			if(CollectionUtils.isEmpty(merchantAccountList)){
				resultMap.put("success", false);
				resultMap.put("message", "该商户无账户代码");
				return resultMap;
			}
			
			//商户存在且状态为CLOSE时，直接返回前台提示
			merchList =  creditMerchantService.selectMerchListByNo(stockMerchProStrategyAllow.getMerchantNo());//查询商户表,产品设计规则的查询结果是一个商户号在商户表中至多有1条记录
			if(!CollectionUtils.isEmpty(merchList) && CreditMerchantStatusEnum.CLOSE.toName().equals(merchList.get(0).getMerchantStatus())){
				//若商户状态为CLOSE则提示商户不可用并且不可进行合同创建
				resultMap.put("success", false);
				resultMap.put("message", "该商户的状态为:"+ CreditMerchantStatusEnum.CLOSE.toDescription());
				return resultMap;
			}
//			stockMerchProStrategyAllow.setContractStatus(ContractStatusEnum.NOPAY.toName());//合同状态为代缴费,还需考虑 待确认的合同
			stockMerchProStrategyAllowList = stockMerchAllowService.selectStockMerchAllowByParam(stockMerchProStrategyAllow);
			for(StockMerchProStrategyAllow productStrategy : stockMerchProStrategyAllowList){
				if(null == productStrategy.getStrategyId() || "".equals(productStrategy.getStrategyId())){
					continue;
				}
				if(StringUtils.isNotBlank(productStrategy.getAccountNo())){
					Long balance = selectBalance(productStrategy.getAccountNo());//包量时调用该接口返回的结果值balance对应包量笔数，故无需除以100
					/*计费方式为包量时，查剩余次数*/
					productStrategy.setRemainCount(new Integer(balance.intValue()));
				}
			}
			
			stockMerchProStrategyAllowCount = stockMerchAllowService.selectStockMerchAllowCountByParam(stockMerchProStrategyAllow);
			resultMap.put("rows", stockMerchProStrategyAllowList);
			resultMap.put("total", stockMerchProStrategyAllowCount);
			
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "查询异常");
		}
		
		return resultMap;
	}
	
	/**
	 * 根据商户号动态展示合同下拉信息
	 * @author yangjinlin@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doContractSelect.do")
	
	public Map<String, Object> doContractSelect(@RequestParam Map<String, Object> map, String merchantNo) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "查询成功");
		List<CreditContract> contractList = new ArrayList<CreditContract>();
		List<CreditContract> contractOrigList = null;
		try {
			
			//查询商户单笔余量
//			Long merchantSingleAllow = null;
//			List<CreditProductStrategyAllow> creditProductStrategyList = new ArrayList<CreditProductStrategyAllow>();
//			CreditProductStrategyAllow creditProductStrategy = new CreditProductStrategyAllow();
//			creditProductStrategy.setMerchantNo(merchantNo);
//			creditProductStrategy.setChargeType(ChargeTypeEnum.SINGLE.toName());
//			creditProductStrategy.setStart("0");
//			creditProductStrategy.setLimit("10");
//			creditProductStrategyList = creditProductStrategyService.selectMerchantStrategyByParam(creditProductStrategy);
//			for (CreditProductStrategyAllow creditProductStrategy2 : creditProductStrategyList) {
//				if(null == creditProductStrategy2.getMerchantId()){
//					continue;
//				}
//				if(LOGGER.isInfoEnabled()){
//					LOGGER.info("根据商户ID=" + creditProductStrategy2.getMerchantId() + "查询出的账户号：" + creditProductStrategy2.getAccountNo());
//				}
//				if(StringUtils.isNotBlank(creditProductStrategy2.getAccountNo())){
//					merchantSingleAllow = selectBalance(creditProductStrategy2.getAccountNo());//单笔时返回的banlance对应的是账户余额，单位为分
//				}
//			}
//			
//			resultMap.put("merchantSingleAllow", merchantSingleAllow);
			
			//查询该商户下的合同
			contractOrigList = creditContractService.selectContractByMerchantNo(merchantNo);
			if(!CollectionUtils.isEmpty(contractOrigList)){//该商户已申请过合同
				 //遍历 contractList ,仅展示待确认 代缴费 有效的合同
				for(CreditContract ct: contractOrigList){
					if(( ContractStatusEnum.NOCONFIRM.toName().equals(ct.getContractStatus()) ||
							ContractStatusEnum.NOPAY.toName().equals(ct.getContractStatus()) ||
							ContractStatusEnum.VALID.toName().equals(ct.getContractStatus())  ) 
							){//仅展示个人征信业务下的合同
						if( CreditTypeEnum.PERSON.toName().equalsIgnoreCase(ct.getCreditType()) ){
							contractList.add(ct);
						}
					}
				}
				if(CollectionUtils.isEmpty(contractList)){
					resultMap.put("success", false);
					resultMap.put("contractList", contractList);
					return resultMap;
				}
				resultMap.put("contractList", contractList);
			}else{
				resultMap.put("success", false);
				resultMap.put("contractList", contractList);
			}
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("contractList", new ArrayList<CreditContract>());
			return resultMap;
		}
		
		return resultMap;
	}
	
	/**
	 * 根据合同编号将合同状态由待确认变为待缴费
	 * @author yangjinlin@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doStockConfirmContract.do")
	
	public Map<String, Object> doStockConfirmContract(@RequestParam Map<String, Object> map, Integer contractId) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "查询成功");
		ContractVerifyRequest contractVerifyReq = new ContractVerifyRequest();
		try {
			
			CreditContract contract = creditContractService.selectByPrimaryKey(contractId);
			if(null == contract){
				resultMap.put("success", false);
				resultMap.put("message", "数据异常");
				return resultMap;
			}
			if(!"NOCONFIRM".equals(contract.getContractStatus())){
				resultMap.put("success", false);
				resultMap.put("message", "该合同的状态是:"+ContractStatusEnum.enumValueOf(contract.getContractStatus()).toDescription() +"，不可执行确认合同操作!");
				return resultMap;
			}
			contractVerifyReq.setContractId(contractId);
			contractVerifyReq.setVerifyStatus(ContractVerifyRequestEnum.enumValueOf(ContractVerifyRequestEnum.PASS.toName()));
			Response resp = stockMerchAllowService.updateStockMerchContractConfirm(contractVerifyReq);
			if(resp.isSuccess()){
				resultMap.put("success", true);
				resultMap.put("message", "合同确认成功!");
			}else{
				resultMap.put("success", false);
				resultMap.put("message", "合同确认失败!");
			}
			
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
			return resultMap;
		}
		
		return resultMap;
	}
	
	/**
	 * 提交存量商户余量
	 * @param map 页面传参
	 * @param stockMerchProStrategyAllow 存量商户余量实体类
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doSubmitStockMerchAllow.do")
	public Map<String, Object> doSubmitStockMerchAllow(@RequestParam Map<String, Object> map,
			StockMerchProStrategyAllowModel stockMerchaAllowModel) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "商户余量提交响应成功");

		PaymentUpdateRequest paymentUpdateRequest = new PaymentUpdateRequest();
		List<PaymentPackageEntity> paymentPackageList = new ArrayList<PaymentPackageEntity>();
		
		try {
			
			if(CollectionUtils.isEmpty(stockMerchaAllowModel.getStockMerchAllowList())){
				resultMap.put("success", false);
				resultMap.put("message", "本次操作暂无可提交的余量信息!");
				return resultMap;
			}
			
			if(null == stockMerchaAllowModel.getStockMerchAllowList().get(0).getMerchantNo() || 
					"".equals(stockMerchaAllowModel.getStockMerchAllowList().get(0).getMerchantNo())){
				resultMap.put("success", false);
				resultMap.put("message", "商户号不可为空!");
				return resultMap;
			}
			BigDecimal bg = new BigDecimal("100");
			for(StockMerchProStrategyAllow stockMerch : stockMerchaAllowModel.getStockMerchAllowList() ){
				if(!"待缴费".contentEquals(stockMerch.getContractStatus()) && !"有效".contentEquals(stockMerch.getContractStatus())){//NOCONFIRM 待确认, PAY 有效
					resultMap.put("success", false);
					resultMap.put("message", "合同编号为:"+stockMerch.getContractNo()+"的合同状态是'待确认状态'，请先确认合同!");
					return resultMap;
				}
				if("包量".equals(stockMerch.getChargeType())){//PACKAGE 包量
					if(null != stockMerch.getAllowance()){
						stockAllowanceCheck(resultMap, stockMerch);
					}
					if("false".equals(resultMap.get("success").toString())){
						return resultMap;
					}
					PaymentPackageEntity paymentPackageEntity = new PaymentPackageEntity();
					paymentPackageEntity.setContractId(stockMerch.getContractId());
					paymentPackageEntity.setStrategyId(stockMerch.getStrategyId());
					paymentPackageEntity.setRemainCount(stockMerch.getAllowance());
					paymentPackageList.add(paymentPackageEntity);
				}
			}
			
			paymentUpdateRequest.setMerchantNo(stockMerchaAllowModel.getStockMerchAllowList().get(0).getMerchantNo());
			paymentUpdateRequest.setMoney((null==stockMerchaAllowModel.getPriceStr() || "".equals(stockMerchaAllowModel.getPriceStr())) ? null: new BigDecimal(stockMerchaAllowModel.getPriceStr()).multiply(bg).longValue());
			paymentUpdateRequest.setPaymentPackageList(paymentPackageList);
			
			ResponseData<PaymentUpdateResponse> respData = stockMerchAllowService.addStockMerchAllowInfo(paymentUpdateRequest);
			if(!respData.isSuccess()){
				resultMap.put("success", false);
				resultMap.put("message", "系统异常");
			}else{
				resultMap.put("success", true);
				resultMap.put("message", "商户余量信息提交成功");
				resultMap.put("singleResutMsg", respData.getData().isSuccess() ? "单笔余量充值成功！" : "单笔余量充值失败！");
				resultMap.put("paymentPackageList", respData.getData().getPaymentPackageList());
				
			}
			
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
			return resultMap;
		}

		return resultMap;
	}

	/**
	 * 校验余量与包量次数、当前剩余次数
	 * @param resultMap
	 * @param stockMerch
	 */
	private void stockAllowanceCheck(Map<String, Object> resultMap, StockMerchProStrategyAllow stockMerch) {
		if(null == stockMerch.getRemainCount()){//本次剩余次数的校验
			resultMap.put("success", false);
			resultMap.put("message", "合同编号为:"+stockMerch.getContractNo()+"的数据异常!");
		}else{
			if(stockMerch.getAllowance() > stockMerch.getPacketCount()){
				resultMap.put("success", false);
				resultMap.put("message", "计费策略为:"+stockMerch.getStrategyId()+"的 本次剩余次数 不得大于 包量次数!");
			}
		}
//		else if(null != stockMerch.getRemainCount() && 0!= stockMerch.getRemainCount()){
//			if(stockMerch.getAllowance() > stockMerch.getRemainCount()){
//				resultMap.put("success", false);
//				resultMap.put("message", "计费策略为:"+stockMerch.getStrategyId()+"的 本次剩余次数 不得大于 包量当前剩余次数!");
//			}
//		}
	}
	
	
	/** 根据账户号查询包量当前余量
	 * @author yangjinlin@jd.com
	 * @param accountNo 账户号
	 * @return
	 */
	private Long selectBalance(String accountNo) {
		//依据清结算账号查询余额信息
		com.wangyin.operation.common.beans.RequestParam<GatewayAccountQueryRequest> accountRequestParam = new com.wangyin.operation.common.beans.RequestParam<GatewayAccountQueryRequest>();
		GatewayAccountQueryRequest gatewayAccountQueryRequest = new GatewayAccountQueryRequest();
		gatewayAccountQueryRequest.setAccountNo(accountNo);
		accountRequestParam.setParam(gatewayAccountQueryRequest); 
		ResponseData<GatewayAccountQueryResponse> accountResponseData = accountFacade.queryAccountInfo(accountRequestParam); 
		Long balance = accountResponseData.getData().getBalance();
		return balance;
	}
	
	
	/**
	 * 根据商户号查询商户单笔余量
	 * @author yangjinlin@jd.com
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQryStockMerchSingleAllow.do")
	
	public Map<String, Object> doQryStockMerchSingleAllow(@RequestParam Map<String, Object> map, String merchantNo) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "查询成功");
		
		if(StringUtils.isBlank(merchantNo)){
			resultMap.put("rows", null);
			resultMap.put("total", 0);
			resultMap.put("success", false);
			resultMap.put("message", "商户号不可为空！");
			return resultMap;
		}
		
		try {
			
			//查询商户单笔余量
			Long merchantSingleAllow = null;
			List<CreditProductStrategyAllow> creditProductStrategyList = new ArrayList<CreditProductStrategyAllow>();
			CreditProductStrategyAllow creditProductStrategy = new CreditProductStrategyAllow();
			creditProductStrategy.setMerchantNo(merchantNo);
			creditProductStrategy.setChargeType(ChargeTypeEnum.SINGLE.toName());
			creditProductStrategy.setStart("0");
			creditProductStrategy.setLimit("10");
			creditProductStrategyList = creditProductStrategyService.selectMerchantStrategyByParam(creditProductStrategy);
			for (CreditProductStrategyAllow creditProductStrategy2 : creditProductStrategyList) {
				if(null == creditProductStrategy2.getMerchantId()){
					continue;
				}
				if(LOGGER.isInfoEnabled()){
					LOGGER.info("根据商户ID=" + creditProductStrategy2.getMerchantId() + "查询出的账户号：" + creditProductStrategy2.getAccountNo());
				}
				if(StringUtils.isNotBlank(creditProductStrategy2.getAccountNo())){
					merchantSingleAllow = selectBalance(creditProductStrategy2.getAccountNo());//单笔时返回的banlance对应的是账户余额，单位为分
				}
			}
			
			resultMap.put("merchantSingleAllow", merchantSingleAllow);
			
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "系统异常");
			return resultMap;
		}
		
		return resultMap;
	}
	
	
}
