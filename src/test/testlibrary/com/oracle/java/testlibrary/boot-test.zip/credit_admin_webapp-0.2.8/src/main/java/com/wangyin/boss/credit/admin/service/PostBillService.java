package com.wangyin.boss.credit.admin.service;

import com.jd.jr.boss.credit.domain.common.entity.CreditPostBillMonth;
import com.jd.jr.boss.credit.facade.authen.beans.param.PostBillQueryParam;
import com.wangyin.operation.common.beans.Page;

/**
 * Created by anmeng on 2017/9/14.
 */
public interface PostBillService {

    /**
     * 查询后付费账单
     * @param queryParam
     * @return
     */
    public Page<CreditPostBillMonth> query(PostBillQueryParam queryParam);

    /**
     * 查询后付费账单详情
     * @param queryParam
     * @return
     */
    public CreditPostBillMonth detail(PostBillQueryParam queryParam);
}
