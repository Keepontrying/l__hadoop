package com.wangyin.boss.credit.enterprise.service.impl;

import com.wangyin.boss.credit.enterprise.beans.SensitiveWord;
import com.wangyin.boss.credit.enterprise.beans.SensitiveWordQueryParam;
import com.wangyin.boss.credit.enterprise.dao.SensitiveWordMapper;
import com.wangyin.boss.credit.enterprise.service.SensitiveWordService;
import com.wangyin.operation.common.beans.Page;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author huangzhiqiang
 * @data 2018/11/19
 */
@Service
public class SensitiveWordServiceImpl implements SensitiveWordService {

    @Resource
    private SensitiveWordMapper mapper;

    @Override
    public Long insert(SensitiveWord word) {
        return mapper.insert(word);
    }

    @Override
    public void delete(Long id) {
        mapper.delete(id);
    }

    @Override
    public void update(SensitiveWord word) {
        mapper.update(word);
    }

    @Override
    public Page<SensitiveWord> query(SensitiveWordQueryParam param) {
        Page<SensitiveWord> page = new Page<>();
        int total = mapper.queryCount(param);
        page.setTotal(total);
        if (total > 0) {
            page.setRows(mapper.query(param));
        }
        return page;
    }

}
