package com.wangyin.boss.credit.configuration;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

/**
 * 异常处理
 *
 * @author: dongzhihua
 * @time: 2018/11/21 16:53:32
 */
@Component
public class MyHandlerExceptionResolver implements HandlerExceptionResolver {

    static DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");

    private static Logger logger = LoggerFactory.getLogger(MyHandlerExceptionResolver.class);

    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        ModelAndView modelAndView = new ModelAndView(new MappingJackson2JsonView());
        modelAndView.addObject("code", "9999");
        modelAndView.addObject("message", ex.getMessage());
        modelAndView.addObject("success", false);
        modelAndView.addObject("path", request.getRequestURI());
        modelAndView.addObject("timestamp", format.format(new Date()));
        logger.error("resolveException ", ex);
        return modelAndView;
    }
}
