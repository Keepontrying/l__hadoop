package com.wangyin.boss.credit.enterprise.service;

import com.wangyin.boss.credit.enterprise.beans.CrawlerJob;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResultsQueryParam;
import com.wangyin.operation.common.beans.Page;

import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2018/11/20
 */
public interface CrawlerJobService {

    Long insert(CrawlerJob job);

    void delete(Long id);

    void update(CrawlerJob job);

    Page<CrawlerJob> query(CrawlerJobResultsQueryParam param);

    List<CrawlerJob> queryList(CrawlerJobResultsQueryParam param);
}

