package com.wangyin.boss.credit.admin;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.chinabank.merchant.authcenter.adapter.AuthCenterQueryFacade;
import com.jd.jr.merchant.api.DubboQueryRouteApi;
import com.jd.jr.merchant.form.ResultObject;
import com.wangyin.operation.utils.GsonUtil;

/**
 * 校验商户号是否是实名认证类型为企业的商户 测试类
 * 
 * @author wyhaozhihong
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:applicationContext.xml" })
public class ValidMerchantNoTest {

	/*@Autowired
	private AuthCenterQueryFacade authCenterQueryFacade;
	
	@Autowired
	private DubboQueryRouteApi authQueryApi;
	
	@Test
	public void selectByParamTest(){
		Map<String,Object> arg0 = new HashMap<String,Object>();
		arg0.put("exectype", "AUTH001");
		arg0.put("owner", "110031419");
		ResultObject result = authQueryApi.dubboRoute(arg0);
//		AuthBaseInfoForm query = authCenterQueryFacade.query(arg0, QueryType.AUTHCERD001);
		System.out.println(GsonUtil.getInstance().toJson(result));
	}*/
	
	
}
