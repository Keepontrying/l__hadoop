package com.wangyin.boss.credit.admin.service;

import java.util.List;

import com.jd.jr.boss.credit.facade.authen.beans.param.ProductQueryParam;
import com.wangyin.boss.credit.admin.entity.CreditProduct;

/**
 * 征信产品服务类
 * @author wyhaozhihong
 *
 */
public interface CreditProductService {
	/**
	 * 查询 征信产品
	 * @param cp
	 * @return
	 */
	List<CreditProduct> select(CreditProduct cp);

	/**
	 * 查询 征信产品 count
	 * @param cp
	 * @return
	 */
	int selectCount(CreditProduct cp);

	/**
	 * 查询还未添加到item的产品列表
	 * @return
	 */
	List<CreditProduct> selectAvailableCreditProductToItem();

	/**
	 * 根据参数查询征信产品list
	 * @param cp
	 * @return
	 */
	List<CreditProduct> queryEnterpriseProduct(CreditProduct cp);

	/**
	 * 查询业务产品List
	 * @param productQryPrm
	 * @return
	 */
	List<CreditProduct> queryProductListByPrm(ProductQueryParam productQryPrm);
}
