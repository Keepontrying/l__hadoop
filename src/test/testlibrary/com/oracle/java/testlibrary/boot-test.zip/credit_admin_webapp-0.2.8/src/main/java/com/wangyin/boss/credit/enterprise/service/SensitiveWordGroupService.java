package com.wangyin.boss.credit.enterprise.service;

import com.wangyin.boss.credit.enterprise.beans.SensitiveWordGroup;
import com.wangyin.boss.credit.enterprise.beans.SensitiveWordQueryParam;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.beans.PageQuery;

/**
 * @author huangzhiqiang
 * @data 2018/11/19
 */
public interface SensitiveWordGroupService {

    Long insert(SensitiveWordGroup word);

    void update(SensitiveWordGroup word);

    /**
     * 条件查询
     *
     * @param param
     * @return
     */
    Page<SensitiveWordGroup> query(SensitiveWordQueryParam param);

}
