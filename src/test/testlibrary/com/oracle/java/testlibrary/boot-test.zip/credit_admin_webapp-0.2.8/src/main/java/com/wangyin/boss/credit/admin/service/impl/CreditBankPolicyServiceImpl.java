package com.wangyin.boss.credit.admin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wangyin.boss.credit.admin.dao.CreditBankPolicyMapper;
import com.wangyin.boss.credit.admin.entity.CreditBankPolicy;
import com.wangyin.boss.credit.admin.service.CreditBankPolicyService;

/** 
* @desciption : 银行渠道策略 service实现类
* @author : yangjinlin@jd.com
* @date ：2016年12月13日 下午4:00:56 
* @version 1.0 
* @return  */
@Service
public class CreditBankPolicyServiceImpl implements CreditBankPolicyService {

	
	@Autowired
	CreditBankPolicyMapper bankPolicyMapper;
	
	@Override
	public List<CreditBankPolicy> selectBankPolicyByParam(CreditBankPolicy bankPolicy) {
		// TODO Auto-generated method stub
		return bankPolicyMapper.selectBankPolicyByParam(bankPolicy);
	}

	@Override
	public int selectBankPolicyCountByParam(CreditBankPolicy bankPolicy) {
		// TODO Auto-generated method stub
		return bankPolicyMapper.selectBankPolicyCountByParam(bankPolicy);
	}

	@Override
	public int insert(CreditBankPolicy bankPolicy) {
		// TODO Auto-generated method stub
		return bankPolicyMapper.insert(bankPolicy);
	}

	@Override
	public CreditBankPolicy selectBypolicyId(Integer policyId) {
		// TODO Auto-generated method stub
		return bankPolicyMapper.selectBypolicyId(policyId);
	}

	@Override
	public int updateByPolicyId(CreditBankPolicy bankPolicy) {
		// TODO Auto-generated method stub
		return bankPolicyMapper.updateByPolicyId(bankPolicy);
	}

	@Override
	public List<CreditBankPolicy> selectBankPolicyByUniqueKey(CreditBankPolicy bankPolicy) {
		// TODO Auto-generated method stub
		return bankPolicyMapper.selectBankPolicyByUniqueKey(bankPolicy);
	}

}
