package com.wangyin.boss.credit.enterprise.beans;

import java.io.Serializable;
import java.util.Date;

/**
 * 敏感词分组
 *
 * @author huangzhiqiang
 * @data 2018/11/16
 */
public class SensitiveWordGroup implements Serializable {

    private Long id;

    private String name;

    private String content;

    /**
     * 创建时间
     */
    private Date createdDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
}
