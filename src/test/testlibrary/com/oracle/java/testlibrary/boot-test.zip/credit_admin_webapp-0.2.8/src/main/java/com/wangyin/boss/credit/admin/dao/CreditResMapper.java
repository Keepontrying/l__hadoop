package com.wangyin.boss.credit.admin.dao;

import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;

@SqlMapper
@Component
public interface CreditResMapper {

	/**
	 * 根据前台传过来的sql进行res操作
	 * @param paramSql
	 */
	void updateResOperaBySql(String paramSql);
}