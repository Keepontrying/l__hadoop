package com.wangyin.boss.credit.admin.service;

import com.wangyin.boss.credit.admin.entity.CreditItemSku;

/**
 * @author jiangbo
 * @since 2017/3/26
 */
public interface CreditItemSkuService {

    /**
     * 有选择的插入
     * @param creditItemSku
     * @return
     */
    int insertSelective(CreditItemSku creditItemSku);

    /**
     * 更新sku
     * @param creditItemSku
     * @return
     */
    public int updateByPrimaryKeySelective(CreditItemSku creditItemSku);
}
