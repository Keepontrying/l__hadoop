package com.wangyin.boss.credit.admin.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditCost;

@SqlMapper
@Component
public interface CreditCostMapper {
	
	List<CreditCost> selectByParam(CreditCost creditCost);

	int selectCountByParam(CreditCost creditCost);
	
	int update(CreditCost creditCost);
	
	int insert(CreditCost record);

}