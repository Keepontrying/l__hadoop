package com.wangyin.boss.credit.enterprise.controller;

import com.google.gson.Gson;
import com.jd.jr.boss.credit.facade.authen.beans.entity.JsfConfigBean;
import com.jd.jr.boss.credit.facade.authen.beans.param.BatchDataQueryParam;
import com.wangyin.admin.frame.utils.JSONUtils;
import com.wangyin.boss.credit.enterprise.constants.HspConstant;
import com.wangyin.boss.credit.enterprise.service.CreditBatchDeriveDataService;
import com.wangyin.boss.credit.enterprise.utils.HspUtil;
import com.wangyin.operation.beans.UploadFile;
import com.wangyin.operation.beans.UploadObject;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 批量导出数据
 */
@Controller
@RequestMapping("credit/jsfConfig/")
public class JsfConfigController {

    private static Logger logger = LoggerFactory.getLogger(JsfConfigController.class);

    @Autowired
    CreditBatchDeriveDataService creditBatchDeriveDataService;


    /**
     * TODO 查询jsf配置列表
     * @param map
     * @return
     */
    @ResponseBody
    @RequestMapping("/pageList.do")
    protected Map<String, Object> queryJsfConfig(JsfConfigBean map) {
        logger.info("jsf接口配置列表查询参数:"+JSONUtils.toJSON(map));
        return creditBatchDeriveDataService.queryJsfConfigList(map);
    }

    /**
     * TODO 更新jsf接口配置文件
     * @param jsfConfigBean
     * @return
     */
    @ResponseBody
    @RequestMapping("/saveOrUpdate.do")
    protected Map<String, Object> saveOrUpdateJsfConfig(JsfConfigBean jsfConfigBean) {
        logger.info("操作jsf接口配置文件参数：" + JSONUtils.toJSON(jsfConfigBean));
        return creditBatchDeriveDataService.saveOrUpdateJsfConfig(jsfConfigBean);
    }

    @ResponseBody
    @RequestMapping("/showJsfConfig.do")
    protected Map<String,Object> showJsfConfig(JsfConfigBean jsfConfigBean){
        logger.info("jsf接口配置参数id: " + JSONUtils.toJSON(jsfConfigBean));
        return creditBatchDeriveDataService.queryJsfConfig(jsfConfigBean);
    }


    @ResponseBody
    @RequestMapping("/getResult.do")
    protected Map<String, Object> queryResut(@RequestParam Map<String,Object> param) {
        logger.info("调用jsf接口入参：" + JSONUtils.toJSON(param));
        return creditBatchDeriveDataService.queryResult(param);
    }

    /**
     * TODO 根据jsf—— interfaceId查询方法列表
     * @param param
     * @return
     */
    @ResponseBody
    @RequestMapping("/getJsfMethod.do")
    protected Map<String, Object> getJsfMethods(@RequestParam Map<String,Object> param) {
        return creditBatchDeriveDataService.getInterfaceDetailInf(param);
    }

    /**
     * TODO 根据jsf—— interfaceId查询别名
     * @param param
     * @return
     */
    @ResponseBody
    @RequestMapping("/getJsfAlias.do")
    protected Map<String, Object> getJsfAlias(@RequestParam Map<String,Object> param) {
        return creditBatchDeriveDataService.getAliasByInterfaceId(param);
    }

}
