package com.wangyin.boss.credit.admin.utils;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.google.gson.Gson;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.beans.QueryResponse;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.utils.GsonUtil;

/**
 * 
 * <ul>
 * <li>1、开发日期：2016年1月6日</li>
 * <li>2、开发时间：下午8:49:53</li>
 * <li>3、作          者：wangyao15</li>
 * <li>4、类型名称：EnterpriseUtils</li>
 * <li>5、类型意图：企业站相关http接口调用</li>
 * </ul>
 *
 */
public class EnterpriseUtils {

	private static Logger logger = LoggerFactory.getLogger(EnterpriseUtils.class);
	
	public static String getFirstName(String merchantNo) {
		Map<String,String> params= new HashMap<String, String>();
		String sign = MessageDigestUtil.hmacSign(merchantNo ,"marry12#$");
		params.put("merchantId", merchantNo);
		params.put("sign", sign);
		String url = ConfigUtil.getString("app.authentication.getFirstParty.api");
		logger.info("host parameter is "+url);
		String res =  HttpUtil.doPost(url, params);
		if(res != null){
			Gson gson = new Gson();
			Map resmap = gson.fromJson(res, Map.class);
			if("000000".equals(resmap.get("responseCode"))){
				Map resMap = (Map) resmap.get("data");
				logger.debug("认证接口返回数据：" + resMap);
				if ( resMap == null || resMap.size() == 0 ) 
					return null;
				
				if ( !isBlankForAuth(resMap.get("BusinessLicenceAuthItem")) ){
                    String firstName = (String)((Map)resMap.get("BusinessLicenceAuthItem")).get("owner");
                 

                    if(StringUtils.isNotBlank(firstName)) {
                        return firstName;
                    }
                }else if ( !isBlankForAuth(resMap.get("BusinessLicence3In1AuthItem")) ){
                    String firstName = (String)((Map)resMap.get("BusinessLicence3In1AuthItem")).get("owner");
                 
                    if(StringUtils.isNotBlank(firstName)) {
                        return firstName;
                    }
                }else if ( !isBlankForAuth(resMap.get("BusinessLicenceSocialAuthItem")) ){
                    String firstName = (String)((Map)resMap.get("BusinessLicenceSocialAuthItem")).get("owner");
                 
                    if(StringUtils.isNotBlank(firstName)) {
                        return firstName;
                    }
                }else if ( !isBlankForAuth(resMap.get("SelfIdentificationCardAuthItem")) ){
                    String firstName = (String)((Map)resMap.get("SelfEmployedBusinessLicenseAuthItem")).get("owner");
                    if(StringUtils.isNotBlank(firstName)) {
                        return firstName;
                    }
                }else if ( !isBlankForAuth(resMap.get("SelfEmployedBusinessLicenseAuthItem")) ){
                    String firstName = (String)((Map)resMap.get("SelfEmployedBusinessLicenseAuthItem")).get("owner");
                    if(StringUtils.isNotBlank(firstName)) {
                        return firstName;
                    }
                }
                
                if ( !isBlankForAuth(resMap.get("AuthorizationLetterAuthItem")) ){
                    String firstName = (String) ((Map) resMap
                            .get("AuthorizationLetterAuthItem")).get("owner");
                    if(StringUtils.isNotBlank(firstName)) {
                        return firstName;
                    }
                }
				
			}
		}
		return null;
	}
	
	private static boolean isBlankForAuth(Object o){
		if ( o == null || ((Map)o).size() == 0 )
			return true;
		
		return false;
	}
	
	//调用认证，查询内部商户
	public static boolean innerMerchantQuery(String merchantNo){
		Map<String,String> params= new HashMap<String, String>();
		params.put("memberid", merchantNo);
//		String url = ConfigUtil.getString("app.productenter.innermerchant.query");
		String url = "http://172.24.5.53:8092/authRequest/queryIsInnerMerchant.do";
		String res = null; 
		try {
			res = HttpUtil.doPost(url, params);
		} catch ( Exception e ){
			logger.error("请求企业站查询内部商户异常:"+e.toString());
			return true;
		}
		logger.debug("请求企业站查询内部商户返回数据:"+res);
		if (StringUtils.isBlank(res)){
			return true;
		}
		Gson gson = GsonUtil.getInstanceWithDateFormat();
		QueryResponse query = gson.fromJson(res, QueryResponse.class);
		if("000000".equalsIgnoreCase(query.getResponseCode())&&"true".equalsIgnoreCase(query.getData())){
			return true;
		}else{
			return false;
		}
	}
	public static void main(String[] args) {
		innerMerchantQuery("110027213");
	}
}
