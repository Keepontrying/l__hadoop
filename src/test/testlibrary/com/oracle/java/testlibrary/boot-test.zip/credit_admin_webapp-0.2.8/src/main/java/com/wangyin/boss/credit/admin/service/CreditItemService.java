package com.wangyin.boss.credit.admin.service;

import com.wangyin.boss.credit.admin.entity.CreditItem;
import com.wangyin.boss.credit.admin.entity.CreditItemHistory;

import java.util.List;

/**
 * @author jiangbo
 * @since 2017/3/22
 */
public interface CreditItemService {

    /**
     * 返回包含sku的list
     *
     * @param creditItem
     * @return
     */
    List<CreditItem> selectItemAndSkuByParam(CreditItem creditItem);
    /**
     * 返回包含sku的Historylist
     * @param creditItemHistory
     * @return
     */
    List<CreditItemHistory> selectItemHisAndSkuByParam(CreditItemHistory creditItemHistory);

    /**
     * count
     *
     * @param creditItem
     * @return
     */
    int selectItemAndSkuCountByParam(CreditItem creditItem);
    /**
     * count  History
     *
     * @param creditItemHistory
     * @return
     */
    int selectItemHisAndSkuCountByParam(CreditItemHistory creditItemHistory);

    /**
     * 有选择的更新CreditItem
     *
     * @param creditItem
     * @return
     */
    int updateByPrimaryKeySelective(CreditItem creditItem);


    /**
     * 插入
     * @param creditItem
     * @return
     */
    int insertSelective(CreditItem creditItem);

    /**
     * 插入历史,事务处理类
     * @param
     * @return
     */
    public boolean transactionSaveItemAndSkuAndHistory(CreditItem creditItem) throws Exception;
}
