package com.wangyin.boss.credit.enterprise.utils;

import java.util.List;

public class School {
	private String name;
	private String address;
	private int startYear;
	private boolean is211;
	private List<Class> classes;
	private List<Teacher> teachers;
	private Hospital hospital;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public List<Class> getClasses() {
		return classes;
	}
	public void setClasses(List<Class> classes) {
		this.classes = classes;
	}
	public List<Teacher> getTeachers() {
		return teachers;
	}
	public void setTeachers(List<Teacher> teachers) {
		this.teachers = teachers;
	}
	public int getStartYear() {
		return startYear;
	}
	public void setStartYear(int startYear) {
		this.startYear = startYear;
	}
	public boolean isIs211() {
		return is211;
	}
	public void setIs211(boolean is211) {
		this.is211 = is211;
	}
	public Hospital getHospital() {
		return hospital;
	}
	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}
}
