package com.wangyin.boss.credit.admin.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.PaymentOrder;

/** 
* @desciption : 缴费单dao
* @author : yangjinlin@jd.com
* @date ：2017年1月3日 下午4:52:56 
* @version 1.0 
* @return  */
@SqlMapper
@Component
public interface PaymentOrderMapper {

	/**
	 * 查询包量缴费单---分页
	 * @param paymentOrder
	 * @return
	 */
	List<PaymentOrder> selectPackageByParam(PaymentOrder paymentOrder);

	/**
	 * 查询包量缴费单总数目---分页
	 * @param paymentOrder
	 * @return
	 */
	int selectPackageCountByParam(PaymentOrder paymentOrder);

	/**
	 * 查询单笔缴费单---分页
	 * @param paymentOrder
	 * @return
	 */
	List<PaymentOrder> selectSingleByParam(PaymentOrder paymentOrder);

	/**
	 * 查询单笔缴费单总数目---分页
	 * @param paymentOrder
	 * @return
	 */
	int selectSingleCountByParam(PaymentOrder paymentOrder);

}
