package com.wangyin.boss.credit.enterprise.service;

import com.wangyin.boss.credit.enterprise.beans.SensitiveWord;
import com.wangyin.boss.credit.enterprise.beans.SensitiveWordQueryParam;
import com.wangyin.operation.common.beans.Page;

/**
 * @author huangzhiqiang
 * @data 2018/11/19
 */
public interface SensitiveWordService {

    Long insert(SensitiveWord word);

    void delete(Long id);

    void update(SensitiveWord word);

    /**
     * 条件查询
     *
     * @param param
     * @return
     */
    Page<SensitiveWord> query(SensitiveWordQueryParam param);
}
