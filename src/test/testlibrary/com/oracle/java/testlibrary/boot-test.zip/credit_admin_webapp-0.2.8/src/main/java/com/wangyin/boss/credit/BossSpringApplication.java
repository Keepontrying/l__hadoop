package com.wangyin.boss.credit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ImportResource;

@ImportResource(locations = {"classpath:applicationContext.xml"})
@SpringBootApplication
public class BossSpringApplication extends SpringBootServletInitializer {
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(BossSpringApplication.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(BossSpringApplication.class, args);
	}
}
