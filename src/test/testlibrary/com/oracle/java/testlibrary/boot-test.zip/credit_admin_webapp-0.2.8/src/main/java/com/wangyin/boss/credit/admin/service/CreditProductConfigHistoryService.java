package com.wangyin.boss.credit.admin.service;

import com.wangyin.boss.credit.admin.entity.CreditChangeRecord;
import com.wangyin.boss.credit.admin.entity.CreditProductConfig;
import com.wangyin.boss.credit.admin.entity.CreditProductConfigHistory;

import java.util.List;
import java.util.Map;

/** 
* @desciption : 产品服务历史配置接口方法
* @author : liuwei55@jd.com
* @date ：2017年4月13日 下午3:24:55
* @version 1.0 
* @return  */
public interface CreditProductConfigHistoryService {

	/**
	 * 根据查询条件查询  产品服务配置  历史 分页
	 * @return
	 */
	List<CreditProductConfigHistory> selectCreProdConfHisByPams(CreditProductConfigHistory creditProductConfigHistory);
	/**
	 * 根据查询条件查询  产品服务配置 历史数量
	 * @return
	 */
	int selectCountConfHisByPams(CreditProductConfigHistory creditProductConfigHistory);
		/**
	 * 根据产品id、商户Id 新增 产品历史服务配置 信息
	 * @return
	 */
	int addCreProdConfHistory(CreditProductConfigHistory creditProductConfigHistory) throws Exception;
}
