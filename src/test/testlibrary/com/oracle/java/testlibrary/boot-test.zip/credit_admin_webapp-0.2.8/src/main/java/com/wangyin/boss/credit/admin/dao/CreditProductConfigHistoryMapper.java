package com.wangyin.boss.credit.admin.dao;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditProductConfig;
import com.wangyin.boss.credit.admin.entity.CreditProductConfigHistory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/** 
* @desciption : 产品服务历史配置 mapper映射类
* @author : liuwei55@jd.com
* @date ：2017年4月13日 下午5:32:58
* @version 1.0 
* @return  */

@SqlMapper
@Component
public interface CreditProductConfigHistoryMapper {

	/**
	 * 根据查询条件查询  产品历史服务配置  分页
	 * @return
	 */
	List<CreditProductConfigHistory> selectCreProdConfHisByPams(CreditProductConfigHistory creditProductConfigHistory);
	/**
	 * 根据产品id、商户Id 新增 产品历史服务配置 信息
	 * @return
	 */
	int addCreProdConfHistory(CreditProductConfigHistory creditProductConfigHistory);
	/**
	 * 根据查询条件查询  产品服务配置 历史数量
	 * @return
	 */
	int selectCountConfHisByPams(CreditProductConfigHistory creditProductConfigHistory);
	
}
