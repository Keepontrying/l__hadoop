package com.wangyin.boss.credit.admin;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wangyin.boss.credit.admin.dao.CreditMerchantMapper;
import com.wangyin.boss.credit.admin.entity.CreditMerchant;

/**
 * 商户关系表 测试类
 * 
 * @author wyhaozhihong
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:applicationContext.xml" })
public class CreditMerchantTest {

	@Autowired
	CreditMerchantMapper creditMerchantMapper;
	
	@Test
	public void selectByMerchantNoTest(){
		CreditMerchant creditMerchant = creditMerchantMapper.selectByMerchantNo("111");
		System.out.println(creditMerchant);
	}
	
	@Test
	public void insertTest(){
		CreditMerchant creditMerchant = new CreditMerchant();
		creditMerchant.setMerchantStatus("close");
		creditMerchant.setMerchantNo("111");
		creditMerchant.setMerchantName("test");
		creditMerchant.setCreator("hzh");
		creditMerchantMapper.insert(creditMerchant);
		Integer merchantId = creditMerchant.getMerchantId();
		System.out.println(merchantId);
	}
	

}
