package com.wangyin.boss.credit.enterprise.entity;

import java.util.List;

import com.wangyin.boss.credit.admin.entity.EnterpriseProductItemSku;

/** 
* @desciption : 企业征信产品及其包量信息model类
* @author : yangjinlin@jd.com
* @date ：2017年3月20日 下午9:03:39 
* @version 1.0 
* @return  */
public class EnterpriseProductItemSkuModel {

	/**
	 * 普通产品信息List
	 */
	private List<EnterpriseProductItemSku> enterprProdItemSkuList;

	/**
	 * VIP产品信息List
	 */
	private List<EnterpriseProductItemSku> enterprVIPProdItemSkuList;
	/**
	 * Mini尽调响应时间计价List
	 */
	private List<MiniCompletionPriceModel> miniCompleList;

	/**
	 * 标准报告时间计价List
	 */
	private List<StandardReportComplPriceModel> standardRepoCompleList;

	public List<EnterpriseProductItemSku> getEnterprProdItemSkuList() {
		return enterprProdItemSkuList;
	}

	public void setEnterprProdItemSkuList(List<EnterpriseProductItemSku> enterprProdItemSkuList) {
		this.enterprProdItemSkuList = enterprProdItemSkuList;
	}
	public List<EnterpriseProductItemSku> getEnterprVIPProdItemSkuList() {
		return enterprVIPProdItemSkuList;
	}

	public void setEnterprVIPProdItemSkuList(List<EnterpriseProductItemSku> enterprVIPProdItemSkuList) {
		this.enterprVIPProdItemSkuList = enterprVIPProdItemSkuList;
	}
	public List<MiniCompletionPriceModel> getMiniCompleList() {
		return miniCompleList;
	}

	public void setMiniCompleList(List<MiniCompletionPriceModel> miniCompleList) {
		this.miniCompleList = miniCompleList;
	}

	public List<StandardReportComplPriceModel> getStandardRepoCompleList() {
		return standardRepoCompleList;
	}

	public void setStandardRepoCompleList(List<StandardReportComplPriceModel> standardRepoCompleList) {
		this.standardRepoCompleList = standardRepoCompleList;
	}
}
