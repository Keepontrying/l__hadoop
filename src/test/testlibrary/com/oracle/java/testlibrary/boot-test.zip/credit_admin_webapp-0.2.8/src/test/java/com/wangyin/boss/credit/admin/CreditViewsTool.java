package com.wangyin.boss.credit.admin;

import com.wangyin.operation.util.viewUtil.ViewExportUtil;
import com.wangyin.operation.util.viewUtil.enums.EnvironmentEnum;

/** 
* @desciption : 征信前端页面打包
* @author : yangjinlin@jd.com
* @date ：2018年1月16日 上午11:32:58 
* @version 1.0 
* @return  */
public class CreditViewsTool {

	public static final EnvironmentEnum environmentEnum = EnvironmentEnum.gn;
	public static final String projectName = "credit";
	public static final String viewPath = "D:\\运营后台_资料留备\\admin_dev_doc\\00平台建设\\00运营管理平台\\05插件\\credit\\branches";

	public static void main(String[] args) {
		ViewExportUtil.export(viewPath, projectName, environmentEnum);
	}
	
}
