package com.wangyin.boss.credit.admin.service;

import java.util.List;

import com.wangyin.boss.credit.admin.entity.CreditBill;
import com.wangyin.boss.credit.enterprise.beans.CallCaseInfo;
import com.wangyin.boss.credit.enterprise.beans.CallCaseInfoQueryParam;

/**
 * 
 * @author wyhaozhihong
 *
 */
public interface CreditBillService {
	
	/**
	 * 根据条件查询账单数据 分页
	 * @param creditBill
	 * @return
	 */
	List<CreditBill> selectByParam(CreditBill creditBill);
	
	/**
	 * 根据条件查询账单总条数
	 * @param creditBill
	 * @return
	 */
	int selectCountByParam(CreditBill creditBill);
	
	/**
	 * 根据条件查询每月账单数据 分页
	 * @param creditBill
	 * @return
	 */
	List<CreditBill> selectMonthBillByParam(CreditBill creditBill);
	
	/**
	 * 根据条件查询每月账单总条数
	 * @param creditBill
	 * @return
	 */
	int selectMonthBillCountByParam(CreditBill creditBill);

	/*
	 * 查询产品调用情况总行数
	 */
	int queryProductBillPageCount(String productName, String beginDate, String endDate);

	/*
	 * 分页查询产品调用情况列表
	 */
	List<CallCaseInfo> queryProductBillPage(String productName, String beginDate, String endDate,
			Integer start, Integer limit);

	/*
	 * 查询商户调用情况总行数
	 */
	int queryMerchantBillPageCount(String merchantName, String merchantNo, String beginDate, String endDate);

	/*
	 * 分页查询商户调用情况列表
	 */
	List<CallCaseInfo> queryMerchantBillPage(String merchantName, String merchantNo, String beginDate, String endDate,
			Integer start, Integer limit);

	/*
	 * 查询商户+产品调用情况总行数
	 */
	int queryMerProBillPageCount(String merchantName, String merchantNo, String productName, String beginDate,
			String endDate);

	/*
	 * 分页查询商户+产品调用情况列表
	 */
	List<CallCaseInfo> queryMerProBillPage(String merchantName, String merchantNo, String productName, String beginDate,
			String endDate,
			Integer start, Integer limit);

	/**
	 * 查询不同维度次数统计
	 * @param caseInfoQueryParam
	 * @return
	 */
    CallCaseInfo queryBillFiledsTotalCount(CallCaseInfoQueryParam caseInfoQueryParam);
}
