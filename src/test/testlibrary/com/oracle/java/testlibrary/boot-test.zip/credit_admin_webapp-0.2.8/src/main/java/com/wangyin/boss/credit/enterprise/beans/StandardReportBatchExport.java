package com.wangyin.boss.credit.enterprise.beans;

/**
 * Created by zhanghui12 on 2018/7/25.
 */
public class StandardReportBatchExport {
    private String expectedPackageTime;//预计返回结果时间
    private Integer successCount;//成功条数
    private String timeInterval;//提交时选择的时间间隔3,5
    private String packageTime;//打包时间
    private String status;//状态
    private String merchantName;//商户名称
    private String authFileName;//授权书名称
    private String merchantNo;
    private String batchNo;
    private Integer batchCount;
    private String createdDate;
    private String companyName;

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getExpectedPackageTime() {
        return expectedPackageTime;
    }

    public void setExpectedPackageTime(String expectedPackageTime) {
        this.expectedPackageTime = expectedPackageTime;
    }

    public Integer getSuccessCount() {
        return successCount;
    }

    public void setSuccessCount(Integer successCount) {
        this.successCount = successCount;
    }

    public String getTimeInterval() {
        return timeInterval;
    }

    public void setTimeInterval(String timeInterval) {
        this.timeInterval = timeInterval;
    }

    public String getPackageTime() {
        return packageTime;
    }

    public void setPackageTime(String packageTime) {
        this.packageTime = packageTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getAuthFileName() {
        return authFileName;
    }

    public void setAuthFileName(String authFileName) {
        this.authFileName = authFileName;
    }

    public String getMerchantNo() {
        return merchantNo;
    }

    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public Integer getBatchCount() {
        return batchCount;
    }

    public void setBatchCount(Integer batchCount) {
        this.batchCount = batchCount;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }
}
