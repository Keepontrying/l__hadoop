package com.wangyin.boss.credit.enterprise.constants;
/** 
* @desciption : 特殊产品常量类
* @author : yangjinlin@jd.com
* @date ：2018年1月10日 下午8:43:48 
* @version 1.0 
* @return  */
public class SpecialProductConstant {

	public static final String PRODUCT_NAME_MINI = "mini尽调";
	public static final String PRODUCT_NAME_STANDARD_REPORT = "mini尽调";

}
