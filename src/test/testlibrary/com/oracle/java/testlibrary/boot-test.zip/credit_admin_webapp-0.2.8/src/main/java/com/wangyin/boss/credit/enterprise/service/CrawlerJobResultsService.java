package com.wangyin.boss.credit.enterprise.service;

import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResults;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResultsQueryParam;
import com.wangyin.operation.common.beans.Page;

import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2018/11/20
 */
public interface CrawlerJobResultsService {

    void insert(CrawlerJobResults results);

    Page<CrawlerJobResults> query(CrawlerJobResultsQueryParam param);

    Page<CrawlerJobResults> queryList(CrawlerJobResultsQueryParam param);


}
