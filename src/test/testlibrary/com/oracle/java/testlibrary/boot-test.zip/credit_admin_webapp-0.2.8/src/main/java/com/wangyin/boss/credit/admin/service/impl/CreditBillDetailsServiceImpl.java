package com.wangyin.boss.credit.admin.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wangyin.boss.credit.admin.dao.CreditBillDetailsMapper;
import com.wangyin.boss.credit.admin.entity.CreditBillDetails;
import com.wangyin.boss.credit.admin.service.CreditBillDetailsService;

/**
 * 
 * @author wyhaozhihong
 *
 */
@Service
public class CreditBillDetailsServiceImpl implements CreditBillDetailsService {
	
	@Autowired
	private CreditBillDetailsMapper creditBillDetailsMapper;
	
	@Override
	public List<CreditBillDetails> selectPerDayBillDetails(CreditBillDetails creditBillDetails) {
		return creditBillDetailsMapper.selectPerDayBillDetails(creditBillDetails);
	}

	@Override
	public List<CreditBillDetails> selectPerMonthBillDetails(CreditBillDetails creditBillDetails) {
		return creditBillDetailsMapper.selectPerMonthBillDetails(creditBillDetails);
	}

}
