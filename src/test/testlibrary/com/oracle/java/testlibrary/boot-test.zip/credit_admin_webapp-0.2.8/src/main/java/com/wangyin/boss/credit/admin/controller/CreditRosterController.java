package com.wangyin.boss.credit.admin.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wangyin.boss.credit.admin.entity.CreditRoster;
import com.wangyin.boss.credit.admin.enums.CreditMerchantTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditRosterStatusEnum;
import com.wangyin.boss.credit.admin.service.CreditRosterService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/**
 * 商户IP名单管理
 * @author wyhaozhihong
 *
 */
@Controller
@RequestMapping("/creditRoster")
public class CreditRosterController extends BaseController{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CreditRosterController.class);
	
	@Autowired
	CreditRosterService creditRosterService;
	
	/**
	 * 根据merchantId查询所有的IP域名
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toLookCreditRosterDomain.view")
	public Map<String, String> toLookCreditRosterDomain(@RequestParam Map<String, String> map) {
		Map<String,String> resultMap = new HashMap<String, String>();
		CreditRoster creditRoster = new CreditRoster();
		creditRoster.setMerchantId(Integer.valueOf(map.get("merchantId")));
		creditRoster.setRosterStatus(CreditRosterStatusEnum.CREDIT_ROSTER_OPEN.toName());
		String domain = creditRosterService.selectByMerchantId(creditRoster);
		domain = domain.replace(";", ";<br/>");
		resultMap.put("domain", domain);
		return resultMap;
	}
	
	/**
	 * 根据条件查询 商户IP名单管理 分页
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryCreditRoster.do")
	public Map<String, Object> doQueryCreditRoster(@RequestParam Map<String, String> map) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "查询成功");
		
		if(StringUtils.isBlank(map.get("merchantNo")) && StringUtils.isBlank(map.get("merchantName"))){
			resultMap.put("rows", null);
			resultMap.put("total", 0);
			resultMap.put("success", false);
			resultMap.put("message", "商户号和商户名称不能同时为空！");
			return resultMap;
		}
		
		List<CreditRoster> creditRosterList = new ArrayList<CreditRoster>();
		List<CreditRoster> crOpenList = new ArrayList<CreditRoster>();
		List<CreditRoster> crList = new ArrayList<CreditRoster>();
		int creditRosterCount = 0;
		
		try {
			CreditRoster creditRoster = new CreditRoster();
			creditRoster.setMerchantNo(map.get("merchantNo").trim());
			creditRoster.setMerchantName(map.get("merchantName").trim());
			creditRoster.setStart(map.get("start"));
			creditRoster.setLimit(map.get("limit"));
			if(map.containsKey("merchantType")){
				if(CreditMerchantTypeEnum.ENTERPRISE.toName().equalsIgnoreCase(map.get("merchantType"))){//
					creditRoster.setMerchantTypeList(Arrays.asList((CreditMerchantTypeEnum.ENTERPRISE.toName()+","+CreditMerchantTypeEnum.ALL.toName()).substring(0).split(",")));
				}else{//只要不是企征就默认为个征
					creditRoster.setMerchantTypeList(Arrays.asList((CreditMerchantTypeEnum.PERSON.toName()+","+CreditMerchantTypeEnum.ALL.toName()).substring(0).split(",")));
				}
			}else{//默认为个征PERSON
				creditRoster.setMerchantTypeList(Arrays.asList((CreditMerchantTypeEnum.PERSON.toName()+","+CreditMerchantTypeEnum.ALL.toName()).substring(0).split(",")));
			}
			crList = creditRosterService.selectByParam(creditRoster);
			creditRosterCount = creditRosterService.selectCountByParam(creditRoster);
//			if(!CollectionUtils.isEmpty(creditRosterList) && null != creditRosterList.get(0).getDomain() && 
//					!"".equals(creditRosterList.get(0).getDomain())){//如果该商户在ip名单表中存在，则过滤掉已关闭的ip记录
//				creditRoster.setRosterStatus(CreditRosterStatusEnum.CREDIT_ROSTER_OPEN.toName());
//				creditRosterList = creditRosterService.selectByParam(creditRoster);
//			}
//			for (CreditRoster creditRoster1 : creditRosterList) {//仅展示可用的ip名单
//				if(creditRoster1.getDomain() != null){
//					String domain1 = null;
//					if(creditRoster1.getDomain().split(";").length > 3 ){
//						String[] domains = creditRoster1.getDomain().split(";");
//						domain1 = domains[0] + ";<br/>" + domains[1] + ";<br/>" + domains[2] + ";<br/>......";
// 					}else{
// 						domain1 = creditRoster1.getDomain().replace(";", ";<br/>");
// 					}
//					creditRoster1.setDomain1(domain1);
//					creditRoster1.setDomain(creditRoster1.getDomain().replace(";", ";<br/>"));
//				}
//			}
			if(CollectionUtils.isEmpty(crList)){
				resultMap.put("rows", crList);
				resultMap.put("total", 0);
				return resultMap;
			}
			for(CreditRoster cr:  crList){
				if(CreditRosterStatusEnum.CREDIT_ROSTER_OPEN.toName().equals(cr.getRosterStatus())){
					crOpenList.add(cr);
				}
			}
			String domain = "";
			String domain1 = "";
			CreditRoster crShow = crList.get(0);
			for(CreditRoster crOpen : crOpenList){
				domain = domain + crOpen.getDomain() +";";
			}
			crShow.setDomain(domain);
			if(crShow.getDomain().split(";").length < 3){
				crShow.setDomain1(domain.substring(0, "".equals(domain) ? 0: (domain.length()-1) ).replace(";", ";<br/>"));
			}else{
				String[] domains = crShow.getDomain().split(";");
				domain1 = domains[0] + ";<br/>" + domains[1] + ";<br/>" + domains[2] + ";<br/>......";
				crShow.setDomain1(domain1);
			}
			creditRosterList.add(crShow);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "查询异常");
		}
		resultMap.put("rows", creditRosterList);
		resultMap.put("total", creditRosterCount);
		
		return resultMap;
	}
	
	/**
	 * 编辑IP域名
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toEditCreditRoster.view")
	public Map<String, Object> toEditCreditRoster(@RequestParam Map<String, String> map) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		CreditRoster creditRoster = new CreditRoster();
		creditRoster.setMerchantId(Integer.valueOf(map.get("merchantId")));
		if("true".equals(map.get("hasDomainFlag"))){//该商户号已有ip名单，则仅查询有效ip名单
			creditRoster.setRosterStatus(CreditRosterStatusEnum.CREDIT_ROSTER_OPEN.toName());
		}
		if(map.containsKey("merchantType")){
			if(CreditMerchantTypeEnum.ENTERPRISE.toName().equalsIgnoreCase(map.get("merchantType"))){//
				creditRoster.setMerchantTypeList(Arrays.asList((CreditMerchantTypeEnum.ENTERPRISE.toName()+","+CreditMerchantTypeEnum.ALL.toName()).substring(0).split(",")));
			}else{//只要不是企征就默认为个征
				creditRoster.setMerchantTypeList(Arrays.asList((CreditMerchantTypeEnum.PERSON.toName()+","+CreditMerchantTypeEnum.ALL.toName()).substring(0).split(",")));
			}
		}else{//默认为个征PERSON
			creditRoster.setMerchantTypeList(Arrays.asList((CreditMerchantTypeEnum.PERSON.toName()+","+CreditMerchantTypeEnum.ALL.toName()).substring(0).split(",")));
		}
		List<CreditRoster> creditRosterList = creditRosterService.selectInfoByMerchantId(creditRoster);
		if(CollectionUtils.isEmpty(creditRosterList)){
			resultMap.put("merchantNo", map.get("merchantNo"));
			resultMap.put("merchantName", map.get("merchantName"));
			resultMap.put("merchantId", map.get("merchantId"));
		}else{
			resultMap.put("merchantNo", creditRosterList.get(0).getMerchantNo());
			resultMap.put("merchantName", creditRosterList.get(0).getMerchantName());
			resultMap.put("merchantId", creditRosterList.get(0).getMerchantId());
		}
		resultMap.put("creditRosterList", creditRosterList);
		return resultMap;
	}
	
	/**
	 * 删除IP
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doDeleteDomain.do")
	public Map<String, Object> doDeleteDomain(@RequestParam Map<String, String> map) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "删除成功");
		CreditRoster creditRoster = new CreditRoster();
		creditRoster.setRosterId(Integer.valueOf(map.get("rosterId")));
		creditRoster.setRosterStatus(CreditRosterStatusEnum.CREDIT_ROSTER_CLOSE.toName());
		int count = creditRosterService.deleteDomain(creditRoster);
		if(count != 1){
			resultMap.put("success", false);
			resultMap.put("message", "删除失败！");
		}
		return resultMap;
	}
	/**
	 * 新增ip名单信息
	 * @param map
	 * @param user
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doCreateCreditRoster.biz")
	public Map<String, Object> doCreateCreditRoster(@RequestParam Map<String, String> map, String user) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		resultMap.put("success", true);
		resultMap.put("message", "创建成功");
		
		if(StringUtils.isBlank(map.get("domain"))){
			resultMap.put("success", false);
			resultMap.put("message", "请添加IP后再保存！");
			return resultMap;
		}
		
		String userName = null;
		try {
			userName = getLoginRealName(user);
		} catch (Exception e) {
			LOGGER.error(e);
			userName = "error";
		}
		
		CreditRoster creditRoster = new CreditRoster();
		creditRoster.setMerchantId(Integer.valueOf(map.get("merchantId")));
		creditRoster.setMerchantNo(map.get("merchantNo"));
		creditRoster.setMerchantName(map.get("merchantName"));
		creditRoster.setDomain(map.get("domain"));
		creditRoster.setRosterStatus(CreditRosterStatusEnum.CREDIT_ROSTER_OPEN.toName());
		creditRoster.setCreator(userName);
		creditRoster.setModifier(userName);
		try {
			creditRosterService.insert(creditRoster);
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("success", false);
			resultMap.put("message", "创建异常！");
		}
		return resultMap;
	}
}
