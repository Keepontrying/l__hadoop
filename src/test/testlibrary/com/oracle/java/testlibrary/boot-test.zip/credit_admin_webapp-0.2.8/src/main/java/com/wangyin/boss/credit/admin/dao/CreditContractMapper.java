package com.wangyin.boss.credit.admin.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.admin.entity.CreditContract;

@SqlMapper
@Component
public interface CreditContractMapper {
	
	List<CreditContract> selectByParam(CreditContract creditContract);
	
	int selectCountByParam(CreditContract creditContract);

	int updateContractForUpload(CreditContract contractInfo);
	
    int updateByPrimaryKeySelective(CreditContract record);
    
    CreditContract selectByPrimaryKey(Integer contractId);
    
    int insert(CreditContract record);

	List<CreditContract> selectAuditByParam(CreditContract creditContract);

	int selectCountAuditByParam(CreditContract creditContract);

	/**
	 * 根据商户号查询合同表判定该商户是否创建过合同
	 * @param merchantNo
	 * @return
	 */
	List<CreditContract> selectContractByMerchantNo(String merchantNo);

	/**
	 * 根据合同参数多维度获取合同List
	 * @param contract
	 * @return
	 * @return
	 */
	List<CreditContract> selectContrByContrParam(CreditContract contract);
    
}