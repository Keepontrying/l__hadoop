package com.wangyin.boss.credit.admin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.wangyin.boss.credit.admin.beans.TextValuePairs;
import com.wangyin.boss.credit.admin.entity.CreditAccessDetails;
import com.wangyin.boss.credit.admin.enums.AccessCallModeEnum;
import com.wangyin.boss.credit.admin.enums.AccessStatusEnum;
import com.wangyin.boss.credit.admin.enums.AccessStepStatusEnum;
import com.wangyin.boss.credit.admin.enums.ChargeTypeEnum;
import com.wangyin.boss.credit.admin.enums.CreditTypeEnum;
import com.wangyin.boss.credit.admin.service.CreditAccessDetailsService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.beans.UploadFile;

/**
 * 业务详单controller
 * @author wyhaozhihong
 * @since 2016-07-05
 *
 */
@Controller
@RequestMapping("/businessDetail")
public class BusinessDetailController extends BaseController{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BusinessDetailController.class);
	
	@Autowired
	CreditAccessDetailsService creditAccessDetailsService;
	
	private static final Integer splitNumber = 30;
	
	/**
	 * 查询商户业务详单数据 分页
	 * @author wyhaozhihong
	 * @param map
	 * @param creditAccessDetails
	 * @return
	 */
	@ResponseBody
	@RequestMapping("doQueryBusinessDetail.do")
	public Map<String, Object> doQueryBuissnessDetail(@RequestParam Map<String, String> map, CreditAccessDetails creditAccessDetails) {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		try {
			creditAccessDetails.setCreditType(CreditTypeEnum.PERSON.toName());
			List<CreditAccessDetails> creditAccessDetailsList = creditAccessDetailsService.selectByParam(creditAccessDetails);
			
			for (CreditAccessDetails accessDetail : creditAccessDetailsList) {
				
				accessDetail.setAccessStatus(AccessStatusEnum.enumValueOf(accessDetail.getAccessStatus()).toDescription());
				accessDetail.setChargeType(ChargeTypeEnum.enumValueOf(accessDetail.getChargeType()).toDescription());
				accessDetail.setStepStatus(AccessStepStatusEnum.enumValueOf(accessDetail.getStepStatus()).toDescription());
				accessDetail.setCallMode(AccessCallModeEnum.enumValueOf(accessDetail.getCallMode()).toDescription());
				if(accessDetail.getRequestParam().length()>splitNumber){
					accessDetail.setRequestParamBrief( StringEscapeUtils.escapeHtml(accessDetail.getRequestParam().substring(0, splitNumber)+"...}"));
				}else{
					accessDetail.setRequestParamBrief( StringEscapeUtils.escapeHtml(accessDetail.getRequestParam())  );
				}
				if(accessDetail.getResponseParam().length()>splitNumber){
					accessDetail.setResponseParamBrief(StringEscapeUtils.escapeHtml(accessDetail.getResponseParam().substring(0, splitNumber)+"...}"));
				}else{
					accessDetail.setResponseParamBrief(StringEscapeUtils.escapeHtml(accessDetail.getResponseParam()));
				}
			}
			int creditAccessDetailsCount = creditAccessDetailsService.selectCountByParam(creditAccessDetails);
			resultMap.put("rows", creditAccessDetailsList);
			resultMap.put("total", creditAccessDetailsCount);
			
			if(AccessStatusEnum.SUCCESS.toName().equals(creditAccessDetails.getAccessStatus())){
				int successCount = creditAccessDetailsService.selectCountByParam(creditAccessDetails);
				resultMap.put("successCount", successCount);
				resultMap.put("failCount", 0);
			}else if(AccessStatusEnum.FAIL.toName().equals(creditAccessDetails.getAccessStatus())){
				resultMap.put("successCount", 0);
				int failCount = creditAccessDetailsService.selectCountByParam(creditAccessDetails);
				resultMap.put("failCount", failCount);
			}else{
				creditAccessDetails.setAccessStatus(AccessStatusEnum.SUCCESS.toName());
				int successCount = creditAccessDetailsService.selectCountByParam(creditAccessDetails);
				resultMap.put("successCount", successCount);
				creditAccessDetails.setAccessStatus(AccessStatusEnum.FAIL.toName());
				int failCount = creditAccessDetailsService.selectCountByParam(creditAccessDetails);
				resultMap.put("failCount", failCount);
			}
			
		} catch (Exception e) {
			LOGGER.error(e);
			resultMap.put("rows", new ArrayList<CreditAccessDetails>());
			resultMap.put("total", 0);
			resultMap.put("successCount", 0);
			resultMap.put("failCount", 0);
		}
		
		return resultMap;
	}
	
	/**
	 * 下载业务详单数据
	 * @author wyhaozhihong
	 * @param params
	 * @param creditAccessDetails
	 * @return
	 */
	@RequestMapping("downAccessDetailQueryResult.download")
	@ResponseBody
	public UploadFile downAccessDetailQueryResult(@RequestParam Map<String, Object> params,CreditAccessDetails creditAccessDetails) {
		return creditAccessDetailsService.downAccessDetailQueryResult(creditAccessDetails);
	}
	
	/**
	 * 业务详单的详细状态枚举类中  获取状态列表
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryAccessStepStatusInEnum.do")
	public Map<String, Object> queryAccessStepStatusInEnum(@RequestParam Map<String, Object> map) {
		Map<String, Object> result = new HashMap<String, Object>();
		List<TextValuePairs> list = new ArrayList<TextValuePairs>();
		for(AccessStepStatusEnum status : AccessStepStatusEnum.values()){
			if(null == status.toName() || "NULL".equals(status.toName())){
				continue;
			}else{
				TextValuePairs pairs = new TextValuePairs(status.toDescription(), status.toName());
				list.add(pairs);
			}
		}
		result.put("accessStepStatusList", list);
		return result;
	}
	
	/**
	 * 业务详单的详细状态枚举类中  获取状态列表
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryAccessFailStepStatusInEnum.do")
	public Map<String, Object> queryAccessFailStepStatusInEnum(@RequestParam Map<String, Object> map) {
		Map<String, Object> result = new HashMap<String, Object>();
		List<TextValuePairs> list = new ArrayList<TextValuePairs>();
		for(AccessStepStatusEnum status : AccessStepStatusEnum.values()){
			if(null == status.toName() || "NULL".equals(status.toName()) ||
					"SUCCESS".equals(status.toName()) || "BILLFAIL".equals(status.toName())){
				continue;
			}else{
				TextValuePairs pairs = new TextValuePairs(status.toDescription(), status.toName());
				list.add(pairs);
			}
		}
		result.put("accessFailStepStatusList", list);
		return result;
	}
	
	/**
	 * 根据accessId查询所有的详细信息
	 * @param map
	 * @return
	 */
	@ResponseBody
	@RequestMapping("toShowMoreAccessDetailInfo.view")
	public Map<String, String> toShowMoreAccessDetailInfo(@RequestParam Map<String, String> map) {
		Map<String,String> resultMap = new HashMap<String, String>();
		CreditAccessDetails accessDetail = new CreditAccessDetails();
		accessDetail.setAccessId(Integer.valueOf(map.get("accessId")));
		CreditAccessDetails cad = creditAccessDetailsService.selectAccessDetailById(accessDetail);
		if("REQP".equals(map.get("strFlag"))){//REQP---请求参数
			resultMap.put("resultStr", StringEscapeUtils.escapeHtml(cad.getRequestParam()).replace(",", ",<br/>"));
		}else if("RESPP".equals(map.get("strFlag"))){//RESPP---返回参数
			resultMap.put("resultStr", StringEscapeUtils.escapeHtml(cad.getResponseParam()).replace(",", ",<br/>"));
		}else if("RETC".equals(map.get("strFlag"))){//RETC---底层接口返回码
			resultMap.put("resultStr", StringEscapeUtils.escapeHtml(cad.getReturnCode()).replace(",", ",<br/>"));
		}
		
		return resultMap;
	}
	
}
