package com.wangyin.boss.credit.admin;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

/**
 * @author jiangbo
 * @since 2017/3/20
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
public class BaseTest {

    @Resource
    ApplicationContext applicationContext;
    @Test
    public void test() {
        System.out.println(applicationContext);
    }
}
