package com.wangyin.boss.credit.admin.service.impl;

import com.jd.jr.boss.credit.domain.common.entity.CreditPaymentOffline;
import com.jd.jr.boss.credit.domain.common.entity.CreditPostBillMonth;
import com.jd.jr.boss.credit.facade.authen.api.CreditPaymentOfflineFacade;
import com.jd.jr.boss.credit.facade.authen.beans.param.PaymentOfflineQueryParam;
import com.wangyin.boss.credit.admin.service.PaymentOfflineService;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.beans.Page;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by anmeng on 2017/9/14.
 */
@Service
public class PaymentOfflineServiceImpl implements PaymentOfflineService {

    private Logger logger = LoggerFactory.getLogger(PaymentOfflineServiceImpl.class);

    @Resource
    private CreditPaymentOfflineFacade paymentOfflineFacade;

    /**
     * 查询线下付款单
     *
     * @param queryParam
     * @return
     */
    @Override
    public Page<CreditPaymentOffline> query(PaymentOfflineQueryParam queryParam) {
        return paymentOfflineFacade.query(queryParam);
    }

    /**
     * 创建线下收款单
     *
     * @param paymentOffline
     */
    @Override
    public void createPaymentOffline(CreditPaymentOffline paymentOffline) {
        paymentOfflineFacade.create(paymentOffline);
    }
}
