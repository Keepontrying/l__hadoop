package com.wangyin.boss.credit.enterprise.dao;

import com.wangyin.admin.frame.annotation.SqlMapper;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResults;
import com.wangyin.boss.credit.enterprise.beans.CrawlerJobResultsQueryParam;
import com.wangyin.boss.credit.enterprise.beans.CrawlerWord;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author huangzhiqiang
 * @data 2018/11/20
 */
@SqlMapper
@Component
public interface CrawlerJobResultsMapper {

    Long insert(CrawlerJobResults results);

    Long insertWord(CrawlerWord word);

    Integer queryCount(CrawlerJobResultsQueryParam param);

    List<CrawlerWord> queryWord(Long jobResId);

    List<CrawlerJobResults> query(CrawlerJobResultsQueryParam param);
}
