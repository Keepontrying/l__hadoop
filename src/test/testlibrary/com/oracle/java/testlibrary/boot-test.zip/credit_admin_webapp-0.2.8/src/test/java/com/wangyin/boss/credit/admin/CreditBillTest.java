package com.wangyin.boss.credit.admin;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.wangyin.boss.credit.admin.dao.CreditBillDetailsMapper;
import com.wangyin.boss.credit.admin.dao.CreditBillMapper;
import com.wangyin.boss.credit.admin.entity.CreditBill;
import com.wangyin.boss.credit.admin.entity.CreditBillDetails;

/**
 * 商户账单 测试类
 * 
 * @author wyhaozhihong
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath*:applicationContext.xml" })
public class CreditBillTest {

	@Autowired
	CreditBillMapper creditBillMapper;
	
	@Autowired
	CreditBillDetailsMapper creditBillDetailsMapper;
	
//	@Test
	public void insert(){
		CreditBill record = new CreditBill();
		record.setBillNo("110103531-01-20160719-001");
		record.setStartDate(new Date());
		record.setMonthDate("201607");
		record.setMerchantId(28);
		record.setMerchantNo("110028018");
		record.setMerchantName("京东支付待结算账户");
		record.setProductId(1);
		record.setPacketCount(100);
		record.setSingleAmount(3000l);
		record.setBillStatus("open");
		record.setCreator("haozhihong");
		creditBillMapper.insert(record);
	}
	
	@Test
	public void insertDetail(){
		CreditBillDetails record = new CreditBillDetails();
		record.setBillId(4);
		record.setStartDate(new Date());
		record.setMerchantId(28);
		record.setStrategyId(113);
		record.setChargeType("package");
		record.setExpendCount(3000L);
		record.setCreator("haozhihong");
		creditBillDetailsMapper.insert(record);
	}
	
}
