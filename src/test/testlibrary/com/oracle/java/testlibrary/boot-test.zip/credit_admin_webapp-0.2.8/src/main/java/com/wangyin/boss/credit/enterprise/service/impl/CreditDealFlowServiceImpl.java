package com.wangyin.boss.credit.enterprise.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import com.jd.jr.boss.credit.domain.common.enums.CreditPurchaseTypeEnum;
import com.wangyin.admin.frame.utils.ConfigUtil;
import com.wangyin.boss.credit.admin.entity.CreditAccessDetails;
import com.wangyin.boss.credit.admin.enums.*;
import com.wangyin.boss.credit.admin.utils.ExcelUtil;
import com.wangyin.operation.beans.UploadFile;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.jd.jr.boss.credit.facade.common.dto.CreditPage;
import com.jd.jr.boss.credit.facade.common.dto.CreditResponseData;
import com.jd.jr.boss.credit.facade.elasticsearch.api.CreditDealFlowSearchFacade;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.param.CreditDealFlowQueryParam;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.CreditDealFlowInfo;
import com.jd.jr.boss.credit.facade.elasticsearch.beans.response.QueryCountEntity;
import com.wangyin.boss.credit.enterprise.service.CreditDealFlowService;
import com.wangyin.operation.utils.GsonUtil;

/** 
* @desciption : 交易流水service接口实现类
* @author : yangjinlin@jd.com
* @date ：2018年4月17日 下午7:59:41 
* @version 1.0 
* @return  */
@Service
public class CreditDealFlowServiceImpl implements CreditDealFlowService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CreditDealFlowServiceImpl.class);
	
	@Resource
	private CreditDealFlowSearchFacade creditDealFlowSearchFacade;

	@Override
	public CreditPage<CreditDealFlowInfo> queryDealFlowPage(CreditDealFlowQueryParam dealFlowQryPrm) {
		CreditPage<CreditDealFlowInfo> dealFlowPage = null;
		try {
			LOGGER.info("[CreditDealFlowSearchServiceImpl-queryDealFlowPage] requestParam: {}, countFeil: {}", GsonUtil.getInstance().toJson(dealFlowQryPrm) );
			dealFlowPage = creditDealFlowSearchFacade.queryDealFlowList(dealFlowQryPrm);
			LOGGER.info("[CreditDealFlowSearchServiceImpl-queryDealFlowPage] reaponseData, {}", GsonUtil.getInstance().toJson(dealFlowPage) );
		} catch (Exception e) {
			LOGGER.error("[CreditDealFlowSearchServiceImpl-queryDealFlowPage] failed, {}", e);
		}
		return dealFlowPage;
	}

	@Override
	public CreditResponseData<List<QueryCountEntity>> countDealFlowByField(CreditDealFlowQueryParam dealFlowQryPrm,
			String countField) {
		CreditResponseData<List<QueryCountEntity>> countDealFlowByFieldResp = null;
		try {
			LOGGER.info("[CreditDealFlowSearchServiceImpl-countDealFlowByField] requestParam: {}, countFeild: {}", GsonUtil.getInstance().toJson(dealFlowQryPrm), countField);
			countDealFlowByFieldResp = creditDealFlowSearchFacade.countDealFlowByField(dealFlowQryPrm, countField);
			LOGGER.info("[CreditDealFlowSearchServiceImpl-countDealFlowByField] reaponseData, {}", GsonUtil.getInstance().toJson(countDealFlowByFieldResp));
		} catch (Exception e) {
			LOGGER.error("[CreditDealFlowSearchServiceImpl-countDealFlowByField] failed, {}", e);
		}
		return countDealFlowByFieldResp;
	}

	@Override
	public UploadFile downDealFlowQueryResult(CreditDealFlowQueryParam queryParam) {
        LOGGER.info("start downDealFlowQueryResult start.");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        ExcelUtil excelUtil = new ExcelUtil();
        String path = ConfigUtil.getString("app.credit.downloadpath");
        String date = (new SimpleDateFormat("yyyyMMddHHmmSS")).format(new Date());
        String month = date.substring(0, 6);
        String day = date.substring(6, 14);
        String randomStr = String.valueOf((int)(1000000+Math.random()*9900000));
        String name = "/AccessDetailQueryResult/" + month + "/交易流水查询结果_"+ day +randomStr + ".xlsx";
        String dir = path + name;
        String pathName = "/accessDetail" + name;
        String originalName = "交易流水查询结果.xlsx";
        String[] titles = { "业务流水号","商户号","商户名称","产品名称","计费方式","付费类型","单价","联调模式","计费状态","调用来源","交易时间","创建人"};
        String[] properties = { "tradeNo","merchantNo","merchantName", "productName", "chargeType", "purchaseType", "price", "callMode", "stepStatus", "resource","occursDate","creator"};
        OutputStream outputStream = null;
        String workSheetName = "交易流水查询结果";
        int start = 0;
        int limit = 5000000;
        try {
            File file = new File(dir);
            if (!file.getParentFile().exists()) {
                if (!file.getParentFile().mkdirs()) {
                }
            }
            if (!file.exists()) {
                file.createNewFile();
            }
            outputStream = new FileOutputStream(file);
            SXSSFWorkbook wb = new SXSSFWorkbook(500);//// 创建工作薄
            Sheet sheet = null;//// 声明工作表
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            for (int i = 1;; i++) {
                List<CreditDealFlowInfo> resultList = selectDealFlowByParam(queryParam);
                for (CreditDealFlowInfo dealFlowInfo : resultList) {
                    dealFlowInfo.setChargeType(ChargeTypeEnum.enumValueOf(dealFlowInfo.getChargeType()).toDescription());
                    dealFlowInfo.setPurchaseType(StringUtils.isBlank(dealFlowInfo.getPurchaseType()) ? "-":CreditPurchaseTypeEnum.getNameByCode(dealFlowInfo.getPurchaseType()));
                    dealFlowInfo.setStepStatus(AccessStepStatusEnum.enumValueOf(dealFlowInfo.getStepStatus()).toDescription());
                    dealFlowInfo.setCallMode(AccessCallModeEnum.enumValueOf(dealFlowInfo.getCallMode()).toDescription());
                    dealFlowInfo.setResource(CreditSourceEnum.enumValueOf(dealFlowInfo.getResource()).toDescription());
                    //在excel中将空数据展示为 -
                    dealFlowInfo.setMerchantNo(dealFlowInfo.getMerchantNo() == null ? "-":dealFlowInfo.getMerchantNo());
                    dealFlowInfo.setMerchantName(dealFlowInfo.getMerchantName() == null ?"-":dealFlowInfo.getMerchantName());
                    dealFlowInfo.setProductName(dealFlowInfo.getProductName() == null ?"-":dealFlowInfo.getProductName());
                    dealFlowInfo.setChargeType(dealFlowInfo.getChargeType() == null ?"-":dealFlowInfo.getChargeType());
                    dealFlowInfo.setPurchaseType(dealFlowInfo.getPurchaseType() == null ? "-" : dealFlowInfo.getPurchaseType());
                    dealFlowInfo.setCallMode(dealFlowInfo.getCallMode() == null ?"-":dealFlowInfo.getCallMode());
                    dealFlowInfo.setStepStatus(dealFlowInfo.getStepStatus() == null ?"-":dealFlowInfo.getStepStatus());
                    dealFlowInfo.setRemarks(dealFlowInfo.getRemarks() == null ? "-":dealFlowInfo.getRemarks());
                    dealFlowInfo.setResource(dealFlowInfo.getResource() == null ? "-":dealFlowInfo.getResource());
                    dealFlowInfo.setOccursDate(dealFlowInfo.getOccursDate() == null ? "-":dealFlowInfo.getOccursDate());
                    dealFlowInfo.setCreator(dealFlowInfo.getCreator() == null ?"-":dealFlowInfo.getCreator());
                }
                if(i == 1 && resultList.size() == 0){
                    sheet = excelUtil.export(wb, workSheetName, titles, sheet);
                    break;
                }
                start = i * limit;
                LOGGER.info("resultList.size()=" + resultList.size());
                int rowNum = 0;
                if (i != 1) {
                    rowNum = (i - 1) * limit;
                }
                sheet = excelUtil.export(wb, outputStream, workSheetName, titles,
                        properties, resultList, "", CreditDealFlowInfo.class, sheet,  rowNum);
                if (resultList.size() < limit) {// 最后一批则跳出循环
                    break;
                }
            }
            wb.write(outputStream);
            wb.dispose();
        } catch (Exception e) {
            LOGGER.error("downDealFlowQueryResult create result excel error,{}", e);
        } finally {
            try {
                outputStream.flush();
                outputStream.close();
            } catch (IOException e) {
                LOGGER.error(" downDealFlowQueryResult create result excel error,{}", e);
            }
        }
        UploadFile uploadfile = new UploadFile();
        uploadfile.setPathname(pathName);
        uploadfile.setOriginalName(originalName);
        uploadfile.setVersion("2.0");
        uploadfile.setTemp(true);
        LOGGER.info("ending downDealFlowQueryResult download end.");
        String endDate = sdf.format(new Date());
        return uploadfile;
	}

    public List<CreditDealFlowInfo> selectDealFlowByParam(CreditDealFlowQueryParam queryParam) {
        List<CreditDealFlowInfo> dealFlowInfoList = new ArrayList<CreditDealFlowInfo>();
        CreditResponseData<List<CreditDealFlowInfo>> respData = creditDealFlowSearchFacade.queryScrollDealFlowList(queryParam);
        if(null!=respData && respData.isSuccess() && CollectionUtils.isNotEmpty(respData.getData())){
            dealFlowInfoList = respData.getData();
            LOGGER.info("selectDealFlowByParam- creditDealFlowSearchFacade.queryScrollDealFlowList success, responseData size : {},", respData.getData().size());
        }else{
            LOGGER.info("selectDealFlowByParam- creditDealFlowSearchFacade.queryScrollDealFlowList failed.");
        }
        return dealFlowInfoList;
    }

    public static void main(String[] args) {
        System.out.println(CreditPurchaseTypeEnum.getNameByCode("--"));
    }
}
